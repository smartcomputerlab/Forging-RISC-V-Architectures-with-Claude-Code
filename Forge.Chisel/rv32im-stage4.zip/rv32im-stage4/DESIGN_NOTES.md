# Design notes: Stage 4, single-cycle RV32I core + parallel multiplication

## Architecture

| Item | Choice |
|---|---|
| ISA | RV32I (all 40 base instructions) + MUL MULH MULHSU MULHU + Zicsr (6) + MRET and WFI, machine mode only |
| Microarchitecture | Single cycle: fetch, decode, execute, memory and write-back in one clock |
| Reset | pc = `0x80000000` (`Core(resetPc = ...)`), registers and CSRs = 0 |
| Memories | Harvard, zero-wait ports: instruction and data read data are combinational functions of the address; stores land at the clock edge under a 4-bit byte mask |
| System (`RV32ITestWrapper`) | `InstructionMemory` (ROM from a hex file at 0x80000000) + `DataMemory` (RAM, 256 words, initial content from a hex file, at 0x80010000) |
| Multiplication | Combinational ("parallel"): one shared 33 × 33 signed multiplier, operands extended by their sign (signed operand) or by 0 (unsigned); the low 64 bits of the product are exact for all four instructions. 1 cycle |
| Division | Not implemented: DIV DIVU REM REMU are illegal instructions (Stage 5) |
| Interrupts | None |

## Stage progression

| Stage | Instructions | New hardware |
|---|---|---|
| 1 | R-type and I-type ALU (19) | ALU, register file, decoder, immediate generator |
| 2 | + loads, JALR (25) | Read-only data memory, load alignment, write-back mux, JALR |
| 3 | All of RV32I + Zicsr + MRET/WFI | Stores (byte strobes), branches, LUI/AUIPC/JAL, CSR file, precise exceptions |
| **4** | **+ MUL, MULH, MULHSU, MULHU** | **Combinational 33 × 33 multiplier** |
| 5 | + DIV, DIVU, REM, REMU | Sequential divider (34 cycles) |

Stage 4 is the Stage 3 core with a `Multiplier`. The core recognises the four multiplications itself (OP opcode,
funct7 = 0000001, funct3 = 0xx) and overrides the decoder's "illegal" for those only, so the Stage 3 `Decoder` and its
tests are unchanged. Register addresses and the destination come straight from the instruction, and the multiplier
result replaces the ALU result at write-back.

## Execution rules

Every cycle is exactly one of:

1. **retire** (`trace.valid`): one instruction completes and its effects are visible at the edge;
2. **trap** (`trace.trap`): the instruction changes nothing except mepc, mcause, mtval, mstatus and the pc (= mtvec).

Exception priority: illegal instruction (2) > ECALL (11) > EBREAK (3) > load misaligned (4) > store misaligned (6) >
instruction address misaligned (0).

## Choices made where the specification leaves an option

| Topic | Choice | Why |
|---|---|---|
| Misaligned loads/stores | Trap (cause 4 / 6, mtval = address) | Simplest correct option; allowed by the privileged spec |
| Misaligned branch/jump targets | Trap at the branch/jump (cause 0, mtval = target), rd not written | Required with IALIGN = 32 |
| EBREAK mtval | pc | Allowed (pc or 0) |
| ECALL mtval | 0 | Required |
| Illegal-instruction mtval | The instruction word | Allowed, helps debugging |
| FENCE | No-op | Single hart, in-order, no caches |
| FENCE.I | Illegal | Zifencei is not part of the ISA |
| WFI | No-op | No interrupts to wait for |
| mtvec | Direct mode only, low two bits read as 0 | WARL |
| mepc | Bits 1:0 read as 0 | IALIGN = 32 |
| misa | `0x40000100` (RV32, I), writes ignored | The M bit means the whole M extension; it is set in Stage 5 when division exists |
| Multiplier structure | One 33 × 33 signed array for all four instructions | One array instead of four; maps onto DSP blocks on an FPGA (about 4 DSP48 on Xilinx 7-series) |
| mstatus | MIE (bit 3) and MPIE (bit 7) writable, MPP fixed to 11 | Machine mode only |
| mie | Only MSIE, MTIE, MEIE writable | WARL |
| mip, mstatush | Read 0, writes ignored | No interrupt sources |
| mcycle / minstret | Every clock / every retired instruction; a CSR write replaces one 32-bit half of the incremented value | Deterministic and easy to model |
| cycle/instret (user) | Read-only shadows; `time` not implemented (illegal) | No real-time clock |
| Unknown CSR / write to a read-only CSR | Illegal instruction | Required |
| Data memory | 256 words of registers with an initial content, accesses outside it read 0 and are not written | Simulates and synthesises with the same initial content; no access faults in this stage |

## Verification

- Unit tests: ALU, ImmGen, RegFile, Decoder (48 instructions with their control signals, 29 illegal encodings
  the decoder still rejects the 8 M encodings, all 128 opcodes), Multiplier (484 edge pairs, 2,000 random), CsrFile, InstructionMemory and DataMemory (byte strobes,
  outside accesses), the wrapper running `program.hex` on `data.hex`.
- Program tests (`CoreProgramSpec`), each in lockstep with `RefModel` (every retirement and trap compared field by
  field) and with final registers checked against independent constants: arithmetic and logic; loads and stores of
  every size; every branch both ways, JAL, JALR; dependency chains; loops in pure RV32I (gcd by subtraction, a sum,
  shift-and-add multiplication); the four multiplications on corner cases (MIN × −1, MIN × MIN, −1 × −1, large
  operands, rd = x0); 12! with MUL; DIV/DIVU/REM/REMU trapping as illegal; Zicsr and all six exception types;
  3,000 random instructions.
- Timing (`CoreTimingSpec`): every instruction, every multiplication and every trap in one cycle.
- Planted bugs: MULHSU treating rs2 as signed, DIV/REM accepted as multiplications, the multiplier result not written
  back: all caught.
