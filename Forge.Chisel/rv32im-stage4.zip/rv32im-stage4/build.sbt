// Stage 4: RV32I + M-extension multiplications (parallel multiplier), single cycle, Zicsr, machine-mode traps (package rv32i)
ThisBuild / scalaVersion := "2.13.12"
ThisBuild / version      := "0.5.0"
ThisBuild / organization := "rv32i"

// Chisel 3.6.1 is the final Chisel 3 release; chiseltest 0.6.2 is built against it.
val chiselVersion = "3.6.1"

lazy val root = (project in file("."))
  .settings(
    name := "rv32im-stage4",
    libraryDependencies ++= Seq(
      "edu.berkeley.cs" %% "chisel3"    % chiselVersion,
      "edu.berkeley.cs" %% "chiseltest" % "0.6.2" % Test
    ),
    scalacOptions ++= Seq(
      "-language:reflectiveCalls",
      "-deprecation",
      "-feature",
      "-Xcheckinit",
      "-Ymacro-annotations",
      // chiseltest's VCD and target-directory annotations still live in the firrtl package
      "-Wconf:msg=Importing from firrtl is deprecated:s"
    ),
    addCompilerPlugin("edu.berkeley.cs" % "chisel3-plugin" % chiselVersion cross CrossVersion.full),
    Test / parallelExecution := false
  )
