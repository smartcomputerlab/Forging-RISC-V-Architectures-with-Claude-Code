# Stage 4: single-cycle RV32I core + parallel multiplication (MUL, MULH, MULHSU, MULHU) in Chisel 3

The fourth core of the series, in package `rv32i`: the Stage 3 core (all 40 RV32I instructions, Zicsr, MRET, WFI,
precise machine-mode exceptions) plus the four M-extension multiplications, executed in one cycle by a combinational
("parallel") multiplier. DIV, DIVU, REM and REMU are still illegal instructions: Stage 5 adds them with a sequential
divider. One instruction per clock cycle.

It comes with a hex-file system (`RV32ITestWrapper`: instruction ROM + data RAM), unit tests for every block, lockstep
program tests against an instruction-level reference model, VCD waveforms with GTKWave sessions, and SystemVerilog
generation. See `DESIGN_NOTES.md` for the execution rules and every design choice.

## Instructions

| Group | Instructions |
|---|---|
| U-type, jumps | LUI AUIPC JAL JALR |
| Branches | BEQ BNE BLT BGE BLTU BGEU |
| Loads, stores | LB LH LW LBU LHU, SB SH SW |
| ALU immediate | ADDI SLTI SLTIU XORI ORI ANDI SLLI SRLI SRAI |
| ALU register | ADD SUB SLL SLT SLTU XOR SRL SRA OR AND |
| System | FENCE (no-op), ECALL, EBREAK, MRET, WFI (no-op), CSRRW CSRRS CSRRC CSRRWI CSRRSI CSRRCI |
| M extension (Stage 4) | MUL MULH MULHSU MULHU (1 cycle); DIV DIVU REM REMU trap as illegal instructions |

Exceptions: illegal instruction (incl. DIV/DIVU/REM/REMU), ECALL, EBREAK, misaligned load, misaligned store, misaligned
branch/jump target. CSRs: mstatus, misa (`0x40000100`: RV32I, the M bit comes with the divisions in Stage 5), mie, mtvec, mscratch, mepc, mcause, mtval, mip, mcycle(h),
minstret(h), cycle(h), instret(h), mvendorid, marchid, mimpid, mhartid.

## Requirements

- Java 11+ (tested with 21) and sbt 1.10 (https://www.scala-sbt.org/download/); tests run on Treadle (no simulator to install)
- Optional: CIRCT firtool 1.37.0 on the PATH for firtool output from `Emit`; GTKWave to view waveforms

Pinned: Scala 2.13.12, Chisel 3.6.1 (+ chisel3-plugin), chiseltest 0.6.2, sbt 1.10.2.

## Commands

```bash
sbt test
```

```bash
sbt "testOnly rv32i.CoreProgramSpec"
```

Generate SystemVerilog for `Core` and `RV32ITestWrapper` (with `program.hex` and `data.hex`) into `generated/`:

```bash
sbt "runMain rv32i.Emit"
```

With firtool 1.37.0 on the PATH the output uses `-disable-all-randomization -strip-debug-info` (Linux shown; use
`firrtl-bin-macos-11.tar.gz` on macOS):

```bash
curl -sSL https://github.com/llvm/circt/releases/download/firtool-1.37.0/firrtl-bin-ubuntu-20.04.tar.gz | tar xz
export PATH="$PWD/firtool-1.37.0/bin:$PATH"
```

## Source files (`src/main/scala/rv32i/`)

| File | Contents |
|---|---|
| `Defs.scala` | Opcodes, exception causes, CSR addresses, `ASrc`/`WbSel`/`ImmSel`/`AluOp` enums, memory port and `Trace` bundles |
| `Decoder.scala` | RV32I + Zicsr + SYSTEM decoder; flags illegal encodings |
| `ImmGen.scala` | I/S/B/U/J immediates |
| `RegFile.scala` | 32 × 32 register file, 2 read ports, 1 write port, x0 hardwired to zero |
| `Alu.scala` | ADD, SUB, shifts, comparisons, logic |
| `CsrFile.scala` | Machine-mode CSRs, counters, trap entry and MRET |
| `Core.scala` | The single-cycle core (top-level module): decodes the 4 multiplications itself |
| `Multiplier.scala` | MUL, MULH, MULHSU, MULHU on one shared 33 × 33 signed multiplier (combinational) |
| `InstructionMemory.scala` | ROM from a hex file, mapped at 0x80000000 |
| `DataMemory.scala` | RAM with byte strobes and an initial content from a hex file, mapped at 0x80010000 |
| `RV32ITestWrapper.scala` | Core + instruction memory + data memory |
| `RefModel.scala` | Instruction-level reference model (`RefModel`) and sparse memory (`SimMemory`) |
| `Emit.scala` | SystemVerilog generation |

Project root: `program.hex` (demo: dot product of two arrays from `data.hex` with MUL, stored and reloaded, then
MULH/MULHU/MULHSU corner cases),
`data.hex`, and `tools/rv32im_filter.py` (GTKWave translate filter process: any instruction word as assembly).

## Tests (`src/test/scala/rv32i/`)

| Suite | What it checks |
|---|---|
| `AluSpec` | Every ALU operation on all pairs of 22 edge values and 3,000 random operand pairs |
| `ImmGenSpec` | All five immediate formats on 500 random instructions per format |
| `RegFileSpec` | x0 hardwired to zero, all 31 registers, write enable, old value during a write |
| `DecoderSpec` | All 48 RV32I/Zicsr/SYSTEM instructions with their control signals, 29 illegal encodings (the decoder itself still rejects the 8 M encodings: the core accepts the multiplications), all 128 major opcodes |
| `MultiplierSpec` | MUL/MULH/MULHSU/MULHU on 484 edge pairs and 2,000 random pairs against BigInt |
| `CsrFileSpec` | CSRRW/RS/RC, misa, mhartid, WARL masks, illegal accesses, counters, trap entry and MRET |
| `MemorySpec` | Instruction memory mapping, hex parsing, data RAM byte strobes and outside accesses, `program.hex` on the wrapper |
| `CoreProgramSpec` | Lockstep against `RefModel`: arithmetic, loads/stores, branches/jumps, dependency chains, RV32I loops, the 4 multiplications on corner cases, 12! with MUL, DIV/DIVU/REM/REMU trapping, Zicsr and all six exception types, 3,000 random instructions (incl. multiplications) |
| `CoreTimingSpec` | Every instruction of RV32I + Zicsr, every multiplication and every trap in exactly one cycle |
| `WaveformSpec` | Five demos that write VCDs and GTKWave sessions to `waves/` |

Test helpers: `Asm.scala` (two-pass assembler with labels), `CoreSim.scala` (lockstep harness), `Disasm.scala`,
`Gtkw.scala` (GTKWave session writer) and `TestUtil.scala` (the `WAVES` switch).

## Interface of `Core`

```scala
class Core(resetPc: Long = 0x80000000L, hartId: Int = 0) extends Module {
  val io = IO(new Bundle {
    val imem  = new InstrMemPort   // addr out, data in (combinational)
    val dmem  = new DataMemPort    // addr, re, we, wdata, wstrb out; rdata in (combinational, aligned word)
    val trace = Output(new Trace)  // one retirement or one trap per cycle
  })
}
```

## Waveforms with GTKWave

```bash
sbt "testOnly rv32i.WaveformSpec"
```

| Demo | Contents |
|---|---|
| `waves/stage4_demo/` | `program.hex` + `data.hex` on `RV32ITestWrapper` (dot product with MUL) |
| `waves/mul/` | The four multiplications on corner values, each in one cycle |
| `waves/upper_jumps/` | LUI, AUIPC, all six branches (taken and not taken), JAL |
| `waves/load_store_branch/` | A loop with stores, loads of every size, a call and a return |
| `waves/trap/` | ECALL and an illegal instruction (DIV): trap to the handler, mcause/mepc, MRET |

Each folder holds the VCD, `core.gtkw` (session), `inst.filter` (instruction words as assembly), `mulfn.filter`
(MUL / MULH / MULHSU / MULHU) and `program.lst`.
Open from the project root:

```bash
gtkwave waves/stage4_demo/RV32ITestWrapper.vcd waves/stage4_demo/core.gtkw
```

```bash
gtkwave waves/mul/Core.vcd waves/mul/core.gtkw
```

Groups in `core.gtkw`: Clock; Fetch / execute (`pc`, instruction as assembly and hex, `brTaken`, `ctlTaken`,
`nextPc`); Multiplier (`isMul`, function by name, operands, 66-bit product, result); Retire / trap (valid, trap, cause, rd, rd value); Data memory (load, store, address, read/write data,
byte strobes); Registers x1..x15 (signed decimal); CSRs (mtvec, mepc, mcause, mcycle, minstret).

A VCD for any test: `WAVES=1 sbt test` (files in `test_run_dir/<test name>/`). Assembly on any instruction signal:
in GTKWave, Data Format → Translate Filter Process → `tools/rv32im_filter.py` (make it executable first).
