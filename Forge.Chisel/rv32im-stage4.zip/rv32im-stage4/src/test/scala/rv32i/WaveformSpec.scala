package rv32i

import chisel3._
import chiseltest._
import firrtl.options.TargetDirAnnotation
import org.scalatest.flatspec.AnyFlatSpec
import org.scalatest.matchers.should.Matchers

import java.nio.file.{Files, Path, Paths}

/** Writes VCD waveforms of short demo programs into waves/<name>/ for GTKWave: the VCD, a session (core.gtkw), an
  * instruction translate filter (inst.filter) and a listing (program.lst). Every run is checked against RefModel,
  * so a waveform is only written for a correct run.
  */
class WaveformSpec extends AnyFlatSpec with ChiselScalatestTester with Matchers {
  private val Data = 0x80010000L
  private def annos(dir: Path) = Seq(WriteVcdAnnotation, TargetDirAnnotation(dir.toString))

  private def sideFiles(dir: Path, words: Seq[Long], base: Long, vcd: String, top: String): Unit = {
    Files.write(dir.resolve("program.lst"), Disasm.listing(words, base).getBytes("UTF-8"))
    Gtkw.writeFilter(dir, "inst.filter",
      (words.zipWithIndex.map { case (w, k) => w -> Disasm(w, base + 4L * k) } :+ (0L -> "(empty)")).distinctBy(_._1), 8)
    Gtkw.writeMulFnFilter(dir)
    Gtkw.write(dir, vcd, "core.gtkw", Gtkw.coreGroups(top))
  }

  private def demoCore(name: String, a: Asm): CoreSim.Result = {
    val dir = Paths.get("waves", name); Files.createDirectories(dir)
    var res: CoreSim.Result = null
    test(new Core()).withAnnotations(annos(dir)) { c => res = CoreSim.run(c, a.words) }
    sideFiles(dir, a.words, a.base, "Core.vcd", "Core")
    res
  }

  private def vcd(dir: String, module: String): Path = Paths.get("waves", dir, s"$module.vcd")

  "Waveforms" should "show the Stage 4 demo (program.hex + data.hex) on RV32ITestWrapper (waves/stage4_demo)" in {
    val dir = Paths.get("waves", "stage4_demo"); Files.createDirectories(dir)
    val prog = InstructionMemory.readHex("program.hex").map(_.toLong)
    val regs = Array.fill(32)(0L)
    test(new RV32ITestWrapper("program.hex", "data.hex")).withAnnotations(annos(dir)) { dut =>
      var cycles = 0
      while (!(dut.io.trace.valid.peek().litToBoolean && dut.io.trace.inst.peek().litValue == Asm.Halt)) {
        dut.io.trace.trap.expect(false.B)
        assert(cycles < 300)
        val rd = dut.io.trace.rdAddr.peek().litValue.toInt
        if (rd != 0) regs(rd) = dut.io.trace.rdData.peek().litValue.toLong
        dut.clock.step(); cycles += 1
        assert(cycles < 200)
      }
      dut.clock.step(2)
    }
    regs(14) shouldBe 0xffffffecL; regs(20) shouldBe 0x40000000L; regs(23) shouldBe 0xffffffffL; regs(24) shouldBe 1
    sideFiles(dir, prog, 0x80000000L, "RV32ITestWrapper.vcd", "RV32ITestWrapper.core")
    Files.exists(vcd("stage4_demo", "RV32ITestWrapper")) shouldBe true
  }

  it should "show LUI, AUIPC, JAL and all six branches (waves/upper_jumps)" in {
    val a = new Asm
    a.lui(1, 0x12345); a.addi(1, 1, 0x678)            // x1 = 0x12345678
    a.auipc(2, 0)                                      // x2 = pc
    a.li(3, -1); a.li(4, 1)
    a.beq(3, 3, "b1"); a.addi(20, 20, 1); a.label("b1")
    a.bne(3, 4, "b2"); a.addi(20, 20, 1); a.label("b2")
    a.blt(3, 4, "b3"); a.addi(20, 20, 1); a.label("b3")
    a.bge(4, 3, "b4"); a.addi(20, 20, 1); a.label("b4")
    a.bltu(4, 3, "b5"); a.addi(20, 20, 1); a.label("b5")
    a.bgeu(3, 4, "b6"); a.addi(20, 20, 1); a.label("b6")
    a.beq(3, 4, "never"); a.addi(21, 21, 1)            // not taken
    a.jal(5, "far"); a.addi(20, 20, 1)
    a.label("far"); a.addi(22, 0, 7)
    a.label("never"); a.halt()
    val r = demoCore("upper_jumps", a)
    r.model.x(1) shouldBe 0x12345678L
    r.model.x(20) shouldBe 0
    r.model.x(21) shouldBe 1
    Files.exists(vcd("upper_jumps", "Core")) shouldBe true
  }

  it should "show loads, stores, a loop and a call (waves/load_store_branch)" in {
    val a = new Asm
    a.li(10, Data)
    a.li(1, 0); a.li(2, 5); a.li(3, 0)
    a.label("loop"); a.addi(1, 1, 1); a.add(3, 3, 1); a.sw(3, 0, 10); a.addi(10, 10, 4); a.blt(1, 2, "loop")
    a.lw(4, -4, 10); a.lbu(5, -4, 10); a.sh(4, 2, 10); a.lh(6, 2, 10)
    a.jal(1, "func"); a.halt()
    a.label("func"); a.addi(7, 0, 42); a.jalr(0, 1, 0)
    val r = demoCore("load_store_branch", a)
    r.model.x(3) shouldBe 15
    r.model.x(7) shouldBe 42
    Files.exists(vcd("load_store_branch", "Core")) shouldBe true
  }

  it should "show the four multiplications on corner values, each in one cycle (waves/mul)" in {
    val a = new Asm
    a.li(1, 0x80000000L); a.li(2, -1); a.li(3, 7); a.li(4, -7); a.li(5, 0x12345678L)
    a.mul(10, 3, 4); a.mulh(11, 3, 4); a.mulhsu(12, 4, 3); a.mulhu(13, 3, 4)
    a.mul(14, 1, 2); a.mulh(15, 1, 1); a.mulhsu(16, 2, 1); a.mulhu(17, 2, 2)
    a.mul(18, 5, 5); a.mulhu(19, 5, 5)
    a.add(20, 10, 13)                   // a multiplication result used by the next instruction
    a.halt()
    val r = demoCore("mul", a)
    r.model.x(10) shouldBe ((-49L) & 0xFFFFFFFFL)
    r.model.x(17) shouldBe 0xfffffffeL
    r.events.forall(_.cycles == 1) shouldBe true
    Files.exists(vcd("mul", "Core")) shouldBe true
  }

  it should "show an ECALL, an illegal instruction (DIV), the handler and MRET (waves/trap)" in {
    val a = new Asm
    a.la(1, "handler"); a.csrrw(0, CsrAddr.mtvec, 1)
    a.li(2, 5)
    a.ecall()
    a.addi(2, 2, 1)
    a.div(3, 2, 2)                      // division: illegal instruction in Stage 4
    a.addi(2, 2, 1)
    a.halt()
    a.label("handler")
    a.csrrs(3, CsrAddr.mcause, 0); a.csrrs(4, CsrAddr.mepc, 0)
    a.addi(4, 4, 4); a.csrrw(0, CsrAddr.mepc, 4)
    a.mret()
    val r = demoCore("trap", a)
    r.traps shouldBe 2
    r.model.x(2) shouldBe 7
    r.model.x(3) shouldBe Cause.IllegalInstruction
    Files.exists(vcd("trap", "Core")) shouldBe true
  }
}
