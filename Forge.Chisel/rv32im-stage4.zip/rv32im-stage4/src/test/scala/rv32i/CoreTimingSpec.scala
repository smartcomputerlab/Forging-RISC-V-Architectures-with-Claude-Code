package rv32i

import chiseltest._
import org.scalatest.flatspec.AnyFlatSpec
import org.scalatest.matchers.should.Matchers

/** Timing contract of the single-cycle Stage 4 core: every instruction of RV32I + Zicsr and the four multiplications
  * (parallel multiplier) retires in exactly one clock cycle; every trap (including DIV/DIVU/REM/REMU, which are
  * illegal in this stage) takes one cycle.
  */
class CoreTimingSpec extends AnyFlatSpec with ChiselScalatestTester with Matchers {
  private val Data = 0x80010000L

  /** Instruction names exercised below: all of RV32I, Zicsr, the M-mode SYSTEM instructions and the M extension. */
  private val allInstructions = Set(
    "lui", "auipc", "jal", "jalr", "beq", "bne", "blt", "bge", "bltu", "bgeu",
    "lb", "lh", "lw", "lbu", "lhu", "sb", "sh", "sw",
    "addi", "slti", "sltiu", "xori", "ori", "andi", "slli", "srli", "srai",
    "add", "sub", "sll", "slt", "sltu", "xor", "srl", "sra", "or", "and",
    "fence", "ecall", "ebreak", "mret", "wfi",
    "csrrw", "csrrs", "csrrc", "csrrwi", "csrrsi", "csrrci",
    "mul", "mulh", "mulhsu", "mulhu")

  "Core" should "execute every RV32I, Zicsr and multiplication instruction in one cycle, and every trap in one cycle" in {
    val a = new Asm
    // operands: x1 = -100, x2 = 7, x10 = data
    a.li(1, -100); a.li(2, 7); a.li(3, 0); a.li(4, 0x80000000L); a.li(5, -1); a.li(10, Data)
    a.la(6, "handler"); a.csrrw(0, CsrAddr.mtvec, 6)
    // OP-IMM, LUI, AUIPC
    a.addi(11, 1, 5); a.slti(11, 1, 5); a.sltiu(11, 1, 5); a.xori(11, 1, 5); a.ori(11, 1, 5); a.andi(11, 1, 5)
    a.slli(11, 1, 3); a.srli(11, 1, 3); a.srai(11, 1, 3); a.lui(11, 0x12345); a.auipc(11, 1)
    // OP
    a.add(11, 1, 2); a.sub(11, 1, 2); a.sll(11, 1, 2); a.slt(11, 1, 2); a.sltu(11, 1, 2)
    a.xor(11, 1, 2); a.srl(11, 1, 2); a.sra(11, 1, 2); a.or(11, 1, 2); a.and(11, 1, 2)
    // loads and stores
    a.sw(1, 0, 10); a.sh(2, 4, 10); a.sb(2, 6, 10)
    a.lw(11, 0, 10); a.lh(11, 0, 10); a.lhu(11, 2, 10); a.lb(11, 1, 10); a.lbu(11, 3, 10)
    // branches: taken (skips one instruction) and not taken
    for ((br, k) <- Seq[(Int, Int, String) => Unit](a.beq, a.bne, a.blt, a.bge, a.bltu, a.bgeu).zipWithIndex) {
      // x1 = -100 (0xffffff9c unsigned), x2 = 7
      val (tA, tB) = Seq((1, 1), (1, 2), (1, 2), (2, 1), (2, 1), (1, 2))(k) // operands that make each branch taken
      val (nA, nB) = Seq((1, 2), (1, 1), (2, 1), (1, 2), (1, 2), (2, 1))(k) // operands that make it not taken
      br(tA, tB, s"taken$k"); a.addi(20, 20, 1); a.label(s"taken$k")
      br(nA, nB, s"skip$k"); a.addi(21, 21, 1); a.label(s"skip$k")
    }
    // jumps
    a.jal(12, "after"); a.addi(20, 20, 1); a.label("after")
    a.la(13, "back"); a.jalr(14, 13, 0); a.addi(20, 20, 1); a.label("back")
    // multiplications: parallel multiplier, one cycle each
    a.mul(11, 1, 2); a.mulh(11, 1, 2); a.mulhsu(11, 1, 2); a.mulhu(11, 1, 2)
    // divisions are not implemented in Stage 4: each traps (illegal instruction), in one cycle
    a.div(11, 1, 2); a.divu(11, 1, 2); a.rem(11, 1, 2); a.remu(11, 1, 2)
    // Zicsr and SYSTEM
    a.csrrw(11, CsrAddr.mscratch, 1); a.csrrs(11, CsrAddr.mscratch, 2); a.csrrc(11, CsrAddr.mscratch, 2)
    a.csrrwi(11, CsrAddr.mscratch, 9); a.csrrsi(11, CsrAddr.mscratch, 6); a.csrrci(11, CsrAddr.mscratch, 1)
    a.fence(); a.wfi()
    a.ecall(); a.ebreak(); a.word(0xffffffffL)   // three more traps
    a.halt()
    a.label("handler")
    a.csrrs(15, CsrAddr.mepc, 0); a.addi(15, 15, 4); a.csrrw(0, CsrAddr.mepc, 15); a.mret()

    var res: CoreSim.Result = null
    test(new Core()).withAnnotations(TestUtil.waves) { c => res = CoreSim.run(c, a.words) }

    val seen = scala.collection.mutable.Set.empty[String]
    for (e <- res.events) {
      seen += Disasm(e.inst, e.pc).split(' ').head   // ECALL and EBREAK are seen as traps
      withClue(f"${Disasm(e.inst, e.pc)} at 0x${e.pc}%08x (trap=${e.trap}): ") { e.cycles shouldBe 1 }
    }
    (allInstructions -- seen) shouldBe empty
    res.traps shouldBe (4 + 3)           // DIV, DIVU, REM, REMU, then ECALL, EBREAK, an illegal word
    res.model.x(20) shouldBe 0           // every taken branch and jump skipped its instruction
    res.model.x(21) shouldBe 6           // every not-taken branch fell through
    res.cycles shouldBe res.events.length.toLong
    res.stallCycles shouldBe 0
  }
}
