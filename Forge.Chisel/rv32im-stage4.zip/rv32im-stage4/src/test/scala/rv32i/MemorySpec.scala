package rv32i

import chisel3._
import chiseltest._
import org.scalatest.flatspec.AnyFlatSpec
import java.nio.file.{Files, Paths}

class MemorySpec extends AnyFlatSpec with ChiselScalatestTester {
  "InstructionMemory" should "map the program at 0x80000000 and read 0 outside it" in {
    val words = InstructionMemory.readHex("program.hex")
    assert(words.length == 22 && words.head == BigInt("80010537", 16))
    test(new InstructionMemory("program.hex", depth = 32)).withAnnotations(TestUtil.waves) { dut =>
      for ((k, w) <- words.zipWithIndex.map(_.swap).take(4)) {
        dut.io.addr.poke((0x80000000L + 4 * k).U(32.W)); dut.io.inst.expect(w.U(32.W))
      }
      for (addr <- Seq(0L, 0x7ffffffcL, 0x80000080L, 0xfffffffcL)) {
        dut.io.addr.poke(addr.U(32.W)); dut.io.inst.expect(0.U, f"address 0x$addr%08x")
      }
    }
  }

  it should "accept comments, blank lines and separators in hex files" in {
    val dir = Paths.get("test_run_dir", "hex_parse"); Files.createDirectories(dir)
    val f = dir.resolve("p.hex")
    Files.write(f, "# c\n0000_0013\n\n00a00093  # addi\n".getBytes("UTF-8"))
    assert(InstructionMemory.readHex(f.toString) == Seq(BigInt(0x13), BigInt("00a00093", 16)))
  }

  "DataMemory" should "start from data.hex, write bytes, halves and words under byte strobes, and ignore outside writes" in {
    val B = 0x80010000L
    test(new DataMemory("data.hex", depth = 16)).withAnnotations(TestUtil.waves) { dut =>
      def rd(a: Long): BigInt = { dut.io.addr.poke(a.U(32.W)); dut.io.rdata.peek().litValue }
      def wr(a: Long, d: Long, s: Int): Unit = {
        dut.io.addr.poke(a.U(32.W)); dut.io.wdata.poke(d.U(32.W)); dut.io.wstrb.poke(s.U); dut.io.we.poke(true.B)
        dut.clock.step(); dut.io.we.poke(false.B)
      }
      dut.io.we.poke(false.B)
      assert(rd(B) == 4 && rd(B + 4) == 1 && rd(B + 16) == 4 && rd(B + 32) == 0xffffffd8L && rd(B + 36) == 0)
      assert(rd(B + 2) == 4)                                    // any byte address reads its aligned word
      wr(B + 36, 0x11223344L, 0xf); assert(rd(B + 36) == 0x11223344L)
      wr(B + 36, 0xaaaaaaaaL, 0x2); assert(rd(B + 36) == 0x1122aa44L)       // one byte lane
      wr(B + 36, 0xbbbbbbbbL, 0xc); assert(rd(B + 36) == 0xbbbbaa44L)       // upper half
      wr(B + 36, 0x12345678L, 0x0); assert(rd(B + 36) == 0xbbbbaa44L)       // no lane
      wr(B - 4, 0xffffffffL, 0xf); wr(B + 64, 0xffffffffL, 0xf)             // outside: ignored
      assert(rd(B - 4) == 0 && rd(B + 64) == 0 && rd(B) == 4 && rd(B + 60) == 0)
    }
  }

  "RV32ITestWrapper" should "run program.hex on data.hex: a dot product with MUL, then MULH/MULHU/MULHSU corner cases" in {
    test(new RV32ITestWrapper("program.hex", "data.hex")).withAnnotations(TestUtil.waves) { dut =>
      val regs = Array.fill(32)(0L)
      var retired = 0; var stores = 0; var muls = 0
      while (!(dut.io.trace.valid.peek().litToBoolean && dut.io.trace.inst.peek().litValue == Asm.Halt)) {
        dut.io.trace.trap.expect(false.B)
        if (dut.io.trace.valid.peek().litToBoolean) retired += 1
        val inst = dut.io.trace.inst.peek().litValue.toLong
        if ((inst & 0x7f) == 0x33 && ((inst >> 25) & 0x7f) == 1) muls += 1
        if (dut.io.trace.memWe.peek().litToBoolean) {
          stores += 1
          dut.io.trace.memAddr.expect("h80010024".U); dut.io.trace.memWdata.expect("hffffffec".U)
        }
        val rd = dut.io.trace.rdAddr.peek().litValue.toInt
        if (rd != 0) regs(rd) = dut.io.trace.rdData.peek().litValue.toLong
        dut.clock.step()
        assert(retired < 300)
      }
      assert(regs(14) == 0xffffffecL && regs(18) == 0xffffffecL)    // 1*10 + 2*20 + 3*30 + 4*(-40) = -20, reloaded
      assert(regs(20) == 0x40000000L && regs(21) == 0x40000000L && regs(23) == 0xffffffffL && regs(24) == 1)
      assert(stores == 1)
      assert(muls == 4 + 4)                // 4 in the loop, then MULH, MULHU, MULHSU, MUL
      assert(retired == 5 + 4 * 8 + 8)     // set-up, 4 iterations of 8, then the 8 instructions before the halt
    }
  }
}
