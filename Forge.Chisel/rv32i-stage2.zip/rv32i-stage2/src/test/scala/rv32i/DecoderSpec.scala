package rv32i

import chisel3._
import chiseltest._
import org.scalatest.flatspec.AnyFlatSpec

class DecoderSpec extends AnyFlatSpec with ChiselScalatestTester {
  private def expectLegal(dut: Decoder, instr: Long, rs1: Int, rs2: Option[Int], rd: Int, op: UInt, imm: Boolean): Unit = {
    dut.io.instr.poke(instr.U(32.W))
    dut.io.rs1.expect(rs1.U); rs2.foreach(v => dut.io.rs2.expect(v.U)); dut.io.rd.expect(rd.U)
    dut.io.aluOp.expect(op); dut.io.aluSrc.expect(imm.B)
    dut.io.regWrite.expect(true.B); dut.io.valid.expect(true.B)
  }

  "Decoder" should "decode the 10 R-type instructions (lab1 cases)" in {
    test(new Decoder).withAnnotations(TestUtil.waves) { dut =>
      val E = RV32IEncoding
      Seq((E.add(3, 1, 2), 1, 2, 3, ALUOp.ADD), (E.sub(4, 2, 5), 2, 5, 4, ALUOp.SUB), (E.sll(5, 3, 6), 3, 6, 5, ALUOp.SLL),
        (E.slt(6, 4, 7), 4, 7, 6, ALUOp.SLT), (E.sltu(7, 5, 8), 5, 8, 7, ALUOp.SLTU), (E.xor(8, 6, 9), 6, 9, 8, ALUOp.XOR),
        (E.srl(9, 7, 10), 7, 10, 9, ALUOp.SRL), (E.sra(10, 8, 11), 8, 11, 10, ALUOp.SRA), (E.or(11, 9, 12), 9, 12, 11, ALUOp.OR),
        (E.and(12, 10, 13), 10, 13, 12, ALUOp.AND)
      ).foreach { case (w, rs1, rs2, rd, op) => expectLegal(dut, w.toLong, rs1, Some(rs2), rd, op, imm = false) }
    }
  }

  it should "decode the 9 I-type ALU instructions (lab1 cases)" in {
    test(new Decoder).withAnnotations(TestUtil.waves) { dut =>
      val E = RV32IEncoding
      Seq((E.addi(13, 1, 10), 1, 13, ALUOp.ADD), (E.addi(14, 2, -10), 2, 14, ALUOp.ADD), (E.slti(15, 3, 100), 3, 15, ALUOp.SLT),
        (E.sltiu(16, 4, 100), 4, 16, ALUOp.SLTU), (E.xori(17, 5, 0x55), 5, 17, ALUOp.XOR), (E.ori(18, 6, 0x55), 6, 18, ALUOp.OR),
        (E.andi(19, 7, 0x55), 7, 19, ALUOp.AND), (E.slli(20, 8, 3), 8, 20, ALUOp.SLL), (E.srli(21, 9, 3), 9, 21, ALUOp.SRL),
        (E.srai(22, 10, 3), 10, 22, ALUOp.SRA)
      ).foreach { case (w, rs1, rd, op) => expectLegal(dut, w.toLong, rs1, None, rd, op, imm = true) }
    }
  }

  it should "decode the 5 loads and JALR (Stage 2)" in {
    test(new Decoder).withAnnotations(TestUtil.waves) { dut =>
      val E = RV32IEncoding
      for ((w, size, uns) <- Seq((E.lb(3, -4, 2), 0, false), (E.lh(3, -4, 2), 1, false), (E.lw(3, -4, 2), 2, false),
        (E.lbu(3, -4, 2), 0, true), (E.lhu(3, -4, 2), 1, true))) {
        dut.io.instr.poke(w.U)
        dut.io.valid.expect(true.B); dut.io.regWrite.expect(true.B); dut.io.memRead.expect(true.B)
        dut.io.memSize.expect(size.U); dut.io.memUnsigned.expect(uns.B); dut.io.jalr.expect(false.B)
        dut.io.aluOp.expect(ALUOp.ADD); dut.io.aluSrc.expect(true.B); dut.io.wbSel.expect(WbSel.MEM)
        dut.io.rs1.expect(2.U); dut.io.rd.expect(3.U)
      }
      dut.io.instr.poke(E.jalr(1, 5, -8).U)
      dut.io.valid.expect(true.B); dut.io.regWrite.expect(true.B); dut.io.jalr.expect(true.B); dut.io.memRead.expect(false.B)
      dut.io.aluOp.expect(ALUOp.ADD); dut.io.aluSrc.expect(true.B); dut.io.wbSel.expect(WbSel.PC4)
      dut.io.rs1.expect(5.U); dut.io.rd.expect(1.U)
    }
  }

  it should "give the ALU instructions write-back from the ALU, no load and no jump" in {
    test(new Decoder).withAnnotations(TestUtil.waves) { dut =>
      for (w <- Seq(Enc.r(0, 2, 1, 0, 3), Enc.r(0x20, 2, 1, 5, 3), Enc.i(5, 1, 0, 3), Enc.i(0x400 | 3, 1, 5, 3))) {
        dut.io.instr.poke(w.U(32.W))
        dut.io.valid.expect(true.B); dut.io.wbSel.expect(WbSel.ALU); dut.io.memRead.expect(false.B); dut.io.jalr.expect(false.B)
      }
    }
  }

  it should "reject every other encoding: valid = 0, aluOp = NOP, no register write, no load, no jump" in {
    val illegal: Seq[(String, Long)] = Seq(
      "all zeros" -> 0L, "all ones" -> 0xffffffffL,
      "lui" -> 0x000120b7L, "auipc" -> 0x00001097L, "jal" -> 0x0080006fL, "jalr funct3=1" -> Enc.i(0, 1, 1, 1, 0x67),
      "beq" -> 0x00208463L, "sw" -> 0x0020a023L, "sb" -> 0x00208023L, "fence" -> 0x0ff0000fL,
      "load funct3=3 (ld)" -> Enc.i(0, 1, 3, 2, 0x03), "load funct3=6 (lwu)" -> Enc.i(0, 1, 6, 2, 0x03),
      "load funct3=7" -> Enc.i(0, 1, 7, 2, 0x03), "ebreak" -> 0x00100073L,
      "ecall" -> 0x00000073L, "csrrw" -> 0x34009073L,
      "slli funct7=0100000" -> Enc.i(0x400 | 3, 1, 1, 2), "srli funct7=0000001" -> Enc.i(0x020 | 3, 1, 5, 2),
      "srai funct7=0100001" -> Enc.i(0x420 | 3, 1, 5, 2),
      "add funct7=0000010" -> Enc.r(2, 2, 1, 0, 3), "sll funct7=0100000" -> Enc.r(0x20, 2, 1, 1, 3),
      "xor funct7=0100000" -> Enc.r(0x20, 2, 1, 4, 3), "and funct7=1111111" -> Enc.r(0x7f, 2, 1, 7, 3)
    ) ++ (0 until 8).map(f3 => s"M extension funct3=$f3" -> Enc.r(1, 2, 1, f3, 3))
    test(new Decoder).withAnnotations(TestUtil.waves) { dut =>
      for ((name, w) <- illegal) {
        dut.io.instr.poke(w.U(32.W))
        assert(!dut.io.valid.peek().litToBoolean, s"$name must not be valid")
        assert(!dut.io.regWrite.peek().litToBoolean, s"$name must not write a register")
        dut.io.aluOp.expect(ALUOp.NOP, name)
        assert(!dut.io.memRead.peek().litToBoolean && !dut.io.jalr.peek().litToBoolean, s"$name: no load, no jump")
      }
    }
  }

  it should "accept only the OP, OP-IMM, LOAD and JALR major opcodes among all 128" in {
    test(new Decoder).withAnnotations(TestUtil.waves) { dut =>
      for (op <- 0 until 128) {
        dut.io.instr.poke((op | (1 << 7)).toLong.U(32.W)) // funct3 = funct7 = 0: ADD / ADDI / LB / JALR
        assert(dut.io.valid.peek().litToBoolean == Set(0x33, 0x13, 0x03, 0x67)(op), f"opcode 0x$op%02x")
      }
    }
  }
}
