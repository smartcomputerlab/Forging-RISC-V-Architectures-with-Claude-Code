package rv32i

import chisel3._
import chiseltest._
import org.scalatest.flatspec.AnyFlatSpec

class DataMemorySpec extends AnyFlatSpec with ChiselScalatestTester {
  "DataMemory" should "return the aligned word for any byte address, and 0 past its end or with no file" in {
    test(new DataMemory("data.hex", depth = 16)).withAnnotations(TestUtil.waves) { dut =>
      for ((addr, w) <- Seq(0 -> 0x8899aabbL, 1 -> 0x8899aabbL, 3 -> 0x8899aabbL, 4 -> 0x28L, 8 -> 0x12345678L,
        11 -> 0x12345678L, 12 -> 0L, 60 -> 0L, 64 -> 0L, 0x10000 -> 0L)) {
        dut.io.addr.poke(addr.U); dut.io.rdata.expect(w.U(32.W), s"address $addr")
      }
    }
    test(new DataMemory()).withAnnotations(TestUtil.waves) { dut =>
      for (addr <- Seq(0, 4, 100)) { dut.io.addr.poke(addr.U); dut.io.rdata.expect(0.U) }
    }
  }
}
