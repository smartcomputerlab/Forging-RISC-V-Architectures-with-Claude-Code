package rv32i

import chisel3._
import chiseltest._

/** Lockstep harness: runs a program on RV32IRICore (instruction and data words served from Scala maps by address,
  * like the combinational memories) and on RefModel, one instruction per cycle, comparing every trace field.
  * Stops when the pc reaches the address just past the program (straight-line end), or after `maxCycles`.
  */
object CoreSim {
  private def check(ok: Boolean, msg: => String): Unit = if (!ok) throw new AssertionError(msg)
  final case class Result(model: RefModel, executed: Int, notExecuted: Int, cycles: Int, loads: Int, jumps: Int)

  def run(c: RV32IRICore, prog: Seq[Long], initialRegs: Seq[BigInt] = Seq.empty, data: Map[Long, Long] = Map.empty,
          maxCycles: Int = 100000, stopAtEnd: Boolean = true): Result = {
    val model = new RefModel(initialRegs, data)
    val end = 4L * prog.length
    var executed = 0; var notExecuted = 0; var loads = 0; var jumps = 0; var cycle = 0
    while (cycle < maxCycles && !(stopAtEnd && model.pc == end)) {
      val pc = c.io.imemAddr.peek().litValue.toLong
      val w = if (pc % 4 == 0 && pc / 4 < prog.length) prog((pc / 4).toInt) else 0L
      c.io.imemInst.poke(w.U(32.W))
      c.io.dmemRdata.poke(model.readWord(c.io.dmemAddr.peek().litValue.toLong).U(32.W))
      val r = model.step(w)
      val t = c.io.trace
      def hw(d: UInt): Long = d.peek().litValue.toLong
      val where = f"cycle $cycle, pc 0x${r.pc}%08x, inst 0x${r.inst}%08x (${Disasm(r.inst, r.pc)})"
      check(pc == r.pc && hw(t.pc) == r.pc && hw(c.io.debugPC) == r.pc, f"$where: pc hw=0x$pc%08x")
      check(hw(t.inst) == r.inst, s"$where: inst")
      check(t.valid.peek().litToBoolean == r.valid, s"$where: valid hw=${t.valid.peek().litToBoolean} model=${r.valid}")
      check(hw(t.pcNext) == r.pcNext, f"$where: pcNext hw=0x${hw(t.pcNext)}%08x model=0x${r.pcNext}%08x")
      check(hw(t.rdAddr) == r.rdAddr, s"$where: rdAddr hw=${hw(t.rdAddr)} model=${r.rdAddr}")
      check(hw(t.rdData) == r.rdData, f"$where: rdData hw=0x${hw(t.rdData)}%08x model=0x${r.rdData}%08x")
      check(t.memRe.peek().litToBoolean == r.memRe && c.io.dmemRe.peek().litToBoolean == r.memRe, s"$where: memRe")
      if (r.memRe) check(hw(t.memAddr) == r.memAddr && hw(c.io.dmemAddr) == r.memAddr, f"$where: memAddr hw=0x${hw(t.memAddr)}%08x")
      if (r.valid) executed += 1 else notExecuted += 1
      if (r.memRe) loads += 1
      if (r.valid && (r.inst & 0x7f) == 0x67) jumps += 1
      c.clock.step(); cycle += 1
      for ((port, k) <- Seq(c.io.debugX1, c.io.debugX2, c.io.debugX3, c.io.debugX4).zip(1 to 4))
        check(hw(port) == model.x(k), f"$where: after the cycle x$k hw=0x${hw(port)}%08x model=0x${model.x(k)}%08x")
    }
    check(!stopAtEnd || model.pc == end, s"program did not reach its end within $maxCycles cycles")
    Result(model, executed, notExecuted, cycle, loads, jumps)
  }
}
