package rv32i

import chisel3._
import chiseltest._
import firrtl.options.TargetDirAnnotation
import org.scalatest.flatspec.AnyFlatSpec
import org.scalatest.matchers.should.Matchers

import java.nio.file.{Files, Path, Paths}

/** Writes VCD waveforms of demo programs into waves/<name>/, with a GTKWave session (core.gtkw), translate filters
  * (instruction words as assembly, ALU operation and write-back source names) and a program listing. Every run is also
  * checked against RefModel, so a waveform is only written for a correct run.
  */
class WaveformSpec extends AnyFlatSpec with ChiselScalatestTester with Matchers {
  private def annos(dir: Path) = Seq(WriteVcdAnnotation, TargetDirAnnotation(dir.toString))

  private def sideFiles(dir: Path, words: Seq[Long], vcd: String, top: String): Unit = {
    Files.write(dir.resolve("program.lst"), Disasm.listing(words, 0L).getBytes("UTF-8"))
    Gtkw.writeFilter(dir, "inst.filter",
      (words.zipWithIndex.map { case (w, k) => w -> Disasm(w, 4L * k) } :+ (0L -> "(empty: no-op)")).distinctBy(_._1), 8)
    Gtkw.writeAluOpFilter(dir)
    Gtkw.writeWbSelFilter(dir)
    Gtkw.write(dir, vcd, "core.gtkw", Gtkw.coreGroups(top))
  }

  private def demoCore(name: String, a: Asm, data: Map[Long, Long] = Map.empty): CoreSim.Result = {
    val dir = Paths.get("waves", name); Files.createDirectories(dir)
    var res: CoreSim.Result = null
    test(new RV32IRICore()).withAnnotations(annos(dir)) { c => res = CoreSim.run(c, a.words, data = data) }
    sideFiles(dir, a.words, "RV32IRICore.vcd", "RV32IRICore")
    res
  }

  private def demoWrapper(name: String, progFile: String, dataFile: String): RefModel = {
    val dir = Paths.get("waves", name); Files.createDirectories(dir)
    val prog = InstructionMemory.readHex(progFile).map(_.toLong)
    val data = if (dataFile.isEmpty) Map.empty[Long, Long]
               else InstructionMemory.readHex(dataFile).map(_.toLong).zipWithIndex.map { case (w, k) => k.toLong -> w }.toMap
    val model = new RefModel(Lab1.regs, data)
    test(new RV32ITestWrapper(CoreParams(), progFile, Lab1.regs, dataFile)).withAnnotations(annos(dir)) { dut =>
      while (model.pc != 4L * prog.length) {
        dut.io.debugPC.expect(model.pc.U)
        val r = model.step(prog((model.pc / 4).toInt))
        dut.io.trace.rdAddr.expect(r.rdAddr.U); dut.io.trace.rdData.expect(r.rdData.U(32.W)); dut.io.trace.pcNext.expect(r.pcNext.U)
        dut.clock.step()
      }
      dut.clock.step(2)   // two cycles past the end: no-ops
    }
    sideFiles(dir, prog, "RV32ITestWrapper.vcd", "RV32ITestWrapper.core")
    model
  }

  "Waveforms" should "show the Stage 2 demo (program.hex + data.hex) in RV32ITestWrapper (waves/stage2_demo)" in {
    val m = demoWrapper("stage2_demo", "program.hex", "data.hex")
    m.x(11) shouldBe 52
    Files.exists(Paths.get("waves", "stage2_demo", "RV32ITestWrapper.vcd")) shouldBe true
  }

  it should "show the lab1 R-type program (memory.hex) on the Stage 2 wrapper (waves/lab1_rtype)" in {
    val m = demoWrapper("lab1_rtype", "memory.hex", "")
    m.x(3) shouldBe 13
    Files.exists(Paths.get("waves", "lab1_rtype", "RV32ITestWrapper.vcd")) shouldBe true
  }

  it should "show every load size and sign, and a misaligned load (waves/loads)" in {
    val a = new Asm
    a.addi(1, 0, 4)
    a.lw(10, -4, 1); a.lb(11, -1, 1); a.lbu(12, -1, 1); a.lh(13, -2, 1); a.lhu(14, -2, 1)
    a.lw(15, 0, 1); a.lb(16, 3, 1)
    a.lw(17, -2, 1)                  // misaligned: no-op
    a.add(18, 10, 15)
    val r = demoCore("loads", a, Map(0L -> 0x8899aabbL, 1L -> 0x7f000010L))
    r.model.x(11) shouldBe 0xffffff88L
    r.notExecuted shouldBe 1
    Files.exists(Paths.get("waves", "loads", "RV32IRICore.vcd")) shouldBe true
  }

  it should "show JALR calls, returns and a jump (waves/jalr_call)" in {
    val a = new Asm
    a.addi(10, 0, 3)
    a.jalrTo(1, "triple"); a.addi(11, 10, 0)          // x11 = 9
    a.jalrTo(1, "triple"); a.addi(12, 10, 0)          // x12 = 27
    a.jalrTo(0, "end")
    a.addi(13, 0, -1)                                  // skipped
    a.label("triple")                                  // function: x10 = 3 * x10, return through x1
    a.add(20, 10, 0); a.add(10, 20, 20); a.add(10, 10, 20)
    a.ret()
    a.label("end"); a.addi(14, 0, 1)
    val r = demoCore("jalr_call", a)
    r.model.x(11) shouldBe 9; r.model.x(12) shouldBe 27; r.model.x(13) shouldBe 0
    r.jumps shouldBe 5
    Files.exists(Paths.get("waves", "jalr_call", "RV32IRICore.vcd")) shouldBe true
  }
}
