package rv32i

import chisel3._
import chiseltest._
import org.scalatest.flatspec.AnyFlatSpec
import org.scalatest.matchers.should.Matchers
import scala.util.Random
import TestUtil._

/** Programs on the full Stage 2 core. Every cycle is checked against RefModel (CoreSim: pc, next pc, instruction,
  * valid, rd, rd value, load address, x1..x4), and final registers against independently computed constants.
  */
class RV32IRICoreSpec extends AnyFlatSpec with ChiselScalatestTester with Matchers {
  private val labRegs = Lab1.regs   // x1 = 10, x2 = 3
  private val table: Map[Long, Long] = Map(0L -> 0x8899aabbL, 1L -> 0x00000028L, 2L -> 0x12345678L, 3L -> 0x80000001L)

  /** Expected values may be given as Int or Long. */
  private def runProg(a: Asm, expect: Map[Int, AnyVal], regs: Seq[BigInt] = Seq.empty,
                      data: Map[Long, Long] = Map.empty): CoreSim.Result = {
    var res: CoreSim.Result = null
    test(new RV32IRICore(CoreParams(), regs)).withAnnotations(TestUtil.waves) { c => res = CoreSim.run(c, a.words, regs, data) }
    for ((r, v) <- expect) {
      val exp = v match { case i: Int => i.toLong; case l: Long => l; case o => sys.error(s"bad value $o") }
      withClue(s"x$r: ") { res.model.x(r) shouldBe (exp & M) }
    }
    res
  }

  private def readHexWords(f: String) = InstructionMemory.readHex(f).map(_.toLong)

  "RV32ITestWrapper" should "run the Stage 2 demo (program.hex + data.hex): loads of every size, a JALR call and return" in {
    test(new RV32ITestWrapper(CoreParams(), "program.hex", labRegs, "data.hex")).withAnnotations(TestUtil.waves) { dut =>
      val prog = readHexWords("program.hex")
      val data = readHexWords("data.hex").zipWithIndex.map { case (w, k) => k.toLong -> w }.toMap
      val model = new RefModel(labRegs, data)
      while (model.pc != 4L * prog.length) {
        dut.io.debugPC.expect(model.pc.U)
        val r = model.step(prog((model.pc / 4).toInt))
        dut.io.trace.valid.expect(r.valid.B); dut.io.trace.pcNext.expect(r.pcNext.U)
        dut.io.trace.rdAddr.expect(r.rdAddr.U); dut.io.trace.rdData.expect(r.rdData.U(32.W))
        dut.clock.step()
      }
      dut.io.debugX3.expect("h8899aabb".U); dut.io.debugX4.expect("hffffffbb".U)
      model.x(5) shouldBe 0xaaL; model.x(6) shouldBe 0xffff8899L; model.x(7) shouldBe 0x8899L
      model.x(8) shouldBe 0x28L; model.x(9) shouldBe 0x1cL; model.x(10) shouldBe 42; model.x(11) shouldBe 52
      model.x(13) shouldBe 0; model.x(14) shouldBe 7
    }
  }

  it should "still run the lab1 memory.hex program (R-type, no data file)" in {
    test(new RV32ITestWrapper(CoreParams(), "memory.hex", labRegs)).withAnnotations(TestUtil.waves) { dut =>
      dut.clock.step(10)
      dut.io.debugPC.expect(40.U); dut.io.debugX3.expect(13.U); dut.io.debugX4.expect(7.U)
    }
  }

  "RV32IRICore" should "execute all 10 R-type instructions on edge values" in {
    val a = new Asm
    val x1 = 0x80000001L; val x2 = 0xfffffffbL; val x3 = 0x12345678L
    a.li(1, x1); a.li(2, x2); a.li(3, x3)
    a.add(10, 1, 2); a.sub(11, 1, 2); a.sll(12, 3, 2); a.slt(13, 1, 2); a.sltu(14, 1, 2)
    a.xor(15, 1, 3); a.srl(16, 1, 3); a.sra(17, 1, 3); a.or(18, 2, 3); a.and(19, 2, 3); a.add(20, 1, 1)
    runProg(a, Map(10 -> (x1 + x2), 11 -> (x1 - x2), 12 -> (x3 << 27), 13 -> 1, 14 -> 1, 15 -> (x1 ^ x3),
      16 -> (x1 >>> 24), 17 -> (s32(x1) >> 24), 18 -> (x2 | x3), 19 -> (x2 & x3), 20 -> 2))
  }

  it should "execute all 9 I-type ALU instructions" in {
    val a = new Asm
    val v = 0x87654321L
    a.li(1, v)
    a.addi(10, 1, -1); a.slti(11, 1, -2048); a.sltiu(12, 1, -1); a.xori(13, 1, -1); a.ori(14, 1, 0x7ff)
    a.andi(15, 1, -16); a.slli(16, 1, 31); a.srli(17, 1, 31); a.srai(18, 1, 31); a.srai(19, 1, 0)
    runProg(a, Map(10 -> (v - 1), 11 -> 1, 12 -> 1, 13 -> ~v, 14 -> (v | 0x7ff), 15 -> (v & ~15L),
      16 -> (v << 31), 17 -> 1, 18 -> 0xffffffffL, 19 -> v))
  }

  it should "execute LB, LBU, LH, LHU and LW at every aligned offset, with sign and zero extension" in {
    val a = new Asm
    a.addi(1, 0, 8)                                   // base register: word 2 = 0x12345678 at 8, word 3 at 12
    a.lb(10, 0, 1); a.lb(11, 1, 1); a.lb(12, 2, 1); a.lb(13, 3, 1)
    a.lbu(14, -8, 1); a.lbu(15, -7, 1); a.lbu(16, -6, 1); a.lbu(17, -5, 1)   // word 0 = 0x8899aabb
    a.lb(18, -5, 1)                                    // 0x88 sign-extended
    a.lh(19, -8, 1); a.lh(20, -6, 1); a.lhu(21, -8, 1); a.lhu(22, -6, 1)
    a.lw(23, -8, 1); a.lw(24, 4, 1); a.lw(25, 0, 1); a.lw(26, 100, 1) // 100+8: outside the table: 0
    a.lh(27, 6, 1)                                     // upper half of 0x80000001: 0x8000 -> sign-extended
    val res = runProg(a, Map(10 -> 0x78, 11 -> 0x56, 12 -> 0x34, 13 -> 0x12,
      14 -> 0xbb, 15 -> 0xaa, 16 -> 0x99, 17 -> 0x88, 18 -> 0xffffff88L,
      19 -> 0xffffaabbL, 20 -> 0xffff8899L, 21 -> 0xaabb, 22 -> 0x8899,
      23 -> 0x8899aabbL, 24 -> 0x80000001L, 25 -> 0x12345678, 26 -> 0, 27 -> 0xffff8000L), data = table)
    res.loads shouldBe 18
  }

  it should "use a loaded value in the next instruction and as the next load's base address" in {
    val a = new Asm
    a.lw(1, 4, 0)            // x1 = 0x28 (from the table)
    a.addi(2, 1, -0x20)      // x2 = 8
    a.lw(3, 0, 2)            // x3 = word at 8 = 0x12345678
    a.lbu(4, 3, 2)           // x4 = 0x12
    a.add(5, 3, 4)
    runProg(a, Map(1 -> 0x28, 2 -> 8, 3 -> 0x12345678, 4 -> 0x12, 5 -> (0x12345678 + 0x12)), data = table)
  }

  it should "execute misaligned loads as no-ops (no exceptions in Stage 2)" in {
    val a = new Asm
    a.addi(5, 0, 77)
    a.lh(5, 1, 0); a.lhu(5, 3, 0); a.lw(5, 2, 0); a.lw(5, 1, 0); a.lw(5, 3, 0)   // all misaligned: x5 unchanged
    a.lb(6, 3, 0); a.lbu(7, 1, 0); a.lh(8, 2, 0)                                  // bytes and even halves are fine
    val res = runProg(a, Map(5 -> 77, 6 -> 0xffffff88L, 7 -> 0xaa, 8 -> 0xffff8899L), data = table)
    res.notExecuted shouldBe 5
    res.loads shouldBe 3
  }

  it should "call and return with JALR, write the link register, clear bit 0, and skip over code" in {
    val a = new Asm
    a.addi(10, 0, 5)
    val call1 = a.here; a.jalrTo(1, "double")      // x1 = return address
    a.addi(11, 10, 0)                               // 10
    val call2 = a.here; a.jalrTo(1, "double")
    a.addi(12, 10, 0)                               // 20
    a.la(5, "odd"); a.addi(5, 5, 1)                 // odd target: bit 0 is cleared
    val oddJump = a.here; a.jalr(6, 5, 0)
    a.addi(13, 0, -1)                               // skipped
    a.label("odd"); a.addi(14, 0, 1)
    a.jalrTo(0, "end")
    a.label("double"); a.add(10, 10, 10); a.ret()   // function: x10 *= 2, return through x1
    a.label("end"); a.addi(15, 0, 9)
    val res = runProg(a, Map(1 -> (call2 + 4), 10 -> 20, 11 -> 10, 12 -> 20, 6 -> (oddJump + 4), 13 -> 0, 14 -> 1, 15 -> 9))
    res.jumps shouldBe 6                             // 2 calls, 2 returns, the odd-address jump, the jump to end
    call1 should be < call2
  }

  it should "execute a JALR to a misaligned target (bit 1 set) as a no-op: no link write, pc + 4" in {
    val a = new Asm
    a.addi(1, 0, 22)                                 // 22 = 0b10110: bit 1 set after clearing bit 0
    a.addi(2, 0, 3)
    a.jalr(2, 1, 0)                                  // misaligned: x2 keeps 3, falls through
    a.addi(3, 0, 1)
    val res = runProg(a, Map(2 -> 3, 3 -> 1))
    res.notExecuted shouldBe 1
    res.jumps shouldBe 0
  }

  it should "execute unsupported instructions as no-ops (stores, branches, LUI, system, M extension, ...)" in {
    val a = new Asm
    a.addi(1, 0, 5)
    for (w <- Seq(0L, 0xffffffffL, 0x000120b7L, 0x0020a023L, 0x00208463L, 0x0080006fL, 0x00000073L, 0x0ff0000fL,
      Enc.r(1, 1, 1, 0, 1), Enc.i(0, 1, 3, 1, 0x03), Enc.i(0, 1, 1, 1, 0x67), Enc.i(0x400 | 3, 1, 1, 1))) a.word(w)
    a.addi(2, 1, 1)
    val res = runProg(a, Map(1 -> 5, 2 -> 6))
    res.notExecuted shouldBe 12
  }

  it should "start from preset registers (initialRegs) like lab1" in {
    val a = new Asm
    a.add(3, 1, 2); a.sub(4, 1, 2)
    runProg(a, Map(1 -> 10, 2 -> 3, 3 -> 13, 4 -> 7), regs = labRegs)
  }

  it should "match the reference model on 3000 random instructions, including loads" in {
    val r = new Random(11)
    val data = (0L until 64L).map(k => k -> (r.nextLong() & M)).toMap
    val a = new Asm
    for (k <- 1 to 15) a.li(k, rnd32(r))
    a.addi(16, 0, 64)                                 // base register for loads (never overwritten below)
    def reg = 1 + r.nextInt(15)
    def src = r.nextInt(16)
    def imm = r.nextInt(4096) - 2048
    for (_ <- 0 until 3000) r.nextInt(24) match {
      case 0 => a.add(reg, src, src);  case 1 => a.sub(reg, src, src);  case 2 => a.sll(reg, src, src)
      case 3 => a.slt(reg, src, src);  case 4 => a.sltu(reg, src, src); case 5 => a.xor(reg, src, src)
      case 6 => a.srl(reg, src, src);  case 7 => a.sra(reg, src, src);  case 8 => a.or(reg, src, src)
      case 9 => a.and(reg, src, src);  case 10 => a.addi(reg, src, imm); case 11 => a.slti(reg, src, imm)
      case 12 => a.sltiu(reg, src, imm); case 13 => a.xori(reg, src, imm); case 14 => a.ori(reg, src, imm)
      case 15 => a.andi(reg, src, imm); case 16 => a.slli(reg, src, r.nextInt(32))
      case 17 => a.srli(reg, src, r.nextInt(32)); case 18 => a.srai(reg, src, r.nextInt(32))
      case 19 => a.lw(reg, 4 * r.nextInt(48) - 64, 16)
      case 20 => if (r.nextBoolean()) a.lb(reg, r.nextInt(192) - 64, 16) else a.lbu(reg, r.nextInt(192) - 64, 16)
      case 21 => if (r.nextBoolean()) a.lh(reg, r.nextInt(192) - 64, 16) else a.lhu(reg, r.nextInt(192) - 64, 16) // some misaligned
      case 22 => a.lw(reg, r.nextInt(64), src)        // any base: aligned or not, in or out of the table
      case _ => a.word(Enc.r(r.nextInt(128), src, src, r.nextInt(8), reg)) // random funct7: valid or not
    }
    val res = runProg(a, Map.empty, data = data)
    res.loads should be > 300
    res.notExecuted should be > 0
  }
}
