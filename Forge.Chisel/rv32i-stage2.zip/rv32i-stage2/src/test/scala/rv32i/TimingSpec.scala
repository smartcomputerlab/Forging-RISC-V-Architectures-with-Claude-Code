package rv32i

import chisel3._
import chiseltest._
import org.scalatest.flatspec.AnyFlatSpec

/** Timing contract of the single-cycle Stage 2 core: every instruction (ALU, load, JALR, or a no-op) takes exactly
  * one clock cycle; the pc moves to pc + 4, or to the JALR target, at every edge; results are in the register file
  * after that edge.
  */
class TimingSpec extends AnyFlatSpec with ChiselScalatestTester {
  "RV32IRICore" should "execute one instruction per cycle: ALU, loads, JALR and unsupported words alike" in {
    val a = new Asm
    a.addi(1, 0, 6); a.addi(2, 0, 4)
    a.add(3, 1, 2); a.sub(3, 1, 2); a.sll(3, 1, 2); a.slt(3, 1, 2); a.sltu(3, 1, 2)
    a.xor(3, 1, 2); a.srl(3, 1, 2); a.sra(3, 1, 2); a.or(3, 1, 2); a.and(3, 1, 2)
    a.addi(3, 1, 1); a.slti(3, 1, 1); a.sltiu(3, 1, 1); a.xori(3, 1, 1); a.ori(3, 1, 1); a.andi(3, 1, 1)
    a.slli(3, 1, 1); a.srli(3, 1, 1); a.srai(3, 1, 1)
    a.lb(3, 0, 0); a.lh(3, 0, 0); a.lw(3, 0, 0); a.lbu(3, 0, 0); a.lhu(3, 0, 0)
    a.jalrTo(3, "next"); a.label("next")
    a.lw(3, 1, 0)                                                  // misaligned: no-op, one cycle
    a.word(0x00000073L); a.word(0L); a.word(Enc.r(1, 2, 1, 0, 3))  // unsupported: no-ops, one cycle
    val data = Map(0L -> 0xcafe1234L)
    val model = new RefModel(Seq.empty, data)
    test(new RV32IRICore()).withAnnotations(TestUtil.waves) { c =>
      var cycles = 0
      while (model.pc != 4L * a.words.length) {
        c.io.imemAddr.expect(model.pc.U)
        c.io.imemInst.poke(a.words((model.pc / 4).toInt).U(32.W))
        c.io.dmemRdata.poke(model.readWord(c.io.dmemAddr.peek().litValue.toLong).U(32.W))
        val r = model.step(a.words((model.pc / 4).toInt))
        c.clock.step(); cycles += 1
        c.io.imemAddr.expect(r.pcNext.U)                         // pc + 4 or the JALR target, after one edge
        c.io.debugX3.expect(model.x(3).U(32.W))                  // result already in the register file
      }
      assert(cycles == a.words.length)                            // one cycle per instruction
    }
  }
}
