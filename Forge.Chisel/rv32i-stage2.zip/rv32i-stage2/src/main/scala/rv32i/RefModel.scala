package rv32i

/** What one instruction did (32-bit values held in Long). */
final case class TraceRecord(pc: Long, pcNext: Long, inst: Long, valid: Boolean, rdAddr: Int, rdData: Long,
                             memRe: Boolean, memAddr: Long)

/** Instruction-level reference model of RV32IRICore (Stage 2): R-type, I-type ALU, loads, JALR.
  * `dmem(i)` is data word i (word address); missing words read 0. Not executable: no-op, pc + 4.
  */
class RefModel(initialRegs: Seq[BigInt] = Seq.empty, val dmem: Map[Long, Long] = Map.empty, resetPc: Long = 0L) {
  private val M = 0xFFFFFFFFL
  val x: Array[Long] = Array.tabulate(32)(i => if (i == 0 || initialRegs.isEmpty) 0L else initialRegs(i).toLong & M)
  var pc: Long = resetPc

  private def s32(v: Long): Long = v.toInt.toLong
  private def sext(v: Long, bits: Int): Long = ((v << (64 - bits)) >> (64 - bits)) & M
  def readWord(addr: Long): Long = dmem.getOrElse((addr & M) >>> 2, 0L) & M

  def step(inst: Long): TraceRecord = {
    val op = (inst & 0x7f).toInt; val rd = ((inst >> 7) & 31).toInt; val f3 = ((inst >> 12) & 7).toInt
    val rs1 = ((inst >> 15) & 31).toInt; val rs2 = ((inst >> 20) & 31).toInt; val f7 = ((inst >> 25) & 0x7f).toInt
    val a = x(rs1)
    val imm = sext(inst >>> 20, 12)
    val pc4 = (pc + 4) & M
    def alu(fn: Int, alt: Boolean, b: Long): Long = {
      val sh = (b & 31).toInt
      (fn match {
        case 0 => if (alt) a - b else a + b
        case 1 => a << sh
        case 2 => if (s32(a) < s32(b)) 1L else 0L
        case 3 => if (a < b) 1L else 0L
        case 4 => a ^ b
        case 5 => if (alt) s32(a) >> sh else a >>> sh
        case 6 => a | b
        case _ => a & b
      }) & M
    }
    var result: Option[Long] = None
    var next = pc4
    var memRe = false
    val addr = (a + imm) & M
    op match {
      case 0x33 if f7 == 0 || (f7 == 0x20 && (f3 == 0 || f3 == 5)) => result = Some(alu(f3, f7 == 0x20, x(rs2)))
      case 0x13 if !(f3 == 1 && f7 != 0) && !(f3 == 5 && f7 != 0 && f7 != 0x20) => result = Some(alu(f3, f3 == 5 && f7 == 0x20, imm))
      case 0x03 if Set(0, 1, 2, 4, 5)(f3) =>
        val size = f3 & 3
        val misaligned = (size == 1 && (addr & 1) != 0) || (size == 2 && (addr & 3) != 0)
        if (!misaligned) {
          memRe = true
          val w = readWord(addr); val sh = 8 * (addr & 3).toInt
          result = Some(f3 match {
            case 0 => sext((w >>> sh) & 0xff, 8)
            case 1 => sext((w >>> sh) & 0xffff, 16)
            case 2 => w
            case 4 => (w >>> sh) & 0xff
            case _ => (w >>> sh) & 0xffff
          })
        }
      case 0x67 if f3 == 0 =>
        val target = addr & ~1L & M
        if ((target & 2) == 0) { result = Some(pc4); next = target }
      case _ =>
    }
    val writes = result.isDefined && rd != 0
    if (writes) x(rd) = result.get
    val rec = TraceRecord(pc, next, inst & M, result.isDefined, if (writes) rd else 0, if (writes) result.get else 0L, memRe, addr)
    pc = next
    rec
  }
}
