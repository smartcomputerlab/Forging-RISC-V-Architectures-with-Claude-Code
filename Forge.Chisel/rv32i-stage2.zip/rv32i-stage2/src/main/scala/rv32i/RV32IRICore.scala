package rv32i

import chisel3._
import chisel3.util._

/** Stage 2: single-cycle RV32I core for the R-type and I-type instructions, one instruction per clock cycle.
  *
  *  - R-type: ADD SUB SLL SLT SLTU XOR SRL SRA OR AND        (ALU b = rs2)
  *  - I-type: ADDI SLTI SLTIU XORI ORI ANDI SLLI SRLI SRAI   (ALU b = immediate)
  *  - I-type: LB LH LW LBU LHU                                (address rs1 + imm, data from the data memory)
  *  - I-type: JALR                                            (pc = (rs1 + imm) & ~1, rd = pc + 4)
  *
  * There are no exceptions in this stage. An instruction that cannot complete is executed as a no-op
  * (no register write, pc + 4, trace.valid = 0): an unsupported encoding, a misaligned load (LH/LHU at an odd
  * address, LW not at a multiple of 4), or a JALR whose target is not 4-byte aligned.
  * Memories are Harvard and combinational: imem for instructions, dmem (read-only here) for loads.
  */
class RV32IRICore(
  p: CoreParams = CoreParams(),
  initialRegs: Seq[BigInt] = Seq.empty,
  resetPc: BigInt = 0
) extends Module {
  require(p.xlen == 32, "RV32IRICore implements RV32I: xlen must be 32")
  require(p.numRegs == 32, "RV32IRICore implements RV32I: 32 registers")

  val io = IO(new Bundle {
    // Instruction-memory interface (combinational read).
    val imemAddr  = Output(UInt(p.xlen.W))
    val imemInst  = Input(UInt(32.W))
    // Data-memory interface (combinational read of the aligned word at dmemAddr & ~3).
    val dmemAddr  = Output(UInt(p.xlen.W))
    val dmemRe    = Output(Bool())
    val dmemRdata = Input(UInt(32.W))
    // Debug outputs for laboratory verification.
    val debugPC = Output(UInt(p.xlen.W))
    val debugX1 = Output(UInt(p.xlen.W))
    val debugX2 = Output(UInt(p.xlen.W))
    val debugX3 = Output(UInt(p.xlen.W))
    val debugX4 = Output(UInt(p.xlen.W))
    // What was executed this cycle.
    val trace = Output(new Trace(p))
  })

  // ---------------------------------------------------------------- program counter
  val pc = RegInit(resetPc.U(p.xlen.W))
  io.imemAddr := pc
  io.debugPC  := pc
  val pcPlus4 = pc + 4.U

  // ---------------------------------------------------------------- decode
  val decoder = Module(new Decoder)
  decoder.io.instr := io.imemInst

  val immGen = Module(new ImmediateGenerator(p))
  immGen.io.instr := io.imemInst

  // ---------------------------------------------------------------- register file
  val regFile = Module(new RegisterFile(p, initialRegs))
  regFile.io.rs1 := decoder.io.rs1
  regFile.io.rs2 := decoder.io.rs2

  // ---------------------------------------------------------------- ALU (also computes load addresses and JALR targets)
  val alu = Module(new ALU(p))
  alu.io.a  := regFile.io.readData1
  alu.io.b  := Mux(decoder.io.aluSrc, immGen.io.imm, regFile.io.readData2)
  alu.io.op := decoder.io.aluOp
  val aluY = alu.io.y

  // ---------------------------------------------------------------- loads
  val size      = decoder.io.memSize
  val loadMis   = decoder.io.memRead && ((size === 1.U && aluY(0)) || (size === 2.U && aluY(1, 0) =/= 0.U))
  val doLoad    = decoder.io.memRead && !loadMis
  io.dmemAddr  := aluY
  io.dmemRe    := doLoad

  val rdata = io.dmemRdata
  val byte  = VecInit(Seq.tabulate(4)(k => rdata(8 * k + 7, 8 * k)))(aluY(1, 0))
  val half  = Mux(aluY(1), rdata(31, 16), rdata(15, 0))
  val loadData = WireDefault(rdata)
  switch(size) {
    is(0.U) { loadData := Mux(decoder.io.memUnsigned, Cat(0.U(24.W), byte), Cat(Fill(24, byte(7)), byte)) }
    is(1.U) { loadData := Mux(decoder.io.memUnsigned, Cat(0.U(16.W), half), Cat(Fill(16, half(15)), half)) }
  }

  // ---------------------------------------------------------------- JALR
  val jalrTarget = Cat(aluY(31, 1), 0.U(1.W))
  val jalrMis    = decoder.io.jalr && jalrTarget(1)          // target not 4-byte aligned
  val doJalr     = decoder.io.jalr && !jalrMis

  // ---------------------------------------------------------------- write-back
  val executed = decoder.io.valid && !loadMis && !jalrMis
  val wbData = MuxLookup(decoder.io.wbSel, aluY)(Seq(
    WbSel.ALU -> aluY,
    WbSel.MEM -> loadData,
    WbSel.PC4 -> pcPlus4
  ))
  regFile.io.rd          := decoder.io.rd
  regFile.io.writeData   := wbData
  regFile.io.writeEnable := decoder.io.regWrite && executed

  // ---------------------------------------------------------------- next pc
  val nextPc = Mux(doJalr, jalrTarget, pcPlus4)
  pc := nextPc

  // ---------------------------------------------------------------- debug and trace
  io.debugX1 := regFile.io.debugRead(1)
  io.debugX2 := regFile.io.debugRead(2)
  io.debugX3 := regFile.io.debugRead(3)
  io.debugX4 := regFile.io.debugRead(4)

  val writes = regFile.io.writeEnable && decoder.io.rd =/= 0.U
  io.trace.pc      := pc
  io.trace.pcNext  := nextPc
  io.trace.inst    := io.imemInst
  io.trace.valid   := executed
  io.trace.rdAddr  := Mux(writes, decoder.io.rd, 0.U)
  io.trace.rdData  := Mux(writes, wbData, 0.U)
  io.trace.memRe   := doLoad
  io.trace.memAddr := aluY

  assert(!(regFile.io.writeEnable && !executed), "register write by an instruction that was not executed")
  assert(pc(1, 0) === 0.U, "pc must stay 4-byte aligned")
}
