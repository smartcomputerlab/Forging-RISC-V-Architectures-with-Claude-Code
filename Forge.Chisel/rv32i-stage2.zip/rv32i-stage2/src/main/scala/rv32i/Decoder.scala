package rv32i

import chisel3._
import chisel3.util._

/** Write-back source. */
object WbSel {
  val width = 2
  val ALU = 0.U(width.W)
  val MEM = 1.U(width.W)   // load data
  val PC4 = 2.U(width.W)   // return address (JALR)
}

/** Decoder for the Stage 2 instructions (R-type and I-type, 25 in total):
  *  - R-type   (0110011): ADD SUB SLL SLT SLTU XOR SRL SRA OR AND
  *  - I-type   (0010011): ADDI SLTI SLTIU XORI ORI ANDI SLLI SRLI SRAI
  *  - I-type   (0000011): LB LH LW LBU LHU                         (address = rs1 + imm)
  *  - I-type   (1100111): JALR                                      (target = (rs1 + imm) & ~1, rd = pc + 4)
  * `valid` is high only for these encodings; anything else gives valid = 0, aluOp = NOP and no side effect.
  */
class Decoder extends Module {
  val io = IO(new Bundle {
    val instr       = Input(UInt(32.W))
    val rs1         = Output(UInt(5.W))
    val rs2         = Output(UInt(5.W))
    val rd          = Output(UInt(5.W))
    val aluOp       = Output(UInt(ALUOp.width.W))
    val aluSrc      = Output(Bool())        // 0: ALU b = rs2, 1: ALU b = immediate
    val memRead     = Output(Bool())        // load
    val memSize     = Output(UInt(2.W))     // 0 byte, 1 half, 2 word
    val memUnsigned = Output(Bool())        // LBU, LHU
    val jalr        = Output(Bool())
    val wbSel       = Output(UInt(WbSel.width.W))
    val regWrite    = Output(Bool())
    val valid       = Output(Bool())
  })

  val opcode = io.instr(6, 0)
  val funct3 = io.instr(14, 12)
  val funct7 = io.instr(31, 25)

  io.rs1 := io.instr(19, 15)
  io.rs2 := io.instr(24, 20)
  io.rd  := io.instr(11, 7)

  io.aluOp       := ALUOp.NOP
  io.aluSrc      := false.B
  io.memRead     := false.B
  io.memSize     := funct3(1, 0)
  io.memUnsigned := funct3(2)
  io.jalr        := false.B
  io.wbSel       := WbSel.ALU
  io.valid       := false.B

  // R-type: funct7 ## funct3 selects the operation
  when(opcode === "b0110011".U) {
    io.aluOp := MuxLookup(Cat(funct7, funct3), ALUOp.NOP)(Seq(
      "b0000000000".U -> ALUOp.ADD,
      "b0100000000".U -> ALUOp.SUB,
      "b0000000001".U -> ALUOp.SLL,
      "b0000000010".U -> ALUOp.SLT,
      "b0000000011".U -> ALUOp.SLTU,
      "b0000000100".U -> ALUOp.XOR,
      "b0000000101".U -> ALUOp.SRL,
      "b0100000101".U -> ALUOp.SRA,
      "b0000000110".U -> ALUOp.OR,
      "b0000000111".U -> ALUOp.AND
    ))
    io.valid := io.aluOp =/= ALUOp.NOP
  }

  // I-type ALU: the second operand is the immediate
  when(opcode === "b0010011".U) {
    io.aluSrc := true.B
    io.aluOp := MuxLookup(funct3, ALUOp.NOP)(Seq(
      "b000".U -> ALUOp.ADD,                                                        // ADDI
      "b010".U -> ALUOp.SLT,                                                        // SLTI
      "b011".U -> ALUOp.SLTU,                                                       // SLTIU
      "b100".U -> ALUOp.XOR,                                                        // XORI
      "b110".U -> ALUOp.OR,                                                         // ORI
      "b111".U -> ALUOp.AND,                                                        // ANDI
      "b001".U -> Mux(funct7 === "b0000000".U, ALUOp.SLL, ALUOp.NOP),              // SLLI
      "b101".U -> Mux(funct7 === "b0000000".U, ALUOp.SRL,                          // SRLI
                  Mux(funct7 === "b0100000".U, ALUOp.SRA, ALUOp.NOP))              // SRAI
    ))
    io.valid := io.aluOp =/= ALUOp.NOP
  }

  // I-type loads: the ALU computes the address rs1 + imm
  when(opcode === "b0000011".U) {
    val ok = funct3 === 0.U || funct3 === 1.U || funct3 === 2.U || funct3 === 4.U || funct3 === 5.U
    when(ok) {
      io.aluOp   := ALUOp.ADD
      io.aluSrc  := true.B
      io.memRead := true.B
      io.wbSel   := WbSel.MEM
      io.valid   := true.B
    }
  }

  // I-type JALR: the ALU computes rs1 + imm, rd gets pc + 4
  when(opcode === "b1100111".U && funct3 === 0.U) {
    io.aluOp  := ALUOp.ADD
    io.aluSrc := true.B
    io.jalr   := true.B
    io.wbSel  := WbSel.PC4
    io.valid  := true.B
  }

  io.regWrite := io.valid
}
