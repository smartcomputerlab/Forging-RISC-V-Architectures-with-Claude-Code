package rv32i

import chisel3._
import chisel3.util._

/** Read-only data memory (Stage 2 has loads but no stores), initialised from a hex file like InstructionMemory
  * (an empty file name gives an all-zero memory). Combinational read of the aligned word at `addr & ~3`;
  * words past the end read as 0. Byte/half selection and sign extension happen in the core.
  */
class DataMemory(
  fileName: String = "",
  depth: Int = 1024
) extends Module {
  val io = IO(new Bundle {
    val addr  = Input(UInt(32.W))
    val rdata = Output(UInt(32.W))
  })

  val words: Seq[BigInt] = if (fileName.isEmpty) Seq.empty else InstructionMemory.readHex(fileName)
  require(words.length <= depth, s"Data memory file '$fileName' has ${words.length} words, but depth is only $depth")

  val mem = VecInit(words.map(_.U(32.W)) ++ Seq.fill(depth - words.length)(0.U(32.W)))
  val wordAddr = io.addr >> 2
  io.rdata := Mux(wordAddr < depth.U, mem(wordAddr(log2Ceil(depth) - 1, 0)), 0.U)
}
