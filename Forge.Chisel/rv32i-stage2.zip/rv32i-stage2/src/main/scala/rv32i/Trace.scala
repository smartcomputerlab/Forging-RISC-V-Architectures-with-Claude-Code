package rv32i

import chisel3._

/** What the core did this cycle (one instruction per cycle). */
class Trace(p: CoreParams) extends Bundle {
  val pc      = UInt(p.xlen.W)
  val pcNext  = UInt(p.xlen.W)   // pc of the next instruction (JALR target or pc + 4)
  val inst    = UInt(32.W)
  val valid   = Bool()           // executed (else: unsupported, misaligned load or misaligned JALR target: no-op)
  val rdAddr  = UInt(5.W)        // 0 when no register is written
  val rdData  = UInt(p.xlen.W)   // 0 when no register is written
  val memRe   = Bool()           // a load read the data memory
  val memAddr = UInt(p.xlen.W)   // load address (meaningful when memRe)
}
