# Stage 2: single-cycle RV32I core, R-type and I-type instructions (Chisel 3)

The second core of the series, in package `rv32i`: Stage 1 (lab1) extended with the I-type loads and JALR.
It executes 25 RV32I instructions, one per clock cycle:

| Format | Instructions |
|---|---|
| R-type | ADD SUB SLL SLT SLTU XOR SRL SRA OR AND |
| I-type ALU | ADDI SLTI SLTIU XORI ORI ANDI SLLI SRLI SRAI |
| I-type loads | LB LH LW LBU LHU (from a read-only data memory) |
| I-type jump | JALR |

Same modules and tooling as Stage 1, plus a `DataMemory`. See `DESIGN_NOTES.md` for the datapath and every choice.

## Requirements

- Java 11+ (tested with 21) and sbt 1.10 (https://www.scala-sbt.org/download/); tests run on Treadle (no simulator to install)
- Optional: CIRCT firtool 1.37.0 on the PATH for firtool output from `Emit`; GTKWave to view waveforms

Pinned: Scala 2.13.12, Chisel 3.6.1 (+ chisel3-plugin), chiseltest 0.6.2, sbt 1.10.2.

## Commands

```bash
sbt test
```

```bash
sbt "testOnly rv32i.RV32IRICoreSpec"
```

Generate SystemVerilog for `RV32IRICore` and `RV32ITestWrapper` (with `program.hex` and `data.hex`) into `generated/`:

```bash
sbt "runMain rv32i.Emit"
```

## Files

| File | Contents |
|---|---|
| `src/main/scala/rv32i/CoreParams.scala` | `xlen`, `numRegs` |
| `.../ALU.scala` | `ALUOp` codes and the combinational ALU |
| `.../Decoder.scala` | The 25 instructions; `WbSel` codes; `valid` = 0 for anything else |
| `.../ImmediateGenerator.scala` | Sign-extended I-type immediate |
| `.../RegisterFile.scala` | 32 × 32, x0 hardwired to zero, initial values, `debugRead` |
| `.../InstructionMemory.scala` | ROM from a hex file |
| `.../DataMemory.scala` | Read-only data memory from a hex file |
| `.../RV32IRICore.scala` | The Stage 2 core: `imem*`, `dmem*`, `debugPC`, `debugX1..X4`, `trace` |
| `.../RV32ITestWrapper.scala` | Core + instruction memory + data memory |
| `.../Trace.scala` | pc, next pc, instruction, valid, rd, rd value, load address |
| `.../RV32IEncoding.scala` | Instruction encoders (lab1's, plus loads and JALR) |
| `.../RefModel.scala` | Instruction-level reference model |
| `.../Emit.scala` | SystemVerilog generation (`Emit`, `GenerateRV32IRICore`, `GenerateRV32ITestWrapper`, `Lab1.regs`) |
| `program.hex`, `data.hex` | Stage 2 demo: loads of every size from a table, a JALR call and return (x1 = 10, x2 = 3) |
| `memory.hex` | lab1's 10 R-type instructions (still runs on this core) |
| `tools/rv32im_filter.py` | GTKWave translate filter process: any instruction word as assembly |

## Tests (`src/test/scala/rv32i/`)

| Suite | What it checks |
|---|---|
| `ALUSpec` | lab1's checks, all operations on all pairs of 22 edge values, 3,000 random pairs |
| `DecoderSpec` | lab1's R and I cases, the 5 loads and JALR with all control outputs, 31 rejected encodings, all 128 opcodes |
| `ImmediateGeneratorSpec` | All 4,096 12-bit immediates |
| `RegisterFileSpec` | x0, initial values, all registers, read during write |
| `InstructionMemorySpec`, `DataMemorySpec` | Hex parsing, aligned-word reads at any byte address, reads past the end |
| `RV32IRICoreSpec` | The demo and lab1 programs on the wrapper; all ALU instructions; every load size, sign and offset; load-to-use and load-as-address; misaligned loads; JALR calls, returns, bit 0; misaligned JALR; unsupported encodings; 3,000 random instructions with loads. Lockstep with `RefModel` every cycle |
| `TimingSpec` | One instruction per cycle for all 25 instructions and for no-ops |
| `WaveformSpec` | Four demos writing VCDs and GTKWave sessions to `waves/` |

Helpers: `Asm.scala` (assembler with labels, `li` from ALU instructions, `la`, `jalrTo`, `ret`), `CoreSim.scala`
(lockstep harness), `Disasm.scala`, `Gtkw.scala`, `TestUtil.scala` (`WAVES` switch).

## Waveforms with GTKWave

```bash
sbt "testOnly rv32i.WaveformSpec"
```

| Demo | Contents |
|---|---|
| `waves/stage2_demo/` | `program.hex` + `data.hex` on `RV32ITestWrapper` |
| `waves/lab1_rtype/` | lab1's `memory.hex` on the Stage 2 wrapper |
| `waves/loads/` | Every load size and sign, and a misaligned load executed as a no-op |
| `waves/jalr_call/` | Two calls to a function, returns, and a jump |

Each folder holds the VCD, `core.gtkw`, `inst.filter` (instructions as assembly), `aluop.filter` (ALU operation names),
`wbsel.filter` (ALU / MEM / PC4) and `program.lst`. Open from the project root:

```bash
gtkwave waves/stage2_demo/RV32ITestWrapper.vcd waves/stage2_demo/core.gtkw
```

```bash
gtkwave waves/loads/RV32IRICore.vcd waves/loads/core.gtkw
```

Groups: Clock; Fetch (pc, instruction as assembly and hex); Decoder (valid, aluOp, aluSrc, memRead, jalr, wbSel,
registers); Operands and ALU; Data memory (`doLoad`, address, read word, `loadMis`, `loadData`); Next pc (`jalrMis`,
`nextPc`); Write-back (`executed`, rd, value); Registers x1..x15 (signed decimal).

A VCD for any test: `WAVES=1 sbt test` (files in `test_run_dir/<test name>/`). Assembly on any instruction signal:
in GTKWave, Data Format → Translate Filter Process → `tools/rv32im_filter.py` (make it executable first).
