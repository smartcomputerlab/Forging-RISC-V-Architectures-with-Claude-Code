# Design notes: Stage 2, single-cycle RV32I core with R-type and I-type instructions

## Architecture

| Item | Choice |
|---|---|
| ISA subset | 25 RV32I instructions. R-type: ADD SUB SLL SLT SLTU XOR SRL SRA OR AND. I-type: ADDI SLTI SLTIU XORI ORI ANDI SLLI SRLI SRAI, LB LH LW LBU LHU, JALR |
| Not in this stage | S-type stores, B-type branches, U-type LUI/AUIPC, J-type JAL, and the I-type SYSTEM/FENCE instructions (ECALL, EBREAK, CSR*, FENCE), which need traps and CSRs |
| Microarchitecture | Single cycle: fetch, decode, register read, ALU, data-memory read and write-back in one clock |
| Control flow | pc + 4, or the JALR target `(rs1 + imm) & ~1`; reset pc 0 |
| Memories | Harvard, combinational: `InstructionMemory` (hex file) and a read-only `DataMemory` (hex file; Stage 2 has no stores) |
| Registers | 32 × 32 bits, x0 hardwired to zero, optional reset values (`initialRegs`) |
| Instructions that cannot complete | Executed as no-ops (no register write, pc + 4, `trace.valid` = 0): unsupported encodings, misaligned loads, JALR to a target that is not 4-byte aligned. There are no exceptions yet |

## Datapath (one clock)

```
pc ─► imem ─► inst ─► Decoder ── aluOp, aluSrc, memRead, memSize, memUnsigned, jalr, wbSel, rd
               │        └─ rs1, rs2 ─► RegisterFile ─► rs1 ─────────────────────────► ALU.a
               └─► ImmediateGenerator ─► imm ─┐            rs2 ─┐
                                              └── aluSrc ? imm : rs2 ──────────────► ALU.b
ALU.y = rs1 + imm for loads and JALR ─► dmem addr ─► word ─► byte/half select, sign/zero extend ─► loadData
write-back: wbSel = ALU ─► ALU.y | MEM ─► loadData | PC4 ─► pc + 4          (only if the instruction executes)
next pc:    JALR (aligned target) ─► ALU.y & ~1 | otherwise pc + 4
```

## Changes from Stage 1

| Block | Change |
|---|---|
| `Decoder` | + LB LH LW LBU LHU and JALR; new outputs `memRead`, `memSize`, `memUnsigned`, `jalr`, `wbSel` (`WbSel.ALU/MEM/PC4`) |
| `DataMemory` | New: read-only, hex file, combinational aligned-word read |
| Core (`RV32IRICore`, was `RV32IRCore`) | Data-memory port (`dmemAddr`, `dmemRe`, `dmemRdata`), load alignment and extension, write-back mux, JALR next-pc, misalignment checks |
| `RV32ITestWrapper` | + `DataMemory` from a `dataFile` (default: none, all zero) |
| `Trace` | + `pcNext`, `memRe`, `memAddr` |
| `RV32IEncoding` | + `lb lh lw lbu lhu jalr` |
| `RefModel` | + loads (with a data map) and JALR |

lab1's R-type program `memory.hex` runs unchanged on the Stage 2 wrapper.

## Choices where the specification leaves an option

| Topic | Choice | Why |
|---|---|---|
| Misaligned LH/LHU/LW | No-op (`valid` = 0) | Without traps the core cannot report the exception; Stage 3 will trap instead |
| JALR target with bit 1 set | No-op, no link write | Same reason (IALIGN = 32 makes it an instruction-address-misaligned exception) |
| JALR bit 0 | Cleared, as the spec requires | |
| Data memory | Read-only, separate from the instruction memory | Stores arrive with S-type in Stage 3 |
| Loads past the data memory | Read 0 | No access faults in this stage |
| Constants | ALU instructions only (`Asm.li`), or `initialRegs` | No LUI in this stage |

## Verification

- Unit tests: ALU, Decoder (lab1's 20 cases, the 5 loads and JALR with all control outputs, 31 rejected encodings,
  all 128 major opcodes), ImmediateGenerator (all 4,096 immediates), RegisterFile, InstructionMemory, DataMemory.
- Program tests (`RV32IRICoreSpec`), each in lockstep with `RefModel` every cycle (pc, next pc, instruction, valid,
  rd, rd value, load address, x1..x4) and with final registers checked against independent constants:
  the `program.hex`/`data.hex` demo and lab1's `memory.hex` on the wrapper; all R-type and I-type ALU instructions on
  edge values; every load size and sign at every byte offset; loaded values used as data and as base addresses;
  misaligned loads; JALR calls, returns, bit-0 clearing; misaligned JALR targets; unsupported encodings; preset
  registers; 3,000 random instructions with 300+ loads.
- Timing (`TimingSpec`): one instruction per cycle for every instruction, next pc after one edge.
- Planted bugs: LB without sign extension, JALR linking the target instead of pc + 4, misaligned loads executed:
  all caught.
