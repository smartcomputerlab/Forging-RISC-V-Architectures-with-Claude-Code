# Stage 9: single-cycle RV32IMF core with a sequential FPU, in Chisel 3

The ninth core of the series, in package `rv32i`: the single-cycle RV32IM core of Stage 5 (parallel multiplier,
sequential divider, Zicsr, precise machine-mode traps) extended with the **F extension**: 32 floating-point registers,
the `fcsr` CSRs and all 26 single-precision instructions, IEEE 754 binary32 with the five rounding modes and the five
exception flags.

The floating-point operations are split the same way the M extension is:

| Kind | Instructions | Hardware | Cycles |
|---|---|---|---|
| Never round | FSGNJ.S FSGNJN.S FSGNJX.S, FMIN.S FMAX.S, FEQ.S FLT.S FLE.S, FCLASS.S, FMV.X.W FMV.W.X | `FpMisc`, combinational | 1 |
| Memory | FLW, FSW | the data port | 1 |
| Round | FADD.S FSUB.S | sequential `Fpu` | 6 |
| | FMUL.S, FMADD.S FMSUB.S FNMSUB.S FNMADD.S | sequential `Fpu` (24-step multiplier) | 30 |
| | FDIV.S, FSQRT.S | sequential `Fpu` (27-step divider / square root) | 32 |
| | FCVT.W.S FCVT.WU.S | sequential `Fpu` | 4 |
| | FCVT.S.W FCVT.S.WU | sequential `Fpu` | 5 |

Cycles = retiring cycle included. Special operands (NaN, infinity, invalid, x / 0, zeros) are answered in 3 cycles,
an exact-zero sum in 4 (FADD/FSUB) or 28 (fused multiply-add). While the FPU works the core waits, exactly as it does for
a division: the pc holds, nothing is written, and the instruction retires in the FPU's response cycle.

See `DESIGN_NOTES.md` for the FPU datapath, the execution rules and every design choice.

## Instructions

| Group | Instructions |
|---|---|
| RV32I | LUI AUIPC JAL JALR, 6 branches, LB LH LW LBU LHU SB SH SW, 9 ALU-immediate and 10 ALU-register instructions |
| System | FENCE (no-op), ECALL, EBREAK, MRET, WFI (no-op), CSRRW CSRRS CSRRC CSRRWI CSRRSI CSRRCI |
| M extension | MUL MULH MULHSU MULHU (1 cycle); DIV DIVU REM REMU (34 cycles, 2 for x/0 and MIN/-1) |
| F extension | FLW FSW; FADD FSUB FMUL FDIV FSQRT; FMADD FMSUB FNMSUB FNMADD; FSGNJ FSGNJN FSGNJX; FMIN FMAX; FEQ FLT FLE; FCLASS; FCVT.W.S FCVT.WU.S FCVT.S.W FCVT.S.WU; FMV.X.W FMV.W.X |

CSRs: fflags (0x001), frm (0x002), fcsr (0x003), mstatus (SD = 1, FS = Dirty, MPP = M, MIE, MPIE), misa (`0x40001120`:
RV32IMF), mie, mtvec, mscratch, mepc, mcause, mtval, mip, mcycle(h), minstret(h), cycle(h), instret(h), mvendorid,
marchid, mimpid, mhartid. Exceptions: illegal instruction (including reserved rounding modes and non-S formats),
ECALL, EBREAK, misaligned load/store (FLW/FSW included), misaligned branch/jump target.

## Requirements

- Java 11+ (tested with 21) and sbt 1.10 (https://www.scala-sbt.org/download/); tests run on Treadle (no simulator to install)
- Optional: CIRCT firtool 1.37.0 on the PATH for firtool output from `Emit`; GTKWave to view waveforms

Pinned: Scala 2.13.12, Chisel 3.6.1 (+ chisel3-plugin), chiseltest 0.6.2, sbt 1.10.2.

## Commands

```bash
sbt test
```

The full suite (69 tests) takes about 35 minutes on Treadle (the FPU and FP program tests are long). One suite:

```bash
sbt "testOnly rv32i.FpuSpec"
```

More random FPU operations (here ten times the default):

```bash
FPU_TESTS=10 sbt "testOnly rv32i.FpuSpec"
```

Generate SystemVerilog for `Core`, `Fpu` and `RV32ITestWrapper` (with `program.hex` and `data.hex`) into `generated/`:

```bash
sbt "runMain rv32i.Emit"
```

## Source files (`src/main/scala/rv32i/`)

| File | Contents |
|---|---|
| `Core.scala` | The single-cycle RV32IMF core: decodes the M and F instructions, waits for the divider and the FPU |
| `Fpu.scala` | Sequential FPU: unpack, 24-step multiplier, aligner/adder, 27-step divider, 27-step square root, normalizer, rounder, float↔integer conversion; `FpuOp` (operations and latencies) |
| `FpMisc.scala` | Single-cycle FP operations: sign injection, min/max, compares, class |
| `FDecoder.scala` | Decoder for the 26 F instructions: encodings, rounding-mode legality, destinations |
| `FRegFile.scala` | f0..f31, three read ports (rs3 for the fused multiply-adds), one write port |
| `FpRef.scala` | Bit-exact software model of binary32 arithmetic (exact BigInt arithmetic, one rounding), `Rm`, `FFlags` |
| `CsrFile.scala` | Machine-mode CSRs plus fflags / frm / fcsr; flags accrue on every retiring FP instruction |
| `Defs.scala` | Opcodes, causes, CSR addresses, enums, memory ports, `Trace` (with the FP write and the raised flags) |
| `Decoder.scala`, `ImmGen.scala`, `RegFile.scala`, `Alu.scala`, `Multiplier.scala`, `DivUnit.scala` | Integer datapath (as in Stage 5) |
| `InstructionMemory.scala`, `DataMemory.scala`, `RV32ITestWrapper.scala` | The hex-file system: ROM at 0x80000000, RAM at 0x80010000 |
| `RefModel.scala` | Instruction-level reference model of the whole core (RV32IMF, CSRs, traps), using `FpRef` |
| `Emit.scala` | SystemVerilog generation |

Project root: `program.hex` (demo: single-precision dot product of two arrays from `data.hex` with FLW and FMADD.S,
stored with FSW and reloaded, then FDIV, FSQRT, FCVT in two rounding modes, FMUL, FLT, FCLASS, FMAX, FSGNJN, FMV.X.W,
an exact zero, a division by zero, and the fflags CSR), `data.hex`, `tools/rv32im_filter.py` (GTKWave filter process:
instruction words as assembly) and `tools/f32_filter.py` (GTKWave filter process: any 32-bit value as a float).

## Tests (`src/test/scala/rv32i/`)

| Suite | What it checks |
|---|---|
| `FpRefSpec` | The software reference against the JVM's IEEE arithmetic (+ − × ÷ √, fused multiply-add, int↔float) on 200,000 random operand sets in round-to-nearest-even, then RISC-V flags and special results by hand: canonical NaN, the other four rounding modes, overflow, underflow with tininess after rounding, conversions |
| `FpuSpec` | The FPU against `FpRef`, bit for bit, flags included, in all five rounding modes: 1,500 FADD and FSUB, 600 FMUL, 300 of each fused multiply-add, 500 FDIV and FSQRT, 1,000 of each conversion (scalable with `FPU_TESTS`), 35 corner cases × 5 rounding modes, exact latencies |
| `FpMiscSpec` | The single-cycle FP unit against `FpRef` on 20,000 operand pairs (9 operations each) |
| `CoreFpSpec` | The F extension on the core in lockstep with `RefModel`: every rounding FP instruction on special operands in all rounding modes (static and dynamic), the single-cycle ones on 96 operand pairs, FLW/FSW with misaligned traps, fflags/frm/fcsr and flag accrual, reserved rounding modes and non-RV32F encodings, 1,500 random mixed instructions, exact stall cycles |
| `CsrFileSpec` | CSRRW/RS/RC, misa = RV32IMF, mstatus with SD/FS, WARL masks, illegal accesses, counters, traps, fflags/frm/fcsr |
| `MemorySpec` | Memories, hex parsing, `program.hex` on the wrapper: every FP result, the flags, the store, 51 retirements and 222 wait cycles |
| `AluSpec`, `ImmGenSpec`, `RegFileSpec`, `DecoderSpec`, `MultiplierSpec`, `DivRefSpec`, `DivUnitSpec`, `CoreDivSpec`, `CoreProgramSpec`, `CoreTimingSpec` | The integer core, as in Stage 5 (now running with the F extension present) |
| `WaveformSpec` | Nine demos that write VCDs and GTKWave sessions to `waves/` |

Test helpers: `Asm.scala` (assembler with the F instructions and `fli`), `CoreSim.scala` (lockstep harness, also
compares the FP write and the raised flags), `Disasm.scala` (RV32IMF), `FpGen.scala` (random float operands),
`Gtkw.scala`, `TestUtil.scala`.

## Interface of `Core`

```scala
class Core(resetPc: Long = 0x80000000L, hartId: Int = 0) extends Module {
  val io = IO(new Bundle {
    val imem  = new InstrMemPort   // addr out, data in (combinational)
    val dmem  = new DataMemPort    // addr, re, we, wdata, wstrb out; rdata in (combinational, aligned word)
    val trace = Output(new Trace)  // one retirement or one trap per cycle, or neither while dividing / in the FPU
  })
}
```

`Trace` adds to the Stage 5 fields: `fdWe`, `fdAddr`, `fdData` (the f register written) and `fflags` (the exception
flags raised by the instruction).

## Waveforms with GTKWave

```bash
sbt "testOnly rv32i.WaveformSpec"
```

| Demo | Contents |
|---|---|
| `waves/stage9_demo/` | `program.hex` + `data.hex` on `RV32ITestWrapper`: the float dot product and the FP operations after it |
| `waves/fp_ops/` | Every kind of F instruction: FPU operations, single-cycle ones, a signaling NaN (NV), a division by zero (DZ) |
| `waves/fpu_unit/` | The FPU alone: FADD, FMUL, FDIV, FSQRT, FMADD, FCVT.W.S (`fpu.gtkw`) |
| `waves/div_rem/`, `waves/div_unit/`, `waves/mul/` | Divisions, the divider alone, multiplications |
| `waves/upper_jumps/`, `waves/load_store_branch/`, `waves/trap/` | LUI/AUIPC/branches/JAL, a loop with loads and stores, traps |

Open from the project root:

```bash
gtkwave waves/stage9_demo/RV32ITestWrapper.vcd waves/stage9_demo/core.gtkw
```

```bash
gtkwave waves/fpu_unit/Fpu.vcd waves/fpu_unit/fpu.gtkw
```

Groups in `core.gtkw`: Clock; Fetch / execute; Multiplier; Divider stall; Divider; Retire / trap; Data memory;
Registers x1..x15; **F extension** (`isF`, legality, resolved rounding mode, `useFpu`, `fpuStall`, single-cycle result,
the f register written and its value, raised flags); **FPU** (request, operation and rounding mode by name, operands
as floats, state UNPACK/MUL/ADD/DIV/SQRT/NORM/ROUND/TOINT/DONE, step counter, product, quotient/root and remainder,
raw and normalized significands with their exponents, sticky bit, result as a float and in hex, flags by name);
**FP registers f0..f11** (as floats); **fcsr** (frm by name, fflags by name); CSRs.

Each folder also holds the translate filters the session uses: `inst.filter` (assembly), `float.filter` (every float
value of that run as text, e.g. `-1.6666666 (0xbfd55555)`), `fpustate.filter`, `fpuop.filter`, `rm.filter`,
`fflags.filter`, and the multiplier/divider filters. For any other float signal: Data Format → Translate Filter
Process → `tools/f32_filter.py`.

Reading an FPU operation in `stage9_demo`: on FDIV.S, `useFpu` and `fpuStall` rise, the FPU `state` goes UNPACK →
DIV (27 steps, `count` 0…26, quotient bits shifting into `quo`) → NORM → ROUND → DONE, the pc and the instruction
hold, and the result (`-1.6666666`) retires in the DONE cycle with `fflags` = NX.

A VCD for any test: `WAVES=1 sbt test` (files in `test_run_dir/<test name>/`).
