module Fpu(
  input         clock,
  input         reset,
  output        io_req_ready, // @[src/main/scala/rv32i/Fpu.scala 101:14]
  input         io_req_valid, // @[src/main/scala/rv32i/Fpu.scala 101:14]
  input  [3:0]  io_req_bits_op, // @[src/main/scala/rv32i/Fpu.scala 101:14]
  input  [2:0]  io_req_bits_rm, // @[src/main/scala/rv32i/Fpu.scala 101:14]
  input  [31:0] io_req_bits_a, // @[src/main/scala/rv32i/Fpu.scala 101:14]
  input  [31:0] io_req_bits_b, // @[src/main/scala/rv32i/Fpu.scala 101:14]
  input  [31:0] io_req_bits_c, // @[src/main/scala/rv32i/Fpu.scala 101:14]
  output        io_resp_valid, // @[src/main/scala/rv32i/Fpu.scala 101:14]
  output [31:0] io_resp_bits_bits, // @[src/main/scala/rv32i/Fpu.scala 101:14]
  output [4:0]  io_resp_bits_flags, // @[src/main/scala/rv32i/Fpu.scala 101:14]
  input         io_kill, // @[src/main/scala/rv32i/Fpu.scala 101:14]
  output        io_busy // @[src/main/scala/rv32i/Fpu.scala 101:14]
);
`ifdef RANDOMIZE_REG_INIT
  reg [31:0] _RAND_0;
  reg [31:0] _RAND_1;
  reg [31:0] _RAND_2;
  reg [31:0] _RAND_3;
  reg [31:0] _RAND_4;
  reg [31:0] _RAND_5;
  reg [31:0] _RAND_6;
  reg [31:0] _RAND_7;
  reg [63:0] _RAND_8;
  reg [31:0] _RAND_9;
  reg [31:0] _RAND_10;
  reg [31:0] _RAND_11;
  reg [63:0] _RAND_12;
  reg [31:0] _RAND_13;
  reg [63:0] _RAND_14;
  reg [63:0] _RAND_15;
  reg [31:0] _RAND_16;
  reg [31:0] _RAND_17;
  reg [31:0] _RAND_18;
  reg [31:0] _RAND_19;
  reg [31:0] _RAND_20;
  reg [63:0] _RAND_21;
  reg [63:0] _RAND_22;
  reg [31:0] _RAND_23;
  reg [31:0] _RAND_24;
  reg [31:0] _RAND_25;
  reg [63:0] _RAND_26;
  reg [31:0] _RAND_27;
  reg [31:0] _RAND_28;
  reg [31:0] _RAND_29;
`endif // RANDOMIZE_REG_INIT
  reg [3:0] state; // @[src/main/scala/rv32i/Fpu.scala 109:22]
  reg [3:0] op; // @[src/main/scala/rv32i/Fpu.scala 111:15]
  reg [2:0] rm; // @[src/main/scala/rv32i/Fpu.scala 112:15]
  reg [31:0] ra; // @[src/main/scala/rv32i/Fpu.scala 113:15]
  reg [31:0] rb; // @[src/main/scala/rv32i/Fpu.scala 114:15]
  reg [31:0] rc; // @[src/main/scala/rv32i/Fpu.scala 115:15]
  wire  _io_resp_valid_T = state == 4'h9; // @[src/main/scala/rv32i/Fpu.scala 119:26]
  wire  _T = io_req_ready & io_req_valid; // @[src/main/scala/chisel3/util/Decoupled.scala 57:35]
  wire [3:0] _GEN_5 = _T ? 4'h1 : state; // @[src/main/scala/rv32i/Fpu.scala 121:21 124:11 109:22]
  wire [7:0] A_ef = ra[30:23]; // @[src/main/scala/rv32i/Fpu.scala 65:15]
  wire [22:0] A_f = ra[22:0]; // @[src/main/scala/rv32i/Fpu.scala 66:15]
  wire  A_sign = ra[31]; // @[src/main/scala/rv32i/Fpu.scala 67:16]
  wire  _A_w_zero_T = A_ef == 8'h0; // @[src/main/scala/rv32i/Fpu.scala 68:18]
  wire  _A_w_zero_T_1 = A_f == 23'h0; // @[src/main/scala/rv32i/Fpu.scala 68:31]
  wire  A_zero = A_ef == 8'h0 & A_f == 23'h0; // @[src/main/scala/rv32i/Fpu.scala 68:26]
  wire  _A_w_inf_T = &A_ef; // @[src/main/scala/rv32i/Fpu.scala 69:18]
  wire  A_inf = &A_ef & _A_w_zero_T_1; // @[src/main/scala/rv32i/Fpu.scala 69:23]
  wire  A_nan = _A_w_inf_T & A_f != 23'h0; // @[src/main/scala/rv32i/Fpu.scala 70:23]
  wire  A_snan = A_nan & ~A_f[22]; // @[src/main/scala/rv32i/Fpu.scala 71:21]
  wire [23:0] A_raw = {A_ef != 8'h0,A_f}; // @[src/main/scala/rv32i/Fpu.scala 72:18]
  wire [15:0] _GEN_386 = {{8'd0}, A_raw[15:8]}; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _A_lz_T_4 = _GEN_386 & 16'hff; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _A_lz_T_6 = {A_raw[7:0], 8'h0}; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _A_lz_T_8 = _A_lz_T_6 & 16'hff00; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _A_lz_T_9 = _A_lz_T_4 | _A_lz_T_8; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _GEN_387 = {{4'd0}, _A_lz_T_9[15:4]}; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _A_lz_T_14 = _GEN_387 & 16'hf0f; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _A_lz_T_16 = {_A_lz_T_9[11:0], 4'h0}; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _A_lz_T_18 = _A_lz_T_16 & 16'hf0f0; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _A_lz_T_19 = _A_lz_T_14 | _A_lz_T_18; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _GEN_388 = {{2'd0}, _A_lz_T_19[15:2]}; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _A_lz_T_24 = _GEN_388 & 16'h3333; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _A_lz_T_26 = {_A_lz_T_19[13:0], 2'h0}; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _A_lz_T_28 = _A_lz_T_26 & 16'hcccc; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _A_lz_T_29 = _A_lz_T_24 | _A_lz_T_28; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _GEN_389 = {{1'd0}, _A_lz_T_29[15:1]}; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _A_lz_T_34 = _GEN_389 & 16'h5555; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _A_lz_T_36 = {_A_lz_T_29[14:0], 1'h0}; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _A_lz_T_38 = _A_lz_T_36 & 16'haaaa; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _A_lz_T_39 = _A_lz_T_34 | _A_lz_T_38; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [7:0] _GEN_390 = {{4'd0}, A_raw[23:20]}; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [7:0] _A_lz_T_44 = _GEN_390 & 8'hf; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [7:0] _A_lz_T_46 = {A_raw[19:16], 4'h0}; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [7:0] _A_lz_T_48 = _A_lz_T_46 & 8'hf0; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [7:0] _A_lz_T_49 = _A_lz_T_44 | _A_lz_T_48; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [7:0] _GEN_391 = {{2'd0}, _A_lz_T_49[7:2]}; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [7:0] _A_lz_T_54 = _GEN_391 & 8'h33; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [7:0] _A_lz_T_56 = {_A_lz_T_49[5:0], 2'h0}; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [7:0] _A_lz_T_58 = _A_lz_T_56 & 8'hcc; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [7:0] _A_lz_T_59 = _A_lz_T_54 | _A_lz_T_58; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [7:0] _GEN_392 = {{1'd0}, _A_lz_T_59[7:1]}; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [7:0] _A_lz_T_64 = _GEN_392 & 8'h55; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [7:0] _A_lz_T_66 = {_A_lz_T_59[6:0], 1'h0}; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [7:0] _A_lz_T_68 = _A_lz_T_66 & 8'haa; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [7:0] _A_lz_T_69 = _A_lz_T_64 | _A_lz_T_68; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [23:0] _A_lz_T_70 = {_A_lz_T_39,_A_lz_T_69}; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [4:0] _A_lz_T_95 = _A_lz_T_70[22] ? 5'h16 : 5'h17; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _A_lz_T_96 = _A_lz_T_70[21] ? 5'h15 : _A_lz_T_95; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _A_lz_T_97 = _A_lz_T_70[20] ? 5'h14 : _A_lz_T_96; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _A_lz_T_98 = _A_lz_T_70[19] ? 5'h13 : _A_lz_T_97; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _A_lz_T_99 = _A_lz_T_70[18] ? 5'h12 : _A_lz_T_98; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _A_lz_T_100 = _A_lz_T_70[17] ? 5'h11 : _A_lz_T_99; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _A_lz_T_101 = _A_lz_T_70[16] ? 5'h10 : _A_lz_T_100; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _A_lz_T_102 = _A_lz_T_70[15] ? 5'hf : _A_lz_T_101; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _A_lz_T_103 = _A_lz_T_70[14] ? 5'he : _A_lz_T_102; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _A_lz_T_104 = _A_lz_T_70[13] ? 5'hd : _A_lz_T_103; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _A_lz_T_105 = _A_lz_T_70[12] ? 5'hc : _A_lz_T_104; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _A_lz_T_106 = _A_lz_T_70[11] ? 5'hb : _A_lz_T_105; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _A_lz_T_107 = _A_lz_T_70[10] ? 5'ha : _A_lz_T_106; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _A_lz_T_108 = _A_lz_T_70[9] ? 5'h9 : _A_lz_T_107; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _A_lz_T_109 = _A_lz_T_70[8] ? 5'h8 : _A_lz_T_108; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _A_lz_T_110 = _A_lz_T_70[7] ? 5'h7 : _A_lz_T_109; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _A_lz_T_111 = _A_lz_T_70[6] ? 5'h6 : _A_lz_T_110; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _A_lz_T_112 = _A_lz_T_70[5] ? 5'h5 : _A_lz_T_111; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _A_lz_T_113 = _A_lz_T_70[4] ? 5'h4 : _A_lz_T_112; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _A_lz_T_114 = _A_lz_T_70[3] ? 5'h3 : _A_lz_T_113; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _A_lz_T_115 = _A_lz_T_70[2] ? 5'h2 : _A_lz_T_114; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _A_lz_T_116 = _A_lz_T_70[1] ? 5'h1 : _A_lz_T_115; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] A_lz = _A_lz_T_70[0] ? 5'h0 : _A_lz_T_116; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [54:0] _GEN_0 = {{31'd0}, A_raw}; // @[src/main/scala/rv32i/Fpu.scala 74:19]
  wire [54:0] _A_w_sig_T = _GEN_0 << A_lz; // @[src/main/scala/rv32i/Fpu.scala 74:19]
  wire [23:0] A_sig = _A_w_sig_T[23:0]; // @[src/main/scala/rv32i/Fpu.scala 74:25]
  wire [8:0] _A_eLsb_T_1 = {1'b0,$signed(A_ef)}; // @[src/main/scala/rv32i/Fpu.scala 75:51]
  wire [12:0] _A_eLsb_T_2 = {{4{_A_eLsb_T_1[8]}},_A_eLsb_T_1}; // @[src/main/scala/rv32i/Fpu.scala 75:59]
  wire [12:0] _A_eLsb_T_5 = $signed(_A_eLsb_T_2) - 13'sh96; // @[src/main/scala/rv32i/Fpu.scala 75:64]
  wire [12:0] A_eLsb = _A_w_zero_T ? $signed(-13'sh95) : $signed(_A_eLsb_T_5); // @[src/main/scala/rv32i/Fpu.scala 75:19]
  wire [12:0] _A_w_exp_T_2 = $signed(A_eLsb) + 13'sh17; // @[src/main/scala/rv32i/Fpu.scala 76:19]
  wire [5:0] _A_w_exp_T_3 = {1'b0,$signed(A_lz)}; // @[src/main/scala/rv32i/Fpu.scala 76:37]
  wire [12:0] _A_w_exp_T_4 = {{7{_A_w_exp_T_3[5]}},_A_w_exp_T_3}; // @[src/main/scala/rv32i/Fpu.scala 76:45]
  wire [12:0] A_exp = $signed(_A_w_exp_T_2) - $signed(_A_w_exp_T_4); // @[src/main/scala/rv32i/Fpu.scala 76:32]
  wire [7:0] B_ef = rb[30:23]; // @[src/main/scala/rv32i/Fpu.scala 65:15]
  wire [22:0] B_f = rb[22:0]; // @[src/main/scala/rv32i/Fpu.scala 66:15]
  wire  B_sign = rb[31]; // @[src/main/scala/rv32i/Fpu.scala 67:16]
  wire  _B_w_zero_T = B_ef == 8'h0; // @[src/main/scala/rv32i/Fpu.scala 68:18]
  wire  _B_w_zero_T_1 = B_f == 23'h0; // @[src/main/scala/rv32i/Fpu.scala 68:31]
  wire  B_zero = B_ef == 8'h0 & B_f == 23'h0; // @[src/main/scala/rv32i/Fpu.scala 68:26]
  wire  _B_w_inf_T = &B_ef; // @[src/main/scala/rv32i/Fpu.scala 69:18]
  wire  B_inf = &B_ef & _B_w_zero_T_1; // @[src/main/scala/rv32i/Fpu.scala 69:23]
  wire  B_nan = _B_w_inf_T & B_f != 23'h0; // @[src/main/scala/rv32i/Fpu.scala 70:23]
  wire  B_snan = B_nan & ~B_f[22]; // @[src/main/scala/rv32i/Fpu.scala 71:21]
  wire [23:0] B_raw = {B_ef != 8'h0,B_f}; // @[src/main/scala/rv32i/Fpu.scala 72:18]
  wire [15:0] _GEN_393 = {{8'd0}, B_raw[15:8]}; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _B_lz_T_4 = _GEN_393 & 16'hff; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _B_lz_T_6 = {B_raw[7:0], 8'h0}; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _B_lz_T_8 = _B_lz_T_6 & 16'hff00; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _B_lz_T_9 = _B_lz_T_4 | _B_lz_T_8; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _GEN_394 = {{4'd0}, _B_lz_T_9[15:4]}; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _B_lz_T_14 = _GEN_394 & 16'hf0f; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _B_lz_T_16 = {_B_lz_T_9[11:0], 4'h0}; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _B_lz_T_18 = _B_lz_T_16 & 16'hf0f0; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _B_lz_T_19 = _B_lz_T_14 | _B_lz_T_18; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _GEN_395 = {{2'd0}, _B_lz_T_19[15:2]}; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _B_lz_T_24 = _GEN_395 & 16'h3333; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _B_lz_T_26 = {_B_lz_T_19[13:0], 2'h0}; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _B_lz_T_28 = _B_lz_T_26 & 16'hcccc; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _B_lz_T_29 = _B_lz_T_24 | _B_lz_T_28; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _GEN_396 = {{1'd0}, _B_lz_T_29[15:1]}; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _B_lz_T_34 = _GEN_396 & 16'h5555; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _B_lz_T_36 = {_B_lz_T_29[14:0], 1'h0}; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _B_lz_T_38 = _B_lz_T_36 & 16'haaaa; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _B_lz_T_39 = _B_lz_T_34 | _B_lz_T_38; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [7:0] _GEN_397 = {{4'd0}, B_raw[23:20]}; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [7:0] _B_lz_T_44 = _GEN_397 & 8'hf; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [7:0] _B_lz_T_46 = {B_raw[19:16], 4'h0}; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [7:0] _B_lz_T_48 = _B_lz_T_46 & 8'hf0; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [7:0] _B_lz_T_49 = _B_lz_T_44 | _B_lz_T_48; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [7:0] _GEN_398 = {{2'd0}, _B_lz_T_49[7:2]}; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [7:0] _B_lz_T_54 = _GEN_398 & 8'h33; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [7:0] _B_lz_T_56 = {_B_lz_T_49[5:0], 2'h0}; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [7:0] _B_lz_T_58 = _B_lz_T_56 & 8'hcc; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [7:0] _B_lz_T_59 = _B_lz_T_54 | _B_lz_T_58; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [7:0] _GEN_399 = {{1'd0}, _B_lz_T_59[7:1]}; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [7:0] _B_lz_T_64 = _GEN_399 & 8'h55; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [7:0] _B_lz_T_66 = {_B_lz_T_59[6:0], 1'h0}; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [7:0] _B_lz_T_68 = _B_lz_T_66 & 8'haa; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [7:0] _B_lz_T_69 = _B_lz_T_64 | _B_lz_T_68; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [23:0] _B_lz_T_70 = {_B_lz_T_39,_B_lz_T_69}; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [4:0] _B_lz_T_95 = _B_lz_T_70[22] ? 5'h16 : 5'h17; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _B_lz_T_96 = _B_lz_T_70[21] ? 5'h15 : _B_lz_T_95; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _B_lz_T_97 = _B_lz_T_70[20] ? 5'h14 : _B_lz_T_96; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _B_lz_T_98 = _B_lz_T_70[19] ? 5'h13 : _B_lz_T_97; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _B_lz_T_99 = _B_lz_T_70[18] ? 5'h12 : _B_lz_T_98; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _B_lz_T_100 = _B_lz_T_70[17] ? 5'h11 : _B_lz_T_99; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _B_lz_T_101 = _B_lz_T_70[16] ? 5'h10 : _B_lz_T_100; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _B_lz_T_102 = _B_lz_T_70[15] ? 5'hf : _B_lz_T_101; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _B_lz_T_103 = _B_lz_T_70[14] ? 5'he : _B_lz_T_102; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _B_lz_T_104 = _B_lz_T_70[13] ? 5'hd : _B_lz_T_103; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _B_lz_T_105 = _B_lz_T_70[12] ? 5'hc : _B_lz_T_104; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _B_lz_T_106 = _B_lz_T_70[11] ? 5'hb : _B_lz_T_105; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _B_lz_T_107 = _B_lz_T_70[10] ? 5'ha : _B_lz_T_106; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _B_lz_T_108 = _B_lz_T_70[9] ? 5'h9 : _B_lz_T_107; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _B_lz_T_109 = _B_lz_T_70[8] ? 5'h8 : _B_lz_T_108; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _B_lz_T_110 = _B_lz_T_70[7] ? 5'h7 : _B_lz_T_109; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _B_lz_T_111 = _B_lz_T_70[6] ? 5'h6 : _B_lz_T_110; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _B_lz_T_112 = _B_lz_T_70[5] ? 5'h5 : _B_lz_T_111; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _B_lz_T_113 = _B_lz_T_70[4] ? 5'h4 : _B_lz_T_112; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _B_lz_T_114 = _B_lz_T_70[3] ? 5'h3 : _B_lz_T_113; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _B_lz_T_115 = _B_lz_T_70[2] ? 5'h2 : _B_lz_T_114; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _B_lz_T_116 = _B_lz_T_70[1] ? 5'h1 : _B_lz_T_115; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] B_lz = _B_lz_T_70[0] ? 5'h0 : _B_lz_T_116; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [54:0] _GEN_1 = {{31'd0}, B_raw}; // @[src/main/scala/rv32i/Fpu.scala 74:19]
  wire [54:0] _B_w_sig_T = _GEN_1 << B_lz; // @[src/main/scala/rv32i/Fpu.scala 74:19]
  wire [23:0] B_sig = _B_w_sig_T[23:0]; // @[src/main/scala/rv32i/Fpu.scala 74:25]
  wire [8:0] _B_eLsb_T_1 = {1'b0,$signed(B_ef)}; // @[src/main/scala/rv32i/Fpu.scala 75:51]
  wire [12:0] _B_eLsb_T_2 = {{4{_B_eLsb_T_1[8]}},_B_eLsb_T_1}; // @[src/main/scala/rv32i/Fpu.scala 75:59]
  wire [12:0] _B_eLsb_T_5 = $signed(_B_eLsb_T_2) - 13'sh96; // @[src/main/scala/rv32i/Fpu.scala 75:64]
  wire [12:0] B_eLsb = _B_w_zero_T ? $signed(-13'sh95) : $signed(_B_eLsb_T_5); // @[src/main/scala/rv32i/Fpu.scala 75:19]
  wire [12:0] _B_w_exp_T_2 = $signed(B_eLsb) + 13'sh17; // @[src/main/scala/rv32i/Fpu.scala 76:19]
  wire [5:0] _B_w_exp_T_3 = {1'b0,$signed(B_lz)}; // @[src/main/scala/rv32i/Fpu.scala 76:37]
  wire [12:0] _B_w_exp_T_4 = {{7{_B_w_exp_T_3[5]}},_B_w_exp_T_3}; // @[src/main/scala/rv32i/Fpu.scala 76:45]
  wire [12:0] B_exp = $signed(_B_w_exp_T_2) - $signed(_B_w_exp_T_4); // @[src/main/scala/rv32i/Fpu.scala 76:32]
  wire [7:0] C_ef = rc[30:23]; // @[src/main/scala/rv32i/Fpu.scala 65:15]
  wire [22:0] C_f = rc[22:0]; // @[src/main/scala/rv32i/Fpu.scala 66:15]
  wire  C_sign = rc[31]; // @[src/main/scala/rv32i/Fpu.scala 67:16]
  wire  _C_w_zero_T = C_ef == 8'h0; // @[src/main/scala/rv32i/Fpu.scala 68:18]
  wire  _C_w_zero_T_1 = C_f == 23'h0; // @[src/main/scala/rv32i/Fpu.scala 68:31]
  wire  C_zero = C_ef == 8'h0 & C_f == 23'h0; // @[src/main/scala/rv32i/Fpu.scala 68:26]
  wire  _C_w_inf_T = &C_ef; // @[src/main/scala/rv32i/Fpu.scala 69:18]
  wire  C_inf = &C_ef & _C_w_zero_T_1; // @[src/main/scala/rv32i/Fpu.scala 69:23]
  wire  C_nan = _C_w_inf_T & C_f != 23'h0; // @[src/main/scala/rv32i/Fpu.scala 70:23]
  wire  C_snan = C_nan & ~C_f[22]; // @[src/main/scala/rv32i/Fpu.scala 71:21]
  wire [23:0] C_raw = {C_ef != 8'h0,C_f}; // @[src/main/scala/rv32i/Fpu.scala 72:18]
  wire [15:0] _GEN_400 = {{8'd0}, C_raw[15:8]}; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _C_lz_T_4 = _GEN_400 & 16'hff; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _C_lz_T_6 = {C_raw[7:0], 8'h0}; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _C_lz_T_8 = _C_lz_T_6 & 16'hff00; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _C_lz_T_9 = _C_lz_T_4 | _C_lz_T_8; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _GEN_401 = {{4'd0}, _C_lz_T_9[15:4]}; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _C_lz_T_14 = _GEN_401 & 16'hf0f; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _C_lz_T_16 = {_C_lz_T_9[11:0], 4'h0}; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _C_lz_T_18 = _C_lz_T_16 & 16'hf0f0; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _C_lz_T_19 = _C_lz_T_14 | _C_lz_T_18; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _GEN_402 = {{2'd0}, _C_lz_T_19[15:2]}; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _C_lz_T_24 = _GEN_402 & 16'h3333; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _C_lz_T_26 = {_C_lz_T_19[13:0], 2'h0}; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _C_lz_T_28 = _C_lz_T_26 & 16'hcccc; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _C_lz_T_29 = _C_lz_T_24 | _C_lz_T_28; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _GEN_403 = {{1'd0}, _C_lz_T_29[15:1]}; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _C_lz_T_34 = _GEN_403 & 16'h5555; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _C_lz_T_36 = {_C_lz_T_29[14:0], 1'h0}; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _C_lz_T_38 = _C_lz_T_36 & 16'haaaa; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _C_lz_T_39 = _C_lz_T_34 | _C_lz_T_38; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [7:0] _GEN_404 = {{4'd0}, C_raw[23:20]}; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [7:0] _C_lz_T_44 = _GEN_404 & 8'hf; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [7:0] _C_lz_T_46 = {C_raw[19:16], 4'h0}; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [7:0] _C_lz_T_48 = _C_lz_T_46 & 8'hf0; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [7:0] _C_lz_T_49 = _C_lz_T_44 | _C_lz_T_48; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [7:0] _GEN_405 = {{2'd0}, _C_lz_T_49[7:2]}; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [7:0] _C_lz_T_54 = _GEN_405 & 8'h33; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [7:0] _C_lz_T_56 = {_C_lz_T_49[5:0], 2'h0}; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [7:0] _C_lz_T_58 = _C_lz_T_56 & 8'hcc; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [7:0] _C_lz_T_59 = _C_lz_T_54 | _C_lz_T_58; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [7:0] _GEN_406 = {{1'd0}, _C_lz_T_59[7:1]}; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [7:0] _C_lz_T_64 = _GEN_406 & 8'h55; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [7:0] _C_lz_T_66 = {_C_lz_T_59[6:0], 1'h0}; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [7:0] _C_lz_T_68 = _C_lz_T_66 & 8'haa; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [7:0] _C_lz_T_69 = _C_lz_T_64 | _C_lz_T_68; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [23:0] _C_lz_T_70 = {_C_lz_T_39,_C_lz_T_69}; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [4:0] _C_lz_T_95 = _C_lz_T_70[22] ? 5'h16 : 5'h17; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _C_lz_T_96 = _C_lz_T_70[21] ? 5'h15 : _C_lz_T_95; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _C_lz_T_97 = _C_lz_T_70[20] ? 5'h14 : _C_lz_T_96; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _C_lz_T_98 = _C_lz_T_70[19] ? 5'h13 : _C_lz_T_97; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _C_lz_T_99 = _C_lz_T_70[18] ? 5'h12 : _C_lz_T_98; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _C_lz_T_100 = _C_lz_T_70[17] ? 5'h11 : _C_lz_T_99; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _C_lz_T_101 = _C_lz_T_70[16] ? 5'h10 : _C_lz_T_100; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _C_lz_T_102 = _C_lz_T_70[15] ? 5'hf : _C_lz_T_101; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _C_lz_T_103 = _C_lz_T_70[14] ? 5'he : _C_lz_T_102; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _C_lz_T_104 = _C_lz_T_70[13] ? 5'hd : _C_lz_T_103; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _C_lz_T_105 = _C_lz_T_70[12] ? 5'hc : _C_lz_T_104; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _C_lz_T_106 = _C_lz_T_70[11] ? 5'hb : _C_lz_T_105; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _C_lz_T_107 = _C_lz_T_70[10] ? 5'ha : _C_lz_T_106; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _C_lz_T_108 = _C_lz_T_70[9] ? 5'h9 : _C_lz_T_107; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _C_lz_T_109 = _C_lz_T_70[8] ? 5'h8 : _C_lz_T_108; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _C_lz_T_110 = _C_lz_T_70[7] ? 5'h7 : _C_lz_T_109; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _C_lz_T_111 = _C_lz_T_70[6] ? 5'h6 : _C_lz_T_110; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _C_lz_T_112 = _C_lz_T_70[5] ? 5'h5 : _C_lz_T_111; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _C_lz_T_113 = _C_lz_T_70[4] ? 5'h4 : _C_lz_T_112; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _C_lz_T_114 = _C_lz_T_70[3] ? 5'h3 : _C_lz_T_113; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _C_lz_T_115 = _C_lz_T_70[2] ? 5'h2 : _C_lz_T_114; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _C_lz_T_116 = _C_lz_T_70[1] ? 5'h1 : _C_lz_T_115; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] C_lz = _C_lz_T_70[0] ? 5'h0 : _C_lz_T_116; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [54:0] _GEN_2 = {{31'd0}, C_raw}; // @[src/main/scala/rv32i/Fpu.scala 74:19]
  wire [54:0] _C_w_sig_T = _GEN_2 << C_lz; // @[src/main/scala/rv32i/Fpu.scala 74:19]
  wire [23:0] C_sig = _C_w_sig_T[23:0]; // @[src/main/scala/rv32i/Fpu.scala 74:25]
  wire [8:0] _C_eLsb_T_1 = {1'b0,$signed(C_ef)}; // @[src/main/scala/rv32i/Fpu.scala 75:51]
  wire [12:0] _C_eLsb_T_2 = {{4{_C_eLsb_T_1[8]}},_C_eLsb_T_1}; // @[src/main/scala/rv32i/Fpu.scala 75:59]
  wire [12:0] _C_eLsb_T_5 = $signed(_C_eLsb_T_2) - 13'sh96; // @[src/main/scala/rv32i/Fpu.scala 75:64]
  wire [12:0] C_eLsb = _C_w_zero_T ? $signed(-13'sh95) : $signed(_C_eLsb_T_5); // @[src/main/scala/rv32i/Fpu.scala 75:19]
  wire [12:0] _C_w_exp_T_2 = $signed(C_eLsb) + 13'sh17; // @[src/main/scala/rv32i/Fpu.scala 76:19]
  wire [5:0] _C_w_exp_T_3 = {1'b0,$signed(C_lz)}; // @[src/main/scala/rv32i/Fpu.scala 76:37]
  wire [12:0] _C_w_exp_T_4 = {{7{_C_w_exp_T_3[5]}},_C_w_exp_T_3}; // @[src/main/scala/rv32i/Fpu.scala 76:45]
  wire [12:0] C_exp = $signed(_C_w_exp_T_2) - $signed(_C_w_exp_T_4); // @[src/main/scala/rv32i/Fpu.scala 76:32]
  wire  _isAddSub_T_1 = op == 4'h1; // @[src/main/scala/rv32i/Fpu.scala 131:44]
  wire  isAddSub = op == 4'h0 | op == 4'h1; // @[src/main/scala/rv32i/Fpu.scala 131:62]
  wire  isMul = op == 4'h2; // @[src/main/scala/rv32i/Fpu.scala 131:44]
  wire  isFma = op == 4'h5 | op == 4'h6 | op == 4'h7 | op == 4'h8; // @[src/main/scala/rv32i/Fpu.scala 131:62]
  wire  isDiv = op == 4'h3; // @[src/main/scala/rv32i/Fpu.scala 131:44]
  wire  isSqrt = op == 4'h4; // @[src/main/scala/rv32i/Fpu.scala 131:44]
  wire  _isToInt_T = op == 4'h9; // @[src/main/scala/rv32i/Fpu.scala 131:44]
  wire  isToInt = op == 4'h9 | op == 4'ha; // @[src/main/scala/rv32i/Fpu.scala 131:62]
  wire  _isFromInt_T = op == 4'hb; // @[src/main/scala/rv32i/Fpu.scala 131:44]
  wire  negProd = op == 4'h7 | op == 4'h8; // @[src/main/scala/rv32i/Fpu.scala 131:62]
  wire  negC = op == 4'h6 | op == 4'h8; // @[src/main/scala/rv32i/Fpu.scala 131:62]
  reg  xSign; // @[src/main/scala/rv32i/Fpu.scala 155:18]
  reg  xZero; // @[src/main/scala/rv32i/Fpu.scala 155:43]
  reg [47:0] xSig; // @[src/main/scala/rv32i/Fpu.scala 155:67]
  reg [12:0] xExp; // @[src/main/scala/rv32i/Fpu.scala 155:95]
  reg  ySign; // @[src/main/scala/rv32i/Fpu.scala 156:18]
  reg  yZero; // @[src/main/scala/rv32i/Fpu.scala 156:43]
  reg [47:0] ySig; // @[src/main/scala/rv32i/Fpu.scala 156:67]
  reg [12:0] yExp; // @[src/main/scala/rv32i/Fpu.scala 156:95]
  reg [47:0] acc; // @[src/main/scala/rv32i/Fpu.scala 157:21]
  reg [47:0] mcand; // @[src/main/scala/rv32i/Fpu.scala 158:21]
  reg [23:0] mplier; // @[src/main/scala/rv32i/Fpu.scala 159:21]
  reg [4:0] count; // @[src/main/scala/rv32i/Fpu.scala 160:21]
  reg [30:0] rem; // @[src/main/scala/rv32i/Fpu.scala 161:21]
  reg [26:0] quo; // @[src/main/scala/rv32i/Fpu.scala 162:21]
  reg [23:0] divisor; // @[src/main/scala/rv32i/Fpu.scala 163:21]
  reg [53:0] radicand; // @[src/main/scala/rv32i/Fpu.scala 164:21]
  reg [55:0] raw; // @[src/main/scala/rv32i/Fpu.scala 165:21]
  reg [12:0] rawE; // @[src/main/scala/rv32i/Fpu.scala 166:21]
  reg  sticky; // @[src/main/scala/rv32i/Fpu.scala 167:21]
  reg  rSign; // @[src/main/scala/rv32i/Fpu.scala 168:21]
  reg [55:0] nSig; // @[src/main/scala/rv32i/Fpu.scala 169:21]
  reg [12:0] nExp; // @[src/main/scala/rv32i/Fpu.scala 170:21]
  reg [31:0] resBits; // @[src/main/scala/rv32i/Fpu.scala 171:21]
  reg [4:0] resFlags; // @[src/main/scala/rv32i/Fpu.scala 172:21]
  wire  sb = B_sign ^ _isAddSub_T_1; // @[src/main/scala/rv32i/Fpu.scala 181:23]
  wire  _T_2 = A_nan | B_nan; // @[src/main/scala/rv32i/Fpu.scala 182:18]
  wire  _T_3 = A_snan | B_snan; // @[src/main/scala/rv32i/Fpu.scala 182:53]
  wire [4:0] _T_4 = A_snan | B_snan ? 5'h10 : 5'h0; // @[src/main/scala/rv32i/Fpu.scala 182:45]
  wire  _T_5 = A_inf & B_inf; // @[src/main/scala/rv32i/Fpu.scala 183:25]
  wire  _T_6 = A_sign == sb; // @[src/main/scala/rv32i/Fpu.scala 183:55]
  wire [31:0] _T_7 = {A_sign,31'h7f800000}; // @[src/main/scala/rv32i/Fpu.scala 143:32]
  wire [31:0] _T_8 = A_sign == sb ? _T_7 : 32'h7fc00000; // @[src/main/scala/rv32i/Fpu.scala 183:47]
  wire [4:0] _T_10 = A_sign == sb ? 5'h0 : 5'h10; // @[src/main/scala/rv32i/Fpu.scala 183:85]
  wire [31:0] _T_12 = {sb,31'h7f800000}; // @[src/main/scala/rv32i/Fpu.scala 143:32]
  wire  _T_13 = A_zero & B_zero; // @[src/main/scala/rv32i/Fpu.scala 186:26]
  wire  _T_15 = rm == 3'h2; // @[src/main/scala/rv32i/Fpu.scala 186:81]
  wire  _T_16 = _T_6 ? A_sign : rm == 3'h2; // @[src/main/scala/rv32i/Fpu.scala 186:54]
  wire [31:0] _T_17 = {_T_16,31'h0}; // @[src/main/scala/rv32i/Fpu.scala 144:32]
  wire [47:0] _xSig_T = {A_sig,24'h0}; // @[src/main/scala/rv32i/Fpu.scala 188:56]
  wire [47:0] _ySig_T = {B_sig,24'h0}; // @[src/main/scala/rv32i/Fpu.scala 189:56]
  wire [31:0] _GEN_6 = A_zero & B_zero ? _T_17 : resBits; // @[src/main/scala/rv32i/Fpu.scala 171:21 186:37 174:57]
  wire [4:0] _GEN_7 = A_zero & B_zero ? 5'h0 : resFlags; // @[src/main/scala/rv32i/Fpu.scala 172:21 186:37 174:75]
  wire [3:0] _GEN_8 = A_zero & B_zero ? 4'h9 : 4'h3; // @[src/main/scala/rv32i/Fpu.scala 186:37 174:91 190:17]
  wire  _GEN_9 = A_zero & B_zero ? xSign : A_sign; // @[src/main/scala/rv32i/Fpu.scala 155:18 186:37 188:17]
  wire  _GEN_10 = A_zero & B_zero ? xZero : A_zero; // @[src/main/scala/rv32i/Fpu.scala 186:37 155:43 188:34]
  wire [47:0] _GEN_11 = A_zero & B_zero ? xSig : _xSig_T; // @[src/main/scala/rv32i/Fpu.scala 186:37 155:67 188:50]
  wire [12:0] _GEN_12 = A_zero & B_zero ? $signed(xExp) : $signed(A_exp); // @[src/main/scala/rv32i/Fpu.scala 186:37 155:95 188:81]
  wire  _GEN_13 = A_zero & B_zero ? ySign : sb; // @[src/main/scala/rv32i/Fpu.scala 156:18 186:37 189:17]
  wire  _GEN_14 = A_zero & B_zero ? yZero : B_zero; // @[src/main/scala/rv32i/Fpu.scala 186:37 156:43 189:34]
  wire [47:0] _GEN_15 = A_zero & B_zero ? ySig : _ySig_T; // @[src/main/scala/rv32i/Fpu.scala 186:37 156:67 189:50]
  wire [12:0] _GEN_16 = A_zero & B_zero ? $signed(yExp) : $signed(B_exp); // @[src/main/scala/rv32i/Fpu.scala 186:37 156:95 189:81]
  wire [31:0] _GEN_17 = B_inf ? _T_12 : _GEN_6; // @[src/main/scala/rv32i/Fpu.scala 185:26 174:57]
  wire [4:0] _GEN_18 = B_inf ? 5'h0 : _GEN_7; // @[src/main/scala/rv32i/Fpu.scala 185:26 174:75]
  wire [3:0] _GEN_19 = B_inf ? 4'h9 : _GEN_8; // @[src/main/scala/rv32i/Fpu.scala 185:26 174:91]
  wire  _GEN_20 = B_inf ? xSign : _GEN_9; // @[src/main/scala/rv32i/Fpu.scala 155:18 185:26]
  wire  _GEN_21 = B_inf ? xZero : _GEN_10; // @[src/main/scala/rv32i/Fpu.scala 185:26 155:43]
  wire [47:0] _GEN_22 = B_inf ? xSig : _GEN_11; // @[src/main/scala/rv32i/Fpu.scala 185:26 155:67]
  wire [12:0] _GEN_23 = B_inf ? $signed(xExp) : $signed(_GEN_12); // @[src/main/scala/rv32i/Fpu.scala 185:26 155:95]
  wire  _GEN_24 = B_inf ? ySign : _GEN_13; // @[src/main/scala/rv32i/Fpu.scala 156:18 185:26]
  wire  _GEN_25 = B_inf ? yZero : _GEN_14; // @[src/main/scala/rv32i/Fpu.scala 185:26 156:43]
  wire [47:0] _GEN_26 = B_inf ? ySig : _GEN_15; // @[src/main/scala/rv32i/Fpu.scala 185:26 156:67]
  wire [12:0] _GEN_27 = B_inf ? $signed(yExp) : $signed(_GEN_16); // @[src/main/scala/rv32i/Fpu.scala 185:26 156:95]
  wire [31:0] _GEN_28 = A_inf ? _T_7 : _GEN_17; // @[src/main/scala/rv32i/Fpu.scala 184:26 174:57]
  wire [4:0] _GEN_29 = A_inf ? 5'h0 : _GEN_18; // @[src/main/scala/rv32i/Fpu.scala 184:26 174:75]
  wire [3:0] _GEN_30 = A_inf ? 4'h9 : _GEN_19; // @[src/main/scala/rv32i/Fpu.scala 184:26 174:91]
  wire  _GEN_31 = A_inf ? xSign : _GEN_20; // @[src/main/scala/rv32i/Fpu.scala 155:18 184:26]
  wire  _GEN_32 = A_inf ? xZero : _GEN_21; // @[src/main/scala/rv32i/Fpu.scala 184:26 155:43]
  wire [47:0] _GEN_33 = A_inf ? xSig : _GEN_22; // @[src/main/scala/rv32i/Fpu.scala 184:26 155:67]
  wire [12:0] _GEN_34 = A_inf ? $signed(xExp) : $signed(_GEN_23); // @[src/main/scala/rv32i/Fpu.scala 184:26 155:95]
  wire  _GEN_35 = A_inf ? ySign : _GEN_24; // @[src/main/scala/rv32i/Fpu.scala 156:18 184:26]
  wire  _GEN_36 = A_inf ? yZero : _GEN_25; // @[src/main/scala/rv32i/Fpu.scala 184:26 156:43]
  wire [47:0] _GEN_37 = A_inf ? ySig : _GEN_26; // @[src/main/scala/rv32i/Fpu.scala 184:26 156:67]
  wire [12:0] _GEN_38 = A_inf ? $signed(yExp) : $signed(_GEN_27); // @[src/main/scala/rv32i/Fpu.scala 184:26 156:95]
  wire [31:0] _GEN_39 = A_inf & B_inf ? _T_8 : _GEN_28; // @[src/main/scala/rv32i/Fpu.scala 183:35 174:57]
  wire [4:0] _GEN_40 = A_inf & B_inf ? _T_10 : _GEN_29; // @[src/main/scala/rv32i/Fpu.scala 183:35 174:75]
  wire [3:0] _GEN_41 = A_inf & B_inf ? 4'h9 : _GEN_30; // @[src/main/scala/rv32i/Fpu.scala 183:35 174:91]
  wire [31:0] _GEN_50 = A_nan | B_nan ? 32'h7fc00000 : _GEN_39; // @[src/main/scala/rv32i/Fpu.scala 182:28 174:57]
  wire [4:0] _GEN_51 = A_nan | B_nan ? _T_4 : _GEN_40; // @[src/main/scala/rv32i/Fpu.scala 182:28 174:75]
  wire [3:0] _GEN_52 = A_nan | B_nan ? 4'h9 : _GEN_41; // @[src/main/scala/rv32i/Fpu.scala 182:28 174:91]
  wire  _ps_T = A_sign ^ B_sign; // @[src/main/scala/rv32i/Fpu.scala 193:23]
  wire  ps = A_sign ^ B_sign ^ negProd; // @[src/main/scala/rv32i/Fpu.scala 193:32]
  wire  cs = C_sign ^ negC; // @[src/main/scala/rv32i/Fpu.scala 194:23]
  wire  infTimesZero = A_inf & B_zero | A_zero & B_inf; // @[src/main/scala/rv32i/Fpu.scala 195:44]
  wire [4:0] _T_25 = _T_3 | isFma & C_snan ? 5'h10 : 5'h0; // @[src/main/scala/rv32i/Fpu.scala 198:26]
  wire  _T_27 = isFma & C_inf; // @[src/main/scala/rv32i/Fpu.scala 201:22]
  wire [31:0] _T_30 = {ps,31'h7f800000}; // @[src/main/scala/rv32i/Fpu.scala 143:32]
  wire [31:0] _GEN_61 = isFma & C_inf & cs != ps ? 32'h7fc00000 : _T_30; // @[src/main/scala/rv32i/Fpu.scala 201:45 174:{57,57}]
  wire [4:0] _GEN_62 = isFma & C_inf & cs != ps ? 5'h10 : 5'h0; // @[src/main/scala/rv32i/Fpu.scala 201:45 174:{75,75}]
  wire [31:0] _T_32 = {cs,31'h7f800000}; // @[src/main/scala/rv32i/Fpu.scala 143:32]
  wire  _T_39 = isMul | ps == cs ? ps : _T_15; // @[src/main/scala/rv32i/Fpu.scala 205:26]
  wire [31:0] _T_40 = {_T_39,31'h0}; // @[src/main/scala/rv32i/Fpu.scala 144:32]
  wire [12:0] _xExp_T_2 = $signed(A_exp) + $signed(B_exp); // @[src/main/scala/rv32i/Fpu.scala 209:65]
  wire [47:0] _ySig_T_1 = {C_sig,24'h0}; // @[src/main/scala/rv32i/Fpu.scala 210:61]
  wire [31:0] _GEN_64 = (A_zero | B_zero) & (isMul | C_zero) ? _T_40 : resBits; // @[src/main/scala/rv32i/Fpu.scala 171:21 174:57 204:60]
  wire [4:0] _GEN_65 = (A_zero | B_zero) & (isMul | C_zero) ? 5'h0 : resFlags; // @[src/main/scala/rv32i/Fpu.scala 172:21 204:60 174:75]
  wire [3:0] _GEN_66 = (A_zero | B_zero) & (isMul | C_zero) ? 4'h9 : 4'h2; // @[src/main/scala/rv32i/Fpu.scala 204:60 174:91 211:17]
  wire [47:0] _GEN_67 = (A_zero | B_zero) & (isMul | C_zero) ? acc : 48'h0; // @[src/main/scala/rv32i/Fpu.scala 157:21 204:60 208:15]
  wire [47:0] _GEN_68 = (A_zero | B_zero) & (isMul | C_zero) ? mcand : {{24'd0}, A_sig}; // @[src/main/scala/rv32i/Fpu.scala 158:21 204:60 208:29]
  wire [23:0] _GEN_69 = (A_zero | B_zero) & (isMul | C_zero) ? mplier : B_sig; // @[src/main/scala/rv32i/Fpu.scala 159:21 204:60 208:46]
  wire [4:0] _GEN_70 = (A_zero | B_zero) & (isMul | C_zero) ? count : 5'h0; // @[src/main/scala/rv32i/Fpu.scala 160:21 204:60 208:62]
  wire  _GEN_71 = (A_zero | B_zero) & (isMul | C_zero) ? xSign : ps; // @[src/main/scala/rv32i/Fpu.scala 155:18 204:60 209:17]
  wire  _GEN_72 = (A_zero | B_zero) & (isMul | C_zero) ? xZero : A_zero | B_zero; // @[src/main/scala/rv32i/Fpu.scala 155:43 204:60 209:30]
  wire [12:0] _GEN_73 = (A_zero | B_zero) & (isMul | C_zero) ? $signed(xExp) : $signed(_xExp_T_2); // @[src/main/scala/rv32i/Fpu.scala 204:60 155:95 209:56]
  wire  _GEN_74 = (A_zero | B_zero) & (isMul | C_zero) ? ySign : cs; // @[src/main/scala/rv32i/Fpu.scala 156:18 204:60 210:17]
  wire  _GEN_75 = (A_zero | B_zero) & (isMul | C_zero) ? yZero : isMul | C_zero; // @[src/main/scala/rv32i/Fpu.scala 156:43 204:60 210:30]
  wire [47:0] _GEN_76 = (A_zero | B_zero) & (isMul | C_zero) ? ySig : _ySig_T_1; // @[src/main/scala/rv32i/Fpu.scala 204:60 156:67 210:55]
  wire [12:0] _GEN_77 = (A_zero | B_zero) & (isMul | C_zero) ? $signed(yExp) : $signed(C_exp); // @[src/main/scala/rv32i/Fpu.scala 204:60 156:95 210:86]
  wire [31:0] _GEN_78 = _T_27 ? _T_32 : _GEN_64; // @[src/main/scala/rv32i/Fpu.scala 203:35 174:57]
  wire [4:0] _GEN_79 = _T_27 ? 5'h0 : _GEN_65; // @[src/main/scala/rv32i/Fpu.scala 203:35 174:75]
  wire [3:0] _GEN_80 = _T_27 ? 4'h9 : _GEN_66; // @[src/main/scala/rv32i/Fpu.scala 203:35 174:91]
  wire [47:0] _GEN_81 = _T_27 ? acc : _GEN_67; // @[src/main/scala/rv32i/Fpu.scala 157:21 203:35]
  wire [47:0] _GEN_82 = _T_27 ? mcand : _GEN_68; // @[src/main/scala/rv32i/Fpu.scala 158:21 203:35]
  wire [23:0] _GEN_83 = _T_27 ? mplier : _GEN_69; // @[src/main/scala/rv32i/Fpu.scala 159:21 203:35]
  wire [4:0] _GEN_84 = _T_27 ? count : _GEN_70; // @[src/main/scala/rv32i/Fpu.scala 160:21 203:35]
  wire  _GEN_85 = _T_27 ? xSign : _GEN_71; // @[src/main/scala/rv32i/Fpu.scala 155:18 203:35]
  wire  _GEN_86 = _T_27 ? xZero : _GEN_72; // @[src/main/scala/rv32i/Fpu.scala 203:35 155:43]
  wire [12:0] _GEN_87 = _T_27 ? $signed(xExp) : $signed(_GEN_73); // @[src/main/scala/rv32i/Fpu.scala 203:35 155:95]
  wire  _GEN_88 = _T_27 ? ySign : _GEN_74; // @[src/main/scala/rv32i/Fpu.scala 156:18 203:35]
  wire  _GEN_89 = _T_27 ? yZero : _GEN_75; // @[src/main/scala/rv32i/Fpu.scala 203:35 156:43]
  wire [47:0] _GEN_90 = _T_27 ? ySig : _GEN_76; // @[src/main/scala/rv32i/Fpu.scala 203:35 156:67]
  wire [12:0] _GEN_91 = _T_27 ? $signed(yExp) : $signed(_GEN_77); // @[src/main/scala/rv32i/Fpu.scala 203:35 156:95]
  wire [31:0] _GEN_92 = A_inf | B_inf ? _GEN_61 : _GEN_78; // @[src/main/scala/rv32i/Fpu.scala 200:35]
  wire [4:0] _GEN_93 = A_inf | B_inf ? _GEN_62 : _GEN_79; // @[src/main/scala/rv32i/Fpu.scala 200:35]
  wire [3:0] _GEN_94 = A_inf | B_inf ? 4'h9 : _GEN_80; // @[src/main/scala/rv32i/Fpu.scala 200:35]
  wire [47:0] _GEN_95 = A_inf | B_inf ? acc : _GEN_81; // @[src/main/scala/rv32i/Fpu.scala 157:21 200:35]
  wire [47:0] _GEN_96 = A_inf | B_inf ? mcand : _GEN_82; // @[src/main/scala/rv32i/Fpu.scala 158:21 200:35]
  wire [23:0] _GEN_97 = A_inf | B_inf ? mplier : _GEN_83; // @[src/main/scala/rv32i/Fpu.scala 159:21 200:35]
  wire [4:0] _GEN_98 = A_inf | B_inf ? count : _GEN_84; // @[src/main/scala/rv32i/Fpu.scala 160:21 200:35]
  wire  _GEN_99 = A_inf | B_inf ? xSign : _GEN_85; // @[src/main/scala/rv32i/Fpu.scala 155:18 200:35]
  wire  _GEN_100 = A_inf | B_inf ? xZero : _GEN_86; // @[src/main/scala/rv32i/Fpu.scala 200:35 155:43]
  wire [12:0] _GEN_101 = A_inf | B_inf ? $signed(xExp) : $signed(_GEN_87); // @[src/main/scala/rv32i/Fpu.scala 200:35 155:95]
  wire  _GEN_102 = A_inf | B_inf ? ySign : _GEN_88; // @[src/main/scala/rv32i/Fpu.scala 156:18 200:35]
  wire  _GEN_103 = A_inf | B_inf ? yZero : _GEN_89; // @[src/main/scala/rv32i/Fpu.scala 200:35 156:43]
  wire [47:0] _GEN_104 = A_inf | B_inf ? ySig : _GEN_90; // @[src/main/scala/rv32i/Fpu.scala 200:35 156:67]
  wire [12:0] _GEN_105 = A_inf | B_inf ? $signed(yExp) : $signed(_GEN_91); // @[src/main/scala/rv32i/Fpu.scala 200:35 156:95]
  wire [31:0] _GEN_106 = _T_2 | isFma & C_nan ? 32'h7fc00000 : _GEN_92; // @[src/main/scala/rv32i/Fpu.scala 197:55 174:57]
  wire [4:0] _GEN_107 = _T_2 | isFma & C_nan ? _T_25 : _GEN_93; // @[src/main/scala/rv32i/Fpu.scala 197:55 174:75]
  wire [3:0] _GEN_108 = _T_2 | isFma & C_nan ? 4'h9 : _GEN_94; // @[src/main/scala/rv32i/Fpu.scala 197:55 174:91]
  wire [47:0] _GEN_109 = _T_2 | isFma & C_nan ? acc : _GEN_95; // @[src/main/scala/rv32i/Fpu.scala 157:21 197:55]
  wire [47:0] _GEN_110 = _T_2 | isFma & C_nan ? mcand : _GEN_96; // @[src/main/scala/rv32i/Fpu.scala 158:21 197:55]
  wire [23:0] _GEN_111 = _T_2 | isFma & C_nan ? mplier : _GEN_97; // @[src/main/scala/rv32i/Fpu.scala 159:21 197:55]
  wire [4:0] _GEN_112 = _T_2 | isFma & C_nan ? count : _GEN_98; // @[src/main/scala/rv32i/Fpu.scala 160:21 197:55]
  wire  _GEN_113 = _T_2 | isFma & C_nan ? xSign : _GEN_99; // @[src/main/scala/rv32i/Fpu.scala 155:18 197:55]
  wire  _GEN_114 = _T_2 | isFma & C_nan ? xZero : _GEN_100; // @[src/main/scala/rv32i/Fpu.scala 155:43 197:55]
  wire [12:0] _GEN_115 = _T_2 | isFma & C_nan ? $signed(xExp) : $signed(_GEN_101); // @[src/main/scala/rv32i/Fpu.scala 197:55 155:95]
  wire  _GEN_116 = _T_2 | isFma & C_nan ? ySign : _GEN_102; // @[src/main/scala/rv32i/Fpu.scala 156:18 197:55]
  wire  _GEN_117 = _T_2 | isFma & C_nan ? yZero : _GEN_103; // @[src/main/scala/rv32i/Fpu.scala 156:43 197:55]
  wire [47:0] _GEN_118 = _T_2 | isFma & C_nan ? ySig : _GEN_104; // @[src/main/scala/rv32i/Fpu.scala 197:55 156:67]
  wire [12:0] _GEN_119 = _T_2 | isFma & C_nan ? $signed(yExp) : $signed(_GEN_105); // @[src/main/scala/rv32i/Fpu.scala 197:55 156:95]
  wire [31:0] _GEN_120 = infTimesZero ? 32'h7fc00000 : _GEN_106; // @[src/main/scala/rv32i/Fpu.scala 196:26 174:57]
  wire [4:0] _GEN_121 = infTimesZero ? 5'h10 : _GEN_107; // @[src/main/scala/rv32i/Fpu.scala 196:26 174:75]
  wire [3:0] _GEN_122 = infTimesZero ? 4'h9 : _GEN_108; // @[src/main/scala/rv32i/Fpu.scala 196:26 174:91]
  wire [47:0] _GEN_123 = infTimesZero ? acc : _GEN_109; // @[src/main/scala/rv32i/Fpu.scala 157:21 196:26]
  wire [47:0] _GEN_124 = infTimesZero ? mcand : _GEN_110; // @[src/main/scala/rv32i/Fpu.scala 158:21 196:26]
  wire [23:0] _GEN_125 = infTimesZero ? mplier : _GEN_111; // @[src/main/scala/rv32i/Fpu.scala 159:21 196:26]
  wire [4:0] _GEN_126 = infTimesZero ? count : _GEN_112; // @[src/main/scala/rv32i/Fpu.scala 160:21 196:26]
  wire [31:0] _T_47 = {_ps_T,31'h7f800000}; // @[src/main/scala/rv32i/Fpu.scala 143:32]
  wire [31:0] _T_48 = {_ps_T,31'h0}; // @[src/main/scala/rv32i/Fpu.scala 144:32]
  wire [12:0] _rawE_T_2 = $signed(A_exp) - $signed(B_exp); // @[src/main/scala/rv32i/Fpu.scala 223:37]
  wire [12:0] _rawE_T_5 = $signed(_rawE_T_2) - 13'sh1a; // @[src/main/scala/rv32i/Fpu.scala 223:45]
  wire [31:0] _GEN_134 = A_zero ? _T_48 : resBits; // @[src/main/scala/rv32i/Fpu.scala 171:21 220:27 174:57]
  wire [4:0] _GEN_135 = A_zero ? 5'h0 : resFlags; // @[src/main/scala/rv32i/Fpu.scala 172:21 220:27 174:75]
  wire [3:0] _GEN_136 = A_zero ? 4'h9 : 4'h4; // @[src/main/scala/rv32i/Fpu.scala 220:27 174:91 224:17]
  wire [30:0] _GEN_137 = A_zero ? rem : {{7'd0}, A_sig}; // @[src/main/scala/rv32i/Fpu.scala 161:21 220:27 222:15]
  wire [23:0] _GEN_138 = A_zero ? divisor : B_sig; // @[src/main/scala/rv32i/Fpu.scala 163:21 220:27 222:33]
  wire [26:0] _GEN_139 = A_zero ? quo : 27'h0; // @[src/main/scala/rv32i/Fpu.scala 162:21 220:27 222:47]
  wire [4:0] _GEN_140 = A_zero ? count : 5'h0; // @[src/main/scala/rv32i/Fpu.scala 160:21 220:27 222:61]
  wire  _GEN_141 = A_zero ? rSign : _ps_T; // @[src/main/scala/rv32i/Fpu.scala 168:21 220:27 223:17]
  wire [12:0] _GEN_142 = A_zero ? $signed(rawE) : $signed(_rawE_T_5); // @[src/main/scala/rv32i/Fpu.scala 166:21 220:27 223:28]
  wire [31:0] _GEN_143 = B_zero ? _T_47 : _GEN_134; // @[src/main/scala/rv32i/Fpu.scala 219:27 174:57]
  wire [4:0] _GEN_144 = B_zero ? 5'h8 : _GEN_135; // @[src/main/scala/rv32i/Fpu.scala 219:27 174:75]
  wire [3:0] _GEN_145 = B_zero ? 4'h9 : _GEN_136; // @[src/main/scala/rv32i/Fpu.scala 219:27 174:91]
  wire [30:0] _GEN_146 = B_zero ? rem : _GEN_137; // @[src/main/scala/rv32i/Fpu.scala 161:21 219:27]
  wire [23:0] _GEN_147 = B_zero ? divisor : _GEN_138; // @[src/main/scala/rv32i/Fpu.scala 163:21 219:27]
  wire [26:0] _GEN_148 = B_zero ? quo : _GEN_139; // @[src/main/scala/rv32i/Fpu.scala 162:21 219:27]
  wire [4:0] _GEN_149 = B_zero ? count : _GEN_140; // @[src/main/scala/rv32i/Fpu.scala 160:21 219:27]
  wire  _GEN_150 = B_zero ? rSign : _GEN_141; // @[src/main/scala/rv32i/Fpu.scala 168:21 219:27]
  wire [12:0] _GEN_151 = B_zero ? $signed(rawE) : $signed(_GEN_142); // @[src/main/scala/rv32i/Fpu.scala 166:21 219:27]
  wire [31:0] _GEN_152 = B_inf ? _T_48 : _GEN_143; // @[src/main/scala/rv32i/Fpu.scala 218:26 174:57]
  wire [4:0] _GEN_153 = B_inf ? 5'h0 : _GEN_144; // @[src/main/scala/rv32i/Fpu.scala 218:26 174:75]
  wire [3:0] _GEN_154 = B_inf ? 4'h9 : _GEN_145; // @[src/main/scala/rv32i/Fpu.scala 218:26 174:91]
  wire [30:0] _GEN_155 = B_inf ? rem : _GEN_146; // @[src/main/scala/rv32i/Fpu.scala 161:21 218:26]
  wire [23:0] _GEN_156 = B_inf ? divisor : _GEN_147; // @[src/main/scala/rv32i/Fpu.scala 163:21 218:26]
  wire [26:0] _GEN_157 = B_inf ? quo : _GEN_148; // @[src/main/scala/rv32i/Fpu.scala 162:21 218:26]
  wire [4:0] _GEN_158 = B_inf ? count : _GEN_149; // @[src/main/scala/rv32i/Fpu.scala 160:21 218:26]
  wire  _GEN_159 = B_inf ? rSign : _GEN_150; // @[src/main/scala/rv32i/Fpu.scala 168:21 218:26]
  wire [12:0] _GEN_160 = B_inf ? $signed(rawE) : $signed(_GEN_151); // @[src/main/scala/rv32i/Fpu.scala 166:21 218:26]
  wire [31:0] _GEN_161 = A_inf ? _T_47 : _GEN_152; // @[src/main/scala/rv32i/Fpu.scala 217:26 174:57]
  wire [4:0] _GEN_162 = A_inf ? 5'h0 : _GEN_153; // @[src/main/scala/rv32i/Fpu.scala 217:26 174:75]
  wire [3:0] _GEN_163 = A_inf ? 4'h9 : _GEN_154; // @[src/main/scala/rv32i/Fpu.scala 217:26 174:91]
  wire [30:0] _GEN_164 = A_inf ? rem : _GEN_155; // @[src/main/scala/rv32i/Fpu.scala 161:21 217:26]
  wire [23:0] _GEN_165 = A_inf ? divisor : _GEN_156; // @[src/main/scala/rv32i/Fpu.scala 163:21 217:26]
  wire [26:0] _GEN_166 = A_inf ? quo : _GEN_157; // @[src/main/scala/rv32i/Fpu.scala 162:21 217:26]
  wire [4:0] _GEN_167 = A_inf ? count : _GEN_158; // @[src/main/scala/rv32i/Fpu.scala 160:21 217:26]
  wire  _GEN_168 = A_inf ? rSign : _GEN_159; // @[src/main/scala/rv32i/Fpu.scala 168:21 217:26]
  wire [12:0] _GEN_169 = A_inf ? $signed(rawE) : $signed(_GEN_160); // @[src/main/scala/rv32i/Fpu.scala 166:21 217:26]
  wire [31:0] _GEN_170 = _T_13 | _T_5 ? 32'h7fc00000 : _GEN_161; // @[src/main/scala/rv32i/Fpu.scala 174:57 216:59]
  wire [4:0] _GEN_171 = _T_13 | _T_5 ? 5'h10 : _GEN_162; // @[src/main/scala/rv32i/Fpu.scala 216:59 174:75]
  wire [3:0] _GEN_172 = _T_13 | _T_5 ? 4'h9 : _GEN_163; // @[src/main/scala/rv32i/Fpu.scala 216:59 174:91]
  wire [30:0] _GEN_173 = _T_13 | _T_5 ? rem : _GEN_164; // @[src/main/scala/rv32i/Fpu.scala 161:21 216:59]
  wire [23:0] _GEN_174 = _T_13 | _T_5 ? divisor : _GEN_165; // @[src/main/scala/rv32i/Fpu.scala 163:21 216:59]
  wire [26:0] _GEN_175 = _T_13 | _T_5 ? quo : _GEN_166; // @[src/main/scala/rv32i/Fpu.scala 162:21 216:59]
  wire [4:0] _GEN_176 = _T_13 | _T_5 ? count : _GEN_167; // @[src/main/scala/rv32i/Fpu.scala 160:21 216:59]
  wire  _GEN_177 = _T_13 | _T_5 ? rSign : _GEN_168; // @[src/main/scala/rv32i/Fpu.scala 168:21 216:59]
  wire [12:0] _GEN_178 = _T_13 | _T_5 ? $signed(rawE) : $signed(_GEN_169); // @[src/main/scala/rv32i/Fpu.scala 166:21 216:59]
  wire [31:0] _GEN_179 = _T_2 ? 32'h7fc00000 : _GEN_170; // @[src/main/scala/rv32i/Fpu.scala 215:28 174:57]
  wire [4:0] _GEN_180 = _T_2 ? _T_4 : _GEN_171; // @[src/main/scala/rv32i/Fpu.scala 215:28 174:75]
  wire [3:0] _GEN_181 = _T_2 ? 4'h9 : _GEN_172; // @[src/main/scala/rv32i/Fpu.scala 215:28 174:91]
  wire [30:0] _GEN_182 = _T_2 ? rem : _GEN_173; // @[src/main/scala/rv32i/Fpu.scala 161:21 215:28]
  wire [23:0] _GEN_183 = _T_2 ? divisor : _GEN_174; // @[src/main/scala/rv32i/Fpu.scala 163:21 215:28]
  wire [26:0] _GEN_184 = _T_2 ? quo : _GEN_175; // @[src/main/scala/rv32i/Fpu.scala 162:21 215:28]
  wire [4:0] _GEN_185 = _T_2 ? count : _GEN_176; // @[src/main/scala/rv32i/Fpu.scala 160:21 215:28]
  wire  _GEN_186 = _T_2 ? rSign : _GEN_177; // @[src/main/scala/rv32i/Fpu.scala 168:21 215:28]
  wire [12:0] _GEN_187 = _T_2 ? $signed(rawE) : $signed(_GEN_178); // @[src/main/scala/rv32i/Fpu.scala 166:21 215:28]
  wire [4:0] _T_51 = A_snan ? 5'h10 : 5'h0; // @[src/main/scala/rv32i/Fpu.scala 227:36]
  wire [12:0] e0 = $signed(A_exp) - 13'sh17; // @[src/main/scala/rv32i/Fpu.scala 232:27]
  wire  odd = e0[0]; // @[src/main/scala/rv32i/Fpu.scala 233:23]
  wire [24:0] _m_T = {A_sig,1'h0}; // @[src/main/scala/rv32i/Fpu.scala 234:33]
  wire [24:0] _m_T_1 = {1'h0,A_sig}; // @[src/main/scala/rv32i/Fpu.scala 234:55]
  wire [24:0] m = odd ? _m_T : _m_T_1; // @[src/main/scala/rv32i/Fpu.scala 234:24]
  wire [12:0] _e1_T_2 = $signed(e0) - 13'sh1; // @[src/main/scala/rv32i/Fpu.scala 235:33]
  wire [12:0] e1 = odd ? $signed(_e1_T_2) : $signed(e0); // @[src/main/scala/rv32i/Fpu.scala 235:24]
  wire [53:0] _radicand_T = {1'h0,m,28'h0}; // @[src/main/scala/rv32i/Fpu.scala 236:26]
  wire [11:0] _rawE_T_6 = e1[12:1]; // @[src/main/scala/rv32i/Fpu.scala 238:41]
  wire [12:0] _GEN_407 = {{1{_rawE_T_6[11]}},_rawE_T_6}; // @[src/main/scala/rv32i/Fpu.scala 238:47]
  wire [12:0] _rawE_T_9 = $signed(_GEN_407) - 13'she; // @[src/main/scala/rv32i/Fpu.scala 238:47]
  wire [31:0] _GEN_188 = A_inf ? 32'h7f800000 : resBits; // @[src/main/scala/rv32i/Fpu.scala 171:21 230:26 174:57]
  wire [4:0] _GEN_189 = A_inf ? 5'h0 : resFlags; // @[src/main/scala/rv32i/Fpu.scala 172:21 230:26 174:75]
  wire [3:0] _GEN_190 = A_inf ? 4'h9 : 4'h5; // @[src/main/scala/rv32i/Fpu.scala 230:26 174:91 239:17]
  wire [53:0] _GEN_191 = A_inf ? radicand : _radicand_T; // @[src/main/scala/rv32i/Fpu.scala 164:21 230:26 236:20]
  wire [30:0] _GEN_192 = A_inf ? rem : 31'h0; // @[src/main/scala/rv32i/Fpu.scala 161:21 230:26 237:15]
  wire [26:0] _GEN_193 = A_inf ? quo : 27'h0; // @[src/main/scala/rv32i/Fpu.scala 162:21 230:26 237:27]
  wire [4:0] _GEN_194 = A_inf ? count : 5'h0; // @[src/main/scala/rv32i/Fpu.scala 160:21 230:26 237:41]
  wire  _GEN_195 = A_inf & rSign; // @[src/main/scala/rv32i/Fpu.scala 168:21 230:26 238:17]
  wire [12:0] _GEN_196 = A_inf ? $signed(rawE) : $signed(_rawE_T_9); // @[src/main/scala/rv32i/Fpu.scala 166:21 230:26 238:34]
  wire [31:0] _GEN_197 = A_sign ? 32'h7fc00000 : _GEN_188; // @[src/main/scala/rv32i/Fpu.scala 229:27 174:57]
  wire [4:0] _GEN_198 = A_sign ? 5'h10 : _GEN_189; // @[src/main/scala/rv32i/Fpu.scala 229:27 174:75]
  wire [3:0] _GEN_199 = A_sign ? 4'h9 : _GEN_190; // @[src/main/scala/rv32i/Fpu.scala 229:27 174:91]
  wire [53:0] _GEN_200 = A_sign ? radicand : _GEN_191; // @[src/main/scala/rv32i/Fpu.scala 164:21 229:27]
  wire [30:0] _GEN_201 = A_sign ? rem : _GEN_192; // @[src/main/scala/rv32i/Fpu.scala 161:21 229:27]
  wire [26:0] _GEN_202 = A_sign ? quo : _GEN_193; // @[src/main/scala/rv32i/Fpu.scala 162:21 229:27]
  wire [4:0] _GEN_203 = A_sign ? count : _GEN_194; // @[src/main/scala/rv32i/Fpu.scala 160:21 229:27]
  wire  _GEN_204 = A_sign ? rSign : _GEN_195; // @[src/main/scala/rv32i/Fpu.scala 168:21 229:27]
  wire [12:0] _GEN_205 = A_sign ? $signed(rawE) : $signed(_GEN_196); // @[src/main/scala/rv32i/Fpu.scala 166:21 229:27]
  wire [31:0] _GEN_206 = A_zero ? ra : _GEN_197; // @[src/main/scala/rv32i/Fpu.scala 228:27 174:57]
  wire [4:0] _GEN_207 = A_zero ? 5'h0 : _GEN_198; // @[src/main/scala/rv32i/Fpu.scala 228:27 174:75]
  wire [3:0] _GEN_208 = A_zero ? 4'h9 : _GEN_199; // @[src/main/scala/rv32i/Fpu.scala 228:27 174:91]
  wire [53:0] _GEN_209 = A_zero ? radicand : _GEN_200; // @[src/main/scala/rv32i/Fpu.scala 164:21 228:27]
  wire [30:0] _GEN_210 = A_zero ? rem : _GEN_201; // @[src/main/scala/rv32i/Fpu.scala 161:21 228:27]
  wire [26:0] _GEN_211 = A_zero ? quo : _GEN_202; // @[src/main/scala/rv32i/Fpu.scala 162:21 228:27]
  wire [4:0] _GEN_212 = A_zero ? count : _GEN_203; // @[src/main/scala/rv32i/Fpu.scala 160:21 228:27]
  wire  _GEN_213 = A_zero ? rSign : _GEN_204; // @[src/main/scala/rv32i/Fpu.scala 168:21 228:27]
  wire [12:0] _GEN_214 = A_zero ? $signed(rawE) : $signed(_GEN_205); // @[src/main/scala/rv32i/Fpu.scala 166:21 228:27]
  wire [31:0] _GEN_215 = A_nan ? 32'h7fc00000 : _GEN_206; // @[src/main/scala/rv32i/Fpu.scala 227:19 174:57]
  wire [4:0] _GEN_216 = A_nan ? _T_51 : _GEN_207; // @[src/main/scala/rv32i/Fpu.scala 227:19 174:75]
  wire [3:0] _GEN_217 = A_nan ? 4'h9 : _GEN_208; // @[src/main/scala/rv32i/Fpu.scala 227:19 174:91]
  wire [53:0] _GEN_218 = A_nan ? radicand : _GEN_209; // @[src/main/scala/rv32i/Fpu.scala 227:19 164:21]
  wire [30:0] _GEN_219 = A_nan ? rem : _GEN_210; // @[src/main/scala/rv32i/Fpu.scala 227:19 161:21]
  wire [26:0] _GEN_220 = A_nan ? quo : _GEN_211; // @[src/main/scala/rv32i/Fpu.scala 227:19 162:21]
  wire [4:0] _GEN_221 = A_nan ? count : _GEN_212; // @[src/main/scala/rv32i/Fpu.scala 227:19 160:21]
  wire  _GEN_222 = A_nan ? rSign : _GEN_213; // @[src/main/scala/rv32i/Fpu.scala 227:19 168:21]
  wire [12:0] _GEN_223 = A_nan ? $signed(rawE) : $signed(_GEN_214); // @[src/main/scala/rv32i/Fpu.scala 227:19 166:21]
  wire  neg = _isFromInt_T & A_sign; // @[src/main/scala/rv32i/Fpu.scala 244:35]
  wire [31:0] _mag_T_1 = 32'h0 - ra; // @[src/main/scala/rv32i/Fpu.scala 245:36]
  wire [31:0] mag = neg ? _mag_T_1 : ra; // @[src/main/scala/rv32i/Fpu.scala 245:20]
  wire [31:0] _GEN_224 = mag == 32'h0 ? 32'h0 : resBits; // @[src/main/scala/rv32i/Fpu.scala 171:21 246:25 174:57]
  wire [4:0] _GEN_225 = mag == 32'h0 ? 5'h0 : resFlags; // @[src/main/scala/rv32i/Fpu.scala 172:21 246:25 174:75]
  wire [3:0] _GEN_226 = mag == 32'h0 ? 4'h9 : 4'h6; // @[src/main/scala/rv32i/Fpu.scala 246:25 174:91 248:15]
  wire [55:0] _GEN_227 = mag == 32'h0 ? raw : {{24'd0}, mag}; // @[src/main/scala/rv32i/Fpu.scala 165:21 246:25 247:13]
  wire [12:0] _GEN_228 = mag == 32'h0 ? $signed(rawE) : $signed(13'sh0); // @[src/main/scala/rv32i/Fpu.scala 166:21 246:25 247:26]
  wire  _GEN_229 = mag == 32'h0 ? rSign : neg; // @[src/main/scala/rv32i/Fpu.scala 168:21 246:25 247:41]
  wire [3:0] _GEN_230 = isToInt ? 4'h8 : _GEN_226; // @[src/main/scala/rv32i/Fpu.scala 241:25 242:13]
  wire [31:0] _GEN_231 = isToInt ? resBits : _GEN_224; // @[src/main/scala/rv32i/Fpu.scala 171:21 241:25]
  wire [4:0] _GEN_232 = isToInt ? resFlags : _GEN_225; // @[src/main/scala/rv32i/Fpu.scala 172:21 241:25]
  wire [55:0] _GEN_233 = isToInt ? raw : _GEN_227; // @[src/main/scala/rv32i/Fpu.scala 165:21 241:25]
  wire [12:0] _GEN_234 = isToInt ? $signed(rawE) : $signed(_GEN_228); // @[src/main/scala/rv32i/Fpu.scala 166:21 241:25]
  wire  _GEN_235 = isToInt ? rSign : _GEN_229; // @[src/main/scala/rv32i/Fpu.scala 168:21 241:25]
  wire [31:0] _GEN_236 = isSqrt ? _GEN_215 : _GEN_231; // @[src/main/scala/rv32i/Fpu.scala 226:24]
  wire [4:0] _GEN_237 = isSqrt ? _GEN_216 : _GEN_232; // @[src/main/scala/rv32i/Fpu.scala 226:24]
  wire [3:0] _GEN_238 = isSqrt ? _GEN_217 : _GEN_230; // @[src/main/scala/rv32i/Fpu.scala 226:24]
  wire [53:0] _GEN_239 = isSqrt ? _GEN_218 : radicand; // @[src/main/scala/rv32i/Fpu.scala 164:21 226:24]
  wire [30:0] _GEN_240 = isSqrt ? _GEN_219 : rem; // @[src/main/scala/rv32i/Fpu.scala 161:21 226:24]
  wire [26:0] _GEN_241 = isSqrt ? _GEN_220 : quo; // @[src/main/scala/rv32i/Fpu.scala 162:21 226:24]
  wire [4:0] _GEN_242 = isSqrt ? _GEN_221 : count; // @[src/main/scala/rv32i/Fpu.scala 160:21 226:24]
  wire  _GEN_243 = isSqrt ? _GEN_222 : _GEN_235; // @[src/main/scala/rv32i/Fpu.scala 226:24]
  wire [12:0] _GEN_244 = isSqrt ? $signed(_GEN_223) : $signed(_GEN_234); // @[src/main/scala/rv32i/Fpu.scala 226:24]
  wire [55:0] _GEN_245 = isSqrt ? raw : _GEN_233; // @[src/main/scala/rv32i/Fpu.scala 165:21 226:24]
  wire [31:0] _GEN_246 = isDiv ? _GEN_179 : _GEN_236; // @[src/main/scala/rv32i/Fpu.scala 213:23]
  wire [4:0] _GEN_247 = isDiv ? _GEN_180 : _GEN_237; // @[src/main/scala/rv32i/Fpu.scala 213:23]
  wire [3:0] _GEN_248 = isDiv ? _GEN_181 : _GEN_238; // @[src/main/scala/rv32i/Fpu.scala 213:23]
  wire [30:0] _GEN_249 = isDiv ? _GEN_182 : _GEN_240; // @[src/main/scala/rv32i/Fpu.scala 213:23]
  wire [26:0] _GEN_251 = isDiv ? _GEN_184 : _GEN_241; // @[src/main/scala/rv32i/Fpu.scala 213:23]
  wire [4:0] _GEN_252 = isDiv ? _GEN_185 : _GEN_242; // @[src/main/scala/rv32i/Fpu.scala 213:23]
  wire  _GEN_253 = isDiv ? _GEN_186 : _GEN_243; // @[src/main/scala/rv32i/Fpu.scala 213:23]
  wire [12:0] _GEN_254 = isDiv ? $signed(_GEN_187) : $signed(_GEN_244); // @[src/main/scala/rv32i/Fpu.scala 213:23]
  wire [53:0] _GEN_255 = isDiv ? radicand : _GEN_239; // @[src/main/scala/rv32i/Fpu.scala 164:21 213:23]
  wire [55:0] _GEN_256 = isDiv ? raw : _GEN_245; // @[src/main/scala/rv32i/Fpu.scala 165:21 213:23]
  wire [31:0] _GEN_257 = isMul | isFma ? _GEN_120 : _GEN_246; // @[src/main/scala/rv32i/Fpu.scala 192:32]
  wire [4:0] _GEN_258 = isMul | isFma ? _GEN_121 : _GEN_247; // @[src/main/scala/rv32i/Fpu.scala 192:32]
  wire [3:0] _GEN_259 = isMul | isFma ? _GEN_122 : _GEN_248; // @[src/main/scala/rv32i/Fpu.scala 192:32]
  wire [47:0] _GEN_261 = isMul | isFma ? _GEN_124 : mcand; // @[src/main/scala/rv32i/Fpu.scala 158:21 192:32]
  wire [4:0] _GEN_263 = isMul | isFma ? _GEN_126 : _GEN_252; // @[src/main/scala/rv32i/Fpu.scala 192:32]
  wire [30:0] _GEN_271 = isMul | isFma ? rem : _GEN_249; // @[src/main/scala/rv32i/Fpu.scala 161:21 192:32]
  wire [26:0] _GEN_273 = isMul | isFma ? quo : _GEN_251; // @[src/main/scala/rv32i/Fpu.scala 162:21 192:32]
  wire  _GEN_274 = isMul | isFma ? rSign : _GEN_253; // @[src/main/scala/rv32i/Fpu.scala 168:21 192:32]
  wire [12:0] _GEN_275 = isMul | isFma ? $signed(rawE) : $signed(_GEN_254); // @[src/main/scala/rv32i/Fpu.scala 166:21 192:32]
  wire [53:0] _GEN_276 = isMul | isFma ? radicand : _GEN_255; // @[src/main/scala/rv32i/Fpu.scala 164:21 192:32]
  wire [55:0] _GEN_277 = isMul | isFma ? raw : _GEN_256; // @[src/main/scala/rv32i/Fpu.scala 165:21 192:32]
  wire [31:0] _GEN_278 = isAddSub ? _GEN_50 : _GEN_257; // @[src/main/scala/rv32i/Fpu.scala 180:20]
  wire [4:0] _GEN_279 = isAddSub ? _GEN_51 : _GEN_258; // @[src/main/scala/rv32i/Fpu.scala 180:20]
  wire [3:0] _GEN_280 = isAddSub ? _GEN_52 : _GEN_259; // @[src/main/scala/rv32i/Fpu.scala 180:20]
  wire [47:0] _GEN_290 = isAddSub ? mcand : _GEN_261; // @[src/main/scala/rv32i/Fpu.scala 180:20 158:21]
  wire [4:0] _GEN_292 = isAddSub ? count : _GEN_263; // @[src/main/scala/rv32i/Fpu.scala 180:20 160:21]
  wire [30:0] _GEN_293 = isAddSub ? rem : _GEN_271; // @[src/main/scala/rv32i/Fpu.scala 180:20 161:21]
  wire  _GEN_296 = isAddSub ? rSign : _GEN_274; // @[src/main/scala/rv32i/Fpu.scala 180:20 168:21]
  wire [12:0] _GEN_297 = isAddSub ? $signed(rawE) : $signed(_GEN_275); // @[src/main/scala/rv32i/Fpu.scala 180:20 166:21]
  wire [53:0] _GEN_298 = isAddSub ? radicand : _GEN_276; // @[src/main/scala/rv32i/Fpu.scala 180:20 164:21]
  wire [55:0] _GEN_299 = isAddSub ? raw : _GEN_277; // @[src/main/scala/rv32i/Fpu.scala 180:20 165:21]
  wire  _GEN_300 = state == 4'h1 ? 1'h0 : sticky; // @[src/main/scala/rv32i/Fpu.scala 178:27 179:12 167:21]
  wire [31:0] _GEN_301 = state == 4'h1 ? _GEN_278 : resBits; // @[src/main/scala/rv32i/Fpu.scala 171:21 178:27]
  wire [4:0] _GEN_302 = state == 4'h1 ? _GEN_279 : resFlags; // @[src/main/scala/rv32i/Fpu.scala 172:21 178:27]
  wire [3:0] _GEN_303 = state == 4'h1 ? _GEN_280 : _GEN_5; // @[src/main/scala/rv32i/Fpu.scala 178:27]
  wire [47:0] _GEN_313 = state == 4'h1 ? _GEN_290 : mcand; // @[src/main/scala/rv32i/Fpu.scala 158:21 178:27]
  wire [30:0] _GEN_316 = state == 4'h1 ? _GEN_293 : rem; // @[src/main/scala/rv32i/Fpu.scala 161:21 178:27]
  wire  _GEN_319 = state == 4'h1 ? _GEN_296 : rSign; // @[src/main/scala/rv32i/Fpu.scala 168:21 178:27]
  wire [12:0] _GEN_320 = state == 4'h1 ? $signed(_GEN_297) : $signed(rawE); // @[src/main/scala/rv32i/Fpu.scala 166:21 178:27]
  wire [53:0] _GEN_321 = state == 4'h1 ? _GEN_298 : radicand; // @[src/main/scala/rv32i/Fpu.scala 164:21 178:27]
  wire [55:0] _GEN_322 = state == 4'h1 ? _GEN_299 : raw; // @[src/main/scala/rv32i/Fpu.scala 165:21 178:27]
  wire [47:0] _acc_T_1 = mplier[0] ? mcand : 48'h0; // @[src/main/scala/rv32i/Fpu.scala 255:24]
  wire [47:0] _acc_T_3 = acc + _acc_T_1; // @[src/main/scala/rv32i/Fpu.scala 255:19]
  wire [48:0] _mcand_T = {mcand, 1'h0}; // @[src/main/scala/rv32i/Fpu.scala 256:21]
  wire [4:0] _count_T_1 = count + 5'h1; // @[src/main/scala/rv32i/Fpu.scala 258:21]
  wire [3:0] _GEN_323 = count == 5'h17 ? 4'h3 : _GEN_303; // @[src/main/scala/rv32i/Fpu.scala 259:{26,34}]
  wire [48:0] _GEN_325 = state == 4'h2 ? _mcand_T : {{1'd0}, _GEN_313}; // @[src/main/scala/rv32i/Fpu.scala 254:24 256:12]
  wire [3:0] _GEN_328 = state == 4'h2 ? _GEN_323 : _GEN_303; // @[src/main/scala/rv32i/Fpu.scala 254:24]
  wire  prodTop = acc[47]; // @[src/main/scala/rv32i/Fpu.scala 264:22]
  wire [48:0] _sigX_T = {acc, 1'h0}; // @[src/main/scala/rv32i/Fpu.scala 265:58]
  wire [48:0] _sigX_T_1 = prodTop ? {{1'd0}, acc} : _sigX_T; // @[src/main/scala/rv32i/Fpu.scala 265:39]
  wire [47:0] sigX = isAddSub ? xSig : _sigX_T_1[47:0]; // @[src/main/scala/rv32i/Fpu.scala 265:19]
  wire [12:0] _expX_T_2 = $signed(xExp) + 13'sh1; // @[src/main/scala/rv32i/Fpu.scala 266:54]
  wire [12:0] _expX_T_3 = prodTop ? $signed(_expX_T_2) : $signed(xExp); // @[src/main/scala/rv32i/Fpu.scala 266:39]
  wire [12:0] expX = isAddSub ? $signed(xExp) : $signed(_expX_T_3); // @[src/main/scala/rv32i/Fpu.scala 266:19]
  wire  xBig = ~xZero & (yZero | $signed(expX) > $signed(yExp) | $signed(expX) == $signed(yExp) & sigX >= ySig); // @[src/main/scala/rv32i/Fpu.scala 267:23]
  wire [47:0] bigSig = xBig ? sigX : ySig; // @[src/main/scala/rv32i/Fpu.scala 268:23]
  wire [12:0] bigExp = xBig ? $signed(expX) : $signed(yExp); // @[src/main/scala/rv32i/Fpu.scala 269:23]
  wire  bigSign = xBig ? xSign : ySign; // @[src/main/scala/rv32i/Fpu.scala 270:23]
  wire [47:0] smallSig = xBig ? ySig : sigX; // @[src/main/scala/rv32i/Fpu.scala 271:23]
  wire [12:0] smallExp = xBig ? $signed(yExp) : $signed(expX); // @[src/main/scala/rv32i/Fpu.scala 272:23]
  wire  smallSign = xBig ? ySign : xSign; // @[src/main/scala/rv32i/Fpu.scala 273:24]
  wire  smallAbsent = xBig ? yZero : xZero; // @[src/main/scala/rv32i/Fpu.scala 274:26]
  wire [12:0] d = $signed(bigExp) - $signed(smallExp); // @[src/main/scala/rv32i/Fpu.scala 275:35]
  wire [5:0] dC = d > 13'h3f ? 6'h3f : d[5:0]; // @[src/main/scala/rv32i/Fpu.scala 276:18]
  wire [50:0] smallExt = {smallSig,3'h0}; // @[src/main/scala/rv32i/Fpu.scala 277:23]
  wire [126:0] _lost_T = 127'h1 << dC; // @[src/main/scala/rv32i/Fpu.scala 278:44]
  wire [126:0] _lost_T_2 = _lost_T - 127'h1; // @[src/main/scala/rv32i/Fpu.scala 278:51]
  wire [50:0] _lost_T_4 = smallExt & _lost_T_2[50:0]; // @[src/main/scala/rv32i/Fpu.scala 278:30]
  wire  lost = |_lost_T_4; // @[src/main/scala/rv32i/Fpu.scala 278:66]
  wire [50:0] _smallAl_T = smallExt >> dC; // @[src/main/scala/rv32i/Fpu.scala 279:52]
  wire [50:0] _GEN_408 = {{50'd0}, lost}; // @[src/main/scala/rv32i/Fpu.scala 279:59]
  wire [50:0] _smallAl_T_1 = _smallAl_T | _GEN_408; // @[src/main/scala/rv32i/Fpu.scala 279:59]
  wire [50:0] smallAl = smallAbsent ? 51'h0 : _smallAl_T_1; // @[src/main/scala/rv32i/Fpu.scala 279:23]
  wire [50:0] bigExt = {bigSig,3'h0}; // @[src/main/scala/rv32i/Fpu.scala 280:23]
  wire [50:0] _sum_T_2 = bigExt - smallAl; // @[src/main/scala/rv32i/Fpu.scala 281:49]
  wire [51:0] _sum_T_3 = bigExt + smallAl; // @[src/main/scala/rv32i/Fpu.scala 281:67]
  wire [51:0] sum = bigSign != smallSign ? {{1'd0}, _sum_T_2} : _sum_T_3; // @[src/main/scala/rv32i/Fpu.scala 281:18]
  wire [31:0] _T_59 = {_T_15,31'h0}; // @[src/main/scala/rv32i/Fpu.scala 144:32]
  wire [12:0] _rawE_T_12 = $signed(bigExp) - 13'sh32; // @[src/main/scala/rv32i/Fpu.scala 284:36]
  wire [3:0] _GEN_331 = sum == 52'h0 ? 4'h9 : 4'h6; // @[src/main/scala/rv32i/Fpu.scala 282:23 174:91 285:15]
  wire [55:0] _GEN_332 = sum == 52'h0 ? _GEN_322 : {{4'd0}, sum}; // @[src/main/scala/rv32i/Fpu.scala 282:23 284:13]
  wire [3:0] _GEN_337 = state == 4'h3 ? _GEN_331 : _GEN_328; // @[src/main/scala/rv32i/Fpu.scala 263:24]
  wire [55:0] _GEN_338 = state == 4'h3 ? _GEN_332 : _GEN_322; // @[src/main/scala/rv32i/Fpu.scala 263:24]
  wire [30:0] _GEN_409 = {{7'd0}, divisor}; // @[src/main/scala/rv32i/Fpu.scala 291:18]
  wire  ge = rem >= _GEN_409; // @[src/main/scala/rv32i/Fpu.scala 291:18]
  wire [30:0] _r1_T_1 = rem - _GEN_409; // @[src/main/scala/rv32i/Fpu.scala 292:26]
  wire [30:0] r1 = ge ? _r1_T_1 : rem; // @[src/main/scala/rv32i/Fpu.scala 292:17]
  wire [26:0] q = {quo[25:0],ge}; // @[src/main/scala/rv32i/Fpu.scala 293:17]
  wire [31:0] _rem_T = {r1, 1'h0}; // @[src/main/scala/rv32i/Fpu.scala 295:17]
  wire  _T_61 = count == 5'h1a; // @[src/main/scala/rv32i/Fpu.scala 297:16]
  wire [55:0] _GEN_341 = count == 5'h1a ? {{29'd0}, q} : _GEN_338; // @[src/main/scala/rv32i/Fpu.scala 297:{26,32}]
  wire  _GEN_342 = count == 5'h1a ? r1 != 31'h0 : _GEN_300; // @[src/main/scala/rv32i/Fpu.scala 297:{26,45}]
  wire [3:0] _GEN_343 = count == 5'h1a ? 4'h6 : _GEN_337; // @[src/main/scala/rv32i/Fpu.scala 297:{26,66}]
  wire [31:0] _GEN_345 = state == 4'h4 ? _rem_T : {{1'd0}, _GEN_316}; // @[src/main/scala/rv32i/Fpu.scala 290:24 295:11]
  wire [55:0] _GEN_347 = state == 4'h4 ? _GEN_341 : _GEN_338; // @[src/main/scala/rv32i/Fpu.scala 290:24]
  wire  _GEN_348 = state == 4'h4 ? _GEN_342 : _GEN_300; // @[src/main/scala/rv32i/Fpu.scala 290:24]
  wire [3:0] _GEN_349 = state == 4'h4 ? _GEN_343 : _GEN_337; // @[src/main/scala/rv32i/Fpu.scala 290:24]
  wire [30:0] remN = {rem[28:0],radicand[53:52]}; // @[src/main/scala/rv32i/Fpu.scala 302:19]
  wire [28:0] t = {quo,2'h1}; // @[src/main/scala/rv32i/Fpu.scala 303:19]
  wire [30:0] _GEN_411 = {{2'd0}, t}; // @[src/main/scala/rv32i/Fpu.scala 304:21]
  wire  ge_1 = remN >= _GEN_411; // @[src/main/scala/rv32i/Fpu.scala 304:21]
  wire [30:0] _remNext_T_1 = remN - _GEN_411; // @[src/main/scala/rv32i/Fpu.scala 305:32]
  wire [30:0] remNext = ge_1 ? _remNext_T_1 : remN; // @[src/main/scala/rv32i/Fpu.scala 305:22]
  wire [26:0] q_1 = {quo[25:0],ge_1}; // @[src/main/scala/rv32i/Fpu.scala 306:19]
  wire [55:0] _radicand_T_1 = {radicand, 2'h0}; // @[src/main/scala/rv32i/Fpu.scala 309:26]
  wire [3:0] _GEN_352 = _T_61 ? 4'h6 : _GEN_349; // @[src/main/scala/rv32i/Fpu.scala 311:{26,71}]
  wire [31:0] _GEN_353 = state == 4'h5 ? {{1'd0}, remNext} : _GEN_345; // @[src/main/scala/rv32i/Fpu.scala 301:25 307:14]
  wire [55:0] _GEN_355 = state == 4'h5 ? _radicand_T_1 : {{2'd0}, _GEN_321}; // @[src/main/scala/rv32i/Fpu.scala 301:25 309:14]
  wire [3:0] _GEN_359 = state == 4'h5 ? _GEN_352 : _GEN_349; // @[src/main/scala/rv32i/Fpu.scala 301:25]
  wire [31:0] _GEN_413 = {{16'd0}, raw[31:16]}; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [31:0] _lz_T_4 = _GEN_413 & 32'hffff; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [31:0] _lz_T_6 = {raw[15:0], 16'h0}; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [31:0] _lz_T_8 = _lz_T_6 & 32'hffff0000; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [31:0] _lz_T_9 = _lz_T_4 | _lz_T_8; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [31:0] _GEN_414 = {{8'd0}, _lz_T_9[31:8]}; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [31:0] _lz_T_14 = _GEN_414 & 32'hff00ff; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [31:0] _lz_T_16 = {_lz_T_9[23:0], 8'h0}; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [31:0] _lz_T_18 = _lz_T_16 & 32'hff00ff00; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [31:0] _lz_T_19 = _lz_T_14 | _lz_T_18; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [31:0] _GEN_415 = {{4'd0}, _lz_T_19[31:4]}; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [31:0] _lz_T_24 = _GEN_415 & 32'hf0f0f0f; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [31:0] _lz_T_26 = {_lz_T_19[27:0], 4'h0}; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [31:0] _lz_T_28 = _lz_T_26 & 32'hf0f0f0f0; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [31:0] _lz_T_29 = _lz_T_24 | _lz_T_28; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [31:0] _GEN_416 = {{2'd0}, _lz_T_29[31:2]}; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [31:0] _lz_T_34 = _GEN_416 & 32'h33333333; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [31:0] _lz_T_36 = {_lz_T_29[29:0], 2'h0}; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [31:0] _lz_T_38 = _lz_T_36 & 32'hcccccccc; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [31:0] _lz_T_39 = _lz_T_34 | _lz_T_38; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [31:0] _GEN_417 = {{1'd0}, _lz_T_39[31:1]}; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [31:0] _lz_T_44 = _GEN_417 & 32'h55555555; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [31:0] _lz_T_46 = {_lz_T_39[30:0], 1'h0}; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [31:0] _lz_T_48 = _lz_T_46 & 32'haaaaaaaa; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [31:0] _lz_T_49 = _lz_T_44 | _lz_T_48; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [15:0] _GEN_418 = {{8'd0}, raw[47:40]}; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [15:0] _lz_T_55 = _GEN_418 & 16'hff; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [15:0] _lz_T_57 = {raw[39:32], 8'h0}; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [15:0] _lz_T_59 = _lz_T_57 & 16'hff00; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [15:0] _lz_T_60 = _lz_T_55 | _lz_T_59; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [15:0] _GEN_419 = {{4'd0}, _lz_T_60[15:4]}; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [15:0] _lz_T_65 = _GEN_419 & 16'hf0f; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [15:0] _lz_T_67 = {_lz_T_60[11:0], 4'h0}; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [15:0] _lz_T_69 = _lz_T_67 & 16'hf0f0; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [15:0] _lz_T_70 = _lz_T_65 | _lz_T_69; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [15:0] _GEN_420 = {{2'd0}, _lz_T_70[15:2]}; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [15:0] _lz_T_75 = _GEN_420 & 16'h3333; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [15:0] _lz_T_77 = {_lz_T_70[13:0], 2'h0}; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [15:0] _lz_T_79 = _lz_T_77 & 16'hcccc; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [15:0] _lz_T_80 = _lz_T_75 | _lz_T_79; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [15:0] _GEN_421 = {{1'd0}, _lz_T_80[15:1]}; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [15:0] _lz_T_85 = _GEN_421 & 16'h5555; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [15:0] _lz_T_87 = {_lz_T_80[14:0], 1'h0}; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [15:0] _lz_T_89 = _lz_T_87 & 16'haaaa; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [15:0] _lz_T_90 = _lz_T_85 | _lz_T_89; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [7:0] _GEN_422 = {{4'd0}, raw[55:52]}; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [7:0] _lz_T_95 = _GEN_422 & 8'hf; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [7:0] _lz_T_97 = {raw[51:48], 4'h0}; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [7:0] _lz_T_99 = _lz_T_97 & 8'hf0; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [7:0] _lz_T_100 = _lz_T_95 | _lz_T_99; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [7:0] _GEN_423 = {{2'd0}, _lz_T_100[7:2]}; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [7:0] _lz_T_105 = _GEN_423 & 8'h33; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [7:0] _lz_T_107 = {_lz_T_100[5:0], 2'h0}; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [7:0] _lz_T_109 = _lz_T_107 & 8'hcc; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [7:0] _lz_T_110 = _lz_T_105 | _lz_T_109; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [7:0] _GEN_424 = {{1'd0}, _lz_T_110[7:1]}; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [7:0] _lz_T_115 = _GEN_424 & 8'h55; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [7:0] _lz_T_117 = {_lz_T_110[6:0], 1'h0}; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [7:0] _lz_T_119 = _lz_T_117 & 8'haa; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [7:0] _lz_T_120 = _lz_T_115 | _lz_T_119; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [55:0] _lz_T_122 = {_lz_T_49,_lz_T_90,_lz_T_120}; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [5:0] _lz_T_179 = _lz_T_122[54] ? 6'h36 : 6'h37; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_180 = _lz_T_122[53] ? 6'h35 : _lz_T_179; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_181 = _lz_T_122[52] ? 6'h34 : _lz_T_180; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_182 = _lz_T_122[51] ? 6'h33 : _lz_T_181; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_183 = _lz_T_122[50] ? 6'h32 : _lz_T_182; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_184 = _lz_T_122[49] ? 6'h31 : _lz_T_183; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_185 = _lz_T_122[48] ? 6'h30 : _lz_T_184; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_186 = _lz_T_122[47] ? 6'h2f : _lz_T_185; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_187 = _lz_T_122[46] ? 6'h2e : _lz_T_186; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_188 = _lz_T_122[45] ? 6'h2d : _lz_T_187; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_189 = _lz_T_122[44] ? 6'h2c : _lz_T_188; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_190 = _lz_T_122[43] ? 6'h2b : _lz_T_189; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_191 = _lz_T_122[42] ? 6'h2a : _lz_T_190; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_192 = _lz_T_122[41] ? 6'h29 : _lz_T_191; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_193 = _lz_T_122[40] ? 6'h28 : _lz_T_192; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_194 = _lz_T_122[39] ? 6'h27 : _lz_T_193; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_195 = _lz_T_122[38] ? 6'h26 : _lz_T_194; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_196 = _lz_T_122[37] ? 6'h25 : _lz_T_195; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_197 = _lz_T_122[36] ? 6'h24 : _lz_T_196; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_198 = _lz_T_122[35] ? 6'h23 : _lz_T_197; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_199 = _lz_T_122[34] ? 6'h22 : _lz_T_198; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_200 = _lz_T_122[33] ? 6'h21 : _lz_T_199; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_201 = _lz_T_122[32] ? 6'h20 : _lz_T_200; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_202 = _lz_T_122[31] ? 6'h1f : _lz_T_201; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_203 = _lz_T_122[30] ? 6'h1e : _lz_T_202; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_204 = _lz_T_122[29] ? 6'h1d : _lz_T_203; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_205 = _lz_T_122[28] ? 6'h1c : _lz_T_204; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_206 = _lz_T_122[27] ? 6'h1b : _lz_T_205; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_207 = _lz_T_122[26] ? 6'h1a : _lz_T_206; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_208 = _lz_T_122[25] ? 6'h19 : _lz_T_207; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_209 = _lz_T_122[24] ? 6'h18 : _lz_T_208; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_210 = _lz_T_122[23] ? 6'h17 : _lz_T_209; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_211 = _lz_T_122[22] ? 6'h16 : _lz_T_210; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_212 = _lz_T_122[21] ? 6'h15 : _lz_T_211; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_213 = _lz_T_122[20] ? 6'h14 : _lz_T_212; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_214 = _lz_T_122[19] ? 6'h13 : _lz_T_213; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_215 = _lz_T_122[18] ? 6'h12 : _lz_T_214; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_216 = _lz_T_122[17] ? 6'h11 : _lz_T_215; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_217 = _lz_T_122[16] ? 6'h10 : _lz_T_216; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_218 = _lz_T_122[15] ? 6'hf : _lz_T_217; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_219 = _lz_T_122[14] ? 6'he : _lz_T_218; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_220 = _lz_T_122[13] ? 6'hd : _lz_T_219; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_221 = _lz_T_122[12] ? 6'hc : _lz_T_220; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_222 = _lz_T_122[11] ? 6'hb : _lz_T_221; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_223 = _lz_T_122[10] ? 6'ha : _lz_T_222; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_224 = _lz_T_122[9] ? 6'h9 : _lz_T_223; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_225 = _lz_T_122[8] ? 6'h8 : _lz_T_224; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_226 = _lz_T_122[7] ? 6'h7 : _lz_T_225; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_227 = _lz_T_122[6] ? 6'h6 : _lz_T_226; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_228 = _lz_T_122[5] ? 6'h5 : _lz_T_227; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_229 = _lz_T_122[4] ? 6'h4 : _lz_T_228; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_230 = _lz_T_122[3] ? 6'h3 : _lz_T_229; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_231 = _lz_T_122[2] ? 6'h2 : _lz_T_230; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_232 = _lz_T_122[1] ? 6'h1 : _lz_T_231; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] lz = _lz_T_122[0] ? 6'h0 : _lz_T_232; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [118:0] _GEN_3 = {{63'd0}, raw}; // @[src/main/scala/rv32i/Fpu.scala 317:19]
  wire [118:0] _nSig_T = _GEN_3 << lz; // @[src/main/scala/rv32i/Fpu.scala 317:19]
  wire [12:0] _nExp_T_2 = $signed(rawE) + 13'sh37; // @[src/main/scala/rv32i/Fpu.scala 318:19]
  wire [6:0] _nExp_T_3 = {1'b0,$signed(lz)}; // @[src/main/scala/rv32i/Fpu.scala 318:32]
  wire [12:0] _nExp_T_4 = {{6{_nExp_T_3[6]}},_nExp_T_3}; // @[src/main/scala/rv32i/Fpu.scala 318:40]
  wire [12:0] _nExp_T_7 = $signed(_nExp_T_2) - $signed(_nExp_T_4); // @[src/main/scala/rv32i/Fpu.scala 318:27]
  wire [3:0] _GEN_362 = state == 4'h6 ? 4'h7 : _GEN_359; // @[src/main/scala/rv32i/Fpu.scala 315:25 319:11]
  wire [23:0] keep = nSig[55:32]; // @[src/main/scala/rv32i/Fpu.scala 325:20]
  wire  rb_1 = nSig[31]; // @[src/main/scala/rv32i/Fpu.scala 326:20]
  wire  st = |nSig[30:0] | sticky; // @[src/main/scala/rv32i/Fpu.scala 327:32]
  wire  _k25_T_2 = rb_1 & (st | keep[0]); // @[src/main/scala/rv32i/Fpu.scala 147:20]
  wire  _k25_T_3 = rb_1 | st; // @[src/main/scala/rv32i/Fpu.scala 149:29]
  wire  _k25_T_4 = rSign & (rb_1 | st); // @[src/main/scala/rv32i/Fpu.scala 149:23]
  wire  _k25_T_5 = ~rSign; // @[src/main/scala/rv32i/Fpu.scala 150:18]
  wire  _k25_T_7 = ~rSign & _k25_T_3; // @[src/main/scala/rv32i/Fpu.scala 150:24]
  wire  _k25_T_10 = 3'h1 == rm; // @[src/main/scala/rv32i/Fpu.scala 146:88]
  wire  _k25_T_11 = 3'h1 == rm ? 1'h0 : 3'h0 == rm & _k25_T_2; // @[src/main/scala/rv32i/Fpu.scala 146:88]
  wire  _k25_T_12 = 3'h2 == rm; // @[src/main/scala/rv32i/Fpu.scala 146:88]
  wire  _k25_T_13 = 3'h2 == rm ? _k25_T_4 : _k25_T_11; // @[src/main/scala/rv32i/Fpu.scala 146:88]
  wire  _k25_T_14 = 3'h3 == rm; // @[src/main/scala/rv32i/Fpu.scala 146:88]
  wire  _k25_T_15 = 3'h3 == rm ? _k25_T_7 : _k25_T_13; // @[src/main/scala/rv32i/Fpu.scala 146:88]
  wire  _k25_T_17 = 3'h4 == rm ? rb_1 : _k25_T_15; // @[src/main/scala/rv32i/Fpu.scala 146:88]
  wire [23:0] _GEN_425 = {{23'd0}, _k25_T_17}; // @[src/main/scala/rv32i/Fpu.scala 328:21]
  wire [24:0] k25 = keep + _GEN_425; // @[src/main/scala/rv32i/Fpu.scala 328:21]
  wire  carry = k25[24]; // @[src/main/scala/rv32i/Fpu.scala 329:20]
  wire [12:0] _eU_T = carry ? $signed(13'sh1) : $signed(13'sh0); // @[src/main/scala/rv32i/Fpu.scala 330:26]
  wire [12:0] eU = $signed(nExp) + $signed(_eU_T); // @[src/main/scala/rv32i/Fpu.scala 330:21]
  wire  tiny = $signed(eU) < -13'sh7e; // @[src/main/scala/rv32i/Fpu.scala 331:19]
  wire  _toInf_T_2 = _k25_T_10 ? 1'h0 : 1'h1; // @[src/main/scala/rv32i/Fpu.scala 333:38]
  wire  _toInf_T_4 = _k25_T_12 ? rSign : _toInf_T_2; // @[src/main/scala/rv32i/Fpu.scala 333:38]
  wire  toInf = _k25_T_14 ? _k25_T_5 : _toInf_T_4; // @[src/main/scala/rv32i/Fpu.scala 333:38]
  wire [30:0] _ovBits_T = toInf ? 31'h7f800000 : 31'h7f7fffff; // @[src/main/scala/rv32i/Fpu.scala 334:32]
  wire [31:0] ovBits = {rSign,_ovBits_T}; // @[src/main/scala/rv32i/Fpu.scala 334:21]
  wire [12:0] biased = $signed(eU) + 13'sh7f; // @[src/main/scala/rv32i/Fpu.scala 336:23]
  wire [12:0] _T_68 = $signed(eU) + 13'sh7f; // @[src/main/scala/rv32i/Fpu.scala 340:36]
  wire [22:0] _T_71 = carry ? 23'h0 : k25[22:0]; // @[src/main/scala/rv32i/Fpu.scala 340:53]
  wire [31:0] _T_72 = {rSign,_T_68[7:0],_T_71}; // @[src/main/scala/rv32i/Fpu.scala 340:21]
  wire [4:0] _T_73 = _k25_T_3 ? 5'h1 : 5'h0; // @[src/main/scala/rv32i/Fpu.scala 340:89]
  wire [12:0] sh = -13'sh7e - $signed(nExp); // @[src/main/scala/rv32i/Fpu.scala 344:34]
  wire [4:0] shC = sh > 13'h1f ? 5'h1f : sh[4:0]; // @[src/main/scala/rv32i/Fpu.scala 345:20]
  wire [87:0] _lostS_T = 88'h1 << shC; // @[src/main/scala/rv32i/Fpu.scala 346:39]
  wire [87:0] _lostS_T_2 = _lostS_T - 88'h1; // @[src/main/scala/rv32i/Fpu.scala 346:47]
  wire [55:0] _lostS_T_4 = nSig & _lostS_T_2[55:0]; // @[src/main/scala/rv32i/Fpu.scala 346:25]
  wire  lostS = |_lostS_T_4; // @[src/main/scala/rv32i/Fpu.scala 346:62]
  wire [55:0] shifted = nSig >> shC; // @[src/main/scala/rv32i/Fpu.scala 347:26]
  wire [23:0] sKeep = shifted[55:32]; // @[src/main/scala/rv32i/Fpu.scala 348:26]
  wire  sRb = shifted[31]; // @[src/main/scala/rv32i/Fpu.scala 349:26]
  wire  sSt = |shifted[30:0] | lostS | sticky; // @[src/main/scala/rv32i/Fpu.scala 350:47]
  wire  _q_T_4 = sRb & (sSt | sKeep[0]); // @[src/main/scala/rv32i/Fpu.scala 147:20]
  wire  _q_T_5 = sRb | sSt; // @[src/main/scala/rv32i/Fpu.scala 149:29]
  wire  _q_T_6 = rSign & (sRb | sSt); // @[src/main/scala/rv32i/Fpu.scala 149:23]
  wire  _q_T_9 = ~rSign & _q_T_5; // @[src/main/scala/rv32i/Fpu.scala 150:24]
  wire  _q_T_13 = 3'h1 == rm ? 1'h0 : 3'h0 == rm & _q_T_4; // @[src/main/scala/rv32i/Fpu.scala 146:88]
  wire  _q_T_15 = 3'h2 == rm ? _q_T_6 : _q_T_13; // @[src/main/scala/rv32i/Fpu.scala 146:88]
  wire  _q_T_17 = 3'h3 == rm ? _q_T_9 : _q_T_15; // @[src/main/scala/rv32i/Fpu.scala 146:88]
  wire  _q_T_19 = 3'h4 == rm ? sRb : _q_T_17; // @[src/main/scala/rv32i/Fpu.scala 146:88]
  wire [23:0] _GEN_426 = {{23'd0}, _q_T_19}; // @[src/main/scala/rv32i/Fpu.scala 351:25]
  wire [24:0] q_2 = sKeep + _GEN_426; // @[src/main/scala/rv32i/Fpu.scala 351:25]
  wire [30:0] _T_74 = {{6'd0}, q_2}; // @[src/main/scala/rv32i/Fpu.scala 353:30]
  wire [31:0] _T_76 = {rSign,_T_74}; // @[src/main/scala/rv32i/Fpu.scala 353:17]
  wire [4:0] _T_77 = _q_T_5 ? 5'h1 : 5'h0; // @[src/main/scala/rv32i/Fpu.scala 354:12]
  wire [4:0] _T_79 = tiny & _q_T_5 ? 5'h2 : 5'h0; // @[src/main/scala/rv32i/Fpu.scala 354:49]
  wire [4:0] _T_80 = _T_77 | _T_79; // @[src/main/scala/rv32i/Fpu.scala 354:44]
  wire [3:0] _GEN_371 = state == 4'h7 ? 4'h9 : _GEN_362; // @[src/main/scala/rv32i/Fpu.scala 323:26]
  wire [31:0] _T_82 = _isToInt_T ? 32'h7fffffff : 32'hffffffff; // @[src/main/scala/rv32i/Fpu.scala 363:29]
  wire [31:0] _T_83 = _isToInt_T ? 32'h80000000 : 32'h0; // @[src/main/scala/rv32i/Fpu.scala 364:43]
  wire  huge = $signed(A_exp) >= 13'sh21; // @[src/main/scala/rv32i/Fpu.scala 368:22]
  wire  left = $signed(A_exp) >= 13'sh17; // @[src/main/scala/rv32i/Fpu.scala 369:22]
  wire [12:0] _magL_T_3 = $signed(A_exp) - 13'sh17; // @[src/main/scala/rv32i/Fpu.scala 370:42]
  wire [38:0] _GEN_4 = {{15'd0}, A_sig}; // @[src/main/scala/rv32i/Fpu.scala 370:27]
  wire [38:0] _magL_T_5 = _GEN_4 << _magL_T_3[3:0]; // @[src/main/scala/rv32i/Fpu.scala 370:27]
  wire [33:0] magL = _magL_T_5[33:0]; // @[src/main/scala/rv32i/Fpu.scala 370:55]
  wire [12:0] rsh = 13'sh17 - $signed(A_exp); // @[src/main/scala/rv32i/Fpu.scala 371:32]
  wire [4:0] rshC = rsh > 13'h19 ? 5'h19 : rsh[4:0]; // @[src/main/scala/rv32i/Fpu.scala 372:23]
  wire [49:0] _ext_T = {A_sig,26'h0}; // @[src/main/scala/rv32i/Fpu.scala 373:23]
  wire [49:0] ext = _ext_T >> rshC; // @[src/main/scala/rv32i/Fpu.scala 373:42]
  wire [23:0] kept = ext[49:26]; // @[src/main/scala/rv32i/Fpu.scala 374:23]
  wire  rbit = ext[25]; // @[src/main/scala/rv32i/Fpu.scala 375:23]
  wire  stl = |ext[24:0]; // @[src/main/scala/rv32i/Fpu.scala 376:31]
  wire  _magR_T_2 = rbit & (stl | kept[0]); // @[src/main/scala/rv32i/Fpu.scala 147:20]
  wire  _magR_T_3 = rbit | stl; // @[src/main/scala/rv32i/Fpu.scala 149:29]
  wire  _magR_T_4 = A_sign & (rbit | stl); // @[src/main/scala/rv32i/Fpu.scala 149:23]
  wire  _magR_T_7 = ~A_sign & _magR_T_3; // @[src/main/scala/rv32i/Fpu.scala 150:24]
  wire  _magR_T_11 = 3'h1 == rm ? 1'h0 : 3'h0 == rm & _magR_T_2; // @[src/main/scala/rv32i/Fpu.scala 146:88]
  wire  _magR_T_13 = 3'h2 == rm ? _magR_T_4 : _magR_T_11; // @[src/main/scala/rv32i/Fpu.scala 146:88]
  wire  _magR_T_15 = 3'h3 == rm ? _magR_T_7 : _magR_T_13; // @[src/main/scala/rv32i/Fpu.scala 146:88]
  wire  _magR_T_17 = 3'h4 == rm ? rbit : _magR_T_15; // @[src/main/scala/rv32i/Fpu.scala 146:88]
  wire [23:0] _GEN_427 = {{23'd0}, _magR_T_17}; // @[src/main/scala/rv32i/Fpu.scala 377:25]
  wire [24:0] magR = kept + _GEN_427; // @[src/main/scala/rv32i/Fpu.scala 377:25]
  wire [33:0] _mag_T_2 = {{9'd0}, magR}; // @[src/main/scala/rv32i/Fpu.scala 378:44]
  wire [33:0] mag_1 = left ? magL : _mag_T_2; // @[src/main/scala/rv32i/Fpu.scala 378:23]
  wire  inexact_2 = ~left & _magR_T_3; // @[src/main/scala/rv32i/Fpu.scala 379:29]
  wire  _nv_T_2 = A_sign ? mag_1 > 34'h80000000 : mag_1 > 34'h7fffffff; // @[src/main/scala/rv32i/Fpu.scala 380:41]
  wire  _nv_T_5 = A_sign ? mag_1 != 34'h0 : mag_1 > 34'hffffffff; // @[src/main/scala/rv32i/Fpu.scala 381:41]
  wire  _nv_T_6 = _isToInt_T ? _nv_T_2 : _nv_T_5; // @[src/main/scala/rv32i/Fpu.scala 380:29]
  wire  nv = huge | _nv_T_6; // @[src/main/scala/rv32i/Fpu.scala 380:23]
  wire [31:0] _sat_T = A_sign ? 32'h80000000 : 32'h7fffffff; // @[src/main/scala/rv32i/Fpu.scala 382:34]
  wire [31:0] _sat_T_1 = A_sign ? 32'h0 : 32'hffffffff; // @[src/main/scala/rv32i/Fpu.scala 382:54]
  wire [31:0] sat = _isToInt_T ? _sat_T : _sat_T_1; // @[src/main/scala/rv32i/Fpu.scala 382:22]
  wire [33:0] _value_T_1 = 34'h0 - mag_1; // @[src/main/scala/rv32i/Fpu.scala 383:39]
  wire [31:0] value = A_sign ? _value_T_1[31:0] : mag_1[31:0]; // @[src/main/scala/rv32i/Fpu.scala 383:24]
  wire [31:0] _T_86 = nv ? sat : value; // @[src/main/scala/rv32i/Fpu.scala 384:19]
  wire [4:0] _T_87 = inexact_2 ? 5'h1 : 5'h0; // @[src/main/scala/rv32i/Fpu.scala 384:65]
  wire [4:0] _T_88 = nv ? 5'h10 : _T_87; // @[src/main/scala/rv32i/Fpu.scala 384:40]
  assign io_req_ready = state == 4'h0; // @[src/main/scala/rv32i/Fpu.scala 117:26]
  assign io_resp_valid = state == 4'h9; // @[src/main/scala/rv32i/Fpu.scala 119:26]
  assign io_resp_bits_bits = resBits; // @[src/main/scala/rv32i/Fpu.scala 391:22]
  assign io_resp_bits_flags = resFlags; // @[src/main/scala/rv32i/Fpu.scala 392:22]
  assign io_busy = state != 4'h0; // @[src/main/scala/rv32i/Fpu.scala 118:26]
  always @(posedge clock) begin
    if (reset) begin // @[src/main/scala/rv32i/Fpu.scala 109:22]
      state <= 4'h0; // @[src/main/scala/rv32i/Fpu.scala 109:22]
    end else if (io_kill) begin // @[src/main/scala/rv32i/Fpu.scala 389:17]
      state <= 4'h0; // @[src/main/scala/rv32i/Fpu.scala 389:25]
    end else if (_io_resp_valid_T) begin // @[src/main/scala/rv32i/Fpu.scala 388:25]
      state <= 4'h0; // @[src/main/scala/rv32i/Fpu.scala 388:33]
    end else if (state == 4'h8) begin // @[src/main/scala/rv32i/Fpu.scala 359:26]
      state <= 4'h9;
    end else begin
      state <= _GEN_371;
    end
    if (_T) begin // @[src/main/scala/rv32i/Fpu.scala 121:21]
      op <= io_req_bits_op; // @[src/main/scala/rv32i/Fpu.scala 122:8]
    end
    if (_T) begin // @[src/main/scala/rv32i/Fpu.scala 121:21]
      rm <= io_req_bits_rm; // @[src/main/scala/rv32i/Fpu.scala 122:30]
    end
    if (_T) begin // @[src/main/scala/rv32i/Fpu.scala 121:21]
      ra <= io_req_bits_a; // @[src/main/scala/rv32i/Fpu.scala 123:8]
    end
    if (_T) begin // @[src/main/scala/rv32i/Fpu.scala 121:21]
      rb <= io_req_bits_b; // @[src/main/scala/rv32i/Fpu.scala 123:29]
    end
    if (_T) begin // @[src/main/scala/rv32i/Fpu.scala 121:21]
      rc <= io_req_bits_c; // @[src/main/scala/rv32i/Fpu.scala 123:50]
    end
    if (state == 4'h1) begin // @[src/main/scala/rv32i/Fpu.scala 178:27]
      if (isAddSub) begin // @[src/main/scala/rv32i/Fpu.scala 180:20]
        if (!(A_nan | B_nan)) begin // @[src/main/scala/rv32i/Fpu.scala 182:28]
          if (!(A_inf & B_inf)) begin // @[src/main/scala/rv32i/Fpu.scala 183:35]
            xSign <= _GEN_31;
          end
        end
      end else if (isMul | isFma) begin // @[src/main/scala/rv32i/Fpu.scala 192:32]
        if (!(infTimesZero)) begin // @[src/main/scala/rv32i/Fpu.scala 196:26]
          xSign <= _GEN_113;
        end
      end
    end
    if (state == 4'h1) begin // @[src/main/scala/rv32i/Fpu.scala 178:27]
      if (isAddSub) begin // @[src/main/scala/rv32i/Fpu.scala 180:20]
        if (!(A_nan | B_nan)) begin // @[src/main/scala/rv32i/Fpu.scala 182:28]
          if (!(A_inf & B_inf)) begin // @[src/main/scala/rv32i/Fpu.scala 183:35]
            xZero <= _GEN_32;
          end
        end
      end else if (isMul | isFma) begin // @[src/main/scala/rv32i/Fpu.scala 192:32]
        if (!(infTimesZero)) begin // @[src/main/scala/rv32i/Fpu.scala 196:26]
          xZero <= _GEN_114;
        end
      end
    end
    if (state == 4'h1) begin // @[src/main/scala/rv32i/Fpu.scala 178:27]
      if (isAddSub) begin // @[src/main/scala/rv32i/Fpu.scala 180:20]
        if (!(A_nan | B_nan)) begin // @[src/main/scala/rv32i/Fpu.scala 182:28]
          if (!(A_inf & B_inf)) begin // @[src/main/scala/rv32i/Fpu.scala 183:35]
            xSig <= _GEN_33;
          end
        end
      end
    end
    if (state == 4'h1) begin // @[src/main/scala/rv32i/Fpu.scala 178:27]
      if (isAddSub) begin // @[src/main/scala/rv32i/Fpu.scala 180:20]
        if (!(A_nan | B_nan)) begin // @[src/main/scala/rv32i/Fpu.scala 182:28]
          if (!(A_inf & B_inf)) begin // @[src/main/scala/rv32i/Fpu.scala 183:35]
            xExp <= _GEN_34;
          end
        end
      end else if (isMul | isFma) begin // @[src/main/scala/rv32i/Fpu.scala 192:32]
        if (!(infTimesZero)) begin // @[src/main/scala/rv32i/Fpu.scala 196:26]
          xExp <= _GEN_115;
        end
      end
    end
    if (state == 4'h1) begin // @[src/main/scala/rv32i/Fpu.scala 178:27]
      if (isAddSub) begin // @[src/main/scala/rv32i/Fpu.scala 180:20]
        if (!(A_nan | B_nan)) begin // @[src/main/scala/rv32i/Fpu.scala 182:28]
          if (!(A_inf & B_inf)) begin // @[src/main/scala/rv32i/Fpu.scala 183:35]
            ySign <= _GEN_35;
          end
        end
      end else if (isMul | isFma) begin // @[src/main/scala/rv32i/Fpu.scala 192:32]
        if (!(infTimesZero)) begin // @[src/main/scala/rv32i/Fpu.scala 196:26]
          ySign <= _GEN_116;
        end
      end
    end
    if (state == 4'h1) begin // @[src/main/scala/rv32i/Fpu.scala 178:27]
      if (isAddSub) begin // @[src/main/scala/rv32i/Fpu.scala 180:20]
        if (!(A_nan | B_nan)) begin // @[src/main/scala/rv32i/Fpu.scala 182:28]
          if (!(A_inf & B_inf)) begin // @[src/main/scala/rv32i/Fpu.scala 183:35]
            yZero <= _GEN_36;
          end
        end
      end else if (isMul | isFma) begin // @[src/main/scala/rv32i/Fpu.scala 192:32]
        if (!(infTimesZero)) begin // @[src/main/scala/rv32i/Fpu.scala 196:26]
          yZero <= _GEN_117;
        end
      end
    end
    if (state == 4'h1) begin // @[src/main/scala/rv32i/Fpu.scala 178:27]
      if (isAddSub) begin // @[src/main/scala/rv32i/Fpu.scala 180:20]
        if (!(A_nan | B_nan)) begin // @[src/main/scala/rv32i/Fpu.scala 182:28]
          if (!(A_inf & B_inf)) begin // @[src/main/scala/rv32i/Fpu.scala 183:35]
            ySig <= _GEN_37;
          end
        end
      end else if (isMul | isFma) begin // @[src/main/scala/rv32i/Fpu.scala 192:32]
        if (!(infTimesZero)) begin // @[src/main/scala/rv32i/Fpu.scala 196:26]
          ySig <= _GEN_118;
        end
      end
    end
    if (state == 4'h1) begin // @[src/main/scala/rv32i/Fpu.scala 178:27]
      if (isAddSub) begin // @[src/main/scala/rv32i/Fpu.scala 180:20]
        if (!(A_nan | B_nan)) begin // @[src/main/scala/rv32i/Fpu.scala 182:28]
          if (!(A_inf & B_inf)) begin // @[src/main/scala/rv32i/Fpu.scala 183:35]
            yExp <= _GEN_38;
          end
        end
      end else if (isMul | isFma) begin // @[src/main/scala/rv32i/Fpu.scala 192:32]
        if (!(infTimesZero)) begin // @[src/main/scala/rv32i/Fpu.scala 196:26]
          yExp <= _GEN_119;
        end
      end
    end
    if (state == 4'h2) begin // @[src/main/scala/rv32i/Fpu.scala 254:24]
      acc <= _acc_T_3; // @[src/main/scala/rv32i/Fpu.scala 255:12]
    end else if (state == 4'h1) begin // @[src/main/scala/rv32i/Fpu.scala 178:27]
      if (!(isAddSub)) begin // @[src/main/scala/rv32i/Fpu.scala 180:20]
        if (isMul | isFma) begin // @[src/main/scala/rv32i/Fpu.scala 192:32]
          acc <= _GEN_123;
        end
      end
    end
    mcand <= _GEN_325[47:0];
    if (state == 4'h2) begin // @[src/main/scala/rv32i/Fpu.scala 254:24]
      mplier <= {{1'd0}, mplier[23:1]}; // @[src/main/scala/rv32i/Fpu.scala 257:12]
    end else if (state == 4'h1) begin // @[src/main/scala/rv32i/Fpu.scala 178:27]
      if (!(isAddSub)) begin // @[src/main/scala/rv32i/Fpu.scala 180:20]
        if (isMul | isFma) begin // @[src/main/scala/rv32i/Fpu.scala 192:32]
          mplier <= _GEN_125;
        end
      end
    end
    if (state == 4'h5) begin // @[src/main/scala/rv32i/Fpu.scala 301:25]
      count <= _count_T_1; // @[src/main/scala/rv32i/Fpu.scala 310:14]
    end else if (state == 4'h4) begin // @[src/main/scala/rv32i/Fpu.scala 290:24]
      count <= _count_T_1; // @[src/main/scala/rv32i/Fpu.scala 296:11]
    end else if (state == 4'h2) begin // @[src/main/scala/rv32i/Fpu.scala 254:24]
      count <= _count_T_1; // @[src/main/scala/rv32i/Fpu.scala 258:12]
    end else if (state == 4'h1) begin // @[src/main/scala/rv32i/Fpu.scala 178:27]
      count <= _GEN_292;
    end
    rem <= _GEN_353[30:0];
    if (state == 4'h5) begin // @[src/main/scala/rv32i/Fpu.scala 301:25]
      quo <= q_1; // @[src/main/scala/rv32i/Fpu.scala 308:14]
    end else if (state == 4'h4) begin // @[src/main/scala/rv32i/Fpu.scala 290:24]
      quo <= q; // @[src/main/scala/rv32i/Fpu.scala 294:11]
    end else if (state == 4'h1) begin // @[src/main/scala/rv32i/Fpu.scala 178:27]
      if (!(isAddSub)) begin // @[src/main/scala/rv32i/Fpu.scala 180:20]
        quo <= _GEN_273;
      end
    end
    if (state == 4'h1) begin // @[src/main/scala/rv32i/Fpu.scala 178:27]
      if (!(isAddSub)) begin // @[src/main/scala/rv32i/Fpu.scala 180:20]
        if (!(isMul | isFma)) begin // @[src/main/scala/rv32i/Fpu.scala 192:32]
          if (isDiv) begin // @[src/main/scala/rv32i/Fpu.scala 213:23]
            divisor <= _GEN_183;
          end
        end
      end
    end
    radicand <= _GEN_355[53:0];
    if (state == 4'h5) begin // @[src/main/scala/rv32i/Fpu.scala 301:25]
      if (_T_61) begin // @[src/main/scala/rv32i/Fpu.scala 311:26]
        raw <= {{29'd0}, q_1}; // @[src/main/scala/rv32i/Fpu.scala 311:32]
      end else begin
        raw <= _GEN_347;
      end
    end else begin
      raw <= _GEN_347;
    end
    if (state == 4'h3) begin // @[src/main/scala/rv32i/Fpu.scala 263:24]
      if (sum == 52'h0) begin // @[src/main/scala/rv32i/Fpu.scala 282:23]
        rawE <= _GEN_320;
      end else begin
        rawE <= _rawE_T_12; // @[src/main/scala/rv32i/Fpu.scala 284:26]
      end
    end else begin
      rawE <= _GEN_320;
    end
    if (state == 4'h5) begin // @[src/main/scala/rv32i/Fpu.scala 301:25]
      if (_T_61) begin // @[src/main/scala/rv32i/Fpu.scala 311:26]
        sticky <= remNext != 31'h0; // @[src/main/scala/rv32i/Fpu.scala 311:45]
      end else begin
        sticky <= _GEN_348;
      end
    end else begin
      sticky <= _GEN_348;
    end
    if (state == 4'h3) begin // @[src/main/scala/rv32i/Fpu.scala 263:24]
      if (sum == 52'h0) begin // @[src/main/scala/rv32i/Fpu.scala 282:23]
        rSign <= _GEN_319;
      end else if (xBig) begin // @[src/main/scala/rv32i/Fpu.scala 270:23]
        rSign <= xSign;
      end else begin
        rSign <= ySign;
      end
    end else begin
      rSign <= _GEN_319;
    end
    if (state == 4'h6) begin // @[src/main/scala/rv32i/Fpu.scala 315:25]
      nSig <= _nSig_T[55:0]; // @[src/main/scala/rv32i/Fpu.scala 317:11]
    end
    if (state == 4'h6) begin // @[src/main/scala/rv32i/Fpu.scala 315:25]
      nExp <= _nExp_T_7; // @[src/main/scala/rv32i/Fpu.scala 318:11]
    end
    if (state == 4'h8) begin // @[src/main/scala/rv32i/Fpu.scala 359:26]
      if (A_nan) begin // @[src/main/scala/rv32i/Fpu.scala 363:17]
        resBits <= _T_82; // @[src/main/scala/rv32i/Fpu.scala 174:57]
      end else if (A_inf) begin // @[src/main/scala/rv32i/Fpu.scala 364:24]
        if (A_sign) begin // @[src/main/scala/rv32i/Fpu.scala 364:36]
          resBits <= _T_83;
        end else begin
          resBits <= _T_82;
        end
      end else if (A_zero) begin // @[src/main/scala/rv32i/Fpu.scala 365:25]
        resBits <= 32'h0; // @[src/main/scala/rv32i/Fpu.scala 174:57]
      end else begin
        resBits <= _T_86; // @[src/main/scala/rv32i/Fpu.scala 174:57]
      end
    end else if (state == 4'h7) begin // @[src/main/scala/rv32i/Fpu.scala 323:26]
      if ($signed(nExp) >= -13'sh7e) begin // @[src/main/scala/rv32i/Fpu.scala 335:27]
        if ($signed(biased) >= 13'shff) begin // @[src/main/scala/rv32i/Fpu.scala 338:30]
          resBits <= ovBits; // @[src/main/scala/rv32i/Fpu.scala 174:57]
        end else begin
          resBits <= _T_72; // @[src/main/scala/rv32i/Fpu.scala 174:57]
        end
      end else begin
        resBits <= _T_76; // @[src/main/scala/rv32i/Fpu.scala 174:57]
      end
    end else if (state == 4'h3) begin // @[src/main/scala/rv32i/Fpu.scala 263:24]
      if (sum == 52'h0) begin // @[src/main/scala/rv32i/Fpu.scala 282:23]
        resBits <= _T_59; // @[src/main/scala/rv32i/Fpu.scala 174:57]
      end else begin
        resBits <= _GEN_301;
      end
    end else begin
      resBits <= _GEN_301;
    end
    if (state == 4'h8) begin // @[src/main/scala/rv32i/Fpu.scala 359:26]
      if (A_nan) begin // @[src/main/scala/rv32i/Fpu.scala 363:17]
        resFlags <= 5'h10; // @[src/main/scala/rv32i/Fpu.scala 174:75]
      end else if (A_inf) begin // @[src/main/scala/rv32i/Fpu.scala 364:24]
        resFlags <= 5'h10; // @[src/main/scala/rv32i/Fpu.scala 174:75]
      end else if (A_zero) begin // @[src/main/scala/rv32i/Fpu.scala 365:25]
        resFlags <= 5'h0; // @[src/main/scala/rv32i/Fpu.scala 174:75]
      end else begin
        resFlags <= _T_88; // @[src/main/scala/rv32i/Fpu.scala 174:75]
      end
    end else if (state == 4'h7) begin // @[src/main/scala/rv32i/Fpu.scala 323:26]
      if ($signed(nExp) >= -13'sh7e) begin // @[src/main/scala/rv32i/Fpu.scala 335:27]
        if ($signed(biased) >= 13'shff) begin // @[src/main/scala/rv32i/Fpu.scala 338:30]
          resFlags <= 5'h5; // @[src/main/scala/rv32i/Fpu.scala 174:75]
        end else begin
          resFlags <= _T_73; // @[src/main/scala/rv32i/Fpu.scala 174:75]
        end
      end else begin
        resFlags <= _T_80; // @[src/main/scala/rv32i/Fpu.scala 174:75]
      end
    end else if (state == 4'h3) begin // @[src/main/scala/rv32i/Fpu.scala 263:24]
      if (sum == 52'h0) begin // @[src/main/scala/rv32i/Fpu.scala 282:23]
        resFlags <= 5'h0; // @[src/main/scala/rv32i/Fpu.scala 174:75]
      end else begin
        resFlags <= _GEN_302;
      end
    end else begin
      resFlags <= _GEN_302;
    end
  end
// Register and memory initialization
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif
`ifndef RANDOM
`define RANDOM $random
`endif
`ifdef RANDOMIZE_MEM_INIT
  integer initvar;
`endif
`ifndef SYNTHESIS
`ifdef FIRRTL_BEFORE_INITIAL
`FIRRTL_BEFORE_INITIAL
`endif
initial begin
  `ifdef RANDOMIZE
    `ifdef INIT_RANDOM
      `INIT_RANDOM
    `endif
    `ifndef VERILATOR
      `ifdef RANDOMIZE_DELAY
        #`RANDOMIZE_DELAY begin end
      `else
        #0.002 begin end
      `endif
    `endif
`ifdef RANDOMIZE_REG_INIT
  _RAND_0 = {1{`RANDOM}};
  state = _RAND_0[3:0];
  _RAND_1 = {1{`RANDOM}};
  op = _RAND_1[3:0];
  _RAND_2 = {1{`RANDOM}};
  rm = _RAND_2[2:0];
  _RAND_3 = {1{`RANDOM}};
  ra = _RAND_3[31:0];
  _RAND_4 = {1{`RANDOM}};
  rb = _RAND_4[31:0];
  _RAND_5 = {1{`RANDOM}};
  rc = _RAND_5[31:0];
  _RAND_6 = {1{`RANDOM}};
  xSign = _RAND_6[0:0];
  _RAND_7 = {1{`RANDOM}};
  xZero = _RAND_7[0:0];
  _RAND_8 = {2{`RANDOM}};
  xSig = _RAND_8[47:0];
  _RAND_9 = {1{`RANDOM}};
  xExp = _RAND_9[12:0];
  _RAND_10 = {1{`RANDOM}};
  ySign = _RAND_10[0:0];
  _RAND_11 = {1{`RANDOM}};
  yZero = _RAND_11[0:0];
  _RAND_12 = {2{`RANDOM}};
  ySig = _RAND_12[47:0];
  _RAND_13 = {1{`RANDOM}};
  yExp = _RAND_13[12:0];
  _RAND_14 = {2{`RANDOM}};
  acc = _RAND_14[47:0];
  _RAND_15 = {2{`RANDOM}};
  mcand = _RAND_15[47:0];
  _RAND_16 = {1{`RANDOM}};
  mplier = _RAND_16[23:0];
  _RAND_17 = {1{`RANDOM}};
  count = _RAND_17[4:0];
  _RAND_18 = {1{`RANDOM}};
  rem = _RAND_18[30:0];
  _RAND_19 = {1{`RANDOM}};
  quo = _RAND_19[26:0];
  _RAND_20 = {1{`RANDOM}};
  divisor = _RAND_20[23:0];
  _RAND_21 = {2{`RANDOM}};
  radicand = _RAND_21[53:0];
  _RAND_22 = {2{`RANDOM}};
  raw = _RAND_22[55:0];
  _RAND_23 = {1{`RANDOM}};
  rawE = _RAND_23[12:0];
  _RAND_24 = {1{`RANDOM}};
  sticky = _RAND_24[0:0];
  _RAND_25 = {1{`RANDOM}};
  rSign = _RAND_25[0:0];
  _RAND_26 = {2{`RANDOM}};
  nSig = _RAND_26[55:0];
  _RAND_27 = {1{`RANDOM}};
  nExp = _RAND_27[12:0];
  _RAND_28 = {1{`RANDOM}};
  resBits = _RAND_28[31:0];
  _RAND_29 = {1{`RANDOM}};
  resFlags = _RAND_29[4:0];
`endif // RANDOMIZE_REG_INIT
  `endif // RANDOMIZE
end // initial
`ifdef FIRRTL_AFTER_INITIAL
`FIRRTL_AFTER_INITIAL
`endif
`endif // SYNTHESIS
endmodule
