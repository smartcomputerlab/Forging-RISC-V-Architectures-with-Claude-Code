#!/usr/bin/env python3
"""GTKWave translate filter *process* for IEEE 754 single-precision (binary32) values.

GTKWave writes one value per line on stdin (as the trace is formatted, e.g. hex "BFD55555") and reads one line of
text per value on stdout. Use it on any 32-bit float signal (f registers, FPU operands and results):
right-click the trace -> Data Format -> Translate Filter Process -> Enable and Select -> this file
(make it executable first: chmod +x tools/f32_filter.py).
"""
import struct
import sys


def text(bits):
    s, e, f = bits >> 31, (bits >> 23) & 0xff, bits & 0x7fffff
    if e == 0xff:
        return ("-inf" if s else "+inf") if f == 0 else ("qNaN" if f & 0x400000 else "sNaN")
    if bits == 0x80000000:
        return "-0.0"
    v = struct.unpack(">f", struct.pack(">I", bits))[0]
    return f"{v:.9g}" + (" (subnormal)" if e == 0 and f else "")


for line in sys.stdin:
    t = line.strip()
    try:
        out = text(int(t, 16) & 0xffffffff)
    except ValueError:
        out = t
    sys.stdout.write(out + "\n")
    sys.stdout.flush()
