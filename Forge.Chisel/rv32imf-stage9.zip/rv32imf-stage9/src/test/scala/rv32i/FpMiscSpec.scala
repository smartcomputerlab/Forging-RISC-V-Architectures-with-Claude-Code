package rv32i

import chisel3._
import chiseltest._
import org.scalatest.flatspec.AnyFlatSpec
import org.scalatest.matchers.should.Matchers
import scala.util.Random

/** The single-cycle FP unit (sign injection, min/max, compares, class) against the reference FpRef. */
class FpMiscSpec extends AnyFlatSpec with ChiselScalatestTester with Matchers {
  "FpMisc" should "match the reference on 20,000 random and special operand pairs" in {
    test(new FpMisc) { c =>
      val r = new Random(41)
      for (_ <- 0 until 20000) {
        val a = FpGen.randF(r); val b = if (r.nextInt(8) == 0) a else FpGen.randF(r)
        c.io.a.poke(a.U(32.W)); c.io.b.poke(b.U(32.W))
        def chk(op: Int, f3: Int, exp: (Long, Int)): Unit = {
          c.io.op.poke(op.U); c.io.funct3.poke(f3.U)
          withClue(f"op $op funct3 $f3 a=0x$a%08x b=0x$b%08x: ") {
            c.io.result.peek().litValue.toLong shouldBe exp._1
            c.io.flags.peek().litValue.toInt shouldBe exp._2
          }
        }
        for (k <- 0 to 2) chk(FpMiscOp.SGNJ, k, (FpRef.sgnj(a, b, k), 0))
        chk(FpMiscOp.MINMAX, 0, FpRef.min(a, b)); chk(FpMiscOp.MINMAX, 1, FpRef.max(a, b))
        chk(FpMiscOp.CMP, 2, FpRef.feq(a, b)); chk(FpMiscOp.CMP, 1, FpRef.flt(a, b)); chk(FpMiscOp.CMP, 0, FpRef.fle(a, b))
        chk(FpMiscOp.CLASS, 0, (FpRef.fclass(a), 0))
      }
    }
  }
}
