package rv32i

import chisel3._
import chiseltest._
import org.scalatest.flatspec.AnyFlatSpec
import java.nio.file.{Files, Paths}

class MemorySpec extends AnyFlatSpec with ChiselScalatestTester {
  "InstructionMemory" should "map the program at 0x80000000 and read 0 outside it" in {
    val words = InstructionMemory.readHex("program.hex")
    assert(words.length == 31 && words.head == BigInt("80010537", 16))
    test(new InstructionMemory("program.hex", depth = 32)).withAnnotations(TestUtil.waves) { dut =>
      for ((k, w) <- words.zipWithIndex.map(_.swap).take(4)) {
        dut.io.addr.poke((0x80000000L + 4 * k).U(32.W)); dut.io.inst.expect(w.U(32.W))
      }
      for (addr <- Seq(0L, 0x7ffffffcL, 0x80000080L, 0xfffffffcL)) { // depth 32: 0x80000080 is past the end
        dut.io.addr.poke(addr.U(32.W)); dut.io.inst.expect(0.U, f"address 0x$addr%08x")
      }
    }
  }

  it should "accept comments, blank lines and separators in hex files" in {
    val dir = Paths.get("test_run_dir", "hex_parse"); Files.createDirectories(dir)
    val f = dir.resolve("p.hex")
    Files.write(f, "# c\n0000_0013\n\n00a00093  # addi\n".getBytes("UTF-8"))
    assert(InstructionMemory.readHex(f.toString) == Seq(BigInt(0x13), BigInt("00a00093", 16)))
  }

  "DataMemory" should "start from data.hex, write bytes, halves and words under byte strobes, and ignore outside writes" in {
    val B = 0x80010000L
    test(new DataMemory("data.hex", depth = 16)).withAnnotations(TestUtil.waves) { dut =>
      def rd(a: Long): BigInt = { dut.io.addr.poke(a.U(32.W)); dut.io.rdata.peek().litValue }
      def wr(a: Long, d: Long, s: Int): Unit = {
        dut.io.addr.poke(a.U(32.W)); dut.io.wdata.poke(d.U(32.W)); dut.io.wstrb.poke(s.U); dut.io.we.poke(true.B)
        dut.clock.step(); dut.io.we.poke(false.B)
      }
      dut.io.we.poke(false.B)
      assert(rd(B) == 4 && rd(B + 4) == 0x3fc00000L && rd(B + 16) == 0x3f000000L && rd(B + 32) == 0x41000000L && rd(B + 36) == 0)
      assert(rd(B + 2) == 4)                                    // any byte address reads its aligned word
      wr(B + 36, 0x11223344L, 0xf); assert(rd(B + 36) == 0x11223344L)
      wr(B + 36, 0xaaaaaaaaL, 0x2); assert(rd(B + 36) == 0x1122aa44L)       // one byte lane
      wr(B + 36, 0xbbbbbbbbL, 0xc); assert(rd(B + 36) == 0xbbbbaa44L)       // upper half
      wr(B + 36, 0x12345678L, 0x0); assert(rd(B + 36) == 0xbbbbaa44L)       // no lane
      wr(B - 4, 0xffffffffL, 0xf); wr(B + 64, 0xffffffffL, 0xf)             // outside: ignored
      assert(rd(B - 4) == 0 && rd(B + 64) == 0 && rd(B) == 4 && rd(B + 60) == 0)
    }
  }

  "RV32ITestWrapper" should "run program.hex on data.hex: float dot product with FMADD.S, FDIV, FSQRT, conversions, fflags" in {
    test(new RV32ITestWrapper("program.hex", "data.hex")).withAnnotations(TestUtil.waves) { dut =>
      dut.clock.setTimeout(0)
      val x = Array.fill(32)(0L); val f = Array.fill(32)(0L)
      var retired = 0; var stores = 0; var cycles = 0; var waits = 0
      while (!(dut.io.trace.valid.peek().litToBoolean && dut.io.trace.inst.peek().litValue == Asm.Halt)) {
        dut.io.trace.trap.expect(false.B)
        if (dut.io.trace.valid.peek().litToBoolean) retired += 1 else waits += 1
        if (dut.io.trace.memWe.peek().litToBoolean) {
          stores += 1
          dut.io.trace.memAddr.expect("h80010024".U); dut.io.trace.memWdata.expect("hc0a00000".U)
        }
        val rd = dut.io.trace.rdAddr.peek().litValue.toInt
        if (rd != 0) x(rd) = dut.io.trace.rdData.peek().litValue.toLong
        if (dut.io.trace.fdWe.peek().litToBoolean)
          f(dut.io.trace.fdAddr.peek().litValue.toInt) = dut.io.trace.fdData.peek().litValue.toLong
        dut.clock.step(); cycles += 1
        assert(cycles < 1000)
      }
      assert(f(0) == 0xc0a00000L && f(3) == 0xc0a00000L)           // dot product -5.0, stored and reloaded
      assert(f(4) == 0x40400000L && f(5) == 0xbfd55555L)           // 3.0, -5/3
      assert(f(6) == 0x403504f3L && f(7) == 0xc0a00000L)           // sqrt(8), -5/3 * 3 = -5.0
      assert(f(8) == 0x40400000L && f(9) == 0xc0400000L)           // max = 3.0, -3.0
      assert(f(10) == 0L && f(11) == 0x7f800000L)                  // +0.0, 3 / +0 = +inf
      assert(x(15) == 0xfffffffeL && x(16) == 0xffffffffL)         // -2 (to nearest), -1 (towards zero)
      assert(x(17) == 1 && x(18) == 2 && x(19) == 0x403504f3L)     // flt, fclass = negative normal, raw bits
      assert(x(20) == FFlags.NX && x(21) == (FFlags.NX | FFlags.DZ))
      assert(stores == 1)
      assert(retired == 5 + 4 * 7 + 18)                            // set-up, loop, the rest
      // FPU waits: 4 FMADD.S (29), FCVT.S.W (4), FDIV.S (31), FSQRT.S (31), 2 FCVT.W.S (3), FMUL.S (29),
      // FSUB.S with an exact zero result (3), FDIV.S by zero (2)
      assert(waits == 4 * 29 + 4 + 31 + 31 + 2 * 3 + 29 + 3 + 2)
    }
  }
}
