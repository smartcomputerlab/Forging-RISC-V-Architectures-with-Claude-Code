package rv32i

import scala.util.Random

/** Random binary32 operands for the floating-point tests. */
object FpGen {
  import FpRef._
  /** Random binary32 patterns weighted towards the interesting places. */
  def randF(r: Random): Long = r.nextInt(12) match {
    case 0 => Seq(0L, 0x80000000L, PosInf, NegInf, CanonicalNaN, 0x7f800001L, 0xffc00001L, 1L, 0x807fffffL,
                  0x00800000L, MaxFinite, 0xff7fffffL, 0x3f800000L, 0xbf800000L)(r.nextInt(14))
    case 1 => r.nextInt(0x800000).toLong | (if (r.nextBoolean()) 0x80000000L else 0L)                 // subnormal
    case 2 => (r.nextInt(0x800000).toLong | ((r.nextInt(8) + 120L) << 23)) ^ (if (r.nextBoolean()) 0x80000000L else 0L) // near 1
    case 3 => (r.nextInt(0x800000).toLong | ((r.nextInt(6) + 1L) << 23)) | (if (r.nextBoolean()) 0x80000000L else 0L)  // tiny normal
    case 4 => (r.nextInt(0x800000).toLong | ((r.nextInt(6) + 248L) << 23)) | (if (r.nextBoolean()) 0x80000000L else 0L) // huge
    case _ => r.nextLong() & 0xFFFFFFFFL
  }

}
