package rv32i

import chisel3._
import chiseltest._
import org.scalatest.flatspec.AnyFlatSpec
import org.scalatest.matchers.should.Matchers
import scala.util.Random

/** The sequential FPU against the bit-exact software reference FpRef: result bits, exception flags and latency,
  * for every operation, every rounding mode, special operands and random operands.
  * `FPU_TESTS=10 sbt "testOnly rv32i.FpuSpec"` multiplies the number of random operations (default sizes keep the
  * suite to a few minutes on Treadle). */
class FpuSpec extends AnyFlatSpec with ChiselScalatestTester with Matchers {
  import FpuOp._

  /** The reference result of one FPU operation. */
  def ref(op: Int, a: Long, b: Long, c: Long, rm: Int): (Long, Int) = op match {
    case ADD      => FpRef.add(a, b, rm)
    case SUB      => FpRef.sub(a, b, rm)
    case MUL      => FpRef.mul(a, b, rm)
    case DIV      => FpRef.div(a, b, rm)
    case SQRT     => FpRef.sqrt(a, rm)
    case MADD     => FpRef.fma(a, b, c, negProd = false, negC = false, rm)
    case MSUB     => FpRef.fma(a, b, c, negProd = false, negC = true, rm)
    case NMSUB    => FpRef.fma(a, b, c, negProd = true, negC = false, rm)
    case NMADD    => FpRef.fma(a, b, c, negProd = true, negC = true, rm)
    case CVT_W_S  => FpRef.toInt(a, signed = true, rm)
    case CVT_WU_S => FpRef.toInt(a, signed = false, rm)
    case CVT_S_W  => FpRef.fromInt(a, signed = true, rm)
    case CVT_S_WU => FpRef.fromInt(a, signed = false, rm)
  }

  /** Runs one operation; returns (bits, flags, latency in clock edges from the accepting edge). */
  def run(c: Fpu, op: Int, a: Long, b: Long, cc: Long, rm: Int): (Long, Int, Int) = {
    c.io.req.ready.expect(true.B)
    c.io.req.valid.poke(true.B)
    c.io.req.bits.op.poke(op.U); c.io.req.bits.rm.poke(rm.U)
    c.io.req.bits.a.poke(a.U(32.W)); c.io.req.bits.b.poke(b.U(32.W)); c.io.req.bits.c.poke(cc.U(32.W))
    c.clock.step()
    c.io.req.valid.poke(false.B)
    var lat = 1
    while (!c.io.resp.valid.peek().litToBoolean) { c.clock.step(); lat += 1; require(lat < 100, "no response") }
    c.io.busy.expect(true.B)
    c.io.req.ready.expect(false.B)
    val r = (c.io.resp.bits.bits.peek().litValue.toLong, c.io.resp.bits.flags.peek().litValue.toInt, lat)
    c.clock.step()
    r
  }

  private def operand(r: Random, op: Int): Long =
    if (op == CVT_S_W || op == CVT_S_WU)
      (if (r.nextInt(4) == 0) Seq(0L, 1L, 0x7fffffffL, 0x80000000L, 0xffffffffL, 0x01000001L)(r.nextInt(6))
       else if (r.nextBoolean()) r.nextInt(1 << (1 + r.nextInt(30))).toLong else r.nextLong() & 0xFFFFFFFFL)
    else if ((op == CVT_W_S || op == CVT_WU_S) && r.nextBoolean())
      // around the integer range: 2^-2 .. 2^34, both signs
      (r.nextInt(0x800000).toLong | ((125L + r.nextInt(36)) << 23)) | (if (r.nextBoolean()) 0x80000000L else 0L)
    else FpGen.randF(r)

  private def check(c: Fpu, op: Int, a: Long, b: Long, cc: Long, rm: Int): Unit = {
    val (bits, flags, lat) = run(c, op, a, b, cc, rm)
    val (eb, ef) = ref(op, a, b, cc, rm)
    val where = f"${names(op)} rm=${Rm.names(rm)} a=0x$a%08x b=0x$b%08x c=0x$cc%08x"
    withClue(where + ": ") {
      bits shouldBe eb
      flags shouldBe ef
      lat should (be(latency(op)) or be(SpecialLatency) or be(3) or be(27))
    }
  }

  private val scale = sys.env.get("FPU_TESTS").map(_.toDouble).getOrElse(1.0)
  private def sweep(ops: Seq[Int], n0: Int, seed: Int): Unit = {
    val n = math.max(1, (n0 * scale).toInt)
    test(new Fpu) { c =>
      c.clock.setTimeout(0)
      c.io.kill.poke(false.B); c.io.req.valid.poke(false.B)
      val r = new Random(seed)
      for (op <- ops; _ <- 0 until n)
        check(c, op, operand(r, op), operand(r, op), operand(r, op), r.nextInt(5))
    }
  }

  "Fpu" should "add and subtract exactly like the reference (1,500 each, all rounding modes)" in {
    sweep(Seq(ADD, SUB), 1500, 1)
  }
  it should "multiply exactly like the reference (600, all rounding modes)" in {
    sweep(Seq(MUL), 600, 2)
  }
  it should "compute the four fused multiply-adds exactly like the reference (300 each)" in {
    sweep(Seq(MADD, MSUB, NMSUB, NMADD), 300, 3)
  }
  it should "divide and take square roots exactly like the reference (500 each)" in {
    sweep(Seq(DIV, SQRT), 500, 4)
  }
  it should "convert between float and 32-bit integers exactly like the reference (1,000 each)" in {
    sweep(Seq(CVT_W_S, CVT_WU_S, CVT_S_W, CVT_S_WU), 1000, 5)
  }

  it should "take exactly the documented number of cycles" in {
    test(new Fpu) { c =>
      c.io.kill.poke(false.B); c.io.req.valid.poke(false.B)
      val one = 0x3f800000L; val three = 0x40400000L
      for (op <- Seq(ADD, SUB, MUL, DIV, SQRT, MADD, MSUB, NMSUB, NMADD)) run(c, op, three, one, one, Rm.RNE)._3 shouldBe latency(op)
      run(c, CVT_W_S, three, 0, 0, Rm.RNE)._3 shouldBe latency(CVT_W_S)
      run(c, CVT_S_W, 7, 0, 0, Rm.RNE)._3 shouldBe latency(CVT_S_W)
      run(c, DIV, one, 0, 0, Rm.RNE)._3 shouldBe SpecialLatency                 // x / 0
      run(c, ADD, FpRef.CanonicalNaN, one, 0, Rm.RNE)._3 shouldBe SpecialLatency
      run(c, SUB, three, three, 0, Rm.RNE)._3 shouldBe 3                          // exact cancellation
    }
  }

  it should "handle the corner cases of rounding, underflow and overflow" in {
    test(new Fpu) { c =>
      c.io.kill.poke(false.B); c.io.req.valid.poke(false.B)
      val cases = Seq(
        (MUL, 0x00800001L, 0x3f000000L, 0L), (MUL, 0x007fffffL, 0x3f800001L, 0L), (MUL, 0x7f7fffffL, 0x40000000L, 0L),
        (MUL, 0x00000001L, 0x3f000000L, 0L), (MUL, 0x00000001L, 0x3f400000L, 0L), (MUL, 0x80000003L, 0x3f000000L, 0L),
        (ADD, 0x00800000L, 0x80000001L, 0L), (ADD, 0x4b800000L, 0x3f800001L, 0L), (SUB, 0x3f800000L, 0x33800000L, 0L),
        (ADD, 0x7f7fffffL, 0x73800000L, 0L), (DIV, 0x00800000L, 0x40000000L, 0L), (DIV, 0x3f800000L, 0x7f7fffffL, 0L),
        (DIV, 0x7f7fffffL, 0x00000001L, 0L), (SQRT, 0x00000001L, 0L, 0L), (SQRT, 0x7f7fffffL, 0L, 0L),
        (SQRT, 0x40000000L, 0L, 0L), (MADD, 0x3f800001L, 0x3f7fffffL, 0xbf800000L), (MADD, 0x5f800000L, 0x5f800000L, 0xff800000L),
        (NMADD, 0x00000001L, 0x00000001L, 0x80000000L), (MSUB, 0x3f800000L, 0x3f800000L, 0x3f800000L),
        (CVT_W_S, 0x4effffffL, 0L, 0L), (CVT_W_S, 0xcf000001L, 0L, 0L), (CVT_WU_S, 0x4f7fffffL, 0L, 0L),
        (CVT_WU_S, 0x4f800000L, 0L, 0L), (CVT_WU_S, 0xbe800000L, 0L, 0L), (CVT_S_WU, 0xffffffffL, 0L, 0L),
        (CVT_S_W, 0x80000000L, 0L, 0L), (CVT_S_W, 0x00ffffffL, 0L, 0L),
        (MUL, FpRef.PosInf, 0x80000000L, 0L), (MADD, FpRef.PosInf, 0L, FpRef.CanonicalNaN),      // 0 x inf: NV even with a qNaN addend
        (NMADD, 0L, FpRef.NegInf, 0x3f800000L), (MSUB, FpRef.PosInf, 0x3f800000L, FpRef.PosInf), // inf - inf
        (SQRT, 0x40800000L, 0L, 0L), (SQRT, 0x41100000L, 0L, 0L), (SQRT, 0x00000004L, 0L, 0L))  // sqrt 4, 9, a subnormal
      for ((op, a, b, cc) <- cases; rm <- 0 until 5) check(c, op, a, b, cc, rm)
    }
  }
}
