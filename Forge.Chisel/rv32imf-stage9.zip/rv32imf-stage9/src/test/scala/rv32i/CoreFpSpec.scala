package rv32i

import chisel3._
import chiseltest._
import org.scalatest.flatspec.AnyFlatSpec
import org.scalatest.matchers.should.Matchers
import scala.util.Random

/** The F extension on the whole core, in lockstep with RefModel (every retirement: x and f writes, memory access,
  * traps, raised flags), plus the cycle cost of each FP instruction. */
class CoreFpSpec extends AnyFlatSpec with ChiselScalatestTester with Matchers {
  private val Data = 0x80010000L
  private val one = 0x3f800000L

  /** Interesting operands: zeros, ones, a third, subnormals, the largest finite, infinities, NaNs. */
  private val specials = Seq(0L, 0x80000000L, one, 0xbfc00000L, 0x3eaaaaabL, 0x00000001L, 0x807fffffL, 0x00800000L,
    FpRef.MaxFinite, FpRef.PosInf, FpRef.NegInf, FpRef.CanonicalNaN, 0x7f800001L, 0x4b800001L, 0xcf000000L, 0x5f800000L)

  private def run(a: Asm, data: Seq[(Long, Long)] = Nil) = {
    var res: CoreSim.Result = null
    test(new Core()).withAnnotations(TestUtil.waves) { c => res = CoreSim.run(c, a.words, data = data) }
    res
  }

  /** f1..f16 = the special values (through x5). */
  private def loadSpecials(a: Asm): Unit = specials.zipWithIndex.foreach { case (v, k) => a.fli(k + 1, v, 5) }

  "Core (F extension)" should "execute every arithmetic F instruction on special operands in all rounding modes" in {
    val r = new Random(31)
    val a = new Asm
    loadSpecials(a)
    for (rm <- Seq(0, 1, 2, 3, 4, 7); _ <- 0 until 6) {
      def f() = 1 + r.nextInt(specials.length)
      a.fadd(20, f(), f(), rm); a.fsub(21, f(), f(), rm); a.fmul(22, f(), f(), rm); a.fdiv(23, f(), f(), rm)
      a.fsqrt(24, f(), rm); a.fmadd(25, f(), f(), f(), rm); a.fmsub(26, f(), f(), f(), rm)
      a.fnmsub(27, f(), f(), f(), rm); a.fnmadd(28, f(), f(), f(), rm)
      a.fcvtws(6, f(), rm); a.fcvtwus(7, f(), rm); a.fcvtsw(29, 6, rm); a.fcvtswu(30, 7, rm)
      if (rm == 7) a.csrrsi(0, CsrAddr.frm, 1)           // vary the dynamic rounding mode between rounds
    }
    a.csrrs(8, CsrAddr.fflags, 0)
    a.halt()
    val res = run(a)
    res.traps shouldBe 0
    res.model.fflags shouldBe 0x1f                       // NV, DZ, OF, UF and NX all occurred
  }

  it should "execute the single-cycle F instructions (sign injection, min/max, compares, class, moves)" in {
    val a = new Asm
    loadSpecials(a)
    for (i <- 1 to 16; j <- Seq(1, 3, 6, 10, 12, 13)) {
      a.fsgnj(20, i, j); a.fsgnjn(21, i, j); a.fsgnjx(22, i, j); a.fmin(23, i, j); a.fmax(24, i, j)
      a.feq(6, i, j); a.flt(7, i, j); a.fle(8, i, j)
    }
    for (i <- 1 to 16) { a.fclass(9, i); a.fmvxw(10, i); a.fmvwx(25, 10) }
    a.halt()
    val res = run(a)
    res.traps shouldBe 0
    res.events.forall(_.cycles == 1) shouldBe true       // no stall: one cycle each
  }

  it should "load and store single-precision values with FLW and FSW, and trap on misaligned ones" in {
    val a = new Asm
    a.li(10, Data)
    a.fli(1, 0x40490fdbL, 5)                             // pi
    a.fsw(1, 0, 10); a.flw(2, 0, 10); a.lw(11, 0, 10)    // the bits round-trip through memory and the x registers
    a.fsw(2, 8, 10); a.lh(12, 10, 10)
    a.fmvwx(3, 11); a.feq(13, 1, 3)
    a.la(6, "handler"); a.csrrw(0, CsrAddr.mtvec, 6)
    a.flw(4, 2, 10)                                      // misaligned: load address misaligned, f4 unchanged
    a.fsw(1, 6, 10)                                      // misaligned: store address misaligned, no write
    a.flw(5, 4, 10)                                      // aligned, from never-written memory: 0
    a.halt()
    a.label("handler")
    a.csrrs(7, CsrAddr.mepc, 0); a.addi(7, 7, 4); a.csrrw(0, CsrAddr.mepc, 7); a.mret()
    val res = run(a)
    res.traps shouldBe 2
    res.model.x(11) shouldBe 0x40490fdbL
    res.model.x(12) shouldBe 0x4049L
    res.model.x(13) shouldBe 1
    res.model.f(5) shouldBe 0
  }

  it should "keep fflags, frm and fcsr, accrue flags, and use frm for the dynamic rounding mode" in {
    val a = new Asm
    a.fli(1, one, 5); a.fli(2, 0x40400000L, 5)           // 1.0, 3.0
    a.fdiv(3, 1, 2)                                      // 1/3 with frm = RNE: 0x3eaaaaab, NX
    a.csrrs(10, CsrAddr.fflags, 0)                       // 1
    a.csrrwi(0, CsrAddr.frm, Rm.RTZ)
    a.fdiv(4, 1, 2)                                      // RTZ: 0x3eaaaaaa
    a.fdiv(5, 1, 2, Rm.RUP)                              // static mode beats frm: 0x3eaaaaab
    a.csrrs(11, CsrAddr.fcsr, 0)                         // frm = 1, NX: 0x21
    a.csrrwi(12, CsrAddr.fflags, 0)                      // read and clear
    a.fdiv(6, 1, 0)                                      // 1 / +0 (f0 = +0): +inf, DZ
    a.fli(7, 0x7f800001L, 5); a.fadd(8, 7, 1)            // signaling NaN: NV
    a.csrrs(13, CsrAddr.fflags, 0)                       // DZ | NV = 0x18
    a.li(9, 0xffffff00L); a.csrrw(14, CsrAddr.fcsr, 9)   // only frm (bits 7:5) and fflags (4:0) are kept
    a.csrrs(15, CsrAddr.fcsr, 0)                         // 0x00
    a.csrrs(16, CsrAddr.mstatus, 0)                      // SD = 1, FS = 11 (dirty, hardwired)
    a.csrrs(17, CsrAddr.misa, 0)
    a.halt()
    val res = run(a)
    res.traps shouldBe 0
    val x = res.model.x
    res.model.f(3) shouldBe 0x3eaaaaabL; res.model.f(4) shouldBe 0x3eaaaaaaL; res.model.f(5) shouldBe 0x3eaaaaabL
    x(10) shouldBe 1; x(11) shouldBe 0x21; x(12) shouldBe 1; x(13) shouldBe 0x18; x(15) shouldBe 0
    x(16) shouldBe 0x80007800L; x(17) shouldBe 0x40001120L
  }

  it should "trap on reserved rounding modes and on encodings outside RV32F (illegal instruction, mtval = word)" in {
    val a = new Asm
    a.la(6, "handler"); a.csrrw(0, CsrAddr.mtvec, 6)
    a.fli(1, one, 5)
    a.fadd(2, 1, 1, rm = 5)                              // reserved rounding mode 5
    a.fadd(2, 1, 1, rm = 6)                              // reserved rounding mode 6
    a.csrrwi(0, CsrAddr.frm, 5); a.fadd(2, 1, 1)         // dynamic with frm = 5
    a.fsgnj(3, 1, 1)                                     // sign injection does not round: still legal
    a.csrrwi(0, CsrAddr.frm, 0); a.fadd(2, 1, 1)         // legal again
    a.word(Enc.r(0x01, 1, 1, 7, 2, 0x53))                // fadd.d (fmt = D): illegal
    a.word(Enc.r4(1, 1, 1, 7, 2, 0x43) | (1L << 25))     // fmadd.d: illegal
    a.word(Enc.r(0x2c, 1, 1, 7, 2, 0x53))                // fsqrt.s with rs2 = 1: illegal
    a.word(Enc.r(0x10, 1, 1, 3, 2, 0x53))                // fsgnj funct3 = 3: illegal
    a.word(Enc.r(0x70, 0, 1, 2, 2, 0x53))                // fmv.x.w funct3 = 2: illegal
    a.word(Enc.r(0x60, 2, 1, 7, 2, 0x53))                // fcvt.l.s (RV64 only): illegal
    a.word(Enc.i(0, 0, 3, 2, 0x07))                      // fld: illegal
    a.word(Enc.s(0, 1, 0, 3, 0x27))                      // fsd: illegal
    a.halt()
    a.label("handler")
    a.csrrs(7, CsrAddr.mepc, 0); a.addi(7, 7, 4); a.csrrw(0, CsrAddr.mepc, 7); a.mret()
    val res = run(a)
    res.traps shouldBe 11
    res.model.f(3) shouldBe one
    res.model.mcause shouldBe Cause.IllegalInstruction
  }

  it should "run 1,500 random instructions mixing integer and F instructions in lockstep with the model" in {
    val r = new Random(32)
    val a = new Asm
    a.li(10, Data)
    for (k <- 0 until 16) { a.fli(k, FpGen.randF(r), 5); a.fsw(k, 4 * k, 10) }
    def fr() = r.nextInt(32); def xr() = 11 + r.nextInt(10)
    for (_ <- 0 until 1500) r.nextInt(30) match {
      case 0 => a.fadd(fr(), fr(), fr(), Seq(0, 1, 2, 3, 4, 7)(r.nextInt(6)))
      case 1 => a.fsub(fr(), fr(), fr())
      case 2 => a.fmul(fr(), fr(), fr(), r.nextInt(5))
      case 3 => a.fdiv(fr(), fr(), fr())
      case 4 => a.fsqrt(fr(), fr(), r.nextInt(5))
      case 5 => a.fmadd(fr(), fr(), fr(), fr())
      case 6 => a.fnmsub(fr(), fr(), fr(), fr(), r.nextInt(5))
      case 7 => a.fcvtws(xr(), fr(), r.nextInt(5))
      case 8 => a.fcvtwus(xr(), fr())
      case 9 => a.fcvtsw(fr(), xr()); case 10 => a.fcvtswu(fr(), xr(), r.nextInt(5))
      case 11 => a.fsgnj(fr(), fr(), fr()); case 12 => a.fsgnjx(fr(), fr(), fr())
      case 13 => a.fmin(fr(), fr(), fr()); case 14 => a.fmax(fr(), fr(), fr())
      case 15 => a.feq(xr(), fr(), fr()); case 16 => a.flt(xr(), fr(), fr()); case 17 => a.fle(xr(), fr(), fr())
      case 18 => a.fclass(xr(), fr()); case 19 => a.fmvxw(xr(), fr()); case 20 => a.fmvwx(fr(), xr())
      case 21 => a.flw(fr(), 4 * r.nextInt(16), 10); case 22 => a.fsw(fr(), 4 * r.nextInt(16), 10)
      case 23 => a.csrrs(xr(), CsrAddr.fflags, 0)
      case 24 => a.csrrwi(0, CsrAddr.frm, r.nextInt(5))
      case 25 => a.addi(xr(), xr(), r.nextInt(4096) - 2048)
      case 26 => a.mul(xr(), xr(), xr())
      case 27 => a.lui(xr(), r.nextInt(1 << 20))
      case 28 => a.xor(xr(), xr(), xr())
      case _ => a.fnmadd(fr(), fr(), fr(), fr(), r.nextInt(5))
    }
    a.halt()
    val res = run(a)
    res.traps shouldBe 0
    res.retired shouldBe 2 + 16 * 4 + 1500 + 1     // li, 16 x (fli = 3, fsw), the random ones, halt
  }

  it should "stall for exactly the FPU latency and retire in its response cycle" in {
    val a = new Asm
    a.fli(1, 0x40400000L, 5); a.fli(2, one, 5)          // 3.0, 1.0
    a.li(6, 7)
    a.fadd(3, 1, 2); a.fsub(3, 1, 2); a.fmul(3, 1, 2); a.fdiv(3, 1, 2); a.fsqrt(3, 1)
    a.fmadd(3, 1, 2, 2); a.fmsub(3, 1, 2, 2); a.fnmsub(3, 1, 2, 2); a.fnmadd(3, 1, 2, 2)
    a.fcvtws(7, 1); a.fcvtwus(7, 1); a.fcvtsw(3, 6); a.fcvtswu(3, 6)
    a.fdiv(3, 1, 0)                                      // divide by zero: special case
    a.fsub(3, 1, 1)                                      // exact cancellation
    a.fsgnj(3, 1, 2); a.fmin(3, 1, 2); a.feq(7, 1, 2); a.fclass(7, 1); a.fmvxw(7, 1); a.fmvwx(3, 7)
    a.halt()
    val res = run(a)
    import FpuOp._
    val expected = Seq(ADD, SUB, MUL, DIV, SQRT, MADD, MSUB, NMSUB, NMADD, CVT_W_S, CVT_WU_S, CVT_S_W, CVT_S_WU)
      .map(latency(_) + 1) ++ Seq(SpecialLatency + 1, 3 + 1) ++ Seq.fill(7)(1)
    val start = 3 + 3 + 2                                // fli, fli (3 instructions each), li
    res.events.slice(start, start + expected.length).map(_.cycles) shouldBe expected
  }
}
