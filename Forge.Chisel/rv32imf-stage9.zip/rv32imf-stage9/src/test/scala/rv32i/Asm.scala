package rv32i

import scala.collection.mutable

/** Instruction encoders (all return the 32-bit word as Long). */
object Enc {
  private def m(v: Long) = v & 0xFFFFFFFFL
  def r(f7: Int, rs2: Int, rs1: Int, f3: Int, rd: Int, op: Int): Long =
    m((f7.toLong << 25) | (rs2 << 20) | (rs1 << 15) | (f3 << 12) | (rd << 7) | op)
  def i(imm: Long, rs1: Int, f3: Int, rd: Int, op: Int): Long =
    m(((imm & 0xfff) << 20) | (rs1 << 15) | (f3 << 12) | (rd << 7) | op)
  def s(imm: Long, rs2: Int, rs1: Int, f3: Int, op: Int): Long =
    m((((imm >> 5) & 0x7f) << 25) | (rs2 << 20) | (rs1 << 15) | (f3 << 12) | ((imm & 31) << 7) | op)
  def b(off: Long, rs2: Int, rs1: Int, f3: Int): Long =
    m((((off >> 12) & 1) << 31) | (((off >> 5) & 0x3f) << 25) | (rs2 << 20) | (rs1 << 15) | (f3 << 12) |
      (((off >> 1) & 0xf) << 8) | (((off >> 11) & 1) << 7) | 0x63)
  /** R4-type (fused multiply-add): rs3 in bits 31:27, fmt (bits 26:25) = 00 for single precision. */
  def r4(rs3: Int, rs2: Int, rs1: Int, rm: Int, rd: Int, op: Int): Long =
    m((rs3.toLong << 27) | (rs2 << 20) | (rs1 << 15) | (rm << 12) | (rd << 7) | op)
  def u(imm20: Long, rd: Int, op: Int): Long = m(((imm20 & 0xfffff) << 12) | (rd << 7) | op)
  def j(off: Long, rd: Int): Long =
    m((((off >> 20) & 1) << 31) | (((off >> 1) & 0x3ff) << 21) | (((off >> 11) & 1) << 20) |
      (((off >> 12) & 0xff) << 12) | (rd << 7) | 0x6f)
}

/** Tiny two-pass assembler: instructions are recorded as functions of their own address, labels resolve at the end. */
class Asm(val base: Long = 0x80000000L) {
  import Enc._
  private val items  = mutable.ArrayBuffer.empty[Long => Long]
  private val labels = mutable.Map.empty[String, Long]

  def here: Long = base + 4L * items.length
  def label(name: String): Unit = { require(!labels.contains(name), s"duplicate label $name"); labels(name) = here }
  def addr(name: String): Long = labels(name)
  def words: Seq[Long] = items.zipWithIndex.map { case (f, k) => f(base + 4L * k) & 0xFFFFFFFFL }.toSeq
  private def emit(f: Long => Long): Unit = items += f
  private def fixed(w: Long): Unit = emit(_ => w)
  private def rel(l: String, at: Long): Long = labels.getOrElse(l, sys.error(s"unknown label $l")) - at

  def word(w: Long): Unit = fixed(w)

  // ---- RV32I
  def lui(rd: Int, imm20: Long): Unit   = fixed(u(imm20, rd, 0x37))
  def auipc(rd: Int, imm20: Long): Unit = fixed(u(imm20, rd, 0x17))
  def jal(rd: Int, l: String): Unit     = emit(at => j(rel(l, at), rd))
  def jalr(rd: Int, rs1: Int, imm: Long): Unit = fixed(i(imm, rs1, 0, rd, 0x67))
  private def br(f3: Int)(rs1: Int, rs2: Int, l: String): Unit = emit(at => b(rel(l, at), rs2, rs1, f3))
  def beq(a: Int, b: Int, l: String): Unit  = br(0)(a, b, l)
  def bne(a: Int, b: Int, l: String): Unit  = br(1)(a, b, l)
  def blt(a: Int, b: Int, l: String): Unit  = br(4)(a, b, l)
  def bge(a: Int, b: Int, l: String): Unit  = br(5)(a, b, l)
  def bltu(a: Int, b: Int, l: String): Unit = br(6)(a, b, l)
  def bgeu(a: Int, b: Int, l: String): Unit = br(7)(a, b, l)
  def lb(rd: Int, off: Long, rs1: Int): Unit  = fixed(i(off, rs1, 0, rd, 0x03))
  def lh(rd: Int, off: Long, rs1: Int): Unit  = fixed(i(off, rs1, 1, rd, 0x03))
  def lw(rd: Int, off: Long, rs1: Int): Unit  = fixed(i(off, rs1, 2, rd, 0x03))
  def lbu(rd: Int, off: Long, rs1: Int): Unit = fixed(i(off, rs1, 4, rd, 0x03))
  def lhu(rd: Int, off: Long, rs1: Int): Unit = fixed(i(off, rs1, 5, rd, 0x03))
  def sb(rs2: Int, off: Long, rs1: Int): Unit = fixed(s(off, rs2, rs1, 0, 0x23))
  def sh(rs2: Int, off: Long, rs1: Int): Unit = fixed(s(off, rs2, rs1, 1, 0x23))
  def sw(rs2: Int, off: Long, rs1: Int): Unit = fixed(s(off, rs2, rs1, 2, 0x23))
  def addi(rd: Int, rs1: Int, imm: Long): Unit  = fixed(i(imm, rs1, 0, rd, 0x13))
  def slti(rd: Int, rs1: Int, imm: Long): Unit  = fixed(i(imm, rs1, 2, rd, 0x13))
  def sltiu(rd: Int, rs1: Int, imm: Long): Unit = fixed(i(imm, rs1, 3, rd, 0x13))
  def xori(rd: Int, rs1: Int, imm: Long): Unit  = fixed(i(imm, rs1, 4, rd, 0x13))
  def ori(rd: Int, rs1: Int, imm: Long): Unit   = fixed(i(imm, rs1, 6, rd, 0x13))
  def andi(rd: Int, rs1: Int, imm: Long): Unit  = fixed(i(imm, rs1, 7, rd, 0x13))
  def slli(rd: Int, rs1: Int, sh: Int): Unit    = fixed(i(sh, rs1, 1, rd, 0x13))
  def srli(rd: Int, rs1: Int, sh: Int): Unit    = fixed(i(sh, rs1, 5, rd, 0x13))
  def srai(rd: Int, rs1: Int, sh: Int): Unit    = fixed(i(0x400 | sh, rs1, 5, rd, 0x13))
  private def op(f7: Int, f3: Int)(rd: Int, a: Int, b: Int): Unit = fixed(r(f7, b, a, f3, rd, 0x33))
  def add(rd: Int, a: Int, b: Int): Unit  = op(0, 0)(rd, a, b)
  def sub(rd: Int, a: Int, b: Int): Unit  = op(0x20, 0)(rd, a, b)
  def sll(rd: Int, a: Int, b: Int): Unit  = op(0, 1)(rd, a, b)
  def slt(rd: Int, a: Int, b: Int): Unit  = op(0, 2)(rd, a, b)
  def sltu(rd: Int, a: Int, b: Int): Unit = op(0, 3)(rd, a, b)
  def xor(rd: Int, a: Int, b: Int): Unit  = op(0, 4)(rd, a, b)
  def srl(rd: Int, a: Int, b: Int): Unit  = op(0, 5)(rd, a, b)
  def sra(rd: Int, a: Int, b: Int): Unit  = op(0x20, 5)(rd, a, b)
  def or(rd: Int, a: Int, b: Int): Unit   = op(0, 6)(rd, a, b)
  def and(rd: Int, a: Int, b: Int): Unit  = op(0, 7)(rd, a, b)
  def fence(): Unit  = fixed(0x0ff0000fL)
  def ecall(): Unit  = fixed(0x00000073L)
  def ebreak(): Unit = fixed(0x00100073L)
  def mret(): Unit   = fixed(0x30200073L)
  def wfi(): Unit    = fixed(0x10500073L)

  // ---- M extension
  def mul(rd: Int, a: Int, b: Int): Unit    = op(1, 0)(rd, a, b)
  def mulh(rd: Int, a: Int, b: Int): Unit   = op(1, 1)(rd, a, b)
  def mulhsu(rd: Int, a: Int, b: Int): Unit = op(1, 2)(rd, a, b)
  def mulhu(rd: Int, a: Int, b: Int): Unit  = op(1, 3)(rd, a, b)
  def div(rd: Int, a: Int, b: Int): Unit    = op(1, 4)(rd, a, b)
  def divu(rd: Int, a: Int, b: Int): Unit   = op(1, 5)(rd, a, b)
  def rem(rd: Int, a: Int, b: Int): Unit    = op(1, 6)(rd, a, b)
  def remu(rd: Int, a: Int, b: Int): Unit   = op(1, 7)(rd, a, b)

  // ---- Zicsr
  def csrrw(rd: Int, csr: Int, rs1: Int): Unit   = fixed(i(csr, rs1, 1, rd, 0x73))
  def csrrs(rd: Int, csr: Int, rs1: Int): Unit   = fixed(i(csr, rs1, 2, rd, 0x73))
  def csrrc(rd: Int, csr: Int, rs1: Int): Unit   = fixed(i(csr, rs1, 3, rd, 0x73))
  def csrrwi(rd: Int, csr: Int, uimm: Int): Unit = fixed(i(csr, uimm, 5, rd, 0x73))
  def csrrsi(rd: Int, csr: Int, uimm: Int): Unit = fixed(i(csr, uimm, 6, rd, 0x73))
  def csrrci(rd: Int, csr: Int, uimm: Int): Unit = fixed(i(csr, uimm, 7, rd, 0x73))

  // ---- F extension (Stage 9). rm defaults to 7 (dynamic: fcsr.frm)
  def flw(fd: Int, off: Long, rs1: Int): Unit = fixed(i(off, rs1, 2, fd, 0x07))
  def fsw(fs2: Int, off: Long, rs1: Int): Unit = fixed(s(off, fs2, rs1, 2, 0x27))
  private def fop(f7: Int)(fd: Int, a: Int, b: Int, rm: Int): Unit = fixed(r(f7, b, a, rm, fd, 0x53))
  def fadd(fd: Int, a: Int, b: Int, rm: Int = 7): Unit = fop(0x00)(fd, a, b, rm)
  def fsub(fd: Int, a: Int, b: Int, rm: Int = 7): Unit = fop(0x04)(fd, a, b, rm)
  def fmul(fd: Int, a: Int, b: Int, rm: Int = 7): Unit = fop(0x08)(fd, a, b, rm)
  def fdiv(fd: Int, a: Int, b: Int, rm: Int = 7): Unit = fop(0x0c)(fd, a, b, rm)
  def fsqrt(fd: Int, a: Int, rm: Int = 7): Unit        = fop(0x2c)(fd, a, 0, rm)
  def fmadd(fd: Int, a: Int, b: Int, c: Int, rm: Int = 7): Unit  = fixed(r4(c, b, a, rm, fd, 0x43))
  def fmsub(fd: Int, a: Int, b: Int, c: Int, rm: Int = 7): Unit  = fixed(r4(c, b, a, rm, fd, 0x47))
  def fnmsub(fd: Int, a: Int, b: Int, c: Int, rm: Int = 7): Unit = fixed(r4(c, b, a, rm, fd, 0x4b))
  def fnmadd(fd: Int, a: Int, b: Int, c: Int, rm: Int = 7): Unit = fixed(r4(c, b, a, rm, fd, 0x4f))
  def fsgnj(fd: Int, a: Int, b: Int): Unit  = fop(0x10)(fd, a, b, 0)
  def fsgnjn(fd: Int, a: Int, b: Int): Unit = fop(0x10)(fd, a, b, 1)
  def fsgnjx(fd: Int, a: Int, b: Int): Unit = fop(0x10)(fd, a, b, 2)
  def fmin(fd: Int, a: Int, b: Int): Unit   = fop(0x14)(fd, a, b, 0)
  def fmax(fd: Int, a: Int, b: Int): Unit   = fop(0x14)(fd, a, b, 1)
  def feq(rd: Int, a: Int, b: Int): Unit    = fop(0x50)(rd, a, b, 2)
  def flt(rd: Int, a: Int, b: Int): Unit    = fop(0x50)(rd, a, b, 1)
  def fle(rd: Int, a: Int, b: Int): Unit    = fop(0x50)(rd, a, b, 0)
  def fcvtws(rd: Int, fa: Int, rm: Int = 7): Unit  = fop(0x60)(rd, fa, 0, rm)
  def fcvtwus(rd: Int, fa: Int, rm: Int = 7): Unit = fop(0x60)(rd, fa, 1, rm)
  def fcvtsw(fd: Int, a: Int, rm: Int = 7): Unit   = fop(0x68)(fd, a, 0, rm)
  def fcvtswu(fd: Int, a: Int, rm: Int = 7): Unit  = fop(0x68)(fd, a, 1, rm)
  def fmvxw(rd: Int, fa: Int): Unit   = fop(0x70)(rd, fa, 0, 0)
  def fclass(rd: Int, fa: Int): Unit  = fop(0x70)(rd, fa, 0, 1)
  def fmvwx(fd: Int, a: Int): Unit    = fop(0x78)(fd, a, 0, 0)
  /** fli: load a float bit pattern into f[fd] through x[tmp]. */
  def fli(fd: Int, bits: Long, tmp: Int): Unit = { li(tmp, bits); fmvwx(fd, tmp) }
  def fli(fd: Int, v: Float, tmp: Int): Unit = fli(fd, java.lang.Float.floatToRawIntBits(v).toLong & 0xFFFFFFFFL, tmp)

  // ---- pseudo-instructions
  def nop(): Unit = addi(0, 0, 0)
  def mv(rd: Int, rs: Int): Unit = addi(rd, rs, 0)
  def jump(l: String): Unit = jal(0, l)
  def li(rd: Int, v: Long): Unit = {
    val x  = v & 0xFFFFFFFFL
    val lo = ((x & 0xfff) ^ 0x800) - 0x800
    val hi = ((x - lo) >> 12) & 0xfffff
    lui(rd, hi); addi(rd, rd, lo)
  }
  /** la: address of a label (resolved at the end), with auipc-free lui/addi. */
  def la(rd: Int, l: String): Unit = {
    emit(_ => { val x = labels(l); val lo = ((x & 0xfff) ^ 0x800) - 0x800; u(((x - lo) >> 12) & 0xfffff, rd, 0x37) })
    emit(_ => { val x = labels(l); val lo = ((x & 0xfff) ^ 0x800) - 0x800; i(lo, rd, 0, rd, 0x13) })
  }
  /** Stop: `jal x0, 0` (an infinite loop on itself); the harness ends when it retires. */
  def halt(): Unit = fixed(Asm.Halt)
}

object Asm {
  val Halt = 0x0000006fL
}
