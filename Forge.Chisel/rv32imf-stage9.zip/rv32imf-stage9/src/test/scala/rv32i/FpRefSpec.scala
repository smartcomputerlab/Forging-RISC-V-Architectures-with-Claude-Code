package rv32i

import org.scalatest.flatspec.AnyFlatSpec
import org.scalatest.matchers.should.Matchers
import scala.util.Random

/** Cross-checks the software reference FpRef against the JVM's IEEE 754 float arithmetic (round to nearest even):
  * + - * / are correctly rounded binary32 operations in Java, Math.fma(float, float, float) is a fused multiply-add,
  * and sqrt computed in double then rounded to float is correctly rounded (53 >= 2 * 24 + 2). Then checks the
  * RISC-V-specific cases (canonical NaN, flags, the other rounding modes, conversions) on hand-picked values.
  */
class FpRefSpec extends AnyFlatSpec with Matchers {
  import FpRef._
  private def f(x: Long): Float = java.lang.Float.intBitsToFloat(x.toInt)
  private def bits(x: Float): Long = java.lang.Float.floatToRawIntBits(x).toLong & 0xFFFFFFFFL
  private def jv(x: Float): Long = if (x.isNaN) CanonicalNaN else bits(x)

  import FpGen.randF

  "FpRef in round-to-nearest-even" should "match Java float + - * / sqrt and fma on 200,000 random operand sets" in {
    val r = new Random(7)
    for (_ <- 0 until 200000) {
      val a = randF(r); val b = randF(r); val c = randF(r)
      withClue(f"a=0x$a%08x b=0x$b%08x c=0x$c%08x: ") {
        add(a, b, Rm.RNE)._1 shouldBe jv(f(a) + f(b))
        sub(a, b, Rm.RNE)._1 shouldBe jv(f(a) - f(b))
        mul(a, b, Rm.RNE)._1 shouldBe jv(f(a) * f(b))
        div(a, b, Rm.RNE)._1 shouldBe jv(f(a) / f(b))
        sqrt(a, Rm.RNE)._1 shouldBe jv(math.sqrt(f(a).toDouble).toFloat)
        fma(a, b, c, negProd = false, negC = false, Rm.RNE)._1 shouldBe jv(Math.fma(f(a), f(b), f(c)))
        fma(a, b, c, negProd = true, negC = true, Rm.RNE)._1 shouldBe jv(Math.fma(-f(a), f(b), -f(c)))
      }
    }
  }

  it should "convert integers like Java (int and unsigned int to float)" in {
    val r = new Random(8)
    for (_ <- 0 until 100000) {
      val x = if (r.nextInt(4) == 0) Seq(0L, 1L, 0x7fffffffL, 0x80000000L, 0xffffffffL, 16777217L)(r.nextInt(6)) else r.nextLong() & 0xFFFFFFFFL
      fromInt(x, signed = true, Rm.RNE)._1 shouldBe bits(x.toInt.toFloat)
      fromInt(x, signed = false, Rm.RNE)._1 shouldBe bits(x.toFloat)
    }
  }

  it should "convert in-range floats to integers like Java (round to nearest even via Math.rint)" in {
    val r = new Random(9)
    for (_ <- 0 until 100000) {
      val a = randF(r); val v = f(a)
      if (!v.isNaN && math.abs(v.toDouble) < 2.0e9) toInt(a, signed = true, Rm.RNE)._1 shouldBe (math.rint(v.toDouble).toLong & 0xFFFFFFFFL)
    }
  }

  "FpRef" should "raise the RISC-V flags and produce the RISC-V special results" in {
    val one = 0x3f800000L; val two = 0x40000000L; val three = 0x40400000L
    div(one, 0L, Rm.RNE) shouldBe (PosInf, FFlags.DZ)
    div(0L, 0L, Rm.RNE) shouldBe (CanonicalNaN, FFlags.NV)
    div(one, three, Rm.RNE) shouldBe (0x3eaaaaabL, FFlags.NX)
    div(one, three, Rm.RTZ) shouldBe (0x3eaaaaaaL, FFlags.NX)
    div(one, three, Rm.RDN) shouldBe (0x3eaaaaaaL, FFlags.NX)
    div(one, three, Rm.RUP) shouldBe (0x3eaaaaabL, FFlags.NX)
    sqrt(0xbf800000L, Rm.RNE) shouldBe (CanonicalNaN, FFlags.NV)
    sqrt(0x80000000L, Rm.RNE) shouldBe (0x80000000L, 0)
    sqrt(0x40800000L, Rm.RNE) shouldBe (two, 0)
    add(PosInf, NegInf, Rm.RNE) shouldBe (CanonicalNaN, FFlags.NV)
    add(0x7f800001L, one, Rm.RNE) shouldBe (CanonicalNaN, FFlags.NV)        // signaling NaN
    add(0x7fc00001L, one, Rm.RNE) shouldBe (CanonicalNaN, 0)                // quiet NaN: no flag, canonical result
    add(one, 0xbf800000L, Rm.RNE) shouldBe (0L, 0)                          // x - x = +0
    add(one, 0xbf800000L, Rm.RDN) shouldBe (0x80000000L, 0)                 // ... = -0 when rounding down
    add(0x80000000L, 0x80000000L, Rm.RNE) shouldBe (0x80000000L, 0)         // -0 + -0 = -0
    mul(MaxFinite, two, Rm.RNE) shouldBe (PosInf, FFlags.OF | FFlags.NX)
    mul(MaxFinite, two, Rm.RTZ) shouldBe (MaxFinite, FFlags.OF | FFlags.NX)
    mul(0xff7fffffL, two, Rm.RUP) shouldBe (0xff7fffffL, FFlags.OF | FFlags.NX)
    mul(0x00800000L, 0x3f000000L, Rm.RNE) shouldBe (0x00400000L, 0)         // exact subnormal result: no UF
    mul(0x00800001L, 0x3f000000L, Rm.RNE) shouldBe (0x00400000L, FFlags.NX | FFlags.UF)
    // tininess after rounding: rounds up to the smallest normal -> not tiny, no UF
    mul(0x007fffffL, 0x3f800001L, Rm.RUP) shouldBe (0x00800000L, FFlags.NX)
    fma(PosInf, 0L, CanonicalNaN, negProd = false, negC = false, Rm.RNE) shouldBe (CanonicalNaN, FFlags.NV)
    fma(two, three, one, negProd = false, negC = true, Rm.RNE) shouldBe (0x40a00000L, 0)   // 2*3 - 1 = 5
    min(0L, 0x80000000L) shouldBe (0x80000000L, 0)
    max(0L, 0x80000000L) shouldBe (0L, 0)
    min(CanonicalNaN, one) shouldBe (one, 0)
    min(0x7f800001L, one) shouldBe (one, FFlags.NV)
    min(CanonicalNaN, CanonicalNaN) shouldBe (CanonicalNaN, 0)
    feq(CanonicalNaN, one) shouldBe (0L, 0)
    feq(0x7f800001L, one) shouldBe (0L, FFlags.NV)
    flt(CanonicalNaN, one) shouldBe (0L, FFlags.NV)
    fle(0x80000000L, 0L) shouldBe (1L, 0)
    flt(0x80000000L, 0L) shouldBe (0L, 0)
    fclass(NegInf) shouldBe 1L; fclass(0x80000000L) shouldBe 8L; fclass(1L) shouldBe 32L
    fclass(0x7f800001L) shouldBe 256L; fclass(CanonicalNaN) shouldBe 512L
    toInt(CanonicalNaN, signed = true, Rm.RNE) shouldBe (0x7fffffffL, FFlags.NV)
    toInt(NegInf, signed = true, Rm.RNE) shouldBe (0x80000000L, FFlags.NV)
    toInt(NegInf, signed = false, Rm.RNE) shouldBe (0L, FFlags.NV)
    toInt(0xbf000000L, signed = false, Rm.RNE) shouldBe (0L, FFlags.NX)    // -0.5 -> -0 -> 0, not invalid
    toInt(0xbf800000L, signed = false, Rm.RNE) shouldBe (0L, FFlags.NV)    // -1.0 is out of range
    toInt(0x3fc00000L, signed = true, Rm.RNE) shouldBe (2L, FFlags.NX)     // 1.5 -> 2
    toInt(0x3fc00000L, signed = true, Rm.RTZ) shouldBe (1L, FFlags.NX)
    toInt(0xbfc00000L, signed = true, Rm.RDN) shouldBe (0xfffffffeL, FFlags.NX) // -1.5 -> -2
    toInt(0x4f000000L, signed = true, Rm.RNE) shouldBe (0x7fffffffL, FFlags.NV) // 2^31 out of range
    toInt(0xcf000000L, signed = true, Rm.RNE) shouldBe (0x80000000L, 0)         // -2^31 exact
    fromInt(16777217L, signed = true, Rm.RTZ) shouldBe (0x4b800000L, FFlags.NX)
    sgnj(one, 0x80000000L, 0) shouldBe 0xbf800000L
    sgnj(0xbf800000L, 0x80000000L, 2) shouldBe one
  }
}
