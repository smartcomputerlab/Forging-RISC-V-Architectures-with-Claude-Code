package rv32i

/** RISC-V rounding modes (instruction rm field and fcsr.frm). 7 = dynamic (use frm); 5 and 6 are reserved. */
object Rm {
  val RNE = 0 // round to nearest, ties to even
  val RTZ = 1 // round towards zero
  val RDN = 2 // round down (towards -infinity)
  val RUP = 3 // round up (towards +infinity)
  val RMM = 4 // round to nearest, ties to max magnitude
  val DYN = 7
  val names = Seq("rne", "rtz", "rdn", "rup", "rmm", "rm5", "rm6", "dyn")
}

/** Accrued exception flags (fcsr.fflags bit positions). */
object FFlags {
  val NX = 1  // inexact
  val UF = 2  // underflow
  val OF = 4  // overflow
  val DZ = 8  // divide by zero
  val NV = 16 // invalid operation
}

/** Bit-exact software model of RISC-V single-precision (binary32) arithmetic, written independently of the
  * hardware: every result is computed exactly with BigInt and rounded once by [[FpRef.round]].
  *
  * RISC-V specifics: NaN results are the canonical NaN 0x7fc00000; tininess is detected after rounding;
  * FMIN/FMAX return the non-NaN operand and treat -0 < +0; FEQ signals only on signaling NaNs, FLT/FLE on any NaN;
  * out-of-range and NaN conversions to integer saturate and raise NV.
  *
  * Values are 32-bit patterns held in a Long (0 .. 2^32-1). Every operation returns (result, flags).
  */
object FpRef {
  val CanonicalNaN = 0x7fc00000L
  val PosInf  = 0x7f800000L
  val NegInf  = 0xff800000L
  val MaxFinite = 0x7f7fffffL
  private val M32 = 0xFFFFFFFFL

  def sign(x: Long): Boolean = ((x >> 31) & 1) == 1
  def expField(x: Long): Int = ((x >> 23) & 0xff).toInt
  def frac(x: Long): Long = x & 0x7fffff
  def isNaN(x: Long): Boolean = expField(x) == 255 && frac(x) != 0
  def isSNaN(x: Long): Boolean = isNaN(x) && ((x >> 22) & 1) == 0
  def isInf(x: Long): Boolean = expField(x) == 255 && frac(x) == 0
  def isZero(x: Long): Boolean = (x & 0x7fffffff) == 0
  private def signBit(s: Boolean): Long = if (s) 0x80000000L else 0L

  /** Finite value as magnitude * 2^exp (the magnitude is 0 for zeros). */
  def decode(x: Long): (BigInt, Int) =
    if (expField(x) == 0) (BigInt(frac(x)), -149) else (BigInt(frac(x) | 0x800000L), expField(x) - 150)

  private def roundInc(rm: Int, sign: Boolean, lsb: Boolean, r: Boolean, st: Boolean): Boolean = rm match {
    case Rm.RNE => r && (st || lsb)
    case Rm.RTZ => false
    case Rm.RDN => sign && (r || st)
    case Rm.RUP => !sign && (r || st)
    case Rm.RMM => r
    case _      => throw new IllegalArgumentException(s"bad rounding mode $rm")
  }

  /** Rounds (-1)^sign * (m + d) * 2^e to binary32, where d = 0 if !sticky and 0 < d < 1 if sticky.
    * With `sticky`, m must have at least 26 bits so that d lies below the round bit. m > 0.
    */
  def round(sign: Boolean, m: BigInt, e: Int, sticky: Boolean, rm: Int): (Long, Int) = {
    require(m > 0)
    require(!sticky || m.bitLength >= 26, "sticky needs at least 26 significant bits")
    val L = m.bitLength
    val msbExp = e + L - 1
    def cut(v: BigInt, drop: Int): (BigInt, Boolean, Boolean) = // (kept, round bit, sticky)
      if (drop <= 0) (v << -drop, false, sticky)
      else (v >> drop, v.testBit(drop - 1), (v & ((BigInt(1) << (drop - 1)) - 1)) != 0 || sticky)
    // unbounded exponent, 24-bit precision: tininess after rounding
    val (ku, ru, su) = cut(m, L - 24)
    val kuR = ku + (if (roundInc(rm, sign, ku.testBit(0), ru, su)) 1 else 0)
    val eU = if (kuR.bitLength > 24) msbExp + 1 else msbExp
    val tiny = eU < -126
    if (msbExp >= -126) {
      val inexact = ru || su
      val biased = eU + 127
      if (biased >= 255) {
        val over = rm match {
          case Rm.RNE | Rm.RMM => PosInf
          case Rm.RTZ          => MaxFinite
          case Rm.RDN          => if (sign) PosInf else MaxFinite
          case _               => if (sign) MaxFinite else PosInf
        }
        (signBit(sign) | over, FFlags.OF | FFlags.NX)
      } else {
        val mant = (if (kuR.bitLength > 24) kuR >> 1 else kuR).toLong & 0x7fffff
        (signBit(sign) | (biased.toLong << 23) | mant, if (inexact) FFlags.NX else 0)
      }
    } else {
      // subnormal range: the LSB weighs 2^-149
      val (k, r, s) = cut(m, -149 - e)
      val q = k + (if (roundInc(rm, sign, k.testBit(0), r, s)) 1 else 0) // <= 2^23 (2^23 = smallest normal)
      val inexact = r || s
      (signBit(sign) | q.toLong, (if (inexact) FFlags.NX else 0) | (if (tiny && inexact) FFlags.UF else 0))
    }
  }

  private def nanResult(ops: Seq[Long]): (Long, Int) = (CanonicalNaN, if (ops.exists(isSNaN)) FFlags.NV else 0)
  private def zero(s: Boolean): Long = signBit(s)
  private def inf(s: Boolean): Long = signBit(s) | PosInf

  /** Exact sum of two signed exact values, rounded; zero results follow IEEE 754 sign rules. */
  private def addExact(s1: Boolean, m1: BigInt, e1: Int, s2: Boolean, m2: BigInt, e2: Int, rm: Int): (Long, Int) = {
    val e = math.min(e1, e2)
    val v1 = (m1 << (e1 - e)) * (if (s1) -1 else 1)
    val v2 = (m2 << (e2 - e)) * (if (s2) -1 else 1)
    val sum = v1 + v2
    if (sum == 0) {
      val sz = if (m1 == 0 && m2 == 0 && s1 == s2) s1 else rm == Rm.RDN
      (zero(sz), 0)
    } else round(sum < 0, sum.abs, e, sticky = false, rm)
  }

  def add(a: Long, b: Long, rm: Int): (Long, Int) = addSub(a, b, rm, negB = false)
  def sub(a: Long, b: Long, rm: Int): (Long, Int) = addSub(a, b, rm, negB = true)
  private def addSub(a: Long, b: Long, rm: Int, negB: Boolean): (Long, Int) = {
    val sa = sign(a); val sb = sign(b) ^ negB
    if (isNaN(a) || isNaN(b)) nanResult(Seq(a, b))
    else if (isInf(a) && isInf(b)) { if (sa == sb) (inf(sa), 0) else (CanonicalNaN, FFlags.NV) }
    else if (isInf(a)) (inf(sa), 0)
    else if (isInf(b)) (inf(sb), 0)
    else { val (ma, ea) = decode(a); val (mb, eb) = decode(b); addExact(sa, ma, ea, sb, mb, eb, rm) }
  }

  def mul(a: Long, b: Long, rm: Int): (Long, Int) = {
    val s = sign(a) ^ sign(b)
    if (isNaN(a) || isNaN(b)) nanResult(Seq(a, b))
    else if ((isInf(a) && isZero(b)) || (isZero(a) && isInf(b))) (CanonicalNaN, FFlags.NV)
    else if (isInf(a) || isInf(b)) (inf(s), 0)
    else if (isZero(a) || isZero(b)) (zero(s), 0)
    else { val (ma, ea) = decode(a); val (mb, eb) = decode(b); round(s, ma * mb, ea + eb, sticky = false, rm) }
  }

  /** Fused multiply-add: (-1)^negProd * a * b + (-1)^negC * c, rounded once.
    * FMADD = (false, false), FMSUB = (false, true), FNMSUB = (true, false), FNMADD = (true, true). */
  def fma(a: Long, b: Long, c: Long, negProd: Boolean, negC: Boolean, rm: Int): (Long, Int) = {
    val ps = sign(a) ^ sign(b) ^ negProd
    val cs = sign(c) ^ negC
    val infTimesZero = (isInf(a) && isZero(b)) || (isZero(a) && isInf(b))
    if (infTimesZero) (CanonicalNaN, FFlags.NV)                 // even when c is a quiet NaN
    else if (isNaN(a) || isNaN(b) || isNaN(c)) nanResult(Seq(a, b, c))
    else if (isInf(a) || isInf(b)) { if (isInf(c) && cs != ps) (CanonicalNaN, FFlags.NV) else (inf(ps), 0) }
    else if (isInf(c)) (inf(cs), 0)
    else {
      val (ma, ea) = decode(a); val (mb, eb) = decode(b); val (mc, ec) = decode(c)
      addExact(ps, ma * mb, ea + eb, cs, mc, ec, rm)
    }
  }

  def div(a: Long, b: Long, rm: Int): (Long, Int) = {
    val s = sign(a) ^ sign(b)
    if (isNaN(a) || isNaN(b)) nanResult(Seq(a, b))
    else if ((isZero(a) && isZero(b)) || (isInf(a) && isInf(b))) (CanonicalNaN, FFlags.NV)
    else if (isInf(a)) (inf(s), 0)
    else if (isInf(b)) (zero(s), 0)
    else if (isZero(b)) (inf(s), FFlags.DZ)
    else if (isZero(a)) (zero(s), 0)
    else {
      val (ma, ea) = decode(a); val (mb, eb) = decode(b)
      val k = 27 + mb.bitLength - ma.bitLength                   // quotient gets 26 or 27 bits
      val (q, r) = (ma << k) /% mb
      round(s, q, ea - eb - k, sticky = r != 0, rm)
    }
  }

  def sqrt(a: Long, rm: Int): (Long, Int) = {
    if (isNaN(a)) nanResult(Seq(a))
    else if (isZero(a)) (a, 0)                                    // sqrt(-0) = -0
    else if (sign(a)) (CanonicalNaN, FFlags.NV)
    else if (isInf(a)) (PosInf, 0)
    else {
      val (m0, e0) = decode(a)
      val (m1, e1) = if ((e0 & 1) != 0) (m0 << 1, e0 - 1) else (m0, e0)
      val k = math.max(0, (54 - m1.bitLength) / 2 + 1)
      val n = m1 << (2 * k)
      val s = BigInt(n.bigInteger.sqrt())
      round(sign = false, s, e1 / 2 - k, sticky = s * s != n, rm)
    }
  }

  /** FCVT.S.W (signed = true) and FCVT.S.WU: 32-bit integer to binary32. */
  def fromInt(x: Long, signed: Boolean, rm: Int): (Long, Int) = {
    val v = if (signed) (x & M32).toInt.toLong else x & M32
    if (v == 0) (0L, 0) else round(v < 0, BigInt(math.abs(v)), 0, sticky = false, rm)
  }

  /** FCVT.W.S (signed = true) and FCVT.WU.S: binary32 to 32-bit integer, saturating, NV on NaN / out of range. */
  def toInt(a: Long, signed: Boolean, rm: Int): (Long, Int) = {
    val maxS = 0x7fffffffL; val minS = 0x80000000L; val maxU = 0xffffffffL
    if (isNaN(a)) (if (signed) maxS else maxU, FFlags.NV)
    else if (isInf(a)) (if (sign(a)) (if (signed) minS else 0L) else (if (signed) maxS else maxU), FFlags.NV)
    else {
      val s = sign(a); val (m, e) = decode(a)
      val (mag, inexact) =
        if (e >= 0) (m << e, false)
        else {
          val k = m >> -e; val r = m.testBit(-e - 1); val st = (m & ((BigInt(1) << (-e - 1)) - 1)) != 0
          (k + (if (roundInc(rm, s, k.testBit(0), r, st)) 1 else 0), r || st)
        }
      val n = if (s) -mag else mag
      val (lo, hi) = if (signed) (BigInt(-0x80000000L), BigInt(0x7fffffffL)) else (BigInt(0), BigInt(0xffffffffL))
      if (n < lo) (if (signed) minS else 0L, FFlags.NV)
      else if (n > hi) (if (signed) maxS else maxU, FFlags.NV)
      else (n.toLong & M32, if (inexact) FFlags.NX else 0)
    }
  }

  // ---------------------------------------------------------------- non-arithmetic operations
  /** Total order key for non-NaN values with -0 < +0. */
  private def key(x: Long): Long = if (sign(x)) -(x & 0x7fffffff) - 1 else x & 0x7fffffff

  def min(a: Long, b: Long): (Long, Int) = minMax(a, b, isMax = false)
  def max(a: Long, b: Long): (Long, Int) = minMax(a, b, isMax = true)
  private def minMax(a: Long, b: Long, isMax: Boolean): (Long, Int) = {
    val nv = if (isSNaN(a) || isSNaN(b)) FFlags.NV else 0
    if (isNaN(a) && isNaN(b)) (CanonicalNaN, nv)
    else if (isNaN(a)) (b, nv)
    else if (isNaN(b)) (a, nv)
    else (if ((key(a) < key(b)) ^ isMax) a else b, nv)
  }

  /** FEQ.S, FLT.S, FLE.S: (0 or 1, flags). */
  def feq(a: Long, b: Long): (Long, Int) =
    if (isNaN(a) || isNaN(b)) (0L, if (isSNaN(a) || isSNaN(b)) FFlags.NV else 0)
    else (if ((isZero(a) && isZero(b)) || a == b) 1L else 0L, 0)
  def flt(a: Long, b: Long): (Long, Int) =
    if (isNaN(a) || isNaN(b)) (0L, FFlags.NV)
    else (if (!(isZero(a) && isZero(b)) && key(a) < key(b)) 1L else 0L, 0)
  def fle(a: Long, b: Long): (Long, Int) =
    if (isNaN(a) || isNaN(b)) (0L, FFlags.NV)
    else (if ((isZero(a) && isZero(b)) || key(a) <= key(b)) 1L else 0L, 0)

  /** FCLASS.S: one-hot 10-bit mask. */
  def fclass(a: Long): Long = {
    val s = sign(a)
    val bit =
      if (isNaN(a)) (if (isSNaN(a)) 8 else 9)
      else if (isInf(a)) (if (s) 0 else 7)
      else if (isZero(a)) (if (s) 3 else 4)
      else if (expField(a) == 0) (if (s) 2 else 5)
      else (if (s) 1 else 6)
    1L << bit
  }

  /** FSGNJ.S (0), FSGNJN.S (1), FSGNJX.S (2). */
  def sgnj(a: Long, b: Long, kind: Int): Long = {
    val sb = kind match { case 0 => sign(b); case 1 => !sign(b); case _ => sign(a) ^ sign(b) }
    (a & 0x7fffffff) | signBit(sb)
  }
}
