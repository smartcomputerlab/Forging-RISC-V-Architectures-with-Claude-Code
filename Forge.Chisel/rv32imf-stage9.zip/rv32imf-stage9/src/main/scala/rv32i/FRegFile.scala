package rv32i

import chisel3._

/** 32 x 32-bit floating-point register file f0..f31 (no hardwired register): three combinational read ports
  * (rs1, rs2 and rs3 for the fused multiply-adds) and one write port. All registers reset to 0 (+0.0).
  */
class FRegFile extends Module {
  val io = IO(new Bundle {
    val rs1   = Input(UInt(5.W))
    val rs2   = Input(UInt(5.W))
    val rs3   = Input(UInt(5.W))
    val rd1   = Output(UInt(32.W))
    val rd2   = Output(UInt(32.W))
    val rd3   = Output(UInt(32.W))
    val we    = Input(Bool())
    val waddr = Input(UInt(5.W))
    val wdata = Input(UInt(32.W))
  })
  val regs = RegInit(VecInit(Seq.fill(32)(0.U(32.W))))
  io.rd1 := regs(io.rs1)
  io.rd2 := regs(io.rs2)
  io.rd3 := regs(io.rs3)
  when(io.we) { regs(io.waddr) := io.wdata }
}
