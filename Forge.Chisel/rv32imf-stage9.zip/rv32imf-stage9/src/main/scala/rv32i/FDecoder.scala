package rv32i

import chisel3._
import chisel3.util._

/** Major opcodes of the F extension. */
object FOpcode {
  val LOAD_FP  = 0x07
  val STORE_FP = 0x27
  val MADD     = 0x43
  val MSUB     = 0x47
  val NMSUB    = 0x4b
  val NMADD    = 0x4f
  val OP_FP    = 0x53
}

/** Decoder for the 26 RV32F instructions (combinational). The Stage 3 integer decoder still reports these opcodes
  * as illegal; the core uses this decoder for them, as it does with the M extension.
  *
  * `isF`: the opcode belongs to the F extension. `illegal`: it does, but the encoding is not a valid RV32F
  * instruction (unknown funct7/funct5, fmt =/= S, bad rs2 or funct3) or its rounding mode is reserved (5, 6) or
  * dynamic while frm holds a reserved value (5, 6, 7). Every other output is meaningful only when !illegal.
  */
class FDecoder extends Module {
  val io = IO(new Bundle {
    val inst     = Input(UInt(32.W))
    val frm      = Input(UInt(3.W))
    val isF      = Output(Bool())
    val illegal  = Output(Bool())
    val rm       = Output(UInt(3.W))           // resolved rounding mode (0..4)
    val useFpu   = Output(Bool())              // sequential FPU operation
    val fpuOp    = Output(UInt(FpuOp.width.W))
    val useMisc  = Output(Bool())              // single-cycle FpMisc operation
    val miscOp   = Output(UInt(FpMiscOp.width.W))
    val mvXW     = Output(Bool())              // FMV.X.W: x[rd] = f[rs1] bits
    val mvWX     = Output(Bool())              // FMV.W.X: f[rd] = x[rs1] bits
    val load     = Output(Bool())              // FLW
    val store    = Output(Bool())              // FSW
    val intSrc   = Output(Bool())              // operand a is x[rs1] (FCVT.S.W/WU)
    val writesX  = Output(Bool())              // result goes to x[rd]
    val writesF  = Output(Bool())              // result goes to f[rd]
  })

  val inst   = io.inst
  val opcode = inst(6, 0)
  val f3     = inst(14, 12)
  val rs2    = inst(24, 20)
  val f7     = inst(31, 25)
  val fmtS   = inst(26, 25) === 0.U

  val rmField = f3
  val rmOk = rmField <= 4.U || (rmField === 7.U && io.frm <= 4.U)
  io.rm := Mux(rmField === 7.U, io.frm, rmField)

  val isLoad  = opcode === FOpcode.LOAD_FP.U
  val isStore = opcode === FOpcode.STORE_FP.U
  val isFma   = opcode === FOpcode.MADD.U || opcode === FOpcode.MSUB.U || opcode === FOpcode.NMSUB.U || opcode === FOpcode.NMADD.U
  val isOpFp  = opcode === FOpcode.OP_FP.U
  io.isF := isLoad || isStore || isFma || isOpFp

  io.useFpu := false.B; io.fpuOp := 0.U
  io.useMisc := false.B; io.miscOp := 0.U
  io.mvXW := false.B; io.mvWX := false.B
  io.load := false.B; io.store := false.B
  io.intSrc := false.B; io.writesX := false.B; io.writesF := false.B
  val valid = WireDefault(false.B)

  def fpu(op: Int, needRm: Boolean = true): Unit = {
    valid := (if (needRm) rmOk else true.B); io.useFpu := true.B; io.fpuOp := op.U; io.writesF := true.B
  }

  when(isLoad && f3 === 2.U) { valid := true.B; io.load := true.B; io.writesF := true.B }
  when(isStore && f3 === 2.U) { valid := true.B; io.store := true.B }
  when(isFma && fmtS) {
    val op = MuxLookup(opcode, FpuOp.MADD.U)(Seq(
      FOpcode.MADD.U -> FpuOp.MADD.U, FOpcode.MSUB.U -> FpuOp.MSUB.U,
      FOpcode.NMSUB.U -> FpuOp.NMSUB.U, FOpcode.NMADD.U -> FpuOp.NMADD.U))
    valid := rmOk; io.useFpu := true.B; io.fpuOp := op; io.writesF := true.B
  }
  when(isOpFp) {
    switch(f7) {
      is("h00".U) { fpu(FpuOp.ADD) }
      is("h04".U) { fpu(FpuOp.SUB) }
      is("h08".U) { fpu(FpuOp.MUL) }
      is("h0c".U) { fpu(FpuOp.DIV) }
      is("h2c".U) { when(rs2 === 0.U) { fpu(FpuOp.SQRT) } }
      is("h10".U) { when(f3 <= 2.U) { valid := true.B; io.useMisc := true.B; io.miscOp := FpMiscOp.SGNJ.U; io.writesF := true.B } }
      is("h14".U) { when(f3 <= 1.U) { valid := true.B; io.useMisc := true.B; io.miscOp := FpMiscOp.MINMAX.U; io.writesF := true.B } }
      is("h50".U) { when(f3 <= 2.U) { valid := true.B; io.useMisc := true.B; io.miscOp := FpMiscOp.CMP.U; io.writesX := true.B } }
      is("h60".U) {
        when(rs2 <= 1.U) { fpu(FpuOp.CVT_W_S); io.fpuOp := Mux(rs2(0), FpuOp.CVT_WU_S.U, FpuOp.CVT_W_S.U); io.writesF := false.B; io.writesX := true.B }
      }
      is("h68".U) {
        when(rs2 <= 1.U) { fpu(FpuOp.CVT_S_W); io.fpuOp := Mux(rs2(0), FpuOp.CVT_S_WU.U, FpuOp.CVT_S_W.U); io.intSrc := true.B }
      }
      is("h70".U) {
        when(rs2 === 0.U && f3 === 0.U) { valid := true.B; io.mvXW := true.B; io.writesX := true.B }
        when(rs2 === 0.U && f3 === 1.U) { valid := true.B; io.useMisc := true.B; io.miscOp := FpMiscOp.CLASS.U; io.writesX := true.B }
      }
      is("h78".U) { when(rs2 === 0.U && f3 === 0.U) { valid := true.B; io.mvWX := true.B; io.writesF := true.B; io.intSrc := true.B } }
    }
  }
  io.illegal := io.isF && !valid
}
