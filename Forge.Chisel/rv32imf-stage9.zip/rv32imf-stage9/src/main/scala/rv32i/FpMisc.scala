package rv32i

import chisel3._
import chisel3.util._

/** Single-cycle RV32F operations that never round (combinational):
  *  - FSGNJ.S / FSGNJN.S / FSGNJX.S (funct3 0 / 1 / 2): sign injection, no NaN canonicalization, no flags
  *  - FMIN.S / FMAX.S (funct3 0 / 1): -0 < +0; one NaN operand -> the other one; two NaNs -> canonical NaN;
  *    NV for a signaling NaN
  *  - FEQ.S / FLT.S / FLE.S (funct3 2 / 1 / 0): result 0 for any NaN; FEQ raises NV only for signaling NaNs,
  *    FLT and FLE for any NaN
  *  - FCLASS.S: one-hot 10-bit class
  */
object FpMiscOp {
  val width = 3
  val SGNJ   = 0
  val MINMAX = 1
  val CMP    = 2
  val CLASS  = 3
}

class FpMisc extends Module {
  val io = IO(new Bundle {
    val op     = Input(UInt(FpMiscOp.width.W))
    val funct3 = Input(UInt(3.W))
    val a      = Input(UInt(32.W))
    val b      = Input(UInt(32.W))
    val result = Output(UInt(32.W)) // float for SGNJ / MINMAX, integer for CMP / CLASS
    val flags  = Output(UInt(5.W))
  })

  val A = FpUnpack(io.a)
  val B = FpUnpack(io.b)
  val sa = io.a(31); val sb = io.b(31)
  val magA = io.a(30, 0); val magB = io.b(30, 0)
  val bothZero = A.zero && B.zero
  val anyNaN   = A.nan || B.nan
  val anySNaN  = A.snan || B.snan

  // a < b on non-NaN values, -0 < +0 (a total order on bit patterns)
  val ltOrdered = Mux(sa =/= sb, sa, Mux(sa, magA > magB, magA < magB))
  val eqBits    = io.a === io.b

  val nv = WireDefault(false.B)
  io.result := 0.U
  switch(io.op) {
    is(FpMiscOp.SGNJ.U) {
      val s = MuxLookup(io.funct3, sb)(Seq(0.U -> sb, 1.U -> !sb, 2.U -> (sa ^ sb)))
      io.result := Cat(s, magA)
    }
    is(FpMiscOp.MINMAX.U) {
      val isMax = io.funct3(0)
      val pickA = Mux(isMax, !ltOrdered, ltOrdered) || eqBits
      io.result := Mux(A.nan && B.nan, "h7fc00000".U, Mux(A.nan, io.b, Mux(B.nan, io.a, Mux(pickA, io.a, io.b))))
      nv := anySNaN
    }
    is(FpMiscOp.CMP.U) {
      val eq = !anyNaN && (eqBits || bothZero)
      val lt = !anyNaN && !bothZero && ltOrdered
      io.result := MuxLookup(io.funct3, 0.U)(Seq(2.U -> eq, 1.U -> lt, 0.U -> (lt || eq))).asUInt
      nv := Mux(io.funct3 === 2.U, anySNaN, anyNaN)
    }
    is(FpMiscOp.CLASS.U) {
      val sub = io.a(30, 23) === 0.U && !A.zero
      val normal = !A.zero && !sub && !A.inf && !A.nan
      io.result := Cat(A.nan && !A.snan, A.snan, A.inf && !sa, normal && !sa, sub && !sa, A.zero && !sa,
                       A.zero && sa, sub && sa, normal && sa, A.inf && sa)
    }
  }
  io.flags := Mux(nv, FFlags.NV.U(5.W), 0.U)
}
