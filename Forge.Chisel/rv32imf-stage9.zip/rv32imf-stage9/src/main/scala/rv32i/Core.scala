package rv32i

import chisel3._
import chisel3.util._

/** Stage 9: single-cycle RV32IMF core: RV32I, the M extension, the F extension (single-precision floating point),
  * Zicsr, machine mode only, no interrupts.
  *
  * Every cycle does exactly one of three things:
  *   - retires one instruction       (trace.valid)
  *   - takes one precise exception   (trace.trap)
  *   - waits for the divider or FPU  (neither: a DIV/DIVU/REM/REMU or a rounding FP operation in progress; pc,
  *                                    registers, memory and CSRs do not change; the same instruction stays on
  *                                    the fetch port)
  * A trapping instruction changes no architectural state except the trap CSRs (mepc, mcause, mtval, mstatus)
  * and the pc, which becomes mtvec (direct mode).
  *
  * Stage 4: MUL, MULH, MULHSU, MULHU execute in one cycle on the combinational (parallel) `Multiplier`.
  * Stage 5: DIV, DIVU, REM, REMU execute on the sequential `DivUnit`: 1 extra cycle for divide-by-zero and
  *          signed overflow, 33 extra cycles otherwise; the instruction retires in the divider's response cycle.
  * All eight are decoded here (OP opcode, funct7 = 0000001), so the Stage 3 Decoder is unchanged and still
  * reports funct7 = 0000001 as illegal on its own.
  * Stage 9: the 26 RV32F instructions, decoded by `FDecoder` (the Stage 3 Decoder reports their opcodes illegal):
  *          FLW/FSW use the data port; FSGNJ*, FMIN/FMAX, FEQ/FLT/FLE, FCLASS, FMV.X.W and FMV.W.X execute in one
  *          cycle on `FpMisc`; everything that rounds (FADD, FSUB, FMUL, FDIV, FSQRT, the four fused multiply-adds,
  *          the four FCVTs) runs on the sequential `Fpu` and retires in its response cycle (see FpuOp.latency).
  *          Raised exception flags accrue into fcsr.fflags; a reserved rounding mode makes the instruction illegal.
  *
  * Exceptions, in priority order: illegal instruction (2), ECALL (11), EBREAK (3), load misaligned (4),
  * store misaligned (6), instruction address misaligned (0: taken branch/JAL/JALR target with bit 1 set).
  * Misaligned data accesses trap (no hardware support). There are no access faults in this step.
  *
  * Memory ports are zero-wait: the instruction and data read data must be combinational functions of the
  * address. While the core waits for the divider it keeps `imem.addr` (the pc) unchanged.
  */
class Core(resetPc: Long = 0x80000000L, hartId: Int = 0) extends Module {
  val io = IO(new Bundle {
    val imem  = new InstrMemPort
    val dmem  = new DataMemPort
    val trace = Output(new Trace)
  })

  require(resetPc >= 0 && resetPc < (1L << 32) && resetPc % 4 == 0, "reset pc must be 4-byte aligned")

  val pc = RegInit(resetPc.U(32.W))
  io.imem.addr := pc
  val inst = io.imem.data
  val f3   = inst(14, 12)

  // ---------------- M extension: OP opcode with funct7 = 0000001 ----------------
  val isMulDiv = inst(6, 0) === "b0110011".U && inst(31, 25) === "b0000001".U
  val isMul    = isMulDiv && !f3(2)   // Stage 4: MUL, MULH, MULHSU, MULHU   (funct3 = 0xx)
  val isDiv    = isMulDiv && f3(2)    // Stage 5: DIV, DIVU, REM, REMU       (funct3 = 1xx)

  val dec  = Module(new Decoder)
  val immg = Module(new ImmGen)
  val rf   = Module(new RegFile)
  val alu  = Module(new Alu)
  val csr  = Module(new CsrFile(hartId))
  val mul  = Module(new Multiplier)
  val div  = Module(new DivUnit(32))
  val fdec  = Module(new FDecoder)
  val frf   = Module(new FRegFile)
  val fpu   = Module(new Fpu)
  val fmisc = Module(new FpMisc)

  dec.io.inst  := inst
  immg.io.inst := inst
  immg.io.sel  := dec.io.immSel
  // Register addresses straight from the instruction for M-extension ops (the decoder treats them as illegal).
  rf.io.rs1    := Mux(isMulDiv, inst(19, 15), dec.io.rs1)
  rf.io.rs2    := Mux(isMulDiv, inst(24, 20), dec.io.rs2)
  val rs1v = rf.io.rd1
  val rs2v = rf.io.rd2
  val imm  = immg.io.imm

  mul.io.fn := f3(1, 0)
  mul.io.a  := rs1v
  mul.io.b  := rs2v

  // Sequential divider. `busy` stays high through its response cycle, so holding the same instruction on the
  // fetch port never starts it twice. The divider latches rs1/rs2 when it accepts the request.
  div.io.req.valid   := isDiv && !div.io.busy
  div.io.req.bits.op := f3(1, 0)
  div.io.req.bits.a  := rs1v
  div.io.req.bits.b  := rs2v
  val divStall = isDiv && !div.io.resp.valid   // waiting: retire nothing this cycle

  // ---------------- F extension ----------------
  fdec.io.inst := inst
  fdec.io.frm  := csr.io.frm
  val isF    = fdec.io.isF
  val fOk    = isF && !fdec.io.illegal
  val fLoad  = fOk && fdec.io.load
  val fStore = fOk && fdec.io.store
  val fMem   = fLoad || fStore
  frf.io.rs1 := inst(19, 15)
  frf.io.rs2 := inst(24, 20)
  frf.io.rs3 := inst(31, 27)
  val frs1v = frf.io.rd1
  val frs2v = frf.io.rd2
  val frs3v = frf.io.rd3

  val useFpu = fOk && fdec.io.useFpu
  fpu.io.req.valid   := useFpu && !fpu.io.busy
  fpu.io.req.bits.op := fdec.io.fpuOp
  fpu.io.req.bits.rm := fdec.io.rm
  fpu.io.req.bits.a  := Mux(fdec.io.intSrc, rs1v, frs1v)
  fpu.io.req.bits.b  := frs2v
  fpu.io.req.bits.c  := frs3v
  val fpuStall = useFpu && !fpu.io.resp.valid
  val stall    = divStall || fpuStall

  fmisc.io.op     := fdec.io.miscOp
  fmisc.io.funct3 := f3
  fmisc.io.a      := frs1v
  fmisc.io.b      := frs2v

  // FLW: rs1 + I-immediate; FSW: rs1 + S-immediate
  val fImm  = Mux(fStore, Cat(Fill(20, inst(31)), inst(31, 25), inst(11, 7)), Cat(Fill(20, inst(31)), inst(31, 20)))
  val fAddr = rs1v + fImm

  // ---------------- execute ----------------
  val aluA = WireDefault(rs1v)
  switch(dec.io.aluSrcA) {
    is(ASrc.RS1)  { aluA := rs1v }
    is(ASrc.PC)   { aluA := pc }
    is(ASrc.ZERO) { aluA := 0.U }
  }
  alu.io.op := dec.io.aluOp
  alu.io.a  := aluA
  alu.io.b  := Mux(dec.io.aluSrcImm, imm, rs2v)
  val aluY = alu.io.y

  // branch comparator and target adders
  val eq  = rs1v === rs2v
  val lt  = rs1v.asSInt < rs2v.asSInt
  val ltu = rs1v < rs2v
  val brCond = WireDefault(false.B)
  switch(f3) {
    is("b000".U) { brCond := eq }
    is("b001".U) { brCond := !eq }
    is("b100".U) { brCond := lt }
    is("b101".U) { brCond := !lt }
    is("b110".U) { brCond := ltu }
    is("b111".U) { brCond := !ltu }
  }
  val brTaken    = dec.io.branch && brCond
  val pcPlus4    = pc + 4.U
  val brTarget   = pc + imm                           // branches and JAL
  val jalrTarget = Cat(aluY(31, 1), 0.U(1.W))         // rs1 + imm, bit 0 cleared
  val ctlTaken   = brTaken || dec.io.jal || dec.io.jalr
  val ctlTarget  = Mux(dec.io.jalr, jalrTarget, brTarget)

  // ---------------- data access ----------------
  val size    = Mux(fMem, 2.U, dec.io.memSize)
  val memAddr = Mux(fMem, fAddr, aluY)
  val misalignedAccess = (size === 2.U && memAddr(1, 0) =/= 0.U) || (size === 1.U && memAddr(0))
  val loadMis  = (dec.io.memRead || fLoad) && misalignedAccess
  val storeMis = (dec.io.memWrite || fStore) && misalignedAccess
  val fetchMis = ctlTaken && ctlTarget(1)

  // ---------------- CSR / traps ----------------
  val rs1Field = inst(19, 15)
  csr.io.addr   := inst(31, 20)
  csr.io.en     := dec.io.csr
  csr.io.op     := f3(1, 0)
  csr.io.src    := Mux(f3(2), Cat(0.U(27.W), rs1Field), rs1v)
  csr.io.wrEn   := f3(1, 0) === 1.U || rs1Field =/= 0.U

  // The eight M-extension instructions are legal even though the Stage 3 decoder flags funct7 = 0000001.
  // ... and so are the RV32F instructions (FDecoder checks their encodings and rounding modes).
  val illegal = (dec.io.illegal && !isMulDiv && !isF) || (isF && fdec.io.illegal) || csr.io.illegal
  val trapNow = illegal || dec.io.ecall || dec.io.ebreak || loadMis || storeMis || fetchMis

  // A division never traps (it is legal and does not touch memory), but keep the divider consistent anyway.
  div.io.kill := trapNow
  fpu.io.kill := trapNow

  val cause = PriorityMux(Seq(
    illegal         -> Cause.IllegalInstruction.U(4.W),
    dec.io.ecall    -> Cause.EcallFromM.U(4.W),
    dec.io.ebreak   -> Cause.Breakpoint.U(4.W),
    loadMis         -> Cause.LoadAddrMisaligned.U(4.W),
    storeMis        -> Cause.StoreAddrMisaligned.U(4.W),
    fetchMis        -> Cause.InstrAddrMisaligned.U(4.W)
  ))
  val tval = PriorityMux(Seq(
    illegal                -> inst,
    dec.io.ecall           -> 0.U(32.W),
    dec.io.ebreak          -> pc,
    (loadMis || storeMis)  -> memAddr,
    fetchMis               -> ctlTarget
  ))

  val retire = !trapNow && !stall

  csr.io.commit    := retire           // no CSR side effects (e.g. minstret) while waiting for the divider or FPU
  csr.io.trapEnter := trapNow
  csr.io.trapCause := Cat(0.U(28.W), cause)
  csr.io.trapPc    := pc
  csr.io.trapVal   := tval
  csr.io.mretEnter := dec.io.mret && !trapNow

  // ---------------- next pc ----------------
  val nextPc = Mux(trapNow, csr.io.mtvecBase,
               Mux(stall, pc,
               Mux(dec.io.mret, csr.io.mepc,
               Mux(ctlTaken, ctlTarget, pcPlus4))))
  pc := nextPc

  // ---------------- load / store datapath ----------------
  val rdata = io.dmem.rdata
  val bytes = VecInit(Seq.tabulate(4)(k => rdata(8 * k + 7, 8 * k)))
  val b     = bytes(memAddr(1, 0))
  val h     = Mux(memAddr(1), rdata(31, 16), rdata(15, 0))
  val uns   = dec.io.memUnsigned
  val loadData = WireDefault(rdata)
  switch(size) {
    is(0.U) { loadData := Mux(uns, Cat(0.U(24.W), b), Cat(Fill(24, b(7)), b)) }
    is(1.U) { loadData := Mux(uns, Cat(0.U(16.W), h), Cat(Fill(16, h(15)), h)) }
    is(2.U) { loadData := rdata }
  }

  val storeSrc = Mux(fStore, frs2v, rs2v)
  val sbyte = storeSrc(7, 0)
  val shalf = storeSrc(15, 0)
  val wdata = WireDefault(storeSrc)
  val wstrb = WireDefault("b1111".U(4.W))
  switch(size) {
    is(0.U) { wdata := Fill(4, sbyte); wstrb := (1.U(4.W) << memAddr(1, 0))(3, 0) }
    is(1.U) { wdata := Fill(2, shalf); wstrb := Mux(memAddr(1), "b1100".U(4.W), "b0011".U(4.W)) }
  }

  io.dmem.addr  := memAddr
  io.dmem.re    := (dec.io.memRead || fLoad) && !trapNow
  io.dmem.we    := (dec.io.memWrite || fStore) && !trapNow
  io.dmem.wdata := wdata
  io.dmem.wstrb := Mux(io.dmem.we, wstrb, 0.U)

  // ---------------- write-back ----------------
  val wbData = WireDefault(aluY)
  switch(dec.io.wbSel) {
    is(WbSel.ALU) { wbData := aluY }
    is(WbSel.MEM) { wbData := loadData }
    is(WbSel.PC4) { wbData := pcPlus4 }
    is(WbSel.CSR) { wbData := csr.io.rdata }
  }
  when(isMul) { wbData := mul.io.result }            // last connect wins
  when(isDiv) { wbData := div.io.resp.bits }
  // F instructions writing x[rd]: FCVT.W(U).S (FPU), FMV.X.W, FEQ/FLT/FLE and FCLASS (FpMisc)
  val fXval = Mux(useFpu, fpu.io.resp.bits.bits, Mux(fdec.io.mvXW, frs1v, fmisc.io.result))
  val fWritesX = fOk && fdec.io.writesX
  when(fWritesX) { wbData := fXval }
  val rd = Mux(isMulDiv || isF, inst(11, 7), dec.io.rd)
  rf.io.we    := (dec.io.regWrite || isMulDiv || fWritesX) && retire
  rf.io.waddr := rd
  rf.io.wdata := wbData
  val writes = rf.io.we && rd =/= 0.U

  // F instructions writing f[rd]: FLW, the FPU (except FCVT.W(U).S), FSGNJ*, FMIN/FMAX (FpMisc), FMV.W.X
  val fVal = Mux(fLoad, rdata, Mux(useFpu, fpu.io.resp.bits.bits, Mux(fdec.io.mvWX, rs1v, fmisc.io.result)))
  frf.io.we    := fOk && fdec.io.writesF && retire
  frf.io.waddr := inst(11, 7)
  frf.io.wdata := fVal
  val fRaised = Mux(retire && fOk, Mux(useFpu, fpu.io.resp.bits.flags, Mux(fdec.io.useMisc, fmisc.io.flags, 0.U)), 0.U)
  csr.io.fflagsSet := fRaised

  // ---------------- trace ----------------
  io.trace.valid    := retire
  io.trace.trap     := trapNow
  io.trace.cause    := cause
  io.trace.pc       := pc
  io.trace.pcNext   := nextPc
  io.trace.inst     := inst
  io.trace.rdAddr   := Mux(writes, rd, 0.U)
  io.trace.rdData   := Mux(writes, wbData, 0.U)
  io.trace.memRe    := io.dmem.re
  io.trace.memWe    := io.dmem.we
  io.trace.memSize  := size
  io.trace.memWdata := Mux(size === 0.U, Cat(0.U(24.W), sbyte), Mux(size === 1.U, Cat(0.U(16.W), shalf), storeSrc))
  io.trace.memAddr  := memAddr
  io.trace.fdWe     := frf.io.we
  io.trace.fdAddr   := Mux(frf.io.we, inst(11, 7), 0.U)
  io.trace.fdData   := Mux(frf.io.we, fVal, 0.U)
  io.trace.fflags   := fRaised

  // ---------------- assertions (compiled out of synthesis builds) ----------------
  assert(pc(1, 0) === 0.U, "pc must stay 4-byte aligned")
  assert(!(io.trace.valid && io.trace.trap), "retire and trap in the same cycle")
  assert(!(io.dmem.we && io.dmem.re), "simultaneous load and store")
  assert(!(trapNow && (rf.io.we || frf.io.we || io.dmem.we || fRaised =/= 0.U)), "trapping instruction modifies state")
  assert(!(stall && (rf.io.we || frf.io.we || io.dmem.we || io.dmem.re || trapNow)), "state changed while waiting for the divider or FPU")
  assert(!(stall && nextPc =/= pc), "pc moved while waiting for the divider or FPU")
}
