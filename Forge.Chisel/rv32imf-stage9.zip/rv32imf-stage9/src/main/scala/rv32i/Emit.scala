package rv32i

import java.io.File
import java.nio.file.{Files, Paths}
import scala.annotation.nowarn

/** Generates SystemVerilog for the Stage 9 `Core`, the `Fpu` on its own, and for `RV32ITestWrapper` (with program.hex and data.hex)
  * into generated/. Run: sbt "runMain rv32i.Emit"
  *
  * Chisel 3.6 hands Verilog generation to CIRCT's firtool, which must be on the PATH
  * (target: firtool 1.37.0, https://github.com/llvm/circt/releases/tag/firtool-1.37.0).
  * Without firtool it falls back to Chisel 3's built-in (legacy, deprecated) Scala FIRRTL compiler,
  * so you still get Verilog; the firtool options only apply on the firtool path.
  */
object Emit extends App {
  val firtoolOnPath = sys.env.getOrElse("PATH", "").split(File.pathSeparator)
    .exists(dir => new File(dir, "firtool").canExecute)

  def emit(name: String, gen: => chisel3.RawModule): Unit =
    if (firtoolOnPath)
      circt.stage.ChiselStage.emitSystemVerilogFile(gen, Array("--target-dir", "generated"),
        Array("-disable-all-randomization", "-strip-debug-info"))
    else {
      Console.err.println(s"$name: firtool not found on PATH, using the legacy Scala FIRRTL compiler (firtool options not applied).")
      emitLegacy(name, gen)
    }

  @nowarn("cat=deprecation") // the legacy compiler is deprecated in Chisel 3.6; it is only the fallback
  private def emitLegacy(name: String, gen: => chisel3.RawModule): Unit = {
    val sv = (new chisel3.stage.ChiselStage).emitSystemVerilog(gen, Array("--target-dir", "generated"))
    Files.createDirectories(Paths.get("generated"))
    Files.write(Paths.get("generated", s"$name.sv"), sv.getBytes("UTF-8"))
  }

  emit("Core", new Core())
  emit("Fpu", new Fpu())
  emit("RV32ITestWrapper", new RV32ITestWrapper("program.hex", "data.hex"))
}
