package rv32i

import chisel3._
import chisel3.util._

/** Operations of the sequential FPU (everything in RV32F that has to round). */
object FpuOp {
  val width    = 4
  val ADD      = 0
  val SUB      = 1
  val MUL      = 2
  val DIV      = 3
  val SQRT     = 4
  val MADD     = 5  // (a * b) + c
  val MSUB     = 6  // (a * b) - c
  val NMSUB    = 7  // -(a * b) + c
  val NMADD    = 8  // -(a * b) - c
  val CVT_W_S  = 9  // float -> signed int
  val CVT_WU_S = 10 // float -> unsigned int
  val CVT_S_W  = 11 // signed int -> float   (operand a is the integer)
  val CVT_S_WU = 12 // unsigned int -> float
  val names = Seq("fadd", "fsub", "fmul", "fdiv", "fsqrt", "fmadd", "fmsub", "fnmsub", "fnmadd",
    "fcvt.w.s", "fcvt.wu.s", "fcvt.s.w", "fcvt.s.wu")

  /** Clock edges from the accepting edge to the response cycle, when no special case applies. */
  def latency(op: Int): Int = op match {
    case ADD | SUB                  => 5          // unpack, add, normalize, round
    case MUL | MADD | MSUB | NMSUB | NMADD => 29  // unpack, 24 x multiply, add, normalize, round
    case DIV | SQRT                 => 31         // unpack, 27 x divide / square-root step, normalize, round
    case CVT_W_S | CVT_WU_S         => 3          // unpack, convert
    case CVT_S_W | CVT_S_WU         => 4          // unpack, normalize, round
  }
  /** Special operands (NaN, infinity, zero cases, x / 0, ...) are answered right after unpacking. */
  val SpecialLatency = 2
}

class FpuReq extends Bundle {
  val op = UInt(FpuOp.width.W)
  val rm = UInt(3.W)  // already resolved: 0..4 (the core replaces DYN by frm and traps on invalid modes)
  val a  = UInt(32.W) // rs1 (a float, or the integer for FCVT.S.W/WU)
  val b  = UInt(32.W) // rs2
  val c  = UInt(32.W) // rs3 (fused multiply-add)
}

class FpuResp extends Bundle {
  val bits  = UInt(32.W) // float result, or the integer for FCVT.W.S/WU.S
  val flags = UInt(5.W)  // NV DZ OF UF NX (fcsr.fflags order)
}

/** An unpacked binary32 operand. `sig` is normalized (bit 23 set) for every nonzero finite value, subnormals
  * included, and `exp` is the exponent of that leading bit: value = sig * 2^(exp - 23). */
class FpOperand extends Bundle {
  val sign = Bool()
  val zero = Bool()
  val inf  = Bool()
  val nan  = Bool()
  val snan = Bool()
  val sig  = UInt(24.W)
  val exp  = SInt(13.W)
}

object FpUnpack {
  def apply(x: UInt): FpOperand = {
    val w  = Wire(new FpOperand)
    val ef = x(30, 23)
    val f  = x(22, 0)
    w.sign := x(31)
    w.zero := ef === 0.U && f === 0.U
    w.inf  := ef.andR && f === 0.U
    w.nan  := ef.andR && f =/= 0.U
    w.snan := w.nan && !f(22)
    val raw = Cat(ef =/= 0.U, f)
    val lz  = PriorityEncoder(Reverse(raw))           // leading zeros (only meaningful for raw =/= 0)
    w.sig := (raw << lz)(23, 0)
    val eLsb = Mux(ef === 0.U, (-149).S(13.W), ef.zext.pad(13) - 150.S(13.W))
    w.exp := eLsb + 23.S(13.W) - lz.zext.pad(13)
    w
  }
}

/** Sequential single-precision FPU: FADD, FSUB, FMUL, FDIV, FSQRT, the four fused multiply-adds and the four
  * integer conversions, IEEE 754 binary32 with the five RISC-V rounding modes and the five exception flags.
  *
  * Structure (one state machine, one result path):
  *  - unpack: classify the operands; special cases (NaN, infinity, invalid, divide by zero, zeros) finish here
  *  - multiply: 24 shift-and-add steps give the exact 48-bit product (FMUL and the fused multiply-adds)
  *  - add: align the smaller operand with 3 extra bits (guard, round, sticky), add or subtract (FADD, FSUB, FMA)
  *  - divide: 27 restoring steps give 27 quotient bits; the remainder becomes the sticky bit
  *  - square root: 27 digit-by-digit steps give 27 root bits; the remainder becomes the sticky bit
  *  - normalize: count leading zeros and shift the raw result to a 56-bit significand
  *  - round: round to 24 bits (normal) or to the subnormal grid; overflow, underflow (tininess after rounding),
  *    inexact
  *  - convert to integer: round to an integer, saturate out-of-range values and NaN, raise NV or NX
  *
  * Handshake as the divider: a request is accepted only while idle; `resp.valid` lasts one cycle and `busy` stays
  * high through it, so a stalled core holding the same instruction cannot start it twice; `kill` abandons it.
  * Latencies: [[FpuOp.latency]] (2 for special cases; 3 for an ADD/SUB whose result is an exact zero, and 27 for a
  * fused multiply-add whose result is an exact zero).
  */
class Fpu extends Module {
  val io = IO(new Bundle {
    val req  = Flipped(Decoupled(new FpuReq))
    val resp = Valid(new FpuResp)
    val kill = Input(Bool())
    val busy = Output(Bool())
  })

  val sIdle :: sUnpack :: sMul :: sAdd :: sDiv :: sSqrt :: sNorm :: sRound :: sToInt :: sDone :: Nil = Enum(10)
  val state = RegInit(sIdle)

  val op = Reg(UInt(FpuOp.width.W))
  val rm = Reg(UInt(3.W))
  val ra = Reg(UInt(32.W))
  val rb = Reg(UInt(32.W))
  val rc = Reg(UInt(32.W))

  io.req.ready  := state === sIdle
  io.busy       := state =/= sIdle
  io.resp.valid := state === sDone

  when(io.req.fire) {
    op := io.req.bits.op; rm := io.req.bits.rm
    ra := io.req.bits.a; rb := io.req.bits.b; rc := io.req.bits.c
    state := sUnpack
  }

  // ---------------------------------------------------------------- operands and operation classes
  val A = FpUnpack(ra)
  val B = FpUnpack(rb)
  val C = FpUnpack(rc)
  private def is(o: Int*): Bool = o.map(op === _.U).reduce(_ || _)
  val isAddSub = is(FpuOp.ADD, FpuOp.SUB)
  val isMul    = is(FpuOp.MUL)
  val isFma    = is(FpuOp.MADD, FpuOp.MSUB, FpuOp.NMSUB, FpuOp.NMADD)
  val isDiv    = is(FpuOp.DIV)
  val isSqrt   = is(FpuOp.SQRT)
  val isToInt  = is(FpuOp.CVT_W_S, FpuOp.CVT_WU_S)
  val isFromInt = is(FpuOp.CVT_S_W, FpuOp.CVT_S_WU)
  val negProd  = is(FpuOp.NMSUB, FpuOp.NMADD)
  val negC     = is(FpuOp.MSUB, FpuOp.NMADD)

  val NaN = "h7fc00000".U(32.W)
  def inf(s: Bool): UInt  = Cat(s, "h7f800000".U(31.W))
  def zero(s: Bool): UInt = Cat(s, 0.U(31.W))
  def flag(f: Int): UInt  = f.U(5.W)
  def roundInc(sign: Bool, lsb: Bool, r: Bool, st: Bool): Bool = MuxLookup(rm, false.B)(Seq(
    Rm.RNE.U -> (r && (st || lsb)),
    Rm.RTZ.U -> false.B,
    Rm.RDN.U -> (sign && (r || st)),
    Rm.RUP.U -> (!sign && (r || st)),
    Rm.RMM.U -> r
  ))

  // ---------------------------------------------------------------- datapath registers
  val xSign = Reg(Bool()); val xZero = Reg(Bool()); val xSig = Reg(UInt(48.W)); val xExp = Reg(SInt(13.W))
  val ySign = Reg(Bool()); val yZero = Reg(Bool()); val ySig = Reg(UInt(48.W)); val yExp = Reg(SInt(13.W))
  val acc      = Reg(UInt(48.W))   // product
  val mcand    = Reg(UInt(48.W))
  val mplier   = Reg(UInt(24.W))
  val count    = Reg(UInt(5.W))
  val rem      = Reg(UInt(31.W))   // divider / square-root partial remainder
  val quo      = Reg(UInt(27.W))   // quotient / root bits
  val divisor  = Reg(UInt(24.W))
  val radicand = Reg(UInt(54.W))
  val raw      = Reg(UInt(56.W))   // unrounded magnitude: raw * 2^rawE (+ sticky)
  val rawE     = Reg(SInt(13.W))
  val sticky   = Reg(Bool())
  val rSign    = Reg(Bool())
  val nSig     = Reg(UInt(56.W))   // normalized: bit 55 set, value = nSig / 2^55 * 2^nExp
  val nExp     = Reg(SInt(13.W))
  val resBits  = Reg(UInt(32.W))
  val resFlags = Reg(UInt(5.W))

  def finish(bits: UInt, flags: UInt): Unit = { resBits := bits; resFlags := flags; state := sDone }
  def S(v: Int): SInt = v.S(13.W)

  // ---------------------------------------------------------------- unpack: special cases, set up the datapath
  when(state === sUnpack) {
    sticky := false.B
    when(isAddSub) {
      val sb = B.sign ^ is(FpuOp.SUB)
      when(A.nan || B.nan) { finish(NaN, Mux(A.snan || B.snan, flag(FFlags.NV), 0.U)) }
        .elsewhen(A.inf && B.inf) { finish(Mux(A.sign === sb, inf(A.sign), NaN), Mux(A.sign === sb, 0.U, flag(FFlags.NV))) }
        .elsewhen(A.inf) { finish(inf(A.sign), 0.U) }
        .elsewhen(B.inf) { finish(inf(sb), 0.U) }
        .elsewhen(A.zero && B.zero) { finish(zero(Mux(A.sign === sb, A.sign, rm === Rm.RDN.U)), 0.U) }
        .otherwise {
          xSign := A.sign; xZero := A.zero; xSig := Cat(A.sig, 0.U(24.W)); xExp := A.exp
          ySign := sb;     yZero := B.zero; ySig := Cat(B.sig, 0.U(24.W)); yExp := B.exp
          state := sAdd
        }
    }.elsewhen(isMul || isFma) {
      val ps = A.sign ^ B.sign ^ negProd
      val cs = C.sign ^ negC
      val infTimesZero = (A.inf && B.zero) || (A.zero && B.inf)
      when(infTimesZero) { finish(NaN, flag(FFlags.NV)) }                        // even if c is a quiet NaN
        .elsewhen(A.nan || B.nan || (isFma && C.nan)) {
          finish(NaN, Mux(A.snan || B.snan || (isFma && C.snan), flag(FFlags.NV), 0.U))
        }
        .elsewhen(A.inf || B.inf) {
          when(isFma && C.inf && cs =/= ps) { finish(NaN, flag(FFlags.NV)) }.otherwise { finish(inf(ps), 0.U) }
        }
        .elsewhen(isFma && C.inf) { finish(inf(cs), 0.U) }
        .elsewhen((A.zero || B.zero) && (isMul || C.zero)) {
          finish(zero(Mux(isMul || ps === cs, ps, rm === Rm.RDN.U)), 0.U)
        }
        .otherwise {
          acc := 0.U; mcand := A.sig; mplier := B.sig; count := 0.U
          xSign := ps; xZero := A.zero || B.zero; xExp := A.exp + B.exp
          ySign := cs; yZero := isMul || C.zero; ySig := Cat(C.sig, 0.U(24.W)); yExp := C.exp
          state := sMul
        }
    }.elsewhen(isDiv) {
      val s = A.sign ^ B.sign
      when(A.nan || B.nan) { finish(NaN, Mux(A.snan || B.snan, flag(FFlags.NV), 0.U)) }
        .elsewhen((A.zero && B.zero) || (A.inf && B.inf)) { finish(NaN, flag(FFlags.NV)) }
        .elsewhen(A.inf) { finish(inf(s), 0.U) }
        .elsewhen(B.inf) { finish(zero(s), 0.U) }
        .elsewhen(B.zero) { finish(inf(s), flag(FFlags.DZ)) }
        .elsewhen(A.zero) { finish(zero(s), 0.U) }
        .otherwise {
          rem := A.sig; divisor := B.sig; quo := 0.U; count := 0.U
          rSign := s; rawE := A.exp - B.exp - S(26)
          state := sDiv
        }
    }.elsewhen(isSqrt) {
      when(A.nan) { finish(NaN, Mux(A.snan, flag(FFlags.NV), 0.U)) }
        .elsewhen(A.zero) { finish(ra, 0.U) }                                     // sqrt(+-0) = +-0
        .elsewhen(A.sign) { finish(NaN, flag(FFlags.NV)) }
        .elsewhen(A.inf) { finish(inf(false.B), 0.U) }
        .otherwise {
          val e0  = A.exp - S(23)                                                  // exponent of the LSB of sig
          val odd = e0(0)
          val m   = Mux(odd, Cat(A.sig, 0.U(1.W)), Cat(0.U(1.W), A.sig))          // 25 bits, exponent now even
          val e1  = Mux(odd, e0 - S(1), e0)
          radicand := Cat(0.U(1.W), m, 0.U(28.W))                                  // m * 2^28, 54 bits = 27 pairs
          rem := 0.U; quo := 0.U; count := 0.U
          rSign := false.B; rawE := (e1 >> 1) - S(14)
          state := sSqrt
        }
    }.elsewhen(isToInt) {
      state := sToInt
    }.otherwise { // isFromInt
      val neg = is(FpuOp.CVT_S_W) && ra(31)
      val mag = Mux(neg, 0.U(32.W) - ra, ra)
      when(mag === 0.U) { finish(0.U, 0.U) }.otherwise {
        raw := mag; rawE := S(0); rSign := neg
        state := sNorm
      }
    }
  }

  // ---------------------------------------------------------------- multiply: 24 shift-and-add steps
  when(state === sMul) {
    acc    := acc + Mux(mplier(0), mcand, 0.U)
    mcand  := mcand << 1
    mplier := mplier >> 1
    count  := count + 1.U
    when(count === 23.U) { state := sAdd }
  }

  // ---------------------------------------------------------------- add / subtract with guard, round, sticky
  when(state === sAdd) {
    val prodTop = acc(47)
    val sigX = Mux(isAddSub, xSig, Mux(prodTop, acc, acc << 1)(47, 0))
    val expX = Mux(isAddSub, xExp, Mux(prodTop, xExp + S(1), xExp))
    val xBig = !xZero && (yZero || expX > yExp || (expX === yExp && sigX >= ySig))
    val bigSig   = Mux(xBig, sigX, ySig)
    val bigExp   = Mux(xBig, expX, yExp)
    val bigSign  = Mux(xBig, xSign, ySign)
    val smallSig = Mux(xBig, ySig, sigX)
    val smallExp = Mux(xBig, yExp, expX)
    val smallSign = Mux(xBig, ySign, xSign)
    val smallAbsent = Mux(xBig, yZero, xZero)
    val d   = (bigExp - smallExp).asUInt
    val dC  = Mux(d > 63.U, 63.U(6.W), d(5, 0))
    val smallExt = Cat(smallSig, 0.U(3.W))                                         // 51 bits
    val lost     = (smallExt & ((1.U(64.W) << dC) - 1.U)(50, 0)).orR
    val smallAl  = Mux(smallAbsent, 0.U, (smallExt >> dC) | lost)
    val bigExt   = Cat(bigSig, 0.U(3.W))
    val sum = Mux(bigSign =/= smallSign, bigExt - smallAl, bigExt +& smallAl)      // 52 bits, >= 0
    when(sum === 0.U) { finish(zero(rm === Rm.RDN.U), 0.U) }                       // exact cancellation
      .otherwise {
        raw := sum; rawE := bigExp - S(50); rSign := bigSign
        state := sNorm
      }
  }

  // ---------------------------------------------------------------- divide: 27 restoring steps
  when(state === sDiv) {
    val ge = rem >= divisor
    val r1 = Mux(ge, rem - divisor, rem)
    val q  = Cat(quo(25, 0), ge)
    quo   := q
    rem   := r1 << 1
    count := count + 1.U
    when(count === 26.U) { raw := q; sticky := r1 =/= 0.U; state := sNorm }
  }

  // ---------------------------------------------------------------- square root: 27 digit-by-digit steps
  when(state === sSqrt) {
    val remN = Cat(rem(28, 0), radicand(53, 52))                                  // 31 bits
    val t    = Cat(quo, 1.U(2.W))                                                 // (root << 2) | 1
    val ge   = remN >= t
    val remNext = Mux(ge, remN - t, remN)
    val q    = Cat(quo(25, 0), ge)
    rem      := remNext
    quo      := q
    radicand := radicand << 2
    count    := count + 1.U
    when(count === 26.U) { raw := q; sticky := remNext =/= 0.U; state := sNorm }
  }

  // ---------------------------------------------------------------- normalize
  when(state === sNorm) {
    val lz = PriorityEncoder(Reverse(raw))
    nSig  := (raw << lz)(55, 0)
    nExp  := rawE + S(55) - lz.zext.pad(13)
    state := sRound
  }

  // ---------------------------------------------------------------- round
  when(state === sRound) {
    // unbounded exponent, 24-bit precision (also decides tininess after rounding)
    val keep = nSig(55, 32)
    val rb   = nSig(31)
    val st   = nSig(30, 0).orR || sticky
    val k25  = keep +& roundInc(rSign, keep(0), rb, st)
    val carry = k25(24)
    val eU   = nExp + Mux(carry, S(1), S(0))
    val tiny = eU < S(-126)
    // overflow result: infinity or the largest finite value, by rounding direction
    val toInf = MuxLookup(rm, true.B)(Seq(Rm.RTZ.U -> false.B, Rm.RDN.U -> rSign, Rm.RUP.U -> !rSign))
    val ovBits = Cat(rSign, Mux(toInf, "h7f800000".U(31.W), "h7f7fffff".U(31.W)))
    when(nExp >= S(-126)) {
      val biased = eU + S(127)
      val inexact = rb || st
      when(biased >= S(255)) { finish(ovBits, flag(FFlags.OF | FFlags.NX)) }
        .otherwise {
          finish(Cat(rSign, biased.asUInt(7, 0), Mux(carry, 0.U(23.W), k25(22, 0))), Mux(inexact, flag(FFlags.NX), 0.U))
        }
    }.otherwise {
      // subnormal range: shift right to the 2^-149 grid, then round
      val sh  = (S(-126) - nExp).asUInt
      val shC = Mux(sh > 31.U, 31.U(5.W), sh(4, 0))
      val lostS = (nSig & ((1.U(57.W) << shC) - 1.U)(55, 0)).orR
      val shifted = nSig >> shC
      val sKeep = shifted(55, 32)
      val sRb   = shifted(31)
      val sSt   = shifted(30, 0).orR || lostS || sticky
      val q     = sKeep +& roundInc(rSign, sKeep(0), sRb, sSt)                    // <= 2^23 (smallest normal)
      val inexact = sRb || sSt
      finish(Cat(rSign, q.pad(31)(30, 0)),
        Mux(inexact, flag(FFlags.NX), 0.U) | Mux(tiny && inexact, flag(FFlags.UF), 0.U))
    }
  }

  // ---------------------------------------------------------------- float to integer
  when(state === sToInt) {
    val signed = is(FpuOp.CVT_W_S)
    val s = A.sign
    val maxS = "h7fffffff".U(32.W); val minS = "h80000000".U(32.W); val maxU = "hffffffff".U(32.W)
    when(A.nan) { finish(Mux(signed, maxS, maxU), flag(FFlags.NV)) }
      .elsewhen(A.inf) { finish(Mux(s, Mux(signed, minS, 0.U), Mux(signed, maxS, maxU)), flag(FFlags.NV)) }
      .elsewhen(A.zero) { finish(0.U, 0.U) }
      .otherwise {
        val e    = A.exp
        val huge = e >= S(33)                                                      // |value| >= 2^33
        val left = e >= S(23)
        val magL = (A.sig << (e - S(23)).asUInt(3, 0))(33, 0)                       // e in 23..32: exact
        val rsh  = (S(23) - e).asUInt
        val rshC = Mux(rsh > 25.U, 25.U(5.W), rsh(4, 0))
        val ext  = Cat(A.sig, 0.U(26.W)) >> rshC                                   // 50 bits
        val kept = ext(49, 26)
        val rbit = ext(25)
        val stl  = ext(24, 0).orR
        val magR = kept +& roundInc(s, kept(0), rbit, stl)
        val mag  = Mux(left, magL, magR.pad(34))
        val inexact = !left && (rbit || stl)
        val nv = huge || Mux(signed, Mux(s, mag > "h80000000".U, mag > "h7fffffff".U),
                                     Mux(s, mag =/= 0.U, mag > "hffffffff".U))
        val sat = Mux(signed, Mux(s, minS, maxS), Mux(s, 0.U, maxU))
        val value = Mux(s, (0.U(34.W) - mag)(31, 0), mag(31, 0))
        finish(Mux(nv, sat, value), Mux(nv, flag(FFlags.NV), Mux(inexact, flag(FFlags.NX), 0.U)))
      }
  }

  when(state === sDone) { state := sIdle }
  when(io.kill) { state := sIdle }

  io.resp.bits.bits  := resBits
  io.resp.bits.flags := resFlags
}
