# Design notes: Stage 9, single-cycle RV32IMF core with a sequential FPU

## Architecture

| Item | Choice |
|---|---|
| ISA | RV32IMF (40 + 8 + 26 instructions) + Zicsr (6) + MRET and WFI, machine mode only |
| Microarchitecture | Single cycle, no pipeline: fetch, decode, execute, memory and write-back in one clock; multi-cycle units stall the core |
| Floating point | IEEE 754 binary32, the five RISC-V rounding modes (RNE, RTZ, RDN, RUP, RMM) plus dynamic (frm), the five exception flags (NV, DZ, OF, UF, NX) accrued in fcsr, canonical NaN, tininess after rounding |
| Register files | x0..x31 (x0 = 0) and f0..f31 (no hardwired register, three read ports) |
| Single-cycle FP | `FpMisc`: sign injection, min/max, compares, class; FMV.X.W / FMV.W.X are wires; FLW/FSW use the data port |
| Sequential FP | `Fpu`: one state machine for every operation that rounds: add/subtract, multiply, fused multiply-add, divide, square root, conversions |
| Multiplication / division (integer) | As in Stage 5: combinational 33 × 33 multiplier; sequential divider (34 cycles) |
| Memories, reset, interrupts | As in Stage 5: zero-wait Harvard ports, pc = `0x80000000`, no interrupts |

## Stage progression

| Stage | Instructions | New hardware |
|---|---|---|
| 1 | R-type and I-type ALU (19) | ALU, register file, decoder, immediate generator |
| 2 | + loads, JALR | Read-only data memory, load alignment |
| 3 | All of RV32I + Zicsr | Stores, branches, LUI/AUIPC/JAL, CSR file, precise exceptions |
| 4 | + MUL, MULH, MULHSU, MULHU | Combinational multiplier |
| 5 | + DIV, DIVU, REM, REMU | Sequential divider |
| 6, 7, 8 | Same ISA | 2-stage pipeline, 5-stage pipeline, I-cache and D-cache |
| **9** | **+ the F extension (26 instructions)** | **f registers, fcsr, single-cycle `FpMisc`, sequential `Fpu` (on the single-cycle Stage 5 core)** |

## The sequential FPU

```
            ┌────────┐  special case (NaN, inf, zero, x/0, invalid) ───────────────────────────┐
 request ──►│ UNPACK │──► MUL (24 steps) ──► ADD ──┐                                              │
            └────────┘──► ADD ─────────────────────┤                                              ▼
                      ──► DIV  (27 steps) ─────────┼──► NORM ──► ROUND ──────────────────────► DONE ──► response
                      ──► SQRT (27 steps) ─────────┤                                              ▲
                      ──► (int → float) ───────────┘                                              │
                      ──► TOINT (float → int) ────────────────────────────────────────────────────┘
```

| State | Work |
|---|---|
| UNPACK | Classify the operands (zero, subnormal, normal, infinity, quiet/signaling NaN); normalize every significand to 24 bits with the leading 1 at bit 23 (subnormals included, by a leading-zero count); answer the special cases directly; set up the datapath |
| MUL | 24 shift-and-add steps: the exact 48-bit product of the two significands (FMUL and the fused multiply-adds) |
| ADD | Normalize the product to bit 47 (or take a·2^24 for FADD/FSUB), pick the larger operand by exponent then significand, shift the smaller right with 3 extra bits (guard, round and a sticky bit that ORs everything shifted out), add or subtract; an exact zero finishes here with the IEEE sign rule |
| DIV | 27 restoring steps on the normalized significands: q = ⌊a·2^26 / b⌋ (26 or 27 bits); the remainder ≠ 0 becomes the sticky bit |
| SQRT | Make the exponent even (shift the significand by one), then 27 digit-by-digit steps on m·2^28: ⌊√⌋ with 26 or 27 bits; the remainder ≠ 0 becomes the sticky bit |
| NORM | Leading-zero count and shift: a 56-bit significand with its leading 1 at bit 55, and the exponent of that bit |
| ROUND | Round to 24 bits (normal range) or to the 2^−149 grid (subnormal range) in the requested mode; overflow to infinity or the largest finite value by rounding direction (OF, NX); underflow (UF) when the result is tiny after rounding with an unbounded exponent and inexact; NX when inexact |
| TOINT | Round to an integer in the requested mode; NaN and out-of-range values saturate (0x7fffffff / 0x80000000 / 0xffffffff / 0) and raise NV, otherwise NX when inexact |
| DONE | `resp.valid` for one cycle with the result and the flags |

Latencies (clock edges from the accepting edge to the response; the core spends that many extra cycles):

| Operation | Latency |
|---|---|
| FADD, FSUB | 5 |
| FMUL, FMADD, FMSUB, FNMSUB, FNMADD | 29 |
| FDIV, FSQRT | 31 |
| FCVT.W.S, FCVT.WU.S | 3 |
| FCVT.S.W, FCVT.S.WU | 4 |
| Any special case | 2 |
| Exact-zero sum | 3 (FADD/FSUB), 27 (fused multiply-add) |

Why the three extra bits are enough: the operands of the adder carry 48 significant bits and the result is rounded to
24, so the guard and round bits plus a sticky bit placed below them give the correctly rounded sum (a large shift
loses only bits that the sticky bit summarizes; a large cancellation happens only for shifts of 0 or 1, which lose
nothing). Why 27 quotient and root bits are enough: the result then has at least 26 significant bits, so its round bit
is inside the computed bits and the remainder-based sticky bit lies below it.

Special cases decided in UNPACK (the RISC-V rules):

| Case | Result | Flags |
|---|---|---|
| Any NaN operand | Canonical NaN `0x7fc00000` | NV if one is signaling |
| ∞ − ∞, 0 × ∞, 0 / 0, ∞ / ∞, √(negative) | Canonical NaN | NV |
| Fused multiply-add with 0 × ∞ | Canonical NaN, even if the addend is a quiet NaN | NV |
| x / 0 (x finite, nonzero) | ±∞ | DZ |
| √(−0) | −0 | – |
| Exact zero sum | +0, or −0 when both addends are −0 or the rounding mode is RDN | – |

## Execution rules

Every cycle is exactly one of:

1. **retire** (`trace.valid`): one instruction completes; its x or f write, its store and the flags it raised take
   effect at the edge (fflags |= raised);
2. **trap** (`trace.trap`): the instruction changes nothing except mepc, mcause, mtval, mstatus and the pc;
3. **wait** (both low): a division or a rounding FP operation is in progress; nothing changes, the instruction stays on
   the fetch port; the FPU's `busy` stays high through its response cycle, so it cannot be started twice.

Exception priority: illegal instruction (2) > ECALL (11) > EBREAK (3) > load misaligned (4) > store misaligned (6) >
instruction address misaligned (0).

## Choices made where the specification leaves an option

| Topic | Choice | Why |
|---|---|---|
| Which FP operations are sequential | Everything that rounds (add, multiply, divide, square root, fused multiply-add, conversions); the rest in one cycle | The rounding datapath is shared by all of them; the non-rounding operations are a few gates |
| FPU algorithms | Shift-and-add multiplier (1 bit/cycle), restoring division and digit-by-digit square root (1 bit/cycle), one shared normalizer and rounder | Small and easy to verify; latencies are fixed per operation |
| mstatus.FS | Hardwired to 11 (Dirty), SD = 1 | Always-present FP state; no lazy context switching in machine mode only |
| Reserved rounding modes | rm = 5 or 6, or rm = 7 with frm ≥ 5: illegal instruction | Required by the spec |
| fcsr bits | frm (7:5) and fflags (4:0) kept, the rest read 0 | Required (bits 31:8 reserved) |
| Flag accrual | The flags of a retiring instruction are ORed into fflags at its edge; a CSR write in the same cycle is impossible (one instruction per cycle) | Single-cycle core |
| NaN results | Always the canonical NaN; FSGNJ*, FMV and FLW/FSW move bit patterns unchanged | RISC-V rules |
| Tininess | After rounding | RISC-V rule |
| FMIN/FMAX | −0 < +0; one NaN → the other operand; two NaNs → canonical NaN; NV on signaling NaN | F extension v2.2 |
| Misaligned FLW/FSW | Trap (cause 4 / 6, mtval = address) | Same as the integer loads and stores |
| Non-S formats (D, H, Q), FLD/FSD, FCVT.L | Illegal instruction | Only RV32F is implemented |
| FPU kill | Tied to `trapNow` | An FP instruction that starts never traps; a safety net for interrupts |
| misa | `0x40001120` (RV32, I, M, F), writes ignored | Everything implemented |
| Integer side, CSRs, memories | As in Stage 5 | Unchanged |

## Verification

- `FpRefSpec`: the software reference against the JVM's correctly rounded binary32 arithmetic on 200,000 random
  operand sets weighted towards zeros, subnormals, tiny and huge values, infinities and NaNs (FADD, FSUB, FMUL, FDIV,
  FSQRT via double, both kinds of fused multiply-add via `Math.fma`), integer↔float conversions, then the RISC-V cases
  by hand: flags, canonical NaN, the four other rounding modes, overflow, underflow and tininess after rounding,
  saturating conversions.
- `FpuSpec`: the hardware FPU against `FpRef`, bit for bit with the flags, in all rounding modes, plus exact latencies
  and 35 corner cases in every rounding mode; `FPU_TESTS=n` scales the random part (the default keeps the suite to a
  few minutes; it was also run with 10,000 FADD/FSUB and 4,000 fused multiply-adds).
- `FpMiscSpec`: the single-cycle unit against `FpRef` on 20,000 operand pairs.
- `CoreFpSpec`: the whole core in lockstep with `RefModel`, which compares every retirement field by field (x write,
  f write, memory access, trap, raised flags): special operands in every rounding mode, single-cycle operations, FLW/FSW
  and misaligned traps, fcsr, illegal encodings and rounding modes, 1,500 random mixed instructions, exact stall
  cycles; `MemorySpec` runs `program.hex` with every result and the exact cycle count.
- The Stage 5 suites (integer instructions, divider, CSRs, traps, timing) all still pass with the F extension present.
- Planted bugs, each planted alone; every one makes the suite fail:

| Planted bug | Caught by |
|---|---|
| Round to nearest even never rounds up on a tie with an odd last bit | `FpuSpec` (3 tests) |
| Tininess detected before rounding instead of after | `FpuSpec` (2 tests) |
| Bits shifted out by the aligner not kept in the sticky bit | `FpuSpec` (2 tests) |
| Square root of an odd exponent without doubling the significand | `FpuSpec` (corner cases) |
| Division remainder not used as the sticky bit | `FpuSpec` |
| 0 × ∞ in a fused multiply-add checked after the NaN case (no NV with a quiet-NaN addend) | `FpuSpec` (corner cases) |
| FCVT.WU.S of any negative value flagged invalid (−0.5 must give 0 with NX only) | `FpuSpec` (2 tests) |
| Raised flags not accrued into fflags | `MemorySpec` (and `CoreFpSpec`) |
| FSW storing an x register instead of the f register | `MemorySpec` (and `CoreFpSpec`) |
