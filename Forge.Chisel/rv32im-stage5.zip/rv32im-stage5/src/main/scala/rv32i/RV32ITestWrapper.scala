package rv32i

import chisel3._

/** Stage 3 system: Core + InstructionMemory (program at 0x80000000) + DataMemory RAM (at 0x80010000). */
class RV32ITestWrapper(programFile: String, dataFile: String = "", dataDepth: Int = 256) extends Module {
  val io = IO(new Bundle {
    val trace = Output(new Trace)
  })
  val core = Module(new Core())
  val imem = Module(new InstructionMemory(programFile))
  val dmem = Module(new DataMemory(dataFile, dataDepth))

  imem.io.addr       := core.io.imem.addr
  core.io.imem.data  := imem.io.inst
  dmem.io.addr       := core.io.dmem.addr
  dmem.io.we         := core.io.dmem.we
  dmem.io.wdata      := core.io.dmem.wdata
  dmem.io.wstrb      := core.io.dmem.wstrb
  core.io.dmem.rdata := dmem.io.rdata
  io.trace := core.io.trace
}
