package rv32i

import chisel3._

/** RISC-V major opcodes (inst[6:0]) used by this core. */
object Opcode {
  val LOAD     = 0x03
  val MISC_MEM = 0x0f
  val OP_IMM   = 0x13
  val AUIPC    = 0x17
  val STORE    = 0x23
  val OP       = 0x33
  val LUI      = 0x37
  val BRANCH   = 0x63
  val JALR     = 0x67
  val JAL      = 0x6f
  val SYSTEM   = 0x73
}

/** mcause exception codes (interrupt bit = 0). */
object Cause {
  val InstrAddrMisaligned = 0
  val IllegalInstruction  = 2
  val Breakpoint          = 3
  val LoadAddrMisaligned  = 4
  val StoreAddrMisaligned = 6
  val EcallFromM          = 11
}

/** CSR addresses implemented by [[CsrFile]]. */
object CsrAddr {
  val mstatus   = 0x300
  val misa      = 0x301
  val mie       = 0x304
  val mtvec     = 0x305
  val mstatush  = 0x310
  val mscratch  = 0x340
  val mepc      = 0x341
  val mcause    = 0x342
  val mtval     = 0x343
  val mip       = 0x344
  val mcycle    = 0xb00
  val minstret  = 0xb02
  val mcycleh   = 0xb80
  val minstreth = 0xb82
  val cycle     = 0xc00
  val instret   = 0xc02
  val cycleh    = 0xc80
  val instreth  = 0xc82
  val mvendorid = 0xf11
  val marchid   = 0xf12
  val mimpid    = 0xf13
  val mhartid   = 0xf14

  /** misa for RV32IM: MXL = 1 (bits 31:30), I = bit 8, M = bit 12. */
  val MisaValue = 0x40001100L
}

/** First ALU operand. */
object ASrc extends ChiselEnum {
  val RS1, PC, ZERO = Value
}

/** Write-back source. */
object WbSel extends ChiselEnum {
  val ALU, MEM, PC4, CSR = Value
}

/** Immediate format. */
object ImmSel extends ChiselEnum {
  val I, S, B, U, J = Value
}

/** ALU operation. */
object AluOp extends ChiselEnum {
  val ADD, SUB, SLL, SLT, SLTU, XOR, SRL, SRA, OR, AND = Value
}

/** Instruction port: zero-wait, `data` is a combinational function of `addr`. */
class InstrMemPort extends Bundle {
  val addr = Output(UInt(32.W))
  val data = Input(UInt(32.W))
}

/** Data port: zero-wait. `rdata` is the aligned word at `addr & ~3`, a combinational function of `addr`.
  * A store writes the bytes selected by `wstrb` of `wdata` (already shifted into byte lanes) at the clock edge.
  */
class DataMemPort extends Bundle {
  val addr  = Output(UInt(32.W))
  val re    = Output(Bool())
  val we    = Output(Bool())
  val wdata = Output(UInt(32.W))
  val wstrb = Output(UInt(4.W))
  val rdata = Input(UInt(32.W))
}

/** Per-cycle retirement trace. `valid`: an instruction retired. `trap`: an exception was taken.
  * Both low: the core is waiting for the divider (nothing changed in that cycle).
  */
class Trace extends Bundle {
  val valid    = Bool()
  val trap     = Bool()
  val cause    = UInt(4.W)
  val pc       = UInt(32.W)
  val pcNext   = UInt(32.W)
  val inst     = UInt(32.W)
  val rdAddr   = UInt(5.W)   // 0 when no register is written
  val rdData   = UInt(32.W)  // 0 when no register is written
  val memAddr  = UInt(32.W)
  val memRe    = Bool()
  val memWe    = Bool()
  val memSize  = UInt(2.W)   // 0 byte, 1 half, 2 word
  val memWdata = UInt(32.W)  // store data, not shifted into lanes
}
