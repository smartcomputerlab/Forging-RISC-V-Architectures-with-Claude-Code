package rv32i

import chisel3._
import chisel3.util._

/** Data RAM mapped at `base` (`depth` words), optionally initialised from a hex file (empty name: all zero).
  * Combinational read of the aligned word at `addr & ~3`; a store writes the byte lanes selected by `wstrb` of `wdata`
  * at the clock edge. Accesses outside [base, base + 4 * depth) read 0 and are not written.
  * (Built from registers so that it simulates and synthesises with an initial content everywhere; replace it with a
  * block RAM for large memories.)
  */
class DataMemory(fileName: String = "", depth: Int = 256, base: Long = 0x80010000L) extends Module {
  val io = IO(new Bundle {
    val addr  = Input(UInt(32.W))
    val we    = Input(Bool())
    val wdata = Input(UInt(32.W))
    val wstrb = Input(UInt(4.W))
    val rdata = Output(UInt(32.W))
  })
  val words: Seq[BigInt] = if (fileName.isEmpty) Seq.empty else InstructionMemory.readHex(fileName)
  require(words.length <= depth, s"Data memory file '$fileName' has ${words.length} words, but depth is only $depth")

  val mem   = RegInit(VecInit(words.map(_.U(32.W)) ++ Seq.fill(depth - words.length)(0.U(32.W))))
  val index = ((io.addr - base.U(32.W)) >> 2)(log2Ceil(depth) - 1, 0)
  val hit   = io.addr >= base.U(32.W) && ((io.addr - base.U(32.W)) >> 2) < depth.U
  val old   = mem(index)
  io.rdata := Mux(hit, old, 0.U)

  when(io.we && hit) {
    mem(index) := Cat((3 to 0 by -1).map(k => Mux(io.wstrb(k), io.wdata(8 * k + 7, 8 * k), old(8 * k + 7, 8 * k))))
  }
}
