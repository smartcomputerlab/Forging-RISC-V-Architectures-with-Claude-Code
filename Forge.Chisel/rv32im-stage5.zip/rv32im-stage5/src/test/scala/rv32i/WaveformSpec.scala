package rv32i

import chisel3._
import chiseltest._
import firrtl.options.TargetDirAnnotation
import org.scalatest.flatspec.AnyFlatSpec
import org.scalatest.matchers.should.Matchers

import java.nio.file.{Files, Path, Paths}

/** Writes VCD waveforms of short demo programs into waves/<name>/ for GTKWave: the VCD, a session (core.gtkw), an
  * instruction translate filter (inst.filter) and a listing (program.lst). Every run is checked against RefModel,
  * so a waveform is only written for a correct run.
  */
class WaveformSpec extends AnyFlatSpec with ChiselScalatestTester with Matchers {
  private val Data = 0x80010000L
  private def annos(dir: Path) = Seq(WriteVcdAnnotation, TargetDirAnnotation(dir.toString))

  private def sideFiles(dir: Path, words: Seq[Long], base: Long, vcd: String, top: String): Unit = {
    Files.write(dir.resolve("program.lst"), Disasm.listing(words, base).getBytes("UTF-8"))
    Gtkw.writeFilter(dir, "inst.filter",
      (words.zipWithIndex.map { case (w, k) => w -> Disasm(w, base + 4L * k) } :+ (0L -> "(empty)")).distinctBy(_._1), 8)
    Gtkw.writeMulFnFilter(dir); Gtkw.writeDivStateFilter(dir); Gtkw.writeDivOpFilter(dir)
    Gtkw.write(dir, vcd, "core.gtkw", Gtkw.coreGroups(top))
  }

  private def demoCore(name: String, a: Asm): CoreSim.Result = {
    val dir = Paths.get("waves", name); Files.createDirectories(dir)
    var res: CoreSim.Result = null
    test(new Core()).withAnnotations(annos(dir)) { c => res = CoreSim.run(c, a.words) }
    sideFiles(dir, a.words, a.base, "Core.vcd", "Core")
    res
  }

  private def vcd(dir: String, module: String): Path = Paths.get("waves", dir, s"$module.vcd")

  "Waveforms" should "show the Stage 5 demo (program.hex + data.hex) on RV32ITestWrapper (waves/stage5_demo)" in {
    val dir = Paths.get("waves", "stage5_demo"); Files.createDirectories(dir)
    val prog = InstructionMemory.readHex("program.hex").map(_.toLong)
    val regs = Array.fill(32)(0L)
    test(new RV32ITestWrapper("program.hex", "data.hex")).withAnnotations(annos(dir)) { dut =>
      dut.clock.setTimeout(0)
      var cycles = 0
      while (!(dut.io.trace.valid.peek().litToBoolean && dut.io.trace.inst.peek().litValue == Asm.Halt)) {
        dut.io.trace.trap.expect(false.B)
        assert(cycles < 1000)
        val rd = dut.io.trace.rdAddr.peek().litValue.toInt
        if (rd != 0) regs(rd) = dut.io.trace.rdData.peek().litValue.toLong
        dut.clock.step(); cycles += 1
        assert(cycles < 200)
      }
      dut.clock.step(2)
    }
    regs(14) shouldBe 0xffffffecL; regs(20) shouldBe 0x40000000L; regs(26) shouldBe 0xfffffffaL; regs(28) shouldBe 0x5555554eL
    sideFiles(dir, prog, 0x80000000L, "RV32ITestWrapper.vcd", "RV32ITestWrapper.core")
    Files.exists(vcd("stage5_demo", "RV32ITestWrapper")) shouldBe true
  }

  it should "show LUI, AUIPC, JAL and all six branches (waves/upper_jumps)" in {
    val a = new Asm
    a.lui(1, 0x12345); a.addi(1, 1, 0x678)            // x1 = 0x12345678
    a.auipc(2, 0)                                      // x2 = pc
    a.li(3, -1); a.li(4, 1)
    a.beq(3, 3, "b1"); a.addi(20, 20, 1); a.label("b1")
    a.bne(3, 4, "b2"); a.addi(20, 20, 1); a.label("b2")
    a.blt(3, 4, "b3"); a.addi(20, 20, 1); a.label("b3")
    a.bge(4, 3, "b4"); a.addi(20, 20, 1); a.label("b4")
    a.bltu(4, 3, "b5"); a.addi(20, 20, 1); a.label("b5")
    a.bgeu(3, 4, "b6"); a.addi(20, 20, 1); a.label("b6")
    a.beq(3, 4, "never"); a.addi(21, 21, 1)            // not taken
    a.jal(5, "far"); a.addi(20, 20, 1)
    a.label("far"); a.addi(22, 0, 7)
    a.label("never"); a.halt()
    val r = demoCore("upper_jumps", a)
    r.model.x(1) shouldBe 0x12345678L
    r.model.x(20) shouldBe 0
    r.model.x(21) shouldBe 1
    Files.exists(vcd("upper_jumps", "Core")) shouldBe true
  }

  it should "show loads, stores, a loop and a call (waves/load_store_branch)" in {
    val a = new Asm
    a.li(10, Data)
    a.li(1, 0); a.li(2, 5); a.li(3, 0)
    a.label("loop"); a.addi(1, 1, 1); a.add(3, 3, 1); a.sw(3, 0, 10); a.addi(10, 10, 4); a.blt(1, 2, "loop")
    a.lw(4, -4, 10); a.lbu(5, -4, 10); a.sh(4, 2, 10); a.lh(6, 2, 10)
    a.jal(1, "func"); a.halt()
    a.label("func"); a.addi(7, 0, 42); a.jalr(0, 1, 0)
    val r = demoCore("load_store_branch", a)
    r.model.x(3) shouldBe 15
    r.model.x(7) shouldBe 42
    Files.exists(vcd("load_store_branch", "Core")) shouldBe true
  }

  it should "show the four multiplications on corner values, each in one cycle (waves/mul)" in {
    val a = new Asm
    a.li(1, 0x80000000L); a.li(2, -1); a.li(3, 7); a.li(4, -7); a.li(5, 0x12345678L)
    a.mul(10, 3, 4); a.mulh(11, 3, 4); a.mulhsu(12, 4, 3); a.mulhu(13, 3, 4)
    a.mul(14, 1, 2); a.mulh(15, 1, 1); a.mulhsu(16, 2, 1); a.mulhu(17, 2, 2)
    a.mul(18, 5, 5); a.mulhu(19, 5, 5)
    a.add(20, 10, 13)                   // a multiplication result used by the next instruction
    a.halt()
    val r = demoCore("mul", a)
    r.model.x(10) shouldBe ((-49L) & 0xFFFFFFFFL)
    r.model.x(17) shouldBe 0xfffffffeL
    r.events.forall(_.cycles == 1) shouldBe true
    Files.exists(vcd("mul", "Core")) shouldBe true
  }

  it should "show DIV/REM waiting on the sequential divider and MUL in one cycle (waves/div_rem)" in {
    val a = new Asm
    a.li(1, -100); a.li(2, 7); a.li(7, 0); a.li(8, 0x80000000L); a.li(9, -1)
    a.div(3, 1, 2)       // -14, 34 cycles
    a.rem(4, 1, 2)       // -2
    a.divu(5, 1, 2)
    a.div(6, 1, 7)       // divide by zero: -1, 2 cycles
    a.rem(10, 8, 9)      // overflow MIN % -1: 0, 2 cycles
    a.mul(11, 1, 2)      // -700, 1 cycle
    a.add(12, 3, 4)      // uses the division results
    a.halt()
    val r = demoCore("div_rem", a)
    r.model.x(3) shouldBe ((-14L) & 0xFFFFFFFFL)
    r.model.x(4) shouldBe ((-2L) & 0xFFFFFFFFL)
    r.stallCycles shouldBe (3 * 33 + 2 * 1)
    Files.exists(vcd("div_rem", "Core")) shouldBe true
  }

  it should "show the divider on its own: request, 32 iterations, response (waves/div_unit)" in {
    val dir = Paths.get("waves", "div_unit"); Files.createDirectories(dir)
    test(new DivUnit(32)).withAnnotations(annos(dir)) { c =>
      c.io.kill.poke(false.B)
      c.clock.step(2)
      for ((op, a, b) <- Seq((0, -1000L, 7L), (2, -1000L, 7L), (1, 1000L, 0L))) {
        c.io.req.valid.poke(true.B); c.io.req.bits.op.poke(op.U)
        c.io.req.bits.a.poke((a & 0xFFFFFFFFL).U(32.W)); c.io.req.bits.b.poke((b & 0xFFFFFFFFL).U(32.W))
        c.clock.step()
        c.io.req.valid.poke(false.B)
        while (!c.io.resp.valid.peek().litToBoolean) c.clock.step()
        c.io.resp.bits.expect((DivRef(op, BigInt(a & 0xFFFFFFFFL), BigInt(b)) & 0xFFFFFFFFL).U(32.W))
        c.clock.step(2)
      }
    }
    Gtkw.writeDivStateFilter(dir); Gtkw.writeDivOpFilter(dir)
    Gtkw.write(dir, "DivUnit.vcd", "divunit.gtkw", Seq(
      Gtkw.Group("Clock", Seq(Gtkw.Sig("DivUnit.clock", 1, Gtkw.Bin), Gtkw.Sig("DivUnit.reset", 1, Gtkw.Bin),
        Gtkw.Sig("DivUnit.io_kill", 1, Gtkw.Bin))),
      Gtkw.divGroup("DivUnit"),
      Gtkw.Group("Result register", Seq(Gtkw.Sig("DivUnit.result", 32, Gtkw.SDec)))))
    Files.exists(vcd("div_unit", "DivUnit")) shouldBe true
  }

  it should "show an ECALL, an illegal instruction (FENCE.I), the handler and MRET (waves/trap)" in {
    val a = new Asm
    a.la(1, "handler"); a.csrrw(0, CsrAddr.mtvec, 1)
    a.li(2, 5)
    a.ecall()
    a.addi(2, 2, 1)
    a.word(0x0000100fL)                 // FENCE.I: illegal (Zifencei is not implemented)
    a.addi(2, 2, 1)
    a.halt()
    a.label("handler")
    a.csrrs(3, CsrAddr.mcause, 0); a.csrrs(4, CsrAddr.mepc, 0)
    a.addi(4, 4, 4); a.csrrw(0, CsrAddr.mepc, 4)
    a.mret()
    val r = demoCore("trap", a)
    r.traps shouldBe 2
    r.model.x(2) shouldBe 7
    r.model.x(3) shouldBe Cause.IllegalInstruction
    Files.exists(vcd("trap", "Core")) shouldBe true
  }
}
