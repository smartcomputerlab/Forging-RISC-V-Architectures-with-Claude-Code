#!/usr/bin/env python3
"""GTKWave translate filter *process* for RV32IM + Zicsr instruction words.

GTKWave writes one value per line on stdin (as the trace is formatted, e.g. hex "0220C1B3")
and reads one line of text per value on stdout. Use it on any 32-bit instruction signal:
right-click the trace -> Data Format -> Translate Filter Process -> Enable and Select -> this file.
Branch and jump targets are shown as offsets (pc+N), because the filter only sees the word.
"""
import sys

CSR = {0x300: "mstatus", 0x301: "misa", 0x304: "mie", 0x305: "mtvec", 0x310: "mstatush", 0x340: "mscratch",
       0x341: "mepc", 0x342: "mcause", 0x343: "mtval", 0x344: "mip", 0xb00: "mcycle", 0xb02: "minstret",
       0xb80: "mcycleh", 0xb82: "minstreth", 0xc00: "cycle", 0xc02: "instret", 0xc80: "cycleh",
       0xc82: "instreth", 0xf11: "mvendorid", 0xf12: "marchid", 0xf13: "mimpid", 0xf14: "mhartid"}


def sext(v, bits):
    return v - (1 << bits) if v & (1 << (bits - 1)) else v


def disasm(w):
    op, rd, f3 = w & 0x7f, (w >> 7) & 31, (w >> 12) & 7
    rs1, rs2, f7 = (w >> 15) & 31, (w >> 20) & 31, (w >> 25) & 0x7f
    x = lambda r: f"x{r}"
    immI = sext(w >> 20, 12)
    immS = sext(((w >> 25) << 5) | ((w >> 7) & 31), 12)
    immB = sext((((w >> 31) & 1) << 12) | (((w >> 7) & 1) << 11) | (((w >> 25) & 0x3f) << 5) | (((w >> 8) & 0xf) << 1), 13)
    immJ = sext((((w >> 31) & 1) << 20) | (((w >> 12) & 0xff) << 12) | (((w >> 20) & 1) << 11) | (((w >> 21) & 0x3ff) << 1), 21)
    off = lambda o: f"pc{o:+d}"
    if w == 0x13: return "nop"
    if w == 0x6f: return "halt (j .)"
    if op == 0x37: return f"lui {x(rd)}, 0x{w >> 12:x}"
    if op == 0x17: return f"auipc {x(rd)}, 0x{w >> 12:x}"
    if op == 0x6f: return f"jal {x(rd)}, {off(immJ)}"
    if op == 0x67 and f3 == 0: return f"jalr {x(rd)}, {immI}({x(rs1)})"
    if op == 0x63 and f3 not in (2, 3):
        return f"{['beq','bne','','','blt','bge','bltu','bgeu'][f3]} {x(rs1)}, {x(rs2)}, {off(immB)}"
    if op == 0x03 and f3 in (0, 1, 2, 4, 5): return f"{['lb','lh','lw','','lbu','lhu'][f3]} {x(rd)}, {immI}({x(rs1)})"
    if op == 0x23 and f3 <= 2: return f"{['sb','sh','sw'][f3]} {x(rs2)}, {immS}({x(rs1)})"
    if op == 0x13:
        if f3 == 1 and f7 == 0: return f"slli {x(rd)}, {x(rs1)}, {rs2}"
        if f3 == 5 and f7 in (0, 0x20): return f"{'srai' if f7 else 'srli'} {x(rd)}, {x(rs1)}, {rs2}"
        if f3 not in (1, 5): return f"{['addi','','slti','sltiu','xori','','ori','andi'][f3]} {x(rd)}, {x(rs1)}, {immI}"
    if op == 0x33 and f7 == 1:
        return f"{['mul','mulh','mulhsu','mulhu','div','divu','rem','remu'][f3]} {x(rd)}, {x(rs1)}, {x(rs2)}"
    if op == 0x33 and (f7 == 0 or (f7 == 0x20 and f3 in (0, 5))):
        n = {(0, 0x20): "sub", (5, 0x20): "sra"}.get((f3, f7)) or ["add","sll","slt","sltu","xor","srl","or","and"][f3]
        return f"{n} {x(rd)}, {x(rs1)}, {x(rs2)}"
    if op == 0x0f and f3 == 0: return "fence"
    if op == 0x73:
        fixed = {0x73: "ecall", 0x100073: "ebreak", 0x30200073: "mret", 0x10500073: "wfi"}
        if w in fixed: return fixed[w]
        if f3 not in (0, 4):
            name = ['', 'csrrw', 'csrrs', 'csrrc', '', 'csrrwi', 'csrrsi', 'csrrci'][f3]
            csr = w >> 20
            src = str(rs1) if f3 >= 5 else x(rs1)
            return f"{name} {x(rd)}, {CSR.get(csr, hex(csr))}, {src}"
    return f"illegal 0x{w:08x}"


def main():
    for line in sys.stdin:                    # one value per line from GTKWave
        v = line.strip()
        try:
            out = disasm(int(v, 16) & 0xFFFFFFFF)
        except ValueError:                    # x / z / not hex: echo it unchanged
            out = v
        sys.stdout.write(out + "\n")
        sys.stdout.flush()                    # GTKWave waits for each answer


if __name__ == "__main__":
    main()
