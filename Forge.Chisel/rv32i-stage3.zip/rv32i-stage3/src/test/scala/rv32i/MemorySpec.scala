package rv32i

import chisel3._
import chiseltest._
import org.scalatest.flatspec.AnyFlatSpec
import java.nio.file.{Files, Paths}

class MemorySpec extends AnyFlatSpec with ChiselScalatestTester {
  "InstructionMemory" should "map the program at 0x80000000 and read 0 outside it" in {
    val words = InstructionMemory.readHex("program.hex")
    assert(words.length == 16 && words.head == BigInt("80010537", 16))
    test(new InstructionMemory("program.hex", depth = 32)).withAnnotations(TestUtil.waves) { dut =>
      for ((k, w) <- words.zipWithIndex.map(_.swap).take(4)) {
        dut.io.addr.poke((0x80000000L + 4 * k).U(32.W)); dut.io.inst.expect(w.U(32.W))
      }
      for (addr <- Seq(0L, 0x7ffffffcL, 0x80000080L, 0xfffffffcL)) {
        dut.io.addr.poke(addr.U(32.W)); dut.io.inst.expect(0.U, f"address 0x$addr%08x")
      }
    }
  }

  it should "accept comments, blank lines and separators in hex files" in {
    val dir = Paths.get("test_run_dir", "hex_parse"); Files.createDirectories(dir)
    val f = dir.resolve("p.hex")
    Files.write(f, "# c\n0000_0013\n\n00a00093  # addi\n".getBytes("UTF-8"))
    assert(InstructionMemory.readHex(f.toString) == Seq(BigInt(0x13), BigInt("00a00093", 16)))
  }

  "DataMemory" should "start from data.hex, write bytes, halves and words under byte strobes, and ignore outside writes" in {
    val B = 0x80010000L
    test(new DataMemory("data.hex", depth = 16)).withAnnotations(TestUtil.waves) { dut =>
      def rd(a: Long): BigInt = { dut.io.addr.poke(a.U(32.W)); dut.io.rdata.peek().litValue }
      def wr(a: Long, d: Long, s: Int): Unit = {
        dut.io.addr.poke(a.U(32.W)); dut.io.wdata.poke(d.U(32.W)); dut.io.wstrb.poke(s.U); dut.io.we.poke(true.B)
        dut.clock.step(); dut.io.we.poke(false.B)
      }
      dut.io.we.poke(false.B)
      assert(rd(B) == 4 && rd(B + 4) == 10 && rd(B + 16) == 40 && rd(B + 20) == 0)
      assert(rd(B + 2) == 4)                                    // any byte address reads its aligned word
      wr(B + 20, 0x11223344L, 0xf); assert(rd(B + 20) == 0x11223344L)
      wr(B + 20, 0xaaaaaaaaL, 0x2); assert(rd(B + 20) == 0x1122aa44L)       // one byte lane
      wr(B + 20, 0xbbbbbbbbL, 0xc); assert(rd(B + 20) == 0xbbbbaa44L)       // upper half
      wr(B + 20, 0x12345678L, 0x0); assert(rd(B + 20) == 0xbbbbaa44L)       // no lane
      wr(B - 4, 0xffffffffL, 0xf); wr(B + 64, 0xffffffffL, 0xf)             // outside: ignored
      assert(rd(B - 4) == 0 && rd(B + 64) == 0 && rd(B) == 4 && rd(B + 60) == 0)
    }
  }

  "RV32ITestWrapper" should "run program.hex on data.hex: sum an array, store and reload it, call a function" in {
    test(new RV32ITestWrapper("program.hex", "data.hex")).withAnnotations(TestUtil.waves) { dut =>
      val regs = Array.fill(32)(0L)
      var retired = 0; var stores = 0
      while (!(dut.io.trace.valid.peek().litToBoolean && dut.io.trace.inst.peek().litValue == Asm.Halt)) {
        dut.io.trace.trap.expect(false.B)
        if (dut.io.trace.valid.peek().litToBoolean) retired += 1
        if (dut.io.trace.memWe.peek().litToBoolean) {
          stores += 1
          dut.io.trace.memAddr.expect("h80010014".U); dut.io.trace.memWdata.expect(100.U)
        }
        val rd = dut.io.trace.rdAddr.peek().litValue.toInt
        if (rd != 0) regs(rd) = dut.io.trace.rdData.peek().litValue.toLong
        dut.clock.step()
        assert(retired < 200)
      }
      assert(regs(10) == 0x80010000L && regs(13) == 100 && regs(15) == 100)   // the reload sees the store
      assert(regs(1) == 0x80000030L && regs(16) == 200 && regs(17) == 201)
      assert(stores == 1)
      assert(retired == 4 + 4 * 5 + 6)    // 4 set-up, 4 loop iterations of 5, then sw, lw, jal, slli, jalr, addi
    }
  }
}
