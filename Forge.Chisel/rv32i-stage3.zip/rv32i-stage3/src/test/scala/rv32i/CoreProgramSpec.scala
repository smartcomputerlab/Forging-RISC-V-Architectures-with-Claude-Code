package rv32i

import chiseltest._
import org.scalatest.flatspec.AnyFlatSpec
import org.scalatest.matchers.should.Matchers
import scala.util.Random
import TestUtil._

/** Hand-assembled programs on the full core. Every retirement and trap is checked against [[RefModel]] in lockstep
  * (CoreSim), and the final register values are checked against values computed independently in the test.
  */
class CoreProgramSpec extends AnyFlatSpec with ChiselScalatestTester with Matchers {
  private val Data = 0x80010000L

  private def runAndCheck(a: Asm, expect: Map[Int, Long], data: Seq[(Long, Long)] = Nil): CoreSim.Result = {
    var res: CoreSim.Result = null
    test(new Core()).withAnnotations(TestUtil.waves) { c => res = CoreSim.run(c, a.words, data = data) }
    for ((r, v) <- expect) withClue(s"x$r: ") { res.model.x(r) shouldBe (v & M) }
    res
  }

  "Core" should "run arithmetic and logic instructions (OP, OP-IMM, LUI, AUIPC)" in {
    val a = new Asm
    val x1 = 0x12345678L; val x2 = 0xfffffffbL // -5
    a.li(1, x1); a.li(2, x2)
    a.add(3, 1, 2); a.sub(4, 1, 2); a.and(5, 1, 2); a.or(6, 1, 2); a.xor(7, 1, 2)
    a.sll(8, 1, 2); a.srl(9, 2, 2); a.sra(10, 2, 1); a.slt(11, 2, 1); a.sltu(12, 2, 1)
    a.addi(13, 1, -1); a.slti(14, 2, -4); a.sltiu(15, 2, -4); a.xori(16, 1, -1); a.ori(17, 1, 0x0f0); a.andi(18, 1, 0x7ff)
    a.slli(19, 1, 4); a.srli(20, 2, 4); a.srai(21, 2, 1); a.lui(22, 0xabcde)
    val auipcPc = a.here; a.auipc(23, 1)
    a.addi(0, 1, 5); a.add(24, 0, 0)
    a.halt()
    runAndCheck(a, Map(
      3 -> (x1 + x2), 4 -> (x1 - x2), 5 -> (x1 & x2), 6 -> (x1 | x2), 7 -> (x1 ^ x2),
      8 -> (x1 << 27), 9 -> (x2 >>> (x2 & 31)), 10 -> (s32(x2) >> (x1 & 31)), 11 -> 1, 12 -> 0,
      13 -> (x1 - 1), 14 -> 1, 15 -> 1, 16 -> ~x1, 17 -> (x1 | 0xf0), 18 -> (x1 & 0x7ff),
      19 -> (x1 << 4), 20 -> (x2 >>> 4), 21 -> (s32(x2) >> 1), 22 -> 0xabcde000L, 23 -> (auipcPc + 0x1000),
      0 -> 0, 24 -> 0))
  }

  it should "run loads and stores of every size, signed and unsigned" in {
    val a = new Asm
    a.li(1, Data); a.li(2, 0x8899aabbL)
    a.sw(2, 0, 1); a.lw(3, 0, 1)
    a.lb(4, 0, 1); a.lbu(5, 1, 1); a.lb(6, 3, 1); a.lh(7, 2, 1); a.lhu(8, 0, 1)
    a.li(9, 0x11)
    a.sb(9, 1, 1); a.lw(10, 0, 1)
    a.sh(9, 2, 1); a.lw(11, 0, 1)
    a.sw(2, -4, 1); a.lw(12, -4, 1)
    a.lw(13, 8, 1)                      // preloaded word
    a.lhu(14, 10, 1); a.lb(15, 11, 1)
    a.halt()
    runAndCheck(a, Map(
      3 -> 0x8899aabbL, 4 -> 0xffffffbbL, 5 -> 0xaaL, 6 -> 0xffffff88L, 7 -> 0xffff8899L, 8 -> 0xaabbL,
      10 -> 0x889911bbL, 11 -> 0x001111bbL, 12 -> 0x8899aabbL, 13 -> 0xcafebabeL, 14 -> 0xcafeL, 15 -> 0xffffffcaL),
      data = Seq(Data + 8 -> 0xcafebabeL))
  }

  it should "run every branch both ways, loops, JAL and JALR (incl. clearing bit 0)" in {
    val a = new Asm
    // loop: x3 = 1 + 2 + ... + 10
    a.li(1, 0); a.li(2, 10); a.li(3, 0)
    a.label("loop"); a.addi(1, 1, 1); a.add(3, 3, 1); a.blt(1, 2, "loop")
    // each case sets bit k of x11 when taken, bit k of x12 when not taken
    val cases: Seq[(String, Long, Long, Boolean)] = Seq(
      ("beq", 5, 5, true), ("beq", 5, 6, false), ("bne", 5, 6, true), ("bne", 5, 5, false),
      ("blt", -1, 1, true), ("blt", 1, -1, false), ("bge", 7, 7, true), ("bge", -2, 3, false),
      ("bltu", 1, -1, true), ("bltu", -1, 1, false), ("bgeu", -1, 1, true), ("bgeu", 1, -1, false))
    var taken = 0L; var notTaken = 0L
    for (((op, x, y, t), k) <- cases.zipWithIndex) {
      a.li(5, x); a.li(6, y); a.li(13, 1L << k)
      op match {
        case "beq" => a.beq(5, 6, s"t$k"); case "bne" => a.bne(5, 6, s"t$k")
        case "blt" => a.blt(5, 6, s"t$k"); case "bge" => a.bge(5, 6, s"t$k")
        case "bltu" => a.bltu(5, 6, s"t$k"); case _ => a.bgeu(5, 6, s"t$k")
      }
      a.or(12, 12, 13); a.jump(s"e$k")
      a.label(s"t$k"); a.or(11, 11, 13)
      a.label(s"e$k")
      if (t) taken |= 1L << k else notTaken |= 1L << k
    }
    // call / return
    val callPc = a.here; a.jal(1, "func")
    a.addi(21, 20, 1)
    // jalr to an odd address: bit 0 is cleared
    a.la(5, "odd"); a.addi(5, 5, 1); val jalrPc = a.here; a.jalr(6, 5, 0)
    a.li(22, 99)                        // skipped
    a.label("odd"); a.addi(23, 0, 42)
    a.halt()
    a.label("func"); a.addi(20, 0, 7); a.jalr(0, 1, 0)
    runAndCheck(a, Map(3 -> 55, 11 -> taken, 12 -> notTaken, 1 -> (callPc + 4), 20 -> 7, 21 -> 8,
      6 -> (jalrPc + 4), 22 -> 0, 23 -> 42))
  }

  it should "handle back-to-back dependencies, including a load result used immediately" in {
    val a = new Asm
    a.li(30, Data)
    a.li(1, 3)
    a.add(2, 1, 1); a.add(3, 2, 1); a.sll(4, 3, 1); a.sub(5, 4, 3)    // 6, 9, 72, 63
    a.sw(5, 0, 30); a.lw(6, 0, 30); a.addi(7, 6, 1)                  // 63, 64
    a.srli(8, 7, 2); a.andi(9, 7, 3); a.add(10, 8, 9)                 // 16, 0, 16
    a.slli(11, 10, 4); a.srai(12, 11, 4); a.sw(12, 4, 30); a.lw(13, 4, 30); a.xor(14, 13, 7) // 256, 16, 16, 80
    a.halt()
    runAndCheck(a, Map(2 -> 6, 3 -> 9, 4 -> 72, 5 -> 63, 6 -> 63, 7 -> 64, 8 -> 16, 9 -> 0, 10 -> 16,
      11 -> 256, 12 -> 16, 13 -> 16, 14 -> 80))
  }

  it should "run loops written in RV32I only: gcd by subtraction, a sum, and multiplication by shift-and-add" in {
    val a = new Asm
    // gcd(1071, 462) = 21, by repeated subtraction
    a.li(20, 1071); a.li(21, 462)
    a.label("gcd"); a.beq(20, 21, "gcdDone"); a.bltu(20, 21, "swap"); a.sub(20, 20, 21); a.jump("gcd")
    a.label("swap"); a.sub(21, 21, 20); a.jump("gcd")
    a.label("gcdDone")
    // 1 + 2 + ... + 100 = 5050
    a.li(22, 0); a.li(23, 100)
    a.label("sum"); a.add(22, 22, 23); a.addi(23, 23, -1); a.bne(23, 0, "sum")
    // 1234 * 5678 = 7006652, shift-and-add over the bits of the multiplier
    a.li(24, 1234); a.li(25, 5678); a.li(26, 0)
    a.label("mul"); a.andi(27, 25, 1); a.beq(27, 0, "skip"); a.add(26, 26, 24)
    a.label("skip"); a.slli(24, 24, 1); a.srli(25, 25, 1); a.bne(25, 0, "mul")
    a.halt()
    runAndCheck(a, Map(20 -> 21, 21 -> 21, 22 -> 5050, 23 -> 0, 26 -> 7006652L))
  }

  it should "treat the eight M-extension encodings as illegal instructions (cause 2, mtval = the instruction)" in {
    val a = new Asm
    a.la(1, "handler"); a.csrrw(0, CsrAddr.mtvec, 1)
    a.li(2, 6); a.li(3, 7)
    val mInsts = Seq[Asm => Unit](_.mul(4, 2, 3), _.mulh(4, 2, 3), _.mulhsu(4, 2, 3), _.mulhu(4, 2, 3),
      _.div(4, 2, 3), _.divu(4, 2, 3), _.rem(4, 2, 3), _.remu(4, 2, 3))
    mInsts.foreach(f => f(a))
    a.halt()
    a.label("handler")
    a.csrrs(5, CsrAddr.mcause, 0); a.csrrs(6, CsrAddr.mtval, 0); a.xor(7, 7, 6)   // x7 = xor of all mtval values
    a.addi(31, 31, 1)
    a.csrrs(8, CsrAddr.mepc, 0); a.addi(8, 8, 4); a.csrrw(0, CsrAddr.mepc, 8); a.mret()
    val words = a.words
    val mWords = mInsts.map(f => { val b = new Asm; f(b); b.words.head })
    val res = runAndCheck(a, Map(4 -> 0, 5 -> Cause.IllegalInstruction, 31 -> 8, 7 -> mWords.reduce(_ ^ _)))
    res.traps shouldBe 8
    mWords.foreach(w => words should contain (w))
  }

  it should "implement Zicsr and take every exception precisely (illegal, ECALL, EBREAK, misaligned load/store/fetch)" in {
    val a = new Asm
    a.la(1, "handler"); a.csrrw(0, CsrAddr.mtvec, 1)
    a.csrrs(2, CsrAddr.misa, 0); a.csrrs(3, CsrAddr.mhartid, 0)
    a.li(4, 0x55); a.csrrw(5, CsrAddr.mscratch, 4); a.csrrsi(6, CsrAddr.mscratch, 0xa)
    a.csrrci(7, CsrAddr.mscratch, 0x3); a.csrrwi(8, CsrAddr.mscratch, 0x1f); a.csrrc(9, CsrAddr.mscratch, 0)
    a.csrrs(10, CsrAddr.minstret, 0); a.csrrs(11, CsrAddr.mcycle, 0); a.csrrs(12, CsrAddr.cycle, 0)
    a.csrrsi(0, CsrAddr.mstatus, 8)     // MIE = 1
    a.ecall()
    a.ebreak()
    a.word(0xffffffffL)                 // illegal
    a.word(0x0000100fL)                 // fence.i: illegal (no Zifencei)
    a.csrrw(0, CsrAddr.cycle, 1)        // write to a read-only CSR: illegal
    a.csrrs(0, 0x7c0, 0)                // unknown CSR: illegal
    a.li(13, Data + 1)
    a.lw(14, 0, 13)                     // load misaligned (x14 not written)
    a.sw(4, 0, 13)                      // store misaligned
    a.lh(14, 0, 13)                     // load misaligned
    a.la(15, "aligned"); a.addi(15, 15, 2); a.jalr(16, 15, 0) // fetch misaligned (x16 not written)
    a.word(Enc.b(6, 0, 0, 0))           // beq x0, x0, +6: fetch misaligned
    a.label("aligned"); a.wfi(); a.fence()
    a.csrrs(17, CsrAddr.mcause, 0); a.csrrs(18, CsrAddr.mstatus, 0)
    a.lw(19, 0, 0)                      // lw from address 0: aligned, reads 0 (no access faults)
    a.halt()
    a.label("handler")
    a.csrrs(20, CsrAddr.mcause, 0); a.csrrs(21, CsrAddr.mepc, 0); a.csrrs(22, CsrAddr.mtval, 0)
    a.csrrs(24, CsrAddr.mstatus, 0)
    a.addi(31, 31, 1)
    a.li(23, 1); a.sll(23, 23, 20); a.or(30, 30, 23)
    a.addi(21, 21, 4); a.csrrw(0, CsrAddr.mepc, 21)
    a.mret()
    val causes = Seq(Cause.EcallFromM, Cause.Breakpoint, Cause.IllegalInstruction, Cause.LoadAddrMisaligned,
      Cause.StoreAddrMisaligned, Cause.InstrAddrMisaligned).map(1L << _).reduce(_ | _)
    val res = runAndCheck(a, Map(
      2 -> 0x40000100L, 3 -> 0, 5 -> 0, 6 -> 0x55, 7 -> 0x5f, 8 -> 0x5c, 9 -> 0x1f,
      14 -> 0, 16 -> 0, 17 -> Cause.InstrAddrMisaligned, 18 -> 0x1888, 19 -> 0,
      24 -> 0x1880, 31 -> 11, 30 -> causes))
    res.traps shouldBe 11
    res.model.mscratch shouldBe 0x1f
  }

  it should "match the reference model on 3000 random instructions" in {
    val r = new Random(7)
    val a = new Asm
    a.li(16, Data)
    for (k <- 1 to 15) a.li(k, rnd32(r))
    def reg = 1 + r.nextInt(15)
    def src = r.nextInt(16)
    for (_ <- 0 until 3000) r.nextInt(30) match {
      case 0 => a.add(reg, src, src);  case 1 => a.sub(reg, src, src);  case 2 => a.sll(reg, src, src)
      case 3 => a.slt(reg, src, src);  case 4 => a.sltu(reg, src, src); case 5 => a.xor(reg, src, src)
      case 6 => a.srl(reg, src, src);  case 7 => a.sra(reg, src, src);  case 8 => a.or(reg, src, src)
      case 9 => a.and(reg, src, src);  case 10 => a.addi(reg, src, r.nextInt(4096) - 2048)
      case 11 => a.slti(reg, src, r.nextInt(4096) - 2048); case 12 => a.sltiu(reg, src, r.nextInt(4096) - 2048)
      case 13 => a.xori(reg, src, r.nextInt(4096) - 2048); case 14 => a.slli(reg, src, r.nextInt(32))
      case 15 => a.srli(reg, src, r.nextInt(32)); case 16 => a.srai(reg, src, r.nextInt(32))
      case 17 => a.lui(reg, r.nextInt(1 << 20))
      case 18 => a.auipc(reg, r.nextInt(1 << 20)); case 19 => a.andi(reg, src, r.nextInt(4096) - 2048)
      case 20 => a.ori(reg, src, r.nextInt(4096) - 2048); case 21 => a.sra(reg, src, src)
      case 22 => a.lb(reg, r.nextInt(256), 16); case 23 => a.lhu(reg, 2 * r.nextInt(128), 16)
      case 24 => a.sb(src, r.nextInt(256), 16); case 25 => a.sw(src, 4 * r.nextInt(64), 16)
      case 26 => a.sw(src, 4 * r.nextInt(64), 16)
      case 27 => a.lw(reg, 4 * r.nextInt(64), 16)
      case 28 => if (r.nextBoolean()) a.sb(src, r.nextInt(256), 16) else a.lbu(reg, r.nextInt(256), 16)
      case _ => if (r.nextBoolean()) a.sh(src, 2 * r.nextInt(128), 16) else a.lh(reg, 2 * r.nextInt(128), 16)
    }
    a.halt()
    var res: CoreSim.Result = null
    test(new Core()).withAnnotations(TestUtil.waves) { c => res = CoreSim.run(c, a.words) }
    res.traps shouldBe 0
    res.retired shouldBe (2 + 30 + 3000 + 1)
  }
}
