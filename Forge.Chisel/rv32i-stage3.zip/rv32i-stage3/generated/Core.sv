module Decoder(
  input  [31:0] io_inst, // @[src/main/scala/rv32i/Decoder.scala 15:14]
  output [4:0]  io_rs1, // @[src/main/scala/rv32i/Decoder.scala 15:14]
  output [4:0]  io_rs2, // @[src/main/scala/rv32i/Decoder.scala 15:14]
  output [4:0]  io_rd, // @[src/main/scala/rv32i/Decoder.scala 15:14]
  output [2:0]  io_immSel, // @[src/main/scala/rv32i/Decoder.scala 15:14]
  output [1:0]  io_aluSrcA, // @[src/main/scala/rv32i/Decoder.scala 15:14]
  output        io_aluSrcImm, // @[src/main/scala/rv32i/Decoder.scala 15:14]
  output [3:0]  io_aluOp, // @[src/main/scala/rv32i/Decoder.scala 15:14]
  output        io_branch, // @[src/main/scala/rv32i/Decoder.scala 15:14]
  output        io_jal, // @[src/main/scala/rv32i/Decoder.scala 15:14]
  output        io_jalr, // @[src/main/scala/rv32i/Decoder.scala 15:14]
  output        io_memRead, // @[src/main/scala/rv32i/Decoder.scala 15:14]
  output        io_memWrite, // @[src/main/scala/rv32i/Decoder.scala 15:14]
  output [1:0]  io_memSize, // @[src/main/scala/rv32i/Decoder.scala 15:14]
  output        io_memUnsigned, // @[src/main/scala/rv32i/Decoder.scala 15:14]
  output [1:0]  io_wbSel, // @[src/main/scala/rv32i/Decoder.scala 15:14]
  output        io_regWrite, // @[src/main/scala/rv32i/Decoder.scala 15:14]
  output        io_csr, // @[src/main/scala/rv32i/Decoder.scala 15:14]
  output        io_ecall, // @[src/main/scala/rv32i/Decoder.scala 15:14]
  output        io_ebreak, // @[src/main/scala/rv32i/Decoder.scala 15:14]
  output        io_mret, // @[src/main/scala/rv32i/Decoder.scala 15:14]
  output        io_illegal // @[src/main/scala/rv32i/Decoder.scala 15:14]
);
  wire [6:0] opcode = io_inst[6:0]; // @[src/main/scala/rv32i/Decoder.scala 41:20]
  wire [2:0] f3 = io_inst[14:12]; // @[src/main/scala/rv32i/Decoder.scala 42:20]
  wire [6:0] f7 = io_inst[31:25]; // @[src/main/scala/rv32i/Decoder.scala 43:20]
  wire  _T_4 = f3 == 3'h0; // @[src/main/scala/rv32i/Decoder.scala 107:15]
  wire  _GEN_0 = f3 == 3'h0 ? 1'h0 : 1'h1; // @[src/main/scala/rv32i/Decoder.scala 107:24 108:22 66:18]
  wire [1:0] _GEN_2 = f3 == 3'h0 ? 2'h2 : 2'h0; // @[src/main/scala/rv32i/Decoder.scala 107:24 111:22 60:18]
  wire  _T_8 = f3 != 3'h2 & f3 != 3'h3; // @[src/main/scala/rv32i/Decoder.scala 116:23]
  wire  _GEN_3 = f3 != 3'h2 & f3 != 3'h3 ? 1'h0 : 1'h1; // @[src/main/scala/rv32i/Decoder.scala 116:38 117:20 66:18]
  wire [1:0] _GEN_5 = f3 != 3'h2 & f3 != 3'h3 ? 2'h2 : 2'h0; // @[src/main/scala/rv32i/Decoder.scala 116:38 119:20 49:18]
  wire  _T_11 = f3 == 3'h1; // @[src/main/scala/rv32i/Decoder.scala 123:29]
  wire  _T_14 = _T_4 | f3 == 3'h1 | f3 == 3'h2; // @[src/main/scala/rv32i/Decoder.scala 123:37]
  wire  _T_17 = f3 == 3'h5; // @[src/main/scala/rv32i/Decoder.scala 123:71]
  wire  _T_18 = _T_4 | f3 == 3'h1 | f3 == 3'h2 | f3 == 3'h4 | f3 == 3'h5; // @[src/main/scala/rv32i/Decoder.scala 123:65]
  wire  _GEN_6 = _T_4 | f3 == 3'h1 | f3 == 3'h2 | f3 == 3'h4 | f3 == 3'h5 ? 1'h0 : 1'h1; // @[src/main/scala/rv32i/Decoder.scala 123:80 124:22 66:18]
  wire  _GEN_8 = _T_14 ? 1'h0 : 1'h1; // @[src/main/scala/rv32i/Decoder.scala 132:52 133:22 66:18]
  wire  _shiftOk_T_1 = f7 == 7'h0; // @[src/main/scala/rv32i/Decoder.scala 140:40]
  wire  _shiftOk_T_4 = f7 == 7'h20; // @[src/main/scala/rv32i/Decoder.scala 140:82]
  wire  _shiftOk_T_6 = _T_17 ? f7 == 7'h0 | f7 == 7'h20 : 1'h1; // @[src/main/scala/rv32i/Decoder.scala 140:52]
  wire  shiftOk = _T_11 ? f7 == 7'h0 : _shiftOk_T_6; // @[src/main/scala/rv32i/Decoder.scala 140:24]
  wire  _io_aluOp_T_2 = _T_17 & f7[5]; // @[src/main/scala/rv32i/Decoder.scala 145:43]
  wire [2:0] _io_aluOp_op_T_1 = _io_aluOp_T_2 ? 3'h7 : 3'h6; // @[src/main/scala/rv32i/Decoder.scala 77:26]
  wire [3:0] _GEN_10 = 3'h7 == f3 ? 4'h9 : 4'h0; // @[src/main/scala/rv32i/Decoder.scala 71:16 79:20 70:25]
  wire [3:0] _GEN_11 = 3'h6 == f3 ? 4'h8 : _GEN_10; // @[src/main/scala/rv32i/Decoder.scala 71:16 78:20]
  wire [3:0] _GEN_12 = 3'h5 == f3 ? {{1'd0}, _io_aluOp_op_T_1} : _GEN_11; // @[src/main/scala/rv32i/Decoder.scala 71:16 77:20]
  wire [3:0] _GEN_13 = 3'h4 == f3 ? 4'h5 : _GEN_12; // @[src/main/scala/rv32i/Decoder.scala 71:16 76:20]
  wire [3:0] _GEN_14 = 3'h3 == f3 ? 4'h4 : _GEN_13; // @[src/main/scala/rv32i/Decoder.scala 71:16 75:20]
  wire [3:0] _GEN_15 = 3'h2 == f3 ? 4'h3 : _GEN_14; // @[src/main/scala/rv32i/Decoder.scala 71:16 74:20]
  wire [3:0] _GEN_16 = 3'h1 == f3 ? 4'h2 : _GEN_15; // @[src/main/scala/rv32i/Decoder.scala 71:16 73:20]
  wire [3:0] io_aluOp_op = 3'h0 == f3 ? {{3'd0}, _io_aluOp_T_2} : _GEN_16; // @[src/main/scala/rv32i/Decoder.scala 71:16 72:20]
  wire  _GEN_18 = shiftOk ? 1'h0 : 1'h1; // @[src/main/scala/rv32i/Decoder.scala 141:21 142:22 66:18]
  wire [3:0] _GEN_20 = shiftOk ? io_aluOp_op : 4'h0; // @[src/main/scala/rv32i/Decoder.scala 141:21 145:22 52:18]
  wire  altOk = _shiftOk_T_4 & (_T_4 | _T_17); // @[src/main/scala/rv32i/Decoder.scala 149:39]
  wire  _T_28 = _shiftOk_T_1 | altOk; // @[src/main/scala/rv32i/Decoder.scala 150:23]
  wire [2:0] _io_aluOp_op_T_3 = f7[5] ? 3'h7 : 3'h6; // @[src/main/scala/rv32i/Decoder.scala 77:26]
  wire [3:0] _GEN_23 = 3'h5 == f3 ? {{1'd0}, _io_aluOp_op_T_3} : _GEN_11; // @[src/main/scala/rv32i/Decoder.scala 71:16 77:20]
  wire [3:0] _GEN_24 = 3'h4 == f3 ? 4'h5 : _GEN_23; // @[src/main/scala/rv32i/Decoder.scala 71:16 76:20]
  wire [3:0] _GEN_25 = 3'h3 == f3 ? 4'h4 : _GEN_24; // @[src/main/scala/rv32i/Decoder.scala 71:16 75:20]
  wire [3:0] _GEN_26 = 3'h2 == f3 ? 4'h3 : _GEN_25; // @[src/main/scala/rv32i/Decoder.scala 71:16 74:20]
  wire [3:0] _GEN_27 = 3'h1 == f3 ? 4'h2 : _GEN_26; // @[src/main/scala/rv32i/Decoder.scala 71:16 73:20]
  wire [3:0] io_aluOp_op_1 = 3'h0 == f3 ? {{3'd0}, f7[5]} : _GEN_27; // @[src/main/scala/rv32i/Decoder.scala 71:16 72:20]
  wire  _GEN_29 = _shiftOk_T_1 | altOk ? 1'h0 : 1'h1; // @[src/main/scala/rv32i/Decoder.scala 150:33 151:21 66:18]
  wire [3:0] _GEN_31 = _shiftOk_T_1 | altOk ? io_aluOp_op_1 : 4'h0; // @[src/main/scala/rv32i/Decoder.scala 150:33 153:21 52:18]
  wire  _T_33 = io_inst == 32'h73; // @[src/main/scala/rv32i/Decoder.scala 161:19]
  wire  _GEN_33 = io_inst == 32'h73 ? 1'h0 : 1'h1; // @[src/main/scala/rv32i/Decoder.scala 161:{38,51} 66:18]
  wire  _T_34 = io_inst == 32'h100073; // @[src/main/scala/rv32i/Decoder.scala 162:19]
  wire  _GEN_35 = io_inst == 32'h100073 ? 1'h0 : _GEN_33; // @[src/main/scala/rv32i/Decoder.scala 162:{38,51}]
  wire  _T_35 = io_inst == 32'h30200073; // @[src/main/scala/rv32i/Decoder.scala 163:19]
  wire  _GEN_37 = io_inst == 32'h30200073 ? 1'h0 : _GEN_35; // @[src/main/scala/rv32i/Decoder.scala 163:{38,51}]
  wire  _GEN_39 = io_inst == 32'h10500073 ? 1'h0 : _GEN_37; // @[src/main/scala/rv32i/Decoder.scala 164:{38,51}]
  wire  _T_37 = f3 != 3'h4; // @[src/main/scala/rv32i/Decoder.scala 165:21]
  wire  _GEN_40 = f3 != 3'h4 ? 1'h0 : 1'h1; // @[src/main/scala/rv32i/Decoder.scala 165:30 166:21 66:18]
  wire [1:0] _GEN_42 = f3 != 3'h4 ? 2'h3 : 2'h0; // @[src/main/scala/rv32i/Decoder.scala 165:30 169:21 60:18]
  wire  _GEN_43 = _T_4 ? _GEN_39 : _GEN_40; // @[src/main/scala/rv32i/Decoder.scala 160:24]
  wire  _GEN_44 = _T_4 & _T_33; // @[src/main/scala/rv32i/Decoder.scala 160:24 63:18]
  wire  _GEN_45 = _T_4 & _T_34; // @[src/main/scala/rv32i/Decoder.scala 160:24 64:18]
  wire  _GEN_46 = _T_4 & _T_35; // @[src/main/scala/rv32i/Decoder.scala 160:24 65:18]
  wire  _GEN_47 = _T_4 ? 1'h0 : _T_37; // @[src/main/scala/rv32i/Decoder.scala 160:24 62:18]
  wire [1:0] _GEN_48 = _T_4 ? 2'h0 : _GEN_42; // @[src/main/scala/rv32i/Decoder.scala 160:24 60:18]
  wire  _GEN_49 = 7'h73 == opcode ? _GEN_43 : 1'h1; // @[src/main/scala/rv32i/Decoder.scala 66:18 84:18]
  wire [1:0] _GEN_54 = 7'h73 == opcode ? _GEN_48 : 2'h0; // @[src/main/scala/rv32i/Decoder.scala 60:18 84:18]
  wire  _GEN_55 = 7'hf == opcode ? _GEN_0 : _GEN_49; // @[src/main/scala/rv32i/Decoder.scala 84:18]
  wire  _GEN_56 = 7'hf == opcode ? 1'h0 : 7'h73 == opcode & _GEN_44; // @[src/main/scala/rv32i/Decoder.scala 63:18 84:18]
  wire  _GEN_57 = 7'hf == opcode ? 1'h0 : 7'h73 == opcode & _GEN_45; // @[src/main/scala/rv32i/Decoder.scala 64:18 84:18]
  wire  _GEN_58 = 7'hf == opcode ? 1'h0 : 7'h73 == opcode & _GEN_46; // @[src/main/scala/rv32i/Decoder.scala 65:18 84:18]
  wire  _GEN_59 = 7'hf == opcode ? 1'h0 : 7'h73 == opcode & _GEN_47; // @[src/main/scala/rv32i/Decoder.scala 62:18 84:18]
  wire [1:0] _GEN_60 = 7'hf == opcode ? 2'h0 : _GEN_54; // @[src/main/scala/rv32i/Decoder.scala 60:18 84:18]
  wire  _GEN_61 = 7'h33 == opcode ? _GEN_29 : _GEN_55; // @[src/main/scala/rv32i/Decoder.scala 84:18]
  wire  _GEN_62 = 7'h33 == opcode ? _T_28 : _GEN_59; // @[src/main/scala/rv32i/Decoder.scala 84:18]
  wire [3:0] _GEN_63 = 7'h33 == opcode ? _GEN_31 : 4'h0; // @[src/main/scala/rv32i/Decoder.scala 52:18 84:18]
  wire  _GEN_64 = 7'h33 == opcode ? 1'h0 : _GEN_56; // @[src/main/scala/rv32i/Decoder.scala 63:18 84:18]
  wire  _GEN_65 = 7'h33 == opcode ? 1'h0 : _GEN_57; // @[src/main/scala/rv32i/Decoder.scala 64:18 84:18]
  wire  _GEN_66 = 7'h33 == opcode ? 1'h0 : _GEN_58; // @[src/main/scala/rv32i/Decoder.scala 65:18 84:18]
  wire  _GEN_67 = 7'h33 == opcode ? 1'h0 : _GEN_59; // @[src/main/scala/rv32i/Decoder.scala 62:18 84:18]
  wire [1:0] _GEN_68 = 7'h33 == opcode ? 2'h0 : _GEN_60; // @[src/main/scala/rv32i/Decoder.scala 60:18 84:18]
  wire  _GEN_69 = 7'h13 == opcode ? _GEN_18 : _GEN_61; // @[src/main/scala/rv32i/Decoder.scala 84:18]
  wire  _GEN_70 = 7'h13 == opcode ? shiftOk : _GEN_62; // @[src/main/scala/rv32i/Decoder.scala 84:18]
  wire  _GEN_71 = 7'h13 == opcode & shiftOk; // @[src/main/scala/rv32i/Decoder.scala 51:18 84:18]
  wire [3:0] _GEN_72 = 7'h13 == opcode ? _GEN_20 : _GEN_63; // @[src/main/scala/rv32i/Decoder.scala 84:18]
  wire  _GEN_73 = 7'h13 == opcode ? 1'h0 : _GEN_64; // @[src/main/scala/rv32i/Decoder.scala 63:18 84:18]
  wire  _GEN_74 = 7'h13 == opcode ? 1'h0 : _GEN_65; // @[src/main/scala/rv32i/Decoder.scala 64:18 84:18]
  wire  _GEN_75 = 7'h13 == opcode ? 1'h0 : _GEN_66; // @[src/main/scala/rv32i/Decoder.scala 65:18 84:18]
  wire  _GEN_76 = 7'h13 == opcode ? 1'h0 : _GEN_67; // @[src/main/scala/rv32i/Decoder.scala 62:18 84:18]
  wire [1:0] _GEN_77 = 7'h13 == opcode ? 2'h0 : _GEN_68; // @[src/main/scala/rv32i/Decoder.scala 60:18 84:18]
  wire  _GEN_78 = 7'h23 == opcode ? _GEN_8 : _GEN_69; // @[src/main/scala/rv32i/Decoder.scala 84:18]
  wire  _GEN_80 = 7'h23 == opcode ? _T_14 : _GEN_71; // @[src/main/scala/rv32i/Decoder.scala 84:18]
  wire  _GEN_81 = 7'h23 == opcode ? 1'h0 : _GEN_70; // @[src/main/scala/rv32i/Decoder.scala 61:18 84:18]
  wire [3:0] _GEN_82 = 7'h23 == opcode ? 4'h0 : _GEN_72; // @[src/main/scala/rv32i/Decoder.scala 52:18 84:18]
  wire  _GEN_83 = 7'h23 == opcode ? 1'h0 : _GEN_73; // @[src/main/scala/rv32i/Decoder.scala 63:18 84:18]
  wire  _GEN_84 = 7'h23 == opcode ? 1'h0 : _GEN_74; // @[src/main/scala/rv32i/Decoder.scala 64:18 84:18]
  wire  _GEN_85 = 7'h23 == opcode ? 1'h0 : _GEN_75; // @[src/main/scala/rv32i/Decoder.scala 65:18 84:18]
  wire  _GEN_86 = 7'h23 == opcode ? 1'h0 : _GEN_76; // @[src/main/scala/rv32i/Decoder.scala 62:18 84:18]
  wire [1:0] _GEN_87 = 7'h23 == opcode ? 2'h0 : _GEN_77; // @[src/main/scala/rv32i/Decoder.scala 60:18 84:18]
  wire  _GEN_88 = 7'h3 == opcode ? _GEN_6 : _GEN_78; // @[src/main/scala/rv32i/Decoder.scala 84:18]
  wire  _GEN_90 = 7'h3 == opcode ? _T_18 : _GEN_81; // @[src/main/scala/rv32i/Decoder.scala 84:18]
  wire [1:0] _GEN_91 = 7'h3 == opcode ? {{1'd0}, _T_18} : _GEN_87; // @[src/main/scala/rv32i/Decoder.scala 84:18]
  wire  _GEN_92 = 7'h3 == opcode ? _T_18 : _GEN_80; // @[src/main/scala/rv32i/Decoder.scala 84:18]
  wire  _GEN_93 = 7'h3 == opcode ? 1'h0 : 7'h23 == opcode & _T_14; // @[src/main/scala/rv32i/Decoder.scala 57:18 84:18]
  wire [3:0] _GEN_94 = 7'h3 == opcode ? 4'h0 : _GEN_82; // @[src/main/scala/rv32i/Decoder.scala 52:18 84:18]
  wire  _GEN_95 = 7'h3 == opcode ? 1'h0 : _GEN_83; // @[src/main/scala/rv32i/Decoder.scala 63:18 84:18]
  wire  _GEN_96 = 7'h3 == opcode ? 1'h0 : _GEN_84; // @[src/main/scala/rv32i/Decoder.scala 64:18 84:18]
  wire  _GEN_97 = 7'h3 == opcode ? 1'h0 : _GEN_85; // @[src/main/scala/rv32i/Decoder.scala 65:18 84:18]
  wire  _GEN_98 = 7'h3 == opcode ? 1'h0 : _GEN_86; // @[src/main/scala/rv32i/Decoder.scala 62:18 84:18]
  wire  _GEN_99 = 7'h63 == opcode ? _GEN_3 : _GEN_88; // @[src/main/scala/rv32i/Decoder.scala 84:18]
  wire [1:0] _GEN_101 = 7'h63 == opcode ? _GEN_5 : {{1'd0}, _GEN_93}; // @[src/main/scala/rv32i/Decoder.scala 84:18]
  wire  _GEN_102 = 7'h63 == opcode ? 1'h0 : 7'h3 == opcode & _T_18; // @[src/main/scala/rv32i/Decoder.scala 56:18 84:18]
  wire  _GEN_103 = 7'h63 == opcode ? 1'h0 : _GEN_90; // @[src/main/scala/rv32i/Decoder.scala 61:18 84:18]
  wire [1:0] _GEN_104 = 7'h63 == opcode ? 2'h0 : _GEN_91; // @[src/main/scala/rv32i/Decoder.scala 60:18 84:18]
  wire  _GEN_105 = 7'h63 == opcode ? 1'h0 : _GEN_92; // @[src/main/scala/rv32i/Decoder.scala 51:18 84:18]
  wire  _GEN_106 = 7'h63 == opcode ? 1'h0 : _GEN_93; // @[src/main/scala/rv32i/Decoder.scala 57:18 84:18]
  wire [3:0] _GEN_107 = 7'h63 == opcode ? 4'h0 : _GEN_94; // @[src/main/scala/rv32i/Decoder.scala 52:18 84:18]
  wire  _GEN_108 = 7'h63 == opcode ? 1'h0 : _GEN_95; // @[src/main/scala/rv32i/Decoder.scala 63:18 84:18]
  wire  _GEN_109 = 7'h63 == opcode ? 1'h0 : _GEN_96; // @[src/main/scala/rv32i/Decoder.scala 64:18 84:18]
  wire  _GEN_110 = 7'h63 == opcode ? 1'h0 : _GEN_97; // @[src/main/scala/rv32i/Decoder.scala 65:18 84:18]
  wire  _GEN_111 = 7'h63 == opcode ? 1'h0 : _GEN_98; // @[src/main/scala/rv32i/Decoder.scala 62:18 84:18]
  wire  _GEN_112 = 7'h67 == opcode ? _GEN_0 : _GEN_99; // @[src/main/scala/rv32i/Decoder.scala 84:18]
  wire  _GEN_114 = 7'h67 == opcode ? _T_4 : _GEN_103; // @[src/main/scala/rv32i/Decoder.scala 84:18]
  wire [1:0] _GEN_115 = 7'h67 == opcode ? _GEN_2 : _GEN_104; // @[src/main/scala/rv32i/Decoder.scala 84:18]
  wire  _GEN_116 = 7'h67 == opcode ? _T_4 : _GEN_105; // @[src/main/scala/rv32i/Decoder.scala 84:18]
  wire  _GEN_117 = 7'h67 == opcode ? 1'h0 : 7'h63 == opcode & _T_8; // @[src/main/scala/rv32i/Decoder.scala 53:18 84:18]
  wire [1:0] _GEN_118 = 7'h67 == opcode ? 2'h0 : _GEN_101; // @[src/main/scala/rv32i/Decoder.scala 49:18 84:18]
  wire  _GEN_119 = 7'h67 == opcode ? 1'h0 : _GEN_102; // @[src/main/scala/rv32i/Decoder.scala 56:18 84:18]
  wire  _GEN_120 = 7'h67 == opcode ? 1'h0 : _GEN_106; // @[src/main/scala/rv32i/Decoder.scala 57:18 84:18]
  wire [3:0] _GEN_121 = 7'h67 == opcode ? 4'h0 : _GEN_107; // @[src/main/scala/rv32i/Decoder.scala 52:18 84:18]
  wire  _GEN_122 = 7'h67 == opcode ? 1'h0 : _GEN_108; // @[src/main/scala/rv32i/Decoder.scala 63:18 84:18]
  wire  _GEN_123 = 7'h67 == opcode ? 1'h0 : _GEN_109; // @[src/main/scala/rv32i/Decoder.scala 64:18 84:18]
  wire  _GEN_124 = 7'h67 == opcode ? 1'h0 : _GEN_110; // @[src/main/scala/rv32i/Decoder.scala 65:18 84:18]
  wire  _GEN_125 = 7'h67 == opcode ? 1'h0 : _GEN_111; // @[src/main/scala/rv32i/Decoder.scala 62:18 84:18]
  wire  _GEN_126 = 7'h6f == opcode ? 1'h0 : _GEN_112; // @[src/main/scala/rv32i/Decoder.scala 84:18 100:19]
  wire  _GEN_128 = 7'h6f == opcode | _GEN_114; // @[src/main/scala/rv32i/Decoder.scala 84:18 102:19]
  wire [1:0] _GEN_129 = 7'h6f == opcode ? 2'h2 : _GEN_115; // @[src/main/scala/rv32i/Decoder.scala 84:18 103:19]
  wire [2:0] _GEN_130 = 7'h6f == opcode ? 3'h4 : {{1'd0}, _GEN_118}; // @[src/main/scala/rv32i/Decoder.scala 84:18 104:19]
  wire  _GEN_131 = 7'h6f == opcode ? 1'h0 : 7'h67 == opcode & _T_4; // @[src/main/scala/rv32i/Decoder.scala 55:18 84:18]
  wire  _GEN_132 = 7'h6f == opcode ? 1'h0 : _GEN_116; // @[src/main/scala/rv32i/Decoder.scala 51:18 84:18]
  wire  _GEN_133 = 7'h6f == opcode ? 1'h0 : _GEN_117; // @[src/main/scala/rv32i/Decoder.scala 53:18 84:18]
  wire  _GEN_134 = 7'h6f == opcode ? 1'h0 : _GEN_119; // @[src/main/scala/rv32i/Decoder.scala 56:18 84:18]
  wire  _GEN_135 = 7'h6f == opcode ? 1'h0 : _GEN_120; // @[src/main/scala/rv32i/Decoder.scala 57:18 84:18]
  wire [3:0] _GEN_136 = 7'h6f == opcode ? 4'h0 : _GEN_121; // @[src/main/scala/rv32i/Decoder.scala 52:18 84:18]
  wire  _GEN_137 = 7'h6f == opcode ? 1'h0 : _GEN_122; // @[src/main/scala/rv32i/Decoder.scala 63:18 84:18]
  wire  _GEN_138 = 7'h6f == opcode ? 1'h0 : _GEN_123; // @[src/main/scala/rv32i/Decoder.scala 64:18 84:18]
  wire  _GEN_139 = 7'h6f == opcode ? 1'h0 : _GEN_124; // @[src/main/scala/rv32i/Decoder.scala 65:18 84:18]
  wire  _GEN_140 = 7'h6f == opcode ? 1'h0 : _GEN_125; // @[src/main/scala/rv32i/Decoder.scala 62:18 84:18]
  wire  _GEN_141 = 7'h17 == opcode ? 1'h0 : _GEN_126; // @[src/main/scala/rv32i/Decoder.scala 84:18 93:20]
  wire  _GEN_142 = 7'h17 == opcode | _GEN_128; // @[src/main/scala/rv32i/Decoder.scala 84:18 94:20]
  wire [2:0] _GEN_143 = 7'h17 == opcode ? 3'h3 : _GEN_130; // @[src/main/scala/rv32i/Decoder.scala 84:18 95:20]
  wire  _GEN_145 = 7'h17 == opcode | _GEN_132; // @[src/main/scala/rv32i/Decoder.scala 84:18 97:20]
  wire  _GEN_146 = 7'h17 == opcode ? 1'h0 : 7'h6f == opcode; // @[src/main/scala/rv32i/Decoder.scala 54:18 84:18]
  wire [1:0] _GEN_147 = 7'h17 == opcode ? 2'h0 : _GEN_129; // @[src/main/scala/rv32i/Decoder.scala 60:18 84:18]
  wire  _GEN_148 = 7'h17 == opcode ? 1'h0 : _GEN_131; // @[src/main/scala/rv32i/Decoder.scala 55:18 84:18]
  wire  _GEN_149 = 7'h17 == opcode ? 1'h0 : _GEN_133; // @[src/main/scala/rv32i/Decoder.scala 53:18 84:18]
  wire  _GEN_150 = 7'h17 == opcode ? 1'h0 : _GEN_134; // @[src/main/scala/rv32i/Decoder.scala 56:18 84:18]
  wire  _GEN_151 = 7'h17 == opcode ? 1'h0 : _GEN_135; // @[src/main/scala/rv32i/Decoder.scala 57:18 84:18]
  wire [3:0] _GEN_152 = 7'h17 == opcode ? 4'h0 : _GEN_136; // @[src/main/scala/rv32i/Decoder.scala 52:18 84:18]
  wire  _GEN_153 = 7'h17 == opcode ? 1'h0 : _GEN_137; // @[src/main/scala/rv32i/Decoder.scala 63:18 84:18]
  wire  _GEN_154 = 7'h17 == opcode ? 1'h0 : _GEN_138; // @[src/main/scala/rv32i/Decoder.scala 64:18 84:18]
  wire  _GEN_155 = 7'h17 == opcode ? 1'h0 : _GEN_139; // @[src/main/scala/rv32i/Decoder.scala 65:18 84:18]
  wire  _GEN_156 = 7'h17 == opcode ? 1'h0 : _GEN_140; // @[src/main/scala/rv32i/Decoder.scala 62:18 84:18]
  assign io_rs1 = io_inst[19:15]; // @[src/main/scala/rv32i/Decoder.scala 45:17]
  assign io_rs2 = io_inst[24:20]; // @[src/main/scala/rv32i/Decoder.scala 46:17]
  assign io_rd = io_inst[11:7]; // @[src/main/scala/rv32i/Decoder.scala 47:17]
  assign io_immSel = 7'h37 == opcode ? 3'h3 : _GEN_143; // @[src/main/scala/rv32i/Decoder.scala 84:18 88:20]
  assign io_aluSrcA = 7'h37 == opcode ? 2'h2 : {{1'd0}, 7'h17 == opcode}; // @[src/main/scala/rv32i/Decoder.scala 84:18 89:20]
  assign io_aluSrcImm = 7'h37 == opcode | _GEN_145; // @[src/main/scala/rv32i/Decoder.scala 84:18 90:20]
  assign io_aluOp = 7'h37 == opcode ? 4'h0 : _GEN_152; // @[src/main/scala/rv32i/Decoder.scala 52:18 84:18]
  assign io_branch = 7'h37 == opcode ? 1'h0 : _GEN_149; // @[src/main/scala/rv32i/Decoder.scala 53:18 84:18]
  assign io_jal = 7'h37 == opcode ? 1'h0 : _GEN_146; // @[src/main/scala/rv32i/Decoder.scala 54:18 84:18]
  assign io_jalr = 7'h37 == opcode ? 1'h0 : _GEN_148; // @[src/main/scala/rv32i/Decoder.scala 55:18 84:18]
  assign io_memRead = 7'h37 == opcode ? 1'h0 : _GEN_150; // @[src/main/scala/rv32i/Decoder.scala 56:18 84:18]
  assign io_memWrite = 7'h37 == opcode ? 1'h0 : _GEN_151; // @[src/main/scala/rv32i/Decoder.scala 57:18 84:18]
  assign io_memSize = f3[1:0]; // @[src/main/scala/rv32i/Decoder.scala 58:23]
  assign io_memUnsigned = f3[2]; // @[src/main/scala/rv32i/Decoder.scala 59:23]
  assign io_wbSel = 7'h37 == opcode ? 2'h0 : _GEN_147; // @[src/main/scala/rv32i/Decoder.scala 60:18 84:18]
  assign io_regWrite = 7'h37 == opcode | _GEN_142; // @[src/main/scala/rv32i/Decoder.scala 84:18 87:20]
  assign io_csr = 7'h37 == opcode ? 1'h0 : _GEN_156; // @[src/main/scala/rv32i/Decoder.scala 62:18 84:18]
  assign io_ecall = 7'h37 == opcode ? 1'h0 : _GEN_153; // @[src/main/scala/rv32i/Decoder.scala 63:18 84:18]
  assign io_ebreak = 7'h37 == opcode ? 1'h0 : _GEN_154; // @[src/main/scala/rv32i/Decoder.scala 64:18 84:18]
  assign io_mret = 7'h37 == opcode ? 1'h0 : _GEN_155; // @[src/main/scala/rv32i/Decoder.scala 65:18 84:18]
  assign io_illegal = 7'h37 == opcode ? 1'h0 : _GEN_141; // @[src/main/scala/rv32i/Decoder.scala 84:18 86:20]
endmodule
module ImmGen(
  input  [31:0] io_inst, // @[src/main/scala/rv32i/ImmGen.scala 8:14]
  input  [2:0]  io_sel, // @[src/main/scala/rv32i/ImmGen.scala 8:14]
  output [31:0] io_imm // @[src/main/scala/rv32i/ImmGen.scala 8:14]
);
  wire  sign = io_inst[31]; // @[src/main/scala/rv32i/ImmGen.scala 15:15]
  wire [20:0] _immI_T = sign ? 21'h1fffff : 21'h0; // @[src/main/scala/rv32i/ImmGen.scala 16:22]
  wire [31:0] immI = {_immI_T,io_inst[30:20]}; // @[src/main/scala/rv32i/ImmGen.scala 16:17]
  wire [31:0] immS = {_immI_T,io_inst[30:25],io_inst[11:7]}; // @[src/main/scala/rv32i/ImmGen.scala 17:17]
  wire [19:0] _immB_T = sign ? 20'hfffff : 20'h0; // @[src/main/scala/rv32i/ImmGen.scala 18:22]
  wire [31:0] immB = {_immB_T,io_inst[7],io_inst[30:25],io_inst[11:8],1'h0}; // @[src/main/scala/rv32i/ImmGen.scala 18:17]
  wire [31:0] immU = {io_inst[31:12],12'h0}; // @[src/main/scala/rv32i/ImmGen.scala 19:17]
  wire [11:0] _immJ_T = sign ? 12'hfff : 12'h0; // @[src/main/scala/rv32i/ImmGen.scala 20:22]
  wire [31:0] immJ = {_immJ_T,io_inst[19:12],io_inst[20],io_inst[30:21],1'h0}; // @[src/main/scala/rv32i/ImmGen.scala 20:17]
  wire [31:0] _GEN_0 = 3'h4 == io_sel ? immJ : immI; // @[src/main/scala/rv32i/ImmGen.scala 22:10 23:18 28:27]
  wire [31:0] _GEN_1 = 3'h3 == io_sel ? immU : _GEN_0; // @[src/main/scala/rv32i/ImmGen.scala 23:18 27:27]
  wire [31:0] _GEN_2 = 3'h2 == io_sel ? immB : _GEN_1; // @[src/main/scala/rv32i/ImmGen.scala 23:18 26:27]
  wire [31:0] _GEN_3 = 3'h1 == io_sel ? immS : _GEN_2; // @[src/main/scala/rv32i/ImmGen.scala 23:18 25:27]
  assign io_imm = 3'h0 == io_sel ? immI : _GEN_3; // @[src/main/scala/rv32i/ImmGen.scala 23:18 24:27]
endmodule
module RegFile(
  input         clock,
  input         reset,
  input  [4:0]  io_rs1, // @[src/main/scala/rv32i/RegFile.scala 9:14]
  input  [4:0]  io_rs2, // @[src/main/scala/rv32i/RegFile.scala 9:14]
  output [31:0] io_rd1, // @[src/main/scala/rv32i/RegFile.scala 9:14]
  output [31:0] io_rd2, // @[src/main/scala/rv32i/RegFile.scala 9:14]
  input         io_we, // @[src/main/scala/rv32i/RegFile.scala 9:14]
  input  [4:0]  io_waddr, // @[src/main/scala/rv32i/RegFile.scala 9:14]
  input  [31:0] io_wdata // @[src/main/scala/rv32i/RegFile.scala 9:14]
);
`ifdef RANDOMIZE_REG_INIT
  reg [31:0] _RAND_0;
  reg [31:0] _RAND_1;
  reg [31:0] _RAND_2;
  reg [31:0] _RAND_3;
  reg [31:0] _RAND_4;
  reg [31:0] _RAND_5;
  reg [31:0] _RAND_6;
  reg [31:0] _RAND_7;
  reg [31:0] _RAND_8;
  reg [31:0] _RAND_9;
  reg [31:0] _RAND_10;
  reg [31:0] _RAND_11;
  reg [31:0] _RAND_12;
  reg [31:0] _RAND_13;
  reg [31:0] _RAND_14;
  reg [31:0] _RAND_15;
  reg [31:0] _RAND_16;
  reg [31:0] _RAND_17;
  reg [31:0] _RAND_18;
  reg [31:0] _RAND_19;
  reg [31:0] _RAND_20;
  reg [31:0] _RAND_21;
  reg [31:0] _RAND_22;
  reg [31:0] _RAND_23;
  reg [31:0] _RAND_24;
  reg [31:0] _RAND_25;
  reg [31:0] _RAND_26;
  reg [31:0] _RAND_27;
  reg [31:0] _RAND_28;
  reg [31:0] _RAND_29;
  reg [31:0] _RAND_30;
  reg [31:0] _RAND_31;
`endif // RANDOMIZE_REG_INIT
  reg [31:0] regs_0; // @[src/main/scala/rv32i/RegFile.scala 19:21]
  reg [31:0] regs_1; // @[src/main/scala/rv32i/RegFile.scala 19:21]
  reg [31:0] regs_2; // @[src/main/scala/rv32i/RegFile.scala 19:21]
  reg [31:0] regs_3; // @[src/main/scala/rv32i/RegFile.scala 19:21]
  reg [31:0] regs_4; // @[src/main/scala/rv32i/RegFile.scala 19:21]
  reg [31:0] regs_5; // @[src/main/scala/rv32i/RegFile.scala 19:21]
  reg [31:0] regs_6; // @[src/main/scala/rv32i/RegFile.scala 19:21]
  reg [31:0] regs_7; // @[src/main/scala/rv32i/RegFile.scala 19:21]
  reg [31:0] regs_8; // @[src/main/scala/rv32i/RegFile.scala 19:21]
  reg [31:0] regs_9; // @[src/main/scala/rv32i/RegFile.scala 19:21]
  reg [31:0] regs_10; // @[src/main/scala/rv32i/RegFile.scala 19:21]
  reg [31:0] regs_11; // @[src/main/scala/rv32i/RegFile.scala 19:21]
  reg [31:0] regs_12; // @[src/main/scala/rv32i/RegFile.scala 19:21]
  reg [31:0] regs_13; // @[src/main/scala/rv32i/RegFile.scala 19:21]
  reg [31:0] regs_14; // @[src/main/scala/rv32i/RegFile.scala 19:21]
  reg [31:0] regs_15; // @[src/main/scala/rv32i/RegFile.scala 19:21]
  reg [31:0] regs_16; // @[src/main/scala/rv32i/RegFile.scala 19:21]
  reg [31:0] regs_17; // @[src/main/scala/rv32i/RegFile.scala 19:21]
  reg [31:0] regs_18; // @[src/main/scala/rv32i/RegFile.scala 19:21]
  reg [31:0] regs_19; // @[src/main/scala/rv32i/RegFile.scala 19:21]
  reg [31:0] regs_20; // @[src/main/scala/rv32i/RegFile.scala 19:21]
  reg [31:0] regs_21; // @[src/main/scala/rv32i/RegFile.scala 19:21]
  reg [31:0] regs_22; // @[src/main/scala/rv32i/RegFile.scala 19:21]
  reg [31:0] regs_23; // @[src/main/scala/rv32i/RegFile.scala 19:21]
  reg [31:0] regs_24; // @[src/main/scala/rv32i/RegFile.scala 19:21]
  reg [31:0] regs_25; // @[src/main/scala/rv32i/RegFile.scala 19:21]
  reg [31:0] regs_26; // @[src/main/scala/rv32i/RegFile.scala 19:21]
  reg [31:0] regs_27; // @[src/main/scala/rv32i/RegFile.scala 19:21]
  reg [31:0] regs_28; // @[src/main/scala/rv32i/RegFile.scala 19:21]
  reg [31:0] regs_29; // @[src/main/scala/rv32i/RegFile.scala 19:21]
  reg [31:0] regs_30; // @[src/main/scala/rv32i/RegFile.scala 19:21]
  reg [31:0] regs_31; // @[src/main/scala/rv32i/RegFile.scala 19:21]
  wire [31:0] _GEN_1 = 5'h1 == io_rs1 ? regs_1 : regs_0; // @[src/main/scala/rv32i/RegFile.scala 21:{16,16}]
  wire [31:0] _GEN_2 = 5'h2 == io_rs1 ? regs_2 : _GEN_1; // @[src/main/scala/rv32i/RegFile.scala 21:{16,16}]
  wire [31:0] _GEN_3 = 5'h3 == io_rs1 ? regs_3 : _GEN_2; // @[src/main/scala/rv32i/RegFile.scala 21:{16,16}]
  wire [31:0] _GEN_4 = 5'h4 == io_rs1 ? regs_4 : _GEN_3; // @[src/main/scala/rv32i/RegFile.scala 21:{16,16}]
  wire [31:0] _GEN_5 = 5'h5 == io_rs1 ? regs_5 : _GEN_4; // @[src/main/scala/rv32i/RegFile.scala 21:{16,16}]
  wire [31:0] _GEN_6 = 5'h6 == io_rs1 ? regs_6 : _GEN_5; // @[src/main/scala/rv32i/RegFile.scala 21:{16,16}]
  wire [31:0] _GEN_7 = 5'h7 == io_rs1 ? regs_7 : _GEN_6; // @[src/main/scala/rv32i/RegFile.scala 21:{16,16}]
  wire [31:0] _GEN_8 = 5'h8 == io_rs1 ? regs_8 : _GEN_7; // @[src/main/scala/rv32i/RegFile.scala 21:{16,16}]
  wire [31:0] _GEN_9 = 5'h9 == io_rs1 ? regs_9 : _GEN_8; // @[src/main/scala/rv32i/RegFile.scala 21:{16,16}]
  wire [31:0] _GEN_10 = 5'ha == io_rs1 ? regs_10 : _GEN_9; // @[src/main/scala/rv32i/RegFile.scala 21:{16,16}]
  wire [31:0] _GEN_11 = 5'hb == io_rs1 ? regs_11 : _GEN_10; // @[src/main/scala/rv32i/RegFile.scala 21:{16,16}]
  wire [31:0] _GEN_12 = 5'hc == io_rs1 ? regs_12 : _GEN_11; // @[src/main/scala/rv32i/RegFile.scala 21:{16,16}]
  wire [31:0] _GEN_13 = 5'hd == io_rs1 ? regs_13 : _GEN_12; // @[src/main/scala/rv32i/RegFile.scala 21:{16,16}]
  wire [31:0] _GEN_14 = 5'he == io_rs1 ? regs_14 : _GEN_13; // @[src/main/scala/rv32i/RegFile.scala 21:{16,16}]
  wire [31:0] _GEN_15 = 5'hf == io_rs1 ? regs_15 : _GEN_14; // @[src/main/scala/rv32i/RegFile.scala 21:{16,16}]
  wire [31:0] _GEN_16 = 5'h10 == io_rs1 ? regs_16 : _GEN_15; // @[src/main/scala/rv32i/RegFile.scala 21:{16,16}]
  wire [31:0] _GEN_17 = 5'h11 == io_rs1 ? regs_17 : _GEN_16; // @[src/main/scala/rv32i/RegFile.scala 21:{16,16}]
  wire [31:0] _GEN_18 = 5'h12 == io_rs1 ? regs_18 : _GEN_17; // @[src/main/scala/rv32i/RegFile.scala 21:{16,16}]
  wire [31:0] _GEN_19 = 5'h13 == io_rs1 ? regs_19 : _GEN_18; // @[src/main/scala/rv32i/RegFile.scala 21:{16,16}]
  wire [31:0] _GEN_20 = 5'h14 == io_rs1 ? regs_20 : _GEN_19; // @[src/main/scala/rv32i/RegFile.scala 21:{16,16}]
  wire [31:0] _GEN_21 = 5'h15 == io_rs1 ? regs_21 : _GEN_20; // @[src/main/scala/rv32i/RegFile.scala 21:{16,16}]
  wire [31:0] _GEN_22 = 5'h16 == io_rs1 ? regs_22 : _GEN_21; // @[src/main/scala/rv32i/RegFile.scala 21:{16,16}]
  wire [31:0] _GEN_23 = 5'h17 == io_rs1 ? regs_23 : _GEN_22; // @[src/main/scala/rv32i/RegFile.scala 21:{16,16}]
  wire [31:0] _GEN_24 = 5'h18 == io_rs1 ? regs_24 : _GEN_23; // @[src/main/scala/rv32i/RegFile.scala 21:{16,16}]
  wire [31:0] _GEN_25 = 5'h19 == io_rs1 ? regs_25 : _GEN_24; // @[src/main/scala/rv32i/RegFile.scala 21:{16,16}]
  wire [31:0] _GEN_26 = 5'h1a == io_rs1 ? regs_26 : _GEN_25; // @[src/main/scala/rv32i/RegFile.scala 21:{16,16}]
  wire [31:0] _GEN_27 = 5'h1b == io_rs1 ? regs_27 : _GEN_26; // @[src/main/scala/rv32i/RegFile.scala 21:{16,16}]
  wire [31:0] _GEN_28 = 5'h1c == io_rs1 ? regs_28 : _GEN_27; // @[src/main/scala/rv32i/RegFile.scala 21:{16,16}]
  wire [31:0] _GEN_29 = 5'h1d == io_rs1 ? regs_29 : _GEN_28; // @[src/main/scala/rv32i/RegFile.scala 21:{16,16}]
  wire [31:0] _GEN_30 = 5'h1e == io_rs1 ? regs_30 : _GEN_29; // @[src/main/scala/rv32i/RegFile.scala 21:{16,16}]
  wire [31:0] _GEN_31 = 5'h1f == io_rs1 ? regs_31 : _GEN_30; // @[src/main/scala/rv32i/RegFile.scala 21:{16,16}]
  wire [31:0] _GEN_33 = 5'h1 == io_rs2 ? regs_1 : regs_0; // @[src/main/scala/rv32i/RegFile.scala 22:{16,16}]
  wire [31:0] _GEN_34 = 5'h2 == io_rs2 ? regs_2 : _GEN_33; // @[src/main/scala/rv32i/RegFile.scala 22:{16,16}]
  wire [31:0] _GEN_35 = 5'h3 == io_rs2 ? regs_3 : _GEN_34; // @[src/main/scala/rv32i/RegFile.scala 22:{16,16}]
  wire [31:0] _GEN_36 = 5'h4 == io_rs2 ? regs_4 : _GEN_35; // @[src/main/scala/rv32i/RegFile.scala 22:{16,16}]
  wire [31:0] _GEN_37 = 5'h5 == io_rs2 ? regs_5 : _GEN_36; // @[src/main/scala/rv32i/RegFile.scala 22:{16,16}]
  wire [31:0] _GEN_38 = 5'h6 == io_rs2 ? regs_6 : _GEN_37; // @[src/main/scala/rv32i/RegFile.scala 22:{16,16}]
  wire [31:0] _GEN_39 = 5'h7 == io_rs2 ? regs_7 : _GEN_38; // @[src/main/scala/rv32i/RegFile.scala 22:{16,16}]
  wire [31:0] _GEN_40 = 5'h8 == io_rs2 ? regs_8 : _GEN_39; // @[src/main/scala/rv32i/RegFile.scala 22:{16,16}]
  wire [31:0] _GEN_41 = 5'h9 == io_rs2 ? regs_9 : _GEN_40; // @[src/main/scala/rv32i/RegFile.scala 22:{16,16}]
  wire [31:0] _GEN_42 = 5'ha == io_rs2 ? regs_10 : _GEN_41; // @[src/main/scala/rv32i/RegFile.scala 22:{16,16}]
  wire [31:0] _GEN_43 = 5'hb == io_rs2 ? regs_11 : _GEN_42; // @[src/main/scala/rv32i/RegFile.scala 22:{16,16}]
  wire [31:0] _GEN_44 = 5'hc == io_rs2 ? regs_12 : _GEN_43; // @[src/main/scala/rv32i/RegFile.scala 22:{16,16}]
  wire [31:0] _GEN_45 = 5'hd == io_rs2 ? regs_13 : _GEN_44; // @[src/main/scala/rv32i/RegFile.scala 22:{16,16}]
  wire [31:0] _GEN_46 = 5'he == io_rs2 ? regs_14 : _GEN_45; // @[src/main/scala/rv32i/RegFile.scala 22:{16,16}]
  wire [31:0] _GEN_47 = 5'hf == io_rs2 ? regs_15 : _GEN_46; // @[src/main/scala/rv32i/RegFile.scala 22:{16,16}]
  wire [31:0] _GEN_48 = 5'h10 == io_rs2 ? regs_16 : _GEN_47; // @[src/main/scala/rv32i/RegFile.scala 22:{16,16}]
  wire [31:0] _GEN_49 = 5'h11 == io_rs2 ? regs_17 : _GEN_48; // @[src/main/scala/rv32i/RegFile.scala 22:{16,16}]
  wire [31:0] _GEN_50 = 5'h12 == io_rs2 ? regs_18 : _GEN_49; // @[src/main/scala/rv32i/RegFile.scala 22:{16,16}]
  wire [31:0] _GEN_51 = 5'h13 == io_rs2 ? regs_19 : _GEN_50; // @[src/main/scala/rv32i/RegFile.scala 22:{16,16}]
  wire [31:0] _GEN_52 = 5'h14 == io_rs2 ? regs_20 : _GEN_51; // @[src/main/scala/rv32i/RegFile.scala 22:{16,16}]
  wire [31:0] _GEN_53 = 5'h15 == io_rs2 ? regs_21 : _GEN_52; // @[src/main/scala/rv32i/RegFile.scala 22:{16,16}]
  wire [31:0] _GEN_54 = 5'h16 == io_rs2 ? regs_22 : _GEN_53; // @[src/main/scala/rv32i/RegFile.scala 22:{16,16}]
  wire [31:0] _GEN_55 = 5'h17 == io_rs2 ? regs_23 : _GEN_54; // @[src/main/scala/rv32i/RegFile.scala 22:{16,16}]
  wire [31:0] _GEN_56 = 5'h18 == io_rs2 ? regs_24 : _GEN_55; // @[src/main/scala/rv32i/RegFile.scala 22:{16,16}]
  wire [31:0] _GEN_57 = 5'h19 == io_rs2 ? regs_25 : _GEN_56; // @[src/main/scala/rv32i/RegFile.scala 22:{16,16}]
  wire [31:0] _GEN_58 = 5'h1a == io_rs2 ? regs_26 : _GEN_57; // @[src/main/scala/rv32i/RegFile.scala 22:{16,16}]
  wire [31:0] _GEN_59 = 5'h1b == io_rs2 ? regs_27 : _GEN_58; // @[src/main/scala/rv32i/RegFile.scala 22:{16,16}]
  wire [31:0] _GEN_60 = 5'h1c == io_rs2 ? regs_28 : _GEN_59; // @[src/main/scala/rv32i/RegFile.scala 22:{16,16}]
  wire [31:0] _GEN_61 = 5'h1d == io_rs2 ? regs_29 : _GEN_60; // @[src/main/scala/rv32i/RegFile.scala 22:{16,16}]
  wire [31:0] _GEN_62 = 5'h1e == io_rs2 ? regs_30 : _GEN_61; // @[src/main/scala/rv32i/RegFile.scala 22:{16,16}]
  wire [31:0] _GEN_63 = 5'h1f == io_rs2 ? regs_31 : _GEN_62; // @[src/main/scala/rv32i/RegFile.scala 22:{16,16}]
  assign io_rd1 = io_rs1 == 5'h0 ? 32'h0 : _GEN_31; // @[src/main/scala/rv32i/RegFile.scala 21:16]
  assign io_rd2 = io_rs2 == 5'h0 ? 32'h0 : _GEN_63; // @[src/main/scala/rv32i/RegFile.scala 22:16]
  always @(posedge clock) begin
    if (reset) begin // @[src/main/scala/rv32i/RegFile.scala 19:21]
      regs_0 <= 32'h0; // @[src/main/scala/rv32i/RegFile.scala 19:21]
    end else if (io_we & io_waddr != 5'h0) begin // @[src/main/scala/rv32i/RegFile.scala 24:35]
      if (5'h0 == io_waddr) begin // @[src/main/scala/rv32i/RegFile.scala 25:20]
        regs_0 <= io_wdata; // @[src/main/scala/rv32i/RegFile.scala 25:20]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegFile.scala 19:21]
      regs_1 <= 32'h0; // @[src/main/scala/rv32i/RegFile.scala 19:21]
    end else if (io_we & io_waddr != 5'h0) begin // @[src/main/scala/rv32i/RegFile.scala 24:35]
      if (5'h1 == io_waddr) begin // @[src/main/scala/rv32i/RegFile.scala 25:20]
        regs_1 <= io_wdata; // @[src/main/scala/rv32i/RegFile.scala 25:20]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegFile.scala 19:21]
      regs_2 <= 32'h0; // @[src/main/scala/rv32i/RegFile.scala 19:21]
    end else if (io_we & io_waddr != 5'h0) begin // @[src/main/scala/rv32i/RegFile.scala 24:35]
      if (5'h2 == io_waddr) begin // @[src/main/scala/rv32i/RegFile.scala 25:20]
        regs_2 <= io_wdata; // @[src/main/scala/rv32i/RegFile.scala 25:20]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegFile.scala 19:21]
      regs_3 <= 32'h0; // @[src/main/scala/rv32i/RegFile.scala 19:21]
    end else if (io_we & io_waddr != 5'h0) begin // @[src/main/scala/rv32i/RegFile.scala 24:35]
      if (5'h3 == io_waddr) begin // @[src/main/scala/rv32i/RegFile.scala 25:20]
        regs_3 <= io_wdata; // @[src/main/scala/rv32i/RegFile.scala 25:20]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegFile.scala 19:21]
      regs_4 <= 32'h0; // @[src/main/scala/rv32i/RegFile.scala 19:21]
    end else if (io_we & io_waddr != 5'h0) begin // @[src/main/scala/rv32i/RegFile.scala 24:35]
      if (5'h4 == io_waddr) begin // @[src/main/scala/rv32i/RegFile.scala 25:20]
        regs_4 <= io_wdata; // @[src/main/scala/rv32i/RegFile.scala 25:20]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegFile.scala 19:21]
      regs_5 <= 32'h0; // @[src/main/scala/rv32i/RegFile.scala 19:21]
    end else if (io_we & io_waddr != 5'h0) begin // @[src/main/scala/rv32i/RegFile.scala 24:35]
      if (5'h5 == io_waddr) begin // @[src/main/scala/rv32i/RegFile.scala 25:20]
        regs_5 <= io_wdata; // @[src/main/scala/rv32i/RegFile.scala 25:20]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegFile.scala 19:21]
      regs_6 <= 32'h0; // @[src/main/scala/rv32i/RegFile.scala 19:21]
    end else if (io_we & io_waddr != 5'h0) begin // @[src/main/scala/rv32i/RegFile.scala 24:35]
      if (5'h6 == io_waddr) begin // @[src/main/scala/rv32i/RegFile.scala 25:20]
        regs_6 <= io_wdata; // @[src/main/scala/rv32i/RegFile.scala 25:20]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegFile.scala 19:21]
      regs_7 <= 32'h0; // @[src/main/scala/rv32i/RegFile.scala 19:21]
    end else if (io_we & io_waddr != 5'h0) begin // @[src/main/scala/rv32i/RegFile.scala 24:35]
      if (5'h7 == io_waddr) begin // @[src/main/scala/rv32i/RegFile.scala 25:20]
        regs_7 <= io_wdata; // @[src/main/scala/rv32i/RegFile.scala 25:20]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegFile.scala 19:21]
      regs_8 <= 32'h0; // @[src/main/scala/rv32i/RegFile.scala 19:21]
    end else if (io_we & io_waddr != 5'h0) begin // @[src/main/scala/rv32i/RegFile.scala 24:35]
      if (5'h8 == io_waddr) begin // @[src/main/scala/rv32i/RegFile.scala 25:20]
        regs_8 <= io_wdata; // @[src/main/scala/rv32i/RegFile.scala 25:20]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegFile.scala 19:21]
      regs_9 <= 32'h0; // @[src/main/scala/rv32i/RegFile.scala 19:21]
    end else if (io_we & io_waddr != 5'h0) begin // @[src/main/scala/rv32i/RegFile.scala 24:35]
      if (5'h9 == io_waddr) begin // @[src/main/scala/rv32i/RegFile.scala 25:20]
        regs_9 <= io_wdata; // @[src/main/scala/rv32i/RegFile.scala 25:20]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegFile.scala 19:21]
      regs_10 <= 32'h0; // @[src/main/scala/rv32i/RegFile.scala 19:21]
    end else if (io_we & io_waddr != 5'h0) begin // @[src/main/scala/rv32i/RegFile.scala 24:35]
      if (5'ha == io_waddr) begin // @[src/main/scala/rv32i/RegFile.scala 25:20]
        regs_10 <= io_wdata; // @[src/main/scala/rv32i/RegFile.scala 25:20]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegFile.scala 19:21]
      regs_11 <= 32'h0; // @[src/main/scala/rv32i/RegFile.scala 19:21]
    end else if (io_we & io_waddr != 5'h0) begin // @[src/main/scala/rv32i/RegFile.scala 24:35]
      if (5'hb == io_waddr) begin // @[src/main/scala/rv32i/RegFile.scala 25:20]
        regs_11 <= io_wdata; // @[src/main/scala/rv32i/RegFile.scala 25:20]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegFile.scala 19:21]
      regs_12 <= 32'h0; // @[src/main/scala/rv32i/RegFile.scala 19:21]
    end else if (io_we & io_waddr != 5'h0) begin // @[src/main/scala/rv32i/RegFile.scala 24:35]
      if (5'hc == io_waddr) begin // @[src/main/scala/rv32i/RegFile.scala 25:20]
        regs_12 <= io_wdata; // @[src/main/scala/rv32i/RegFile.scala 25:20]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegFile.scala 19:21]
      regs_13 <= 32'h0; // @[src/main/scala/rv32i/RegFile.scala 19:21]
    end else if (io_we & io_waddr != 5'h0) begin // @[src/main/scala/rv32i/RegFile.scala 24:35]
      if (5'hd == io_waddr) begin // @[src/main/scala/rv32i/RegFile.scala 25:20]
        regs_13 <= io_wdata; // @[src/main/scala/rv32i/RegFile.scala 25:20]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegFile.scala 19:21]
      regs_14 <= 32'h0; // @[src/main/scala/rv32i/RegFile.scala 19:21]
    end else if (io_we & io_waddr != 5'h0) begin // @[src/main/scala/rv32i/RegFile.scala 24:35]
      if (5'he == io_waddr) begin // @[src/main/scala/rv32i/RegFile.scala 25:20]
        regs_14 <= io_wdata; // @[src/main/scala/rv32i/RegFile.scala 25:20]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegFile.scala 19:21]
      regs_15 <= 32'h0; // @[src/main/scala/rv32i/RegFile.scala 19:21]
    end else if (io_we & io_waddr != 5'h0) begin // @[src/main/scala/rv32i/RegFile.scala 24:35]
      if (5'hf == io_waddr) begin // @[src/main/scala/rv32i/RegFile.scala 25:20]
        regs_15 <= io_wdata; // @[src/main/scala/rv32i/RegFile.scala 25:20]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegFile.scala 19:21]
      regs_16 <= 32'h0; // @[src/main/scala/rv32i/RegFile.scala 19:21]
    end else if (io_we & io_waddr != 5'h0) begin // @[src/main/scala/rv32i/RegFile.scala 24:35]
      if (5'h10 == io_waddr) begin // @[src/main/scala/rv32i/RegFile.scala 25:20]
        regs_16 <= io_wdata; // @[src/main/scala/rv32i/RegFile.scala 25:20]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegFile.scala 19:21]
      regs_17 <= 32'h0; // @[src/main/scala/rv32i/RegFile.scala 19:21]
    end else if (io_we & io_waddr != 5'h0) begin // @[src/main/scala/rv32i/RegFile.scala 24:35]
      if (5'h11 == io_waddr) begin // @[src/main/scala/rv32i/RegFile.scala 25:20]
        regs_17 <= io_wdata; // @[src/main/scala/rv32i/RegFile.scala 25:20]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegFile.scala 19:21]
      regs_18 <= 32'h0; // @[src/main/scala/rv32i/RegFile.scala 19:21]
    end else if (io_we & io_waddr != 5'h0) begin // @[src/main/scala/rv32i/RegFile.scala 24:35]
      if (5'h12 == io_waddr) begin // @[src/main/scala/rv32i/RegFile.scala 25:20]
        regs_18 <= io_wdata; // @[src/main/scala/rv32i/RegFile.scala 25:20]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegFile.scala 19:21]
      regs_19 <= 32'h0; // @[src/main/scala/rv32i/RegFile.scala 19:21]
    end else if (io_we & io_waddr != 5'h0) begin // @[src/main/scala/rv32i/RegFile.scala 24:35]
      if (5'h13 == io_waddr) begin // @[src/main/scala/rv32i/RegFile.scala 25:20]
        regs_19 <= io_wdata; // @[src/main/scala/rv32i/RegFile.scala 25:20]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegFile.scala 19:21]
      regs_20 <= 32'h0; // @[src/main/scala/rv32i/RegFile.scala 19:21]
    end else if (io_we & io_waddr != 5'h0) begin // @[src/main/scala/rv32i/RegFile.scala 24:35]
      if (5'h14 == io_waddr) begin // @[src/main/scala/rv32i/RegFile.scala 25:20]
        regs_20 <= io_wdata; // @[src/main/scala/rv32i/RegFile.scala 25:20]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegFile.scala 19:21]
      regs_21 <= 32'h0; // @[src/main/scala/rv32i/RegFile.scala 19:21]
    end else if (io_we & io_waddr != 5'h0) begin // @[src/main/scala/rv32i/RegFile.scala 24:35]
      if (5'h15 == io_waddr) begin // @[src/main/scala/rv32i/RegFile.scala 25:20]
        regs_21 <= io_wdata; // @[src/main/scala/rv32i/RegFile.scala 25:20]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegFile.scala 19:21]
      regs_22 <= 32'h0; // @[src/main/scala/rv32i/RegFile.scala 19:21]
    end else if (io_we & io_waddr != 5'h0) begin // @[src/main/scala/rv32i/RegFile.scala 24:35]
      if (5'h16 == io_waddr) begin // @[src/main/scala/rv32i/RegFile.scala 25:20]
        regs_22 <= io_wdata; // @[src/main/scala/rv32i/RegFile.scala 25:20]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegFile.scala 19:21]
      regs_23 <= 32'h0; // @[src/main/scala/rv32i/RegFile.scala 19:21]
    end else if (io_we & io_waddr != 5'h0) begin // @[src/main/scala/rv32i/RegFile.scala 24:35]
      if (5'h17 == io_waddr) begin // @[src/main/scala/rv32i/RegFile.scala 25:20]
        regs_23 <= io_wdata; // @[src/main/scala/rv32i/RegFile.scala 25:20]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegFile.scala 19:21]
      regs_24 <= 32'h0; // @[src/main/scala/rv32i/RegFile.scala 19:21]
    end else if (io_we & io_waddr != 5'h0) begin // @[src/main/scala/rv32i/RegFile.scala 24:35]
      if (5'h18 == io_waddr) begin // @[src/main/scala/rv32i/RegFile.scala 25:20]
        regs_24 <= io_wdata; // @[src/main/scala/rv32i/RegFile.scala 25:20]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegFile.scala 19:21]
      regs_25 <= 32'h0; // @[src/main/scala/rv32i/RegFile.scala 19:21]
    end else if (io_we & io_waddr != 5'h0) begin // @[src/main/scala/rv32i/RegFile.scala 24:35]
      if (5'h19 == io_waddr) begin // @[src/main/scala/rv32i/RegFile.scala 25:20]
        regs_25 <= io_wdata; // @[src/main/scala/rv32i/RegFile.scala 25:20]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegFile.scala 19:21]
      regs_26 <= 32'h0; // @[src/main/scala/rv32i/RegFile.scala 19:21]
    end else if (io_we & io_waddr != 5'h0) begin // @[src/main/scala/rv32i/RegFile.scala 24:35]
      if (5'h1a == io_waddr) begin // @[src/main/scala/rv32i/RegFile.scala 25:20]
        regs_26 <= io_wdata; // @[src/main/scala/rv32i/RegFile.scala 25:20]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegFile.scala 19:21]
      regs_27 <= 32'h0; // @[src/main/scala/rv32i/RegFile.scala 19:21]
    end else if (io_we & io_waddr != 5'h0) begin // @[src/main/scala/rv32i/RegFile.scala 24:35]
      if (5'h1b == io_waddr) begin // @[src/main/scala/rv32i/RegFile.scala 25:20]
        regs_27 <= io_wdata; // @[src/main/scala/rv32i/RegFile.scala 25:20]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegFile.scala 19:21]
      regs_28 <= 32'h0; // @[src/main/scala/rv32i/RegFile.scala 19:21]
    end else if (io_we & io_waddr != 5'h0) begin // @[src/main/scala/rv32i/RegFile.scala 24:35]
      if (5'h1c == io_waddr) begin // @[src/main/scala/rv32i/RegFile.scala 25:20]
        regs_28 <= io_wdata; // @[src/main/scala/rv32i/RegFile.scala 25:20]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegFile.scala 19:21]
      regs_29 <= 32'h0; // @[src/main/scala/rv32i/RegFile.scala 19:21]
    end else if (io_we & io_waddr != 5'h0) begin // @[src/main/scala/rv32i/RegFile.scala 24:35]
      if (5'h1d == io_waddr) begin // @[src/main/scala/rv32i/RegFile.scala 25:20]
        regs_29 <= io_wdata; // @[src/main/scala/rv32i/RegFile.scala 25:20]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegFile.scala 19:21]
      regs_30 <= 32'h0; // @[src/main/scala/rv32i/RegFile.scala 19:21]
    end else if (io_we & io_waddr != 5'h0) begin // @[src/main/scala/rv32i/RegFile.scala 24:35]
      if (5'h1e == io_waddr) begin // @[src/main/scala/rv32i/RegFile.scala 25:20]
        regs_30 <= io_wdata; // @[src/main/scala/rv32i/RegFile.scala 25:20]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegFile.scala 19:21]
      regs_31 <= 32'h0; // @[src/main/scala/rv32i/RegFile.scala 19:21]
    end else if (io_we & io_waddr != 5'h0) begin // @[src/main/scala/rv32i/RegFile.scala 24:35]
      if (5'h1f == io_waddr) begin // @[src/main/scala/rv32i/RegFile.scala 25:20]
        regs_31 <= io_wdata; // @[src/main/scala/rv32i/RegFile.scala 25:20]
      end
    end
  end
// Register and memory initialization
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif
`ifndef RANDOM
`define RANDOM $random
`endif
`ifdef RANDOMIZE_MEM_INIT
  integer initvar;
`endif
`ifndef SYNTHESIS
`ifdef FIRRTL_BEFORE_INITIAL
`FIRRTL_BEFORE_INITIAL
`endif
initial begin
  `ifdef RANDOMIZE
    `ifdef INIT_RANDOM
      `INIT_RANDOM
    `endif
    `ifndef VERILATOR
      `ifdef RANDOMIZE_DELAY
        #`RANDOMIZE_DELAY begin end
      `else
        #0.002 begin end
      `endif
    `endif
`ifdef RANDOMIZE_REG_INIT
  _RAND_0 = {1{`RANDOM}};
  regs_0 = _RAND_0[31:0];
  _RAND_1 = {1{`RANDOM}};
  regs_1 = _RAND_1[31:0];
  _RAND_2 = {1{`RANDOM}};
  regs_2 = _RAND_2[31:0];
  _RAND_3 = {1{`RANDOM}};
  regs_3 = _RAND_3[31:0];
  _RAND_4 = {1{`RANDOM}};
  regs_4 = _RAND_4[31:0];
  _RAND_5 = {1{`RANDOM}};
  regs_5 = _RAND_5[31:0];
  _RAND_6 = {1{`RANDOM}};
  regs_6 = _RAND_6[31:0];
  _RAND_7 = {1{`RANDOM}};
  regs_7 = _RAND_7[31:0];
  _RAND_8 = {1{`RANDOM}};
  regs_8 = _RAND_8[31:0];
  _RAND_9 = {1{`RANDOM}};
  regs_9 = _RAND_9[31:0];
  _RAND_10 = {1{`RANDOM}};
  regs_10 = _RAND_10[31:0];
  _RAND_11 = {1{`RANDOM}};
  regs_11 = _RAND_11[31:0];
  _RAND_12 = {1{`RANDOM}};
  regs_12 = _RAND_12[31:0];
  _RAND_13 = {1{`RANDOM}};
  regs_13 = _RAND_13[31:0];
  _RAND_14 = {1{`RANDOM}};
  regs_14 = _RAND_14[31:0];
  _RAND_15 = {1{`RANDOM}};
  regs_15 = _RAND_15[31:0];
  _RAND_16 = {1{`RANDOM}};
  regs_16 = _RAND_16[31:0];
  _RAND_17 = {1{`RANDOM}};
  regs_17 = _RAND_17[31:0];
  _RAND_18 = {1{`RANDOM}};
  regs_18 = _RAND_18[31:0];
  _RAND_19 = {1{`RANDOM}};
  regs_19 = _RAND_19[31:0];
  _RAND_20 = {1{`RANDOM}};
  regs_20 = _RAND_20[31:0];
  _RAND_21 = {1{`RANDOM}};
  regs_21 = _RAND_21[31:0];
  _RAND_22 = {1{`RANDOM}};
  regs_22 = _RAND_22[31:0];
  _RAND_23 = {1{`RANDOM}};
  regs_23 = _RAND_23[31:0];
  _RAND_24 = {1{`RANDOM}};
  regs_24 = _RAND_24[31:0];
  _RAND_25 = {1{`RANDOM}};
  regs_25 = _RAND_25[31:0];
  _RAND_26 = {1{`RANDOM}};
  regs_26 = _RAND_26[31:0];
  _RAND_27 = {1{`RANDOM}};
  regs_27 = _RAND_27[31:0];
  _RAND_28 = {1{`RANDOM}};
  regs_28 = _RAND_28[31:0];
  _RAND_29 = {1{`RANDOM}};
  regs_29 = _RAND_29[31:0];
  _RAND_30 = {1{`RANDOM}};
  regs_30 = _RAND_30[31:0];
  _RAND_31 = {1{`RANDOM}};
  regs_31 = _RAND_31[31:0];
`endif // RANDOMIZE_REG_INIT
  `endif // RANDOMIZE
end // initial
`ifdef FIRRTL_AFTER_INITIAL
`FIRRTL_AFTER_INITIAL
`endif
`endif // SYNTHESIS
endmodule
module Alu(
  input  [3:0]  io_op, // @[src/main/scala/rv32i/Alu.scala 8:14]
  input  [31:0] io_a, // @[src/main/scala/rv32i/Alu.scala 8:14]
  input  [31:0] io_b, // @[src/main/scala/rv32i/Alu.scala 8:14]
  output [31:0] io_y // @[src/main/scala/rv32i/Alu.scala 8:14]
);
  wire [4:0] sh = io_b[4:0]; // @[src/main/scala/rv32i/Alu.scala 15:16]
  wire [31:0] _io_y_T_1 = io_a + io_b; // @[src/main/scala/rv32i/Alu.scala 16:16]
  wire [31:0] _io_y_T_5 = io_a - io_b; // @[src/main/scala/rv32i/Alu.scala 19:35]
  wire [62:0] _GEN_9 = {{31'd0}, io_a}; // @[src/main/scala/rv32i/Alu.scala 20:36]
  wire [62:0] _io_y_T_6 = _GEN_9 << sh; // @[src/main/scala/rv32i/Alu.scala 20:36]
  wire [31:0] _io_y_T_8 = io_a; // @[src/main/scala/rv32i/Alu.scala 21:36]
  wire [31:0] _io_y_T_9 = io_b; // @[src/main/scala/rv32i/Alu.scala 21:50]
  wire [31:0] _io_y_T_12 = io_a ^ io_b; // @[src/main/scala/rv32i/Alu.scala 23:35]
  wire [31:0] _io_y_T_13 = io_a >> sh; // @[src/main/scala/rv32i/Alu.scala 24:35]
  wire [31:0] _io_y_T_16 = $signed(io_a) >>> sh; // @[src/main/scala/rv32i/Alu.scala 25:50]
  wire [31:0] _io_y_T_17 = io_a | io_b; // @[src/main/scala/rv32i/Alu.scala 26:35]
  wire [31:0] _io_y_T_18 = io_a & io_b; // @[src/main/scala/rv32i/Alu.scala 27:35]
  wire [31:0] _GEN_0 = 4'h9 == io_op ? _io_y_T_18 : _io_y_T_1; // @[src/main/scala/rv32i/Alu.scala 17:17 27:27 16:8]
  wire [31:0] _GEN_1 = 4'h8 == io_op ? _io_y_T_17 : _GEN_0; // @[src/main/scala/rv32i/Alu.scala 17:17 26:27]
  wire [31:0] _GEN_2 = 4'h7 == io_op ? _io_y_T_16 : _GEN_1; // @[src/main/scala/rv32i/Alu.scala 17:17 25:27]
  wire [31:0] _GEN_3 = 4'h6 == io_op ? _io_y_T_13 : _GEN_2; // @[src/main/scala/rv32i/Alu.scala 17:17 24:27]
  wire [31:0] _GEN_4 = 4'h5 == io_op ? _io_y_T_12 : _GEN_3; // @[src/main/scala/rv32i/Alu.scala 17:17 23:27]
  wire [31:0] _GEN_5 = 4'h4 == io_op ? {{31'd0}, io_a < io_b} : _GEN_4; // @[src/main/scala/rv32i/Alu.scala 17:17 22:27]
  wire [31:0] _GEN_6 = 4'h3 == io_op ? {{31'd0}, $signed(_io_y_T_8) < $signed(_io_y_T_9)} : _GEN_5; // @[src/main/scala/rv32i/Alu.scala 17:17 21:27]
  wire [31:0] _GEN_7 = 4'h2 == io_op ? _io_y_T_6[31:0] : _GEN_6; // @[src/main/scala/rv32i/Alu.scala 17:17 20:27]
  wire [31:0] _GEN_8 = 4'h1 == io_op ? _io_y_T_5 : _GEN_7; // @[src/main/scala/rv32i/Alu.scala 17:17 19:27]
  assign io_y = 4'h0 == io_op ? _io_y_T_1 : _GEN_8; // @[src/main/scala/rv32i/Alu.scala 17:17 18:27]
endmodule
module CsrFile(
  input         clock,
  input         reset,
  input  [11:0] io_addr, // @[src/main/scala/rv32i/CsrFile.scala 22:14]
  input         io_en, // @[src/main/scala/rv32i/CsrFile.scala 22:14]
  input  [1:0]  io_op, // @[src/main/scala/rv32i/CsrFile.scala 22:14]
  input  [31:0] io_src, // @[src/main/scala/rv32i/CsrFile.scala 22:14]
  input         io_wrEn, // @[src/main/scala/rv32i/CsrFile.scala 22:14]
  output [31:0] io_rdata, // @[src/main/scala/rv32i/CsrFile.scala 22:14]
  output        io_illegal, // @[src/main/scala/rv32i/CsrFile.scala 22:14]
  input         io_commit, // @[src/main/scala/rv32i/CsrFile.scala 22:14]
  input         io_trapEnter, // @[src/main/scala/rv32i/CsrFile.scala 22:14]
  input  [31:0] io_trapCause, // @[src/main/scala/rv32i/CsrFile.scala 22:14]
  input  [31:0] io_trapPc, // @[src/main/scala/rv32i/CsrFile.scala 22:14]
  input  [31:0] io_trapVal, // @[src/main/scala/rv32i/CsrFile.scala 22:14]
  input         io_mretEnter, // @[src/main/scala/rv32i/CsrFile.scala 22:14]
  output [31:0] io_mtvecBase, // @[src/main/scala/rv32i/CsrFile.scala 22:14]
  output [31:0] io_mepc // @[src/main/scala/rv32i/CsrFile.scala 22:14]
);
`ifdef RANDOMIZE_REG_INIT
  reg [31:0] _RAND_0;
  reg [31:0] _RAND_1;
  reg [31:0] _RAND_2;
  reg [31:0] _RAND_3;
  reg [31:0] _RAND_4;
  reg [31:0] _RAND_5;
  reg [31:0] _RAND_6;
  reg [31:0] _RAND_7;
  reg [63:0] _RAND_8;
  reg [63:0] _RAND_9;
`endif // RANDOMIZE_REG_INIT
  reg  mie_; // @[src/main/scala/rv32i/CsrFile.scala 40:25]
  reg  mpie; // @[src/main/scala/rv32i/CsrFile.scala 41:25]
  reg [31:0] mieReg; // @[src/main/scala/rv32i/CsrFile.scala 42:25]
  reg [31:0] mtvec; // @[src/main/scala/rv32i/CsrFile.scala 43:25]
  reg [31:0] mscratch; // @[src/main/scala/rv32i/CsrFile.scala 44:25]
  reg [31:0] mepc; // @[src/main/scala/rv32i/CsrFile.scala 45:25]
  reg [31:0] mcause; // @[src/main/scala/rv32i/CsrFile.scala 46:25]
  reg [31:0] mtval; // @[src/main/scala/rv32i/CsrFile.scala 47:25]
  reg [63:0] mcycle; // @[src/main/scala/rv32i/CsrFile.scala 48:25]
  reg [63:0] minstret; // @[src/main/scala/rv32i/CsrFile.scala 49:25]
  wire [31:0] mstatus = {21'h3,3'h0,mpie,3'h0,mie_,3'h0}; // @[src/main/scala/rv32i/CsrFile.scala 51:20]
  wire  hit_0 = io_addr == 12'h300; // @[src/main/scala/rv32i/CsrFile.scala 79:53]
  wire  hit_1 = io_addr == 12'h301; // @[src/main/scala/rv32i/CsrFile.scala 79:53]
  wire  hit_2 = io_addr == 12'h304; // @[src/main/scala/rv32i/CsrFile.scala 79:53]
  wire  hit_3 = io_addr == 12'h305; // @[src/main/scala/rv32i/CsrFile.scala 79:53]
  wire  hit_4 = io_addr == 12'h310; // @[src/main/scala/rv32i/CsrFile.scala 79:53]
  wire  hit_5 = io_addr == 12'h340; // @[src/main/scala/rv32i/CsrFile.scala 79:53]
  wire  hit_6 = io_addr == 12'h341; // @[src/main/scala/rv32i/CsrFile.scala 79:53]
  wire  hit_7 = io_addr == 12'h342; // @[src/main/scala/rv32i/CsrFile.scala 79:53]
  wire  hit_8 = io_addr == 12'h343; // @[src/main/scala/rv32i/CsrFile.scala 79:53]
  wire  hit_9 = io_addr == 12'h344; // @[src/main/scala/rv32i/CsrFile.scala 79:53]
  wire  hit_10 = io_addr == 12'hb00; // @[src/main/scala/rv32i/CsrFile.scala 79:53]
  wire  hit_11 = io_addr == 12'hb80; // @[src/main/scala/rv32i/CsrFile.scala 79:53]
  wire  hit_12 = io_addr == 12'hb02; // @[src/main/scala/rv32i/CsrFile.scala 79:53]
  wire  hit_13 = io_addr == 12'hb82; // @[src/main/scala/rv32i/CsrFile.scala 79:53]
  wire  hit_14 = io_addr == 12'hc00; // @[src/main/scala/rv32i/CsrFile.scala 79:53]
  wire  hit_15 = io_addr == 12'hc80; // @[src/main/scala/rv32i/CsrFile.scala 79:53]
  wire  hit_16 = io_addr == 12'hc02; // @[src/main/scala/rv32i/CsrFile.scala 79:53]
  wire  hit_17 = io_addr == 12'hc82; // @[src/main/scala/rv32i/CsrFile.scala 79:53]
  wire  hit_18 = io_addr == 12'hf11; // @[src/main/scala/rv32i/CsrFile.scala 79:53]
  wire  hit_19 = io_addr == 12'hf12; // @[src/main/scala/rv32i/CsrFile.scala 79:53]
  wire  hit_20 = io_addr == 12'hf13; // @[src/main/scala/rv32i/CsrFile.scala 79:53]
  wire  hit_21 = io_addr == 12'hf14; // @[src/main/scala/rv32i/CsrFile.scala 79:53]
  wire  known = hit_0 | hit_1 | hit_2 | hit_3 | hit_4 | hit_5 | hit_6 | hit_7 | hit_8 | hit_9 | hit_10 | hit_11 | hit_12
     | hit_13 | hit_14 | hit_15 | hit_16 | hit_17 | hit_18 | hit_19 | hit_20 | hit_21; // @[src/main/scala/rv32i/CsrFile.scala 80:31]
  wire [31:0] _old_T = hit_0 ? mstatus : 32'h0; // @[src/main/scala/chisel3/util/Mux.scala 30:73]
  wire [31:0] _old_T_1 = hit_1 ? 32'h40000100 : 32'h0; // @[src/main/scala/chisel3/util/Mux.scala 30:73]
  wire [31:0] _old_T_2 = hit_2 ? mieReg : 32'h0; // @[src/main/scala/chisel3/util/Mux.scala 30:73]
  wire [31:0] _old_T_3 = hit_3 ? mtvec : 32'h0; // @[src/main/scala/chisel3/util/Mux.scala 30:73]
  wire [31:0] _old_T_5 = hit_5 ? mscratch : 32'h0; // @[src/main/scala/chisel3/util/Mux.scala 30:73]
  wire [31:0] _old_T_6 = hit_6 ? mepc : 32'h0; // @[src/main/scala/chisel3/util/Mux.scala 30:73]
  wire [31:0] _old_T_7 = hit_7 ? mcause : 32'h0; // @[src/main/scala/chisel3/util/Mux.scala 30:73]
  wire [31:0] _old_T_8 = hit_8 ? mtval : 32'h0; // @[src/main/scala/chisel3/util/Mux.scala 30:73]
  wire [31:0] _old_T_10 = hit_10 ? mcycle[31:0] : 32'h0; // @[src/main/scala/chisel3/util/Mux.scala 30:73]
  wire [31:0] _old_T_11 = hit_11 ? mcycle[63:32] : 32'h0; // @[src/main/scala/chisel3/util/Mux.scala 30:73]
  wire [31:0] _old_T_12 = hit_12 ? minstret[31:0] : 32'h0; // @[src/main/scala/chisel3/util/Mux.scala 30:73]
  wire [31:0] _old_T_13 = hit_13 ? minstret[63:32] : 32'h0; // @[src/main/scala/chisel3/util/Mux.scala 30:73]
  wire [31:0] _old_T_14 = hit_14 ? mcycle[31:0] : 32'h0; // @[src/main/scala/chisel3/util/Mux.scala 30:73]
  wire [31:0] _old_T_15 = hit_15 ? mcycle[63:32] : 32'h0; // @[src/main/scala/chisel3/util/Mux.scala 30:73]
  wire [31:0] _old_T_16 = hit_16 ? minstret[31:0] : 32'h0; // @[src/main/scala/chisel3/util/Mux.scala 30:73]
  wire [31:0] _old_T_17 = hit_17 ? minstret[63:32] : 32'h0; // @[src/main/scala/chisel3/util/Mux.scala 30:73]
  wire [31:0] _old_T_22 = _old_T | _old_T_1; // @[src/main/scala/chisel3/util/Mux.scala 30:73]
  wire [31:0] _old_T_23 = _old_T_22 | _old_T_2; // @[src/main/scala/chisel3/util/Mux.scala 30:73]
  wire [31:0] _old_T_24 = _old_T_23 | _old_T_3; // @[src/main/scala/chisel3/util/Mux.scala 30:73]
  wire [31:0] _old_T_26 = _old_T_24 | _old_T_5; // @[src/main/scala/chisel3/util/Mux.scala 30:73]
  wire [31:0] _old_T_27 = _old_T_26 | _old_T_6; // @[src/main/scala/chisel3/util/Mux.scala 30:73]
  wire [31:0] _old_T_28 = _old_T_27 | _old_T_7; // @[src/main/scala/chisel3/util/Mux.scala 30:73]
  wire [31:0] _old_T_29 = _old_T_28 | _old_T_8; // @[src/main/scala/chisel3/util/Mux.scala 30:73]
  wire [31:0] _old_T_31 = _old_T_29 | _old_T_10; // @[src/main/scala/chisel3/util/Mux.scala 30:73]
  wire [31:0] _old_T_32 = _old_T_31 | _old_T_11; // @[src/main/scala/chisel3/util/Mux.scala 30:73]
  wire [31:0] _old_T_33 = _old_T_32 | _old_T_12; // @[src/main/scala/chisel3/util/Mux.scala 30:73]
  wire [31:0] _old_T_34 = _old_T_33 | _old_T_13; // @[src/main/scala/chisel3/util/Mux.scala 30:73]
  wire [31:0] _old_T_35 = _old_T_34 | _old_T_14; // @[src/main/scala/chisel3/util/Mux.scala 30:73]
  wire [31:0] _old_T_36 = _old_T_35 | _old_T_15; // @[src/main/scala/chisel3/util/Mux.scala 30:73]
  wire [31:0] _old_T_37 = _old_T_36 | _old_T_16; // @[src/main/scala/chisel3/util/Mux.scala 30:73]
  wire [31:0] old = _old_T_37 | _old_T_17; // @[src/main/scala/chisel3/util/Mux.scala 30:73]
  wire  readOnly = io_addr[11:10] == 2'h3; // @[src/main/scala/rv32i/CsrFile.scala 82:34]
  wire [31:0] _wval_T = old | io_src; // @[src/main/scala/rv32i/CsrFile.scala 88:17]
  wire [31:0] _wval_T_1 = ~io_src; // @[src/main/scala/rv32i/CsrFile.scala 89:19]
  wire [31:0] _wval_T_2 = old & _wval_T_1; // @[src/main/scala/rv32i/CsrFile.scala 89:17]
  wire [31:0] _wval_T_6 = 2'h2 == io_op ? _wval_T : io_src; // @[src/main/scala/rv32i/CsrFile.scala 86:38]
  wire [31:0] wval = 2'h3 == io_op ? _wval_T_2 : _wval_T_6; // @[src/main/scala/rv32i/CsrFile.scala 86:38]
  wire  doWrite = io_en & io_wrEn & io_commit & ~io_illegal; // @[src/main/scala/rv32i/CsrFile.scala 91:47]
  wire [63:0] cycleInc = mcycle + 64'h1; // @[src/main/scala/rv32i/CsrFile.scala 95:27]
  wire [63:0] _GEN_15 = {{63'd0}, io_commit}; // @[src/main/scala/rv32i/CsrFile.scala 96:29]
  wire [63:0] instretInc = minstret + _GEN_15; // @[src/main/scala/rv32i/CsrFile.scala 96:29]
  wire  _mcycle_T_1 = doWrite & hit_10; // @[src/main/scala/rv32i/CsrFile.scala 92:34]
  wire [63:0] _mcycle_T_3 = {cycleInc[63:32],wval}; // @[src/main/scala/rv32i/CsrFile.scala 98:24]
  wire  _mcycle_T_5 = doWrite & hit_11; // @[src/main/scala/rv32i/CsrFile.scala 92:34]
  wire [63:0] _mcycle_T_7 = {wval,cycleInc[31:0]}; // @[src/main/scala/rv32i/CsrFile.scala 99:32]
  wire  _minstret_T_1 = doWrite & hit_12; // @[src/main/scala/rv32i/CsrFile.scala 92:34]
  wire [63:0] _minstret_T_3 = {instretInc[63:32],wval}; // @[src/main/scala/rv32i/CsrFile.scala 102:26]
  wire  _minstret_T_5 = doWrite & hit_13; // @[src/main/scala/rv32i/CsrFile.scala 92:34]
  wire [63:0] _minstret_T_7 = {wval,instretInc[31:0]}; // @[src/main/scala/rv32i/CsrFile.scala 103:34]
  wire  _T_9 = doWrite & hit_0; // @[src/main/scala/rv32i/CsrFile.scala 92:34]
  wire  _GEN_1 = _T_9 ? wval[7] : mpie; // @[src/main/scala/rv32i/CsrFile.scala 107:{23,47} 41:25]
  wire  _T_11 = doWrite & hit_2; // @[src/main/scala/rv32i/CsrFile.scala 92:34]
  wire [31:0] _mieReg_T = wval & 32'h888; // @[src/main/scala/rv32i/CsrFile.scala 108:40]
  wire  _T_13 = doWrite & hit_3; // @[src/main/scala/rv32i/CsrFile.scala 92:34]
  wire [31:0] _mtvec_T_1 = {wval[31:2],2'h0}; // @[src/main/scala/rv32i/CsrFile.scala 109:37]
  wire  _T_15 = doWrite & hit_5; // @[src/main/scala/rv32i/CsrFile.scala 92:34]
  wire  _T_17 = doWrite & hit_6; // @[src/main/scala/rv32i/CsrFile.scala 92:34]
  wire  _T_19 = doWrite & hit_7; // @[src/main/scala/rv32i/CsrFile.scala 92:34]
  wire  _T_21 = doWrite & hit_8; // @[src/main/scala/rv32i/CsrFile.scala 92:34]
  wire  _GEN_9 = io_mretEnter | _GEN_1; // @[src/main/scala/rv32i/CsrFile.scala 123:28 125:10]
  assign io_rdata = known ? old : 32'h0; // @[src/main/scala/rv32i/CsrFile.scala 83:20]
  assign io_illegal = io_en & (~known | readOnly & io_wrEn); // @[src/main/scala/rv32i/CsrFile.scala 84:23]
  assign io_mtvecBase = mtvec; // @[src/main/scala/rv32i/CsrFile.scala 128:16]
  assign io_mepc = mepc; // @[src/main/scala/rv32i/CsrFile.scala 129:16]
  always @(posedge clock) begin
    if (reset) begin // @[src/main/scala/rv32i/CsrFile.scala 40:25]
      mie_ <= 1'h0; // @[src/main/scala/rv32i/CsrFile.scala 40:25]
    end else if (io_trapEnter) begin // @[src/main/scala/rv32i/CsrFile.scala 117:22]
      mie_ <= 1'h0; // @[src/main/scala/rv32i/CsrFile.scala 122:12]
    end else if (io_mretEnter) begin // @[src/main/scala/rv32i/CsrFile.scala 123:28]
      mie_ <= mpie; // @[src/main/scala/rv32i/CsrFile.scala 124:10]
    end else if (_T_9) begin // @[src/main/scala/rv32i/CsrFile.scala 107:23]
      mie_ <= wval[3]; // @[src/main/scala/rv32i/CsrFile.scala 107:30]
    end
    if (reset) begin // @[src/main/scala/rv32i/CsrFile.scala 41:25]
      mpie <= 1'h0; // @[src/main/scala/rv32i/CsrFile.scala 41:25]
    end else if (io_trapEnter) begin // @[src/main/scala/rv32i/CsrFile.scala 117:22]
      mpie <= mie_; // @[src/main/scala/rv32i/CsrFile.scala 121:12]
    end else begin
      mpie <= _GEN_9;
    end
    if (reset) begin // @[src/main/scala/rv32i/CsrFile.scala 42:25]
      mieReg <= 32'h0; // @[src/main/scala/rv32i/CsrFile.scala 42:25]
    end else if (_T_11) begin // @[src/main/scala/rv32i/CsrFile.scala 108:23]
      mieReg <= _mieReg_T; // @[src/main/scala/rv32i/CsrFile.scala 108:32]
    end
    if (reset) begin // @[src/main/scala/rv32i/CsrFile.scala 43:25]
      mtvec <= 32'h0; // @[src/main/scala/rv32i/CsrFile.scala 43:25]
    end else if (_T_13) begin // @[src/main/scala/rv32i/CsrFile.scala 109:23]
      mtvec <= _mtvec_T_1; // @[src/main/scala/rv32i/CsrFile.scala 109:31]
    end
    if (reset) begin // @[src/main/scala/rv32i/CsrFile.scala 44:25]
      mscratch <= 32'h0; // @[src/main/scala/rv32i/CsrFile.scala 44:25]
    end else if (_T_15) begin // @[src/main/scala/rv32i/CsrFile.scala 110:24]
      if (2'h3 == io_op) begin // @[src/main/scala/rv32i/CsrFile.scala 86:38]
        mscratch <= _wval_T_2;
      end else if (2'h2 == io_op) begin // @[src/main/scala/rv32i/CsrFile.scala 86:38]
        mscratch <= _wval_T;
      end else begin
        mscratch <= io_src;
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/CsrFile.scala 45:25]
      mepc <= 32'h0; // @[src/main/scala/rv32i/CsrFile.scala 45:25]
    end else if (io_trapEnter) begin // @[src/main/scala/rv32i/CsrFile.scala 117:22]
      mepc <= io_trapPc; // @[src/main/scala/rv32i/CsrFile.scala 118:12]
    end else if (_T_17) begin // @[src/main/scala/rv32i/CsrFile.scala 111:23]
      mepc <= _mtvec_T_1; // @[src/main/scala/rv32i/CsrFile.scala 111:30]
    end
    if (reset) begin // @[src/main/scala/rv32i/CsrFile.scala 46:25]
      mcause <= 32'h0; // @[src/main/scala/rv32i/CsrFile.scala 46:25]
    end else if (io_trapEnter) begin // @[src/main/scala/rv32i/CsrFile.scala 117:22]
      mcause <= io_trapCause; // @[src/main/scala/rv32i/CsrFile.scala 119:12]
    end else if (_T_19) begin // @[src/main/scala/rv32i/CsrFile.scala 112:23]
      if (2'h3 == io_op) begin // @[src/main/scala/rv32i/CsrFile.scala 86:38]
        mcause <= _wval_T_2;
      end else begin
        mcause <= _wval_T_6;
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/CsrFile.scala 47:25]
      mtval <= 32'h0; // @[src/main/scala/rv32i/CsrFile.scala 47:25]
    end else if (io_trapEnter) begin // @[src/main/scala/rv32i/CsrFile.scala 117:22]
      mtval <= io_trapVal; // @[src/main/scala/rv32i/CsrFile.scala 120:12]
    end else if (_T_21) begin // @[src/main/scala/rv32i/CsrFile.scala 113:23]
      if (2'h3 == io_op) begin // @[src/main/scala/rv32i/CsrFile.scala 86:38]
        mtval <= _wval_T_2;
      end else begin
        mtval <= _wval_T_6;
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/CsrFile.scala 48:25]
      mcycle <= 64'h0; // @[src/main/scala/rv32i/CsrFile.scala 48:25]
    end else if (_mcycle_T_1) begin // @[src/main/scala/chisel3/util/Mux.scala 141:16]
      mcycle <= _mcycle_T_3;
    end else if (_mcycle_T_5) begin // @[src/main/scala/chisel3/util/Mux.scala 141:16]
      mcycle <= _mcycle_T_7;
    end else begin
      mcycle <= cycleInc;
    end
    if (reset) begin // @[src/main/scala/rv32i/CsrFile.scala 49:25]
      minstret <= 64'h0; // @[src/main/scala/rv32i/CsrFile.scala 49:25]
    end else if (_minstret_T_1) begin // @[src/main/scala/chisel3/util/Mux.scala 141:16]
      minstret <= _minstret_T_3;
    end else if (_minstret_T_5) begin // @[src/main/scala/chisel3/util/Mux.scala 141:16]
      minstret <= _minstret_T_7;
    end else begin
      minstret <= instretInc;
    end
  end
// Register and memory initialization
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif
`ifndef RANDOM
`define RANDOM $random
`endif
`ifdef RANDOMIZE_MEM_INIT
  integer initvar;
`endif
`ifndef SYNTHESIS
`ifdef FIRRTL_BEFORE_INITIAL
`FIRRTL_BEFORE_INITIAL
`endif
initial begin
  `ifdef RANDOMIZE
    `ifdef INIT_RANDOM
      `INIT_RANDOM
    `endif
    `ifndef VERILATOR
      `ifdef RANDOMIZE_DELAY
        #`RANDOMIZE_DELAY begin end
      `else
        #0.002 begin end
      `endif
    `endif
`ifdef RANDOMIZE_REG_INIT
  _RAND_0 = {1{`RANDOM}};
  mie_ = _RAND_0[0:0];
  _RAND_1 = {1{`RANDOM}};
  mpie = _RAND_1[0:0];
  _RAND_2 = {1{`RANDOM}};
  mieReg = _RAND_2[31:0];
  _RAND_3 = {1{`RANDOM}};
  mtvec = _RAND_3[31:0];
  _RAND_4 = {1{`RANDOM}};
  mscratch = _RAND_4[31:0];
  _RAND_5 = {1{`RANDOM}};
  mepc = _RAND_5[31:0];
  _RAND_6 = {1{`RANDOM}};
  mcause = _RAND_6[31:0];
  _RAND_7 = {1{`RANDOM}};
  mtval = _RAND_7[31:0];
  _RAND_8 = {2{`RANDOM}};
  mcycle = _RAND_8[63:0];
  _RAND_9 = {2{`RANDOM}};
  minstret = _RAND_9[63:0];
`endif // RANDOMIZE_REG_INIT
  `endif // RANDOMIZE
end // initial
`ifdef FIRRTL_AFTER_INITIAL
`FIRRTL_AFTER_INITIAL
`endif
`endif // SYNTHESIS
endmodule
module Core(
  input         clock,
  input         reset,
  output [31:0] io_imem_addr, // @[src/main/scala/rv32i/Core.scala 25:14]
  input  [31:0] io_imem_data, // @[src/main/scala/rv32i/Core.scala 25:14]
  output [31:0] io_dmem_addr, // @[src/main/scala/rv32i/Core.scala 25:14]
  output        io_dmem_re, // @[src/main/scala/rv32i/Core.scala 25:14]
  output        io_dmem_we, // @[src/main/scala/rv32i/Core.scala 25:14]
  output [31:0] io_dmem_wdata, // @[src/main/scala/rv32i/Core.scala 25:14]
  output [3:0]  io_dmem_wstrb, // @[src/main/scala/rv32i/Core.scala 25:14]
  input  [31:0] io_dmem_rdata, // @[src/main/scala/rv32i/Core.scala 25:14]
  output        io_trace_valid, // @[src/main/scala/rv32i/Core.scala 25:14]
  output        io_trace_trap, // @[src/main/scala/rv32i/Core.scala 25:14]
  output [3:0]  io_trace_cause, // @[src/main/scala/rv32i/Core.scala 25:14]
  output [31:0] io_trace_pc, // @[src/main/scala/rv32i/Core.scala 25:14]
  output [31:0] io_trace_pcNext, // @[src/main/scala/rv32i/Core.scala 25:14]
  output [31:0] io_trace_inst, // @[src/main/scala/rv32i/Core.scala 25:14]
  output [4:0]  io_trace_rdAddr, // @[src/main/scala/rv32i/Core.scala 25:14]
  output [31:0] io_trace_rdData, // @[src/main/scala/rv32i/Core.scala 25:14]
  output [31:0] io_trace_memAddr, // @[src/main/scala/rv32i/Core.scala 25:14]
  output        io_trace_memRe, // @[src/main/scala/rv32i/Core.scala 25:14]
  output        io_trace_memWe, // @[src/main/scala/rv32i/Core.scala 25:14]
  output [1:0]  io_trace_memSize, // @[src/main/scala/rv32i/Core.scala 25:14]
  output [31:0] io_trace_memWdata // @[src/main/scala/rv32i/Core.scala 25:14]
);
`ifdef RANDOMIZE_REG_INIT
  reg [31:0] _RAND_0;
`endif // RANDOMIZE_REG_INIT
  wire [31:0] dec_io_inst; // @[src/main/scala/rv32i/Core.scala 38:20]
  wire [4:0] dec_io_rs1; // @[src/main/scala/rv32i/Core.scala 38:20]
  wire [4:0] dec_io_rs2; // @[src/main/scala/rv32i/Core.scala 38:20]
  wire [4:0] dec_io_rd; // @[src/main/scala/rv32i/Core.scala 38:20]
  wire [2:0] dec_io_immSel; // @[src/main/scala/rv32i/Core.scala 38:20]
  wire [1:0] dec_io_aluSrcA; // @[src/main/scala/rv32i/Core.scala 38:20]
  wire  dec_io_aluSrcImm; // @[src/main/scala/rv32i/Core.scala 38:20]
  wire [3:0] dec_io_aluOp; // @[src/main/scala/rv32i/Core.scala 38:20]
  wire  dec_io_branch; // @[src/main/scala/rv32i/Core.scala 38:20]
  wire  dec_io_jal; // @[src/main/scala/rv32i/Core.scala 38:20]
  wire  dec_io_jalr; // @[src/main/scala/rv32i/Core.scala 38:20]
  wire  dec_io_memRead; // @[src/main/scala/rv32i/Core.scala 38:20]
  wire  dec_io_memWrite; // @[src/main/scala/rv32i/Core.scala 38:20]
  wire [1:0] dec_io_memSize; // @[src/main/scala/rv32i/Core.scala 38:20]
  wire  dec_io_memUnsigned; // @[src/main/scala/rv32i/Core.scala 38:20]
  wire [1:0] dec_io_wbSel; // @[src/main/scala/rv32i/Core.scala 38:20]
  wire  dec_io_regWrite; // @[src/main/scala/rv32i/Core.scala 38:20]
  wire  dec_io_csr; // @[src/main/scala/rv32i/Core.scala 38:20]
  wire  dec_io_ecall; // @[src/main/scala/rv32i/Core.scala 38:20]
  wire  dec_io_ebreak; // @[src/main/scala/rv32i/Core.scala 38:20]
  wire  dec_io_mret; // @[src/main/scala/rv32i/Core.scala 38:20]
  wire  dec_io_illegal; // @[src/main/scala/rv32i/Core.scala 38:20]
  wire [31:0] immg_io_inst; // @[src/main/scala/rv32i/Core.scala 39:20]
  wire [2:0] immg_io_sel; // @[src/main/scala/rv32i/Core.scala 39:20]
  wire [31:0] immg_io_imm; // @[src/main/scala/rv32i/Core.scala 39:20]
  wire  rf_clock; // @[src/main/scala/rv32i/Core.scala 40:20]
  wire  rf_reset; // @[src/main/scala/rv32i/Core.scala 40:20]
  wire [4:0] rf_io_rs1; // @[src/main/scala/rv32i/Core.scala 40:20]
  wire [4:0] rf_io_rs2; // @[src/main/scala/rv32i/Core.scala 40:20]
  wire [31:0] rf_io_rd1; // @[src/main/scala/rv32i/Core.scala 40:20]
  wire [31:0] rf_io_rd2; // @[src/main/scala/rv32i/Core.scala 40:20]
  wire  rf_io_we; // @[src/main/scala/rv32i/Core.scala 40:20]
  wire [4:0] rf_io_waddr; // @[src/main/scala/rv32i/Core.scala 40:20]
  wire [31:0] rf_io_wdata; // @[src/main/scala/rv32i/Core.scala 40:20]
  wire [3:0] alu_io_op; // @[src/main/scala/rv32i/Core.scala 41:20]
  wire [31:0] alu_io_a; // @[src/main/scala/rv32i/Core.scala 41:20]
  wire [31:0] alu_io_b; // @[src/main/scala/rv32i/Core.scala 41:20]
  wire [31:0] alu_io_y; // @[src/main/scala/rv32i/Core.scala 41:20]
  wire  csr_clock; // @[src/main/scala/rv32i/Core.scala 42:20]
  wire  csr_reset; // @[src/main/scala/rv32i/Core.scala 42:20]
  wire [11:0] csr_io_addr; // @[src/main/scala/rv32i/Core.scala 42:20]
  wire  csr_io_en; // @[src/main/scala/rv32i/Core.scala 42:20]
  wire [1:0] csr_io_op; // @[src/main/scala/rv32i/Core.scala 42:20]
  wire [31:0] csr_io_src; // @[src/main/scala/rv32i/Core.scala 42:20]
  wire  csr_io_wrEn; // @[src/main/scala/rv32i/Core.scala 42:20]
  wire [31:0] csr_io_rdata; // @[src/main/scala/rv32i/Core.scala 42:20]
  wire  csr_io_illegal; // @[src/main/scala/rv32i/Core.scala 42:20]
  wire  csr_io_commit; // @[src/main/scala/rv32i/Core.scala 42:20]
  wire  csr_io_trapEnter; // @[src/main/scala/rv32i/Core.scala 42:20]
  wire [31:0] csr_io_trapCause; // @[src/main/scala/rv32i/Core.scala 42:20]
  wire [31:0] csr_io_trapPc; // @[src/main/scala/rv32i/Core.scala 42:20]
  wire [31:0] csr_io_trapVal; // @[src/main/scala/rv32i/Core.scala 42:20]
  wire  csr_io_mretEnter; // @[src/main/scala/rv32i/Core.scala 42:20]
  wire [31:0] csr_io_mtvecBase; // @[src/main/scala/rv32i/Core.scala 42:20]
  wire [31:0] csr_io_mepc; // @[src/main/scala/rv32i/Core.scala 42:20]
  reg [31:0] pc; // @[src/main/scala/rv32i/Core.scala 33:19]
  wire [2:0] f3 = io_imem_data[14:12]; // @[src/main/scala/rv32i/Core.scala 36:18]
  wire [1:0] _T_1 = dec_io_aluSrcA; // @[src/main/scala/rv32i/Core.scala 55:26]
  wire [31:0] _GEN_0 = 2'h2 == _T_1 ? 32'h0 : rf_io_rd1; // @[src/main/scala/rv32i/Core.scala 54:25 55:26 58:26]
  wire [31:0] _GEN_1 = 2'h1 == _T_1 ? pc : _GEN_0; // @[src/main/scala/rv32i/Core.scala 55:26 57:26]
  wire  eq = rf_io_rd1 == rf_io_rd2; // @[src/main/scala/rv32i/Core.scala 66:18]
  wire  lt = $signed(rf_io_rd1) < $signed(rf_io_rd2); // @[src/main/scala/rv32i/Core.scala 67:25]
  wire  ltu = rf_io_rd1 < rf_io_rd2; // @[src/main/scala/rv32i/Core.scala 68:18]
  wire  _GEN_3 = 3'h7 == f3 & ~ltu; // @[src/main/scala/rv32i/Core.scala 70:14 69:27 76:27]
  wire  _GEN_4 = 3'h6 == f3 ? ltu : _GEN_3; // @[src/main/scala/rv32i/Core.scala 70:14 75:27]
  wire  _GEN_5 = 3'h5 == f3 ? ~lt : _GEN_4; // @[src/main/scala/rv32i/Core.scala 70:14 74:27]
  wire  _GEN_6 = 3'h4 == f3 ? lt : _GEN_5; // @[src/main/scala/rv32i/Core.scala 70:14 73:27]
  wire  _GEN_7 = 3'h1 == f3 ? ~eq : _GEN_6; // @[src/main/scala/rv32i/Core.scala 70:14 72:27]
  wire  brCond = 3'h0 == f3 ? eq : _GEN_7; // @[src/main/scala/rv32i/Core.scala 70:14 71:27]
  wire  brTaken = dec_io_branch & brCond; // @[src/main/scala/rv32i/Core.scala 78:34]
  wire [31:0] pcPlus4 = pc + 32'h4; // @[src/main/scala/rv32i/Core.scala 79:23]
  wire [31:0] brTarget = pc + immg_io_imm; // @[src/main/scala/rv32i/Core.scala 80:23]
  wire [31:0] jalrTarget = {alu_io_y[31:1],1'h0}; // @[src/main/scala/rv32i/Core.scala 81:23]
  wire  ctlTaken = brTaken | dec_io_jal | dec_io_jalr; // @[src/main/scala/rv32i/Core.scala 82:42]
  wire [31:0] ctlTarget = dec_io_jalr ? jalrTarget : brTarget; // @[src/main/scala/rv32i/Core.scala 83:23]
  wire  _misalignedAccess_T_4 = dec_io_memSize == 2'h1; // @[src/main/scala/rv32i/Core.scala 87:72]
  wire  misalignedAccess = dec_io_memSize == 2'h2 & alu_io_y[1:0] != 2'h0 | dec_io_memSize == 2'h1 & alu_io_y[0]; // @[src/main/scala/rv32i/Core.scala 87:63]
  wire  loadMis = dec_io_memRead & misalignedAccess; // @[src/main/scala/rv32i/Core.scala 88:33]
  wire  storeMis = dec_io_memWrite & misalignedAccess; // @[src/main/scala/rv32i/Core.scala 89:34]
  wire  fetchMis = ctlTaken & ctlTarget[1]; // @[src/main/scala/rv32i/Core.scala 90:27]
  wire [4:0] rs1Field = io_imem_data[19:15]; // @[src/main/scala/rv32i/Core.scala 93:22]
  wire [31:0] _csr_io_src_T_1 = {27'h0,rs1Field}; // @[src/main/scala/rv32i/Core.scala 97:34]
  wire  illegal = dec_io_illegal | csr_io_illegal; // @[src/main/scala/rv32i/Core.scala 100:32]
  wire  trapNow = illegal | dec_io_ecall | dec_io_ebreak | loadMis | storeMis | fetchMis; // @[src/main/scala/rv32i/Core.scala 101:81]
  wire [3:0] _cause_T = storeMis ? 4'h6 : 4'h0; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [3:0] _cause_T_1 = loadMis ? 4'h4 : _cause_T; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [3:0] _cause_T_2 = dec_io_ebreak ? 4'h3 : _cause_T_1; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [3:0] _cause_T_3 = dec_io_ecall ? 4'hb : _cause_T_2; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [3:0] cause = illegal ? 4'h2 : _cause_T_3; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire  _tval_T = loadMis | storeMis; // @[src/main/scala/rv32i/Core.scala 115:14]
  wire [31:0] _tval_T_1 = _tval_T ? alu_io_y : ctlTarget; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [31:0] _tval_T_2 = dec_io_ebreak ? pc : _tval_T_1; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [31:0] _tval_T_3 = dec_io_ecall ? 32'h0 : _tval_T_2; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire  retire = ~trapNow; // @[src/main/scala/rv32i/Core.scala 119:16]
  wire [31:0] _nextPc_T = ctlTaken ? ctlTarget : pcPlus4; // @[src/main/scala/rv32i/Core.scala 131:19]
  wire [31:0] _nextPc_T_1 = dec_io_mret ? csr_io_mepc : _nextPc_T; // @[src/main/scala/rv32i/Core.scala 130:19]
  wire [7:0] bytes_0 = io_dmem_rdata[7:0]; // @[src/main/scala/rv32i/Core.scala 136:49]
  wire [7:0] bytes_1 = io_dmem_rdata[15:8]; // @[src/main/scala/rv32i/Core.scala 136:49]
  wire [7:0] bytes_2 = io_dmem_rdata[23:16]; // @[src/main/scala/rv32i/Core.scala 136:49]
  wire [7:0] bytes_3 = io_dmem_rdata[31:24]; // @[src/main/scala/rv32i/Core.scala 136:49]
  wire [15:0] h = alu_io_y[1] ? io_dmem_rdata[31:16] : io_dmem_rdata[15:0]; // @[src/main/scala/rv32i/Core.scala 138:18]
  wire  _T_15 = 2'h0 == dec_io_memSize; // @[src/main/scala/rv32i/Core.scala 141:16]
  wire [7:0] _GEN_10 = 2'h1 == alu_io_y[1:0] ? bytes_1 : bytes_0; // @[src/main/scala/rv32i/Core.scala 142:{39,39}]
  wire [7:0] _GEN_11 = 2'h2 == alu_io_y[1:0] ? bytes_2 : _GEN_10; // @[src/main/scala/rv32i/Core.scala 142:{39,39}]
  wire [7:0] _GEN_12 = 2'h3 == alu_io_y[1:0] ? bytes_3 : _GEN_11; // @[src/main/scala/rv32i/Core.scala 142:{39,39}]
  wire [31:0] _loadData_T = {24'h0,_GEN_12}; // @[src/main/scala/rv32i/Core.scala 142:39]
  wire [23:0] _loadData_T_2 = _GEN_12[7] ? 24'hffffff : 24'h0; // @[src/main/scala/rv32i/Core.scala 142:63]
  wire [31:0] _loadData_T_3 = {_loadData_T_2,_GEN_12}; // @[src/main/scala/rv32i/Core.scala 142:58]
  wire [31:0] _loadData_T_4 = dec_io_memUnsigned ? _loadData_T : _loadData_T_3; // @[src/main/scala/rv32i/Core.scala 142:30]
  wire  _T_16 = 2'h1 == dec_io_memSize; // @[src/main/scala/rv32i/Core.scala 141:16]
  wire [31:0] _loadData_T_5 = {16'h0,h}; // @[src/main/scala/rv32i/Core.scala 143:39]
  wire [15:0] _loadData_T_7 = h[15] ? 16'hffff : 16'h0; // @[src/main/scala/rv32i/Core.scala 143:63]
  wire [31:0] _loadData_T_8 = {_loadData_T_7,h}; // @[src/main/scala/rv32i/Core.scala 143:58]
  wire [31:0] _loadData_T_9 = dec_io_memUnsigned ? _loadData_T_5 : _loadData_T_8; // @[src/main/scala/rv32i/Core.scala 143:30]
  wire [31:0] _GEN_14 = 2'h1 == dec_io_memSize ? _loadData_T_9 : io_dmem_rdata; // @[src/main/scala/rv32i/Core.scala 141:16 143:24]
  wire [31:0] loadData = 2'h0 == dec_io_memSize ? _loadData_T_4 : _GEN_14; // @[src/main/scala/rv32i/Core.scala 141:16 142:24]
  wire [7:0] sbyte = rf_io_rd2[7:0]; // @[src/main/scala/rv32i/Core.scala 147:19]
  wire [15:0] shalf = rf_io_rd2[15:0]; // @[src/main/scala/rv32i/Core.scala 148:19]
  wire [31:0] _wdata_T_1 = {sbyte,sbyte,sbyte,sbyte}; // @[src/main/scala/rv32i/Core.scala 152:28]
  wire [6:0] _wstrb_T_1 = 7'h1 << alu_io_y[1:0]; // @[src/main/scala/rv32i/Core.scala 152:59]
  wire [31:0] _wdata_T_2 = {shalf,shalf}; // @[src/main/scala/rv32i/Core.scala 153:28]
  wire [3:0] _wstrb_T_4 = alu_io_y[1] ? 4'hc : 4'h3; // @[src/main/scala/rv32i/Core.scala 153:52]
  wire [31:0] _GEN_16 = _T_16 ? _wdata_T_2 : rf_io_rd2; // @[src/main/scala/rv32i/Core.scala 151:16 153:21 149:26]
  wire [3:0] _GEN_17 = _T_16 ? _wstrb_T_4 : 4'hf; // @[src/main/scala/rv32i/Core.scala 151:16 150:26 153:46]
  wire [3:0] wstrb = _T_15 ? _wstrb_T_1[3:0] : _GEN_17; // @[src/main/scala/rv32i/Core.scala 151:16 152:46]
  wire [1:0] _T_21 = dec_io_wbSel; // @[src/main/scala/rv32i/Core.scala 164:24]
  wire [31:0] _GEN_20 = 2'h3 == _T_21 ? csr_io_rdata : alu_io_y; // @[src/main/scala/rv32i/Core.scala 164:24 163:27 168:28]
  wire [31:0] _GEN_21 = 2'h2 == _T_21 ? pcPlus4 : _GEN_20; // @[src/main/scala/rv32i/Core.scala 164:24 167:28]
  wire [31:0] _GEN_22 = 2'h1 == _T_21 ? loadData : _GEN_21; // @[src/main/scala/rv32i/Core.scala 164:24 166:28]
  wire [31:0] wbData = 2'h0 == _T_21 ? alu_io_y : _GEN_22; // @[src/main/scala/rv32i/Core.scala 164:24 165:28]
  wire  writes = rf_io_we & dec_io_rd != 5'h0; // @[src/main/scala/rv32i/Core.scala 174:25]
  wire [31:0] _io_trace_memWdata_T_1 = {24'h0,sbyte}; // @[src/main/scala/rv32i/Core.scala 189:45]
  wire [31:0] _io_trace_memWdata_T_3 = {16'h0,shalf}; // @[src/main/scala/rv32i/Core.scala 189:86]
  wire [31:0] _io_trace_memWdata_T_4 = _misalignedAccess_T_4 ? _io_trace_memWdata_T_3 : rf_io_rd2; // @[src/main/scala/rv32i/Core.scala 189:68]
  wire  _T_34 = ~reset; // @[src/main/scala/rv32i/Core.scala 192:9]
  Decoder dec ( // @[src/main/scala/rv32i/Core.scala 38:20]
    .io_inst(dec_io_inst),
    .io_rs1(dec_io_rs1),
    .io_rs2(dec_io_rs2),
    .io_rd(dec_io_rd),
    .io_immSel(dec_io_immSel),
    .io_aluSrcA(dec_io_aluSrcA),
    .io_aluSrcImm(dec_io_aluSrcImm),
    .io_aluOp(dec_io_aluOp),
    .io_branch(dec_io_branch),
    .io_jal(dec_io_jal),
    .io_jalr(dec_io_jalr),
    .io_memRead(dec_io_memRead),
    .io_memWrite(dec_io_memWrite),
    .io_memSize(dec_io_memSize),
    .io_memUnsigned(dec_io_memUnsigned),
    .io_wbSel(dec_io_wbSel),
    .io_regWrite(dec_io_regWrite),
    .io_csr(dec_io_csr),
    .io_ecall(dec_io_ecall),
    .io_ebreak(dec_io_ebreak),
    .io_mret(dec_io_mret),
    .io_illegal(dec_io_illegal)
  );
  ImmGen immg ( // @[src/main/scala/rv32i/Core.scala 39:20]
    .io_inst(immg_io_inst),
    .io_sel(immg_io_sel),
    .io_imm(immg_io_imm)
  );
  RegFile rf ( // @[src/main/scala/rv32i/Core.scala 40:20]
    .clock(rf_clock),
    .reset(rf_reset),
    .io_rs1(rf_io_rs1),
    .io_rs2(rf_io_rs2),
    .io_rd1(rf_io_rd1),
    .io_rd2(rf_io_rd2),
    .io_we(rf_io_we),
    .io_waddr(rf_io_waddr),
    .io_wdata(rf_io_wdata)
  );
  Alu alu ( // @[src/main/scala/rv32i/Core.scala 41:20]
    .io_op(alu_io_op),
    .io_a(alu_io_a),
    .io_b(alu_io_b),
    .io_y(alu_io_y)
  );
  CsrFile csr ( // @[src/main/scala/rv32i/Core.scala 42:20]
    .clock(csr_clock),
    .reset(csr_reset),
    .io_addr(csr_io_addr),
    .io_en(csr_io_en),
    .io_op(csr_io_op),
    .io_src(csr_io_src),
    .io_wrEn(csr_io_wrEn),
    .io_rdata(csr_io_rdata),
    .io_illegal(csr_io_illegal),
    .io_commit(csr_io_commit),
    .io_trapEnter(csr_io_trapEnter),
    .io_trapCause(csr_io_trapCause),
    .io_trapPc(csr_io_trapPc),
    .io_trapVal(csr_io_trapVal),
    .io_mretEnter(csr_io_mretEnter),
    .io_mtvecBase(csr_io_mtvecBase),
    .io_mepc(csr_io_mepc)
  );
  assign io_imem_addr = pc; // @[src/main/scala/rv32i/Core.scala 34:16]
  assign io_dmem_addr = alu_io_y; // @[src/main/scala/rv32i/Core.scala 156:17]
  assign io_dmem_re = dec_io_memRead & retire; // @[src/main/scala/rv32i/Core.scala 157:35]
  assign io_dmem_we = dec_io_memWrite & retire; // @[src/main/scala/rv32i/Core.scala 158:36]
  assign io_dmem_wdata = _T_15 ? _wdata_T_1 : _GEN_16; // @[src/main/scala/rv32i/Core.scala 151:16 152:21]
  assign io_dmem_wstrb = io_dmem_we ? wstrb : 4'h0; // @[src/main/scala/rv32i/Core.scala 160:23]
  assign io_trace_valid = ~trapNow; // @[src/main/scala/rv32i/Core.scala 119:16]
  assign io_trace_trap = illegal | dec_io_ecall | dec_io_ebreak | loadMis | storeMis | fetchMis; // @[src/main/scala/rv32i/Core.scala 101:81]
  assign io_trace_cause = illegal ? 4'h2 : _cause_T_3; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  assign io_trace_pc = pc; // @[src/main/scala/rv32i/Core.scala 180:21]
  assign io_trace_pcNext = trapNow ? csr_io_mtvecBase : _nextPc_T_1; // @[src/main/scala/rv32i/Core.scala 129:19]
  assign io_trace_inst = io_imem_data; // @[src/main/scala/rv32i/Core.scala 182:21]
  assign io_trace_rdAddr = writes ? dec_io_rd : 5'h0; // @[src/main/scala/rv32i/Core.scala 183:27]
  assign io_trace_rdData = writes ? wbData : 32'h0; // @[src/main/scala/rv32i/Core.scala 184:27]
  assign io_trace_memAddr = alu_io_y; // @[src/main/scala/rv32i/Core.scala 185:21]
  assign io_trace_memRe = io_dmem_re; // @[src/main/scala/rv32i/Core.scala 186:21]
  assign io_trace_memWe = io_dmem_we; // @[src/main/scala/rv32i/Core.scala 187:21]
  assign io_trace_memSize = dec_io_memSize; // @[src/main/scala/rv32i/Core.scala 188:21]
  assign io_trace_memWdata = dec_io_memSize == 2'h0 ? _io_trace_memWdata_T_1 : _io_trace_memWdata_T_4; // @[src/main/scala/rv32i/Core.scala 189:27]
  assign dec_io_inst = io_imem_data; // @[src/main/scala/rv32i/Core.scala 44:16]
  assign immg_io_inst = io_imem_data; // @[src/main/scala/rv32i/Core.scala 45:16]
  assign immg_io_sel = dec_io_immSel; // @[src/main/scala/rv32i/Core.scala 46:16]
  assign rf_clock = clock;
  assign rf_reset = reset;
  assign rf_io_rs1 = dec_io_rs1; // @[src/main/scala/rv32i/Core.scala 47:16]
  assign rf_io_rs2 = dec_io_rs2; // @[src/main/scala/rv32i/Core.scala 48:16]
  assign rf_io_we = dec_io_regWrite & retire; // @[src/main/scala/rv32i/Core.scala 171:34]
  assign rf_io_waddr = dec_io_rd; // @[src/main/scala/rv32i/Core.scala 172:15]
  assign rf_io_wdata = 2'h0 == _T_21 ? alu_io_y : _GEN_22; // @[src/main/scala/rv32i/Core.scala 164:24 165:28]
  assign alu_io_op = dec_io_aluOp; // @[src/main/scala/rv32i/Core.scala 60:13]
  assign alu_io_a = 2'h0 == _T_1 ? rf_io_rd1 : _GEN_1; // @[src/main/scala/rv32i/Core.scala 55:26 56:26]
  assign alu_io_b = dec_io_aluSrcImm ? immg_io_imm : rf_io_rd2; // @[src/main/scala/rv32i/Core.scala 62:19]
  assign csr_clock = clock;
  assign csr_reset = reset;
  assign csr_io_addr = io_imem_data[31:20]; // @[src/main/scala/rv32i/Core.scala 94:24]
  assign csr_io_en = dec_io_csr; // @[src/main/scala/rv32i/Core.scala 95:17]
  assign csr_io_op = f3[1:0]; // @[src/main/scala/rv32i/Core.scala 96:22]
  assign csr_io_src = f3[2] ? _csr_io_src_T_1 : rf_io_rd1; // @[src/main/scala/rv32i/Core.scala 97:23]
  assign csr_io_wrEn = f3[1:0] == 2'h1 | rs1Field != 5'h0; // @[src/main/scala/rv32i/Core.scala 98:37]
  assign csr_io_commit = ~trapNow; // @[src/main/scala/rv32i/Core.scala 119:16]
  assign csr_io_trapEnter = illegal | dec_io_ecall | dec_io_ebreak | loadMis | storeMis | fetchMis; // @[src/main/scala/rv32i/Core.scala 101:81]
  assign csr_io_trapCause = {28'h0,cause}; // @[src/main/scala/rv32i/Core.scala 123:26]
  assign csr_io_trapPc = pc; // @[src/main/scala/rv32i/Core.scala 124:20]
  assign csr_io_trapVal = illegal ? io_imem_data : _tval_T_3; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  assign csr_io_mretEnter = dec_io_mret & retire; // @[src/main/scala/rv32i/Core.scala 126:35]
  always @(posedge clock) begin
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 33:19]
      pc <= 32'h80000000; // @[src/main/scala/rv32i/Core.scala 33:19]
    end else if (trapNow) begin // @[src/main/scala/rv32i/Core.scala 129:19]
      pc <= csr_io_mtvecBase;
    end else if (dec_io_mret) begin // @[src/main/scala/rv32i/Core.scala 130:19]
      pc <= csr_io_mepc;
    end else if (ctlTaken) begin // @[src/main/scala/rv32i/Core.scala 131:19]
      pc <= ctlTarget;
    end else begin
      pc <= pcPlus4;
    end
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (~reset & ~(pc[1:0] == 2'h0)) begin
          $fwrite(32'h80000002,
            "Assertion failed: pc must stay 4-byte aligned\n    at Core.scala:192 assert(pc(1, 0) === 0.U, \"pc must stay 4-byte aligned\")\n"
            ); // @[src/main/scala/rv32i/Core.scala 192:9]
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif // SYNTHESIS
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_T_34 & ~(~(io_trace_valid & io_trace_trap))) begin
          $fwrite(32'h80000002,
            "Assertion failed: retire and trap in the same cycle\n    at Core.scala:193 assert(!(io.trace.valid && io.trace.trap), \"retire and trap in the same cycle\")\n"
            ); // @[src/main/scala/rv32i/Core.scala 193:9]
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif // SYNTHESIS
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_T_34 & ~(~(io_dmem_we & io_dmem_re))) begin
          $fwrite(32'h80000002,
            "Assertion failed: simultaneous load and store\n    at Core.scala:194 assert(!(io.dmem.we && io.dmem.re), \"simultaneous load and store\")\n"
            ); // @[src/main/scala/rv32i/Core.scala 194:9]
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif // SYNTHESIS
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_T_34 & ~(~(trapNow & (rf_io_we | io_dmem_we)))) begin
          $fwrite(32'h80000002,
            "Assertion failed: trapping instruction modifies state\n    at Core.scala:195 assert(!(trapNow && (rf.io.we || io.dmem.we)), \"trapping instruction modifies state\")\n"
            ); // @[src/main/scala/rv32i/Core.scala 195:9]
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif // SYNTHESIS
  end
// Register and memory initialization
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif
`ifndef RANDOM
`define RANDOM $random
`endif
`ifdef RANDOMIZE_MEM_INIT
  integer initvar;
`endif
`ifndef SYNTHESIS
`ifdef FIRRTL_BEFORE_INITIAL
`FIRRTL_BEFORE_INITIAL
`endif
initial begin
  `ifdef RANDOMIZE
    `ifdef INIT_RANDOM
      `INIT_RANDOM
    `endif
    `ifndef VERILATOR
      `ifdef RANDOMIZE_DELAY
        #`RANDOMIZE_DELAY begin end
      `else
        #0.002 begin end
      `endif
    `endif
`ifdef RANDOMIZE_REG_INIT
  _RAND_0 = {1{`RANDOM}};
  pc = _RAND_0[31:0];
`endif // RANDOMIZE_REG_INIT
  `endif // RANDOMIZE
end // initial
`ifdef FIRRTL_AFTER_INITIAL
`FIRRTL_AFTER_INITIAL
`endif
`endif // SYNTHESIS
  always @(posedge clock) begin
    //
    if (~reset) begin
      assert(pc[1:0] == 2'h0); // @[src/main/scala/rv32i/Core.scala 192:9]
    end
    //
    if (_T_34) begin
      assert(~(io_trace_valid & io_trace_trap)); // @[src/main/scala/rv32i/Core.scala 193:9]
    end
    //
    if (_T_34) begin
      assert(~(io_dmem_we & io_dmem_re)); // @[src/main/scala/rv32i/Core.scala 194:9]
    end
    //
    if (_T_34) begin
      assert(~(trapNow & (rf_io_we | io_dmem_we))); // @[src/main/scala/rv32i/Core.scala 195:9]
    end
  end
endmodule
