# Design notes: Stage 3, single-cycle RV32I core (full base ISA + Zicsr + machine-mode traps)

## Architecture

| Item | Choice |
|---|---|
| ISA | RV32I (all 40 base instructions) + Zicsr (6) + MRET and WFI, machine mode only |
| Microarchitecture | Single cycle: fetch, decode, execute, memory and write-back in one clock |
| Reset | pc = `0x80000000` (`Core(resetPc = ...)`), registers and CSRs = 0 |
| Memories | Harvard, zero-wait ports: instruction and data read data are combinational functions of the address; stores land at the clock edge under a 4-bit byte mask |
| System (`RV32ITestWrapper`) | `InstructionMemory` (ROM from a hex file at 0x80000000) + `DataMemory` (RAM, 256 words, initial content from a hex file, at 0x80010000) |
| M extension | Not implemented: its eight encodings (OP, funct7 = 0000001) are illegal instructions |
| Interrupts | None |

## Stage progression

| Stage | Instructions | New hardware |
|---|---|---|
| 1 | R-type and I-type ALU (19) | ALU, register file, decoder, immediate generator |
| 2 | + loads, JALR (25) | Read-only data memory, load alignment, write-back mux, JALR |
| **3** | **All of RV32I + Zicsr + MRET/WFI** | **Stores (byte strobes), branches, LUI/AUIPC/JAL, CSR file, precise exceptions** |
| 4 | + MUL, MULH, MULHSU, MULHU | Combinational 33 × 33 multiplier |
| 5 | + DIV, DIVU, REM, REMU | Sequential divider (34 cycles) |

Stage 4 is this core with a `Multiplier` and with the M encodings decoded in the core instead of reported illegal.

## Execution rules

Every cycle is exactly one of:

1. **retire** (`trace.valid`): one instruction completes and its effects are visible at the edge;
2. **trap** (`trace.trap`): the instruction changes nothing except mepc, mcause, mtval, mstatus and the pc (= mtvec).

Exception priority: illegal instruction (2) > ECALL (11) > EBREAK (3) > load misaligned (4) > store misaligned (6) >
instruction address misaligned (0).

## Choices made where the specification leaves an option

| Topic | Choice | Why |
|---|---|---|
| Misaligned loads/stores | Trap (cause 4 / 6, mtval = address) | Simplest correct option; allowed by the privileged spec |
| Misaligned branch/jump targets | Trap at the branch/jump (cause 0, mtval = target), rd not written | Required with IALIGN = 32 |
| EBREAK mtval | pc | Allowed (pc or 0) |
| ECALL mtval | 0 | Required |
| Illegal-instruction mtval | The instruction word | Allowed, helps debugging |
| FENCE | No-op | Single hart, in-order, no caches |
| FENCE.I | Illegal | Zifencei is not part of the ISA |
| WFI | No-op | No interrupts to wait for |
| mtvec | Direct mode only, low two bits read as 0 | WARL |
| mepc | Bits 1:0 read as 0 | IALIGN = 32 |
| misa | `0x40000100` (RV32, I), writes ignored | Reports exactly the implemented ISA |
| mstatus | MIE (bit 3) and MPIE (bit 7) writable, MPP fixed to 11 | Machine mode only |
| mie | Only MSIE, MTIE, MEIE writable | WARL |
| mip, mstatush | Read 0, writes ignored | No interrupt sources |
| mcycle / minstret | Every clock / every retired instruction; a CSR write replaces one 32-bit half of the incremented value | Deterministic and easy to model |
| cycle/instret (user) | Read-only shadows; `time` not implemented (illegal) | No real-time clock |
| Unknown CSR / write to a read-only CSR | Illegal instruction | Required |
| Data memory | 256 words of registers with an initial content, accesses outside it read 0 and are not written | Simulates and synthesises with the same initial content; no access faults in this stage |

## Verification

- Unit tests: ALU, ImmGen, RegFile, Decoder (48 instructions with their control signals, 29 illegal encodings
  including the 8 M-extension ones, all 128 opcodes), CsrFile, InstructionMemory and DataMemory (byte strobes,
  outside accesses), the wrapper running `program.hex` on `data.hex`.
- Program tests (`CoreProgramSpec`), each in lockstep with `RefModel` (every retirement and trap compared field by
  field) and with final registers checked against independent constants: arithmetic and logic; loads and stores of
  every size; every branch both ways, JAL, JALR; dependency chains; loops in pure RV32I (gcd by subtraction, a sum,
  shift-and-add multiplication); the 8 M-extension encodings trapping as illegal; Zicsr and all six exception types;
  3,000 random instructions.
- Timing (`CoreTimingSpec`): every instruction and every trap in one cycle.
- Planted bugs: BLTU with a signed compare, SB writing all four bytes, a trap that does not go to mtvec: all caught.
