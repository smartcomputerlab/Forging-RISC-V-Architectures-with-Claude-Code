# Design notes: Stage 8, 5-stage pipelined RV32IM core with an I-cache and a D-cache

## Architecture

| Item | Choice |
|---|---|
| ISA | RV32IM (40 + 8 instructions) + Zicsr (6) + MRET and WFI, machine mode only, no interrupts |
| Pipeline | 5 stages: IF, ID, EX, MEM, WB, with forwarding and load-use detection (the Stage 7 / `rv32im-pipe5` core) |
| Multiplication | Combinational 33 × 33 multiplier in EX (1 cycle) |
| Division | Sequential divider in EX (34 cycles, 2 for divide-by-zero and signed overflow) |
| I-cache | 1 KiB, direct-mapped, 64 lines × 16 bytes (4 words), read-only |
| D-cache | 1 KiB, direct-mapped, 64 lines × 16 bytes, write-through, no-write-allocate |
| Main memory | Harvard: instruction memory (ROM, 4 KiB at 0x80000000) and data memory (RAM, 1 KiB at 0x80010000), each with a fixed latency (default 4 cycles per request), line reads and word writes |
| Cache wait | The whole pipeline freezes for that cycle (`freeze`) |

## Stage progression

| Stage | Instructions | New hardware |
|---|---|---|
| 1 | R-type and I-type ALU | ALU, register file, decoder, immediate generator |
| 2 | + loads, JALR | Read-only data memory, load alignment |
| 3 | All of RV32I + Zicsr | Stores, branches, LUI/AUIPC/JAL, CSRs, precise exceptions |
| 4 | + MUL, MULH, MULHSU, MULHU | Combinational multiplier |
| 5 | + DIV, DIVU, REM, REMU | Sequential divider |
| 6 | Same ISA | 2-stage pipeline IF / EX |
| 7 | Same ISA | 5-stage pipeline with forwarding and load-use stall (`rv32im-pipe5`) |
| **8** | **Same ISA** | **5-stage pipeline + I-cache + D-cache in front of slow main memories** |

## System

```
            ┌──────────── Core (5 stages) ────────────┐
 fetchPc ──►│ IF │ ID │ EX │ MEM │ WB │               │
            └─┬──────────────────┬────────────────────┘
   addr/data/busy             addr/re/we/wdata/wstrb/rdata/busy
              ▼                  ▼
          ┌────────┐         ┌────────┐
          │ ICache │         │ DCache │
          └───┬────┘         └───┬────┘
   line reads │         line reads, word writes
              ▼                  ▼
     instruction memory     data memory        (MainMemory, `memLatency` cycles per request)
```

## Caches

Address split for 64 sets of 16-byte lines: `| tag (22) | index (6) | word (2) | byte (2) |`.

| Access | I-cache | D-cache |
|---|---|---|
| Hit | Word in the same cycle | Load: word in the same cycle |
| Read miss | `busy`; read the line (1 request, line response after the memory latency), install it; the fetch hits one cycle later | Same for a load |
| Store | — | Always written to memory (write-through), one word under the byte mask; `busy` until memory acknowledges; `busy` = 0 in the acknowledge cycle; a present line is updated in that cycle, an absent line is not allocated |
| Ack during a freeze | — | If the core does not advance in the acknowledge cycle (the I-cache is busy), the D-cache waits in `DONE` (`busy` = 0, no request) until `advance`, so the store is written exactly once |

Miss cost with the default 4-cycle memory: about 6 cycles for a refill (request, 4 cycles, install, hit) and about
5 cycles for a store. Each cache counts accesses, misses and (D-cache) writes.

## Pipeline

| Stage | Work | Pipeline register written |
|---|---|---|
| IF | Fetch the word at `fetchPc` through the I-cache; next fetch at `fetchPc + 4` | `IfId` |
| ID | Decode, immediate, register read with WB→ID bypass, load-use detection | `IdEx` (+ `Ctrl`) |
| EX | Forwarding, ALU, multiplier, divider, branch/jump resolution, CSR access, exceptions, trap entry, commit | `ExMem` |
| MEM | Data access through the D-cache, load alignment | `MemWb` |
| WB | Register write, retirement trace | — |

Pipeline control, by priority:

| Condition | fetchPc, IfId | IdEx | ExMem | MemWb |
|---|---|---|---|---|
| `freeze` (I-cache or D-cache busy) | hold | hold | hold | hold |
| `divStall` (DIV/REM busy in EX) | hold | hold | bubble | advance |
| `redirect` (taken branch, JAL, JALR, trap, MRET in EX) | fetchPc := target, IfId := bubble | bubble | advance | advance |
| `loadUse` | hold | bubble | advance | advance |
| otherwise | advance | advance | advance | advance |

## Hazards

| Hazard | Handling | Cost |
|---|---|---|
| RAW, distance 1 | Forward `ExMem.result` into EX (not for loads) | 0 |
| RAW, distance 2 | Forward `MemWb.wdata` into EX | 0 |
| RAW, distance 3 | WB→ID bypass of the register read | 0 |
| Load-use | Stall IF/ID one cycle, bubble into EX, then forward from WB | 1 cycle |
| Control | Resolved in EX; flush IfId and IdEx | 2 cycles |
| Divider | IF/ID/EX hold; MEM and WB drain | 33 cycles |
| Cache miss / store | Whole pipeline frozen until the cache is ready | refill or write latency |

## Freeze rules

While `freeze` is high nothing in the core changes state: every pipeline register holds, and the CSR commit, trap
entry, MRET, divider start, register-file write and trace output are all gated. The caches keep working, and the
memory requests stay on the ports unchanged. The divider also keeps working: a result that arrives during a freeze is
held in `divHave`/`divHeld` until the division leaves EX, so a freeze that overlaps a division costs nothing extra.

The core drives `advance` = `!freeze` on both memory ports. The D-cache needs it: when a store is acknowledged in a
cycle where the I-cache still freezes the pipeline, the store stays in MEM, and without `advance` the D-cache would
send the same write again. (Found by `MemorySpec`: the D-cache counted 2 writes for the single store of
`program.hex`.) Both caches also count an access only when the core advances.

Each instruction carries the cycle in which it left EX (`exCycle`) to WB and the trace, because its CSR reads (mcycle)
happened then; with freezes, WB can be any number of cycles later.

## Precise exceptions

Every exception is known in EX and taken there: older instructions in MEM/WB complete, younger ones are flushed, the
trapping instruction neither accesses memory nor writes a register, and a trap record travels to WB so the trace stays
in program order. A cache freeze delays the trap but cannot reorder it.

## Choices made where the description leaves an option

| Topic | Choice | Why |
|---|---|---|
| Cache organisation | Direct-mapped, 1 KiB each, 16-byte lines | "Modest size"; the simplest cache that still shows hits, misses and conflicts |
| Write policy | Write-through, no-write-allocate | No dirty lines, no write-back on eviction; memory is always up to date |
| Store cost | Every store waits for main memory | Simplest correct option; a write buffer would hide it |
| Cache arrays | `Mem` (combinational read) for tags and lines, registers for valid bits | Same-cycle hit as the zero-wait ports of the earlier stages; synthesises to distributed RAM |
| Main memory | Two separate memories (Harvard), no arbiter | Keeps the instruction and data paths independent; a unified memory would need an arbiter between the two caches |
| Cache wait handling | Global freeze of the pipeline | Clearly correct; costs some performance on I-cache misses (older instructions do not drain) |
| Core-to-cache handshake | `advance` output on both ports | One extra wire; makes a store exactly-once whatever the other cache does |
| Freeze on a redirect | The redirect waits for the freeze to end | Simplest; the wrong-path refill completes first |
| FENCE.I / self-modifying code | Not supported (FENCE.I is illegal; instruction memory is read-only) | No I-cache invalidation needed |
| Cache flush/invalidate | None | Write-through D-cache never holds data that memory lacks |
| Memory sizes and latency | `RV32ITestWrapper(memLatency = 4, icacheParams, dcacheParams, dataDepth = 256)` | All configurable |
| misa, CSRs, traps | As in Stage 5 (`0x40001100`) | Same ISA |

## Verification

- Unit tests from the earlier stages: ALU, ImmGen, RegFile, Decoder, CsrFile, Multiplier, DivUnit, DivRef.
- `CacheSpec`: the I-cache on 3,000 random fetches and the D-cache on 3,000 random loads and stores (16-set caches so
  that conflicts happen), behind a main memory modelled in Scala that answers after a random latency. A Scala model of
  a direct-mapped directory predicts every hit and miss; every load must return the latest stored value, and at the end
  main memory must hold every store (write-through). After 30 % of the accesses `advance` stays low for 1 to 4 more
  cycles: the cache must stay done, without a new request.
- `MemorySpec`: hex parsing, `MainMemory` latency, line reads, byte-masked writes, ROM mode; `program.hex` on the cached
  system with its results, the exact I-cache and D-cache miss counts, and the write-through count.
- `FreezeSpec`: the core with random busy cycles on both ports (30–70 % of cycles) in lockstep with the reference model;
  a freeze costs exactly its length when nothing else is in progress; a freeze overlapping a division keeps the result.
- `CoreProgramSpec`, `CoreDivSpec`, `CoreTimingSpec` (the 5-stage timing contract, including forwarding, load-use and
  wrong-path tests) on the core with zero-wait ports, in lockstep with `RefModel`.
- `WaveformSpec`: seven demos, including `program.hex` through the caches.
