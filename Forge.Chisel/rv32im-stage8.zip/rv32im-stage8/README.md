# Stage 8: 5-stage pipelined RV32IM core with an I-cache and a D-cache (Chisel 3)

The eighth core of the series, in package `rv32i`: the RV32IM 5-stage pipeline (IF, ID, EX, MEM, WB with forwarding,
load-use stall, branches resolved in EX, parallel multiplier, sequential divider, Zicsr, precise machine-mode traps)
behind two caches of modest size, in front of main memories that take several cycles per access.

| Cache | Organisation |
|---|---|
| I-cache | 1 KiB, direct-mapped, 64 lines × 16 bytes, read-only; hit in the same cycle, miss refills the line |
| D-cache | 1 KiB, direct-mapped, 64 lines × 16 bytes, write-through, no-write-allocate; load hit in the same cycle |

While a cache is busy (refill, write-through) the whole pipeline freezes for that cycle; the divider keeps working.
The core tells both caches when it really moves on (`advance` = no freeze), so a store acknowledged while the other
cache still freezes the pipeline is written to memory exactly once.
See `DESIGN_NOTES.md` for the system, the freeze rules, the hazards and every design choice.

## Requirements

- Java 11+ (tested with 21) and sbt 1.10 (https://www.scala-sbt.org/download/); tests run on Treadle (no simulator to install)
- Optional: CIRCT firtool 1.37.0 on the PATH for firtool output from `Emit`; GTKWave to view waveforms

Pinned: Scala 2.13.12, Chisel 3.6.1 (+ chisel3-plugin), chiseltest 0.6.2, sbt 1.10.2.

## Commands

```bash
sbt test
```

The full suite takes about 15 minutes (random freeze runs and cache tests). One suite:

```bash
sbt "testOnly rv32i.CacheSpec"
```

Generate SystemVerilog for `Core` and for the cached system `RV32ITestWrapper` (with `program.hex` and `data.hex`)
into `generated/`:

```bash
sbt "runMain rv32i.Emit"
```

## Source files (`src/main/scala/rv32i/`)

| File | Contents |
|---|---|
| `Defs.scala` | Opcodes, causes, CSR addresses, enums, memory ports (with `busy`), `Trace` (with `exCycle`), pipeline registers `IfId`, `IdEx` (+ `Ctrl`), `ExMem`, `MemWb`; `CacheParams`, `MemReq`, `MemResp`, `MemPort`, `CacheStats` |
| `Core.scala` | The 5-stage pipelined core: forwarding, load-use, redirect, divider stall, cache freeze |
| `ICache.scala` | Direct-mapped instruction cache |
| `DCache.scala` | Direct-mapped write-through, no-write-allocate data cache |
| `MainMemory.scala` | Main memory with a fixed latency, line reads, word writes, optional ROM mode |
| `RV32ITestWrapper.scala` | Core + I-cache + D-cache + instruction memory + data memory; cache statistics on its ports |
| `Decoder.scala`, `ImmGen.scala`, `RegFile.scala`, `Alu.scala`, `CsrFile.scala`, `Multiplier.scala`, `DivUnit.scala` | Datapath blocks (unchanged from Stage 5) |
| `InstructionMemory.scala` | Hex-file reader (`InstructionMemory.readHex`) and a simple ROM |
| `RefModel.scala` | Instruction-level reference model |
| `Emit.scala` | SystemVerilog generation |

Project root: `program.hex` (demo: dot product with MUL, MULH/MULHU/MULHSU, DIV/REM/DIVU/REMU), `data.hex`, and
`tools/rv32im_filter.py` (GTKWave translate filter process: any instruction word as assembly).

## Tests (`src/test/scala/rv32i/`)

| Suite | What it checks |
|---|---|
| `AluSpec`, `ImmGenSpec`, `RegFileSpec`, `DecoderSpec`, `CsrFileSpec`, `MultiplierSpec`, `DivRefSpec`, `DivUnitSpec` | The datapath blocks |
| `CacheSpec` | I-cache: 3,000 random fetches; D-cache: 3,000 random loads and stores; behind a randomly slow memory; every hit and miss predicted by a reference directory model; random extra frozen cycles after each access (no second write, no extra request); memory holds every store (write-through) |
| `MemorySpec` | Hex parsing; main-memory latency, line reads, byte-masked writes, ROM mode; `program.hex` through the caches: results, exact miss counts, write-through count |
| `FreezeSpec` | The core with random busy cycles on both ports, in lockstep with the reference model; exact cost of a freeze; a freeze overlapping a division |
| `CoreProgramSpec` | Lockstep against `RefModel`: arithmetic, loads/stores, branches/jumps, dependency chains, RV32I loops, multiplications, divisions, Zicsr, all six exception types, 3,000 random instructions |
| `CoreDivSpec` | 40 division programs with exact stall lengths |
| `CoreTimingSpec` | 5-stage timing: fill, 2 bubbles per redirect, 1 per load-use, forwarding without stalls, divisions; wrong-path instructions have no effect |
| `WaveformSpec` | Seven demos writing VCDs and GTKWave sessions to `waves/` |

Helpers: `Asm.scala`, `CoreSim.scala` (lockstep harness with random busy injection), `Disasm.scala`, `Gtkw.scala`,
`TestUtil.scala` (`WAVES` switch).

## Interface of `Core`

```scala
class Core(resetPc: Long = 0x80000000L, hartId: Int = 0) extends Module {
  val io = IO(new Bundle {
    val imem  = new InstrMemPort   // addr, advance out; data, busy in (busy: the cache needs more cycles)
    val dmem  = new DataMemPort    // addr, re, we, wdata, wstrb, advance out; rdata, busy in
                                   // advance = !freeze: the pipeline moves on in this cycle
    val trace = Output(new Trace)  // WB stage: one retirement or trap per cycle, or neither (bubble / freeze)
  })
}
```

## Waveforms with GTKWave

```bash
sbt "testOnly rv32i.WaveformSpec"
```

| Demo | Contents |
|---|---|
| `waves/stage8_demo/` | `program.hex` + `data.hex` through the I-cache and D-cache: compulsory misses, refills, write-through |
| `waves/div_rem/` | DIV, REM, DIVU waiting on the divider, the 1-cycle special cases, MUL in one cycle |
| `waves/div_unit/` | The divider alone (`divunit.gtkw`) |
| `waves/mul/`, `waves/upper_jumps/`, `waves/load_store_branch/`, `waves/trap/` | Multiplications, LUI/AUIPC/branches/JAL, a loop with loads and stores, traps |

Open from the project root:

```bash
gtkwave waves/stage8_demo/RV32ITestWrapper.vcd waves/stage8_demo/core.gtkw
```

Groups in `core.gtkw`: Clock (with `cycleCount`); Cache waits (`io_imem_busy`, `io_dmem_busy`, `freeze`); IF; ID;
EX (forwarding selects, `divStall`, `divHave`, `redirect`); MEM; WB; Retire / trap; Multiplier; Divider; Registers
x1..x15; CSRs. The `stage8_demo` session adds an I-cache group and a D-cache group (address, hit, busy, state
IDLE/REFILL/WRITE/DONE, `advance`, set index, memory request and response, access/miss/write counters).

Reading a cache miss in `stage8_demo`: the I-cache `hit` is 0, `busy` and `freeze` rise, the cache sends
`io_mem_req_valid` with the line address, the memory answers `io_mem_resp_valid` 4 cycles later, the line is installed,
`hit` becomes 1 and the pipeline moves again.

A VCD for any test: `WAVES=1 sbt test` (files in `test_run_dir/<test name>/`).

## Verification of the tests (planted bugs)

Each of these bugs, planted one at a time, makes the suite fail:

| Planted bug | Caught by |
|---|---|
| D-cache returns to IDLE after a store acknowledge even if the core stays frozen (the store is written twice) | `CacheSpec`, `MemorySpec` |
| D-cache hit ignores the tag | `CacheSpec` |
| D-cache store hit does not update the present line | `CacheSpec` |
| I-cache installs a wrong tag | `CacheSpec` |
| Register-file write not gated by `freeze` | `MemorySpec` (and the core's freeze assertion) |
| Divider result dropped during a freeze | `FreezeSpec` |
