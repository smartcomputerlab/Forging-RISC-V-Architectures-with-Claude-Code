package rv32i

import chiseltest._
import org.scalatest.flatspec.AnyFlatSpec
import org.scalatest.matchers.should.Matchers

/** Timing contract of the 5-stage RV32IM pipeline (IF / ID / EX / MEM / WB), measured in WB:
  *  - one instruction per cycle; DIV, DIVU, REM and REMU stay 34 cycles in EX (2 for divide-by-zero and signed
  *    overflow); a trap also takes one cycle;
  *  - static not-taken prediction resolved in EX: after a taken branch, JAL, JALR, a trap or MRET the next
  *    instruction arrives two cycles later (two bubbles); not-taken branches cost nothing;
  *  - load-use: an instruction that reads the destination of the load just before it waits one cycle;
  *  - every other dependency is forwarded (no stall);
  *  - after reset the first instruction reaches WB after Core.FillCycles empty cycles.
  */
class CoreTimingSpec extends AnyFlatSpec with ChiselScalatestTester with Matchers {
  private val Data = 0x80010000L

  /** Instruction names exercised below: all of RV32I, Zicsr, the M-mode SYSTEM instructions and the M extension. */
  private val allInstructions = Set(
    "lui", "auipc", "jal", "jalr", "beq", "bne", "blt", "bge", "bltu", "bgeu",
    "lb", "lh", "lw", "lbu", "lhu", "sb", "sh", "sw",
    "addi", "slti", "sltiu", "xori", "ori", "andi", "slli", "srli", "srai",
    "add", "sub", "sll", "slt", "sltu", "xor", "srl", "sra", "or", "and",
    "fence", "ecall", "ebreak", "mret", "wfi",
    "csrrw", "csrrs", "csrrc", "csrrwi", "csrrsi", "csrrci",
    "mul", "mulh", "mulhsu", "mulhu", "div", "divu", "rem", "remu")

  private def isDivRem(w: Long) = (w & 0x7f) == 0x33 && ((w >> 25) & 0x7f) == 1 && ((w >> 12) & 4) != 0

  "Core" should "retire one instruction per cycle except DIV/DIVU/REM/REMU, redirect bubbles and load-use stalls" in {
    val a = new Asm
    // operands: x1 = -100, x2 = 7, x3 = 0 (divide by zero), x4 = MIN, x5 = -1 (signed overflow), x10 = data
    a.li(1, -100); a.li(2, 7); a.li(3, 0); a.li(4, 0x80000000L); a.li(5, -1); a.li(10, Data)
    a.la(6, "handler"); a.csrrw(0, CsrAddr.mtvec, 6)
    // OP-IMM, LUI, AUIPC
    a.addi(11, 1, 5); a.slti(11, 1, 5); a.sltiu(11, 1, 5); a.xori(11, 1, 5); a.ori(11, 1, 5); a.andi(11, 1, 5)
    a.slli(11, 1, 3); a.srli(11, 1, 3); a.srai(11, 1, 3); a.lui(11, 0x12345); a.auipc(11, 1)
    // OP
    a.add(11, 1, 2); a.sub(11, 1, 2); a.sll(11, 1, 2); a.slt(11, 1, 2); a.sltu(11, 1, 2)
    a.xor(11, 1, 2); a.srl(11, 1, 2); a.sra(11, 1, 2); a.or(11, 1, 2); a.and(11, 1, 2)
    // loads and stores
    a.sw(1, 0, 10); a.sh(2, 4, 10); a.sb(2, 6, 10)
    a.lw(11, 0, 10); a.lh(11, 0, 10); a.lhu(11, 2, 10); a.lb(11, 1, 10); a.lbu(11, 3, 10)
    // dependencies: ALU -> ALU at distance 1, 2 and 3 are forwarded (no stall) ...
    a.addi(16, 0, 1); a.add(17, 16, 16); a.add(18, 16, 17); a.add(19, 16, 18)
    // ... a load followed by its user stalls one cycle (as rs1, as rs2 and as store data) ...
    a.lw(16, 0, 10); a.add(17, 16, 0)
    a.lw(16, 0, 10); a.add(17, 0, 16)
    a.lw(16, 0, 10); a.sw(16, 8, 10)
    // ... but not when one instruction separates them, or when the user does not read that register
    a.lw(16, 0, 10); a.addi(18, 0, 3); a.add(17, 16, 18)
    a.lw(16, 0, 10); a.lui(16, 5)
    // branches: taken (skips one instruction) and not taken
    for ((br, k) <- Seq[(Int, Int, String) => Unit](a.beq, a.bne, a.blt, a.bge, a.bltu, a.bgeu).zipWithIndex) {
      // x1 = -100 (0xffffff9c unsigned), x2 = 7
      val (tA, tB) = Seq((1, 1), (1, 2), (1, 2), (2, 1), (2, 1), (1, 2))(k) // operands that make each branch taken
      val (nA, nB) = Seq((1, 2), (1, 1), (2, 1), (1, 2), (1, 2), (2, 1))(k) // operands that make it not taken
      br(tA, tB, s"taken$k"); a.addi(20, 20, 1); a.label(s"taken$k")
      br(nA, nB, s"skip$k"); a.addi(21, 21, 1); a.label(s"skip$k")
    }
    // jumps
    a.jal(12, "after"); a.addi(20, 20, 1); a.label("after")
    a.la(13, "back"); a.jalr(14, 13, 0); a.addi(20, 20, 1); a.label("back")
    // multiplications: one cycle each
    a.mul(11, 1, 2); a.mulh(11, 1, 2); a.mulhsu(11, 1, 2); a.mulhu(11, 1, 2)
    // divisions: the only multi-cycle instructions
    a.div(11, 1, 2); a.divu(11, 1, 2); a.rem(11, 1, 2); a.remu(11, 1, 2)
    a.div(11, 1, 3); a.divu(11, 1, 3); a.rem(11, 1, 3); a.remu(11, 1, 3)   // divide by zero
    a.div(11, 4, 5); a.rem(11, 4, 5)                                       // signed overflow
    // Zicsr and SYSTEM
    a.csrrw(11, CsrAddr.mscratch, 1); a.csrrs(11, CsrAddr.mscratch, 2); a.csrrc(11, CsrAddr.mscratch, 2)
    a.csrrwi(11, CsrAddr.mscratch, 9); a.csrrsi(11, CsrAddr.mscratch, 6); a.csrrci(11, CsrAddr.mscratch, 1)
    a.fence(); a.wfi()
    a.ecall(); a.ebreak(); a.word(0xffffffffL)   // three traps
    a.halt()
    a.label("handler")
    a.csrrs(15, CsrAddr.mepc, 0); a.addi(15, 15, 4); a.csrrw(0, CsrAddr.mepc, 15); a.mret()

    var res: CoreSim.Result = null
    test(new Core()).withAnnotations(TestUtil.waves) { c => res = CoreSim.run(c, a.words) }

    val seen = scala.collection.mutable.Set.empty[String]
    var redirects = 0
    var loadUses = 0
    for ((e, k) <- res.events.zipWithIndex) {
      val name = Disasm(e.inst, e.pc).split(' ').head
      seen += name
      val rs1 = (e.inst >> 15) & 31; val rs2 = (e.inst >> 20) & 31; val signed = ((e.inst >> 12) & 1) == 0
      val base0 =
        if (e.trap || !isDivRem(e.inst)) 1
        else if (rs2 == 3 || (signed && rs1 == 4 && rs2 == 5)) 2
        else 34
      val base = base0
      // bubbles: pipeline fill, 2 after a redirect (trap or non-sequential next pc), 1 for a load-use dependency
      val prev = if (k > 0) Some(res.events(k - 1)) else None
      val prevRedirected = prev.exists(p => p.trap || p.pcNext != ((p.pc + 4) & 0xFFFFFFFFL))
      val loadUse = prev.exists(p => !p.trap && (p.inst & 0x7f) == 0x03 && ((p.inst >> 7) & 31) != 0 && {
        val rd = (p.inst >> 7) & 31
        val op = e.inst & 0x7f
        val usesRs1 = Set(0x67L, 0x63L, 0x03L, 0x23L, 0x13L, 0x33L)(op) || (op == 0x73L && ((e.inst >> 12) & 4) == 0 && ((e.inst >> 12) & 3) != 0)
        val usesRs2 = Set(0x63L, 0x23L, 0x33L)(op)
        (usesRs1 && rs1 == rd) || (usesRs2 && rs2 == rd)
      })
      if (loadUse) loadUses += 1
      val bubble = if (k == 0) Core.FillCycles else if (prevRedirected) 2 else if (loadUse) 1 else 0
      if (prevRedirected) redirects += 1
      withClue(f"${Disasm(e.inst, e.pc)} at 0x${e.pc}%08x (trap=${e.trap}): ") { e.cycles shouldBe (base + bubble) }
    }
    (allInstructions -- seen) shouldBe empty
    res.traps shouldBe 3
    res.model.x(20) shouldBe 0     // every taken branch and jump skipped its instruction
    res.model.x(21) shouldBe 6     // every not-taken branch fell through
    res.cycles shouldBe res.events.map(_.cycles.toLong).sum
    // 6 taken branches + JAL + JALR + 3 traps + 3 MRETs = 14 redirects (2 bubbles each), 3 load-use stalls, fill
    redirects shouldBe 14
    loadUses shouldBe 3
    res.stallCycles shouldBe (4 * 33 + 6 * 1 + 2 * 14 + 3 + Core.FillCycles)
  }

  it should "discard the wrong-path instruction behind a taken branch, a jump, a trap and MRET" in {
    val a = new Asm
    a.li(10, Data); a.li(1, 0x55); a.li(2, 3)
    a.la(6, "handler"); a.csrrw(0, CsrAddr.mtvec, 6)
    // each redirect is followed by an instruction that would change state if it executed
    // two wrong-path instructions (in IF and ID) behind every redirect
    a.beq(0, 0, "l1"); a.sw(1, 0, 10); a.addi(20, 20, 1); a.label("l1")          // no store, no write
    a.jal(0, "l2"); a.div(20, 1, 2); a.sw(1, 0, 10); a.label("l2")              // no division, no store
    a.la(7, "l3"); a.jalr(0, 7, 0); a.csrrw(0, CsrAddr.mscratch, 1); a.ecall(); a.label("l3") // no CSR write, no trap
    a.ecall(); a.addi(21, 21, 1)  // after the handler returns (mepc + 4) this addi runs exactly once
    a.lw(22, 0, 10); a.csrrs(23, CsrAddr.mscratch, 0)
    a.halt()
    a.label("handler")
    a.csrrs(15, CsrAddr.mepc, 0); a.addi(15, 15, 4); a.csrrw(0, CsrAddr.mepc, 15)
    a.mret(); a.addi(24, 24, 1); a.addi(24, 24, 1)   // wrong path behind MRET: must not run
    var res: CoreSim.Result = null
    test(new Core()).withAnnotations(TestUtil.waves) { c => res = CoreSim.run(c, a.words) }
    res.model.x(20) shouldBe 0
    res.model.x(21) shouldBe 1
    res.model.x(22) shouldBe 0    // memory unchanged
    res.model.x(23) shouldBe 0    // mscratch unchanged
    res.model.x(24) shouldBe 0
    res.traps shouldBe 1
    res.stallCycles shouldBe (Core.FillCycles + 2 * 5)  // fill + 2 bubbles for beq, jal, jalr, ecall, mret
  }
}
