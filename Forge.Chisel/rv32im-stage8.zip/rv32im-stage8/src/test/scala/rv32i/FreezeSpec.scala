package rv32i

import chisel3._
import chiseltest._
import org.scalatest.flatspec.AnyFlatSpec
import org.scalatest.matchers.should.Matchers
import scala.util.Random
import TestUtil._

/** The core with random `busy` cycles on its instruction and data ports (what cache misses look like to it): every
  * retirement and trap must still match RefModel, and every busy cycle must cost exactly one cycle.
  */
class FreezeSpec extends AnyFlatSpec with ChiselScalatestTester with Matchers {
  private val Data = 0x80010000L

  private def randomProgram(seed: Int, n: Int): Asm = {
    val r = new Random(seed)
    val a = new Asm
    a.li(16, Data)
    for (k <- 1 to 15) a.li(k, rnd32(r))
    def reg = 1 + r.nextInt(15)
    def src = r.nextInt(16)
    for (i <- 0 until n) r.nextInt(14) match {
      case 0 => a.add(reg, src, src); case 1 => a.sub(reg, src, src); case 2 => a.sll(reg, src, src)
      case 3 => a.xor(reg, src, src); case 4 => a.addi(reg, src, r.nextInt(4096) - 2048)
      case 5 => a.mul(reg, src, src); case 6 => a.mulh(reg, src, src)
      case 7 => if (r.nextInt(4) == 0) a.div(reg, src, src) else a.remu(reg, src, src)
      case 8 => a.sw(src, 4 * r.nextInt(64), 16); case 9 => a.lw(reg, 4 * r.nextInt(64), 16)
      case 10 => a.sb(src, r.nextInt(256), 16); case 11 => a.lbu(reg, r.nextInt(256), 16)
      case 12 => a.lw(reg, 4 * r.nextInt(64), 16)      // load followed by...
                 a.add(reg, reg, src)                   // ...a use: load-use stall
      case _ => a.beq(src, src, s"t$i"); a.addi(reg, reg, 1); a.label(s"t$i")   // taken branch: flush
    }
    a.halt()
    a
  }

  "Core" should "give the same results with random instruction-port and data-port busy cycles" in {
    for ((ib, db, seed) <- Seq((0.3, 0.0, 1), (0.0, 0.5, 2), (0.3, 0.3, 3), (0.7, 0.7, 4))) {
      val a = randomProgram(seed, 600)
      var ref: CoreSim.Result = null
      var res: CoreSim.Result = null
      test(new Core()).withAnnotations(TestUtil.waves) { c => ref = CoreSim.run(c, a.words) }
      test(new Core()).withAnnotations(TestUtil.waves) { c => res = CoreSim.run(c, a.words, iBusy = ib, dBusy = db, seed = seed) }
      withClue(s"iBusy $ib, dBusy $db: ") {
        res.retired shouldBe ref.retired
        res.model.x.toSeq shouldBe ref.model.x.toSeq
        res.cycles should be > ref.cycles
      }
    }
  }

  /** Runs `a` with the data port held busy in cycles [from, until); returns the cycle count up to the halt. */
  private def runFrozen(a: Asm, from: Int, until: Int): (Int, RefModel) = {
    var cycle = 0
    val model = new RefModel(new SimMemory, 0x80000000L)
    model.mem.load(0x80000000L, a.words)
    test(new Core()).withAnnotations(TestUtil.waves) { c =>
      c.clock.setTimeout(0)
      c.io.imem.busy.poke(false.B); c.io.dmem.rdata.poke(0.U)
      var done = false
      while (!done) {
        c.io.dmem.busy.poke((cycle >= from && cycle < until).B)
        c.io.imem.data.poke(model.mem.readWord(c.io.imem.addr.peek().litValue.toLong).U(32.W))
        if (c.io.trace.valid.peek().litToBoolean) {
          val r = model.step(c.io.trace.exCycle.peek().litValue.toLong)
          c.io.trace.rdData.expect(r.rdData.U(32.W), s"inst 0x${r.inst.toHexString}")
          if (r.inst == Asm.Halt) done = true
        }
        c.clock.step(); cycle += 1
        require(cycle < 500)
      }
    }
    (cycle, model)
  }

  private val divProgram: Asm = {
    val a = new Asm
    a.li(1, 1000); a.li(2, 7)
    a.div(3, 1, 2); a.add(4, 3, 3)                     // result used right away
    a.csrrs(5, CsrAddr.mcycle, 0); a.csrrs(6, CsrAddr.minstret, 0)
    a.halt()
    a
  }

  it should "add exactly one cycle per busy cycle when nothing else is in progress, and read mcycle right" in {
    var plain: CoreSim.Result = null
    test(new Core()).withAnnotations(TestUtil.waves) { c => plain = CoreSim.run(c, divProgram.words) }
    val (cycles, model) = runFrozen(divProgram, 2, 12)  // 10 busy cycles while the first instructions are fetched
    cycles.toLong shouldBe (plain.cycles + 10)
    model.x(3) shouldBe 142; model.x(4) shouldBe 284
  }

  it should "keep the divider working during a freeze and hold its result until the division leaves EX" in {
    var plain: CoreSim.Result = null
    test(new Core()).withAnnotations(TestUtil.waves) { c => plain = CoreSim.run(c, divProgram.words) }
    // 40 busy cycles starting in the middle of the 34-cycle division: the divider finishes during the freeze
    val (cycles, model) = runFrozen(divProgram, 15, 55)
    model.x(3) shouldBe 142; model.x(4) shouldBe 284     // the held result was used
    cycles.toLong should be > plain.cycles                // the freeze outlasts the division
    cycles.toLong should be < (plain.cycles + 40)         // ... but the overlap with the division costs nothing
  }
}
