package rv32i

import chisel3._
import chiseltest._
import org.scalatest.flatspec.AnyFlatSpec
import org.scalatest.matchers.should.Matchers
import scala.util.Random

/** The caches against a reference: random accesses, a main memory modelled in Scala that answers after a random
  * latency, and a Scala model of a direct-mapped cache that predicts every hit and miss.
  */
class CacheSpec extends AnyFlatSpec with ChiselScalatestTester with Matchers {
  private val M = 0xFFFFFFFFL

  /** Direct-mapped cache directory model: which line address each set holds. */
  private class Directory(p: CacheParams) {
    private val held = Array.fill[Option[Long]](p.sets)(None)
    private def set(a: Long) = ((a >>> p.offsetBits) & (p.sets - 1)).toInt
    private def lineOf(a: Long) = a >>> p.offsetBits
    def hit(a: Long): Boolean = held(set(a)).contains(lineOf(a))
    def fill(a: Long): Unit = held(set(a)) = Some(lineOf(a))
  }

  /** Scala main memory behind `port`: line reads and word writes, each answered after 1..maxLat cycles. */
  private class SlowMemory(port: MemPort, words: collection.mutable.Map[Long, Long], lineWords: Int, rnd: Random, maxLat: Int) {
    private var pending: Option[(Boolean, Long, Long, Int)] = None   // (write, addr, data|strb, cycles left)
    private var pendingStrb = 0
    var requests = 0
    def beforeEdge(): Unit = {
      port.resp.valid.poke(false.B)
      pending match {
        case Some((w, a, d, 0)) =>
          port.resp.valid.poke(true.B)
          for (k <- 0 until lineWords) port.resp.bits.line(k).poke(words.getOrElse((a + 4 * k) & ~3L, 0L).U(32.W))
        case _ =>
      }
      port.req.ready.poke(pending.isEmpty.B)
    }
    /** Call right before the clock edge: applies what happens at that edge. */
    def atEdge(): Unit = {
      pending match {
        case Some((w, a, d, 0)) =>
          if (w) {
            val old = words.getOrElse(a, 0L); var v = old
            for (k <- 0 until 4 if ((pendingStrb >> k) & 1) == 1) { val m = 0xFFL << (8 * k); v = (v & ~m) | (d & m) }
            words(a) = v & M
          }
          pending = None
        case Some((w, a, d, n)) => pending = Some((w, a, d, n - 1))
        case None =>
          if (port.req.valid.peek().litToBoolean) {
            requests += 1
            val w = port.req.bits.write.peek().litToBoolean
            pendingStrb = port.req.bits.wstrb.peek().litValue.toInt
            pending = Some((w, port.req.bits.addr.peek().litValue.toLong, port.req.bits.wdata.peek().litValue.toLong, rnd.nextInt(maxLat)))
          }
      }
    }
  }

  /** After the access completes, keep `advance` low for 0..4 more cycles (30 % of accesses), as when the other cache
    * freezes the core; `check` runs in each of those cycles. */
  private def holdFrozen(rnd: Random, sm: SlowMemory, clock: Clock, check: () => Unit): Unit = {
    val hold = if (rnd.nextInt(10) < 3) 1 + rnd.nextInt(4) else 0
    for (_ <- 0 until hold) { check(); sm.atEdge(); clock.step(); sm.beforeEdge() }
    check()
  }

  "ICache" should "return the right word for 3,000 random fetches and miss exactly when a direct-mapped cache misses" in {
    val p = CacheParams(sets = 16, lineWords = 4)   // small, so that conflicts happen
    test(new ICache(p)).withAnnotations(TestUtil.waves) { c =>
      c.clock.setTimeout(0)
      val rnd = new Random(3)
      val mem = collection.mutable.Map.empty[Long, Long]
      for (k <- 0 until 1024) mem(0x80000000L + 4 * k) = rnd.nextLong() & M
      val sm = new SlowMemory(c.io.mem, mem, p.lineWords, rnd, 6)
      val dir = new Directory(p)
      var misses = 0
      for (_ <- 0 until 3000) {
        // mostly sequential fetches with jumps, inside a 4 KiB window (4 x the cache size)
        val addr = 0x80000000L + 4 * rnd.nextInt(1024)
        val expectMiss = !dir.hit(addr)
        if (expectMiss) { misses += 1; dir.fill(addr) }
        c.io.addr.poke(addr.U(32.W))
        var waited = 0
        c.io.advance.poke(false.B)                              // the core is frozen while the cache is busy
        sm.beforeEdge()
        while (c.io.busy.peek().litToBoolean) { sm.atEdge(); c.clock.step(); waited += 1; sm.beforeEdge(); require(waited < 50) }
        c.io.data.expect(mem(addr).U(32.W), f"fetch 0x$addr%08x")
        (waited > 0) shouldBe expectMiss
        holdFrozen(rnd, sm, c.clock, () => c.io.busy.expect(false.B))   // the D-cache may keep the core frozen
        c.io.advance.poke(true.B)
        sm.atEdge(); c.clock.step()
      }
      c.io.stats.misses.expect(misses.U)
      c.io.stats.accesses.expect(3000.U)
      sm.requests shouldBe misses
    }
  }

  "DCache" should "load and store correctly (write-through, no-write-allocate) for 3,000 random accesses" in {
    val p = CacheParams(sets = 16, lineWords = 4)
    test(new DCache(p)).withAnnotations(TestUtil.waves) { c =>
      c.clock.setTimeout(0)
      val rnd = new Random(4)
      val base = 0x80010000L
      val mem = collection.mutable.Map.empty[Long, Long]          // the slow main memory
      for (k <- 0 until 512) mem(base + 4 * k) = rnd.nextLong() & M
      val ref = collection.mutable.Map.empty[Long, Long] ++ mem    // what every load must return
      val sm = new SlowMemory(c.io.mem, mem, p.lineWords, rnd, 6)
      val dir = new Directory(p)
      var misses = 0; var writes = 0
      c.io.re.poke(false.B); c.io.we.poke(false.B)
      for (_ <- 0 until 3000) {
        val addr = base + 4 * rnd.nextInt(512)
        val store = rnd.nextInt(3) == 0
        c.io.addr.poke(addr.U(32.W))
        if (store) {
          val data = rnd.nextLong() & M; val strb = 1 + rnd.nextInt(15)
          c.io.we.poke(true.B); c.io.re.poke(false.B); c.io.wdata.poke(data.U(32.W)); c.io.wstrb.poke(strb.U)
          var v = ref(addr)
          for (k <- 0 until 4 if ((strb >> k) & 1) == 1) { val m = 0xFFL << (8 * k); v = (v & ~m) | (data & m) }
          ref(addr) = v; writes += 1
        } else {
          c.io.re.poke(true.B); c.io.we.poke(false.B)
          if (!dir.hit(addr)) { misses += 1; dir.fill(addr) }   // stores never allocate
        }
        var waited = 0
        c.io.advance.poke(false.B)                              // the core is frozen while the cache is busy
        sm.beforeEdge()
        while (c.io.busy.peek().litToBoolean) { sm.atEdge(); c.clock.step(); waited += 1; sm.beforeEdge(); require(waited < 50) }
        if (!store) c.io.rdata.expect(ref(addr).U(32.W), f"load 0x$addr%08x")
        else waited should be > 0                               // a store always waits for memory
        // the I-cache may keep the core frozen after the acknowledge: the access must stay done (no second write)
        holdFrozen(rnd, sm, c.clock, () => {
          c.io.busy.expect(false.B); c.io.mem.req.valid.expect(false.B)
          if (!store) c.io.rdata.expect(ref(addr).U(32.W))
        })
        c.io.advance.poke(true.B)
        sm.atEdge(); c.clock.step()
        c.io.re.poke(false.B); c.io.we.poke(false.B)
      }
      c.io.stats.misses.expect(misses.U)
      c.io.stats.writes.expect(writes.U)
      c.io.stats.accesses.expect(3000.U)
      sm.requests shouldBe (misses + writes)
      for ((a, v) <- ref) mem(a) shouldBe v                       // write-through: memory holds every store
    }
  }
}
