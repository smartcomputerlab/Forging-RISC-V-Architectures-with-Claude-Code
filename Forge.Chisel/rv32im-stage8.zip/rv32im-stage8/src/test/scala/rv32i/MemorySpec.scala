package rv32i

import chisel3._
import chiseltest._
import org.scalatest.flatspec.AnyFlatSpec
import java.nio.file.{Files, Paths}

class MemorySpec extends AnyFlatSpec with ChiselScalatestTester {
  "InstructionMemory.readHex" should "accept comments, blank lines and separators" in {
    val dir = Paths.get("test_run_dir", "hex_parse"); Files.createDirectories(dir)
    val f = dir.resolve("p.hex")
    Files.write(f, "# c\n0000_0013\n\n00a00093  # addi\n".getBytes("UTF-8"))
    assert(InstructionMemory.readHex(f.toString) == Seq(BigInt(0x13), BigInt("00a00093", 16)))
    assert(InstructionMemory.readHex("program.hex").length == 29)
  }

  "MainMemory" should "answer a line read after exactly `latency` cycles, write under byte masks, and act as a ROM if asked" in {
    for (lat <- Seq(1, 4)) test(new MainMemory("data.hex", 16, 0x80010000L, lat, 4)).withAnnotations(TestUtil.waves) { dut =>
      val port = dut.io.port
      def request(addr: Long, write: Boolean = false, data: Long = 0, strb: Int = 0): Seq[BigInt] = {
        port.req.ready.expect(true.B)
        port.req.valid.poke(true.B); port.req.bits.addr.poke(addr.U(32.W)); port.req.bits.write.poke(write.B)
        port.req.bits.wdata.poke(data.U(32.W)); port.req.bits.wstrb.poke(strb.U)
        dut.clock.step(); port.req.valid.poke(false.B)
        var n = 1
        while (!port.resp.valid.peek().litToBoolean) { port.req.ready.expect(false.B); dut.clock.step(); n += 1 }
        assert(n == lat, s"latency $n, expected $lat")
        val line = (0 until 4).map(k => port.resp.bits.line(k).peek().litValue)
        dut.clock.step()
        line
      }
      port.req.valid.poke(false.B)
      assert(request(0x80010000L) == Seq(4, 1, 2, 3).map(BigInt(_)))         // data.hex: n, a[0], a[1], a[2]
      assert(request(0x80010010L) == Seq(4, 10, 20, 30).map(BigInt(_)))
      request(0x80010004L, write = true, data = 0xaabbccddL, strb = 0x5)     // bytes 0 and 2
      assert(request(0x80010000L)(1) == BigInt(0x00bb00ddL))
      assert(request(0x8000fff0L) == Seq.fill(4)(BigInt(0)))                 // outside: zeros
    }
    test(new MainMemory("data.hex", 16, 0x80010000L, 2, 4, writable = false)).withAnnotations(TestUtil.waves) { dut =>
      val port = dut.io.port
      port.req.valid.poke(true.B); port.req.bits.addr.poke("h80010000".U); port.req.bits.write.poke(true.B)
      port.req.bits.wdata.poke(0.U); port.req.bits.wstrb.poke(0xf.U)
      dut.clock.step(); port.req.valid.poke(false.B); dut.clock.step(2)
      port.req.valid.poke(true.B); port.req.bits.write.poke(false.B)
      dut.clock.step(); port.req.valid.poke(false.B); dut.clock.step()
      port.resp.valid.expect(true.B); port.resp.bits.line(0).expect(4.U)      // ROM: the write had no effect
    }
  }

  "RV32ITestWrapper" should "run program.hex through the I-cache and D-cache: results, cache statistics, cycles" in {
    test(new RV32ITestWrapper("program.hex", "data.hex")).withAnnotations(TestUtil.waves) { dut =>
      dut.clock.setTimeout(0)
      val regs = Array.fill(32)(0L)
      var retired = 0; var stores = 0; var cycles = 0
      while (!(dut.io.trace.valid.peek().litToBoolean && dut.io.trace.inst.peek().litValue == Asm.Halt)) {
        dut.io.trace.trap.expect(false.B)
        if (dut.io.trace.valid.peek().litToBoolean) retired += 1
        if (dut.io.trace.memWe.peek().litToBoolean) {
          stores += 1
          dut.io.trace.memAddr.expect("h80010024".U); dut.io.trace.memWdata.expect("hffffffec".U)
        }
        val rd = dut.io.trace.rdAddr.peek().litValue.toInt
        if (rd != 0) regs(rd) = dut.io.trace.rdData.peek().litValue.toLong
        dut.clock.step(); cycles += 1
        assert(cycles < 2000)
      }
      assert(regs(14) == 0xffffffecL && regs(18) == 0xffffffecL)    // dot product -20, stored, reloaded through the cache
      assert(regs(20) == 0x40000000L && regs(21) == 0x40000000L && regs(23) == 0xffffffffL && regs(24) == 1)
      assert(regs(26) == 0xfffffffaL && regs(27) == 0xfffffffeL && regs(28) == 0x5555554eL && regs(29) == 2)
      assert(regs(30) == 0xffffffffL && regs(31) == 0)
      assert(stores == 1 && retired == 5 + 4 * 8 + 8 + 7)
      // I-cache: the 29-word program spans 8 lines of 16 bytes: 8 compulsory misses, the loop hits
      val iMiss = dut.io.icache.misses.peek().litValue
      assert(iMiss == 8, s"I-cache misses $iMiss")
      // D-cache: n, a[0..3] and b[0..3] span lines 0x80010000, 0x80010010 and 0x80010020 (3 misses); the store is
      // written through, and the reload of 0x80010024 hits because the store updated the present line
      assert(dut.io.dcache.misses.peek().litValue == 3)
      assert(dut.io.dcache.writes.peek().litValue == 1)
    }
  }
}
