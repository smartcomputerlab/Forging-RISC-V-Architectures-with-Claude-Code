package rv32i

import chisel3._
import chisel3.util._

/** Data cache: direct-mapped, write-through, no-write-allocate, `p.sets` lines of `p.lineWords` words
  * (default 64 x 16 B = 1 KiB).
  *
  * Core side (the MEM stage): `addr`, `re`, `we`, `wdata` (already in byte lanes), `wstrb`; `rdata` is the aligned
  * word; `busy` = 1 while the access is not complete. The core keeps the request unchanged while `busy` is high.
  *  - Load hit: `rdata` in the same cycle, busy = 0.
  *  - Load miss: read the whole line from memory, install it, then the load hits (one cycle after the refill).
  *  - Store: always written to memory (write-through), one word under the byte mask; busy until memory acknowledges,
  *    and busy = 0 in the acknowledge cycle so the store completes exactly once. If the line is present it is updated
  *    in that same cycle; if not, it is not allocated (no-write-allocate).
  *  - `advance` (from the core): 1 when the MEM stage moves on. If a store is acknowledged while the core stays frozen
  *    (the I-cache is busy), the cache waits in `sDone` (busy = 0, no request) until `advance`, so the same store is
  *    not written a second time.
  */
class DCache(p: CacheParams = CacheParams()) extends Module {
  val io = IO(new Bundle {
    val addr  = Input(UInt(32.W))
    val re    = Input(Bool())
    val we    = Input(Bool())
    val wdata = Input(UInt(32.W))
    val wstrb = Input(UInt(4.W))
    val rdata = Output(UInt(32.W))
    val busy  = Output(Bool())
    val advance = Input(Bool())
    val mem   = new MemPort(p.lineWords)
    val stats = Output(new CacheStats)
  })

  private val wordBits = log2Ceil(p.lineWords)
  val valid = RegInit(VecInit(Seq.fill(p.sets)(false.B)))
  val tags  = Mem(p.sets, UInt(p.tagBits.W))
  val lines = Mem(p.sets, Vec(p.lineWords, UInt(32.W)))

  val index = io.addr(p.offsetBits + p.indexBits - 1, p.offsetBits)
  val tag   = io.addr(31, p.offsetBits + p.indexBits)
  val word  = if (wordBits > 0) io.addr(p.offsetBits - 1, 2) else 0.U
  val hit   = valid(index) && tags(index) === tag
  val line  = lines(index)

  val sIdle :: sRefill :: sWrite :: sDone :: Nil = Enum(4)
  val state   = RegInit(sIdle)
  val fillIdx = Reg(UInt(p.indexBits.W))
  val fillTag = Reg(UInt(p.tagBits.W))

  val writeAck = state === sWrite && io.mem.resp.valid

  io.rdata := line(word)
  io.busy  := (io.re && (state =/= sIdle || !hit)) || (io.we && !writeAck && state =/= sDone)

  // memory requests: a line read for a load miss, a word write for a store
  io.mem.req.valid      := state === sIdle && ((io.re && !hit) || io.we)
  io.mem.req.bits.write := io.we
  io.mem.req.bits.addr  := Mux(io.we, Cat(io.addr(31, 2), 0.U(2.W)), Cat(io.addr(31, p.offsetBits), 0.U(p.offsetBits.W)))
  io.mem.req.bits.wdata := io.wdata
  io.mem.req.bits.wstrb := io.wstrb

  when(io.mem.req.fire) {
    state   := Mux(io.we, sWrite, sRefill)
    fillIdx := index
    fillTag := tag
  }
  when(state === sRefill && io.mem.resp.valid) {
    lines(fillIdx) := io.mem.resp.bits.line
    tags(fillIdx)  := fillTag
    valid(fillIdx) := true.B
    state := sIdle
  }
  when(writeAck) {
    state := Mux(io.advance, sIdle, sDone)
    when(hit) {   // write-through: keep a present line up to date (no allocation on a miss)
      val updated = Wire(Vec(p.lineWords, UInt(32.W)))
      updated := line
      updated(word) := Cat((3 to 0 by -1).map(k => Mux(io.wstrb(k), io.wdata(8 * k + 7, 8 * k), line(word)(8 * k + 7, 8 * k))))
      lines(index) := updated
    }
  }

  when(state === sDone && io.advance) { state := sIdle }

  // statistics: accesses and writes counted when they complete, misses when a refill starts
  val accesses = RegInit(0.U(32.W))
  val misses   = RegInit(0.U(32.W))
  val writes   = RegInit(0.U(32.W))
  when((io.re || io.we) && !io.busy && io.advance) { accesses := accesses + 1.U }
  when(io.we && writeAck) { writes := writes + 1.U }
  when(io.mem.req.fire && !io.we) { misses := misses + 1.U }
  io.stats.accesses := accesses
  io.stats.misses   := misses
  io.stats.writes   := writes
}
