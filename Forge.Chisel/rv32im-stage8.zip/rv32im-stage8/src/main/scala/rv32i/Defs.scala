package rv32i

import chisel3._

/** RISC-V major opcodes (inst[6:0]) used by this core. */
object Opcode {
  val LOAD     = 0x03
  val MISC_MEM = 0x0f
  val OP_IMM   = 0x13
  val AUIPC    = 0x17
  val STORE    = 0x23
  val OP       = 0x33
  val LUI      = 0x37
  val BRANCH   = 0x63
  val JALR     = 0x67
  val JAL      = 0x6f
  val SYSTEM   = 0x73
}

/** mcause exception codes (interrupt bit = 0). */
object Cause {
  val InstrAddrMisaligned = 0
  val IllegalInstruction  = 2
  val Breakpoint          = 3
  val LoadAddrMisaligned  = 4
  val StoreAddrMisaligned = 6
  val EcallFromM          = 11
}

/** CSR addresses implemented by [[CsrFile]]. */
object CsrAddr {
  val mstatus   = 0x300
  val misa      = 0x301
  val mie       = 0x304
  val mtvec     = 0x305
  val mstatush  = 0x310
  val mscratch  = 0x340
  val mepc      = 0x341
  val mcause    = 0x342
  val mtval     = 0x343
  val mip       = 0x344
  val mcycle    = 0xb00
  val minstret  = 0xb02
  val mcycleh   = 0xb80
  val minstreth = 0xb82
  val cycle     = 0xc00
  val instret   = 0xc02
  val cycleh    = 0xc80
  val instreth  = 0xc82
  val mvendorid = 0xf11
  val marchid   = 0xf12
  val mimpid    = 0xf13
  val mhartid   = 0xf14

  /** misa for RV32IM: MXL = 1 (bits 31:30), I = bit 8, M = bit 12. */
  val MisaValue = 0x40001100L
}

/** First ALU operand. */
object ASrc extends ChiselEnum {
  val RS1, PC, ZERO = Value
}

/** Write-back source. */
object WbSel extends ChiselEnum {
  val ALU, MEM, PC4, CSR = Value
}

/** Immediate format. */
object ImmSel extends ChiselEnum {
  val I, S, B, U, J = Value
}

/** ALU operation. */
object AluOp extends ChiselEnum {
  val ADD, SUB, SLL, SLT, SLTU, XOR, SRL, SRA, OR, AND = Value
}

/** Instruction port. `data` is a combinational function of `addr`; `busy` = 1 means the word is not available yet
  * (I-cache miss being refilled): the core then freezes for that cycle and keeps `addr` unchanged.
  */
class InstrMemPort extends Bundle {
  val addr = Output(UInt(32.W))
  val data = Input(UInt(32.W))
  val busy = Input(Bool())
  /** 1: the core's IF stage moves on in this cycle (no freeze); used for the I-cache access count. */
  val advance = Output(Bool())
}

/** Data port: zero-wait. `rdata` is the aligned word at `addr & ~3`, a combinational function of `addr`.
  * A store writes the bytes selected by `wstrb` of `wdata` (already shifted into byte lanes) at the clock edge.
  */
class DataMemPort extends Bundle {
  val addr  = Output(UInt(32.W))
  val re    = Output(Bool())
  val we    = Output(Bool())
  val wdata = Output(UInt(32.W))
  val wstrb = Output(UInt(4.W))
  val rdata = Input(UInt(32.W))
  /** 1: the access is not complete yet (D-cache refill or write-through in progress). The core freezes for that cycle
    * and keeps the request unchanged; a load uses `rdata` and a store counts as done in the first cycle with busy = 0. */
  val busy  = Input(Bool())
  /** 1: the core's MEM stage moves on in this cycle (no freeze). After a store is acknowledged during a freeze caused
    * by the other cache, the D-cache waits for `advance` before it accepts the next access, so a store is written
    * through exactly once. */
  val advance = Output(Bool())
}

/** Per-cycle retirement trace (WB stage). `valid`: an instruction retired. `trap`: an exception was taken.
  * Both low: a pipeline bubble or a cycle waiting for the divider (nothing changed in that cycle).
  */
class Trace extends Bundle {
  val valid    = Bool()
  val trap     = Bool()
  val cause    = UInt(4.W)
  val pc       = UInt(32.W)
  val pcNext   = UInt(32.W)
  val inst     = UInt(32.W)
  val rdAddr   = UInt(5.W)   // 0 when no register is written
  val rdData   = UInt(32.W)  // 0 when no register is written
  val memAddr  = UInt(32.W)
  val memRe    = Bool()
  val memWe    = Bool()
  val memSize  = UInt(2.W)   // 0 byte, 1 half, 2 word
  val memWdata = UInt(32.W)  // store data, not shifted into lanes
  val exCycle  = UInt(32.W)  // clock cycle (since reset) in which the instruction left EX: when it read mcycle
}

// ===================== 5-stage pipeline registers =====================

/** Decoded control signals carried from ID to EX. */
class Ctrl extends Bundle {
  val aluSrcA     = ASrc()
  val aluSrcImm   = Bool()
  val aluOp       = AluOp()
  val branch      = Bool()
  val jal         = Bool()
  val jalr        = Bool()
  val memRead     = Bool()
  val memWrite    = Bool()
  val memSize     = UInt(2.W)
  val memUnsigned = Bool()
  val wbSel       = WbSel()
  val regWrite    = Bool()
  val csr         = Bool()
  val ecall       = Bool()
  val ebreak      = Bool()
  val mret        = Bool()
  val illegal     = Bool()
  val isMul       = Bool()   // MUL, MULH, MULHSU, MULHU
  val isDiv       = Bool()   // DIV, DIVU, REM, REMU (sequential)
  val usesRs1     = Bool()   // for hazard detection and forwarding
  val usesRs2     = Bool()
}

/** IF/ID: the fetched instruction. */
class IfId extends Bundle {
  val valid = Bool()
  val pc    = UInt(32.W)
  val inst  = UInt(32.W)
}

/** ID/EX: decoded instruction with its register operands (read in ID, possibly overridden by forwarding in EX). */
class IdEx extends Bundle {
  val valid  = Bool()
  val pc     = UInt(32.W)
  val inst   = UInt(32.W)
  val rs1    = UInt(5.W)
  val rs2    = UInt(5.W)
  val rd     = UInt(5.W)
  val rs1Val = UInt(32.W)
  val rs2Val = UInt(32.W)
  val imm    = UInt(32.W)
  val ctrl   = new Ctrl
}

/** EX/MEM: an executed instruction, or a trap travelling to WB to be reported in program order. */
class ExMem extends Bundle {
  val valid       = Bool()
  val exCycle     = UInt(32.W)
  val trap        = Bool()
  val cause       = UInt(4.W)
  val pc          = UInt(32.W)
  val pcNext      = UInt(32.W)   // architectural successor (for the trace)
  val inst        = UInt(32.W)
  val rd          = UInt(5.W)
  val regWrite    = Bool()
  val result      = UInt(32.W)   // ALU / PC+4 / CSR / MUL / DIV value
  val memRead     = Bool()
  val memWrite    = Bool()
  val memSize     = UInt(2.W)
  val memUnsigned = Bool()
  val addr        = UInt(32.W)
  val storeData   = UInt(32.W)
}

/** MEM/WB: the value to write back and the trace record. */
class MemWb extends Bundle {
  val valid    = Bool()
  val exCycle  = UInt(32.W)
  val trap     = Bool()
  val cause    = UInt(4.W)
  val pc       = UInt(32.W)
  val pcNext   = UInt(32.W)
  val inst     = UInt(32.W)
  val rd       = UInt(5.W)
  val regWrite = Bool()
  val wdata    = UInt(32.W)
  val memRe    = Bool()
  val memWe    = Bool()
  val memAddr  = UInt(32.W)
  val memSize  = UInt(2.W)
  val memWdata = UInt(32.W)
}

// ===================== caches and main memory =====================

/** Cache geometry: `sets` lines of `lineWords` 32-bit words, direct-mapped. Default: 64 x 4 words = 1 KiB. */
case class CacheParams(sets: Int = 64, lineWords: Int = 4) {
  require(chisel3.util.isPow2(sets) && chisel3.util.isPow2(lineWords) && lineWords >= 1)
  val offsetBits: Int = chisel3.util.log2Ceil(lineWords * 4)
  val indexBits: Int  = chisel3.util.log2Ceil(sets)
  val tagBits: Int    = 32 - offsetBits - indexBits
  val bytes: Int      = sets * lineWords * 4
}

/** Request from a cache to main memory: read a whole line, or write one word under a byte mask. */
class MemReq(lineWords: Int) extends Bundle {
  val addr  = UInt(32.W)       // read: line address; write: word address
  val write = Bool()
  val wdata = UInt(32.W)
  val wstrb = UInt(4.W)
}

/** Response from main memory: the line for a read, or an acknowledge for a write. */
class MemResp(lineWords: Int) extends Bundle {
  val line = Vec(lineWords, UInt(32.W))
}

/** Cache side of the memory port (main memory uses Flipped). */
class MemPort(lineWords: Int) extends Bundle {
  val req  = chisel3.util.Decoupled(new MemReq(lineWords))
  val resp = Flipped(chisel3.util.Valid(new MemResp(lineWords)))
}

/** Hit / miss counters of a cache (for tests and waveforms). */
class CacheStats extends Bundle {
  val accesses = UInt(32.W)
  val misses   = UInt(32.W)
  val writes   = UInt(32.W)
}
