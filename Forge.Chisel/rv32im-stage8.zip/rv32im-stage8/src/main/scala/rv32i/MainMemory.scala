package rv32i

import chisel3._
import chisel3.util._

/** Main memory behind a cache: `depth` words mapped at `base`, initialised from a hex file (empty: all zero), with a
  * fixed `latency` (cycles from accepting a request to its response, >= 1). One request at a time:
  *  - read: returns the whole line at the (line-aligned) address;
  *  - write: writes one word under the byte mask, then acknowledges (a response with an unused line).
  * Words outside [base, base + 4 * depth) read 0 and are not written. `writable = false` makes it a ROM.
  * (Built from registers so that it simulates with its initial content; a real system would use DRAM or block RAM.)
  */
class MainMemory(fileName: String = "", depth: Int = 1024, base: Long = 0x80000000L, latency: Int = 4,
                 lineWords: Int = 4, writable: Boolean = true) extends Module {
  require(latency >= 1)
  val io = IO(new Bundle {
    val port = Flipped(new MemPort(lineWords))
  })

  val init: Seq[BigInt] = if (fileName.isEmpty) Seq.empty else InstructionMemory.readHex(fileName)
  require(init.length <= depth, s"'$fileName' has ${init.length} words, but the memory has only $depth")
  val words = init.map(_.U(32.W)) ++ Seq.fill(depth - init.length)(0.U(32.W))
  val mem   = if (writable) RegInit(VecInit(words)) else VecInit(words)

  private def wordIndex(addr: UInt): (UInt, Bool) = {
    val off = addr - base.U(32.W)
    val idx = off >> 2
    (idx(log2Ceil(depth) - 1, 0), addr >= base.U(32.W) && idx < depth.U)
  }

  val busy  = RegInit(false.B)
  val count = Reg(UInt(log2Ceil(latency + 1).W))
  val req   = Reg(new MemReq(lineWords))

  io.port.req.ready := !busy
  when(io.port.req.fire) {
    busy  := true.B
    count := (latency - 1).U
    req   := io.port.req.bits
  }
  when(busy && count =/= 0.U) { count := count - 1.U }

  val done = busy && count === 0.U
  io.port.resp.valid := done
  io.port.resp.bits.line := VecInit(Seq.tabulate(lineWords) { k =>
    val (idx, inRange) = wordIndex(req.addr + (4 * k).U)
    Mux(inRange, mem(idx), 0.U)
  })

  when(done) {
    busy := false.B
    if (writable) {
      when(req.write) {
        val (idx, inRange) = wordIndex(req.addr)
        when(inRange) {
          mem(idx) := Cat((3 to 0 by -1).map(k => Mux(req.wstrb(k), req.wdata(8 * k + 7, 8 * k), mem(idx)(8 * k + 7, 8 * k))))
        }
      }
    }
  }
}
