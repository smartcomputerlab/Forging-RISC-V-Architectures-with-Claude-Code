package rv32i

import chisel3._
import chisel3.util._

/** Instruction cache: direct-mapped, read-only, `p.sets` lines of `p.lineWords` words (default 64 x 16 B = 1 KiB).
  *
  * Core side: `addr` -> `data` in the same cycle on a hit; `busy` = 1 while the word is not available (miss).
  * On a miss the cache reads the whole line from main memory (one request, one response with the line), writes it
  * into the line selected by the index bits, and serves the word in the following cycle. The core keeps `addr`
  * unchanged while `busy` is high.
  *
  * Address split: | tag (tagBits) | index (indexBits) | word offset | byte offset (2) |
  */
class ICache(p: CacheParams = CacheParams()) extends Module {
  val io = IO(new Bundle {
    val addr  = Input(UInt(32.W))
    val data  = Output(UInt(32.W))
    val busy  = Output(Bool())
    val advance = Input(Bool())   // the core's IF stage moves on (access counting only)
    val mem   = new MemPort(p.lineWords)
    val stats = Output(new CacheStats)
  })

  private val wordBits = log2Ceil(p.lineWords)
  val valid = RegInit(VecInit(Seq.fill(p.sets)(false.B)))
  val tags  = Mem(p.sets, UInt(p.tagBits.W))
  val lines = Mem(p.sets, Vec(p.lineWords, UInt(32.W)))

  val index = io.addr(p.offsetBits + p.indexBits - 1, p.offsetBits)
  val tag   = io.addr(31, p.offsetBits + p.indexBits)
  val word  = if (wordBits > 0) io.addr(p.offsetBits - 1, 2) else 0.U
  val hit   = valid(index) && tags(index) === tag

  val sIdle :: sWait :: Nil = Enum(2)
  val state   = RegInit(sIdle)
  val fillIdx = Reg(UInt(p.indexBits.W))
  val fillTag = Reg(UInt(p.tagBits.W))

  io.data := lines(index)(word)
  io.busy := state =/= sIdle || !hit

  io.mem.req.valid      := state === sIdle && !hit
  io.mem.req.bits.addr  := Cat(io.addr(31, p.offsetBits), 0.U(p.offsetBits.W))
  io.mem.req.bits.write := false.B
  io.mem.req.bits.wdata := 0.U
  io.mem.req.bits.wstrb := 0.U

  when(io.mem.req.fire) {
    state   := sWait
    fillIdx := index
    fillTag := tag
  }
  when(state === sWait && io.mem.resp.valid) {
    lines(fillIdx) := io.mem.resp.bits.line
    tags(fillIdx)  := fillTag
    valid(fillIdx) := true.B
    state := sIdle
  }

  // statistics: an access is counted when the word is delivered; a miss when a refill starts
  val accesses = RegInit(0.U(32.W))
  val misses   = RegInit(0.U(32.W))
  when(!io.busy && io.advance) { accesses := accesses + 1.U }
  when(io.mem.req.fire) { misses := misses + 1.U }
  io.stats.accesses := accesses
  io.stats.misses   := misses
  io.stats.writes   := 0.U
}
