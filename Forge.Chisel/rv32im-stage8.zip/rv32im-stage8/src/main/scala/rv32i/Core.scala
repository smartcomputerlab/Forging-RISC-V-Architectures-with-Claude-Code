package rv32i

import chisel3._
import chisel3.util._

/** Stage 8: 5-stage pipelined RV32IM core (IF, ID, EX, MEM, WB) for use with an I-cache and a D-cache.
  * Machine mode only, no interrupts.
  *
  * Stages
  *  - IF : `fetchPc` addresses the instruction port; the word goes into [[IfId]]. Fetch continues at pc + 4
  *         (static not-taken prediction).
  *  - ID : decode, immediate, register read (with a WB -> ID bypass), load-use hazard detection -> [[IdEx]].
  *  - EX : operand forwarding (from MEM and WB), ALU, multiplier (1 cycle), sequential divider, branch/jump
  *         resolution, CSR read/write, exception detection and trap entry -> [[ExMem]].
  *  - MEM: data port access and load alignment -> [[MemWb]].
  *  - WB : register write and the retirement trace.
  *
  * Hazards (as in the Stage 7 core without caches)
  *  - RAW: forwarding into EX from EX/MEM (non-load results) and MEM/WB; WB -> ID bypass; a load followed by a user of
  *    its result stalls IF/ID one cycle (load-use).
  *  - Control: taken branches, JAL, JALR, traps and MRET resolve in EX and flush the two younger instructions.
  *  - Divider: DIV/DIVU/REM/REMU stay in EX for 34 cycles (2 for divide-by-zero and overflow); IF, ID and EX hold.
  *
  * Caches (Stage 8): the instruction and data ports have a `busy` input. While either is high the whole pipeline is
  * frozen for that cycle (`freeze`): no pipeline register changes, nothing commits (CSRs, traps, divider start,
  * register write, trace), and the memory requests stay unchanged so the caches can complete them. A divider result
  * that arrives during a freeze is held (`divHave`) until the division leaves EX.
  *
  * Precise exceptions: every exception is known in EX and taken there; the trap record travels to WB, so the trace
  * reports it in program order. CSRs (including minstret) are read and written in EX, in program order.
  * The trace is produced in WB; `exCycle` tells when the instruction left EX (for mcycle comparisons).
  */
class Core(resetPc: Long = 0x80000000L, hartId: Int = 0) extends Module {
  val io = IO(new Bundle {
    val imem  = new InstrMemPort
    val dmem  = new DataMemPort
    val trace = Output(new Trace)
  })

  require(resetPc >= 0 && resetPc < (1L << 32) && resetPc % 4 == 0, "reset pc must be 4-byte aligned")

  val dec  = Module(new Decoder)
  val immg = Module(new ImmGen)
  val rf   = Module(new RegFile)
  val alu  = Module(new Alu)
  val csr  = Module(new CsrFile(hartId))
  val mul  = Module(new Multiplier)
  val div  = Module(new DivUnit(32))

  // ---------------- pipeline registers (all empty after reset) ----------------
  val ifid  = RegInit(0.U.asTypeOf(new IfId))
  val idex  = RegInit(0.U.asTypeOf(new IdEx))
  val exmem = RegInit(0.U.asTypeOf(new ExMem))
  val memwb = RegInit(0.U.asTypeOf(new MemWb))

  // =====================================================================================
  // IF
  // =====================================================================================
  val fetchPc = RegInit(resetPc.U(32.W))
  io.imem.addr := fetchPc

  // ---------------- cache waits freeze the whole pipeline ----------------
  val freeze = io.imem.busy || io.dmem.busy
  io.imem.advance := !freeze
  io.dmem.advance := !freeze
  /** Cycles since reset; each instruction carries the value of the cycle in which it left EX. */
  val cycleCount = RegInit(0.U(32.W))
  cycleCount := cycleCount + 1.U

  // =====================================================================================
  // ID
  // =====================================================================================
  val idInst   = Mux(ifid.valid, ifid.inst, Core.Nop.U(32.W))
  val idOpcode = idInst(6, 0)
  val idF3     = idInst(14, 12)
  val idMulDiv = idOpcode === Opcode.OP.U && idInst(31, 25) === "b0000001".U
  val rs1      = idInst(19, 15)
  val rs2      = idInst(24, 20)

  dec.io.inst  := idInst
  immg.io.inst := idInst
  immg.io.sel  := dec.io.immSel
  rf.io.rs1    := rs1
  rf.io.rs2    := rs2

  // WB -> ID bypass: the register written in WB this cycle is read with its new value.
  val wbWrites = memwb.valid && !memwb.trap && memwb.regWrite && memwb.rd =/= 0.U && !freeze
  val rs1Val   = Mux(wbWrites && memwb.rd === rs1, memwb.wdata, rf.io.rd1)
  val rs2Val   = Mux(wbWrites && memwb.rd === rs2, memwb.wdata, rf.io.rd2)

  val idCtrl = Wire(new Ctrl)
  idCtrl.aluSrcA     := dec.io.aluSrcA
  idCtrl.aluSrcImm   := dec.io.aluSrcImm
  idCtrl.aluOp       := dec.io.aluOp
  idCtrl.branch      := dec.io.branch
  idCtrl.jal         := dec.io.jal
  idCtrl.jalr        := dec.io.jalr
  idCtrl.memRead     := dec.io.memRead
  idCtrl.memWrite    := dec.io.memWrite
  idCtrl.memSize     := dec.io.memSize
  idCtrl.memUnsigned := dec.io.memUnsigned
  idCtrl.wbSel       := dec.io.wbSel
  idCtrl.regWrite    := dec.io.regWrite || idMulDiv
  idCtrl.csr         := dec.io.csr
  idCtrl.ecall       := dec.io.ecall
  idCtrl.ebreak      := dec.io.ebreak
  idCtrl.mret        := dec.io.mret
  // The eight M-extension instructions are legal even though the RV32I decoder flags funct7 = 0000001.
  idCtrl.illegal     := dec.io.illegal && !idMulDiv
  idCtrl.isMul       := idMulDiv && !idF3(2)
  idCtrl.isDiv       := idMulDiv && idF3(2)
  // Which source registers the instruction really reads (no false hazards for LUI, JAL, CSR-immediate, ...).
  idCtrl.usesRs1     := !idCtrl.illegal && (dec.io.jalr || dec.io.branch || dec.io.memRead || dec.io.memWrite ||
                        idOpcode === Opcode.OP_IMM.U || idOpcode === Opcode.OP.U || (dec.io.csr && !idF3(2)))
  idCtrl.usesRs2     := !idCtrl.illegal && (dec.io.branch || dec.io.memWrite || idOpcode === Opcode.OP.U)

  // Load-use hazard: EX holds a load whose destination is a source of the ID instruction.
  val loadUse = ifid.valid && idex.valid && idex.ctrl.memRead && idex.rd =/= 0.U &&
    ((idCtrl.usesRs1 && rs1 === idex.rd) || (idCtrl.usesRs2 && rs2 === idex.rd))

  // =====================================================================================
  // EX
  // =====================================================================================
  val exValid = idex.valid
  val c       = idex.ctrl
  val exPc    = idex.pc
  val exInst  = idex.inst
  val exF3    = exInst(14, 12)

  // Forwarding: EX/MEM (not for loads: their data is not there yet) has priority over MEM/WB.
  private def forward(idx: UInt, idVal: UInt): UInt = {
    val fromMem = exmem.valid && !exmem.trap && exmem.regWrite && !exmem.memRead && exmem.rd === idx && idx =/= 0.U
    val fromWb  = memwb.valid && !memwb.trap && memwb.regWrite && memwb.rd === idx && idx =/= 0.U
    Mux(fromMem, exmem.result, Mux(fromWb, memwb.wdata, idVal))
  }
  val a = forward(idex.rs1, idex.rs1Val)
  val b = forward(idex.rs2, idex.rs2Val)

  // ALU
  val aluA = WireDefault(a)
  switch(c.aluSrcA) {
    is(ASrc.RS1)  { aluA := a }
    is(ASrc.PC)   { aluA := exPc }
    is(ASrc.ZERO) { aluA := 0.U }
  }
  alu.io.op := c.aluOp
  alu.io.a  := aluA
  alu.io.b  := Mux(c.aluSrcImm, idex.imm, b)
  val aluY = alu.io.y

  // multiplier (combinational) and divider (sequential)
  mul.io.fn := exF3(1, 0)
  mul.io.a  := a
  mul.io.b  := b
  // The result is kept in divHeld if it arrives while the pipeline is frozen, until the division leaves EX.
  val divHave   = RegInit(false.B)
  val divHeld   = Reg(UInt(32.W))
  val divReady  = div.io.resp.valid || divHave
  val divResult = Mux(div.io.resp.valid, div.io.resp.bits, divHeld)
  div.io.req.valid   := exValid && c.isDiv && !div.io.busy && !divHave && !freeze
  div.io.req.bits.op := exF3(1, 0)
  div.io.req.bits.a  := a
  div.io.req.bits.b  := b
  val divStall = exValid && c.isDiv && !divReady

  // branches and jumps
  val eq  = a === b
  val lt  = a.asSInt < b.asSInt
  val ltu = a < b
  val brCond = WireDefault(false.B)
  switch(exF3) {
    is("b000".U) { brCond := eq }
    is("b001".U) { brCond := !eq }
    is("b100".U) { brCond := lt }
    is("b101".U) { brCond := !lt }
    is("b110".U) { brCond := ltu }
    is("b111".U) { brCond := !ltu }
  }
  val pcPlus4    = exPc + 4.U
  val brTarget   = exPc + idex.imm
  val jalrTarget = Cat(aluY(31, 1), 0.U(1.W))
  val ctlTaken   = (c.branch && brCond) || c.jal || c.jalr
  val ctlTarget  = Mux(c.jalr, jalrTarget, brTarget)

  // address checks
  val misalignedAccess = (c.memSize === 2.U && aluY(1, 0) =/= 0.U) || (c.memSize === 1.U && aluY(0))
  val loadMis  = c.memRead && misalignedAccess
  val storeMis = c.memWrite && misalignedAccess
  val fetchMis = ctlTaken && ctlTarget(1)

  // CSRs
  val rs1Field = exInst(19, 15)
  csr.io.addr := exInst(31, 20)
  csr.io.en   := exValid && c.csr
  csr.io.op   := exF3(1, 0)
  csr.io.src  := Mux(exF3(2), Cat(0.U(27.W), rs1Field), a)
  csr.io.wrEn := exF3(1, 0) === 1.U || rs1Field =/= 0.U

  // exceptions (all known here) and commit
  val illegal = c.illegal || csr.io.illegal
  val trapNow = exValid && (illegal || c.ecall || c.ebreak || loadMis || storeMis || fetchMis)
  div.io.kill := trapNow && !freeze

  val cause = PriorityMux(Seq(
    illegal    -> Cause.IllegalInstruction.U(4.W),
    c.ecall    -> Cause.EcallFromM.U(4.W),
    c.ebreak   -> Cause.Breakpoint.U(4.W),
    loadMis    -> Cause.LoadAddrMisaligned.U(4.W),
    storeMis   -> Cause.StoreAddrMisaligned.U(4.W),
    fetchMis   -> Cause.InstrAddrMisaligned.U(4.W)
  ))
  val tval = PriorityMux(Seq(
    illegal               -> exInst,
    c.ecall               -> 0.U(32.W),
    c.ebreak              -> exPc,
    (loadMis || storeMis) -> aluY,
    fetchMis              -> ctlTarget
  ))

  // The EX instruction is committed here: nothing after EX can fail.
  val exCommit = exValid && !trapNow && !divStall && !freeze
  csr.io.commit    := exCommit
  csr.io.trapEnter := trapNow && !freeze
  csr.io.trapCause := Cat(0.U(28.W), cause)
  csr.io.trapPc    := exPc
  csr.io.trapVal   := tval
  csr.io.mretEnter := exValid && c.mret && !trapNow && !freeze

  val nextPc = Mux(trapNow, csr.io.mtvecBase,
               Mux(c.mret, csr.io.mepc,
               Mux(ctlTaken, ctlTarget, pcPlus4)))
  val redirect = exValid && !divStall && (trapNow || c.mret || ctlTaken)

  val exResult = WireDefault(aluY)
  switch(c.wbSel) {
    is(WbSel.ALU) { exResult := aluY }
    is(WbSel.PC4) { exResult := pcPlus4 }
    is(WbSel.CSR) { exResult := csr.io.rdata }
    is(WbSel.MEM) { exResult := aluY }        // replaced by the load data in MEM
  }
  when(c.isMul) { exResult := mul.io.result }
  when(c.isDiv) { exResult := divResult }

  // the held divider result belongs to the division in EX: set on the response, cleared when it leaves EX
  val exLeaves = exValid && !divStall && !freeze
  when(div.io.resp.valid) { divHave := true.B; divHeld := div.io.resp.bits }
  when(exLeaves || !exValid) { divHave := false.B }

  // =====================================================================================
  // pipeline control: IF, ID and EX
  // =====================================================================================
  when(freeze) {
    // a cache is busy: every pipeline register holds
  }.elsewhen(divStall) {
    // freeze IF, IF/ID and ID/EX while the divider works on the EX instruction
  }.elsewhen(redirect) {
    fetchPc    := nextPc
    ifid.valid := false.B                       // flush the two wrong-path instructions
    idex.valid := false.B
  }.elsewhen(loadUse) {
    idex.valid := false.B                       // bubble into EX; IF and IF/ID hold
  }.otherwise {
    fetchPc     := fetchPc + 4.U
    ifid.valid  := true.B
    ifid.pc     := fetchPc
    ifid.inst   := io.imem.data
    idex.valid  := ifid.valid
    idex.pc     := ifid.pc
    idex.inst   := idInst
    idex.rs1    := rs1
    idex.rs2    := rs2
    idex.rd     := idInst(11, 7)
    idex.rs1Val := rs1Val
    idex.rs2Val := rs2Val
    idex.imm    := immg.io.imm
    idex.ctrl   := idCtrl
  }

  // EX -> MEM: a bubble while the divider works, otherwise the executed instruction (or its trap)
  when(!freeze) { exmem.valid := exValid && !divStall }
  when(!divStall && !freeze) {
    exmem.exCycle     := cycleCount
    exmem.trap        := trapNow
    exmem.cause       := cause
    exmem.pc          := exPc
    exmem.pcNext      := nextPc
    exmem.inst        := exInst
    exmem.rd          := idex.rd
    exmem.regWrite    := c.regWrite && !trapNow
    exmem.result      := exResult
    exmem.memRead     := c.memRead && !trapNow
    exmem.memWrite    := c.memWrite && !trapNow
    exmem.memSize     := c.memSize
    exmem.memUnsigned := c.memUnsigned
    exmem.addr        := aluY
    exmem.storeData   := b
  }

  // =====================================================================================
  // MEM
  // =====================================================================================
  val mAddr = exmem.addr
  val size  = exmem.memSize
  io.dmem.addr := mAddr
  io.dmem.re   := exmem.valid && exmem.memRead
  io.dmem.we   := exmem.valid && exmem.memWrite

  val sbyte = exmem.storeData(7, 0)
  val shalf = exmem.storeData(15, 0)
  val wdata = WireDefault(exmem.storeData)
  val wstrb = WireDefault("b1111".U(4.W))
  switch(size) {
    is(0.U) { wdata := Fill(4, sbyte); wstrb := (1.U(4.W) << mAddr(1, 0))(3, 0) }
    is(1.U) { wdata := Fill(2, shalf); wstrb := Mux(mAddr(1), "b1100".U(4.W), "b0011".U(4.W)) }
  }
  io.dmem.wdata := wdata
  io.dmem.wstrb := Mux(io.dmem.we, wstrb, 0.U)

  val rdata = io.dmem.rdata
  val bytes = VecInit(Seq.tabulate(4)(k => rdata(8 * k + 7, 8 * k)))
  val lb    = bytes(mAddr(1, 0))
  val lh    = Mux(mAddr(1), rdata(31, 16), rdata(15, 0))
  val uns   = exmem.memUnsigned
  val loadData = WireDefault(rdata)
  switch(size) {
    is(0.U) { loadData := Mux(uns, Cat(0.U(24.W), lb), Cat(Fill(24, lb(7)), lb)) }
    is(1.U) { loadData := Mux(uns, Cat(0.U(16.W), lh), Cat(Fill(16, lh(15)), lh)) }
  }

  when(!freeze) {
    memwb.valid    := exmem.valid
    memwb.trap     := exmem.trap
    memwb.cause    := exmem.cause
    memwb.pc       := exmem.pc
    memwb.pcNext   := exmem.pcNext
    memwb.inst     := exmem.inst
    memwb.rd       := exmem.rd
    memwb.regWrite := exmem.regWrite
    memwb.wdata    := Mux(exmem.memRead, loadData, exmem.result)
    memwb.memRe    := io.dmem.re
    memwb.memWe    := io.dmem.we
    memwb.memAddr  := mAddr
    memwb.memSize  := size
    memwb.memWdata := Mux(size === 0.U, Cat(0.U(24.W), sbyte), Mux(size === 1.U, Cat(0.U(16.W), shalf), exmem.storeData))
    memwb.exCycle  := exmem.exCycle
  }

  // =====================================================================================
  // WB
  // =====================================================================================
  rf.io.we    := memwb.valid && !memwb.trap && memwb.regWrite && !freeze
  rf.io.waddr := memwb.rd
  rf.io.wdata := memwb.wdata

  io.trace.valid    := memwb.valid && !memwb.trap && !freeze
  io.trace.trap     := memwb.valid && memwb.trap && !freeze
  io.trace.exCycle  := memwb.exCycle
  io.trace.cause    := memwb.cause
  io.trace.pc       := memwb.pc
  io.trace.pcNext   := memwb.pcNext
  io.trace.inst     := memwb.inst
  io.trace.rdAddr   := Mux(wbWrites, memwb.rd, 0.U)
  io.trace.rdData   := Mux(wbWrites, memwb.wdata, 0.U)
  io.trace.memAddr  := memwb.memAddr
  io.trace.memRe    := memwb.valid && memwb.memRe && !freeze   // only in the cycle the instruction is reported
  io.trace.memWe    := memwb.valid && memwb.memWe && !freeze
  io.trace.memSize  := memwb.memSize
  io.trace.memWdata := memwb.memWdata

  // =====================================================================================
  // assertions (compiled out of synthesis builds)
  // =====================================================================================
  assert(fetchPc(1, 0) === 0.U, "fetch pc must stay 4-byte aligned")
  assert(!(io.dmem.we && io.dmem.re), "simultaneous load and store")
  assert(!(exmem.valid && exmem.trap && (exmem.memRead || exmem.memWrite || exmem.regWrite)),
    "trapping instruction accesses memory or writes a register")
  assert(!(exValid && exmem.valid && exmem.memRead && exmem.rd =/= 0.U &&
    ((c.usesRs1 && idex.rs1 === exmem.rd) || (c.usesRs2 && idex.rs2 === exmem.rd))),
    "load-use hazard reached EX (missing stall)")
  assert(!(divStall && trapNow), "a division cannot trap")
  assert(!(csr.io.commit && !exValid), "bubble committed")
  assert(!(freeze && (rf.io.we || csr.io.commit || csr.io.trapEnter || io.trace.valid || io.trace.trap)),
    "state changed during a cache freeze")
}

object Core {
  /** `addi x0, x0, 0`: what ID decodes when IF/ID holds a bubble. */
  val Nop = 0x00000013L
  /** Cycles from EX to WB: an instruction executed in EX in cycle t is reported in the trace in cycle t + 2. */
  val ExToWb = 2
  /** Empty cycles before the first instruction reaches WB after reset. */
  val FillCycles = 4
}
