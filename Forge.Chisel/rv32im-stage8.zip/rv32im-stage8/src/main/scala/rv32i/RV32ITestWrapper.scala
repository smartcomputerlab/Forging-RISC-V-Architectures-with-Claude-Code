package rv32i

import chisel3._

/** Stage 8 system: Core + I-cache + D-cache, each in front of its own main memory (Harvard):
  * instruction memory (ROM, program at 0x80000000) and data memory (RAM at 0x80010000), both with `memLatency`.
  */
class RV32ITestWrapper(programFile: String, dataFile: String = "", memLatency: Int = 4,
                       icacheParams: CacheParams = CacheParams(), dcacheParams: CacheParams = CacheParams(),
                       dataDepth: Int = 256) extends Module {
  val io = IO(new Bundle {
    val trace  = Output(new Trace)
    val icache = Output(new CacheStats)
    val dcache = Output(new CacheStats)
  })
  val core   = Module(new Core())
  val icache = Module(new ICache(icacheParams))
  val dcache = Module(new DCache(dcacheParams))
  val imem   = Module(new MainMemory(programFile, 1024, 0x80000000L, memLatency, icacheParams.lineWords, writable = false))
  val dmem   = Module(new MainMemory(dataFile, dataDepth, 0x80010000L, memLatency, dcacheParams.lineWords))

  icache.io.addr     := core.io.imem.addr
  core.io.imem.data  := icache.io.data
  core.io.imem.busy  := icache.io.busy
  icache.io.advance  := core.io.imem.advance
  icache.io.mem <> imem.io.port

  dcache.io.addr     := core.io.dmem.addr
  dcache.io.re       := core.io.dmem.re
  dcache.io.we       := core.io.dmem.we
  dcache.io.wdata    := core.io.dmem.wdata
  dcache.io.wstrb    := core.io.dmem.wstrb
  core.io.dmem.rdata := dcache.io.rdata
  core.io.dmem.busy  := dcache.io.busy
  dcache.io.advance  := core.io.dmem.advance
  dcache.io.mem <> dmem.io.port

  io.trace  := core.io.trace
  io.icache := icache.io.stats
  io.dcache := dcache.io.stats
}
