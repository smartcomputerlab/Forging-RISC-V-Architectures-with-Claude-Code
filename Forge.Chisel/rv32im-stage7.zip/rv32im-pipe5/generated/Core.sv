module Decoder(
  input  [31:0] io_inst, // @[src/main/scala/rv32i/Decoder.scala 15:14]
  output [2:0]  io_immSel, // @[src/main/scala/rv32i/Decoder.scala 15:14]
  output [1:0]  io_aluSrcA, // @[src/main/scala/rv32i/Decoder.scala 15:14]
  output        io_aluSrcImm, // @[src/main/scala/rv32i/Decoder.scala 15:14]
  output [3:0]  io_aluOp, // @[src/main/scala/rv32i/Decoder.scala 15:14]
  output        io_branch, // @[src/main/scala/rv32i/Decoder.scala 15:14]
  output        io_jal, // @[src/main/scala/rv32i/Decoder.scala 15:14]
  output        io_jalr, // @[src/main/scala/rv32i/Decoder.scala 15:14]
  output        io_memRead, // @[src/main/scala/rv32i/Decoder.scala 15:14]
  output        io_memWrite, // @[src/main/scala/rv32i/Decoder.scala 15:14]
  output [1:0]  io_memSize, // @[src/main/scala/rv32i/Decoder.scala 15:14]
  output        io_memUnsigned, // @[src/main/scala/rv32i/Decoder.scala 15:14]
  output [1:0]  io_wbSel, // @[src/main/scala/rv32i/Decoder.scala 15:14]
  output        io_regWrite, // @[src/main/scala/rv32i/Decoder.scala 15:14]
  output        io_csr, // @[src/main/scala/rv32i/Decoder.scala 15:14]
  output        io_ecall, // @[src/main/scala/rv32i/Decoder.scala 15:14]
  output        io_ebreak, // @[src/main/scala/rv32i/Decoder.scala 15:14]
  output        io_mret, // @[src/main/scala/rv32i/Decoder.scala 15:14]
  output        io_illegal // @[src/main/scala/rv32i/Decoder.scala 15:14]
);
  wire [6:0] opcode = io_inst[6:0]; // @[src/main/scala/rv32i/Decoder.scala 41:20]
  wire [2:0] f3 = io_inst[14:12]; // @[src/main/scala/rv32i/Decoder.scala 42:20]
  wire [6:0] f7 = io_inst[31:25]; // @[src/main/scala/rv32i/Decoder.scala 43:20]
  wire  _T_4 = f3 == 3'h0; // @[src/main/scala/rv32i/Decoder.scala 107:15]
  wire  _GEN_0 = f3 == 3'h0 ? 1'h0 : 1'h1; // @[src/main/scala/rv32i/Decoder.scala 107:24 108:22 66:18]
  wire [1:0] _GEN_2 = f3 == 3'h0 ? 2'h2 : 2'h0; // @[src/main/scala/rv32i/Decoder.scala 107:24 111:22 60:18]
  wire  _T_8 = f3 != 3'h2 & f3 != 3'h3; // @[src/main/scala/rv32i/Decoder.scala 116:23]
  wire  _GEN_3 = f3 != 3'h2 & f3 != 3'h3 ? 1'h0 : 1'h1; // @[src/main/scala/rv32i/Decoder.scala 116:38 117:20 66:18]
  wire [1:0] _GEN_5 = f3 != 3'h2 & f3 != 3'h3 ? 2'h2 : 2'h0; // @[src/main/scala/rv32i/Decoder.scala 116:38 119:20 49:18]
  wire  _T_11 = f3 == 3'h1; // @[src/main/scala/rv32i/Decoder.scala 123:29]
  wire  _T_14 = _T_4 | f3 == 3'h1 | f3 == 3'h2; // @[src/main/scala/rv32i/Decoder.scala 123:37]
  wire  _T_17 = f3 == 3'h5; // @[src/main/scala/rv32i/Decoder.scala 123:71]
  wire  _T_18 = _T_4 | f3 == 3'h1 | f3 == 3'h2 | f3 == 3'h4 | f3 == 3'h5; // @[src/main/scala/rv32i/Decoder.scala 123:65]
  wire  _GEN_6 = _T_4 | f3 == 3'h1 | f3 == 3'h2 | f3 == 3'h4 | f3 == 3'h5 ? 1'h0 : 1'h1; // @[src/main/scala/rv32i/Decoder.scala 123:80 124:22 66:18]
  wire  _GEN_8 = _T_14 ? 1'h0 : 1'h1; // @[src/main/scala/rv32i/Decoder.scala 132:52 133:22 66:18]
  wire  _shiftOk_T_1 = f7 == 7'h0; // @[src/main/scala/rv32i/Decoder.scala 140:40]
  wire  _shiftOk_T_4 = f7 == 7'h20; // @[src/main/scala/rv32i/Decoder.scala 140:82]
  wire  _shiftOk_T_6 = _T_17 ? f7 == 7'h0 | f7 == 7'h20 : 1'h1; // @[src/main/scala/rv32i/Decoder.scala 140:52]
  wire  shiftOk = _T_11 ? f7 == 7'h0 : _shiftOk_T_6; // @[src/main/scala/rv32i/Decoder.scala 140:24]
  wire  _io_aluOp_T_2 = _T_17 & f7[5]; // @[src/main/scala/rv32i/Decoder.scala 145:43]
  wire [2:0] _io_aluOp_op_T_1 = _io_aluOp_T_2 ? 3'h7 : 3'h6; // @[src/main/scala/rv32i/Decoder.scala 77:26]
  wire [3:0] _GEN_10 = 3'h7 == f3 ? 4'h9 : 4'h0; // @[src/main/scala/rv32i/Decoder.scala 71:16 79:20 70:25]
  wire [3:0] _GEN_11 = 3'h6 == f3 ? 4'h8 : _GEN_10; // @[src/main/scala/rv32i/Decoder.scala 71:16 78:20]
  wire [3:0] _GEN_12 = 3'h5 == f3 ? {{1'd0}, _io_aluOp_op_T_1} : _GEN_11; // @[src/main/scala/rv32i/Decoder.scala 71:16 77:20]
  wire [3:0] _GEN_13 = 3'h4 == f3 ? 4'h5 : _GEN_12; // @[src/main/scala/rv32i/Decoder.scala 71:16 76:20]
  wire [3:0] _GEN_14 = 3'h3 == f3 ? 4'h4 : _GEN_13; // @[src/main/scala/rv32i/Decoder.scala 71:16 75:20]
  wire [3:0] _GEN_15 = 3'h2 == f3 ? 4'h3 : _GEN_14; // @[src/main/scala/rv32i/Decoder.scala 71:16 74:20]
  wire [3:0] _GEN_16 = 3'h1 == f3 ? 4'h2 : _GEN_15; // @[src/main/scala/rv32i/Decoder.scala 71:16 73:20]
  wire [3:0] io_aluOp_op = 3'h0 == f3 ? {{3'd0}, _io_aluOp_T_2} : _GEN_16; // @[src/main/scala/rv32i/Decoder.scala 71:16 72:20]
  wire  _GEN_18 = shiftOk ? 1'h0 : 1'h1; // @[src/main/scala/rv32i/Decoder.scala 141:21 142:22 66:18]
  wire [3:0] _GEN_20 = shiftOk ? io_aluOp_op : 4'h0; // @[src/main/scala/rv32i/Decoder.scala 141:21 145:22 52:18]
  wire  altOk = _shiftOk_T_4 & (_T_4 | _T_17); // @[src/main/scala/rv32i/Decoder.scala 149:39]
  wire  _T_28 = _shiftOk_T_1 | altOk; // @[src/main/scala/rv32i/Decoder.scala 150:23]
  wire [2:0] _io_aluOp_op_T_3 = f7[5] ? 3'h7 : 3'h6; // @[src/main/scala/rv32i/Decoder.scala 77:26]
  wire [3:0] _GEN_23 = 3'h5 == f3 ? {{1'd0}, _io_aluOp_op_T_3} : _GEN_11; // @[src/main/scala/rv32i/Decoder.scala 71:16 77:20]
  wire [3:0] _GEN_24 = 3'h4 == f3 ? 4'h5 : _GEN_23; // @[src/main/scala/rv32i/Decoder.scala 71:16 76:20]
  wire [3:0] _GEN_25 = 3'h3 == f3 ? 4'h4 : _GEN_24; // @[src/main/scala/rv32i/Decoder.scala 71:16 75:20]
  wire [3:0] _GEN_26 = 3'h2 == f3 ? 4'h3 : _GEN_25; // @[src/main/scala/rv32i/Decoder.scala 71:16 74:20]
  wire [3:0] _GEN_27 = 3'h1 == f3 ? 4'h2 : _GEN_26; // @[src/main/scala/rv32i/Decoder.scala 71:16 73:20]
  wire [3:0] io_aluOp_op_1 = 3'h0 == f3 ? {{3'd0}, f7[5]} : _GEN_27; // @[src/main/scala/rv32i/Decoder.scala 71:16 72:20]
  wire  _GEN_29 = _shiftOk_T_1 | altOk ? 1'h0 : 1'h1; // @[src/main/scala/rv32i/Decoder.scala 150:33 151:21 66:18]
  wire [3:0] _GEN_31 = _shiftOk_T_1 | altOk ? io_aluOp_op_1 : 4'h0; // @[src/main/scala/rv32i/Decoder.scala 150:33 153:21 52:18]
  wire  _T_33 = io_inst == 32'h73; // @[src/main/scala/rv32i/Decoder.scala 161:19]
  wire  _GEN_33 = io_inst == 32'h73 ? 1'h0 : 1'h1; // @[src/main/scala/rv32i/Decoder.scala 161:{38,51} 66:18]
  wire  _T_34 = io_inst == 32'h100073; // @[src/main/scala/rv32i/Decoder.scala 162:19]
  wire  _GEN_35 = io_inst == 32'h100073 ? 1'h0 : _GEN_33; // @[src/main/scala/rv32i/Decoder.scala 162:{38,51}]
  wire  _T_35 = io_inst == 32'h30200073; // @[src/main/scala/rv32i/Decoder.scala 163:19]
  wire  _GEN_37 = io_inst == 32'h30200073 ? 1'h0 : _GEN_35; // @[src/main/scala/rv32i/Decoder.scala 163:{38,51}]
  wire  _GEN_39 = io_inst == 32'h10500073 ? 1'h0 : _GEN_37; // @[src/main/scala/rv32i/Decoder.scala 164:{38,51}]
  wire  _T_37 = f3 != 3'h4; // @[src/main/scala/rv32i/Decoder.scala 165:21]
  wire  _GEN_40 = f3 != 3'h4 ? 1'h0 : 1'h1; // @[src/main/scala/rv32i/Decoder.scala 165:30 166:21 66:18]
  wire [1:0] _GEN_42 = f3 != 3'h4 ? 2'h3 : 2'h0; // @[src/main/scala/rv32i/Decoder.scala 165:30 169:21 60:18]
  wire  _GEN_43 = _T_4 ? _GEN_39 : _GEN_40; // @[src/main/scala/rv32i/Decoder.scala 160:24]
  wire  _GEN_44 = _T_4 & _T_33; // @[src/main/scala/rv32i/Decoder.scala 160:24 63:18]
  wire  _GEN_45 = _T_4 & _T_34; // @[src/main/scala/rv32i/Decoder.scala 160:24 64:18]
  wire  _GEN_46 = _T_4 & _T_35; // @[src/main/scala/rv32i/Decoder.scala 160:24 65:18]
  wire  _GEN_47 = _T_4 ? 1'h0 : _T_37; // @[src/main/scala/rv32i/Decoder.scala 160:24 62:18]
  wire [1:0] _GEN_48 = _T_4 ? 2'h0 : _GEN_42; // @[src/main/scala/rv32i/Decoder.scala 160:24 60:18]
  wire  _GEN_49 = 7'h73 == opcode ? _GEN_43 : 1'h1; // @[src/main/scala/rv32i/Decoder.scala 66:18 84:18]
  wire [1:0] _GEN_54 = 7'h73 == opcode ? _GEN_48 : 2'h0; // @[src/main/scala/rv32i/Decoder.scala 60:18 84:18]
  wire  _GEN_55 = 7'hf == opcode ? _GEN_0 : _GEN_49; // @[src/main/scala/rv32i/Decoder.scala 84:18]
  wire  _GEN_56 = 7'hf == opcode ? 1'h0 : 7'h73 == opcode & _GEN_44; // @[src/main/scala/rv32i/Decoder.scala 63:18 84:18]
  wire  _GEN_57 = 7'hf == opcode ? 1'h0 : 7'h73 == opcode & _GEN_45; // @[src/main/scala/rv32i/Decoder.scala 64:18 84:18]
  wire  _GEN_58 = 7'hf == opcode ? 1'h0 : 7'h73 == opcode & _GEN_46; // @[src/main/scala/rv32i/Decoder.scala 65:18 84:18]
  wire  _GEN_59 = 7'hf == opcode ? 1'h0 : 7'h73 == opcode & _GEN_47; // @[src/main/scala/rv32i/Decoder.scala 62:18 84:18]
  wire [1:0] _GEN_60 = 7'hf == opcode ? 2'h0 : _GEN_54; // @[src/main/scala/rv32i/Decoder.scala 60:18 84:18]
  wire  _GEN_61 = 7'h33 == opcode ? _GEN_29 : _GEN_55; // @[src/main/scala/rv32i/Decoder.scala 84:18]
  wire  _GEN_62 = 7'h33 == opcode ? _T_28 : _GEN_59; // @[src/main/scala/rv32i/Decoder.scala 84:18]
  wire [3:0] _GEN_63 = 7'h33 == opcode ? _GEN_31 : 4'h0; // @[src/main/scala/rv32i/Decoder.scala 52:18 84:18]
  wire  _GEN_64 = 7'h33 == opcode ? 1'h0 : _GEN_56; // @[src/main/scala/rv32i/Decoder.scala 63:18 84:18]
  wire  _GEN_65 = 7'h33 == opcode ? 1'h0 : _GEN_57; // @[src/main/scala/rv32i/Decoder.scala 64:18 84:18]
  wire  _GEN_66 = 7'h33 == opcode ? 1'h0 : _GEN_58; // @[src/main/scala/rv32i/Decoder.scala 65:18 84:18]
  wire  _GEN_67 = 7'h33 == opcode ? 1'h0 : _GEN_59; // @[src/main/scala/rv32i/Decoder.scala 62:18 84:18]
  wire [1:0] _GEN_68 = 7'h33 == opcode ? 2'h0 : _GEN_60; // @[src/main/scala/rv32i/Decoder.scala 60:18 84:18]
  wire  _GEN_69 = 7'h13 == opcode ? _GEN_18 : _GEN_61; // @[src/main/scala/rv32i/Decoder.scala 84:18]
  wire  _GEN_70 = 7'h13 == opcode ? shiftOk : _GEN_62; // @[src/main/scala/rv32i/Decoder.scala 84:18]
  wire  _GEN_71 = 7'h13 == opcode & shiftOk; // @[src/main/scala/rv32i/Decoder.scala 51:18 84:18]
  wire [3:0] _GEN_72 = 7'h13 == opcode ? _GEN_20 : _GEN_63; // @[src/main/scala/rv32i/Decoder.scala 84:18]
  wire  _GEN_73 = 7'h13 == opcode ? 1'h0 : _GEN_64; // @[src/main/scala/rv32i/Decoder.scala 63:18 84:18]
  wire  _GEN_74 = 7'h13 == opcode ? 1'h0 : _GEN_65; // @[src/main/scala/rv32i/Decoder.scala 64:18 84:18]
  wire  _GEN_75 = 7'h13 == opcode ? 1'h0 : _GEN_66; // @[src/main/scala/rv32i/Decoder.scala 65:18 84:18]
  wire  _GEN_76 = 7'h13 == opcode ? 1'h0 : _GEN_67; // @[src/main/scala/rv32i/Decoder.scala 62:18 84:18]
  wire [1:0] _GEN_77 = 7'h13 == opcode ? 2'h0 : _GEN_68; // @[src/main/scala/rv32i/Decoder.scala 60:18 84:18]
  wire  _GEN_78 = 7'h23 == opcode ? _GEN_8 : _GEN_69; // @[src/main/scala/rv32i/Decoder.scala 84:18]
  wire  _GEN_80 = 7'h23 == opcode ? _T_14 : _GEN_71; // @[src/main/scala/rv32i/Decoder.scala 84:18]
  wire  _GEN_81 = 7'h23 == opcode ? 1'h0 : _GEN_70; // @[src/main/scala/rv32i/Decoder.scala 61:18 84:18]
  wire [3:0] _GEN_82 = 7'h23 == opcode ? 4'h0 : _GEN_72; // @[src/main/scala/rv32i/Decoder.scala 52:18 84:18]
  wire  _GEN_83 = 7'h23 == opcode ? 1'h0 : _GEN_73; // @[src/main/scala/rv32i/Decoder.scala 63:18 84:18]
  wire  _GEN_84 = 7'h23 == opcode ? 1'h0 : _GEN_74; // @[src/main/scala/rv32i/Decoder.scala 64:18 84:18]
  wire  _GEN_85 = 7'h23 == opcode ? 1'h0 : _GEN_75; // @[src/main/scala/rv32i/Decoder.scala 65:18 84:18]
  wire  _GEN_86 = 7'h23 == opcode ? 1'h0 : _GEN_76; // @[src/main/scala/rv32i/Decoder.scala 62:18 84:18]
  wire [1:0] _GEN_87 = 7'h23 == opcode ? 2'h0 : _GEN_77; // @[src/main/scala/rv32i/Decoder.scala 60:18 84:18]
  wire  _GEN_88 = 7'h3 == opcode ? _GEN_6 : _GEN_78; // @[src/main/scala/rv32i/Decoder.scala 84:18]
  wire  _GEN_90 = 7'h3 == opcode ? _T_18 : _GEN_81; // @[src/main/scala/rv32i/Decoder.scala 84:18]
  wire [1:0] _GEN_91 = 7'h3 == opcode ? {{1'd0}, _T_18} : _GEN_87; // @[src/main/scala/rv32i/Decoder.scala 84:18]
  wire  _GEN_92 = 7'h3 == opcode ? _T_18 : _GEN_80; // @[src/main/scala/rv32i/Decoder.scala 84:18]
  wire  _GEN_93 = 7'h3 == opcode ? 1'h0 : 7'h23 == opcode & _T_14; // @[src/main/scala/rv32i/Decoder.scala 57:18 84:18]
  wire [3:0] _GEN_94 = 7'h3 == opcode ? 4'h0 : _GEN_82; // @[src/main/scala/rv32i/Decoder.scala 52:18 84:18]
  wire  _GEN_95 = 7'h3 == opcode ? 1'h0 : _GEN_83; // @[src/main/scala/rv32i/Decoder.scala 63:18 84:18]
  wire  _GEN_96 = 7'h3 == opcode ? 1'h0 : _GEN_84; // @[src/main/scala/rv32i/Decoder.scala 64:18 84:18]
  wire  _GEN_97 = 7'h3 == opcode ? 1'h0 : _GEN_85; // @[src/main/scala/rv32i/Decoder.scala 65:18 84:18]
  wire  _GEN_98 = 7'h3 == opcode ? 1'h0 : _GEN_86; // @[src/main/scala/rv32i/Decoder.scala 62:18 84:18]
  wire  _GEN_99 = 7'h63 == opcode ? _GEN_3 : _GEN_88; // @[src/main/scala/rv32i/Decoder.scala 84:18]
  wire [1:0] _GEN_101 = 7'h63 == opcode ? _GEN_5 : {{1'd0}, _GEN_93}; // @[src/main/scala/rv32i/Decoder.scala 84:18]
  wire  _GEN_102 = 7'h63 == opcode ? 1'h0 : 7'h3 == opcode & _T_18; // @[src/main/scala/rv32i/Decoder.scala 56:18 84:18]
  wire  _GEN_103 = 7'h63 == opcode ? 1'h0 : _GEN_90; // @[src/main/scala/rv32i/Decoder.scala 61:18 84:18]
  wire [1:0] _GEN_104 = 7'h63 == opcode ? 2'h0 : _GEN_91; // @[src/main/scala/rv32i/Decoder.scala 60:18 84:18]
  wire  _GEN_105 = 7'h63 == opcode ? 1'h0 : _GEN_92; // @[src/main/scala/rv32i/Decoder.scala 51:18 84:18]
  wire  _GEN_106 = 7'h63 == opcode ? 1'h0 : _GEN_93; // @[src/main/scala/rv32i/Decoder.scala 57:18 84:18]
  wire [3:0] _GEN_107 = 7'h63 == opcode ? 4'h0 : _GEN_94; // @[src/main/scala/rv32i/Decoder.scala 52:18 84:18]
  wire  _GEN_108 = 7'h63 == opcode ? 1'h0 : _GEN_95; // @[src/main/scala/rv32i/Decoder.scala 63:18 84:18]
  wire  _GEN_109 = 7'h63 == opcode ? 1'h0 : _GEN_96; // @[src/main/scala/rv32i/Decoder.scala 64:18 84:18]
  wire  _GEN_110 = 7'h63 == opcode ? 1'h0 : _GEN_97; // @[src/main/scala/rv32i/Decoder.scala 65:18 84:18]
  wire  _GEN_111 = 7'h63 == opcode ? 1'h0 : _GEN_98; // @[src/main/scala/rv32i/Decoder.scala 62:18 84:18]
  wire  _GEN_112 = 7'h67 == opcode ? _GEN_0 : _GEN_99; // @[src/main/scala/rv32i/Decoder.scala 84:18]
  wire  _GEN_114 = 7'h67 == opcode ? _T_4 : _GEN_103; // @[src/main/scala/rv32i/Decoder.scala 84:18]
  wire [1:0] _GEN_115 = 7'h67 == opcode ? _GEN_2 : _GEN_104; // @[src/main/scala/rv32i/Decoder.scala 84:18]
  wire  _GEN_116 = 7'h67 == opcode ? _T_4 : _GEN_105; // @[src/main/scala/rv32i/Decoder.scala 84:18]
  wire  _GEN_117 = 7'h67 == opcode ? 1'h0 : 7'h63 == opcode & _T_8; // @[src/main/scala/rv32i/Decoder.scala 53:18 84:18]
  wire [1:0] _GEN_118 = 7'h67 == opcode ? 2'h0 : _GEN_101; // @[src/main/scala/rv32i/Decoder.scala 49:18 84:18]
  wire  _GEN_119 = 7'h67 == opcode ? 1'h0 : _GEN_102; // @[src/main/scala/rv32i/Decoder.scala 56:18 84:18]
  wire  _GEN_120 = 7'h67 == opcode ? 1'h0 : _GEN_106; // @[src/main/scala/rv32i/Decoder.scala 57:18 84:18]
  wire [3:0] _GEN_121 = 7'h67 == opcode ? 4'h0 : _GEN_107; // @[src/main/scala/rv32i/Decoder.scala 52:18 84:18]
  wire  _GEN_122 = 7'h67 == opcode ? 1'h0 : _GEN_108; // @[src/main/scala/rv32i/Decoder.scala 63:18 84:18]
  wire  _GEN_123 = 7'h67 == opcode ? 1'h0 : _GEN_109; // @[src/main/scala/rv32i/Decoder.scala 64:18 84:18]
  wire  _GEN_124 = 7'h67 == opcode ? 1'h0 : _GEN_110; // @[src/main/scala/rv32i/Decoder.scala 65:18 84:18]
  wire  _GEN_125 = 7'h67 == opcode ? 1'h0 : _GEN_111; // @[src/main/scala/rv32i/Decoder.scala 62:18 84:18]
  wire  _GEN_126 = 7'h6f == opcode ? 1'h0 : _GEN_112; // @[src/main/scala/rv32i/Decoder.scala 84:18 100:19]
  wire  _GEN_128 = 7'h6f == opcode | _GEN_114; // @[src/main/scala/rv32i/Decoder.scala 84:18 102:19]
  wire [1:0] _GEN_129 = 7'h6f == opcode ? 2'h2 : _GEN_115; // @[src/main/scala/rv32i/Decoder.scala 84:18 103:19]
  wire [2:0] _GEN_130 = 7'h6f == opcode ? 3'h4 : {{1'd0}, _GEN_118}; // @[src/main/scala/rv32i/Decoder.scala 84:18 104:19]
  wire  _GEN_131 = 7'h6f == opcode ? 1'h0 : 7'h67 == opcode & _T_4; // @[src/main/scala/rv32i/Decoder.scala 55:18 84:18]
  wire  _GEN_132 = 7'h6f == opcode ? 1'h0 : _GEN_116; // @[src/main/scala/rv32i/Decoder.scala 51:18 84:18]
  wire  _GEN_133 = 7'h6f == opcode ? 1'h0 : _GEN_117; // @[src/main/scala/rv32i/Decoder.scala 53:18 84:18]
  wire  _GEN_134 = 7'h6f == opcode ? 1'h0 : _GEN_119; // @[src/main/scala/rv32i/Decoder.scala 56:18 84:18]
  wire  _GEN_135 = 7'h6f == opcode ? 1'h0 : _GEN_120; // @[src/main/scala/rv32i/Decoder.scala 57:18 84:18]
  wire [3:0] _GEN_136 = 7'h6f == opcode ? 4'h0 : _GEN_121; // @[src/main/scala/rv32i/Decoder.scala 52:18 84:18]
  wire  _GEN_137 = 7'h6f == opcode ? 1'h0 : _GEN_122; // @[src/main/scala/rv32i/Decoder.scala 63:18 84:18]
  wire  _GEN_138 = 7'h6f == opcode ? 1'h0 : _GEN_123; // @[src/main/scala/rv32i/Decoder.scala 64:18 84:18]
  wire  _GEN_139 = 7'h6f == opcode ? 1'h0 : _GEN_124; // @[src/main/scala/rv32i/Decoder.scala 65:18 84:18]
  wire  _GEN_140 = 7'h6f == opcode ? 1'h0 : _GEN_125; // @[src/main/scala/rv32i/Decoder.scala 62:18 84:18]
  wire  _GEN_141 = 7'h17 == opcode ? 1'h0 : _GEN_126; // @[src/main/scala/rv32i/Decoder.scala 84:18 93:20]
  wire  _GEN_142 = 7'h17 == opcode | _GEN_128; // @[src/main/scala/rv32i/Decoder.scala 84:18 94:20]
  wire [2:0] _GEN_143 = 7'h17 == opcode ? 3'h3 : _GEN_130; // @[src/main/scala/rv32i/Decoder.scala 84:18 95:20]
  wire  _GEN_145 = 7'h17 == opcode | _GEN_132; // @[src/main/scala/rv32i/Decoder.scala 84:18 97:20]
  wire  _GEN_146 = 7'h17 == opcode ? 1'h0 : 7'h6f == opcode; // @[src/main/scala/rv32i/Decoder.scala 54:18 84:18]
  wire [1:0] _GEN_147 = 7'h17 == opcode ? 2'h0 : _GEN_129; // @[src/main/scala/rv32i/Decoder.scala 60:18 84:18]
  wire  _GEN_148 = 7'h17 == opcode ? 1'h0 : _GEN_131; // @[src/main/scala/rv32i/Decoder.scala 55:18 84:18]
  wire  _GEN_149 = 7'h17 == opcode ? 1'h0 : _GEN_133; // @[src/main/scala/rv32i/Decoder.scala 53:18 84:18]
  wire  _GEN_150 = 7'h17 == opcode ? 1'h0 : _GEN_134; // @[src/main/scala/rv32i/Decoder.scala 56:18 84:18]
  wire  _GEN_151 = 7'h17 == opcode ? 1'h0 : _GEN_135; // @[src/main/scala/rv32i/Decoder.scala 57:18 84:18]
  wire [3:0] _GEN_152 = 7'h17 == opcode ? 4'h0 : _GEN_136; // @[src/main/scala/rv32i/Decoder.scala 52:18 84:18]
  wire  _GEN_153 = 7'h17 == opcode ? 1'h0 : _GEN_137; // @[src/main/scala/rv32i/Decoder.scala 63:18 84:18]
  wire  _GEN_154 = 7'h17 == opcode ? 1'h0 : _GEN_138; // @[src/main/scala/rv32i/Decoder.scala 64:18 84:18]
  wire  _GEN_155 = 7'h17 == opcode ? 1'h0 : _GEN_139; // @[src/main/scala/rv32i/Decoder.scala 65:18 84:18]
  wire  _GEN_156 = 7'h17 == opcode ? 1'h0 : _GEN_140; // @[src/main/scala/rv32i/Decoder.scala 62:18 84:18]
  assign io_immSel = 7'h37 == opcode ? 3'h3 : _GEN_143; // @[src/main/scala/rv32i/Decoder.scala 84:18 88:20]
  assign io_aluSrcA = 7'h37 == opcode ? 2'h2 : {{1'd0}, 7'h17 == opcode}; // @[src/main/scala/rv32i/Decoder.scala 84:18 89:20]
  assign io_aluSrcImm = 7'h37 == opcode | _GEN_145; // @[src/main/scala/rv32i/Decoder.scala 84:18 90:20]
  assign io_aluOp = 7'h37 == opcode ? 4'h0 : _GEN_152; // @[src/main/scala/rv32i/Decoder.scala 52:18 84:18]
  assign io_branch = 7'h37 == opcode ? 1'h0 : _GEN_149; // @[src/main/scala/rv32i/Decoder.scala 53:18 84:18]
  assign io_jal = 7'h37 == opcode ? 1'h0 : _GEN_146; // @[src/main/scala/rv32i/Decoder.scala 54:18 84:18]
  assign io_jalr = 7'h37 == opcode ? 1'h0 : _GEN_148; // @[src/main/scala/rv32i/Decoder.scala 55:18 84:18]
  assign io_memRead = 7'h37 == opcode ? 1'h0 : _GEN_150; // @[src/main/scala/rv32i/Decoder.scala 56:18 84:18]
  assign io_memWrite = 7'h37 == opcode ? 1'h0 : _GEN_151; // @[src/main/scala/rv32i/Decoder.scala 57:18 84:18]
  assign io_memSize = f3[1:0]; // @[src/main/scala/rv32i/Decoder.scala 58:23]
  assign io_memUnsigned = f3[2]; // @[src/main/scala/rv32i/Decoder.scala 59:23]
  assign io_wbSel = 7'h37 == opcode ? 2'h0 : _GEN_147; // @[src/main/scala/rv32i/Decoder.scala 60:18 84:18]
  assign io_regWrite = 7'h37 == opcode | _GEN_142; // @[src/main/scala/rv32i/Decoder.scala 84:18 87:20]
  assign io_csr = 7'h37 == opcode ? 1'h0 : _GEN_156; // @[src/main/scala/rv32i/Decoder.scala 62:18 84:18]
  assign io_ecall = 7'h37 == opcode ? 1'h0 : _GEN_153; // @[src/main/scala/rv32i/Decoder.scala 63:18 84:18]
  assign io_ebreak = 7'h37 == opcode ? 1'h0 : _GEN_154; // @[src/main/scala/rv32i/Decoder.scala 64:18 84:18]
  assign io_mret = 7'h37 == opcode ? 1'h0 : _GEN_155; // @[src/main/scala/rv32i/Decoder.scala 65:18 84:18]
  assign io_illegal = 7'h37 == opcode ? 1'h0 : _GEN_141; // @[src/main/scala/rv32i/Decoder.scala 84:18 86:20]
endmodule
module ImmGen(
  input  [31:0] io_inst, // @[src/main/scala/rv32i/ImmGen.scala 8:14]
  input  [2:0]  io_sel, // @[src/main/scala/rv32i/ImmGen.scala 8:14]
  output [31:0] io_imm // @[src/main/scala/rv32i/ImmGen.scala 8:14]
);
  wire  sign = io_inst[31]; // @[src/main/scala/rv32i/ImmGen.scala 15:15]
  wire [20:0] _immI_T = sign ? 21'h1fffff : 21'h0; // @[src/main/scala/rv32i/ImmGen.scala 16:22]
  wire [31:0] immI = {_immI_T,io_inst[30:20]}; // @[src/main/scala/rv32i/ImmGen.scala 16:17]
  wire [31:0] immS = {_immI_T,io_inst[30:25],io_inst[11:7]}; // @[src/main/scala/rv32i/ImmGen.scala 17:17]
  wire [19:0] _immB_T = sign ? 20'hfffff : 20'h0; // @[src/main/scala/rv32i/ImmGen.scala 18:22]
  wire [31:0] immB = {_immB_T,io_inst[7],io_inst[30:25],io_inst[11:8],1'h0}; // @[src/main/scala/rv32i/ImmGen.scala 18:17]
  wire [31:0] immU = {io_inst[31:12],12'h0}; // @[src/main/scala/rv32i/ImmGen.scala 19:17]
  wire [11:0] _immJ_T = sign ? 12'hfff : 12'h0; // @[src/main/scala/rv32i/ImmGen.scala 20:22]
  wire [31:0] immJ = {_immJ_T,io_inst[19:12],io_inst[20],io_inst[30:21],1'h0}; // @[src/main/scala/rv32i/ImmGen.scala 20:17]
  wire [31:0] _GEN_0 = 3'h4 == io_sel ? immJ : immI; // @[src/main/scala/rv32i/ImmGen.scala 22:10 23:18 28:27]
  wire [31:0] _GEN_1 = 3'h3 == io_sel ? immU : _GEN_0; // @[src/main/scala/rv32i/ImmGen.scala 23:18 27:27]
  wire [31:0] _GEN_2 = 3'h2 == io_sel ? immB : _GEN_1; // @[src/main/scala/rv32i/ImmGen.scala 23:18 26:27]
  wire [31:0] _GEN_3 = 3'h1 == io_sel ? immS : _GEN_2; // @[src/main/scala/rv32i/ImmGen.scala 23:18 25:27]
  assign io_imm = 3'h0 == io_sel ? immI : _GEN_3; // @[src/main/scala/rv32i/ImmGen.scala 23:18 24:27]
endmodule
module RegFile(
  input         clock,
  input         reset,
  input  [4:0]  io_rs1, // @[src/main/scala/rv32i/RegFile.scala 9:14]
  input  [4:0]  io_rs2, // @[src/main/scala/rv32i/RegFile.scala 9:14]
  output [31:0] io_rd1, // @[src/main/scala/rv32i/RegFile.scala 9:14]
  output [31:0] io_rd2, // @[src/main/scala/rv32i/RegFile.scala 9:14]
  input         io_we, // @[src/main/scala/rv32i/RegFile.scala 9:14]
  input  [4:0]  io_waddr, // @[src/main/scala/rv32i/RegFile.scala 9:14]
  input  [31:0] io_wdata // @[src/main/scala/rv32i/RegFile.scala 9:14]
);
`ifdef RANDOMIZE_REG_INIT
  reg [31:0] _RAND_0;
  reg [31:0] _RAND_1;
  reg [31:0] _RAND_2;
  reg [31:0] _RAND_3;
  reg [31:0] _RAND_4;
  reg [31:0] _RAND_5;
  reg [31:0] _RAND_6;
  reg [31:0] _RAND_7;
  reg [31:0] _RAND_8;
  reg [31:0] _RAND_9;
  reg [31:0] _RAND_10;
  reg [31:0] _RAND_11;
  reg [31:0] _RAND_12;
  reg [31:0] _RAND_13;
  reg [31:0] _RAND_14;
  reg [31:0] _RAND_15;
  reg [31:0] _RAND_16;
  reg [31:0] _RAND_17;
  reg [31:0] _RAND_18;
  reg [31:0] _RAND_19;
  reg [31:0] _RAND_20;
  reg [31:0] _RAND_21;
  reg [31:0] _RAND_22;
  reg [31:0] _RAND_23;
  reg [31:0] _RAND_24;
  reg [31:0] _RAND_25;
  reg [31:0] _RAND_26;
  reg [31:0] _RAND_27;
  reg [31:0] _RAND_28;
  reg [31:0] _RAND_29;
  reg [31:0] _RAND_30;
  reg [31:0] _RAND_31;
`endif // RANDOMIZE_REG_INIT
  reg [31:0] regs_0; // @[src/main/scala/rv32i/RegFile.scala 19:21]
  reg [31:0] regs_1; // @[src/main/scala/rv32i/RegFile.scala 19:21]
  reg [31:0] regs_2; // @[src/main/scala/rv32i/RegFile.scala 19:21]
  reg [31:0] regs_3; // @[src/main/scala/rv32i/RegFile.scala 19:21]
  reg [31:0] regs_4; // @[src/main/scala/rv32i/RegFile.scala 19:21]
  reg [31:0] regs_5; // @[src/main/scala/rv32i/RegFile.scala 19:21]
  reg [31:0] regs_6; // @[src/main/scala/rv32i/RegFile.scala 19:21]
  reg [31:0] regs_7; // @[src/main/scala/rv32i/RegFile.scala 19:21]
  reg [31:0] regs_8; // @[src/main/scala/rv32i/RegFile.scala 19:21]
  reg [31:0] regs_9; // @[src/main/scala/rv32i/RegFile.scala 19:21]
  reg [31:0] regs_10; // @[src/main/scala/rv32i/RegFile.scala 19:21]
  reg [31:0] regs_11; // @[src/main/scala/rv32i/RegFile.scala 19:21]
  reg [31:0] regs_12; // @[src/main/scala/rv32i/RegFile.scala 19:21]
  reg [31:0] regs_13; // @[src/main/scala/rv32i/RegFile.scala 19:21]
  reg [31:0] regs_14; // @[src/main/scala/rv32i/RegFile.scala 19:21]
  reg [31:0] regs_15; // @[src/main/scala/rv32i/RegFile.scala 19:21]
  reg [31:0] regs_16; // @[src/main/scala/rv32i/RegFile.scala 19:21]
  reg [31:0] regs_17; // @[src/main/scala/rv32i/RegFile.scala 19:21]
  reg [31:0] regs_18; // @[src/main/scala/rv32i/RegFile.scala 19:21]
  reg [31:0] regs_19; // @[src/main/scala/rv32i/RegFile.scala 19:21]
  reg [31:0] regs_20; // @[src/main/scala/rv32i/RegFile.scala 19:21]
  reg [31:0] regs_21; // @[src/main/scala/rv32i/RegFile.scala 19:21]
  reg [31:0] regs_22; // @[src/main/scala/rv32i/RegFile.scala 19:21]
  reg [31:0] regs_23; // @[src/main/scala/rv32i/RegFile.scala 19:21]
  reg [31:0] regs_24; // @[src/main/scala/rv32i/RegFile.scala 19:21]
  reg [31:0] regs_25; // @[src/main/scala/rv32i/RegFile.scala 19:21]
  reg [31:0] regs_26; // @[src/main/scala/rv32i/RegFile.scala 19:21]
  reg [31:0] regs_27; // @[src/main/scala/rv32i/RegFile.scala 19:21]
  reg [31:0] regs_28; // @[src/main/scala/rv32i/RegFile.scala 19:21]
  reg [31:0] regs_29; // @[src/main/scala/rv32i/RegFile.scala 19:21]
  reg [31:0] regs_30; // @[src/main/scala/rv32i/RegFile.scala 19:21]
  reg [31:0] regs_31; // @[src/main/scala/rv32i/RegFile.scala 19:21]
  wire [31:0] _GEN_1 = 5'h1 == io_rs1 ? regs_1 : regs_0; // @[src/main/scala/rv32i/RegFile.scala 21:{16,16}]
  wire [31:0] _GEN_2 = 5'h2 == io_rs1 ? regs_2 : _GEN_1; // @[src/main/scala/rv32i/RegFile.scala 21:{16,16}]
  wire [31:0] _GEN_3 = 5'h3 == io_rs1 ? regs_3 : _GEN_2; // @[src/main/scala/rv32i/RegFile.scala 21:{16,16}]
  wire [31:0] _GEN_4 = 5'h4 == io_rs1 ? regs_4 : _GEN_3; // @[src/main/scala/rv32i/RegFile.scala 21:{16,16}]
  wire [31:0] _GEN_5 = 5'h5 == io_rs1 ? regs_5 : _GEN_4; // @[src/main/scala/rv32i/RegFile.scala 21:{16,16}]
  wire [31:0] _GEN_6 = 5'h6 == io_rs1 ? regs_6 : _GEN_5; // @[src/main/scala/rv32i/RegFile.scala 21:{16,16}]
  wire [31:0] _GEN_7 = 5'h7 == io_rs1 ? regs_7 : _GEN_6; // @[src/main/scala/rv32i/RegFile.scala 21:{16,16}]
  wire [31:0] _GEN_8 = 5'h8 == io_rs1 ? regs_8 : _GEN_7; // @[src/main/scala/rv32i/RegFile.scala 21:{16,16}]
  wire [31:0] _GEN_9 = 5'h9 == io_rs1 ? regs_9 : _GEN_8; // @[src/main/scala/rv32i/RegFile.scala 21:{16,16}]
  wire [31:0] _GEN_10 = 5'ha == io_rs1 ? regs_10 : _GEN_9; // @[src/main/scala/rv32i/RegFile.scala 21:{16,16}]
  wire [31:0] _GEN_11 = 5'hb == io_rs1 ? regs_11 : _GEN_10; // @[src/main/scala/rv32i/RegFile.scala 21:{16,16}]
  wire [31:0] _GEN_12 = 5'hc == io_rs1 ? regs_12 : _GEN_11; // @[src/main/scala/rv32i/RegFile.scala 21:{16,16}]
  wire [31:0] _GEN_13 = 5'hd == io_rs1 ? regs_13 : _GEN_12; // @[src/main/scala/rv32i/RegFile.scala 21:{16,16}]
  wire [31:0] _GEN_14 = 5'he == io_rs1 ? regs_14 : _GEN_13; // @[src/main/scala/rv32i/RegFile.scala 21:{16,16}]
  wire [31:0] _GEN_15 = 5'hf == io_rs1 ? regs_15 : _GEN_14; // @[src/main/scala/rv32i/RegFile.scala 21:{16,16}]
  wire [31:0] _GEN_16 = 5'h10 == io_rs1 ? regs_16 : _GEN_15; // @[src/main/scala/rv32i/RegFile.scala 21:{16,16}]
  wire [31:0] _GEN_17 = 5'h11 == io_rs1 ? regs_17 : _GEN_16; // @[src/main/scala/rv32i/RegFile.scala 21:{16,16}]
  wire [31:0] _GEN_18 = 5'h12 == io_rs1 ? regs_18 : _GEN_17; // @[src/main/scala/rv32i/RegFile.scala 21:{16,16}]
  wire [31:0] _GEN_19 = 5'h13 == io_rs1 ? regs_19 : _GEN_18; // @[src/main/scala/rv32i/RegFile.scala 21:{16,16}]
  wire [31:0] _GEN_20 = 5'h14 == io_rs1 ? regs_20 : _GEN_19; // @[src/main/scala/rv32i/RegFile.scala 21:{16,16}]
  wire [31:0] _GEN_21 = 5'h15 == io_rs1 ? regs_21 : _GEN_20; // @[src/main/scala/rv32i/RegFile.scala 21:{16,16}]
  wire [31:0] _GEN_22 = 5'h16 == io_rs1 ? regs_22 : _GEN_21; // @[src/main/scala/rv32i/RegFile.scala 21:{16,16}]
  wire [31:0] _GEN_23 = 5'h17 == io_rs1 ? regs_23 : _GEN_22; // @[src/main/scala/rv32i/RegFile.scala 21:{16,16}]
  wire [31:0] _GEN_24 = 5'h18 == io_rs1 ? regs_24 : _GEN_23; // @[src/main/scala/rv32i/RegFile.scala 21:{16,16}]
  wire [31:0] _GEN_25 = 5'h19 == io_rs1 ? regs_25 : _GEN_24; // @[src/main/scala/rv32i/RegFile.scala 21:{16,16}]
  wire [31:0] _GEN_26 = 5'h1a == io_rs1 ? regs_26 : _GEN_25; // @[src/main/scala/rv32i/RegFile.scala 21:{16,16}]
  wire [31:0] _GEN_27 = 5'h1b == io_rs1 ? regs_27 : _GEN_26; // @[src/main/scala/rv32i/RegFile.scala 21:{16,16}]
  wire [31:0] _GEN_28 = 5'h1c == io_rs1 ? regs_28 : _GEN_27; // @[src/main/scala/rv32i/RegFile.scala 21:{16,16}]
  wire [31:0] _GEN_29 = 5'h1d == io_rs1 ? regs_29 : _GEN_28; // @[src/main/scala/rv32i/RegFile.scala 21:{16,16}]
  wire [31:0] _GEN_30 = 5'h1e == io_rs1 ? regs_30 : _GEN_29; // @[src/main/scala/rv32i/RegFile.scala 21:{16,16}]
  wire [31:0] _GEN_31 = 5'h1f == io_rs1 ? regs_31 : _GEN_30; // @[src/main/scala/rv32i/RegFile.scala 21:{16,16}]
  wire [31:0] _GEN_33 = 5'h1 == io_rs2 ? regs_1 : regs_0; // @[src/main/scala/rv32i/RegFile.scala 22:{16,16}]
  wire [31:0] _GEN_34 = 5'h2 == io_rs2 ? regs_2 : _GEN_33; // @[src/main/scala/rv32i/RegFile.scala 22:{16,16}]
  wire [31:0] _GEN_35 = 5'h3 == io_rs2 ? regs_3 : _GEN_34; // @[src/main/scala/rv32i/RegFile.scala 22:{16,16}]
  wire [31:0] _GEN_36 = 5'h4 == io_rs2 ? regs_4 : _GEN_35; // @[src/main/scala/rv32i/RegFile.scala 22:{16,16}]
  wire [31:0] _GEN_37 = 5'h5 == io_rs2 ? regs_5 : _GEN_36; // @[src/main/scala/rv32i/RegFile.scala 22:{16,16}]
  wire [31:0] _GEN_38 = 5'h6 == io_rs2 ? regs_6 : _GEN_37; // @[src/main/scala/rv32i/RegFile.scala 22:{16,16}]
  wire [31:0] _GEN_39 = 5'h7 == io_rs2 ? regs_7 : _GEN_38; // @[src/main/scala/rv32i/RegFile.scala 22:{16,16}]
  wire [31:0] _GEN_40 = 5'h8 == io_rs2 ? regs_8 : _GEN_39; // @[src/main/scala/rv32i/RegFile.scala 22:{16,16}]
  wire [31:0] _GEN_41 = 5'h9 == io_rs2 ? regs_9 : _GEN_40; // @[src/main/scala/rv32i/RegFile.scala 22:{16,16}]
  wire [31:0] _GEN_42 = 5'ha == io_rs2 ? regs_10 : _GEN_41; // @[src/main/scala/rv32i/RegFile.scala 22:{16,16}]
  wire [31:0] _GEN_43 = 5'hb == io_rs2 ? regs_11 : _GEN_42; // @[src/main/scala/rv32i/RegFile.scala 22:{16,16}]
  wire [31:0] _GEN_44 = 5'hc == io_rs2 ? regs_12 : _GEN_43; // @[src/main/scala/rv32i/RegFile.scala 22:{16,16}]
  wire [31:0] _GEN_45 = 5'hd == io_rs2 ? regs_13 : _GEN_44; // @[src/main/scala/rv32i/RegFile.scala 22:{16,16}]
  wire [31:0] _GEN_46 = 5'he == io_rs2 ? regs_14 : _GEN_45; // @[src/main/scala/rv32i/RegFile.scala 22:{16,16}]
  wire [31:0] _GEN_47 = 5'hf == io_rs2 ? regs_15 : _GEN_46; // @[src/main/scala/rv32i/RegFile.scala 22:{16,16}]
  wire [31:0] _GEN_48 = 5'h10 == io_rs2 ? regs_16 : _GEN_47; // @[src/main/scala/rv32i/RegFile.scala 22:{16,16}]
  wire [31:0] _GEN_49 = 5'h11 == io_rs2 ? regs_17 : _GEN_48; // @[src/main/scala/rv32i/RegFile.scala 22:{16,16}]
  wire [31:0] _GEN_50 = 5'h12 == io_rs2 ? regs_18 : _GEN_49; // @[src/main/scala/rv32i/RegFile.scala 22:{16,16}]
  wire [31:0] _GEN_51 = 5'h13 == io_rs2 ? regs_19 : _GEN_50; // @[src/main/scala/rv32i/RegFile.scala 22:{16,16}]
  wire [31:0] _GEN_52 = 5'h14 == io_rs2 ? regs_20 : _GEN_51; // @[src/main/scala/rv32i/RegFile.scala 22:{16,16}]
  wire [31:0] _GEN_53 = 5'h15 == io_rs2 ? regs_21 : _GEN_52; // @[src/main/scala/rv32i/RegFile.scala 22:{16,16}]
  wire [31:0] _GEN_54 = 5'h16 == io_rs2 ? regs_22 : _GEN_53; // @[src/main/scala/rv32i/RegFile.scala 22:{16,16}]
  wire [31:0] _GEN_55 = 5'h17 == io_rs2 ? regs_23 : _GEN_54; // @[src/main/scala/rv32i/RegFile.scala 22:{16,16}]
  wire [31:0] _GEN_56 = 5'h18 == io_rs2 ? regs_24 : _GEN_55; // @[src/main/scala/rv32i/RegFile.scala 22:{16,16}]
  wire [31:0] _GEN_57 = 5'h19 == io_rs2 ? regs_25 : _GEN_56; // @[src/main/scala/rv32i/RegFile.scala 22:{16,16}]
  wire [31:0] _GEN_58 = 5'h1a == io_rs2 ? regs_26 : _GEN_57; // @[src/main/scala/rv32i/RegFile.scala 22:{16,16}]
  wire [31:0] _GEN_59 = 5'h1b == io_rs2 ? regs_27 : _GEN_58; // @[src/main/scala/rv32i/RegFile.scala 22:{16,16}]
  wire [31:0] _GEN_60 = 5'h1c == io_rs2 ? regs_28 : _GEN_59; // @[src/main/scala/rv32i/RegFile.scala 22:{16,16}]
  wire [31:0] _GEN_61 = 5'h1d == io_rs2 ? regs_29 : _GEN_60; // @[src/main/scala/rv32i/RegFile.scala 22:{16,16}]
  wire [31:0] _GEN_62 = 5'h1e == io_rs2 ? regs_30 : _GEN_61; // @[src/main/scala/rv32i/RegFile.scala 22:{16,16}]
  wire [31:0] _GEN_63 = 5'h1f == io_rs2 ? regs_31 : _GEN_62; // @[src/main/scala/rv32i/RegFile.scala 22:{16,16}]
  assign io_rd1 = io_rs1 == 5'h0 ? 32'h0 : _GEN_31; // @[src/main/scala/rv32i/RegFile.scala 21:16]
  assign io_rd2 = io_rs2 == 5'h0 ? 32'h0 : _GEN_63; // @[src/main/scala/rv32i/RegFile.scala 22:16]
  always @(posedge clock) begin
    if (reset) begin // @[src/main/scala/rv32i/RegFile.scala 19:21]
      regs_0 <= 32'h0; // @[src/main/scala/rv32i/RegFile.scala 19:21]
    end else if (io_we & io_waddr != 5'h0) begin // @[src/main/scala/rv32i/RegFile.scala 24:35]
      if (5'h0 == io_waddr) begin // @[src/main/scala/rv32i/RegFile.scala 25:20]
        regs_0 <= io_wdata; // @[src/main/scala/rv32i/RegFile.scala 25:20]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegFile.scala 19:21]
      regs_1 <= 32'h0; // @[src/main/scala/rv32i/RegFile.scala 19:21]
    end else if (io_we & io_waddr != 5'h0) begin // @[src/main/scala/rv32i/RegFile.scala 24:35]
      if (5'h1 == io_waddr) begin // @[src/main/scala/rv32i/RegFile.scala 25:20]
        regs_1 <= io_wdata; // @[src/main/scala/rv32i/RegFile.scala 25:20]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegFile.scala 19:21]
      regs_2 <= 32'h0; // @[src/main/scala/rv32i/RegFile.scala 19:21]
    end else if (io_we & io_waddr != 5'h0) begin // @[src/main/scala/rv32i/RegFile.scala 24:35]
      if (5'h2 == io_waddr) begin // @[src/main/scala/rv32i/RegFile.scala 25:20]
        regs_2 <= io_wdata; // @[src/main/scala/rv32i/RegFile.scala 25:20]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegFile.scala 19:21]
      regs_3 <= 32'h0; // @[src/main/scala/rv32i/RegFile.scala 19:21]
    end else if (io_we & io_waddr != 5'h0) begin // @[src/main/scala/rv32i/RegFile.scala 24:35]
      if (5'h3 == io_waddr) begin // @[src/main/scala/rv32i/RegFile.scala 25:20]
        regs_3 <= io_wdata; // @[src/main/scala/rv32i/RegFile.scala 25:20]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegFile.scala 19:21]
      regs_4 <= 32'h0; // @[src/main/scala/rv32i/RegFile.scala 19:21]
    end else if (io_we & io_waddr != 5'h0) begin // @[src/main/scala/rv32i/RegFile.scala 24:35]
      if (5'h4 == io_waddr) begin // @[src/main/scala/rv32i/RegFile.scala 25:20]
        regs_4 <= io_wdata; // @[src/main/scala/rv32i/RegFile.scala 25:20]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegFile.scala 19:21]
      regs_5 <= 32'h0; // @[src/main/scala/rv32i/RegFile.scala 19:21]
    end else if (io_we & io_waddr != 5'h0) begin // @[src/main/scala/rv32i/RegFile.scala 24:35]
      if (5'h5 == io_waddr) begin // @[src/main/scala/rv32i/RegFile.scala 25:20]
        regs_5 <= io_wdata; // @[src/main/scala/rv32i/RegFile.scala 25:20]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegFile.scala 19:21]
      regs_6 <= 32'h0; // @[src/main/scala/rv32i/RegFile.scala 19:21]
    end else if (io_we & io_waddr != 5'h0) begin // @[src/main/scala/rv32i/RegFile.scala 24:35]
      if (5'h6 == io_waddr) begin // @[src/main/scala/rv32i/RegFile.scala 25:20]
        regs_6 <= io_wdata; // @[src/main/scala/rv32i/RegFile.scala 25:20]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegFile.scala 19:21]
      regs_7 <= 32'h0; // @[src/main/scala/rv32i/RegFile.scala 19:21]
    end else if (io_we & io_waddr != 5'h0) begin // @[src/main/scala/rv32i/RegFile.scala 24:35]
      if (5'h7 == io_waddr) begin // @[src/main/scala/rv32i/RegFile.scala 25:20]
        regs_7 <= io_wdata; // @[src/main/scala/rv32i/RegFile.scala 25:20]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegFile.scala 19:21]
      regs_8 <= 32'h0; // @[src/main/scala/rv32i/RegFile.scala 19:21]
    end else if (io_we & io_waddr != 5'h0) begin // @[src/main/scala/rv32i/RegFile.scala 24:35]
      if (5'h8 == io_waddr) begin // @[src/main/scala/rv32i/RegFile.scala 25:20]
        regs_8 <= io_wdata; // @[src/main/scala/rv32i/RegFile.scala 25:20]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegFile.scala 19:21]
      regs_9 <= 32'h0; // @[src/main/scala/rv32i/RegFile.scala 19:21]
    end else if (io_we & io_waddr != 5'h0) begin // @[src/main/scala/rv32i/RegFile.scala 24:35]
      if (5'h9 == io_waddr) begin // @[src/main/scala/rv32i/RegFile.scala 25:20]
        regs_9 <= io_wdata; // @[src/main/scala/rv32i/RegFile.scala 25:20]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegFile.scala 19:21]
      regs_10 <= 32'h0; // @[src/main/scala/rv32i/RegFile.scala 19:21]
    end else if (io_we & io_waddr != 5'h0) begin // @[src/main/scala/rv32i/RegFile.scala 24:35]
      if (5'ha == io_waddr) begin // @[src/main/scala/rv32i/RegFile.scala 25:20]
        regs_10 <= io_wdata; // @[src/main/scala/rv32i/RegFile.scala 25:20]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegFile.scala 19:21]
      regs_11 <= 32'h0; // @[src/main/scala/rv32i/RegFile.scala 19:21]
    end else if (io_we & io_waddr != 5'h0) begin // @[src/main/scala/rv32i/RegFile.scala 24:35]
      if (5'hb == io_waddr) begin // @[src/main/scala/rv32i/RegFile.scala 25:20]
        regs_11 <= io_wdata; // @[src/main/scala/rv32i/RegFile.scala 25:20]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegFile.scala 19:21]
      regs_12 <= 32'h0; // @[src/main/scala/rv32i/RegFile.scala 19:21]
    end else if (io_we & io_waddr != 5'h0) begin // @[src/main/scala/rv32i/RegFile.scala 24:35]
      if (5'hc == io_waddr) begin // @[src/main/scala/rv32i/RegFile.scala 25:20]
        regs_12 <= io_wdata; // @[src/main/scala/rv32i/RegFile.scala 25:20]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegFile.scala 19:21]
      regs_13 <= 32'h0; // @[src/main/scala/rv32i/RegFile.scala 19:21]
    end else if (io_we & io_waddr != 5'h0) begin // @[src/main/scala/rv32i/RegFile.scala 24:35]
      if (5'hd == io_waddr) begin // @[src/main/scala/rv32i/RegFile.scala 25:20]
        regs_13 <= io_wdata; // @[src/main/scala/rv32i/RegFile.scala 25:20]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegFile.scala 19:21]
      regs_14 <= 32'h0; // @[src/main/scala/rv32i/RegFile.scala 19:21]
    end else if (io_we & io_waddr != 5'h0) begin // @[src/main/scala/rv32i/RegFile.scala 24:35]
      if (5'he == io_waddr) begin // @[src/main/scala/rv32i/RegFile.scala 25:20]
        regs_14 <= io_wdata; // @[src/main/scala/rv32i/RegFile.scala 25:20]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegFile.scala 19:21]
      regs_15 <= 32'h0; // @[src/main/scala/rv32i/RegFile.scala 19:21]
    end else if (io_we & io_waddr != 5'h0) begin // @[src/main/scala/rv32i/RegFile.scala 24:35]
      if (5'hf == io_waddr) begin // @[src/main/scala/rv32i/RegFile.scala 25:20]
        regs_15 <= io_wdata; // @[src/main/scala/rv32i/RegFile.scala 25:20]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegFile.scala 19:21]
      regs_16 <= 32'h0; // @[src/main/scala/rv32i/RegFile.scala 19:21]
    end else if (io_we & io_waddr != 5'h0) begin // @[src/main/scala/rv32i/RegFile.scala 24:35]
      if (5'h10 == io_waddr) begin // @[src/main/scala/rv32i/RegFile.scala 25:20]
        regs_16 <= io_wdata; // @[src/main/scala/rv32i/RegFile.scala 25:20]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegFile.scala 19:21]
      regs_17 <= 32'h0; // @[src/main/scala/rv32i/RegFile.scala 19:21]
    end else if (io_we & io_waddr != 5'h0) begin // @[src/main/scala/rv32i/RegFile.scala 24:35]
      if (5'h11 == io_waddr) begin // @[src/main/scala/rv32i/RegFile.scala 25:20]
        regs_17 <= io_wdata; // @[src/main/scala/rv32i/RegFile.scala 25:20]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegFile.scala 19:21]
      regs_18 <= 32'h0; // @[src/main/scala/rv32i/RegFile.scala 19:21]
    end else if (io_we & io_waddr != 5'h0) begin // @[src/main/scala/rv32i/RegFile.scala 24:35]
      if (5'h12 == io_waddr) begin // @[src/main/scala/rv32i/RegFile.scala 25:20]
        regs_18 <= io_wdata; // @[src/main/scala/rv32i/RegFile.scala 25:20]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegFile.scala 19:21]
      regs_19 <= 32'h0; // @[src/main/scala/rv32i/RegFile.scala 19:21]
    end else if (io_we & io_waddr != 5'h0) begin // @[src/main/scala/rv32i/RegFile.scala 24:35]
      if (5'h13 == io_waddr) begin // @[src/main/scala/rv32i/RegFile.scala 25:20]
        regs_19 <= io_wdata; // @[src/main/scala/rv32i/RegFile.scala 25:20]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegFile.scala 19:21]
      regs_20 <= 32'h0; // @[src/main/scala/rv32i/RegFile.scala 19:21]
    end else if (io_we & io_waddr != 5'h0) begin // @[src/main/scala/rv32i/RegFile.scala 24:35]
      if (5'h14 == io_waddr) begin // @[src/main/scala/rv32i/RegFile.scala 25:20]
        regs_20 <= io_wdata; // @[src/main/scala/rv32i/RegFile.scala 25:20]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegFile.scala 19:21]
      regs_21 <= 32'h0; // @[src/main/scala/rv32i/RegFile.scala 19:21]
    end else if (io_we & io_waddr != 5'h0) begin // @[src/main/scala/rv32i/RegFile.scala 24:35]
      if (5'h15 == io_waddr) begin // @[src/main/scala/rv32i/RegFile.scala 25:20]
        regs_21 <= io_wdata; // @[src/main/scala/rv32i/RegFile.scala 25:20]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegFile.scala 19:21]
      regs_22 <= 32'h0; // @[src/main/scala/rv32i/RegFile.scala 19:21]
    end else if (io_we & io_waddr != 5'h0) begin // @[src/main/scala/rv32i/RegFile.scala 24:35]
      if (5'h16 == io_waddr) begin // @[src/main/scala/rv32i/RegFile.scala 25:20]
        regs_22 <= io_wdata; // @[src/main/scala/rv32i/RegFile.scala 25:20]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegFile.scala 19:21]
      regs_23 <= 32'h0; // @[src/main/scala/rv32i/RegFile.scala 19:21]
    end else if (io_we & io_waddr != 5'h0) begin // @[src/main/scala/rv32i/RegFile.scala 24:35]
      if (5'h17 == io_waddr) begin // @[src/main/scala/rv32i/RegFile.scala 25:20]
        regs_23 <= io_wdata; // @[src/main/scala/rv32i/RegFile.scala 25:20]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegFile.scala 19:21]
      regs_24 <= 32'h0; // @[src/main/scala/rv32i/RegFile.scala 19:21]
    end else if (io_we & io_waddr != 5'h0) begin // @[src/main/scala/rv32i/RegFile.scala 24:35]
      if (5'h18 == io_waddr) begin // @[src/main/scala/rv32i/RegFile.scala 25:20]
        regs_24 <= io_wdata; // @[src/main/scala/rv32i/RegFile.scala 25:20]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegFile.scala 19:21]
      regs_25 <= 32'h0; // @[src/main/scala/rv32i/RegFile.scala 19:21]
    end else if (io_we & io_waddr != 5'h0) begin // @[src/main/scala/rv32i/RegFile.scala 24:35]
      if (5'h19 == io_waddr) begin // @[src/main/scala/rv32i/RegFile.scala 25:20]
        regs_25 <= io_wdata; // @[src/main/scala/rv32i/RegFile.scala 25:20]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegFile.scala 19:21]
      regs_26 <= 32'h0; // @[src/main/scala/rv32i/RegFile.scala 19:21]
    end else if (io_we & io_waddr != 5'h0) begin // @[src/main/scala/rv32i/RegFile.scala 24:35]
      if (5'h1a == io_waddr) begin // @[src/main/scala/rv32i/RegFile.scala 25:20]
        regs_26 <= io_wdata; // @[src/main/scala/rv32i/RegFile.scala 25:20]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegFile.scala 19:21]
      regs_27 <= 32'h0; // @[src/main/scala/rv32i/RegFile.scala 19:21]
    end else if (io_we & io_waddr != 5'h0) begin // @[src/main/scala/rv32i/RegFile.scala 24:35]
      if (5'h1b == io_waddr) begin // @[src/main/scala/rv32i/RegFile.scala 25:20]
        regs_27 <= io_wdata; // @[src/main/scala/rv32i/RegFile.scala 25:20]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegFile.scala 19:21]
      regs_28 <= 32'h0; // @[src/main/scala/rv32i/RegFile.scala 19:21]
    end else if (io_we & io_waddr != 5'h0) begin // @[src/main/scala/rv32i/RegFile.scala 24:35]
      if (5'h1c == io_waddr) begin // @[src/main/scala/rv32i/RegFile.scala 25:20]
        regs_28 <= io_wdata; // @[src/main/scala/rv32i/RegFile.scala 25:20]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegFile.scala 19:21]
      regs_29 <= 32'h0; // @[src/main/scala/rv32i/RegFile.scala 19:21]
    end else if (io_we & io_waddr != 5'h0) begin // @[src/main/scala/rv32i/RegFile.scala 24:35]
      if (5'h1d == io_waddr) begin // @[src/main/scala/rv32i/RegFile.scala 25:20]
        regs_29 <= io_wdata; // @[src/main/scala/rv32i/RegFile.scala 25:20]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegFile.scala 19:21]
      regs_30 <= 32'h0; // @[src/main/scala/rv32i/RegFile.scala 19:21]
    end else if (io_we & io_waddr != 5'h0) begin // @[src/main/scala/rv32i/RegFile.scala 24:35]
      if (5'h1e == io_waddr) begin // @[src/main/scala/rv32i/RegFile.scala 25:20]
        regs_30 <= io_wdata; // @[src/main/scala/rv32i/RegFile.scala 25:20]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegFile.scala 19:21]
      regs_31 <= 32'h0; // @[src/main/scala/rv32i/RegFile.scala 19:21]
    end else if (io_we & io_waddr != 5'h0) begin // @[src/main/scala/rv32i/RegFile.scala 24:35]
      if (5'h1f == io_waddr) begin // @[src/main/scala/rv32i/RegFile.scala 25:20]
        regs_31 <= io_wdata; // @[src/main/scala/rv32i/RegFile.scala 25:20]
      end
    end
  end
// Register and memory initialization
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif
`ifndef RANDOM
`define RANDOM $random
`endif
`ifdef RANDOMIZE_MEM_INIT
  integer initvar;
`endif
`ifndef SYNTHESIS
`ifdef FIRRTL_BEFORE_INITIAL
`FIRRTL_BEFORE_INITIAL
`endif
initial begin
  `ifdef RANDOMIZE
    `ifdef INIT_RANDOM
      `INIT_RANDOM
    `endif
    `ifndef VERILATOR
      `ifdef RANDOMIZE_DELAY
        #`RANDOMIZE_DELAY begin end
      `else
        #0.002 begin end
      `endif
    `endif
`ifdef RANDOMIZE_REG_INIT
  _RAND_0 = {1{`RANDOM}};
  regs_0 = _RAND_0[31:0];
  _RAND_1 = {1{`RANDOM}};
  regs_1 = _RAND_1[31:0];
  _RAND_2 = {1{`RANDOM}};
  regs_2 = _RAND_2[31:0];
  _RAND_3 = {1{`RANDOM}};
  regs_3 = _RAND_3[31:0];
  _RAND_4 = {1{`RANDOM}};
  regs_4 = _RAND_4[31:0];
  _RAND_5 = {1{`RANDOM}};
  regs_5 = _RAND_5[31:0];
  _RAND_6 = {1{`RANDOM}};
  regs_6 = _RAND_6[31:0];
  _RAND_7 = {1{`RANDOM}};
  regs_7 = _RAND_7[31:0];
  _RAND_8 = {1{`RANDOM}};
  regs_8 = _RAND_8[31:0];
  _RAND_9 = {1{`RANDOM}};
  regs_9 = _RAND_9[31:0];
  _RAND_10 = {1{`RANDOM}};
  regs_10 = _RAND_10[31:0];
  _RAND_11 = {1{`RANDOM}};
  regs_11 = _RAND_11[31:0];
  _RAND_12 = {1{`RANDOM}};
  regs_12 = _RAND_12[31:0];
  _RAND_13 = {1{`RANDOM}};
  regs_13 = _RAND_13[31:0];
  _RAND_14 = {1{`RANDOM}};
  regs_14 = _RAND_14[31:0];
  _RAND_15 = {1{`RANDOM}};
  regs_15 = _RAND_15[31:0];
  _RAND_16 = {1{`RANDOM}};
  regs_16 = _RAND_16[31:0];
  _RAND_17 = {1{`RANDOM}};
  regs_17 = _RAND_17[31:0];
  _RAND_18 = {1{`RANDOM}};
  regs_18 = _RAND_18[31:0];
  _RAND_19 = {1{`RANDOM}};
  regs_19 = _RAND_19[31:0];
  _RAND_20 = {1{`RANDOM}};
  regs_20 = _RAND_20[31:0];
  _RAND_21 = {1{`RANDOM}};
  regs_21 = _RAND_21[31:0];
  _RAND_22 = {1{`RANDOM}};
  regs_22 = _RAND_22[31:0];
  _RAND_23 = {1{`RANDOM}};
  regs_23 = _RAND_23[31:0];
  _RAND_24 = {1{`RANDOM}};
  regs_24 = _RAND_24[31:0];
  _RAND_25 = {1{`RANDOM}};
  regs_25 = _RAND_25[31:0];
  _RAND_26 = {1{`RANDOM}};
  regs_26 = _RAND_26[31:0];
  _RAND_27 = {1{`RANDOM}};
  regs_27 = _RAND_27[31:0];
  _RAND_28 = {1{`RANDOM}};
  regs_28 = _RAND_28[31:0];
  _RAND_29 = {1{`RANDOM}};
  regs_29 = _RAND_29[31:0];
  _RAND_30 = {1{`RANDOM}};
  regs_30 = _RAND_30[31:0];
  _RAND_31 = {1{`RANDOM}};
  regs_31 = _RAND_31[31:0];
`endif // RANDOMIZE_REG_INIT
  `endif // RANDOMIZE
end // initial
`ifdef FIRRTL_AFTER_INITIAL
`FIRRTL_AFTER_INITIAL
`endif
`endif // SYNTHESIS
endmodule
module Alu(
  input  [3:0]  io_op, // @[src/main/scala/rv32i/Alu.scala 8:14]
  input  [31:0] io_a, // @[src/main/scala/rv32i/Alu.scala 8:14]
  input  [31:0] io_b, // @[src/main/scala/rv32i/Alu.scala 8:14]
  output [31:0] io_y // @[src/main/scala/rv32i/Alu.scala 8:14]
);
  wire [4:0] sh = io_b[4:0]; // @[src/main/scala/rv32i/Alu.scala 15:16]
  wire [31:0] _io_y_T_1 = io_a + io_b; // @[src/main/scala/rv32i/Alu.scala 16:16]
  wire [31:0] _io_y_T_5 = io_a - io_b; // @[src/main/scala/rv32i/Alu.scala 19:35]
  wire [62:0] _GEN_9 = {{31'd0}, io_a}; // @[src/main/scala/rv32i/Alu.scala 20:36]
  wire [62:0] _io_y_T_6 = _GEN_9 << sh; // @[src/main/scala/rv32i/Alu.scala 20:36]
  wire [31:0] _io_y_T_8 = io_a; // @[src/main/scala/rv32i/Alu.scala 21:36]
  wire [31:0] _io_y_T_9 = io_b; // @[src/main/scala/rv32i/Alu.scala 21:50]
  wire [31:0] _io_y_T_12 = io_a ^ io_b; // @[src/main/scala/rv32i/Alu.scala 23:35]
  wire [31:0] _io_y_T_13 = io_a >> sh; // @[src/main/scala/rv32i/Alu.scala 24:35]
  wire [31:0] _io_y_T_16 = $signed(io_a) >>> sh; // @[src/main/scala/rv32i/Alu.scala 25:50]
  wire [31:0] _io_y_T_17 = io_a | io_b; // @[src/main/scala/rv32i/Alu.scala 26:35]
  wire [31:0] _io_y_T_18 = io_a & io_b; // @[src/main/scala/rv32i/Alu.scala 27:35]
  wire [31:0] _GEN_0 = 4'h9 == io_op ? _io_y_T_18 : _io_y_T_1; // @[src/main/scala/rv32i/Alu.scala 17:17 27:27 16:8]
  wire [31:0] _GEN_1 = 4'h8 == io_op ? _io_y_T_17 : _GEN_0; // @[src/main/scala/rv32i/Alu.scala 17:17 26:27]
  wire [31:0] _GEN_2 = 4'h7 == io_op ? _io_y_T_16 : _GEN_1; // @[src/main/scala/rv32i/Alu.scala 17:17 25:27]
  wire [31:0] _GEN_3 = 4'h6 == io_op ? _io_y_T_13 : _GEN_2; // @[src/main/scala/rv32i/Alu.scala 17:17 24:27]
  wire [31:0] _GEN_4 = 4'h5 == io_op ? _io_y_T_12 : _GEN_3; // @[src/main/scala/rv32i/Alu.scala 17:17 23:27]
  wire [31:0] _GEN_5 = 4'h4 == io_op ? {{31'd0}, io_a < io_b} : _GEN_4; // @[src/main/scala/rv32i/Alu.scala 17:17 22:27]
  wire [31:0] _GEN_6 = 4'h3 == io_op ? {{31'd0}, $signed(_io_y_T_8) < $signed(_io_y_T_9)} : _GEN_5; // @[src/main/scala/rv32i/Alu.scala 17:17 21:27]
  wire [31:0] _GEN_7 = 4'h2 == io_op ? _io_y_T_6[31:0] : _GEN_6; // @[src/main/scala/rv32i/Alu.scala 17:17 20:27]
  wire [31:0] _GEN_8 = 4'h1 == io_op ? _io_y_T_5 : _GEN_7; // @[src/main/scala/rv32i/Alu.scala 17:17 19:27]
  assign io_y = 4'h0 == io_op ? _io_y_T_1 : _GEN_8; // @[src/main/scala/rv32i/Alu.scala 17:17 18:27]
endmodule
module CsrFile(
  input         clock,
  input         reset,
  input  [11:0] io_addr, // @[src/main/scala/rv32i/CsrFile.scala 22:14]
  input         io_en, // @[src/main/scala/rv32i/CsrFile.scala 22:14]
  input  [1:0]  io_op, // @[src/main/scala/rv32i/CsrFile.scala 22:14]
  input  [31:0] io_src, // @[src/main/scala/rv32i/CsrFile.scala 22:14]
  input         io_wrEn, // @[src/main/scala/rv32i/CsrFile.scala 22:14]
  output [31:0] io_rdata, // @[src/main/scala/rv32i/CsrFile.scala 22:14]
  output        io_illegal, // @[src/main/scala/rv32i/CsrFile.scala 22:14]
  input         io_commit, // @[src/main/scala/rv32i/CsrFile.scala 22:14]
  input         io_trapEnter, // @[src/main/scala/rv32i/CsrFile.scala 22:14]
  input  [31:0] io_trapCause, // @[src/main/scala/rv32i/CsrFile.scala 22:14]
  input  [31:0] io_trapPc, // @[src/main/scala/rv32i/CsrFile.scala 22:14]
  input  [31:0] io_trapVal, // @[src/main/scala/rv32i/CsrFile.scala 22:14]
  input         io_mretEnter, // @[src/main/scala/rv32i/CsrFile.scala 22:14]
  output [31:0] io_mtvecBase, // @[src/main/scala/rv32i/CsrFile.scala 22:14]
  output [31:0] io_mepc // @[src/main/scala/rv32i/CsrFile.scala 22:14]
);
`ifdef RANDOMIZE_REG_INIT
  reg [31:0] _RAND_0;
  reg [31:0] _RAND_1;
  reg [31:0] _RAND_2;
  reg [31:0] _RAND_3;
  reg [31:0] _RAND_4;
  reg [31:0] _RAND_5;
  reg [31:0] _RAND_6;
  reg [31:0] _RAND_7;
  reg [63:0] _RAND_8;
  reg [63:0] _RAND_9;
`endif // RANDOMIZE_REG_INIT
  reg  mie_; // @[src/main/scala/rv32i/CsrFile.scala 40:25]
  reg  mpie; // @[src/main/scala/rv32i/CsrFile.scala 41:25]
  reg [31:0] mieReg; // @[src/main/scala/rv32i/CsrFile.scala 42:25]
  reg [31:0] mtvec; // @[src/main/scala/rv32i/CsrFile.scala 43:25]
  reg [31:0] mscratch; // @[src/main/scala/rv32i/CsrFile.scala 44:25]
  reg [31:0] mepc; // @[src/main/scala/rv32i/CsrFile.scala 45:25]
  reg [31:0] mcause; // @[src/main/scala/rv32i/CsrFile.scala 46:25]
  reg [31:0] mtval; // @[src/main/scala/rv32i/CsrFile.scala 47:25]
  reg [63:0] mcycle; // @[src/main/scala/rv32i/CsrFile.scala 48:25]
  reg [63:0] minstret; // @[src/main/scala/rv32i/CsrFile.scala 49:25]
  wire [31:0] mstatus = {21'h3,3'h0,mpie,3'h0,mie_,3'h0}; // @[src/main/scala/rv32i/CsrFile.scala 51:20]
  wire  hit_0 = io_addr == 12'h300; // @[src/main/scala/rv32i/CsrFile.scala 79:53]
  wire  hit_1 = io_addr == 12'h301; // @[src/main/scala/rv32i/CsrFile.scala 79:53]
  wire  hit_2 = io_addr == 12'h304; // @[src/main/scala/rv32i/CsrFile.scala 79:53]
  wire  hit_3 = io_addr == 12'h305; // @[src/main/scala/rv32i/CsrFile.scala 79:53]
  wire  hit_4 = io_addr == 12'h310; // @[src/main/scala/rv32i/CsrFile.scala 79:53]
  wire  hit_5 = io_addr == 12'h340; // @[src/main/scala/rv32i/CsrFile.scala 79:53]
  wire  hit_6 = io_addr == 12'h341; // @[src/main/scala/rv32i/CsrFile.scala 79:53]
  wire  hit_7 = io_addr == 12'h342; // @[src/main/scala/rv32i/CsrFile.scala 79:53]
  wire  hit_8 = io_addr == 12'h343; // @[src/main/scala/rv32i/CsrFile.scala 79:53]
  wire  hit_9 = io_addr == 12'h344; // @[src/main/scala/rv32i/CsrFile.scala 79:53]
  wire  hit_10 = io_addr == 12'hb00; // @[src/main/scala/rv32i/CsrFile.scala 79:53]
  wire  hit_11 = io_addr == 12'hb80; // @[src/main/scala/rv32i/CsrFile.scala 79:53]
  wire  hit_12 = io_addr == 12'hb02; // @[src/main/scala/rv32i/CsrFile.scala 79:53]
  wire  hit_13 = io_addr == 12'hb82; // @[src/main/scala/rv32i/CsrFile.scala 79:53]
  wire  hit_14 = io_addr == 12'hc00; // @[src/main/scala/rv32i/CsrFile.scala 79:53]
  wire  hit_15 = io_addr == 12'hc80; // @[src/main/scala/rv32i/CsrFile.scala 79:53]
  wire  hit_16 = io_addr == 12'hc02; // @[src/main/scala/rv32i/CsrFile.scala 79:53]
  wire  hit_17 = io_addr == 12'hc82; // @[src/main/scala/rv32i/CsrFile.scala 79:53]
  wire  hit_18 = io_addr == 12'hf11; // @[src/main/scala/rv32i/CsrFile.scala 79:53]
  wire  hit_19 = io_addr == 12'hf12; // @[src/main/scala/rv32i/CsrFile.scala 79:53]
  wire  hit_20 = io_addr == 12'hf13; // @[src/main/scala/rv32i/CsrFile.scala 79:53]
  wire  hit_21 = io_addr == 12'hf14; // @[src/main/scala/rv32i/CsrFile.scala 79:53]
  wire  known = hit_0 | hit_1 | hit_2 | hit_3 | hit_4 | hit_5 | hit_6 | hit_7 | hit_8 | hit_9 | hit_10 | hit_11 | hit_12
     | hit_13 | hit_14 | hit_15 | hit_16 | hit_17 | hit_18 | hit_19 | hit_20 | hit_21; // @[src/main/scala/rv32i/CsrFile.scala 80:31]
  wire [31:0] _old_T = hit_0 ? mstatus : 32'h0; // @[src/main/scala/chisel3/util/Mux.scala 30:73]
  wire [31:0] _old_T_1 = hit_1 ? 32'h40001100 : 32'h0; // @[src/main/scala/chisel3/util/Mux.scala 30:73]
  wire [31:0] _old_T_2 = hit_2 ? mieReg : 32'h0; // @[src/main/scala/chisel3/util/Mux.scala 30:73]
  wire [31:0] _old_T_3 = hit_3 ? mtvec : 32'h0; // @[src/main/scala/chisel3/util/Mux.scala 30:73]
  wire [31:0] _old_T_5 = hit_5 ? mscratch : 32'h0; // @[src/main/scala/chisel3/util/Mux.scala 30:73]
  wire [31:0] _old_T_6 = hit_6 ? mepc : 32'h0; // @[src/main/scala/chisel3/util/Mux.scala 30:73]
  wire [31:0] _old_T_7 = hit_7 ? mcause : 32'h0; // @[src/main/scala/chisel3/util/Mux.scala 30:73]
  wire [31:0] _old_T_8 = hit_8 ? mtval : 32'h0; // @[src/main/scala/chisel3/util/Mux.scala 30:73]
  wire [31:0] _old_T_10 = hit_10 ? mcycle[31:0] : 32'h0; // @[src/main/scala/chisel3/util/Mux.scala 30:73]
  wire [31:0] _old_T_11 = hit_11 ? mcycle[63:32] : 32'h0; // @[src/main/scala/chisel3/util/Mux.scala 30:73]
  wire [31:0] _old_T_12 = hit_12 ? minstret[31:0] : 32'h0; // @[src/main/scala/chisel3/util/Mux.scala 30:73]
  wire [31:0] _old_T_13 = hit_13 ? minstret[63:32] : 32'h0; // @[src/main/scala/chisel3/util/Mux.scala 30:73]
  wire [31:0] _old_T_14 = hit_14 ? mcycle[31:0] : 32'h0; // @[src/main/scala/chisel3/util/Mux.scala 30:73]
  wire [31:0] _old_T_15 = hit_15 ? mcycle[63:32] : 32'h0; // @[src/main/scala/chisel3/util/Mux.scala 30:73]
  wire [31:0] _old_T_16 = hit_16 ? minstret[31:0] : 32'h0; // @[src/main/scala/chisel3/util/Mux.scala 30:73]
  wire [31:0] _old_T_17 = hit_17 ? minstret[63:32] : 32'h0; // @[src/main/scala/chisel3/util/Mux.scala 30:73]
  wire [31:0] _old_T_22 = _old_T | _old_T_1; // @[src/main/scala/chisel3/util/Mux.scala 30:73]
  wire [31:0] _old_T_23 = _old_T_22 | _old_T_2; // @[src/main/scala/chisel3/util/Mux.scala 30:73]
  wire [31:0] _old_T_24 = _old_T_23 | _old_T_3; // @[src/main/scala/chisel3/util/Mux.scala 30:73]
  wire [31:0] _old_T_26 = _old_T_24 | _old_T_5; // @[src/main/scala/chisel3/util/Mux.scala 30:73]
  wire [31:0] _old_T_27 = _old_T_26 | _old_T_6; // @[src/main/scala/chisel3/util/Mux.scala 30:73]
  wire [31:0] _old_T_28 = _old_T_27 | _old_T_7; // @[src/main/scala/chisel3/util/Mux.scala 30:73]
  wire [31:0] _old_T_29 = _old_T_28 | _old_T_8; // @[src/main/scala/chisel3/util/Mux.scala 30:73]
  wire [31:0] _old_T_31 = _old_T_29 | _old_T_10; // @[src/main/scala/chisel3/util/Mux.scala 30:73]
  wire [31:0] _old_T_32 = _old_T_31 | _old_T_11; // @[src/main/scala/chisel3/util/Mux.scala 30:73]
  wire [31:0] _old_T_33 = _old_T_32 | _old_T_12; // @[src/main/scala/chisel3/util/Mux.scala 30:73]
  wire [31:0] _old_T_34 = _old_T_33 | _old_T_13; // @[src/main/scala/chisel3/util/Mux.scala 30:73]
  wire [31:0] _old_T_35 = _old_T_34 | _old_T_14; // @[src/main/scala/chisel3/util/Mux.scala 30:73]
  wire [31:0] _old_T_36 = _old_T_35 | _old_T_15; // @[src/main/scala/chisel3/util/Mux.scala 30:73]
  wire [31:0] _old_T_37 = _old_T_36 | _old_T_16; // @[src/main/scala/chisel3/util/Mux.scala 30:73]
  wire [31:0] old = _old_T_37 | _old_T_17; // @[src/main/scala/chisel3/util/Mux.scala 30:73]
  wire  readOnly = io_addr[11:10] == 2'h3; // @[src/main/scala/rv32i/CsrFile.scala 82:34]
  wire [31:0] _wval_T = old | io_src; // @[src/main/scala/rv32i/CsrFile.scala 88:17]
  wire [31:0] _wval_T_1 = ~io_src; // @[src/main/scala/rv32i/CsrFile.scala 89:19]
  wire [31:0] _wval_T_2 = old & _wval_T_1; // @[src/main/scala/rv32i/CsrFile.scala 89:17]
  wire [31:0] _wval_T_6 = 2'h2 == io_op ? _wval_T : io_src; // @[src/main/scala/rv32i/CsrFile.scala 86:38]
  wire [31:0] wval = 2'h3 == io_op ? _wval_T_2 : _wval_T_6; // @[src/main/scala/rv32i/CsrFile.scala 86:38]
  wire  doWrite = io_en & io_wrEn & io_commit & ~io_illegal; // @[src/main/scala/rv32i/CsrFile.scala 91:47]
  wire [63:0] cycleInc = mcycle + 64'h1; // @[src/main/scala/rv32i/CsrFile.scala 95:27]
  wire [63:0] _GEN_15 = {{63'd0}, io_commit}; // @[src/main/scala/rv32i/CsrFile.scala 96:29]
  wire [63:0] instretInc = minstret + _GEN_15; // @[src/main/scala/rv32i/CsrFile.scala 96:29]
  wire  _mcycle_T_1 = doWrite & hit_10; // @[src/main/scala/rv32i/CsrFile.scala 92:34]
  wire [63:0] _mcycle_T_3 = {cycleInc[63:32],wval}; // @[src/main/scala/rv32i/CsrFile.scala 98:24]
  wire  _mcycle_T_5 = doWrite & hit_11; // @[src/main/scala/rv32i/CsrFile.scala 92:34]
  wire [63:0] _mcycle_T_7 = {wval,cycleInc[31:0]}; // @[src/main/scala/rv32i/CsrFile.scala 99:32]
  wire  _minstret_T_1 = doWrite & hit_12; // @[src/main/scala/rv32i/CsrFile.scala 92:34]
  wire [63:0] _minstret_T_3 = {instretInc[63:32],wval}; // @[src/main/scala/rv32i/CsrFile.scala 102:26]
  wire  _minstret_T_5 = doWrite & hit_13; // @[src/main/scala/rv32i/CsrFile.scala 92:34]
  wire [63:0] _minstret_T_7 = {wval,instretInc[31:0]}; // @[src/main/scala/rv32i/CsrFile.scala 103:34]
  wire  _T_9 = doWrite & hit_0; // @[src/main/scala/rv32i/CsrFile.scala 92:34]
  wire  _GEN_1 = _T_9 ? wval[7] : mpie; // @[src/main/scala/rv32i/CsrFile.scala 107:{23,47} 41:25]
  wire  _T_11 = doWrite & hit_2; // @[src/main/scala/rv32i/CsrFile.scala 92:34]
  wire [31:0] _mieReg_T = wval & 32'h888; // @[src/main/scala/rv32i/CsrFile.scala 108:40]
  wire  _T_13 = doWrite & hit_3; // @[src/main/scala/rv32i/CsrFile.scala 92:34]
  wire [31:0] _mtvec_T_1 = {wval[31:2],2'h0}; // @[src/main/scala/rv32i/CsrFile.scala 109:37]
  wire  _T_15 = doWrite & hit_5; // @[src/main/scala/rv32i/CsrFile.scala 92:34]
  wire  _T_17 = doWrite & hit_6; // @[src/main/scala/rv32i/CsrFile.scala 92:34]
  wire  _T_19 = doWrite & hit_7; // @[src/main/scala/rv32i/CsrFile.scala 92:34]
  wire  _T_21 = doWrite & hit_8; // @[src/main/scala/rv32i/CsrFile.scala 92:34]
  wire  _GEN_9 = io_mretEnter | _GEN_1; // @[src/main/scala/rv32i/CsrFile.scala 123:28 125:10]
  assign io_rdata = known ? old : 32'h0; // @[src/main/scala/rv32i/CsrFile.scala 83:20]
  assign io_illegal = io_en & (~known | readOnly & io_wrEn); // @[src/main/scala/rv32i/CsrFile.scala 84:23]
  assign io_mtvecBase = mtvec; // @[src/main/scala/rv32i/CsrFile.scala 128:16]
  assign io_mepc = mepc; // @[src/main/scala/rv32i/CsrFile.scala 129:16]
  always @(posedge clock) begin
    if (reset) begin // @[src/main/scala/rv32i/CsrFile.scala 40:25]
      mie_ <= 1'h0; // @[src/main/scala/rv32i/CsrFile.scala 40:25]
    end else if (io_trapEnter) begin // @[src/main/scala/rv32i/CsrFile.scala 117:22]
      mie_ <= 1'h0; // @[src/main/scala/rv32i/CsrFile.scala 122:12]
    end else if (io_mretEnter) begin // @[src/main/scala/rv32i/CsrFile.scala 123:28]
      mie_ <= mpie; // @[src/main/scala/rv32i/CsrFile.scala 124:10]
    end else if (_T_9) begin // @[src/main/scala/rv32i/CsrFile.scala 107:23]
      mie_ <= wval[3]; // @[src/main/scala/rv32i/CsrFile.scala 107:30]
    end
    if (reset) begin // @[src/main/scala/rv32i/CsrFile.scala 41:25]
      mpie <= 1'h0; // @[src/main/scala/rv32i/CsrFile.scala 41:25]
    end else if (io_trapEnter) begin // @[src/main/scala/rv32i/CsrFile.scala 117:22]
      mpie <= mie_; // @[src/main/scala/rv32i/CsrFile.scala 121:12]
    end else begin
      mpie <= _GEN_9;
    end
    if (reset) begin // @[src/main/scala/rv32i/CsrFile.scala 42:25]
      mieReg <= 32'h0; // @[src/main/scala/rv32i/CsrFile.scala 42:25]
    end else if (_T_11) begin // @[src/main/scala/rv32i/CsrFile.scala 108:23]
      mieReg <= _mieReg_T; // @[src/main/scala/rv32i/CsrFile.scala 108:32]
    end
    if (reset) begin // @[src/main/scala/rv32i/CsrFile.scala 43:25]
      mtvec <= 32'h0; // @[src/main/scala/rv32i/CsrFile.scala 43:25]
    end else if (_T_13) begin // @[src/main/scala/rv32i/CsrFile.scala 109:23]
      mtvec <= _mtvec_T_1; // @[src/main/scala/rv32i/CsrFile.scala 109:31]
    end
    if (reset) begin // @[src/main/scala/rv32i/CsrFile.scala 44:25]
      mscratch <= 32'h0; // @[src/main/scala/rv32i/CsrFile.scala 44:25]
    end else if (_T_15) begin // @[src/main/scala/rv32i/CsrFile.scala 110:24]
      if (2'h3 == io_op) begin // @[src/main/scala/rv32i/CsrFile.scala 86:38]
        mscratch <= _wval_T_2;
      end else if (2'h2 == io_op) begin // @[src/main/scala/rv32i/CsrFile.scala 86:38]
        mscratch <= _wval_T;
      end else begin
        mscratch <= io_src;
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/CsrFile.scala 45:25]
      mepc <= 32'h0; // @[src/main/scala/rv32i/CsrFile.scala 45:25]
    end else if (io_trapEnter) begin // @[src/main/scala/rv32i/CsrFile.scala 117:22]
      mepc <= io_trapPc; // @[src/main/scala/rv32i/CsrFile.scala 118:12]
    end else if (_T_17) begin // @[src/main/scala/rv32i/CsrFile.scala 111:23]
      mepc <= _mtvec_T_1; // @[src/main/scala/rv32i/CsrFile.scala 111:30]
    end
    if (reset) begin // @[src/main/scala/rv32i/CsrFile.scala 46:25]
      mcause <= 32'h0; // @[src/main/scala/rv32i/CsrFile.scala 46:25]
    end else if (io_trapEnter) begin // @[src/main/scala/rv32i/CsrFile.scala 117:22]
      mcause <= io_trapCause; // @[src/main/scala/rv32i/CsrFile.scala 119:12]
    end else if (_T_19) begin // @[src/main/scala/rv32i/CsrFile.scala 112:23]
      if (2'h3 == io_op) begin // @[src/main/scala/rv32i/CsrFile.scala 86:38]
        mcause <= _wval_T_2;
      end else begin
        mcause <= _wval_T_6;
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/CsrFile.scala 47:25]
      mtval <= 32'h0; // @[src/main/scala/rv32i/CsrFile.scala 47:25]
    end else if (io_trapEnter) begin // @[src/main/scala/rv32i/CsrFile.scala 117:22]
      mtval <= io_trapVal; // @[src/main/scala/rv32i/CsrFile.scala 120:12]
    end else if (_T_21) begin // @[src/main/scala/rv32i/CsrFile.scala 113:23]
      if (2'h3 == io_op) begin // @[src/main/scala/rv32i/CsrFile.scala 86:38]
        mtval <= _wval_T_2;
      end else begin
        mtval <= _wval_T_6;
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/CsrFile.scala 48:25]
      mcycle <= 64'h0; // @[src/main/scala/rv32i/CsrFile.scala 48:25]
    end else if (_mcycle_T_1) begin // @[src/main/scala/chisel3/util/Mux.scala 141:16]
      mcycle <= _mcycle_T_3;
    end else if (_mcycle_T_5) begin // @[src/main/scala/chisel3/util/Mux.scala 141:16]
      mcycle <= _mcycle_T_7;
    end else begin
      mcycle <= cycleInc;
    end
    if (reset) begin // @[src/main/scala/rv32i/CsrFile.scala 49:25]
      minstret <= 64'h0; // @[src/main/scala/rv32i/CsrFile.scala 49:25]
    end else if (_minstret_T_1) begin // @[src/main/scala/chisel3/util/Mux.scala 141:16]
      minstret <= _minstret_T_3;
    end else if (_minstret_T_5) begin // @[src/main/scala/chisel3/util/Mux.scala 141:16]
      minstret <= _minstret_T_7;
    end else begin
      minstret <= instretInc;
    end
  end
// Register and memory initialization
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif
`ifndef RANDOM
`define RANDOM $random
`endif
`ifdef RANDOMIZE_MEM_INIT
  integer initvar;
`endif
`ifndef SYNTHESIS
`ifdef FIRRTL_BEFORE_INITIAL
`FIRRTL_BEFORE_INITIAL
`endif
initial begin
  `ifdef RANDOMIZE
    `ifdef INIT_RANDOM
      `INIT_RANDOM
    `endif
    `ifndef VERILATOR
      `ifdef RANDOMIZE_DELAY
        #`RANDOMIZE_DELAY begin end
      `else
        #0.002 begin end
      `endif
    `endif
`ifdef RANDOMIZE_REG_INIT
  _RAND_0 = {1{`RANDOM}};
  mie_ = _RAND_0[0:0];
  _RAND_1 = {1{`RANDOM}};
  mpie = _RAND_1[0:0];
  _RAND_2 = {1{`RANDOM}};
  mieReg = _RAND_2[31:0];
  _RAND_3 = {1{`RANDOM}};
  mtvec = _RAND_3[31:0];
  _RAND_4 = {1{`RANDOM}};
  mscratch = _RAND_4[31:0];
  _RAND_5 = {1{`RANDOM}};
  mepc = _RAND_5[31:0];
  _RAND_6 = {1{`RANDOM}};
  mcause = _RAND_6[31:0];
  _RAND_7 = {1{`RANDOM}};
  mtval = _RAND_7[31:0];
  _RAND_8 = {2{`RANDOM}};
  mcycle = _RAND_8[63:0];
  _RAND_9 = {2{`RANDOM}};
  minstret = _RAND_9[63:0];
`endif // RANDOMIZE_REG_INIT
  `endif // RANDOMIZE
end // initial
`ifdef FIRRTL_AFTER_INITIAL
`FIRRTL_AFTER_INITIAL
`endif
`endif // SYNTHESIS
endmodule
module Multiplier(
  input  [1:0]  io_fn, // @[src/main/scala/rv32i/Multiplier.scala 17:14]
  input  [31:0] io_a, // @[src/main/scala/rv32i/Multiplier.scala 17:14]
  input  [31:0] io_b, // @[src/main/scala/rv32i/Multiplier.scala 17:14]
  output [31:0] io_result // @[src/main/scala/rv32i/Multiplier.scala 17:14]
);
  wire  _aSigned_T = io_fn == 2'h1; // @[src/main/scala/rv32i/Multiplier.scala 24:23]
  wire  aSigned = io_fn == 2'h1 | io_fn == 2'h2; // @[src/main/scala/rv32i/Multiplier.scala 24:31]
  wire  _aExt_T_1 = aSigned & io_a[31]; // @[src/main/scala/rv32i/Multiplier.scala 26:29]
  wire [32:0] aExt = {_aExt_T_1,io_a}; // @[src/main/scala/rv32i/Multiplier.scala 26:48]
  wire  _bExt_T_1 = _aSigned_T & io_b[31]; // @[src/main/scala/rv32i/Multiplier.scala 27:29]
  wire [32:0] bExt = {_bExt_T_1,io_b}; // @[src/main/scala/rv32i/Multiplier.scala 27:48]
  wire [65:0] product = $signed(aExt) * $signed(bExt); // @[src/main/scala/rv32i/Multiplier.scala 28:31]
  assign io_result = io_fn == 2'h0 ? product[31:0] : product[63:32]; // @[src/main/scala/rv32i/Multiplier.scala 30:19]
endmodule
module DivUnit(
  input         clock,
  input         reset,
  output        io_req_ready, // @[src/main/scala/rv32i/DivUnit.scala 37:14]
  input         io_req_valid, // @[src/main/scala/rv32i/DivUnit.scala 37:14]
  input  [1:0]  io_req_bits_op, // @[src/main/scala/rv32i/DivUnit.scala 37:14]
  input  [31:0] io_req_bits_a, // @[src/main/scala/rv32i/DivUnit.scala 37:14]
  input  [31:0] io_req_bits_b, // @[src/main/scala/rv32i/DivUnit.scala 37:14]
  output        io_resp_valid, // @[src/main/scala/rv32i/DivUnit.scala 37:14]
  output [31:0] io_resp_bits, // @[src/main/scala/rv32i/DivUnit.scala 37:14]
  input         io_kill, // @[src/main/scala/rv32i/DivUnit.scala 37:14]
  output        io_busy // @[src/main/scala/rv32i/DivUnit.scala 37:14]
);
`ifdef RANDOMIZE_REG_INIT
  reg [31:0] _RAND_0;
  reg [31:0] _RAND_1;
  reg [31:0] _RAND_2;
  reg [31:0] _RAND_3;
  reg [31:0] _RAND_4;
  reg [31:0] _RAND_5;
  reg [31:0] _RAND_6;
  reg [31:0] _RAND_7;
  reg [31:0] _RAND_8;
`endif // RANDOMIZE_REG_INIT
  reg [1:0] state; // @[src/main/scala/rv32i/DivUnit.scala 45:30]
  reg [31:0] quot; // @[src/main/scala/rv32i/DivUnit.scala 50:28]
  reg [31:0] rem; // @[src/main/scala/rv32i/DivUnit.scala 51:28]
  reg [31:0] divisor; // @[src/main/scala/rv32i/DivUnit.scala 52:28]
  reg [4:0] count; // @[src/main/scala/rv32i/DivUnit.scala 53:28]
  reg  negQ; // @[src/main/scala/rv32i/DivUnit.scala 54:28]
  reg  negR; // @[src/main/scala/rv32i/DivUnit.scala 55:28]
  reg  wantRem; // @[src/main/scala/rv32i/DivUnit.scala 56:28]
  reg [31:0] result; // @[src/main/scala/rv32i/DivUnit.scala 57:28]
  wire  _io_resp_valid_T = state == 2'h2; // @[src/main/scala/rv32i/DivUnit.scala 60:26]
  wire  _T = io_req_ready & io_req_valid; // @[src/main/scala/chisel3/util/Decoupled.scala 57:35]
  wire  signed_ = ~io_req_bits_op[0]; // @[src/main/scala/rv32i/DivUnit.scala 68:18]
  wire  isRem = io_req_bits_op[1]; // @[src/main/scala/rv32i/DivUnit.scala 69:32]
  wire  negA = signed_ & io_req_bits_a[31]; // @[src/main/scala/rv32i/DivUnit.scala 70:25]
  wire  negB = signed_ & io_req_bits_b[31]; // @[src/main/scala/rv32i/DivUnit.scala 71:25]
  wire [31:0] _quot_T_1 = 32'h0 - io_req_bits_a; // @[src/main/scala/rv32i/DivUnit.scala 76:38]
  wire [31:0] _divisor_T_1 = 32'h0 - io_req_bits_b; // @[src/main/scala/rv32i/DivUnit.scala 77:38]
  wire [31:0] _result_T = isRem ? io_req_bits_a : 32'hffffffff; // @[src/main/scala/rv32i/DivUnit.scala 82:20]
  wire [31:0] _result_T_1 = isRem ? 32'h0 : 32'h80000000; // @[src/main/scala/rv32i/DivUnit.scala 85:20]
  wire [31:0] _GEN_0 = signed_ & io_req_bits_a == 32'h80000000 & io_req_bits_b == 32'hffffffff ? _result_T_1 : result; // @[src/main/scala/rv32i/DivUnit.scala 84:57 85:14 57:28]
  wire [1:0] _GEN_1 = signed_ & io_req_bits_a == 32'h80000000 & io_req_bits_b == 32'hffffffff ? 2'h2 : 2'h1; // @[src/main/scala/rv32i/DivUnit.scala 84:57 86:14 88:13]
  wire [31:0] _GEN_2 = io_req_bits_b == 32'h0 ? _result_T : _GEN_0; // @[src/main/scala/rv32i/DivUnit.scala 81:21 82:14]
  wire [1:0] _GEN_3 = io_req_bits_b == 32'h0 ? 2'h2 : _GEN_1; // @[src/main/scala/rv32i/DivUnit.scala 81:21 83:14]
  wire [31:0] _GEN_11 = _T ? _GEN_2 : result; // @[src/main/scala/rv32i/DivUnit.scala 65:21 57:28]
  wire [1:0] _GEN_12 = _T ? _GEN_3 : state; // @[src/main/scala/rv32i/DivUnit.scala 65:21 45:30]
  wire [32:0] shifted = {rem,quot[31]}; // @[src/main/scala/rv32i/DivUnit.scala 94:23]
  wire [32:0] _GEN_22 = {{1'd0}, divisor}; // @[src/main/scala/rv32i/DivUnit.scala 95:28]
  wire  fits = shifted >= _GEN_22; // @[src/main/scala/rv32i/DivUnit.scala 95:28]
  wire [32:0] _nextRem_T_1 = shifted - _GEN_22; // @[src/main/scala/rv32i/DivUnit.scala 96:38]
  wire [32:0] _nextRem_T_2 = fits ? _nextRem_T_1 : shifted; // @[src/main/scala/rv32i/DivUnit.scala 96:23]
  wire [31:0] nextRem = _nextRem_T_2[31:0]; // @[src/main/scala/rv32i/DivUnit.scala 96:57]
  wire [31:0] nextQuot = {quot[30:0],fits}; // @[src/main/scala/rv32i/DivUnit.scala 97:23]
  wire [4:0] _count_T_1 = count + 5'h1; // @[src/main/scala/rv32i/DivUnit.scala 101:20]
  wire [31:0] _q_T_1 = 32'h0 - nextQuot; // @[src/main/scala/rv32i/DivUnit.scala 104:37]
  wire [31:0] _r_T_1 = 32'h0 - nextRem; // @[src/main/scala/rv32i/DivUnit.scala 105:37]
  wire [1:0] _GEN_14 = count == 5'h1f ? 2'h2 : _GEN_12; // @[src/main/scala/rv32i/DivUnit.scala 103:34 107:14]
  assign io_req_ready = state == 2'h0; // @[src/main/scala/rv32i/DivUnit.scala 59:26]
  assign io_resp_valid = state == 2'h2; // @[src/main/scala/rv32i/DivUnit.scala 60:26]
  assign io_resp_bits = result; // @[src/main/scala/rv32i/DivUnit.scala 61:17]
  assign io_busy = state != 2'h0; // @[src/main/scala/rv32i/DivUnit.scala 62:26]
  always @(posedge clock) begin
    if (reset) begin // @[src/main/scala/rv32i/DivUnit.scala 45:30]
      state <= 2'h0; // @[src/main/scala/rv32i/DivUnit.scala 45:30]
    end else if (io_kill) begin // @[src/main/scala/rv32i/DivUnit.scala 115:17]
      state <= 2'h0; // @[src/main/scala/rv32i/DivUnit.scala 116:11]
    end else if (_io_resp_valid_T) begin // @[src/main/scala/rv32i/DivUnit.scala 111:25]
      state <= 2'h0; // @[src/main/scala/rv32i/DivUnit.scala 112:11]
    end else if (state == 2'h1) begin // @[src/main/scala/rv32i/DivUnit.scala 93:25]
      state <= _GEN_14;
    end else begin
      state <= _GEN_12;
    end
    if (state == 2'h1) begin // @[src/main/scala/rv32i/DivUnit.scala 93:25]
      quot <= nextQuot; // @[src/main/scala/rv32i/DivUnit.scala 100:11]
    end else if (_T) begin // @[src/main/scala/rv32i/DivUnit.scala 65:21]
      if (negA) begin // @[src/main/scala/rv32i/DivUnit.scala 76:19]
        quot <= _quot_T_1;
      end else begin
        quot <= io_req_bits_a;
      end
    end
    if (state == 2'h1) begin // @[src/main/scala/rv32i/DivUnit.scala 93:25]
      rem <= nextRem; // @[src/main/scala/rv32i/DivUnit.scala 99:11]
    end else if (_T) begin // @[src/main/scala/rv32i/DivUnit.scala 65:21]
      rem <= 32'h0; // @[src/main/scala/rv32i/DivUnit.scala 78:13]
    end
    if (_T) begin // @[src/main/scala/rv32i/DivUnit.scala 65:21]
      if (negB) begin // @[src/main/scala/rv32i/DivUnit.scala 77:19]
        divisor <= _divisor_T_1;
      end else begin
        divisor <= io_req_bits_b;
      end
    end
    if (state == 2'h1) begin // @[src/main/scala/rv32i/DivUnit.scala 93:25]
      count <= _count_T_1; // @[src/main/scala/rv32i/DivUnit.scala 101:11]
    end else if (_T) begin // @[src/main/scala/rv32i/DivUnit.scala 65:21]
      count <= 5'h0; // @[src/main/scala/rv32i/DivUnit.scala 79:13]
    end
    if (_T) begin // @[src/main/scala/rv32i/DivUnit.scala 65:21]
      negQ <= negA != negB; // @[src/main/scala/rv32i/DivUnit.scala 74:13]
    end
    if (_T) begin // @[src/main/scala/rv32i/DivUnit.scala 65:21]
      negR <= negA; // @[src/main/scala/rv32i/DivUnit.scala 75:13]
    end
    if (_T) begin // @[src/main/scala/rv32i/DivUnit.scala 65:21]
      wantRem <= isRem; // @[src/main/scala/rv32i/DivUnit.scala 73:13]
    end
    if (state == 2'h1) begin // @[src/main/scala/rv32i/DivUnit.scala 93:25]
      if (count == 5'h1f) begin // @[src/main/scala/rv32i/DivUnit.scala 103:34]
        if (wantRem) begin // @[src/main/scala/rv32i/DivUnit.scala 106:20]
          if (negR) begin // @[src/main/scala/rv32i/DivUnit.scala 105:18]
            result <= _r_T_1;
          end else begin
            result <= nextRem;
          end
        end else if (negQ) begin // @[src/main/scala/rv32i/DivUnit.scala 104:18]
          result <= _q_T_1;
        end else begin
          result <= nextQuot;
        end
      end else begin
        result <= _GEN_11;
      end
    end else begin
      result <= _GEN_11;
    end
  end
// Register and memory initialization
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif
`ifndef RANDOM
`define RANDOM $random
`endif
`ifdef RANDOMIZE_MEM_INIT
  integer initvar;
`endif
`ifndef SYNTHESIS
`ifdef FIRRTL_BEFORE_INITIAL
`FIRRTL_BEFORE_INITIAL
`endif
initial begin
  `ifdef RANDOMIZE
    `ifdef INIT_RANDOM
      `INIT_RANDOM
    `endif
    `ifndef VERILATOR
      `ifdef RANDOMIZE_DELAY
        #`RANDOMIZE_DELAY begin end
      `else
        #0.002 begin end
      `endif
    `endif
`ifdef RANDOMIZE_REG_INIT
  _RAND_0 = {1{`RANDOM}};
  state = _RAND_0[1:0];
  _RAND_1 = {1{`RANDOM}};
  quot = _RAND_1[31:0];
  _RAND_2 = {1{`RANDOM}};
  rem = _RAND_2[31:0];
  _RAND_3 = {1{`RANDOM}};
  divisor = _RAND_3[31:0];
  _RAND_4 = {1{`RANDOM}};
  count = _RAND_4[4:0];
  _RAND_5 = {1{`RANDOM}};
  negQ = _RAND_5[0:0];
  _RAND_6 = {1{`RANDOM}};
  negR = _RAND_6[0:0];
  _RAND_7 = {1{`RANDOM}};
  wantRem = _RAND_7[0:0];
  _RAND_8 = {1{`RANDOM}};
  result = _RAND_8[31:0];
`endif // RANDOMIZE_REG_INIT
  `endif // RANDOMIZE
end // initial
`ifdef FIRRTL_AFTER_INITIAL
`FIRRTL_AFTER_INITIAL
`endif
`endif // SYNTHESIS
endmodule
module Core(
  input         clock,
  input         reset,
  output [31:0] io_imem_addr, // @[src/main/scala/rv32i/Core.scala 35:14]
  input  [31:0] io_imem_data, // @[src/main/scala/rv32i/Core.scala 35:14]
  output [31:0] io_dmem_addr, // @[src/main/scala/rv32i/Core.scala 35:14]
  output        io_dmem_re, // @[src/main/scala/rv32i/Core.scala 35:14]
  output        io_dmem_we, // @[src/main/scala/rv32i/Core.scala 35:14]
  output [31:0] io_dmem_wdata, // @[src/main/scala/rv32i/Core.scala 35:14]
  output [3:0]  io_dmem_wstrb, // @[src/main/scala/rv32i/Core.scala 35:14]
  input  [31:0] io_dmem_rdata, // @[src/main/scala/rv32i/Core.scala 35:14]
  output        io_trace_valid, // @[src/main/scala/rv32i/Core.scala 35:14]
  output        io_trace_trap, // @[src/main/scala/rv32i/Core.scala 35:14]
  output [3:0]  io_trace_cause, // @[src/main/scala/rv32i/Core.scala 35:14]
  output [31:0] io_trace_pc, // @[src/main/scala/rv32i/Core.scala 35:14]
  output [31:0] io_trace_pcNext, // @[src/main/scala/rv32i/Core.scala 35:14]
  output [31:0] io_trace_inst, // @[src/main/scala/rv32i/Core.scala 35:14]
  output [4:0]  io_trace_rdAddr, // @[src/main/scala/rv32i/Core.scala 35:14]
  output [31:0] io_trace_rdData, // @[src/main/scala/rv32i/Core.scala 35:14]
  output [31:0] io_trace_memAddr, // @[src/main/scala/rv32i/Core.scala 35:14]
  output        io_trace_memRe, // @[src/main/scala/rv32i/Core.scala 35:14]
  output        io_trace_memWe, // @[src/main/scala/rv32i/Core.scala 35:14]
  output [1:0]  io_trace_memSize, // @[src/main/scala/rv32i/Core.scala 35:14]
  output [31:0] io_trace_memWdata // @[src/main/scala/rv32i/Core.scala 35:14]
);
`ifdef RANDOMIZE_REG_INIT
  reg [31:0] _RAND_0;
  reg [31:0] _RAND_1;
  reg [31:0] _RAND_2;
  reg [31:0] _RAND_3;
  reg [31:0] _RAND_4;
  reg [31:0] _RAND_5;
  reg [31:0] _RAND_6;
  reg [31:0] _RAND_7;
  reg [31:0] _RAND_8;
  reg [31:0] _RAND_9;
  reg [31:0] _RAND_10;
  reg [31:0] _RAND_11;
  reg [31:0] _RAND_12;
  reg [31:0] _RAND_13;
  reg [31:0] _RAND_14;
  reg [31:0] _RAND_15;
  reg [31:0] _RAND_16;
  reg [31:0] _RAND_17;
  reg [31:0] _RAND_18;
  reg [31:0] _RAND_19;
  reg [31:0] _RAND_20;
  reg [31:0] _RAND_21;
  reg [31:0] _RAND_22;
  reg [31:0] _RAND_23;
  reg [31:0] _RAND_24;
  reg [31:0] _RAND_25;
  reg [31:0] _RAND_26;
  reg [31:0] _RAND_27;
  reg [31:0] _RAND_28;
  reg [31:0] _RAND_29;
  reg [31:0] _RAND_30;
  reg [31:0] _RAND_31;
  reg [31:0] _RAND_32;
  reg [31:0] _RAND_33;
  reg [31:0] _RAND_34;
  reg [31:0] _RAND_35;
  reg [31:0] _RAND_36;
  reg [31:0] _RAND_37;
  reg [31:0] _RAND_38;
  reg [31:0] _RAND_39;
  reg [31:0] _RAND_40;
  reg [31:0] _RAND_41;
  reg [31:0] _RAND_42;
  reg [31:0] _RAND_43;
  reg [31:0] _RAND_44;
  reg [31:0] _RAND_45;
  reg [31:0] _RAND_46;
  reg [31:0] _RAND_47;
  reg [31:0] _RAND_48;
  reg [31:0] _RAND_49;
  reg [31:0] _RAND_50;
  reg [31:0] _RAND_51;
  reg [31:0] _RAND_52;
  reg [31:0] _RAND_53;
  reg [31:0] _RAND_54;
  reg [31:0] _RAND_55;
  reg [31:0] _RAND_56;
  reg [31:0] _RAND_57;
  reg [31:0] _RAND_58;
  reg [31:0] _RAND_59;
  reg [31:0] _RAND_60;
  reg [31:0] _RAND_61;
  reg [31:0] _RAND_62;
`endif // RANDOMIZE_REG_INIT
  wire [31:0] dec_io_inst; // @[src/main/scala/rv32i/Core.scala 43:20]
  wire [2:0] dec_io_immSel; // @[src/main/scala/rv32i/Core.scala 43:20]
  wire [1:0] dec_io_aluSrcA; // @[src/main/scala/rv32i/Core.scala 43:20]
  wire  dec_io_aluSrcImm; // @[src/main/scala/rv32i/Core.scala 43:20]
  wire [3:0] dec_io_aluOp; // @[src/main/scala/rv32i/Core.scala 43:20]
  wire  dec_io_branch; // @[src/main/scala/rv32i/Core.scala 43:20]
  wire  dec_io_jal; // @[src/main/scala/rv32i/Core.scala 43:20]
  wire  dec_io_jalr; // @[src/main/scala/rv32i/Core.scala 43:20]
  wire  dec_io_memRead; // @[src/main/scala/rv32i/Core.scala 43:20]
  wire  dec_io_memWrite; // @[src/main/scala/rv32i/Core.scala 43:20]
  wire [1:0] dec_io_memSize; // @[src/main/scala/rv32i/Core.scala 43:20]
  wire  dec_io_memUnsigned; // @[src/main/scala/rv32i/Core.scala 43:20]
  wire [1:0] dec_io_wbSel; // @[src/main/scala/rv32i/Core.scala 43:20]
  wire  dec_io_regWrite; // @[src/main/scala/rv32i/Core.scala 43:20]
  wire  dec_io_csr; // @[src/main/scala/rv32i/Core.scala 43:20]
  wire  dec_io_ecall; // @[src/main/scala/rv32i/Core.scala 43:20]
  wire  dec_io_ebreak; // @[src/main/scala/rv32i/Core.scala 43:20]
  wire  dec_io_mret; // @[src/main/scala/rv32i/Core.scala 43:20]
  wire  dec_io_illegal; // @[src/main/scala/rv32i/Core.scala 43:20]
  wire [31:0] immg_io_inst; // @[src/main/scala/rv32i/Core.scala 44:20]
  wire [2:0] immg_io_sel; // @[src/main/scala/rv32i/Core.scala 44:20]
  wire [31:0] immg_io_imm; // @[src/main/scala/rv32i/Core.scala 44:20]
  wire  rf_clock; // @[src/main/scala/rv32i/Core.scala 45:20]
  wire  rf_reset; // @[src/main/scala/rv32i/Core.scala 45:20]
  wire [4:0] rf_io_rs1; // @[src/main/scala/rv32i/Core.scala 45:20]
  wire [4:0] rf_io_rs2; // @[src/main/scala/rv32i/Core.scala 45:20]
  wire [31:0] rf_io_rd1; // @[src/main/scala/rv32i/Core.scala 45:20]
  wire [31:0] rf_io_rd2; // @[src/main/scala/rv32i/Core.scala 45:20]
  wire  rf_io_we; // @[src/main/scala/rv32i/Core.scala 45:20]
  wire [4:0] rf_io_waddr; // @[src/main/scala/rv32i/Core.scala 45:20]
  wire [31:0] rf_io_wdata; // @[src/main/scala/rv32i/Core.scala 45:20]
  wire [3:0] alu_io_op; // @[src/main/scala/rv32i/Core.scala 46:20]
  wire [31:0] alu_io_a; // @[src/main/scala/rv32i/Core.scala 46:20]
  wire [31:0] alu_io_b; // @[src/main/scala/rv32i/Core.scala 46:20]
  wire [31:0] alu_io_y; // @[src/main/scala/rv32i/Core.scala 46:20]
  wire  csr_clock; // @[src/main/scala/rv32i/Core.scala 47:20]
  wire  csr_reset; // @[src/main/scala/rv32i/Core.scala 47:20]
  wire [11:0] csr_io_addr; // @[src/main/scala/rv32i/Core.scala 47:20]
  wire  csr_io_en; // @[src/main/scala/rv32i/Core.scala 47:20]
  wire [1:0] csr_io_op; // @[src/main/scala/rv32i/Core.scala 47:20]
  wire [31:0] csr_io_src; // @[src/main/scala/rv32i/Core.scala 47:20]
  wire  csr_io_wrEn; // @[src/main/scala/rv32i/Core.scala 47:20]
  wire [31:0] csr_io_rdata; // @[src/main/scala/rv32i/Core.scala 47:20]
  wire  csr_io_illegal; // @[src/main/scala/rv32i/Core.scala 47:20]
  wire  csr_io_commit; // @[src/main/scala/rv32i/Core.scala 47:20]
  wire  csr_io_trapEnter; // @[src/main/scala/rv32i/Core.scala 47:20]
  wire [31:0] csr_io_trapCause; // @[src/main/scala/rv32i/Core.scala 47:20]
  wire [31:0] csr_io_trapPc; // @[src/main/scala/rv32i/Core.scala 47:20]
  wire [31:0] csr_io_trapVal; // @[src/main/scala/rv32i/Core.scala 47:20]
  wire  csr_io_mretEnter; // @[src/main/scala/rv32i/Core.scala 47:20]
  wire [31:0] csr_io_mtvecBase; // @[src/main/scala/rv32i/Core.scala 47:20]
  wire [31:0] csr_io_mepc; // @[src/main/scala/rv32i/Core.scala 47:20]
  wire [1:0] mul_io_fn; // @[src/main/scala/rv32i/Core.scala 48:20]
  wire [31:0] mul_io_a; // @[src/main/scala/rv32i/Core.scala 48:20]
  wire [31:0] mul_io_b; // @[src/main/scala/rv32i/Core.scala 48:20]
  wire [31:0] mul_io_result; // @[src/main/scala/rv32i/Core.scala 48:20]
  wire  div_clock; // @[src/main/scala/rv32i/Core.scala 49:20]
  wire  div_reset; // @[src/main/scala/rv32i/Core.scala 49:20]
  wire  div_io_req_ready; // @[src/main/scala/rv32i/Core.scala 49:20]
  wire  div_io_req_valid; // @[src/main/scala/rv32i/Core.scala 49:20]
  wire [1:0] div_io_req_bits_op; // @[src/main/scala/rv32i/Core.scala 49:20]
  wire [31:0] div_io_req_bits_a; // @[src/main/scala/rv32i/Core.scala 49:20]
  wire [31:0] div_io_req_bits_b; // @[src/main/scala/rv32i/Core.scala 49:20]
  wire  div_io_resp_valid; // @[src/main/scala/rv32i/Core.scala 49:20]
  wire [31:0] div_io_resp_bits; // @[src/main/scala/rv32i/Core.scala 49:20]
  wire  div_io_kill; // @[src/main/scala/rv32i/Core.scala 49:20]
  wire  div_io_busy; // @[src/main/scala/rv32i/Core.scala 49:20]
  reg  ifid_valid; // @[src/main/scala/rv32i/Core.scala 52:22]
  reg [31:0] ifid_pc; // @[src/main/scala/rv32i/Core.scala 52:22]
  reg [31:0] ifid_inst; // @[src/main/scala/rv32i/Core.scala 52:22]
  reg  idex_valid; // @[src/main/scala/rv32i/Core.scala 53:22]
  reg [31:0] idex_pc; // @[src/main/scala/rv32i/Core.scala 53:22]
  reg [31:0] idex_inst; // @[src/main/scala/rv32i/Core.scala 53:22]
  reg [4:0] idex_rs1; // @[src/main/scala/rv32i/Core.scala 53:22]
  reg [4:0] idex_rs2; // @[src/main/scala/rv32i/Core.scala 53:22]
  reg [4:0] idex_rd; // @[src/main/scala/rv32i/Core.scala 53:22]
  reg [31:0] idex_rs1Val; // @[src/main/scala/rv32i/Core.scala 53:22]
  reg [31:0] idex_rs2Val; // @[src/main/scala/rv32i/Core.scala 53:22]
  reg [31:0] idex_imm; // @[src/main/scala/rv32i/Core.scala 53:22]
  reg [1:0] idex_ctrl_aluSrcA; // @[src/main/scala/rv32i/Core.scala 53:22]
  reg  idex_ctrl_aluSrcImm; // @[src/main/scala/rv32i/Core.scala 53:22]
  reg [3:0] idex_ctrl_aluOp; // @[src/main/scala/rv32i/Core.scala 53:22]
  reg  idex_ctrl_branch; // @[src/main/scala/rv32i/Core.scala 53:22]
  reg  idex_ctrl_jal; // @[src/main/scala/rv32i/Core.scala 53:22]
  reg  idex_ctrl_jalr; // @[src/main/scala/rv32i/Core.scala 53:22]
  reg  idex_ctrl_memRead; // @[src/main/scala/rv32i/Core.scala 53:22]
  reg  idex_ctrl_memWrite; // @[src/main/scala/rv32i/Core.scala 53:22]
  reg [1:0] idex_ctrl_memSize; // @[src/main/scala/rv32i/Core.scala 53:22]
  reg  idex_ctrl_memUnsigned; // @[src/main/scala/rv32i/Core.scala 53:22]
  reg [1:0] idex_ctrl_wbSel; // @[src/main/scala/rv32i/Core.scala 53:22]
  reg  idex_ctrl_regWrite; // @[src/main/scala/rv32i/Core.scala 53:22]
  reg  idex_ctrl_csr; // @[src/main/scala/rv32i/Core.scala 53:22]
  reg  idex_ctrl_ecall; // @[src/main/scala/rv32i/Core.scala 53:22]
  reg  idex_ctrl_ebreak; // @[src/main/scala/rv32i/Core.scala 53:22]
  reg  idex_ctrl_mret; // @[src/main/scala/rv32i/Core.scala 53:22]
  reg  idex_ctrl_illegal; // @[src/main/scala/rv32i/Core.scala 53:22]
  reg  idex_ctrl_isMul; // @[src/main/scala/rv32i/Core.scala 53:22]
  reg  idex_ctrl_isDiv; // @[src/main/scala/rv32i/Core.scala 53:22]
  reg  idex_ctrl_usesRs1; // @[src/main/scala/rv32i/Core.scala 53:22]
  reg  idex_ctrl_usesRs2; // @[src/main/scala/rv32i/Core.scala 53:22]
  reg  exmem_valid; // @[src/main/scala/rv32i/Core.scala 54:22]
  reg  exmem_trap; // @[src/main/scala/rv32i/Core.scala 54:22]
  reg [3:0] exmem_cause; // @[src/main/scala/rv32i/Core.scala 54:22]
  reg [31:0] exmem_pc; // @[src/main/scala/rv32i/Core.scala 54:22]
  reg [31:0] exmem_pcNext; // @[src/main/scala/rv32i/Core.scala 54:22]
  reg [31:0] exmem_inst; // @[src/main/scala/rv32i/Core.scala 54:22]
  reg [4:0] exmem_rd; // @[src/main/scala/rv32i/Core.scala 54:22]
  reg  exmem_regWrite; // @[src/main/scala/rv32i/Core.scala 54:22]
  reg [31:0] exmem_result; // @[src/main/scala/rv32i/Core.scala 54:22]
  reg  exmem_memRead; // @[src/main/scala/rv32i/Core.scala 54:22]
  reg  exmem_memWrite; // @[src/main/scala/rv32i/Core.scala 54:22]
  reg [1:0] exmem_memSize; // @[src/main/scala/rv32i/Core.scala 54:22]
  reg  exmem_memUnsigned; // @[src/main/scala/rv32i/Core.scala 54:22]
  reg [31:0] exmem_addr; // @[src/main/scala/rv32i/Core.scala 54:22]
  reg [31:0] exmem_storeData; // @[src/main/scala/rv32i/Core.scala 54:22]
  reg  memwb_valid; // @[src/main/scala/rv32i/Core.scala 55:22]
  reg  memwb_trap; // @[src/main/scala/rv32i/Core.scala 55:22]
  reg [3:0] memwb_cause; // @[src/main/scala/rv32i/Core.scala 55:22]
  reg [31:0] memwb_pc; // @[src/main/scala/rv32i/Core.scala 55:22]
  reg [31:0] memwb_pcNext; // @[src/main/scala/rv32i/Core.scala 55:22]
  reg [31:0] memwb_inst; // @[src/main/scala/rv32i/Core.scala 55:22]
  reg [4:0] memwb_rd; // @[src/main/scala/rv32i/Core.scala 55:22]
  reg  memwb_regWrite; // @[src/main/scala/rv32i/Core.scala 55:22]
  reg [31:0] memwb_wdata; // @[src/main/scala/rv32i/Core.scala 55:22]
  reg  memwb_memRe; // @[src/main/scala/rv32i/Core.scala 55:22]
  reg  memwb_memWe; // @[src/main/scala/rv32i/Core.scala 55:22]
  reg [31:0] memwb_memAddr; // @[src/main/scala/rv32i/Core.scala 55:22]
  reg [1:0] memwb_memSize; // @[src/main/scala/rv32i/Core.scala 55:22]
  reg [31:0] memwb_memWdata; // @[src/main/scala/rv32i/Core.scala 55:22]
  reg [31:0] fetchPc; // @[src/main/scala/rv32i/Core.scala 60:24]
  wire [31:0] idInst = ifid_valid ? ifid_inst : 32'h13; // @[src/main/scala/rv32i/Core.scala 66:21]
  wire [6:0] idOpcode = idInst[6:0]; // @[src/main/scala/rv32i/Core.scala 67:24]
  wire [2:0] idF3 = idInst[14:12]; // @[src/main/scala/rv32i/Core.scala 68:24]
  wire  _idMulDiv_T = idOpcode == 7'h33; // @[src/main/scala/rv32i/Core.scala 69:27]
  wire  idMulDiv = idOpcode == 7'h33 & idInst[31:25] == 7'h1; // @[src/main/scala/rv32i/Core.scala 69:43]
  wire [4:0] rs1 = idInst[19:15]; // @[src/main/scala/rv32i/Core.scala 70:24]
  wire [4:0] rs2 = idInst[24:20]; // @[src/main/scala/rv32i/Core.scala 71:24]
  wire  _wbWrites_T = ~memwb_trap; // @[src/main/scala/rv32i/Core.scala 80:33]
  wire  _wbWrites_T_1 = memwb_valid & ~memwb_trap; // @[src/main/scala/rv32i/Core.scala 80:30]
  wire  _wbWrites_T_2 = memwb_valid & ~memwb_trap & memwb_regWrite; // @[src/main/scala/rv32i/Core.scala 80:45]
  wire  wbWrites = memwb_valid & ~memwb_trap & memwb_regWrite & memwb_rd != 5'h0; // @[src/main/scala/rv32i/Core.scala 80:63]
  wire [31:0] rs1Val = wbWrites & memwb_rd == rs1 ? memwb_wdata : rf_io_rd1; // @[src/main/scala/rv32i/Core.scala 81:21]
  wire [31:0] rs2Val = wbWrites & memwb_rd == rs2 ? memwb_wdata : rf_io_rd2; // @[src/main/scala/rv32i/Core.scala 82:21]
  wire  idCtrl_regWrite = dec_io_regWrite | idMulDiv; // @[src/main/scala/rv32i/Core.scala 96:41]
  wire  idCtrl_illegal = dec_io_illegal & ~idMulDiv; // @[src/main/scala/rv32i/Core.scala 102:40]
  wire  _idCtrl_isMul_T_1 = ~idF3[2]; // @[src/main/scala/rv32i/Core.scala 103:37]
  wire  idCtrl_isMul = idMulDiv & ~idF3[2]; // @[src/main/scala/rv32i/Core.scala 103:34]
  wire  idCtrl_isDiv = idMulDiv & idF3[2]; // @[src/main/scala/rv32i/Core.scala 104:34]
  wire  _idCtrl_usesRs1_T = ~idCtrl_illegal; // @[src/main/scala/rv32i/Core.scala 106:25]
  wire  _idCtrl_usesRs1_T_4 = idOpcode == 7'h13; // @[src/main/scala/rv32i/Core.scala 107:34]
  wire  _idCtrl_usesRs1_T_5 = dec_io_jalr | dec_io_branch | dec_io_memRead | dec_io_memWrite | _idCtrl_usesRs1_T_4; // @[src/main/scala/rv32i/Core.scala 106:111]
  wire  _idCtrl_usesRs1_T_11 = _idCtrl_usesRs1_T_5 | _idMulDiv_T | dec_io_csr & _idCtrl_isMul_T_1; // @[src/main/scala/rv32i/Core.scala 107:82]
  wire  idCtrl_usesRs1 = ~idCtrl_illegal & _idCtrl_usesRs1_T_11; // @[src/main/scala/rv32i/Core.scala 106:41]
  wire  idCtrl_usesRs2 = _idCtrl_usesRs1_T & (dec_io_branch | dec_io_memWrite | _idMulDiv_T); // @[src/main/scala/rv32i/Core.scala 108:41]
  wire  _loadUse_T_8 = idCtrl_usesRs1 & rs1 == idex_rd | idCtrl_usesRs2 & rs2 == idex_rd; // @[src/main/scala/rv32i/Core.scala 112:42]
  wire  loadUse = ifid_valid & idex_valid & idex_ctrl_memRead & idex_rd != 5'h0 & _loadUse_T_8; // @[src/main/scala/rv32i/Core.scala 111:82]
  wire [2:0] exF3 = idex_inst[14:12]; // @[src/main/scala/rv32i/Core.scala 121:23]
  wire  _a_fromMem_T_7 = idex_rs1 != 5'h0; // @[src/main/scala/rv32i/Core.scala 125:109]
  wire  a_fromMem = exmem_valid & ~exmem_trap & exmem_regWrite & ~exmem_memRead & exmem_rd == idex_rs1 & idex_rs1 != 5'h0
    ; // @[src/main/scala/rv32i/Core.scala 125:102]
  wire  a_fromWb = _wbWrites_T_2 & memwb_rd == idex_rs1 & _a_fromMem_T_7; // @[src/main/scala/rv32i/Core.scala 126:84]
  wire [31:0] _a_T = a_fromWb ? memwb_wdata : idex_rs1Val; // @[src/main/scala/rv32i/Core.scala 127:35]
  wire [31:0] a = a_fromMem ? exmem_result : _a_T; // @[src/main/scala/rv32i/Core.scala 127:8]
  wire  _b_fromMem_T_7 = idex_rs2 != 5'h0; // @[src/main/scala/rv32i/Core.scala 125:109]
  wire  b_fromMem = exmem_valid & ~exmem_trap & exmem_regWrite & ~exmem_memRead & exmem_rd == idex_rs2 & idex_rs2 != 5'h0
    ; // @[src/main/scala/rv32i/Core.scala 125:102]
  wire  b_fromWb = _wbWrites_T_2 & memwb_rd == idex_rs2 & _b_fromMem_T_7; // @[src/main/scala/rv32i/Core.scala 126:84]
  wire [31:0] _b_T = b_fromWb ? memwb_wdata : idex_rs2Val; // @[src/main/scala/rv32i/Core.scala 127:35]
  wire [31:0] b = b_fromMem ? exmem_result : _b_T; // @[src/main/scala/rv32i/Core.scala 127:8]
  wire [31:0] _GEN_0 = 2'h2 == idex_ctrl_aluSrcA ? 32'h0 : a; // @[src/main/scala/rv32i/Core.scala 134:21 133:25 137:26]
  wire [31:0] _GEN_1 = 2'h1 == idex_ctrl_aluSrcA ? idex_pc : _GEN_0; // @[src/main/scala/rv32i/Core.scala 134:21 136:26]
  wire  _div_io_req_valid_T = idex_valid & idex_ctrl_isDiv; // @[src/main/scala/rv32i/Core.scala 148:33]
  wire  divStall = _div_io_req_valid_T & ~div_io_resp_valid; // @[src/main/scala/rv32i/Core.scala 152:37]
  wire  eq = a == b; // @[src/main/scala/rv32i/Core.scala 155:15]
  wire [31:0] _lt_T = a_fromMem ? exmem_result : _a_T; // @[src/main/scala/rv32i/Core.scala 156:15]
  wire [31:0] _lt_T_1 = b_fromMem ? exmem_result : _b_T; // @[src/main/scala/rv32i/Core.scala 156:26]
  wire  lt = $signed(_lt_T) < $signed(_lt_T_1); // @[src/main/scala/rv32i/Core.scala 156:22]
  wire  ltu = a < b; // @[src/main/scala/rv32i/Core.scala 157:15]
  wire  _GEN_3 = 3'h7 == exF3 & ~ltu; // @[src/main/scala/rv32i/Core.scala 159:16 158:27 165:27]
  wire  _GEN_4 = 3'h6 == exF3 ? ltu : _GEN_3; // @[src/main/scala/rv32i/Core.scala 159:16 164:27]
  wire  _GEN_5 = 3'h5 == exF3 ? ~lt : _GEN_4; // @[src/main/scala/rv32i/Core.scala 159:16 163:27]
  wire  _GEN_6 = 3'h4 == exF3 ? lt : _GEN_5; // @[src/main/scala/rv32i/Core.scala 159:16 162:27]
  wire  _GEN_7 = 3'h1 == exF3 ? ~eq : _GEN_6; // @[src/main/scala/rv32i/Core.scala 159:16 161:27]
  wire  brCond = 3'h0 == exF3 ? eq : _GEN_7; // @[src/main/scala/rv32i/Core.scala 159:16 160:27]
  wire [31:0] pcPlus4 = idex_pc + 32'h4; // @[src/main/scala/rv32i/Core.scala 167:25]
  wire [31:0] brTarget = idex_pc + idex_imm; // @[src/main/scala/rv32i/Core.scala 168:25]
  wire [31:0] jalrTarget = {alu_io_y[31:1],1'h0}; // @[src/main/scala/rv32i/Core.scala 169:23]
  wire  ctlTaken = idex_ctrl_branch & brCond | idex_ctrl_jal | idex_ctrl_jalr; // @[src/main/scala/rv32i/Core.scala 170:50]
  wire [31:0] ctlTarget = idex_ctrl_jalr ? jalrTarget : brTarget; // @[src/main/scala/rv32i/Core.scala 171:23]
  wire  misalignedAccess = idex_ctrl_memSize == 2'h2 & alu_io_y[1:0] != 2'h0 | idex_ctrl_memSize == 2'h1 & alu_io_y[0]; // @[src/main/scala/rv32i/Core.scala 174:68]
  wire  loadMis = idex_ctrl_memRead & misalignedAccess; // @[src/main/scala/rv32i/Core.scala 175:28]
  wire  storeMis = idex_ctrl_memWrite & misalignedAccess; // @[src/main/scala/rv32i/Core.scala 176:29]
  wire  fetchMis = ctlTaken & ctlTarget[1]; // @[src/main/scala/rv32i/Core.scala 177:27]
  wire [4:0] rs1Field = idex_inst[19:15]; // @[src/main/scala/rv32i/Core.scala 180:24]
  wire [31:0] _csr_io_src_T_1 = {27'h0,rs1Field}; // @[src/main/scala/rv32i/Core.scala 184:34]
  wire  illegal = idex_ctrl_illegal | csr_io_illegal; // @[src/main/scala/rv32i/Core.scala 188:27]
  wire  trapNow = idex_valid & (illegal | idex_ctrl_ecall | idex_ctrl_ebreak | loadMis | storeMis | fetchMis); // @[src/main/scala/rv32i/Core.scala 189:25]
  wire [3:0] _cause_T = storeMis ? 4'h6 : 4'h0; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [3:0] _cause_T_1 = loadMis ? 4'h4 : _cause_T; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [3:0] _cause_T_2 = idex_ctrl_ebreak ? 4'h3 : _cause_T_1; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [3:0] _cause_T_3 = idex_ctrl_ecall ? 4'hb : _cause_T_2; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [3:0] cause = illegal ? 4'h2 : _cause_T_3; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire  _tval_T = loadMis | storeMis; // @[src/main/scala/rv32i/Core.scala 204:14]
  wire [31:0] _tval_T_1 = _tval_T ? alu_io_y : ctlTarget; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [31:0] _tval_T_2 = idex_ctrl_ebreak ? idex_pc : _tval_T_1; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [31:0] _tval_T_3 = idex_ctrl_ecall ? 32'h0 : _tval_T_2; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire  _exCommit_T = ~trapNow; // @[src/main/scala/rv32i/Core.scala 209:29]
  wire  _exCommit_T_2 = ~divStall; // @[src/main/scala/rv32i/Core.scala 209:41]
  wire [31:0] _nextPc_T = ctlTaken ? ctlTarget : pcPlus4; // @[src/main/scala/rv32i/Core.scala 219:19]
  wire [31:0] _nextPc_T_1 = idex_ctrl_mret ? csr_io_mepc : _nextPc_T; // @[src/main/scala/rv32i/Core.scala 218:19]
  wire  _redirect_T_1 = idex_valid & _exCommit_T_2; // @[src/main/scala/rv32i/Core.scala 220:26]
  wire  redirect = idex_valid & _exCommit_T_2 & (trapNow | idex_ctrl_mret | ctlTaken); // @[src/main/scala/rv32i/Core.scala 220:39]
  wire [31:0] _GEN_9 = alu_io_y; // @[src/main/scala/rv32i/Core.scala 223:19 222:29 227:30]
  wire [31:0] _GEN_10 = 2'h3 == idex_ctrl_wbSel ? csr_io_rdata : _GEN_9; // @[src/main/scala/rv32i/Core.scala 223:19 226:30]
  wire [31:0] _GEN_11 = 2'h2 == idex_ctrl_wbSel ? pcPlus4 : _GEN_10; // @[src/main/scala/rv32i/Core.scala 223:19 225:30]
  wire [31:0] _GEN_12 = 2'h0 == idex_ctrl_wbSel ? alu_io_y : _GEN_11; // @[src/main/scala/rv32i/Core.scala 223:19 224:30]
  wire [31:0] _fetchPc_T_1 = fetchPc + 32'h4; // @[src/main/scala/rv32i/Core.scala 244:28]
  wire [1:0] idCtrl_aluSrcA = dec_io_aluSrcA; // @[src/main/scala/rv32i/Core.scala 84:20 85:22]
  wire  idCtrl_aluSrcImm = dec_io_aluSrcImm; // @[src/main/scala/rv32i/Core.scala 84:20 86:22]
  wire [3:0] idCtrl_aluOp = dec_io_aluOp; // @[src/main/scala/rv32i/Core.scala 84:20 87:22]
  wire  idCtrl_branch = dec_io_branch; // @[src/main/scala/rv32i/Core.scala 84:20 88:22]
  wire  idCtrl_jal = dec_io_jal; // @[src/main/scala/rv32i/Core.scala 84:20 89:22]
  wire  idCtrl_jalr = dec_io_jalr; // @[src/main/scala/rv32i/Core.scala 84:20 90:22]
  wire  idCtrl_memRead = dec_io_memRead; // @[src/main/scala/rv32i/Core.scala 84:20 91:22]
  wire  idCtrl_memWrite = dec_io_memWrite; // @[src/main/scala/rv32i/Core.scala 84:20 92:22]
  wire [1:0] idCtrl_memSize = dec_io_memSize; // @[src/main/scala/rv32i/Core.scala 84:20 93:22]
  wire  idCtrl_memUnsigned = dec_io_memUnsigned; // @[src/main/scala/rv32i/Core.scala 84:20 94:22]
  wire [1:0] idCtrl_wbSel = dec_io_wbSel; // @[src/main/scala/rv32i/Core.scala 84:20 95:22]
  wire  idCtrl_csr = dec_io_csr; // @[src/main/scala/rv32i/Core.scala 84:20 97:22]
  wire  idCtrl_ecall = dec_io_ecall; // @[src/main/scala/rv32i/Core.scala 84:20 98:22]
  wire  idCtrl_ebreak = dec_io_ebreak; // @[src/main/scala/rv32i/Core.scala 84:20 99:22]
  wire  idCtrl_mret = dec_io_mret; // @[src/main/scala/rv32i/Core.scala 84:20 100:22]
  wire [7:0] sbyte = exmem_storeData[7:0]; // @[src/main/scala/rv32i/Core.scala 288:30]
  wire [15:0] shalf = exmem_storeData[15:0]; // @[src/main/scala/rv32i/Core.scala 289:30]
  wire  _T_28 = 2'h0 == exmem_memSize; // @[src/main/scala/rv32i/Core.scala 292:16]
  wire [31:0] _wdata_T_1 = {sbyte,sbyte,sbyte,sbyte}; // @[src/main/scala/rv32i/Core.scala 293:28]
  wire [6:0] _wstrb_T_1 = 7'h1 << exmem_addr[1:0]; // @[src/main/scala/rv32i/Core.scala 293:59]
  wire  _T_29 = 2'h1 == exmem_memSize; // @[src/main/scala/rv32i/Core.scala 292:16]
  wire [31:0] _wdata_T_2 = {shalf,shalf}; // @[src/main/scala/rv32i/Core.scala 294:28]
  wire [3:0] _wstrb_T_4 = exmem_addr[1] ? 4'hc : 4'h3; // @[src/main/scala/rv32i/Core.scala 294:52]
  wire [31:0] _GEN_131 = 2'h1 == exmem_memSize ? _wdata_T_2 : exmem_storeData; // @[src/main/scala/rv32i/Core.scala 292:16 294:21 290:26]
  wire [3:0] _GEN_132 = 2'h1 == exmem_memSize ? _wstrb_T_4 : 4'hf; // @[src/main/scala/rv32i/Core.scala 292:16 291:26 294:46]
  wire [3:0] wstrb = 2'h0 == exmem_memSize ? _wstrb_T_1[3:0] : _GEN_132; // @[src/main/scala/rv32i/Core.scala 292:16 293:46]
  wire [7:0] bytes_0 = io_dmem_rdata[7:0]; // @[src/main/scala/rv32i/Core.scala 300:49]
  wire [7:0] bytes_1 = io_dmem_rdata[15:8]; // @[src/main/scala/rv32i/Core.scala 300:49]
  wire [7:0] bytes_2 = io_dmem_rdata[23:16]; // @[src/main/scala/rv32i/Core.scala 300:49]
  wire [7:0] bytes_3 = io_dmem_rdata[31:24]; // @[src/main/scala/rv32i/Core.scala 300:49]
  wire [15:0] lh = exmem_addr[1] ? io_dmem_rdata[31:16] : io_dmem_rdata[15:0]; // @[src/main/scala/rv32i/Core.scala 302:18]
  wire [7:0] _GEN_136 = 2'h1 == exmem_addr[1:0] ? bytes_1 : bytes_0; // @[src/main/scala/rv32i/Core.scala 306:{39,39}]
  wire [7:0] _GEN_137 = 2'h2 == exmem_addr[1:0] ? bytes_2 : _GEN_136; // @[src/main/scala/rv32i/Core.scala 306:{39,39}]
  wire [7:0] _GEN_138 = 2'h3 == exmem_addr[1:0] ? bytes_3 : _GEN_137; // @[src/main/scala/rv32i/Core.scala 306:{39,39}]
  wire [31:0] _loadData_T = {24'h0,_GEN_138}; // @[src/main/scala/rv32i/Core.scala 306:39]
  wire [23:0] _loadData_T_2 = _GEN_138[7] ? 24'hffffff : 24'h0; // @[src/main/scala/rv32i/Core.scala 306:64]
  wire [31:0] _loadData_T_3 = {_loadData_T_2,_GEN_138}; // @[src/main/scala/rv32i/Core.scala 306:59]
  wire [31:0] _loadData_T_5 = {16'h0,lh}; // @[src/main/scala/rv32i/Core.scala 307:39]
  wire [15:0] _loadData_T_7 = lh[15] ? 16'hffff : 16'h0; // @[src/main/scala/rv32i/Core.scala 307:64]
  wire [31:0] _loadData_T_8 = {_loadData_T_7,lh}; // @[src/main/scala/rv32i/Core.scala 307:59]
  wire [31:0] _loadData_T_9 = exmem_memUnsigned ? _loadData_T_5 : _loadData_T_8; // @[src/main/scala/rv32i/Core.scala 307:30]
  wire [31:0] _memwb_memWdata_T_1 = {24'h0,sbyte}; // @[src/main/scala/rv32i/Core.scala 323:42]
  wire [31:0] _memwb_memWdata_T_3 = {16'h0,shalf}; // @[src/main/scala/rv32i/Core.scala 323:83]
  wire  _T_34 = ~reset; // @[src/main/scala/rv32i/Core.scala 349:9]
  wire  _T_55 = idex_ctrl_usesRs1 & idex_rs1 == exmem_rd | idex_ctrl_usesRs2 & idex_rs2 == exmem_rd; // @[src/main/scala/rv32i/Core.scala 354:43]
  Decoder dec ( // @[src/main/scala/rv32i/Core.scala 43:20]
    .io_inst(dec_io_inst),
    .io_immSel(dec_io_immSel),
    .io_aluSrcA(dec_io_aluSrcA),
    .io_aluSrcImm(dec_io_aluSrcImm),
    .io_aluOp(dec_io_aluOp),
    .io_branch(dec_io_branch),
    .io_jal(dec_io_jal),
    .io_jalr(dec_io_jalr),
    .io_memRead(dec_io_memRead),
    .io_memWrite(dec_io_memWrite),
    .io_memSize(dec_io_memSize),
    .io_memUnsigned(dec_io_memUnsigned),
    .io_wbSel(dec_io_wbSel),
    .io_regWrite(dec_io_regWrite),
    .io_csr(dec_io_csr),
    .io_ecall(dec_io_ecall),
    .io_ebreak(dec_io_ebreak),
    .io_mret(dec_io_mret),
    .io_illegal(dec_io_illegal)
  );
  ImmGen immg ( // @[src/main/scala/rv32i/Core.scala 44:20]
    .io_inst(immg_io_inst),
    .io_sel(immg_io_sel),
    .io_imm(immg_io_imm)
  );
  RegFile rf ( // @[src/main/scala/rv32i/Core.scala 45:20]
    .clock(rf_clock),
    .reset(rf_reset),
    .io_rs1(rf_io_rs1),
    .io_rs2(rf_io_rs2),
    .io_rd1(rf_io_rd1),
    .io_rd2(rf_io_rd2),
    .io_we(rf_io_we),
    .io_waddr(rf_io_waddr),
    .io_wdata(rf_io_wdata)
  );
  Alu alu ( // @[src/main/scala/rv32i/Core.scala 46:20]
    .io_op(alu_io_op),
    .io_a(alu_io_a),
    .io_b(alu_io_b),
    .io_y(alu_io_y)
  );
  CsrFile csr ( // @[src/main/scala/rv32i/Core.scala 47:20]
    .clock(csr_clock),
    .reset(csr_reset),
    .io_addr(csr_io_addr),
    .io_en(csr_io_en),
    .io_op(csr_io_op),
    .io_src(csr_io_src),
    .io_wrEn(csr_io_wrEn),
    .io_rdata(csr_io_rdata),
    .io_illegal(csr_io_illegal),
    .io_commit(csr_io_commit),
    .io_trapEnter(csr_io_trapEnter),
    .io_trapCause(csr_io_trapCause),
    .io_trapPc(csr_io_trapPc),
    .io_trapVal(csr_io_trapVal),
    .io_mretEnter(csr_io_mretEnter),
    .io_mtvecBase(csr_io_mtvecBase),
    .io_mepc(csr_io_mepc)
  );
  Multiplier mul ( // @[src/main/scala/rv32i/Core.scala 48:20]
    .io_fn(mul_io_fn),
    .io_a(mul_io_a),
    .io_b(mul_io_b),
    .io_result(mul_io_result)
  );
  DivUnit div ( // @[src/main/scala/rv32i/Core.scala 49:20]
    .clock(div_clock),
    .reset(div_reset),
    .io_req_ready(div_io_req_ready),
    .io_req_valid(div_io_req_valid),
    .io_req_bits_op(div_io_req_bits_op),
    .io_req_bits_a(div_io_req_bits_a),
    .io_req_bits_b(div_io_req_bits_b),
    .io_resp_valid(div_io_resp_valid),
    .io_resp_bits(div_io_resp_bits),
    .io_kill(div_io_kill),
    .io_busy(div_io_busy)
  );
  assign io_imem_addr = fetchPc; // @[src/main/scala/rv32i/Core.scala 61:16]
  assign io_dmem_addr = exmem_addr; // @[src/main/scala/rv32i/Core.scala 284:16]
  assign io_dmem_re = exmem_valid & exmem_memRead; // @[src/main/scala/rv32i/Core.scala 285:31]
  assign io_dmem_we = exmem_valid & exmem_memWrite; // @[src/main/scala/rv32i/Core.scala 286:31]
  assign io_dmem_wdata = 2'h0 == exmem_memSize ? _wdata_T_1 : _GEN_131; // @[src/main/scala/rv32i/Core.scala 292:16 293:21]
  assign io_dmem_wstrb = io_dmem_we ? wstrb : 4'h0; // @[src/main/scala/rv32i/Core.scala 297:23]
  assign io_trace_valid = memwb_valid & _wbWrites_T; // @[src/main/scala/rv32i/Core.scala 332:36]
  assign io_trace_trap = memwb_valid & memwb_trap; // @[src/main/scala/rv32i/Core.scala 333:36]
  assign io_trace_cause = memwb_cause; // @[src/main/scala/rv32i/Core.scala 334:21]
  assign io_trace_pc = memwb_pc; // @[src/main/scala/rv32i/Core.scala 335:21]
  assign io_trace_pcNext = memwb_pcNext; // @[src/main/scala/rv32i/Core.scala 336:21]
  assign io_trace_inst = memwb_inst; // @[src/main/scala/rv32i/Core.scala 337:21]
  assign io_trace_rdAddr = wbWrites ? memwb_rd : 5'h0; // @[src/main/scala/rv32i/Core.scala 338:27]
  assign io_trace_rdData = wbWrites ? memwb_wdata : 32'h0; // @[src/main/scala/rv32i/Core.scala 339:27]
  assign io_trace_memAddr = memwb_memAddr; // @[src/main/scala/rv32i/Core.scala 340:21]
  assign io_trace_memRe = memwb_valid & memwb_memRe; // @[src/main/scala/rv32i/Core.scala 341:36]
  assign io_trace_memWe = memwb_valid & memwb_memWe; // @[src/main/scala/rv32i/Core.scala 342:36]
  assign io_trace_memSize = memwb_memSize; // @[src/main/scala/rv32i/Core.scala 343:21]
  assign io_trace_memWdata = memwb_memWdata; // @[src/main/scala/rv32i/Core.scala 344:21]
  assign dec_io_inst = ifid_valid ? ifid_inst : 32'h13; // @[src/main/scala/rv32i/Core.scala 66:21]
  assign immg_io_inst = ifid_valid ? ifid_inst : 32'h13; // @[src/main/scala/rv32i/Core.scala 66:21]
  assign immg_io_sel = dec_io_immSel; // @[src/main/scala/rv32i/Core.scala 75:16]
  assign rf_clock = clock;
  assign rf_reset = reset;
  assign rf_io_rs1 = idInst[19:15]; // @[src/main/scala/rv32i/Core.scala 70:24]
  assign rf_io_rs2 = idInst[24:20]; // @[src/main/scala/rv32i/Core.scala 71:24]
  assign rf_io_we = _wbWrites_T_1 & memwb_regWrite; // @[src/main/scala/rv32i/Core.scala 328:45]
  assign rf_io_waddr = memwb_rd; // @[src/main/scala/rv32i/Core.scala 329:15]
  assign rf_io_wdata = memwb_wdata; // @[src/main/scala/rv32i/Core.scala 330:15]
  assign alu_io_op = idex_ctrl_aluOp; // @[src/main/scala/rv32i/Core.scala 139:13]
  assign alu_io_a = 2'h0 == idex_ctrl_aluSrcA ? a : _GEN_1; // @[src/main/scala/rv32i/Core.scala 134:21 135:26]
  assign alu_io_b = idex_ctrl_aluSrcImm ? idex_imm : b; // @[src/main/scala/rv32i/Core.scala 141:19]
  assign csr_clock = clock;
  assign csr_reset = reset;
  assign csr_io_addr = idex_inst[31:20]; // @[src/main/scala/rv32i/Core.scala 181:24]
  assign csr_io_en = idex_valid & idex_ctrl_csr; // @[src/main/scala/rv32i/Core.scala 182:26]
  assign csr_io_op = exF3[1:0]; // @[src/main/scala/rv32i/Core.scala 183:22]
  assign csr_io_src = exF3[2] ? _csr_io_src_T_1 : a; // @[src/main/scala/rv32i/Core.scala 184:21]
  assign csr_io_wrEn = exF3[1:0] == 2'h1 | rs1Field != 5'h0; // @[src/main/scala/rv32i/Core.scala 185:37]
  assign csr_io_commit = idex_valid & ~trapNow & ~divStall; // @[src/main/scala/rv32i/Core.scala 209:38]
  assign csr_io_trapEnter = idex_valid & (illegal | idex_ctrl_ecall | idex_ctrl_ebreak | loadMis | storeMis | fetchMis); // @[src/main/scala/rv32i/Core.scala 189:25]
  assign csr_io_trapCause = {28'h0,cause}; // @[src/main/scala/rv32i/Core.scala 212:26]
  assign csr_io_trapPc = idex_pc; // @[src/main/scala/rv32i/Core.scala 213:20]
  assign csr_io_trapVal = illegal ? idex_inst : _tval_T_3; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  assign csr_io_mretEnter = idex_valid & idex_ctrl_mret & _exCommit_T; // @[src/main/scala/rv32i/Core.scala 215:41]
  assign mul_io_fn = exF3[1:0]; // @[src/main/scala/rv32i/Core.scala 145:20]
  assign mul_io_a = a_fromMem ? exmem_result : _a_T; // @[src/main/scala/rv32i/Core.scala 127:8]
  assign mul_io_b = b_fromMem ? exmem_result : _b_T; // @[src/main/scala/rv32i/Core.scala 127:8]
  assign div_clock = clock;
  assign div_reset = reset;
  assign div_io_req_valid = idex_valid & idex_ctrl_isDiv & ~div_io_busy; // @[src/main/scala/rv32i/Core.scala 148:44]
  assign div_io_req_bits_op = exF3[1:0]; // @[src/main/scala/rv32i/Core.scala 149:29]
  assign div_io_req_bits_a = a_fromMem ? exmem_result : _a_T; // @[src/main/scala/rv32i/Core.scala 127:8]
  assign div_io_req_bits_b = b_fromMem ? exmem_result : _b_T; // @[src/main/scala/rv32i/Core.scala 127:8]
  assign div_io_kill = idex_valid & (illegal | idex_ctrl_ecall | idex_ctrl_ebreak | loadMis | storeMis | fetchMis); // @[src/main/scala/rv32i/Core.scala 189:25]
  always @(posedge clock) begin
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 52:22]
      ifid_valid <= 1'h0; // @[src/main/scala/rv32i/Core.scala 52:22]
    end else if (!(divStall)) begin // @[src/main/scala/rv32i/Core.scala 235:18]
      if (redirect) begin // @[src/main/scala/rv32i/Core.scala 237:24]
        ifid_valid <= 1'h0; // @[src/main/scala/rv32i/Core.scala 239:16]
      end else if (!(loadUse)) begin // @[src/main/scala/rv32i/Core.scala 241:23]
        ifid_valid <= 1'h1; // @[src/main/scala/rv32i/Core.scala 245:17]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 52:22]
      ifid_pc <= 32'h0; // @[src/main/scala/rv32i/Core.scala 52:22]
    end else if (!(divStall)) begin // @[src/main/scala/rv32i/Core.scala 235:18]
      if (!(redirect)) begin // @[src/main/scala/rv32i/Core.scala 237:24]
        if (!(loadUse)) begin // @[src/main/scala/rv32i/Core.scala 241:23]
          ifid_pc <= fetchPc; // @[src/main/scala/rv32i/Core.scala 246:17]
        end
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 52:22]
      ifid_inst <= 32'h0; // @[src/main/scala/rv32i/Core.scala 52:22]
    end else if (!(divStall)) begin // @[src/main/scala/rv32i/Core.scala 235:18]
      if (!(redirect)) begin // @[src/main/scala/rv32i/Core.scala 237:24]
        if (!(loadUse)) begin // @[src/main/scala/rv32i/Core.scala 241:23]
          ifid_inst <= io_imem_data; // @[src/main/scala/rv32i/Core.scala 247:17]
        end
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 53:22]
      idex_valid <= 1'h0; // @[src/main/scala/rv32i/Core.scala 53:22]
    end else if (!(divStall)) begin // @[src/main/scala/rv32i/Core.scala 235:18]
      if (redirect) begin // @[src/main/scala/rv32i/Core.scala 237:24]
        idex_valid <= 1'h0; // @[src/main/scala/rv32i/Core.scala 240:16]
      end else if (loadUse) begin // @[src/main/scala/rv32i/Core.scala 241:23]
        idex_valid <= 1'h0; // @[src/main/scala/rv32i/Core.scala 242:16]
      end else begin
        idex_valid <= ifid_valid; // @[src/main/scala/rv32i/Core.scala 248:17]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 53:22]
      idex_pc <= 32'h0; // @[src/main/scala/rv32i/Core.scala 53:22]
    end else if (!(divStall)) begin // @[src/main/scala/rv32i/Core.scala 235:18]
      if (!(redirect)) begin // @[src/main/scala/rv32i/Core.scala 237:24]
        if (!(loadUse)) begin // @[src/main/scala/rv32i/Core.scala 241:23]
          idex_pc <= ifid_pc; // @[src/main/scala/rv32i/Core.scala 249:17]
        end
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 53:22]
      idex_inst <= 32'h0; // @[src/main/scala/rv32i/Core.scala 53:22]
    end else if (!(divStall)) begin // @[src/main/scala/rv32i/Core.scala 235:18]
      if (!(redirect)) begin // @[src/main/scala/rv32i/Core.scala 237:24]
        if (!(loadUse)) begin // @[src/main/scala/rv32i/Core.scala 241:23]
          idex_inst <= idInst; // @[src/main/scala/rv32i/Core.scala 250:17]
        end
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 53:22]
      idex_rs1 <= 5'h0; // @[src/main/scala/rv32i/Core.scala 53:22]
    end else if (!(divStall)) begin // @[src/main/scala/rv32i/Core.scala 235:18]
      if (!(redirect)) begin // @[src/main/scala/rv32i/Core.scala 237:24]
        if (!(loadUse)) begin // @[src/main/scala/rv32i/Core.scala 241:23]
          idex_rs1 <= rs1; // @[src/main/scala/rv32i/Core.scala 251:17]
        end
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 53:22]
      idex_rs2 <= 5'h0; // @[src/main/scala/rv32i/Core.scala 53:22]
    end else if (!(divStall)) begin // @[src/main/scala/rv32i/Core.scala 235:18]
      if (!(redirect)) begin // @[src/main/scala/rv32i/Core.scala 237:24]
        if (!(loadUse)) begin // @[src/main/scala/rv32i/Core.scala 241:23]
          idex_rs2 <= rs2; // @[src/main/scala/rv32i/Core.scala 252:17]
        end
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 53:22]
      idex_rd <= 5'h0; // @[src/main/scala/rv32i/Core.scala 53:22]
    end else if (!(divStall)) begin // @[src/main/scala/rv32i/Core.scala 235:18]
      if (!(redirect)) begin // @[src/main/scala/rv32i/Core.scala 237:24]
        if (!(loadUse)) begin // @[src/main/scala/rv32i/Core.scala 241:23]
          idex_rd <= idInst[11:7]; // @[src/main/scala/rv32i/Core.scala 253:17]
        end
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 53:22]
      idex_rs1Val <= 32'h0; // @[src/main/scala/rv32i/Core.scala 53:22]
    end else if (!(divStall)) begin // @[src/main/scala/rv32i/Core.scala 235:18]
      if (!(redirect)) begin // @[src/main/scala/rv32i/Core.scala 237:24]
        if (!(loadUse)) begin // @[src/main/scala/rv32i/Core.scala 241:23]
          idex_rs1Val <= rs1Val; // @[src/main/scala/rv32i/Core.scala 254:17]
        end
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 53:22]
      idex_rs2Val <= 32'h0; // @[src/main/scala/rv32i/Core.scala 53:22]
    end else if (!(divStall)) begin // @[src/main/scala/rv32i/Core.scala 235:18]
      if (!(redirect)) begin // @[src/main/scala/rv32i/Core.scala 237:24]
        if (!(loadUse)) begin // @[src/main/scala/rv32i/Core.scala 241:23]
          idex_rs2Val <= rs2Val; // @[src/main/scala/rv32i/Core.scala 255:17]
        end
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 53:22]
      idex_imm <= 32'h0; // @[src/main/scala/rv32i/Core.scala 53:22]
    end else if (!(divStall)) begin // @[src/main/scala/rv32i/Core.scala 235:18]
      if (!(redirect)) begin // @[src/main/scala/rv32i/Core.scala 237:24]
        if (!(loadUse)) begin // @[src/main/scala/rv32i/Core.scala 241:23]
          idex_imm <= immg_io_imm; // @[src/main/scala/rv32i/Core.scala 256:17]
        end
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 53:22]
      idex_ctrl_aluSrcA <= 2'h0; // @[src/main/scala/rv32i/Core.scala 53:22]
    end else if (!(divStall)) begin // @[src/main/scala/rv32i/Core.scala 235:18]
      if (!(redirect)) begin // @[src/main/scala/rv32i/Core.scala 237:24]
        if (!(loadUse)) begin // @[src/main/scala/rv32i/Core.scala 241:23]
          idex_ctrl_aluSrcA <= idCtrl_aluSrcA; // @[src/main/scala/rv32i/Core.scala 257:17]
        end
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 53:22]
      idex_ctrl_aluSrcImm <= 1'h0; // @[src/main/scala/rv32i/Core.scala 53:22]
    end else if (!(divStall)) begin // @[src/main/scala/rv32i/Core.scala 235:18]
      if (!(redirect)) begin // @[src/main/scala/rv32i/Core.scala 237:24]
        if (!(loadUse)) begin // @[src/main/scala/rv32i/Core.scala 241:23]
          idex_ctrl_aluSrcImm <= idCtrl_aluSrcImm; // @[src/main/scala/rv32i/Core.scala 257:17]
        end
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 53:22]
      idex_ctrl_aluOp <= 4'h0; // @[src/main/scala/rv32i/Core.scala 53:22]
    end else if (!(divStall)) begin // @[src/main/scala/rv32i/Core.scala 235:18]
      if (!(redirect)) begin // @[src/main/scala/rv32i/Core.scala 237:24]
        if (!(loadUse)) begin // @[src/main/scala/rv32i/Core.scala 241:23]
          idex_ctrl_aluOp <= idCtrl_aluOp; // @[src/main/scala/rv32i/Core.scala 257:17]
        end
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 53:22]
      idex_ctrl_branch <= 1'h0; // @[src/main/scala/rv32i/Core.scala 53:22]
    end else if (!(divStall)) begin // @[src/main/scala/rv32i/Core.scala 235:18]
      if (!(redirect)) begin // @[src/main/scala/rv32i/Core.scala 237:24]
        if (!(loadUse)) begin // @[src/main/scala/rv32i/Core.scala 241:23]
          idex_ctrl_branch <= idCtrl_branch; // @[src/main/scala/rv32i/Core.scala 257:17]
        end
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 53:22]
      idex_ctrl_jal <= 1'h0; // @[src/main/scala/rv32i/Core.scala 53:22]
    end else if (!(divStall)) begin // @[src/main/scala/rv32i/Core.scala 235:18]
      if (!(redirect)) begin // @[src/main/scala/rv32i/Core.scala 237:24]
        if (!(loadUse)) begin // @[src/main/scala/rv32i/Core.scala 241:23]
          idex_ctrl_jal <= idCtrl_jal; // @[src/main/scala/rv32i/Core.scala 257:17]
        end
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 53:22]
      idex_ctrl_jalr <= 1'h0; // @[src/main/scala/rv32i/Core.scala 53:22]
    end else if (!(divStall)) begin // @[src/main/scala/rv32i/Core.scala 235:18]
      if (!(redirect)) begin // @[src/main/scala/rv32i/Core.scala 237:24]
        if (!(loadUse)) begin // @[src/main/scala/rv32i/Core.scala 241:23]
          idex_ctrl_jalr <= idCtrl_jalr; // @[src/main/scala/rv32i/Core.scala 257:17]
        end
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 53:22]
      idex_ctrl_memRead <= 1'h0; // @[src/main/scala/rv32i/Core.scala 53:22]
    end else if (!(divStall)) begin // @[src/main/scala/rv32i/Core.scala 235:18]
      if (!(redirect)) begin // @[src/main/scala/rv32i/Core.scala 237:24]
        if (!(loadUse)) begin // @[src/main/scala/rv32i/Core.scala 241:23]
          idex_ctrl_memRead <= idCtrl_memRead; // @[src/main/scala/rv32i/Core.scala 257:17]
        end
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 53:22]
      idex_ctrl_memWrite <= 1'h0; // @[src/main/scala/rv32i/Core.scala 53:22]
    end else if (!(divStall)) begin // @[src/main/scala/rv32i/Core.scala 235:18]
      if (!(redirect)) begin // @[src/main/scala/rv32i/Core.scala 237:24]
        if (!(loadUse)) begin // @[src/main/scala/rv32i/Core.scala 241:23]
          idex_ctrl_memWrite <= idCtrl_memWrite; // @[src/main/scala/rv32i/Core.scala 257:17]
        end
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 53:22]
      idex_ctrl_memSize <= 2'h0; // @[src/main/scala/rv32i/Core.scala 53:22]
    end else if (!(divStall)) begin // @[src/main/scala/rv32i/Core.scala 235:18]
      if (!(redirect)) begin // @[src/main/scala/rv32i/Core.scala 237:24]
        if (!(loadUse)) begin // @[src/main/scala/rv32i/Core.scala 241:23]
          idex_ctrl_memSize <= idCtrl_memSize; // @[src/main/scala/rv32i/Core.scala 257:17]
        end
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 53:22]
      idex_ctrl_memUnsigned <= 1'h0; // @[src/main/scala/rv32i/Core.scala 53:22]
    end else if (!(divStall)) begin // @[src/main/scala/rv32i/Core.scala 235:18]
      if (!(redirect)) begin // @[src/main/scala/rv32i/Core.scala 237:24]
        if (!(loadUse)) begin // @[src/main/scala/rv32i/Core.scala 241:23]
          idex_ctrl_memUnsigned <= idCtrl_memUnsigned; // @[src/main/scala/rv32i/Core.scala 257:17]
        end
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 53:22]
      idex_ctrl_wbSel <= 2'h0; // @[src/main/scala/rv32i/Core.scala 53:22]
    end else if (!(divStall)) begin // @[src/main/scala/rv32i/Core.scala 235:18]
      if (!(redirect)) begin // @[src/main/scala/rv32i/Core.scala 237:24]
        if (!(loadUse)) begin // @[src/main/scala/rv32i/Core.scala 241:23]
          idex_ctrl_wbSel <= idCtrl_wbSel; // @[src/main/scala/rv32i/Core.scala 257:17]
        end
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 53:22]
      idex_ctrl_regWrite <= 1'h0; // @[src/main/scala/rv32i/Core.scala 53:22]
    end else if (!(divStall)) begin // @[src/main/scala/rv32i/Core.scala 235:18]
      if (!(redirect)) begin // @[src/main/scala/rv32i/Core.scala 237:24]
        if (!(loadUse)) begin // @[src/main/scala/rv32i/Core.scala 241:23]
          idex_ctrl_regWrite <= idCtrl_regWrite; // @[src/main/scala/rv32i/Core.scala 257:17]
        end
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 53:22]
      idex_ctrl_csr <= 1'h0; // @[src/main/scala/rv32i/Core.scala 53:22]
    end else if (!(divStall)) begin // @[src/main/scala/rv32i/Core.scala 235:18]
      if (!(redirect)) begin // @[src/main/scala/rv32i/Core.scala 237:24]
        if (!(loadUse)) begin // @[src/main/scala/rv32i/Core.scala 241:23]
          idex_ctrl_csr <= idCtrl_csr; // @[src/main/scala/rv32i/Core.scala 257:17]
        end
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 53:22]
      idex_ctrl_ecall <= 1'h0; // @[src/main/scala/rv32i/Core.scala 53:22]
    end else if (!(divStall)) begin // @[src/main/scala/rv32i/Core.scala 235:18]
      if (!(redirect)) begin // @[src/main/scala/rv32i/Core.scala 237:24]
        if (!(loadUse)) begin // @[src/main/scala/rv32i/Core.scala 241:23]
          idex_ctrl_ecall <= idCtrl_ecall; // @[src/main/scala/rv32i/Core.scala 257:17]
        end
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 53:22]
      idex_ctrl_ebreak <= 1'h0; // @[src/main/scala/rv32i/Core.scala 53:22]
    end else if (!(divStall)) begin // @[src/main/scala/rv32i/Core.scala 235:18]
      if (!(redirect)) begin // @[src/main/scala/rv32i/Core.scala 237:24]
        if (!(loadUse)) begin // @[src/main/scala/rv32i/Core.scala 241:23]
          idex_ctrl_ebreak <= idCtrl_ebreak; // @[src/main/scala/rv32i/Core.scala 257:17]
        end
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 53:22]
      idex_ctrl_mret <= 1'h0; // @[src/main/scala/rv32i/Core.scala 53:22]
    end else if (!(divStall)) begin // @[src/main/scala/rv32i/Core.scala 235:18]
      if (!(redirect)) begin // @[src/main/scala/rv32i/Core.scala 237:24]
        if (!(loadUse)) begin // @[src/main/scala/rv32i/Core.scala 241:23]
          idex_ctrl_mret <= idCtrl_mret; // @[src/main/scala/rv32i/Core.scala 257:17]
        end
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 53:22]
      idex_ctrl_illegal <= 1'h0; // @[src/main/scala/rv32i/Core.scala 53:22]
    end else if (!(divStall)) begin // @[src/main/scala/rv32i/Core.scala 235:18]
      if (!(redirect)) begin // @[src/main/scala/rv32i/Core.scala 237:24]
        if (!(loadUse)) begin // @[src/main/scala/rv32i/Core.scala 241:23]
          idex_ctrl_illegal <= idCtrl_illegal; // @[src/main/scala/rv32i/Core.scala 257:17]
        end
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 53:22]
      idex_ctrl_isMul <= 1'h0; // @[src/main/scala/rv32i/Core.scala 53:22]
    end else if (!(divStall)) begin // @[src/main/scala/rv32i/Core.scala 235:18]
      if (!(redirect)) begin // @[src/main/scala/rv32i/Core.scala 237:24]
        if (!(loadUse)) begin // @[src/main/scala/rv32i/Core.scala 241:23]
          idex_ctrl_isMul <= idCtrl_isMul; // @[src/main/scala/rv32i/Core.scala 257:17]
        end
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 53:22]
      idex_ctrl_isDiv <= 1'h0; // @[src/main/scala/rv32i/Core.scala 53:22]
    end else if (!(divStall)) begin // @[src/main/scala/rv32i/Core.scala 235:18]
      if (!(redirect)) begin // @[src/main/scala/rv32i/Core.scala 237:24]
        if (!(loadUse)) begin // @[src/main/scala/rv32i/Core.scala 241:23]
          idex_ctrl_isDiv <= idCtrl_isDiv; // @[src/main/scala/rv32i/Core.scala 257:17]
        end
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 53:22]
      idex_ctrl_usesRs1 <= 1'h0; // @[src/main/scala/rv32i/Core.scala 53:22]
    end else if (!(divStall)) begin // @[src/main/scala/rv32i/Core.scala 235:18]
      if (!(redirect)) begin // @[src/main/scala/rv32i/Core.scala 237:24]
        if (!(loadUse)) begin // @[src/main/scala/rv32i/Core.scala 241:23]
          idex_ctrl_usesRs1 <= idCtrl_usesRs1; // @[src/main/scala/rv32i/Core.scala 257:17]
        end
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 53:22]
      idex_ctrl_usesRs2 <= 1'h0; // @[src/main/scala/rv32i/Core.scala 53:22]
    end else if (!(divStall)) begin // @[src/main/scala/rv32i/Core.scala 235:18]
      if (!(redirect)) begin // @[src/main/scala/rv32i/Core.scala 237:24]
        if (!(loadUse)) begin // @[src/main/scala/rv32i/Core.scala 241:23]
          idex_ctrl_usesRs2 <= idCtrl_usesRs2; // @[src/main/scala/rv32i/Core.scala 257:17]
        end
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 54:22]
      exmem_valid <= 1'h0; // @[src/main/scala/rv32i/Core.scala 54:22]
    end else begin
      exmem_valid <= _redirect_T_1; // @[src/main/scala/rv32i/Core.scala 261:15]
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 54:22]
      exmem_trap <= 1'h0; // @[src/main/scala/rv32i/Core.scala 54:22]
    end else if (_exCommit_T_2) begin // @[src/main/scala/rv32i/Core.scala 262:19]
      exmem_trap <= trapNow; // @[src/main/scala/rv32i/Core.scala 263:23]
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 54:22]
      exmem_cause <= 4'h0; // @[src/main/scala/rv32i/Core.scala 54:22]
    end else if (_exCommit_T_2) begin // @[src/main/scala/rv32i/Core.scala 262:19]
      if (illegal) begin // @[src/main/scala/chisel3/util/Mux.scala 50:70]
        exmem_cause <= 4'h2;
      end else if (idex_ctrl_ecall) begin // @[src/main/scala/chisel3/util/Mux.scala 50:70]
        exmem_cause <= 4'hb;
      end else begin
        exmem_cause <= _cause_T_2;
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 54:22]
      exmem_pc <= 32'h0; // @[src/main/scala/rv32i/Core.scala 54:22]
    end else if (_exCommit_T_2) begin // @[src/main/scala/rv32i/Core.scala 262:19]
      exmem_pc <= idex_pc; // @[src/main/scala/rv32i/Core.scala 265:23]
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 54:22]
      exmem_pcNext <= 32'h0; // @[src/main/scala/rv32i/Core.scala 54:22]
    end else if (_exCommit_T_2) begin // @[src/main/scala/rv32i/Core.scala 262:19]
      if (trapNow) begin // @[src/main/scala/rv32i/Core.scala 217:19]
        exmem_pcNext <= csr_io_mtvecBase;
      end else if (idex_ctrl_mret) begin // @[src/main/scala/rv32i/Core.scala 218:19]
        exmem_pcNext <= csr_io_mepc;
      end else begin
        exmem_pcNext <= _nextPc_T;
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 54:22]
      exmem_inst <= 32'h0; // @[src/main/scala/rv32i/Core.scala 54:22]
    end else if (_exCommit_T_2) begin // @[src/main/scala/rv32i/Core.scala 262:19]
      exmem_inst <= idex_inst; // @[src/main/scala/rv32i/Core.scala 267:23]
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 54:22]
      exmem_rd <= 5'h0; // @[src/main/scala/rv32i/Core.scala 54:22]
    end else if (_exCommit_T_2) begin // @[src/main/scala/rv32i/Core.scala 262:19]
      exmem_rd <= idex_rd; // @[src/main/scala/rv32i/Core.scala 268:23]
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 54:22]
      exmem_regWrite <= 1'h0; // @[src/main/scala/rv32i/Core.scala 54:22]
    end else if (_exCommit_T_2) begin // @[src/main/scala/rv32i/Core.scala 262:19]
      exmem_regWrite <= idex_ctrl_regWrite & _exCommit_T; // @[src/main/scala/rv32i/Core.scala 269:23]
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 54:22]
      exmem_result <= 32'h0; // @[src/main/scala/rv32i/Core.scala 54:22]
    end else if (_exCommit_T_2) begin // @[src/main/scala/rv32i/Core.scala 262:19]
      if (idex_ctrl_isDiv) begin // @[src/main/scala/rv32i/Core.scala 230:17]
        exmem_result <= div_io_resp_bits; // @[src/main/scala/rv32i/Core.scala 230:28]
      end else if (idex_ctrl_isMul) begin // @[src/main/scala/rv32i/Core.scala 229:17]
        exmem_result <= mul_io_result; // @[src/main/scala/rv32i/Core.scala 229:28]
      end else begin
        exmem_result <= _GEN_12;
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 54:22]
      exmem_memRead <= 1'h0; // @[src/main/scala/rv32i/Core.scala 54:22]
    end else if (_exCommit_T_2) begin // @[src/main/scala/rv32i/Core.scala 262:19]
      exmem_memRead <= idex_ctrl_memRead & _exCommit_T; // @[src/main/scala/rv32i/Core.scala 271:23]
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 54:22]
      exmem_memWrite <= 1'h0; // @[src/main/scala/rv32i/Core.scala 54:22]
    end else if (_exCommit_T_2) begin // @[src/main/scala/rv32i/Core.scala 262:19]
      exmem_memWrite <= idex_ctrl_memWrite & _exCommit_T; // @[src/main/scala/rv32i/Core.scala 272:23]
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 54:22]
      exmem_memSize <= 2'h0; // @[src/main/scala/rv32i/Core.scala 54:22]
    end else if (_exCommit_T_2) begin // @[src/main/scala/rv32i/Core.scala 262:19]
      exmem_memSize <= idex_ctrl_memSize; // @[src/main/scala/rv32i/Core.scala 273:23]
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 54:22]
      exmem_memUnsigned <= 1'h0; // @[src/main/scala/rv32i/Core.scala 54:22]
    end else if (_exCommit_T_2) begin // @[src/main/scala/rv32i/Core.scala 262:19]
      exmem_memUnsigned <= idex_ctrl_memUnsigned; // @[src/main/scala/rv32i/Core.scala 274:23]
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 54:22]
      exmem_addr <= 32'h0; // @[src/main/scala/rv32i/Core.scala 54:22]
    end else if (_exCommit_T_2) begin // @[src/main/scala/rv32i/Core.scala 262:19]
      exmem_addr <= alu_io_y; // @[src/main/scala/rv32i/Core.scala 275:23]
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 54:22]
      exmem_storeData <= 32'h0; // @[src/main/scala/rv32i/Core.scala 54:22]
    end else if (_exCommit_T_2) begin // @[src/main/scala/rv32i/Core.scala 262:19]
      if (b_fromMem) begin // @[src/main/scala/rv32i/Core.scala 127:8]
        exmem_storeData <= exmem_result;
      end else if (b_fromWb) begin // @[src/main/scala/rv32i/Core.scala 127:35]
        exmem_storeData <= memwb_wdata;
      end else begin
        exmem_storeData <= idex_rs2Val;
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 55:22]
      memwb_valid <= 1'h0; // @[src/main/scala/rv32i/Core.scala 55:22]
    end else begin
      memwb_valid <= exmem_valid; // @[src/main/scala/rv32i/Core.scala 310:18]
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 55:22]
      memwb_trap <= 1'h0; // @[src/main/scala/rv32i/Core.scala 55:22]
    end else begin
      memwb_trap <= exmem_trap; // @[src/main/scala/rv32i/Core.scala 311:18]
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 55:22]
      memwb_cause <= 4'h0; // @[src/main/scala/rv32i/Core.scala 55:22]
    end else begin
      memwb_cause <= exmem_cause; // @[src/main/scala/rv32i/Core.scala 312:18]
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 55:22]
      memwb_pc <= 32'h0; // @[src/main/scala/rv32i/Core.scala 55:22]
    end else begin
      memwb_pc <= exmem_pc; // @[src/main/scala/rv32i/Core.scala 313:18]
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 55:22]
      memwb_pcNext <= 32'h0; // @[src/main/scala/rv32i/Core.scala 55:22]
    end else begin
      memwb_pcNext <= exmem_pcNext; // @[src/main/scala/rv32i/Core.scala 314:18]
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 55:22]
      memwb_inst <= 32'h0; // @[src/main/scala/rv32i/Core.scala 55:22]
    end else begin
      memwb_inst <= exmem_inst; // @[src/main/scala/rv32i/Core.scala 315:18]
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 55:22]
      memwb_rd <= 5'h0; // @[src/main/scala/rv32i/Core.scala 55:22]
    end else begin
      memwb_rd <= exmem_rd; // @[src/main/scala/rv32i/Core.scala 316:18]
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 55:22]
      memwb_regWrite <= 1'h0; // @[src/main/scala/rv32i/Core.scala 55:22]
    end else begin
      memwb_regWrite <= exmem_regWrite; // @[src/main/scala/rv32i/Core.scala 317:18]
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 55:22]
      memwb_wdata <= 32'h0; // @[src/main/scala/rv32i/Core.scala 55:22]
    end else if (exmem_memRead) begin // @[src/main/scala/rv32i/Core.scala 318:24]
      if (_T_28) begin // @[src/main/scala/rv32i/Core.scala 305:16]
        if (exmem_memUnsigned) begin // @[src/main/scala/rv32i/Core.scala 306:30]
          memwb_wdata <= _loadData_T;
        end else begin
          memwb_wdata <= _loadData_T_3;
        end
      end else if (_T_29) begin // @[src/main/scala/rv32i/Core.scala 305:16]
        memwb_wdata <= _loadData_T_9; // @[src/main/scala/rv32i/Core.scala 307:24]
      end else begin
        memwb_wdata <= io_dmem_rdata; // @[src/main/scala/rv32i/Core.scala 304:29]
      end
    end else begin
      memwb_wdata <= exmem_result;
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 55:22]
      memwb_memRe <= 1'h0; // @[src/main/scala/rv32i/Core.scala 55:22]
    end else begin
      memwb_memRe <= io_dmem_re; // @[src/main/scala/rv32i/Core.scala 319:18]
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 55:22]
      memwb_memWe <= 1'h0; // @[src/main/scala/rv32i/Core.scala 55:22]
    end else begin
      memwb_memWe <= io_dmem_we; // @[src/main/scala/rv32i/Core.scala 320:18]
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 55:22]
      memwb_memAddr <= 32'h0; // @[src/main/scala/rv32i/Core.scala 55:22]
    end else begin
      memwb_memAddr <= exmem_addr; // @[src/main/scala/rv32i/Core.scala 321:18]
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 55:22]
      memwb_memSize <= 2'h0; // @[src/main/scala/rv32i/Core.scala 55:22]
    end else begin
      memwb_memSize <= exmem_memSize; // @[src/main/scala/rv32i/Core.scala 322:18]
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 55:22]
      memwb_memWdata <= 32'h0; // @[src/main/scala/rv32i/Core.scala 55:22]
    end else if (exmem_memSize == 2'h0) begin // @[src/main/scala/rv32i/Core.scala 323:24]
      memwb_memWdata <= _memwb_memWdata_T_1;
    end else if (exmem_memSize == 2'h1) begin // @[src/main/scala/rv32i/Core.scala 323:65]
      memwb_memWdata <= _memwb_memWdata_T_3;
    end else begin
      memwb_memWdata <= exmem_storeData;
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 60:24]
      fetchPc <= 32'h80000000; // @[src/main/scala/rv32i/Core.scala 60:24]
    end else if (!(divStall)) begin // @[src/main/scala/rv32i/Core.scala 235:18]
      if (redirect) begin // @[src/main/scala/rv32i/Core.scala 237:24]
        if (trapNow) begin // @[src/main/scala/rv32i/Core.scala 217:19]
          fetchPc <= csr_io_mtvecBase;
        end else begin
          fetchPc <= _nextPc_T_1;
        end
      end else if (!(loadUse)) begin // @[src/main/scala/rv32i/Core.scala 241:23]
        fetchPc <= _fetchPc_T_1; // @[src/main/scala/rv32i/Core.scala 244:17]
      end
    end
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (~reset & ~(fetchPc[1:0] == 2'h0)) begin
          $fwrite(32'h80000002,
            "Assertion failed: fetch pc must stay 4-byte aligned\n    at Core.scala:349 assert(fetchPc(1, 0) === 0.U, \"fetch pc must stay 4-byte aligned\")\n"
            ); // @[src/main/scala/rv32i/Core.scala 349:9]
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif // SYNTHESIS
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_T_34 & ~(~(io_dmem_we & io_dmem_re))) begin
          $fwrite(32'h80000002,
            "Assertion failed: simultaneous load and store\n    at Core.scala:350 assert(!(io.dmem.we && io.dmem.re), \"simultaneous load and store\")\n"
            ); // @[src/main/scala/rv32i/Core.scala 350:9]
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif // SYNTHESIS
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_T_34 & ~(~(exmem_valid & exmem_trap & (exmem_memRead | exmem_memWrite | exmem_regWrite)))) begin
          $fwrite(32'h80000002,
            "Assertion failed: trapping instruction accesses memory or writes a register\n    at Core.scala:351 assert(!(exmem.valid && exmem.trap && (exmem.memRead || exmem.memWrite || exmem.regWrite)),\n"
            ); // @[src/main/scala/rv32i/Core.scala 351:9]
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif // SYNTHESIS
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_T_34 & ~(~(idex_valid & exmem_valid & exmem_memRead & exmem_rd != 5'h0 & _T_55))) begin
          $fwrite(32'h80000002,
            "Assertion failed: load-use hazard reached EX (missing stall)\n    at Core.scala:353 assert(!(exValid && exmem.valid && exmem.memRead && exmem.rd =/= 0.U &&\n"
            ); // @[src/main/scala/rv32i/Core.scala 353:9]
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif // SYNTHESIS
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_T_34 & ~(~(divStall & trapNow))) begin
          $fwrite(32'h80000002,
            "Assertion failed: a division cannot trap\n    at Core.scala:356 assert(!(divStall && trapNow), \"a division cannot trap\")\n"
            ); // @[src/main/scala/rv32i/Core.scala 356:9]
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif // SYNTHESIS
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_T_34 & ~(~(csr_io_commit & ~idex_valid))) begin
          $fwrite(32'h80000002,
            "Assertion failed: bubble committed\n    at Core.scala:357 assert(!(csr.io.commit && !exValid), \"bubble committed\")\n"
            ); // @[src/main/scala/rv32i/Core.scala 357:9]
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif // SYNTHESIS
  end
// Register and memory initialization
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif
`ifndef RANDOM
`define RANDOM $random
`endif
`ifdef RANDOMIZE_MEM_INIT
  integer initvar;
`endif
`ifndef SYNTHESIS
`ifdef FIRRTL_BEFORE_INITIAL
`FIRRTL_BEFORE_INITIAL
`endif
initial begin
  `ifdef RANDOMIZE
    `ifdef INIT_RANDOM
      `INIT_RANDOM
    `endif
    `ifndef VERILATOR
      `ifdef RANDOMIZE_DELAY
        #`RANDOMIZE_DELAY begin end
      `else
        #0.002 begin end
      `endif
    `endif
`ifdef RANDOMIZE_REG_INIT
  _RAND_0 = {1{`RANDOM}};
  ifid_valid = _RAND_0[0:0];
  _RAND_1 = {1{`RANDOM}};
  ifid_pc = _RAND_1[31:0];
  _RAND_2 = {1{`RANDOM}};
  ifid_inst = _RAND_2[31:0];
  _RAND_3 = {1{`RANDOM}};
  idex_valid = _RAND_3[0:0];
  _RAND_4 = {1{`RANDOM}};
  idex_pc = _RAND_4[31:0];
  _RAND_5 = {1{`RANDOM}};
  idex_inst = _RAND_5[31:0];
  _RAND_6 = {1{`RANDOM}};
  idex_rs1 = _RAND_6[4:0];
  _RAND_7 = {1{`RANDOM}};
  idex_rs2 = _RAND_7[4:0];
  _RAND_8 = {1{`RANDOM}};
  idex_rd = _RAND_8[4:0];
  _RAND_9 = {1{`RANDOM}};
  idex_rs1Val = _RAND_9[31:0];
  _RAND_10 = {1{`RANDOM}};
  idex_rs2Val = _RAND_10[31:0];
  _RAND_11 = {1{`RANDOM}};
  idex_imm = _RAND_11[31:0];
  _RAND_12 = {1{`RANDOM}};
  idex_ctrl_aluSrcA = _RAND_12[1:0];
  _RAND_13 = {1{`RANDOM}};
  idex_ctrl_aluSrcImm = _RAND_13[0:0];
  _RAND_14 = {1{`RANDOM}};
  idex_ctrl_aluOp = _RAND_14[3:0];
  _RAND_15 = {1{`RANDOM}};
  idex_ctrl_branch = _RAND_15[0:0];
  _RAND_16 = {1{`RANDOM}};
  idex_ctrl_jal = _RAND_16[0:0];
  _RAND_17 = {1{`RANDOM}};
  idex_ctrl_jalr = _RAND_17[0:0];
  _RAND_18 = {1{`RANDOM}};
  idex_ctrl_memRead = _RAND_18[0:0];
  _RAND_19 = {1{`RANDOM}};
  idex_ctrl_memWrite = _RAND_19[0:0];
  _RAND_20 = {1{`RANDOM}};
  idex_ctrl_memSize = _RAND_20[1:0];
  _RAND_21 = {1{`RANDOM}};
  idex_ctrl_memUnsigned = _RAND_21[0:0];
  _RAND_22 = {1{`RANDOM}};
  idex_ctrl_wbSel = _RAND_22[1:0];
  _RAND_23 = {1{`RANDOM}};
  idex_ctrl_regWrite = _RAND_23[0:0];
  _RAND_24 = {1{`RANDOM}};
  idex_ctrl_csr = _RAND_24[0:0];
  _RAND_25 = {1{`RANDOM}};
  idex_ctrl_ecall = _RAND_25[0:0];
  _RAND_26 = {1{`RANDOM}};
  idex_ctrl_ebreak = _RAND_26[0:0];
  _RAND_27 = {1{`RANDOM}};
  idex_ctrl_mret = _RAND_27[0:0];
  _RAND_28 = {1{`RANDOM}};
  idex_ctrl_illegal = _RAND_28[0:0];
  _RAND_29 = {1{`RANDOM}};
  idex_ctrl_isMul = _RAND_29[0:0];
  _RAND_30 = {1{`RANDOM}};
  idex_ctrl_isDiv = _RAND_30[0:0];
  _RAND_31 = {1{`RANDOM}};
  idex_ctrl_usesRs1 = _RAND_31[0:0];
  _RAND_32 = {1{`RANDOM}};
  idex_ctrl_usesRs2 = _RAND_32[0:0];
  _RAND_33 = {1{`RANDOM}};
  exmem_valid = _RAND_33[0:0];
  _RAND_34 = {1{`RANDOM}};
  exmem_trap = _RAND_34[0:0];
  _RAND_35 = {1{`RANDOM}};
  exmem_cause = _RAND_35[3:0];
  _RAND_36 = {1{`RANDOM}};
  exmem_pc = _RAND_36[31:0];
  _RAND_37 = {1{`RANDOM}};
  exmem_pcNext = _RAND_37[31:0];
  _RAND_38 = {1{`RANDOM}};
  exmem_inst = _RAND_38[31:0];
  _RAND_39 = {1{`RANDOM}};
  exmem_rd = _RAND_39[4:0];
  _RAND_40 = {1{`RANDOM}};
  exmem_regWrite = _RAND_40[0:0];
  _RAND_41 = {1{`RANDOM}};
  exmem_result = _RAND_41[31:0];
  _RAND_42 = {1{`RANDOM}};
  exmem_memRead = _RAND_42[0:0];
  _RAND_43 = {1{`RANDOM}};
  exmem_memWrite = _RAND_43[0:0];
  _RAND_44 = {1{`RANDOM}};
  exmem_memSize = _RAND_44[1:0];
  _RAND_45 = {1{`RANDOM}};
  exmem_memUnsigned = _RAND_45[0:0];
  _RAND_46 = {1{`RANDOM}};
  exmem_addr = _RAND_46[31:0];
  _RAND_47 = {1{`RANDOM}};
  exmem_storeData = _RAND_47[31:0];
  _RAND_48 = {1{`RANDOM}};
  memwb_valid = _RAND_48[0:0];
  _RAND_49 = {1{`RANDOM}};
  memwb_trap = _RAND_49[0:0];
  _RAND_50 = {1{`RANDOM}};
  memwb_cause = _RAND_50[3:0];
  _RAND_51 = {1{`RANDOM}};
  memwb_pc = _RAND_51[31:0];
  _RAND_52 = {1{`RANDOM}};
  memwb_pcNext = _RAND_52[31:0];
  _RAND_53 = {1{`RANDOM}};
  memwb_inst = _RAND_53[31:0];
  _RAND_54 = {1{`RANDOM}};
  memwb_rd = _RAND_54[4:0];
  _RAND_55 = {1{`RANDOM}};
  memwb_regWrite = _RAND_55[0:0];
  _RAND_56 = {1{`RANDOM}};
  memwb_wdata = _RAND_56[31:0];
  _RAND_57 = {1{`RANDOM}};
  memwb_memRe = _RAND_57[0:0];
  _RAND_58 = {1{`RANDOM}};
  memwb_memWe = _RAND_58[0:0];
  _RAND_59 = {1{`RANDOM}};
  memwb_memAddr = _RAND_59[31:0];
  _RAND_60 = {1{`RANDOM}};
  memwb_memSize = _RAND_60[1:0];
  _RAND_61 = {1{`RANDOM}};
  memwb_memWdata = _RAND_61[31:0];
  _RAND_62 = {1{`RANDOM}};
  fetchPc = _RAND_62[31:0];
`endif // RANDOMIZE_REG_INIT
  `endif // RANDOMIZE
end // initial
`ifdef FIRRTL_AFTER_INITIAL
`FIRRTL_AFTER_INITIAL
`endif
`endif // SYNTHESIS
  always @(posedge clock) begin
    //
    if (~reset) begin
      assert(fetchPc[1:0] == 2'h0); // @[src/main/scala/rv32i/Core.scala 349:9]
    end
    //
    if (_T_34) begin
      assert(~(io_dmem_we & io_dmem_re)); // @[src/main/scala/rv32i/Core.scala 350:9]
    end
    //
    if (_T_34) begin
      assert(~(exmem_valid & exmem_trap & (exmem_memRead | exmem_memWrite | exmem_regWrite))); // @[src/main/scala/rv32i/Core.scala 351:9]
    end
    //
    if (_T_34) begin
      assert(~(idex_valid & exmem_valid & exmem_memRead & exmem_rd != 5'h0 & _T_55)); // @[src/main/scala/rv32i/Core.scala 353:9]
    end
    //
    if (_T_34) begin
      assert(~(divStall & trapNow)); // @[src/main/scala/rv32i/Core.scala 356:9]
    end
    //
    if (_T_34) begin
      assert(~(csr_io_commit & ~idex_valid)); // @[src/main/scala/rv32i/Core.scala 357:9]
    end
  end
endmodule
