# Design notes: RV32IM 5-stage pipelined core (IF / ID / EX / MEM / WB) with a sequential divider

## Architecture

| Item | Choice |
|---|---|
| ISA | RV32I + M (MUL, MULH, MULHSU, MULHU, DIV, DIVU, REM, REMU) + Zicsr, machine mode only |
| Microarchitecture | Classic 5-stage pipeline: IF, ID, EX, MEM, WB, with forwarding and hazard detection; datapath blocks reused from the Step 5 single-cycle core |
| Branch prediction | Static not-taken: fetch always continues at pc + 4; branches and jumps resolve in EX, a taken branch/jump, trap or MRET costs 2 bubbles |
| Reset | pc = `0x80000000` (`Core(resetPc = ...)`), all registers and CSRs = 0 |
| Memories | Harvard, zero-wait ports: instruction and data read data are combinational functions of the address; stores land at the clock edge under a 4-bit byte mask |
| Multiply | Combinational, one shared 33 × 33 signed multiplier for all four MUL variants (1 cycle) |
| Divide | Sequential restoring divider, one quotient bit per cycle: 34 cycles per DIV/DIVU/REM/REMU, 2 cycles for divide-by-zero and signed overflow |
| Interrupts | None (`mie`/`mip` exist for software but nothing raises an interrupt) |

## Pipeline

```
  IF            ID                    EX                         MEM             WB
fetchPc ─► IfId ─► Decoder, ImmGen ─► IdEx ─► forward ─► Alu/Mul ─► ExMem ─► dmem ─► MemWb ─► RegFile write
  ▲  imem          RegFile read  ▲            │          DivUnit             load align        trace
  │                (WB bypass)   │            │          CsrFile, branch, traps
  └──── redirect (nextPc) ◄──────┼────────────┘
                                 └── forwarding from ExMem (non-load) and MemWb
```

| Stage | Work | Pipeline register written |
|---|---|---|
| IF | Read the instruction at `fetchPc`; next fetch at `fetchPc + 4` | `IfId` (valid, pc, inst) |
| ID | Decode, immediate, register read with WB→ID bypass, load-use detection | `IdEx` (pc, inst, rs1/rs2/rd, operand values, imm, `Ctrl`) |
| EX | Forwarding, ALU, multiplier, divider, branch/jump resolution, CSR access, exception detection, trap entry, commit | `ExMem` (result, memory request, trap record, next pc) |
| MEM | Data memory access, load alignment and extension | `MemWb` (write-back value, trace record) |
| WB | Register write, retirement trace | - |

Pipeline control, by priority:

| Condition | fetchPc, IfId | IdEx | ExMem |
|---|---|---|---|
| `divStall` (DIV/REM busy in EX) | hold | hold | bubble |
| `redirect` (taken branch, JAL, JALR, trap, MRET in EX) | fetchPc := target, IfId := bubble | bubble | the EX instruction (or its trap record) |
| `loadUse` (ID reads the destination of a load in EX) | hold | bubble | the load |
| otherwise | advance | advance | advance |

MEM and WB never stall.

## Hazards

| Hazard | Handling | Cost |
|---|---|---|
| RAW, distance 1 (producer in MEM) | Forward `ExMem.result` into EX (not for loads) | 0 |
| RAW, distance 2 (producer in WB) | Forward `MemWb.wdata` into EX | 0 |
| RAW, distance 3 (producer writing in WB while consumer is in ID) | WB→ID bypass of the register read | 0 |
| Load-use (load immediately followed by a reader of its rd) | Stall IF/ID one cycle, bubble into EX, then forward from WB | 1 cycle |
| Control (taken branch, JAL, JALR, trap, MRET) | Resolved in EX; flush IfId and IdEx; fetch the target | 2 cycles |
| Divider | IF/ID/EX freeze for 33 cycles (1 for divide-by-zero and overflow); MEM/WB drain | 33 cycles |
| CSR read-after-write | All CSR reads and writes happen in EX, in program order | 0 |
| Store data from a load | Store data is forwarded in EX like any rs2, so a load followed by a store of its rd is a load-use stall | 1 cycle |

Only real source registers count (`Ctrl.usesRs1` / `usesRs2`): LUI, AUIPC, JAL, CSR-immediate and SYSTEM instructions
never cause a false stall.

## Precise exceptions

Every exception is known in EX: illegal instruction, ECALL and EBREAK come from ID; misaligned load/store addresses
and misaligned branch/jump targets are computed in EX. The trap is taken in EX:

- older instructions are in MEM and WB and complete normally;
- the trapping instruction does not access memory and does not write a register;
- the two younger instructions (IF/ID, ID/EX) are flushed;
- mepc/mcause/mtval/mstatus are written in EX and fetch restarts at mtvec.

A trap record then travels through MEM and WB, so the trace reports it in WB, in program order with the retirements.
Since nothing can fail after EX, an instruction that leaves EX is committed: `minstret` counts there.

## Execution rules (trace, WB stage)

Every cycle WB does exactly one of: retire an instruction (`trace.valid`), report a trap (`trace.trap`), or nothing
(a bubble). An instruction executed in EX in cycle t appears in the trace in cycle t + 2 (`Core.ExToWb`); the first
instruction after reset reaches WB after 4 empty cycles (`Core.FillCycles`).

Cycles between retirements: 1, plus 2 after a redirect, plus 1 for a load-use dependency, plus 33 for a regular
DIV/DIVU/REM/REMU (1 for divide-by-zero or overflow).

Exception priority: illegal instruction (2) > ECALL (11) > EBREAK (3) > load misaligned (4) > store misaligned (6) >
instruction address misaligned (0).

## Choices made where the specification leaves an option

| Topic | Choice | Why |
|---|---|---|
| M-extension decoding | The core recognises OP + funct7 = 0000001 itself; the Decoder still reports it illegal | Keeps the Step 3 RV32I decoder (and its tests) unchanged; same pattern as Step 4 |
| Multiplier | One 33 × 33 signed product, operands extended by sign or zero | One array serves MUL/MULH/MULHSU/MULHU; maps to DSP blocks |
| Divider | Restoring division on magnitudes, signs fixed at the end, 1 bit/cycle | Smallest correct sequential divider: one 33-bit subtract/compare and four 32-bit registers |
| Divider special cases | x/0 and MIN/-1 answered in 1 cycle without iterating | They are defined by the spec's table, no division needed |
| Divider stall | IF, ID and EX freeze, bubbles go to MEM; `busy` stays high through the response cycle | The division stays in EX and cannot start twice; older instructions still drain |
| Forwarding | From EX/MEM (non-load) and MEM/WB into EX, plus WB→ID bypass | Removes every stall except load-use |
| Load-use | 1-cycle stall detected in ID | Load data is only available at the end of MEM |
| Branch resolution | In EX, 2 bubbles | Branch compare uses forwarded operands; resolving in ID would need forwarding into ID and more stalls |
| Bubble encoding | `valid` bit in every pipeline register; an empty IfId decodes as `addi x0, x0, 0` | No side effect possible from a bubble |
| Trap point | EX, reported in WB | All causes known in EX; keeps the trace in program order |
| Commit point / minstret | EX | Nothing can fail after EX; CSR reads stay in program order |
| Memories | Combinational (zero-wait) ports, instruction read in IF, data in MEM | Same memory interface and test harness as Step 5 |
| Divider kill | `kill` tied to `trapNow` | A division never traps here; it is a safety net for when interrupts are added |
| Misaligned loads/stores | Trap (cause 4 / 6, mtval = address) | Simplest correct option; allowed by the privileged spec |
| Misaligned branch/jump targets | Trap at the branch/jump (cause 0, mtval = target), rd not written | Required with IALIGN = 32 |
| EBREAK mtval | pc | Allowed (pc or 0) |
| ECALL mtval | 0 | Required |
| Illegal-instruction mtval | The instruction word | Allowed, helps debugging |
| FENCE | No-op | Single hart, in-order, no caches |
| FENCE.I | Illegal | Zifencei is not part of the ISA string |
| WFI | No-op | Allowed; there are no interrupts to wait for |
| mtvec | Direct mode only, low two bits read as 0 | WARL; simplest |
| mepc | Bits 1:0 read as 0 | IALIGN = 32 |
| misa | `0x40001100` (RV32, I, M), writes ignored | WARL; reports exactly the implemented extensions |
| mstatus | MIE (bit 3) and MPIE (bit 7) writable, MPP fixed to 11 | Machine mode only |
| mie | Only MSIE, MTIE, MEIE bits writable | WARL |
| mip, mstatush | Read 0, writes ignored | No interrupt sources |
| mcycle | Counts every clock, including divider wait cycles | It measures time |
| minstret | Counts retired instructions only (not traps, not wait cycles) | Spec definition |
| Counter writes | A CSR write replaces one 32-bit half of the incremented value | Deterministic and easy to model |
| cycle/instret (user) | Read-only shadows of mcycle/minstret; `time` not implemented (illegal) | No real-time clock |
| Unknown CSR / write to read-only CSR | Illegal instruction | Required |
| x0 | Hardwired zero in the register file; writes ignored | Required |

## Verification

- Unit tests per block: ALU (all ops, edge pairs and random), ImmGen (all formats), RegFile (x0, read during write),
  Decoder (every instruction and every major opcode, legal and illegal), CsrFile (RW/RS/RC, WARL, illegal, counters,
  trap/mret), Multiplier (edge pairs and random against BigInt), DivUnit (edge pairs, random, latency, kill, handshake).
- Pipeline tests: `CoreTimingSpec` checks the cycle count of all 56 instructions including every redirect bubble,
  forwarding at distances 1-3 (no stall), load-use stalls (rs1, rs2, store data) and no false stalls, and that the two
  wrong-path instructions behind a taken branch, a jump, a trap and MRET have no effect.
- Program tests: hand-assembled programs run on `Core` and on `RefModel` in lockstep; every retirement and trap is
  compared field by field (pc, next pc, instruction, rd, rd value, memory address/size/data, cause), and final register
  values are also checked against independently computed constants.
