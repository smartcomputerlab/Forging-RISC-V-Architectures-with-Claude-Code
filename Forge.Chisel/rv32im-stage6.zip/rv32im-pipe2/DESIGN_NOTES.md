# Design notes: RV32IM 2-stage pipelined core (IF / EX) with a sequential divider

## Architecture

| Item | Choice |
|---|---|
| ISA | RV32I + M (MUL, MULH, MULHSU, MULHU, DIV, DIVU, REM, REMU) + Zicsr, machine mode only |
| Microarchitecture | 2-stage pipeline: IF (fetch) and EX (decode, register read, execute, memory, write-back), derived from the Step 5 single-cycle core |
| Branch prediction | Static not-taken: fetch always continues at pc + 4; a taken branch/jump, trap or MRET costs 1 bubble |
| Reset | pc = `0x80000000` (`Core(resetPc = ...)`), all registers and CSRs = 0 |
| Memories | Harvard, zero-wait ports: instruction and data read data are combinational functions of the address; stores land at the clock edge under a 4-bit byte mask |
| Multiply | Combinational, one shared 33 × 33 signed multiplier for all four MUL variants (1 cycle) |
| Divide | Sequential restoring divider, one quotient bit per cycle: 34 cycles per DIV/DIVU/REM/REMU, 2 cycles for divide-by-zero and signed overflow |
| Interrupts | None (`mie`/`mip` exist for software but nothing raises an interrupt) |

## Pipeline

```
            IF stage                       IfEx register                  EX stage
 fetchPc ──► imem ──► inst ──►  ┌ valid ┐  ──► Decoder, RegFile read, ImmGen
    ▲                           │ pc    │      Alu / Multiplier / DivUnit (33 cycles)
    │  +4 (predict not taken)   └ inst  ┘      dmem, CsrFile, write-back to RegFile
    └────────── redirect: nextPc (taken branch/jump, trap, MRET) ◄────────┘
```

| Event in EX | fetchPc | IfEx |
|---|---|---|
| Normal (incl. not-taken branch) | fetchPc + 4 | {valid, fetchPc, imem data} |
| Taken branch, JAL, JALR, trap, MRET (`redirect`) | nextPc (the target) | bubble (wrong-path instruction discarded) |
| DIV/DIVU/REM/REMU in progress (`divStall`) | hold | hold |

## Hazards

| Hazard | Handling |
|---|---|
| Data (RAW) | None possible: registers are read and written in EX, so the next instruction reads the value written at the end of the previous EX cycle. No forwarding, no interlock |
| Control | Resolved in EX; 1-cycle penalty for every taken branch, JAL, JALR, trap and MRET; not-taken branches are free |
| Structural (divider) | Both stages freeze while the divider works (33 cycles, 1 for divide-by-zero and overflow) |
| CSR / memory ordering | All CSR and memory accesses happen in EX, in program order; wrong-path instructions never reach EX |

## Execution rules

Every cycle EX does exactly one of:

1. **retire** (`trace.valid`): one instruction completes and its effects are visible at the edge;
2. **trap** (`trace.trap`): the instruction changes nothing except mepc, mcause, mtval, mstatus; fetch is redirected to mtvec;
3. **nothing** (both low): a bubble (after reset, or after a redirect) or a cycle waiting for the divider; no state changes
   (checked by assertions in `Core`).

Cycles per instruction: 1, plus 1 if the previous instruction redirected fetch, plus 33 for a regular
DIV/DIVU/REM/REMU (1 for divide-by-zero or overflow). The first instruction after reset arrives after one fill bubble.

Exception priority: illegal instruction (2) > ECALL (11) > EBREAK (3) > load misaligned (4) > store misaligned (6) >
instruction address misaligned (0). mepc is the pc of the instruction in EX (precise exceptions).

## Choices made where the specification leaves an option

| Topic | Choice | Why |
|---|---|---|
| M-extension decoding | The core recognises OP + funct7 = 0000001 itself; the Decoder still reports it illegal | Keeps the Step 3 RV32I decoder (and its tests) unchanged; same pattern as Step 4 |
| Multiplier | One 33 × 33 signed product, operands extended by sign or zero | One array serves MUL/MULH/MULHSU/MULHU; maps to DSP blocks |
| Divider | Restoring division on magnitudes, signs fixed at the end, 1 bit/cycle | Smallest correct sequential divider: one 33-bit subtract/compare and four 32-bit registers |
| Divider special cases | x/0 and MIN/-1 answered in 1 cycle without iterating | They are defined by the spec's table, no division needed |
| Divider stall | fetchPc and IfEx freeze, `busy` stays high through the response cycle | The division stays in EX and cannot start twice |
| Pipeline depth | 2 stages, register read and write-back in the same stage | Removes all data hazards: no forwarding logic needed |
| Branch resolution | In EX, target fetched in the next cycle (1 bubble) | Keeps the EX-to-imem path out of the critical path; static not-taken needs no predictor state |
| Bubble encoding | IfEx.valid = 0, EX executes `addi x0, x0, 0` and `retire` is gated | No side effect possible from a bubble |
| Instruction memory | Still a combinational (zero-wait) port, read in IF | Same memory interface and test harness as Step 5 |
| Divider kill | `kill` tied to `trapNow` | A division never traps here; it is a safety net for when interrupts are added |
| Misaligned loads/stores | Trap (cause 4 / 6, mtval = address) | Simplest correct option; allowed by the privileged spec |
| Misaligned branch/jump targets | Trap at the branch/jump (cause 0, mtval = target), rd not written | Required with IALIGN = 32 |
| EBREAK mtval | pc | Allowed (pc or 0) |
| ECALL mtval | 0 | Required |
| Illegal-instruction mtval | The instruction word | Allowed, helps debugging |
| FENCE | No-op | Single hart, in-order, no caches |
| FENCE.I | Illegal | Zifencei is not part of the ISA string |
| WFI | No-op | Allowed; there are no interrupts to wait for |
| mtvec | Direct mode only, low two bits read as 0 | WARL; simplest |
| mepc | Bits 1:0 read as 0 | IALIGN = 32 |
| misa | `0x40001100` (RV32, I, M), writes ignored | WARL; reports exactly the implemented extensions |
| mstatus | MIE (bit 3) and MPIE (bit 7) writable, MPP fixed to 11 | Machine mode only |
| mie | Only MSIE, MTIE, MEIE bits writable | WARL |
| mip, mstatush | Read 0, writes ignored | No interrupt sources |
| mcycle | Counts every clock, including divider wait cycles | It measures time |
| minstret | Counts retired instructions only (not traps, not wait cycles) | Spec definition |
| Counter writes | A CSR write replaces one 32-bit half of the incremented value | Deterministic and easy to model |
| cycle/instret (user) | Read-only shadows of mcycle/minstret; `time` not implemented (illegal) | No real-time clock |
| Unknown CSR / write to read-only CSR | Illegal instruction | Required |
| x0 | Hardwired zero in the register file; writes ignored | Required |

## Verification

- Unit tests per block: ALU (all ops, edge pairs and random), ImmGen (all formats), RegFile (x0, read during write),
  Decoder (every instruction and every major opcode, legal and illegal), CsrFile (RW/RS/RC, WARL, illegal, counters,
  trap/mret), Multiplier (edge pairs and random against BigInt), DivUnit (edge pairs, random, latency, kill, handshake).
- Pipeline tests: `CoreTimingSpec` checks the cycle count of all 56 instructions including every redirect bubble,
  and that wrong-path instructions behind a taken branch, a jump, a trap and MRET have no effect.
- Program tests: hand-assembled programs run on `Core` and on `RefModel` in lockstep; every retirement and trap is
  compared field by field (pc, next pc, instruction, rd, rd value, memory address/size/data, cause), and final register
  values are also checked against independently computed constants.
