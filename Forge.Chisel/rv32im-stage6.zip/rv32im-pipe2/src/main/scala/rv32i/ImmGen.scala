package rv32i

import chisel3._
import chisel3.util._

/** Immediate generator for the I, S, B, U and J formats (sign-extended to 32 bits). */
class ImmGen extends Module {
  val io = IO(new Bundle {
    val inst = Input(UInt(32.W))
    val sel  = Input(ImmSel())
    val imm  = Output(UInt(32.W))
  })

  val i    = io.inst
  val sign = i(31)
  val immI = Cat(Fill(21, sign), i(30, 20))
  val immS = Cat(Fill(21, sign), i(30, 25), i(11, 7))
  val immB = Cat(Fill(20, sign), i(7), i(30, 25), i(11, 8), 0.U(1.W))
  val immU = Cat(i(31, 12), 0.U(12.W))
  val immJ = Cat(Fill(12, sign), i(19, 12), i(20), i(30, 21), 0.U(1.W))

  io.imm := immI
  switch(io.sel) {
    is(ImmSel.I) { io.imm := immI }
    is(ImmSel.S) { io.imm := immS }
    is(ImmSel.B) { io.imm := immB }
    is(ImmSel.U) { io.imm := immU }
    is(ImmSel.J) { io.imm := immJ }
  }
}
