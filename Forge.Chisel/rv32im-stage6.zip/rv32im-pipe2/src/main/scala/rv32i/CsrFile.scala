package rv32i

import chisel3._
import chisel3.util._

/** Machine-mode CSRs for an RV32IM core without interrupts.
  *
  * CSR instruction interface (combinational read, write at the clock edge):
  *  - `en`: a CSR instruction is in execute; `addr`, `op` (funct3(1,0): 1 RW, 2 RS, 3 RC), `src` (rs1 value or
  *    zero-extended uimm) and `wrEn` (false for CSRRS/CSRRC with rs1/uimm = 0) describe it.
  *  - `rdata` is the old value; `illegal` is high for an unknown CSR or a write to a read-only CSR.
  *  - The write happens only when `commit` is high (the instruction retires) and the access is legal.
  *
  * Trap interface: `trapEnter` saves mepc/mcause/mtval and MIE -> MPIE, MIE := 0.
  * `mretEnter` restores MIE := MPIE, MPIE := 1. mstatus.MPP is hardwired to 3 (M-mode only).
  *
  * Counters: mcycle counts every clock cycle (including cycles spent waiting for the divider);
  * minstret counts retired instructions (`commit`). A CSR write to one half of a counter replaces that half
  * of the incremented value. cycle/instret(h) are read-only shadows. There is no `time` CSR.
  */
class CsrFile(hartId: Int = 0) extends Module {
  val io = IO(new Bundle {
    val addr      = Input(UInt(12.W))
    val en        = Input(Bool())
    val op        = Input(UInt(2.W))
    val src       = Input(UInt(32.W))
    val wrEn      = Input(Bool())
    val rdata     = Output(UInt(32.W))
    val illegal   = Output(Bool())
    val commit    = Input(Bool())
    val trapEnter = Input(Bool())
    val trapCause = Input(UInt(32.W))
    val trapPc    = Input(UInt(32.W))
    val trapVal   = Input(UInt(32.W))
    val mretEnter = Input(Bool())
    val mtvecBase = Output(UInt(32.W))
    val mepc      = Output(UInt(32.W))
  })

  val mie_     = RegInit(false.B) // mstatus.MIE
  val mpie     = RegInit(false.B) // mstatus.MPIE
  val mieReg   = RegInit(0.U(32.W))
  val mtvec    = RegInit(0.U(32.W))
  val mscratch = RegInit(0.U(32.W))
  val mepc     = RegInit(0.U(32.W))
  val mcause   = RegInit(0.U(32.W))
  val mtval    = RegInit(0.U(32.W))
  val mcycle   = RegInit(0.U(64.W))
  val minstret = RegInit(0.U(64.W))

  val mstatus = Cat(0.U(19.W), "b11".U(2.W), 0.U(3.W), mpie, 0.U(3.W), mie_, 0.U(3.W)) // MPP = 11

  val A = CsrAddr
  val table: Seq[(Int, UInt)] = Seq(
    A.mstatus   -> mstatus,
    A.misa      -> A.MisaValue.U(32.W),
    A.mie       -> mieReg,
    A.mtvec     -> mtvec,
    A.mstatush  -> 0.U(32.W),
    A.mscratch  -> mscratch,
    A.mepc      -> mepc,
    A.mcause    -> mcause,
    A.mtval     -> mtval,
    A.mip       -> 0.U(32.W),
    A.mcycle    -> mcycle(31, 0),
    A.mcycleh   -> mcycle(63, 32),
    A.minstret  -> minstret(31, 0),
    A.minstreth -> minstret(63, 32),
    A.cycle     -> mcycle(31, 0),
    A.cycleh    -> mcycle(63, 32),
    A.instret   -> minstret(31, 0),
    A.instreth  -> minstret(63, 32),
    A.mvendorid -> 0.U(32.W),
    A.marchid   -> 0.U(32.W),
    A.mimpid    -> 0.U(32.W),
    A.mhartid   -> hartId.U(32.W)
  )

  val hit      = table.map { case (a, _) => io.addr === a.U }
  val known    = hit.reduce(_ || _)
  val old      = Mux1H(hit, table.map(_._2))
  val readOnly = io.addr(11, 10) === 3.U
  io.rdata   := Mux(known, old, 0.U)
  io.illegal := io.en && (!known || (readOnly && io.wrEn))

  val wval = MuxLookup(io.op, io.src)(Seq(
    1.U -> io.src,
    2.U -> (old | io.src),
    3.U -> (old & ~io.src)
  ))
  val doWrite = io.en && io.wrEn && io.commit && !io.illegal
  def wr(a: Int): Bool = doWrite && io.addr === a.U

  // ---- counters: increment, then a CSR write replaces the written half
  val cycleInc   = mcycle + 1.U
  val instretInc = minstret + io.commit.asUInt
  mcycle := MuxCase(cycleInc, Seq(
    wr(A.mcycle) -> Cat(cycleInc(63, 32), wval),
    wr(A.mcycleh)        -> Cat(wval, cycleInc(31, 0))
  ))
  minstret := MuxCase(instretInc, Seq(
    wr(A.minstret) -> Cat(instretInc(63, 32), wval),
    wr(A.minstreth)        -> Cat(wval, instretInc(31, 0))
  ))

  // ---- other writable CSRs (WARL masks)
  when(wr(A.mstatus)) { mie_ := wval(3); mpie := wval(7) }
  when(wr(A.mie))     { mieReg := wval & "h888".U }
  when(wr(A.mtvec))   { mtvec := Cat(wval(31, 2), 0.U(2.W)) }  // direct mode only
  when(wr(A.mscratch)) { mscratch := wval }
  when(wr(A.mepc))    { mepc := Cat(wval(31, 2), 0.U(2.W)) }   // IALIGN = 32
  when(wr(A.mcause))  { mcause := wval }
  when(wr(A.mtval))   { mtval := wval }
  // misa, mstatush, mip: writes ignored (WARL, read-only zero / fixed)

  // ---- trap entry and return
  when(io.trapEnter) {
    mepc   := io.trapPc
    mcause := io.trapCause
    mtval  := io.trapVal
    mpie   := mie_
    mie_   := false.B
  }.elsewhen(io.mretEnter) {
    mie_ := mpie
    mpie := true.B
  }

  io.mtvecBase := mtvec
  io.mepc      := mepc
}
