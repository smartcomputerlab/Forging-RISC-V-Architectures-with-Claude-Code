package rv32i

import scala.collection.mutable

/** Sparse word-addressed memory for simulation (unwritten words read as 0). Addresses are 32-bit unsigned. */
class SimMemory {
  private val words = mutable.Map.empty[Long, Long]
  def readWord(addr: Long): Long = words.getOrElse(addr & 0xFFFFFFFCL, 0L)
  def writeWord(addr: Long, v: Long): Unit = words(addr & 0xFFFFFFFCL) = v & 0xFFFFFFFFL
  /** Store `data` (already shifted into byte lanes) under the 4-bit byte mask `strb`. */
  def write(addr: Long, data: Long, strb: Int): Unit = {
    var w = readWord(addr)
    for (k <- 0 until 4 if ((strb >> k) & 1) == 1) {
      val m = 0xFFL << (8 * k)
      w = (w & ~m) | (data & m)
    }
    writeWord(addr, w)
  }
  def load(base: Long, prog: Seq[Long]): Unit = prog.zipWithIndex.foreach { case (w, i) => writeWord(base + 4L * i, w) }
}

/** What one instruction did, in the same terms as the hardware [[Trace]] (values are 32-bit unsigned). */
final case class TraceRecord(
  trap: Boolean,
  cause: Int,
  pc: Long,
  pcNext: Long,
  inst: Long,
  rdAddr: Int,     // 0 when no register is written
  rdData: Long,    // 0 when no register is written
  memRe: Boolean,
  memWe: Boolean,
  memAddr: Long,   // meaningful when memRe || memWe
  memSize: Int,
  memWdata: Long   // store data, not shifted into lanes
)

/** Instruction-level reference model of the RV32IM core: same ISA subset, same CSRs, same traps and the same
  * decisions where the spec leaves a choice (see the Core and CsrFile scaladoc).
  *
  * `step(cycle)` executes one instruction. `cycle` is the hardware clock cycle (0 = first cycle after reset)
  * in which it retires or traps; it is only used to give mcycle/cycle the value the hardware would read.
  */
class RefModel(val mem: SimMemory, resetPc: Long = 0x80000000L, hartId: Int = 0) {
  private val M32 = 0xFFFFFFFFL
  val x: Array[Long] = Array.fill(32)(0L)
  var pc: Long = resetPc

  var mstatusMIE  = false
  var mstatusMPIE = false
  var mie         = 0L
  var mtvec       = 0L
  var mscratch    = 0L
  var mepc        = 0L
  var mcause      = 0L
  var mtval       = 0L
  var minstret    = 0L                 // 64-bit, Long wraps like the hardware register
  private var mcycleOffset = 0L        // mcycle(t) = t + mcycleOffset (mod 2^64)

  private def sext(v: Long, bits: Int): Long = (v << (64 - bits)) >> (64 - bits)
  private def s32(v: Long): Long = sext(v & M32, 32)
  private def reg(i: Int): Long = if (i == 0) 0L else x(i)

  private def mcycle(t: Long): Long = t + mcycleOffset

  private val readOnly = (a: Int) => ((a >> 10) & 3) == 3

  private def csrRead(a: Int, t: Long): Option[Long] = {
    val v: Option[Long] = a match {
      case CsrAddr.mstatus   => Some((3L << 11) | ((if (mstatusMPIE) 1L else 0L) << 7) | ((if (mstatusMIE) 1L else 0L) << 3))
      case CsrAddr.misa      => Some(CsrAddr.MisaValue)
      case CsrAddr.mie       => Some(RefModel.this.mie)
      case CsrAddr.mtvec     => Some(RefModel.this.mtvec)
      case CsrAddr.mstatush  => Some(0L)
      case CsrAddr.mscratch  => Some(RefModel.this.mscratch)
      case CsrAddr.mepc      => Some(RefModel.this.mepc)
      case CsrAddr.mcause    => Some(RefModel.this.mcause)
      case CsrAddr.mtval     => Some(RefModel.this.mtval)
      case CsrAddr.mip       => Some(0L)
      case CsrAddr.mcycle | CsrAddr.cycle       => Some(mcycle(t))
      case CsrAddr.mcycleh | CsrAddr.cycleh     => Some(mcycle(t) >>> 32)
      case CsrAddr.minstret | CsrAddr.instret   => Some(RefModel.this.minstret)
      case CsrAddr.minstreth | CsrAddr.instreth => Some(RefModel.this.minstret >>> 32)
      case CsrAddr.mvendorid | CsrAddr.marchid | CsrAddr.mimpid => Some(0L)
      case CsrAddr.mhartid   => Some(hartId.toLong)
      case _           => None
    }
    v.map(_ & M32)
  }

  private def replaceHalf(full: Long, high: Boolean, v: Long): Long =
    if (high) (full & 0xFFFFFFFFL) | ((v & M32) << 32) else (full & ~0xFFFFFFFFL) | (v & M32)

  /** Executes one instruction and returns what it did. */
  def step(cycle: Long): TraceRecord = {
    val inst   = mem.readWord(pc)
    val opcode = (inst & 0x7f).toInt
    val rd     = ((inst >> 7) & 31).toInt
    val f3     = ((inst >> 12) & 7).toInt
    val rs1    = ((inst >> 15) & 31).toInt
    val rs2    = ((inst >> 20) & 31).toInt
    val f7     = ((inst >> 25) & 0x7f).toInt
    val a      = reg(rs1)
    val b      = reg(rs2)
    val immI   = sext(inst >> 20, 12)
    val immS   = sext(((inst >> 25) << 5) | ((inst >> 7) & 31), 12)
    val immB   = sext((((inst >> 31) & 1) << 12) | (((inst >> 7) & 1) << 11) | (((inst >> 25) & 0x3f) << 5) | (((inst >> 8) & 0xf) << 1), 13)
    val immU   = (inst & 0xFFFFF000L)
    val immJ   = sext((((inst >> 31) & 1) << 20) | (((inst >> 12) & 0xff) << 12) | (((inst >> 20) & 1) << 11) | (((inst >> 21) & 0x3ff) << 1), 21)
    val pc4    = (pc + 4) & M32

    var illegal  = false
    var ecall    = false
    var ebreak   = false
    var mret     = false
    var wb: Option[Long] = None          // value for rd
    var next     = pc4
    var ctlTarget: Option[Long] = None   // taken branch / jump target
    var memRe    = false
    var memWe    = false
    var memAddr  = 0L
    var memSize  = f3 & 3
    var storeData = 0L
    var loadMis  = false
    var storeMis = false
    var csrWrite: Option[(Int, Long)] = None

    def alu(op: Int, alt: Boolean, a: Long, b: Long): Long = {
      val sh = (b & 31).toInt
      (op match {
        case 0 => if (alt) a - b else a + b
        case 1 => a << sh
        case 2 => if (s32(a) < s32(b)) 1L else 0L
        case 3 => if (a < b) 1L else 0L
        case 4 => a ^ b
        case 5 => if (alt) s32(a) >> sh else a >>> sh
        case 6 => a | b
        case _ => a & b
      }) & M32
    }
    def misaligned(addr: Long, size: Int) = (size == 2 && (addr & 3) != 0) || (size == 1 && (addr & 1) != 0)

    opcode match {
      case Opcode.LUI   => wb = Some(immU)
      case Opcode.AUIPC => wb = Some((pc + immU) & M32)
      case Opcode.JAL   => wb = Some(pc4); ctlTarget = Some((pc + immJ) & M32)
      case Opcode.JALR if f3 == 0 =>
        wb = Some(pc4); ctlTarget = Some(((a + immI) & M32) & ~1L)
      case Opcode.BRANCH if f3 != 2 && f3 != 3 =>
        val taken = f3 match {
          case 0 => a == b
          case 1 => a != b
          case 4 => s32(a) < s32(b)
          case 5 => s32(a) >= s32(b)
          case 6 => a < b
          case _ => a >= b
        }
        if (taken) ctlTarget = Some((pc + immB) & M32)
      case Opcode.LOAD if Set(0, 1, 2, 4, 5)(f3) =>
        memAddr = (a + immI) & M32
        if (misaligned(memAddr, f3 & 3)) loadMis = true
        else {
          memRe = true
          val w = mem.readWord(memAddr)
          val sh = 8 * (memAddr & 3).toInt
          wb = Some(f3 match {
            case 0 => sext((w >>> sh) & 0xff, 8) & M32
            case 1 => sext((w >>> sh) & 0xffff, 16) & M32
            case 2 => w
            case 4 => (w >>> sh) & 0xff
            case _ => (w >>> sh) & 0xffff
          })
        }
      case Opcode.STORE if f3 <= 2 =>
        memAddr = (a + immS) & M32
        if (misaligned(memAddr, f3)) storeMis = true
        else {
          memWe = true
          storeData = f3 match { case 0 => b & 0xff; case 1 => b & 0xffff; case _ => b }
        }
      case Opcode.OP_IMM if !(f3 == 1 && f7 != 0) && !(f3 == 5 && f7 != 0 && f7 != 0x20) =>
        wb = Some(alu(f3, f3 == 5 && f7 == 0x20, a, immI & M32))
      case Opcode.OP if f7 == 0 || (f7 == 0x20 && (f3 == 0 || f3 == 5)) =>
        wb = Some(alu(f3, f7 == 0x20, a, b))
      case Opcode.OP if f7 == 1 => // M extension
        wb = Some(f3 match {
          case 0 => (s32(a) * s32(b)) & M32
          case 1 => ((BigInt(s32(a)) * BigInt(s32(b))) >> 32).toLong & M32
          case 2 => ((BigInt(s32(a)) * BigInt(b)) >> 32).toLong & M32
          case 3 => ((BigInt(a) * BigInt(b)) >> 32).toLong & M32
          case _ => DivRef(f3 & 3, BigInt(a), BigInt(b)).toLong & M32
        })
      case Opcode.MISC_MEM if f3 == 0 => // FENCE: no-op
      case Opcode.SYSTEM if f3 == 0 =>
        inst match {
          case 0x00000073L => ecall = true
          case 0x00100073L => ebreak = true
          case 0x30200073L => mret = true; next = mepc
          case 0x10500073L => // WFI: no-op
          case _ => illegal = true
        }
      case Opcode.SYSTEM if f3 != 4 =>
        val addr = ((inst >> 20) & 0xfff).toInt
        val src  = if ((f3 & 4) != 0) rs1.toLong else a
        val wrEn = (f3 & 3) == 1 || rs1 != 0
        csrRead(addr, cycle) match {
          case Some(old) if !(readOnly(addr) && wrEn) =>
            wb = Some(old)
            if (wrEn) csrWrite = Some(addr -> ((f3 & 3) match {
              case 1 => src
              case 2 => old | src
              case _ => old & ~src & M32
            }))
          case _ => illegal = true
        }
      case _ => illegal = true
    }

    val fetchMis = !illegal && ctlTarget.exists(t => (t & 2) != 0)
    val trap = illegal || ecall || ebreak || loadMis || storeMis || fetchMis

    if (trap) {
      val (cause, tval) =
        if (illegal) (Cause.IllegalInstruction, inst)
        else if (ecall) (Cause.EcallFromM, 0L)
        else if (ebreak) (Cause.Breakpoint, pc)
        else if (loadMis) (Cause.LoadAddrMisaligned, memAddr)
        else if (storeMis) (Cause.StoreAddrMisaligned, memAddr)
        else (Cause.InstrAddrMisaligned, ctlTarget.get)
      mepc = pc; mcause = cause.toLong; mtval = tval & M32
      mstatusMPIE = mstatusMIE; mstatusMIE = false
      val rec = TraceRecord(true, cause, pc, mtvec, inst, 0, 0L, false, false, memAddr, memSize, 0L)
      pc = mtvec
      return rec
    }

    // ---- retire
    if (mret) { mstatusMIE = mstatusMPIE; mstatusMPIE = true }
    ctlTarget.foreach(t => next = t)
    if (memWe) {
      val sh = 8 * (memAddr & 3).toInt
      val strb = f3 match { case 0 => 1 << (memAddr & 3).toInt; case 1 => if ((memAddr & 2) != 0) 0xc else 0x3; case _ => 0xf }
      mem.write(memAddr, (storeData << sh) & M32, strb)
    }
    var instretWritten = false
    csrWrite.foreach { case (addr, v) =>
      addr match {
        case CsrAddr.mstatus   => mstatusMIE = ((v >> 3) & 1) == 1; mstatusMPIE = ((v >> 7) & 1) == 1
        case CsrAddr.mie       => this.mie = v & 0x888
        case CsrAddr.mtvec     => this.mtvec = v & 0xFFFFFFFCL
        case CsrAddr.mscratch  => this.mscratch = v
        case CsrAddr.mepc      => this.mepc = v & 0xFFFFFFFCL
        case CsrAddr.mcause    => this.mcause = v
        case CsrAddr.mtval     => this.mtval = v
        case CsrAddr.mcycle | CsrAddr.mcycleh =>
          val nextVal = replaceHalf(mcycle(cycle) + 1, addr == CsrAddr.mcycleh, v)
          mcycleOffset = nextVal - (cycle + 1)
        case CsrAddr.minstret | CsrAddr.minstreth =>
          minstret = replaceHalf(minstret + 1, addr == CsrAddr.minstreth, v); instretWritten = true
        case _ => // misa, mstatush, mip: writes ignored
      }
    }
    if (!instretWritten) minstret += 1
    val rdW = wb.isDefined && rd != 0
    if (rdW) x(rd) = wb.get & M32
    val rec = TraceRecord(false, 0, pc, next, inst, if (rdW) rd else 0, if (rdW) wb.get & M32 else 0L,
      memRe, memWe, memAddr, memSize, storeData)
    pc = next
    rec
  }
}
