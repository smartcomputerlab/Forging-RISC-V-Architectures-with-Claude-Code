package rv32i

import chisel3._

/** 32 x 32-bit register file: two combinational read ports, one write port, x0 hardwired to zero.
  * All registers reset to 0. A read in the cycle of a write returns the old value (the write lands at the edge).
  */
class RegFile extends Module {
  val io = IO(new Bundle {
    val rs1   = Input(UInt(5.W))
    val rs2   = Input(UInt(5.W))
    val rd1   = Output(UInt(32.W))
    val rd2   = Output(UInt(32.W))
    val we    = Input(Bool())
    val waddr = Input(UInt(5.W))
    val wdata = Input(UInt(32.W))
  })

  val regs = RegInit(VecInit(Seq.fill(32)(0.U(32.W))))

  io.rd1 := Mux(io.rs1 === 0.U, 0.U, regs(io.rs1))
  io.rd2 := Mux(io.rs2 === 0.U, 0.U, regs(io.rs2))

  when(io.we && io.waddr =/= 0.U) {
    regs(io.waddr) := io.wdata
  }
}
