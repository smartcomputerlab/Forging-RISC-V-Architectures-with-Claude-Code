package rv32i

import chisel3._
import chisel3.util._

/** Step 4: combinational ("parallel") multiplier for MUL, MULH, MULHSU, MULHU (fn = funct3(1,0)).
  *
  * One shared (33 x 33) signed multiplier: each operand is extended by one bit, with its sign bit for
  * a signed operand (MULH: both, MULHSU: rs1) and with 0 otherwise. The low 64 bits of that product are
  * the exact 64-bit result of every variant, so one array serves all four instructions.
  *   fn 0 MUL    -> product[31:0]  (same bits for signed and unsigned)
  *   fn 1 MULH   -> product[63:32] signed   x signed
  *   fn 2 MULHSU -> product[63:32] signed   x unsigned
  *   fn 3 MULHU  -> product[63:32] unsigned x unsigned
  */
class Multiplier extends Module {
  val io = IO(new Bundle {
    val fn     = Input(UInt(2.W))
    val a      = Input(UInt(32.W))   // rs1
    val b      = Input(UInt(32.W))   // rs2
    val result = Output(UInt(32.W))
  })

  val aSigned = io.fn === 1.U || io.fn === 2.U        // MULH, MULHSU
  val bSigned = io.fn === 1.U                         // MULH
  val aExt    = Cat(aSigned && io.a(31), io.a).asSInt // 33 bits
  val bExt    = Cat(bSigned && io.b(31), io.b).asSInt
  val product = (aExt * bExt).asUInt                  // 66 bits, low 64 are exact

  io.result := Mux(io.fn === 0.U, product(31, 0), product(63, 32))
}
