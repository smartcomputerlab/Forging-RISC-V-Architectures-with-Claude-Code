package rv32i

import chisel3._
import chisel3.util._

/** 32-bit ALU for RV32I. Shifts use the low 5 bits of `b`. */
class Alu extends Module {
  val io = IO(new Bundle {
    val op = Input(AluOp())
    val a  = Input(UInt(32.W))
    val b  = Input(UInt(32.W))
    val y  = Output(UInt(32.W))
  })

  val sh = io.b(4, 0)
  io.y := io.a + io.b
  switch(io.op) {
    is(AluOp.ADD)  { io.y := io.a + io.b }
    is(AluOp.SUB)  { io.y := io.a - io.b }
    is(AluOp.SLL)  { io.y := (io.a << sh)(31, 0) }
    is(AluOp.SLT)  { io.y := (io.a.asSInt < io.b.asSInt).asUInt }
    is(AluOp.SLTU) { io.y := (io.a < io.b).asUInt }
    is(AluOp.XOR)  { io.y := io.a ^ io.b }
    is(AluOp.SRL)  { io.y := io.a >> sh }
    is(AluOp.SRA)  { io.y := (io.a.asSInt >> sh).asUInt }
    is(AluOp.OR)   { io.y := io.a | io.b }
    is(AluOp.AND)  { io.y := io.a & io.b }
  }
}
