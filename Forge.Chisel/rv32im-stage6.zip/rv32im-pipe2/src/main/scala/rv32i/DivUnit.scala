package rv32i

import chisel3._
import chisel3.util._

/** One division request. `op` is funct3(1,0) of the instruction:
  * 0 = DIV, 1 = DIVU, 2 = REM, 3 = REMU (funct3 = 100, 101, 110, 111).
  */
class DivReq(xlen: Int) extends Bundle {
  val op = UInt(2.W)
  val a  = UInt(xlen.W) // rs1: dividend
  val b  = UInt(xlen.W) // rs2: divisor
}

/** Sequential divider for DIV, DIVU, REM and REMU (restoring division, one quotient bit per cycle).
  *
  * Handshake
  *  - `req` is accepted (req.fire) only while the unit is idle (`req.ready`).
  *  - `resp.valid` is high for exactly one cycle with the result; the unit is back to idle on the
  *    next cycle. `req.ready` is low during that response cycle, so a stalled core that keeps
  *    `req.valid` high on the same instruction cannot start it twice.
  *  - `kill` abandons a division in progress (for a trap or interrupt taken while the core is
  *    stalled). Division has no side effects, so the instruction can simply be re-executed later.
  *
  * Latency, counted in clock edges from the accepting edge to the response cycle
  *  - 1 for divide-by-zero and for signed overflow (most negative value / -1)
  *  - xlen + 1 otherwise (33 for RV32)
  *
  * Results follow the RISC-V spec (unprivileged ISA, M extension, division table):
  *  - x / 0: quotient = all ones, remainder = x
  *  - signed overflow MIN / -1: quotient = MIN, remainder = 0
  *  - quotient rounds toward zero; the remainder takes the sign of the dividend.
  */
class DivUnit(xlen: Int = 32) extends Module {
  require(xlen >= 2)

  val io = IO(new Bundle {
    val req  = Flipped(Decoupled(new DivReq(xlen)))
    val resp = Valid(UInt(xlen.W))
    val kill = Input(Bool())
    val busy = Output(Bool()) // high while busy or presenting the response
  })

  private val sIdle :: sBusy :: sDone :: Nil = Enum(3)
  private val state = RegInit(sIdle)

  private val minInt  = (BigInt(1) << (xlen - 1)).U(xlen.W)
  private val allOnes = ((BigInt(1) << xlen) - 1).U(xlen.W)

  private val quot    = Reg(UInt(xlen.W)) // dividend magnitude shifts out (MSB first) as quotient bits shift in
  private val rem     = Reg(UInt(xlen.W)) // partial remainder, always < divisor
  private val divisor = Reg(UInt(xlen.W)) // divisor magnitude
  private val count   = Reg(UInt(log2Ceil(xlen).W))
  private val negQ    = Reg(Bool())
  private val negR    = Reg(Bool())
  private val wantRem = Reg(Bool())
  private val result  = Reg(UInt(xlen.W))

  io.req.ready  := state === sIdle
  io.resp.valid := state === sDone
  io.resp.bits  := result
  io.busy       := state =/= sIdle

  // ---------------------------------------------------------------- accept a request
  when(io.req.fire) {
    val a      = io.req.bits.a
    val b      = io.req.bits.b
    val signed = !io.req.bits.op(0)
    val isRem  = io.req.bits.op(1)
    val negA   = signed && a(xlen - 1)
    val negB   = signed && b(xlen - 1)

    wantRem := isRem
    negQ    := negA =/= negB
    negR    := negA
    quot    := Mux(negA, 0.U(xlen.W) - a, a)
    divisor := Mux(negB, 0.U(xlen.W) - b, b)
    rem     := 0.U
    count   := 0.U

    when(b === 0.U) {
      result := Mux(isRem, a, allOnes)
      state  := sDone
    }.elsewhen(signed && a === minInt && b === allOnes) {
      result := Mux(isRem, 0.U(xlen.W), minInt)
      state  := sDone
    }.otherwise {
      state := sBusy
    }
  }

  // ---------------------------------------------------------------- one quotient bit per cycle
  when(state === sBusy) {
    val shifted  = Cat(rem, quot(xlen - 1))      // xlen + 1 bits
    val fits     = shifted >= divisor
    val nextRem  = Mux(fits, shifted - divisor, shifted)(xlen - 1, 0)
    val nextQuot = Cat(quot(xlen - 2, 0), fits)

    rem   := nextRem
    quot  := nextQuot
    count := count + 1.U

    when(count === (xlen - 1).U) {
      val q = Mux(negQ, 0.U(xlen.W) - nextQuot, nextQuot)
      val r = Mux(negR, 0.U(xlen.W) - nextRem, nextRem)
      result := Mux(wantRem, r, q)
      state  := sDone
    }
  }

  when(state === sDone) {
    state := sIdle
  }

  when(io.kill) {
    state := sIdle
  }
}

/** Software reference for the four division instructions, for tests and for RefModel.
  * Values are unsigned xlen-bit numbers held in BigInt; `op` is funct3(1,0) as in [[DivReq]].
  */
object DivRef {
  def apply(op: Int, a: BigInt, b: BigInt, xlen: Int = 32): BigInt = {
    val mask   = (BigInt(1) << xlen) - 1
    val min    = BigInt(1) << (xlen - 1)
    def toS(v: BigInt): BigInt = if (v >= min) v - (BigInt(1) << xlen) else v
    val signed = (op & 1) == 0
    val isRem  = (op & 2) != 0

    if (b == 0) {
      if (isRem) a else mask
    } else if (signed) {
      val sa = toS(a)
      val sb = toS(b)
      if (sa == -min && sb == -1) {
        if (isRem) BigInt(0) else min
      } else {
        // BigInt division truncates toward zero and the remainder takes the dividend's sign,
        // which is exactly the RISC-V rule.
        (if (isRem) sa % sb else sa / sb) & mask
      }
    } else {
      if (isRem) a % b else a / b
    }
  }

  /** RV32 convenience form for models that keep registers in Int. */
  def int32(op: Int, a: Int, b: Int): Int =
    apply(op, BigInt(a & 0xFFFFFFFFL), BigInt(b & 0xFFFFFFFFL)).toInt
}
