package rv32i

import chisel3._
import chisel3.util._

/** RV32I + Zicsr + M-mode SYSTEM decoder (combinational).
  *
  * Every control output is false/default unless the instruction is legal, so an illegal instruction has no
  * side effect besides the trap. The M extension (OP with funct7 = 0000001) is reported illegal here on
  * purpose: the core recognises those eight instructions itself (Step 4 and Step 5).
  *
  * FENCE and WFI are legal and execute as no-ops. FENCE.I (Zifencei) is not implemented and is illegal.
  */
class Decoder extends Module {
  val io = IO(new Bundle {
    val inst        = Input(UInt(32.W))
    val rs1         = Output(UInt(5.W))
    val rs2         = Output(UInt(5.W))
    val rd          = Output(UInt(5.W))
    val immSel      = Output(ImmSel())
    val aluSrcA     = Output(ASrc())
    val aluSrcImm   = Output(Bool())
    val aluOp       = Output(AluOp())
    val branch      = Output(Bool())
    val jal         = Output(Bool())
    val jalr        = Output(Bool())
    val memRead     = Output(Bool())
    val memWrite    = Output(Bool())
    val memSize     = Output(UInt(2.W))
    val memUnsigned = Output(Bool())
    val wbSel       = Output(WbSel())
    val regWrite    = Output(Bool())
    val csr         = Output(Bool())
    val ecall       = Output(Bool())
    val ebreak      = Output(Bool())
    val mret        = Output(Bool())
    val illegal     = Output(Bool())
  })

  val inst   = io.inst
  val opcode = inst(6, 0)
  val f3     = inst(14, 12)
  val f7     = inst(31, 25)

  io.rs1 := inst(19, 15)
  io.rs2 := inst(24, 20)
  io.rd  := inst(11, 7)

  io.immSel      := ImmSel.I
  io.aluSrcA     := ASrc.RS1
  io.aluSrcImm   := false.B
  io.aluOp       := AluOp.ADD
  io.branch      := false.B
  io.jal         := false.B
  io.jalr        := false.B
  io.memRead     := false.B
  io.memWrite    := false.B
  io.memSize     := f3(1, 0)
  io.memUnsigned := f3(2)
  io.wbSel       := WbSel.ALU
  io.regWrite    := false.B
  io.csr         := false.B
  io.ecall       := false.B
  io.ebreak      := false.B
  io.mret        := false.B
  io.illegal     := true.B

  // funct3 -> ALU operation for OP and OP-IMM (funct7 bit 5 selects SUB / SRA)
  private def aluFor(alt: Bool): AluOp.Type = {
    val op = WireDefault(AluOp.ADD)
    switch(f3) {
      is(0.U) { op := Mux(alt, AluOp.SUB, AluOp.ADD) }
      is(1.U) { op := AluOp.SLL }
      is(2.U) { op := AluOp.SLT }
      is(3.U) { op := AluOp.SLTU }
      is(4.U) { op := AluOp.XOR }
      is(5.U) { op := Mux(alt, AluOp.SRA, AluOp.SRL) }
      is(6.U) { op := AluOp.OR }
      is(7.U) { op := AluOp.AND }
    }
    op
  }

  switch(opcode) {
    is(Opcode.LUI.U) {
      io.illegal   := false.B
      io.regWrite  := true.B
      io.immSel    := ImmSel.U
      io.aluSrcA   := ASrc.ZERO
      io.aluSrcImm := true.B
    }
    is(Opcode.AUIPC.U) {
      io.illegal   := false.B
      io.regWrite  := true.B
      io.immSel    := ImmSel.U
      io.aluSrcA   := ASrc.PC
      io.aluSrcImm := true.B
    }
    is(Opcode.JAL.U) {
      io.illegal  := false.B
      io.jal      := true.B
      io.regWrite := true.B
      io.wbSel    := WbSel.PC4
      io.immSel   := ImmSel.J
    }
    is(Opcode.JALR.U) {
      when(f3 === 0.U) {
        io.illegal   := false.B
        io.jalr      := true.B
        io.regWrite  := true.B
        io.wbSel     := WbSel.PC4
        io.aluSrcImm := true.B
      }
    }
    is(Opcode.BRANCH.U) {
      when(f3 =/= 2.U && f3 =/= 3.U) {
        io.illegal := false.B
        io.branch  := true.B
        io.immSel  := ImmSel.B
      }
    }
    is(Opcode.LOAD.U) {
      when(f3 === 0.U || f3 === 1.U || f3 === 2.U || f3 === 4.U || f3 === 5.U) {
        io.illegal   := false.B
        io.memRead   := true.B
        io.regWrite  := true.B
        io.wbSel     := WbSel.MEM
        io.aluSrcImm := true.B
      }
    }
    is(Opcode.STORE.U) {
      when(f3 === 0.U || f3 === 1.U || f3 === 2.U) {
        io.illegal   := false.B
        io.memWrite  := true.B
        io.immSel    := ImmSel.S
        io.aluSrcImm := true.B
      }
    }
    is(Opcode.OP_IMM.U) {
      val shiftOk = Mux(f3 === 1.U, f7 === 0.U, Mux(f3 === 5.U, f7 === 0.U || f7 === "b0100000".U, true.B))
      when(shiftOk) {
        io.illegal   := false.B
        io.regWrite  := true.B
        io.aluSrcImm := true.B
        io.aluOp     := aluFor(f3 === 5.U && f7(5))
      }
    }
    is(Opcode.OP.U) {
      val altOk = f7 === "b0100000".U && (f3 === 0.U || f3 === 5.U)
      when(f7 === 0.U || altOk) {
        io.illegal  := false.B
        io.regWrite := true.B
        io.aluOp    := aluFor(f7(5))
      }
    }
    is(Opcode.MISC_MEM.U) {
      when(f3 === 0.U) { io.illegal := false.B } // FENCE: no-op on this single-hart, in-order core
    }
    is(Opcode.SYSTEM.U) {
      when(f3 === 0.U) {
        when(inst === "h00000073".U) { io.illegal := false.B; io.ecall := true.B }
        when(inst === "h00100073".U) { io.illegal := false.B; io.ebreak := true.B }
        when(inst === "h30200073".U) { io.illegal := false.B; io.mret := true.B }
        when(inst === "h10500073".U) { io.illegal := false.B } // WFI: no-op (no interrupts)
      }.elsewhen(f3 =/= 4.U) {
        io.illegal  := false.B
        io.csr      := true.B
        io.regWrite := true.B
        io.wbSel    := WbSel.CSR
      }
    }
  }
}
