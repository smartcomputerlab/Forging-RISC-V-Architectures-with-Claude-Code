package rv32i

import chisel3._
import chisel3.util._

/** 2-stage pipelined RV32IM core: IF (fetch) and EX (everything else), machine mode only, no interrupts.
  *
  * Pipeline
  *  - IF: `fetchPc` addresses the instruction memory; the word and its pc are captured in the [[IfEx]]
  *    pipeline register (with a valid bit) at the clock edge. Fetch always continues at fetchPc + 4
  *    (static not-taken prediction).
  *  - EX: decode, register read, ALU / multiplier / divider, data memory, CSRs and write-back, exactly as in the
  *    Step 5 single-cycle core, applied to the instruction held in IfEx.
  *
  * Hazards
  *  - Data: none. Registers are read and written in the same stage, so a result written at the end of one
  *    EX cycle is in the register file when the next instruction reads it. No forwarding, no interlock.
  *  - Control: a taken branch, JAL, JALR, a trap or MRET is resolved in EX. The instruction fetched behind it
  *    (wrong path) is discarded: IfEx becomes a bubble and fetch restarts at the target. Cost: 1 cycle.
  *  - Structural: DIV/DIVU/REM/REMU occupy the sequential divider for 33 extra cycles (1 for divide-by-zero and
  *    signed overflow). Both stages freeze meanwhile: fetchPc and IfEx keep their values.
  *
  * Every cycle EX does exactly one of: retire an instruction (trace.valid), take a trap (trace.trap), or nothing
  * (both low): a bubble after reset or after a redirect, or a cycle waiting for the divider. A bubble or a wait
  * changes no architectural state.
  *
  * Exceptions, in priority order: illegal instruction (2), ECALL (11), EBREAK (3), load misaligned (4),
  * store misaligned (6), instruction address misaligned (0: taken branch/JAL/JALR target with bit 1 set).
  *
  * Memory ports are zero-wait: instruction and data read data must be combinational functions of the address.
  */
class Core(resetPc: Long = 0x80000000L, hartId: Int = 0) extends Module {
  val io = IO(new Bundle {
    val imem  = new InstrMemPort
    val dmem  = new DataMemPort
    val trace = Output(new Trace)
  })

  require(resetPc >= 0 && resetPc < (1L << 32) && resetPc % 4 == 0, "reset pc must be 4-byte aligned")

  // ================= IF stage =================
  val fetchPc = RegInit(resetPc.U(32.W))
  io.imem.addr := fetchPc

  /** IF/EX pipeline register: empty (bubble) after reset. */
  val ifex = RegInit(0.U.asTypeOf(new IfEx))

  // ================= EX stage =================
  val exValid = ifex.valid
  val pc      = ifex.pc
  // A bubble executes as `addi x0, x0, 0`, which has no side effect; `retire` is also gated by exValid.
  val inst    = Mux(exValid, ifex.inst, Core.Nop.U(32.W))
  val f3      = inst(14, 12)

  // ---------------- M extension: OP opcode with funct7 = 0000001 ----------------
  val isMulDiv = inst(6, 0) === "b0110011".U && inst(31, 25) === "b0000001".U
  val isMul    = isMulDiv && !f3(2)   // Step 4: MUL, MULH, MULHSU, MULHU   (funct3 = 0xx)
  val isDiv    = isMulDiv && f3(2)    // Step 5: DIV, DIVU, REM, REMU       (funct3 = 1xx)

  val dec  = Module(new Decoder)
  val immg = Module(new ImmGen)
  val rf   = Module(new RegFile)
  val alu  = Module(new Alu)
  val csr  = Module(new CsrFile(hartId))
  val mul  = Module(new Multiplier)
  val div  = Module(new DivUnit(32))

  dec.io.inst  := inst
  immg.io.inst := inst
  immg.io.sel  := dec.io.immSel
  // Register addresses straight from the instruction for M-extension ops (the decoder treats them as illegal).
  rf.io.rs1    := Mux(isMulDiv, inst(19, 15), dec.io.rs1)
  rf.io.rs2    := Mux(isMulDiv, inst(24, 20), dec.io.rs2)
  val rs1v = rf.io.rd1
  val rs2v = rf.io.rd2
  val imm  = immg.io.imm

  mul.io.fn := f3(1, 0)
  mul.io.a  := rs1v
  mul.io.b  := rs2v

  // Sequential divider. `busy` stays high through its response cycle, so holding the same instruction on the
  // fetch port never starts it twice. The divider latches rs1/rs2 when it accepts the request.
  div.io.req.valid   := isDiv && !div.io.busy
  div.io.req.bits.op := f3(1, 0)
  div.io.req.bits.a  := rs1v
  div.io.req.bits.b  := rs2v
  val divStall = isDiv && !div.io.resp.valid   // waiting: retire nothing this cycle

  // ---------------- execute ----------------
  val aluA = WireDefault(rs1v)
  switch(dec.io.aluSrcA) {
    is(ASrc.RS1)  { aluA := rs1v }
    is(ASrc.PC)   { aluA := pc }
    is(ASrc.ZERO) { aluA := 0.U }
  }
  alu.io.op := dec.io.aluOp
  alu.io.a  := aluA
  alu.io.b  := Mux(dec.io.aluSrcImm, imm, rs2v)
  val aluY = alu.io.y

  // branch comparator and target adders
  val eq  = rs1v === rs2v
  val lt  = rs1v.asSInt < rs2v.asSInt
  val ltu = rs1v < rs2v
  val brCond = WireDefault(false.B)
  switch(f3) {
    is("b000".U) { brCond := eq }
    is("b001".U) { brCond := !eq }
    is("b100".U) { brCond := lt }
    is("b101".U) { brCond := !lt }
    is("b110".U) { brCond := ltu }
    is("b111".U) { brCond := !ltu }
  }
  val brTaken    = dec.io.branch && brCond
  val pcPlus4    = pc + 4.U
  val brTarget   = pc + imm                           // branches and JAL
  val jalrTarget = Cat(aluY(31, 1), 0.U(1.W))         // rs1 + imm, bit 0 cleared
  val ctlTaken   = brTaken || dec.io.jal || dec.io.jalr
  val ctlTarget  = Mux(dec.io.jalr, jalrTarget, brTarget)

  // ---------------- data access ----------------
  val size = dec.io.memSize
  val misalignedAccess = (size === 2.U && aluY(1, 0) =/= 0.U) || (size === 1.U && aluY(0))
  val loadMis  = dec.io.memRead && misalignedAccess
  val storeMis = dec.io.memWrite && misalignedAccess
  val fetchMis = ctlTaken && ctlTarget(1)

  // ---------------- CSR / traps ----------------
  val rs1Field = inst(19, 15)
  csr.io.addr   := inst(31, 20)
  csr.io.en     := dec.io.csr
  csr.io.op     := f3(1, 0)
  csr.io.src    := Mux(f3(2), Cat(0.U(27.W), rs1Field), rs1v)
  csr.io.wrEn   := f3(1, 0) === 1.U || rs1Field =/= 0.U

  // The eight M-extension instructions are legal even though the Step 3 decoder flags funct7 = 0000001.
  val illegal = (dec.io.illegal && !isMulDiv) || csr.io.illegal
  val trapNow = illegal || dec.io.ecall || dec.io.ebreak || loadMis || storeMis || fetchMis

  // A division never traps (it is legal and does not touch memory), but keep the divider consistent anyway.
  div.io.kill := trapNow

  val cause = PriorityMux(Seq(
    illegal         -> Cause.IllegalInstruction.U(4.W),
    dec.io.ecall    -> Cause.EcallFromM.U(4.W),
    dec.io.ebreak   -> Cause.Breakpoint.U(4.W),
    loadMis         -> Cause.LoadAddrMisaligned.U(4.W),
    storeMis        -> Cause.StoreAddrMisaligned.U(4.W),
    fetchMis        -> Cause.InstrAddrMisaligned.U(4.W)
  ))
  val tval = PriorityMux(Seq(
    illegal                -> inst,
    dec.io.ecall           -> 0.U(32.W),
    dec.io.ebreak          -> pc,
    (loadMis || storeMis)  -> aluY,
    fetchMis               -> ctlTarget
  ))

  val retire = exValid && !trapNow && !divStall

  csr.io.commit    := retire           // no CSR side effects (e.g. minstret) while waiting for the divider
  csr.io.trapEnter := trapNow
  csr.io.trapCause := Cat(0.U(28.W), cause)
  csr.io.trapPc    := pc
  csr.io.trapVal   := tval
  csr.io.mretEnter := dec.io.mret && !trapNow

  // ---------------- next pc (architectural successor of the EX instruction) ----------------
  val nextPc = Mux(trapNow, csr.io.mtvecBase,
               Mux(divStall, pc,
               Mux(dec.io.mret, csr.io.mepc,
               Mux(ctlTaken, ctlTarget, pcPlus4))))

  // ---------------- pipeline control ----------------
  // Redirect: the EX instruction changes the control flow, so the instruction in IF is on the wrong path.
  val redirect = exValid && !divStall && (trapNow || dec.io.mret || ctlTaken)
  when(divStall) {
    // freeze both stages: the divider is working on the EX instruction
  }.elsewhen(redirect) {
    fetchPc    := nextPc
    ifex.valid := false.B                 // flush the wrong-path instruction
  }.otherwise {
    fetchPc    := fetchPc + 4.U
    ifex.valid := true.B
    ifex.pc    := fetchPc
    ifex.inst  := io.imem.data
  }

  // ---------------- load / store datapath ----------------
  val rdata = io.dmem.rdata
  val bytes = VecInit(Seq.tabulate(4)(k => rdata(8 * k + 7, 8 * k)))
  val b     = bytes(aluY(1, 0))
  val h     = Mux(aluY(1), rdata(31, 16), rdata(15, 0))
  val uns   = dec.io.memUnsigned
  val loadData = WireDefault(rdata)
  switch(size) {
    is(0.U) { loadData := Mux(uns, Cat(0.U(24.W), b), Cat(Fill(24, b(7)), b)) }
    is(1.U) { loadData := Mux(uns, Cat(0.U(16.W), h), Cat(Fill(16, h(15)), h)) }
    is(2.U) { loadData := rdata }
  }

  val sbyte = rs2v(7, 0)
  val shalf = rs2v(15, 0)
  val wdata = WireDefault(rs2v)
  val wstrb = WireDefault("b1111".U(4.W))
  switch(size) {
    is(0.U) { wdata := Fill(4, sbyte); wstrb := (1.U(4.W) << aluY(1, 0))(3, 0) }
    is(1.U) { wdata := Fill(2, shalf); wstrb := Mux(aluY(1), "b1100".U(4.W), "b0011".U(4.W)) }
  }

  io.dmem.addr  := aluY
  io.dmem.re    := dec.io.memRead && !trapNow
  io.dmem.we    := dec.io.memWrite && !trapNow
  io.dmem.wdata := wdata
  io.dmem.wstrb := Mux(io.dmem.we, wstrb, 0.U)

  // ---------------- write-back ----------------
  val wbData = WireDefault(aluY)
  switch(dec.io.wbSel) {
    is(WbSel.ALU) { wbData := aluY }
    is(WbSel.MEM) { wbData := loadData }
    is(WbSel.PC4) { wbData := pcPlus4 }
    is(WbSel.CSR) { wbData := csr.io.rdata }
  }
  when(isMul) { wbData := mul.io.result }            // last connect wins
  when(isDiv) { wbData := div.io.resp.bits }
  val rd = Mux(isMulDiv, inst(11, 7), dec.io.rd)
  rf.io.we    := (dec.io.regWrite || isMulDiv) && retire
  rf.io.waddr := rd
  rf.io.wdata := wbData
  val writes = rf.io.we && rd =/= 0.U

  // ---------------- trace ----------------
  io.trace.valid    := retire
  io.trace.trap     := trapNow
  io.trace.cause    := cause
  io.trace.pc       := pc
  io.trace.pcNext   := nextPc
  io.trace.inst     := inst
  io.trace.rdAddr   := Mux(writes, rd, 0.U)
  io.trace.rdData   := Mux(writes, wbData, 0.U)
  io.trace.memAddr  := aluY
  io.trace.memRe    := io.dmem.re
  io.trace.memWe    := io.dmem.we
  io.trace.memSize  := size
  io.trace.memWdata := Mux(size === 0.U, Cat(0.U(24.W), sbyte), Mux(size === 1.U, Cat(0.U(16.W), shalf), rs2v))

  // ---------------- assertions (compiled out of synthesis builds) ----------------
  assert(fetchPc(1, 0) === 0.U, "fetch pc must stay 4-byte aligned")
  assert(!exValid || pc(1, 0) === 0.U, "EX pc must be 4-byte aligned")
  assert(exValid || !(rf.io.we || io.dmem.we || io.dmem.re || trapNow || csr.io.commit), "bubble changed state")
  assert(!(io.trace.valid && io.trace.trap), "retire and trap in the same cycle")
  assert(!(io.dmem.we && io.dmem.re), "simultaneous load and store")
  assert(!(trapNow && (rf.io.we || io.dmem.we)), "trapping instruction modifies state")
  assert(!(divStall && (rf.io.we || io.dmem.we || io.dmem.re || trapNow)), "state changed while waiting for the divider")
  assert(!(divStall && nextPc =/= pc), "pc moved while waiting for the divider")
}

object Core {
  /** `addi x0, x0, 0`: what EX executes when IfEx holds a bubble. */
  val Nop = 0x00000013L
}
