package rv32i

import chisel3._
import chiseltest._
import org.scalatest.flatspec.AnyFlatSpec
import org.scalatest.matchers.should.Matchers

/** Runs small DIV/DIVU/REM/REMU programs on the full Step 5 Core with a combinational memory model
  * and checks the retired results, the stall length and that nothing else happens while waiting.
  */
class CoreDivSpec extends AnyFlatSpec with ChiselScalatestTester with Matchers {
  private val M    = (BigInt(1) << 32) - 1
  private val Base = 0x80000000L
  private val Nop  = BigInt(0x00000013) // addi x0, x0, 0
  private def u(v: Long): BigInt = BigInt(v) & M

  // ---- encoders (correct by construction)
  private def rType(f7: Int, rs2: Int, rs1: Int, f3: Int, rd: Int, op: Int): BigInt =
    BigInt((f7 << 25) | (rs2 << 20) | (rs1 << 15) | (f3 << 12) | (rd << 7) | op) & M
  private def addi(rd: Int, rs1: Int, imm: Int): BigInt =
    BigInt(((imm & 0xFFF) << 20) | (rs1 << 15) | (0 << 12) | (rd << 7) | 0x13) & M
  private def lui(rd: Int, imm20: Int): BigInt =
    BigInt(((imm20 & 0xFFFFF) << 12) | (rd << 7) | 0x37) & M
  /** Load a 32-bit constant: lui + addi, with the usual +0x800 rounding for the signed low part. */
  private def li(rd: Int, v: BigInt): Seq[BigInt] = {
    val x  = v.toLong & 0xFFFFFFFFL
    val lo = ((x & 0xFFF) ^ 0x800) - 0x800           // sign-extended low 12 bits
    val hi = (((x - lo) >> 12) & 0xFFFFF).toInt
    Seq(lui(rd, hi), addi(rd, rd, lo.toInt))
  }
  private val opNames = Seq("DIV", "DIVU", "REM", "REMU")
  private def mdiv(op: Int, rd: Int, rs1: Int, rs2: Int): BigInt = rType(1, rs2, rs1, 4 + op, rd, 0x33)

  /** One expected retirement of a division. */
  private case class Expect(word: BigInt, rd: Int, value: BigInt, stall: Int, name: String)

  /** Run `prog` until all expected divisions retired. Checks every retirement listed in `exp` in order. */
  private def run(prog: Seq[BigInt], exp: Seq[Expect]): Unit = {
    test(new Core(Base)).withAnnotations(TestUtil.waves) { c =>
      c.clock.setTimeout(0)
      c.io.dmem.rdata.poke(0.U)
      var pending = exp.toList
      var stall   = 0
      var cycles  = 0
      var first   = true   // the first instruction follows the pipeline-fill bubble
      while (pending.nonEmpty) {
        val addr = c.io.imem.addr.peek().litValue.toLong
        val idx  = ((addr - Base) / 4).toInt
        c.io.imem.data.poke((if (idx >= 0 && idx < prog.length) prog(idx) else Nop).U(32.W))
        val valid = c.io.trace.valid.peek().litToBoolean
        val trap  = c.io.trace.trap.peek().litToBoolean
        trap shouldBe false
        if (!valid) {
          stall += 1
          c.io.dmem.re.expect(false.B)
          c.io.dmem.we.expect(false.B)
        } else {
          val inst = c.io.trace.inst.peek().litValue
          val exPc = c.io.trace.pc.peek().litValue.toLong
          pending match {
            case e :: rest if inst == e.word =>
              withClue(s"${e.name}: ") {
                stall shouldBe e.stall
                c.io.trace.rdAddr.peek().litValue shouldBe (if (e.rd == 0) 0 else e.rd)
                c.io.trace.rdData.peek().litValue shouldBe (if (e.rd == 0) BigInt(0) else e.value)
                c.io.trace.pcNext.peek().litValue shouldBe (exPc + 4)
              }
              pending = rest
            case _ =>
              stall shouldBe (if (first) 1 else 0) // only divisions stall; one fill bubble at reset
          }
          stall = 0
          first = false
        }
        c.clock.step()
        cycles += 1
        require(cycles < 20000, "program did not finish")
      }
    }
  }

  private def stallFor(op: Int, a: BigInt, b: BigInt): Int =
    if (b == 0 || ((op & 1) == 0 && a == (BigInt(1) << 31) && b == M)) 1 else 33

  "Core" should "execute DIV, DIVU, REM and REMU including the spec's corner cases" in {
    val cases: Seq[(Int, BigInt, BigInt)] = for {
      op <- 0 until 4
      (a, b) <- Seq(
        (BigInt(20), BigInt(6)), (u(-20), BigInt(6)), (BigInt(20), u(-6)), (u(-20), u(-6)),
        (BigInt(7), BigInt(0)), (u(-7), BigInt(0)), (BigInt(1) << 31, M), (M, BigInt(1)),
        (BigInt(0x12345678L), BigInt(0x1234)), (BigInt(0), BigInt(5))
      )
    } yield (op, a, b)

    val prog = cases.flatMap { case (op, a, b) => li(1, a) ++ li(2, b) :+ mdiv(op, 3, 1, 2) }
    val exp = cases.map { case (op, a, b) =>
      Expect(mdiv(op, 3, 1, 2), 3, DivRef(op, a, b), stallFor(op, a, b), f"${opNames(op)} 0x$a%08x, 0x$b%08x")
    }
    run(prog, exp)
  }

  it should "use a division result in the next instruction and ignore rd = x0" in {
    // x1 = -100, x2 = 7 ; x3 = x1 / x2 = -14 ; x4 = x3 % x2 = 0 ; x0 = x1 / x2 (no write) ; x5 = x1 remu x2
    val a = u(-100); val b = BigInt(7)
    val prog = li(1, a) ++ li(2, b) ++ Seq(
      mdiv(0, 3, 1, 2),
      mdiv(2, 4, 3, 2),
      mdiv(0, 0, 1, 2),
      mdiv(3, 5, 1, 2)
    )
    val q = DivRef(0, a, b)
    run(prog, Seq(
      Expect(mdiv(0, 3, 1, 2), 3, q, 33, "div x3"),
      Expect(mdiv(2, 4, 3, 2), 4, DivRef(2, q, b), 33, "rem x4 uses x3"),
      Expect(mdiv(0, 0, 1, 2), 0, 0, 33, "div x0"),
      Expect(mdiv(3, 5, 1, 2), 5, DivRef(3, a, b), 33, "remu x5")
    ))
  }

  it should "still execute the Step 4 multiplications in one cycle" in {
    val a = u(-3); val b = BigInt(5)
    val mul = rType(1, 2, 1, 0, 3, 0x33)    // mul   x3, x1, x2
    val mulh = rType(1, 2, 1, 1, 4, 0x33)   // mulh  x4, x1, x2
    val mulhu = rType(1, 2, 1, 3, 5, 0x33)  // mulhu x5, x1, x2
    val prog = li(1, a) ++ li(2, b) ++ Seq(mul, mulh, mulhu)
    run(prog, Seq(
      Expect(mul, 3, u(-15), 0, "mul"),
      Expect(mulh, 4, M, 0, "mulh"),
      Expect(mulhu, 5, BigInt(4), 0, "mulhu")        // (2^32-3)*5 >> 32 = 4
    ))
  }
}
