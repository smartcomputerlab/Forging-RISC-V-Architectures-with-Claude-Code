package rv32i

import chisel3._
import chiseltest._
import org.scalatest.flatspec.AnyFlatSpec

class RegFileSpec extends AnyFlatSpec with ChiselScalatestTester {
  "RegFile" should "hardwire x0 to zero and store x1..x31" in {
    test(new RegFile).withAnnotations(TestUtil.waves) { c =>
      // reset value is 0 everywhere
      for (k <- 0 until 32) { c.io.rs1.poke(k.U); c.io.rd1.expect(0.U) }
      // write every register, including an attempt on x0
      for (k <- 0 until 32) {
        c.io.we.poke(true.B); c.io.waddr.poke(k.U); c.io.wdata.poke((0x1000 + k * 0x01010101L & 0xFFFFFFFFL).U(32.W))
        c.clock.step()
      }
      c.io.we.poke(false.B)
      for (k <- 0 until 32) {
        val exp = if (k == 0) 0L else (0x1000 + k * 0x01010101L) & 0xFFFFFFFFL
        c.io.rs1.poke(k.U); c.io.rs2.poke((31 - k).U)
        c.io.rd1.expect(exp.U(32.W))
        val exp2 = if (31 - k == 0) 0L else (0x1000 + (31 - k) * 0x01010101L) & 0xFFFFFFFFL
        c.io.rd2.expect(exp2.U(32.W))
      }
    }
  }

  it should "ignore writes when we is low and return the old value during a write" in {
    test(new RegFile).withAnnotations(TestUtil.waves) { c =>
      c.io.we.poke(true.B); c.io.waddr.poke(5.U); c.io.wdata.poke(111.U); c.clock.step()
      c.io.we.poke(false.B); c.io.wdata.poke(222.U); c.clock.step()
      c.io.rs1.poke(5.U); c.io.rd1.expect(111.U)
      c.io.we.poke(true.B); c.io.wdata.poke(333.U)
      c.io.rd1.expect(111.U)          // same cycle: old value
      c.clock.step(); c.io.we.poke(false.B)
      c.io.rd1.expect(333.U)
      c.io.we.poke(true.B); c.io.waddr.poke(0.U); c.io.wdata.poke("hffffffff".U); c.clock.step()
      c.io.rs2.poke(0.U); c.io.rd2.expect(0.U)
    }
  }
}
