package rv32i

import chiseltest._
import org.scalatest.flatspec.AnyFlatSpec
import org.scalatest.matchers.should.Matchers
import scala.util.Random
import TestUtil._

/** Hand-assembled programs on the full core. Every retirement and trap is checked against [[RefModel]] in lockstep
  * (CoreSim), and the final register values are checked against values computed independently in the test.
  */
class CoreProgramSpec extends AnyFlatSpec with ChiselScalatestTester with Matchers {
  private val Data = 0x80010000L

  private def runAndCheck(a: Asm, expect: Map[Int, Long], data: Seq[(Long, Long)] = Nil): CoreSim.Result = {
    var res: CoreSim.Result = null
    test(new Core()).withAnnotations(TestUtil.waves) { c => res = CoreSim.run(c, a.words, data = data) }
    for ((r, v) <- expect) withClue(s"x$r: ") { res.model.x(r) shouldBe (v & M) }
    res
  }

  "Core" should "run arithmetic and logic instructions (OP, OP-IMM, LUI, AUIPC)" in {
    val a = new Asm
    val x1 = 0x12345678L; val x2 = 0xfffffffbL // -5
    a.li(1, x1); a.li(2, x2)
    a.add(3, 1, 2); a.sub(4, 1, 2); a.and(5, 1, 2); a.or(6, 1, 2); a.xor(7, 1, 2)
    a.sll(8, 1, 2); a.srl(9, 2, 2); a.sra(10, 2, 1); a.slt(11, 2, 1); a.sltu(12, 2, 1)
    a.addi(13, 1, -1); a.slti(14, 2, -4); a.sltiu(15, 2, -4); a.xori(16, 1, -1); a.ori(17, 1, 0x0f0); a.andi(18, 1, 0x7ff)
    a.slli(19, 1, 4); a.srli(20, 2, 4); a.srai(21, 2, 1); a.lui(22, 0xabcde)
    val auipcPc = a.here; a.auipc(23, 1)
    a.addi(0, 1, 5); a.add(24, 0, 0)
    a.halt()
    runAndCheck(a, Map(
      3 -> (x1 + x2), 4 -> (x1 - x2), 5 -> (x1 & x2), 6 -> (x1 | x2), 7 -> (x1 ^ x2),
      8 -> (x1 << 27), 9 -> (x2 >>> (x2 & 31)), 10 -> (s32(x2) >> (x1 & 31)), 11 -> 1, 12 -> 0,
      13 -> (x1 - 1), 14 -> 1, 15 -> 1, 16 -> ~x1, 17 -> (x1 | 0xf0), 18 -> (x1 & 0x7ff),
      19 -> (x1 << 4), 20 -> (x2 >>> 4), 21 -> (s32(x2) >> 1), 22 -> 0xabcde000L, 23 -> (auipcPc + 0x1000),
      0 -> 0, 24 -> 0))
  }

  it should "run loads and stores of every size, signed and unsigned" in {
    val a = new Asm
    a.li(1, Data); a.li(2, 0x8899aabbL)
    a.sw(2, 0, 1); a.lw(3, 0, 1)
    a.lb(4, 0, 1); a.lbu(5, 1, 1); a.lb(6, 3, 1); a.lh(7, 2, 1); a.lhu(8, 0, 1)
    a.li(9, 0x11)
    a.sb(9, 1, 1); a.lw(10, 0, 1)
    a.sh(9, 2, 1); a.lw(11, 0, 1)
    a.sw(2, -4, 1); a.lw(12, -4, 1)
    a.lw(13, 8, 1)                      // preloaded word
    a.lhu(14, 10, 1); a.lb(15, 11, 1)
    a.halt()
    runAndCheck(a, Map(
      3 -> 0x8899aabbL, 4 -> 0xffffffbbL, 5 -> 0xaaL, 6 -> 0xffffff88L, 7 -> 0xffff8899L, 8 -> 0xaabbL,
      10 -> 0x889911bbL, 11 -> 0x001111bbL, 12 -> 0x8899aabbL, 13 -> 0xcafebabeL, 14 -> 0xcafeL, 15 -> 0xffffffcaL),
      data = Seq(Data + 8 -> 0xcafebabeL))
  }

  it should "run every branch both ways, loops, JAL and JALR (incl. clearing bit 0)" in {
    val a = new Asm
    // loop: x3 = 1 + 2 + ... + 10
    a.li(1, 0); a.li(2, 10); a.li(3, 0)
    a.label("loop"); a.addi(1, 1, 1); a.add(3, 3, 1); a.blt(1, 2, "loop")
    // each case sets bit k of x11 when taken, bit k of x12 when not taken
    val cases: Seq[(String, Long, Long, Boolean)] = Seq(
      ("beq", 5, 5, true), ("beq", 5, 6, false), ("bne", 5, 6, true), ("bne", 5, 5, false),
      ("blt", -1, 1, true), ("blt", 1, -1, false), ("bge", 7, 7, true), ("bge", -2, 3, false),
      ("bltu", 1, -1, true), ("bltu", -1, 1, false), ("bgeu", -1, 1, true), ("bgeu", 1, -1, false))
    var taken = 0L; var notTaken = 0L
    for (((op, x, y, t), k) <- cases.zipWithIndex) {
      a.li(5, x); a.li(6, y); a.li(13, 1L << k)
      op match {
        case "beq" => a.beq(5, 6, s"t$k"); case "bne" => a.bne(5, 6, s"t$k")
        case "blt" => a.blt(5, 6, s"t$k"); case "bge" => a.bge(5, 6, s"t$k")
        case "bltu" => a.bltu(5, 6, s"t$k"); case _ => a.bgeu(5, 6, s"t$k")
      }
      a.or(12, 12, 13); a.jump(s"e$k")
      a.label(s"t$k"); a.or(11, 11, 13)
      a.label(s"e$k")
      if (t) taken |= 1L << k else notTaken |= 1L << k
    }
    // call / return
    val callPc = a.here; a.jal(1, "func")
    a.addi(21, 20, 1)
    // jalr to an odd address: bit 0 is cleared
    a.la(5, "odd"); a.addi(5, 5, 1); val jalrPc = a.here; a.jalr(6, 5, 0)
    a.li(22, 99)                        // skipped
    a.label("odd"); a.addi(23, 0, 42)
    a.halt()
    a.label("func"); a.addi(20, 0, 7); a.jalr(0, 1, 0)
    runAndCheck(a, Map(3 -> 55, 11 -> taken, 12 -> notTaken, 1 -> (callPc + 4), 20 -> 7, 21 -> 8,
      6 -> (jalrPc + 4), 22 -> 0, 23 -> 42))
  }

  it should "handle back-to-back dependencies, including load-use and M results used immediately" in {
    val a = new Asm
    a.li(30, Data)
    a.li(1, 3)
    a.add(2, 1, 1); a.add(3, 2, 1); a.mul(4, 3, 2); a.sub(5, 4, 3)    // 6, 9, 54, 45
    a.sw(5, 0, 30); a.lw(6, 0, 30); a.addi(7, 6, 1)                  // 45, 46
    a.div(8, 7, 1); a.rem(9, 7, 1); a.add(10, 8, 9)                   // 15, 1, 16
    a.mul(11, 10, 10); a.divu(12, 11, 10); a.sw(12, 4, 30); a.lw(13, 4, 30); a.remu(14, 13, 7) // 256, 16, 16, 16
    a.halt()
    runAndCheck(a, Map(2 -> 6, 3 -> 9, 4 -> 54, 5 -> 45, 6 -> 45, 7 -> 46, 8 -> 15, 9 -> 1, 10 -> 16,
      11 -> 256, 12 -> 16, 13 -> 16, 14 -> 16))
  }

  it should "execute the M extension: corner cases, a gcd loop with REM and a factorial with MUL" in {
    val a = new Asm
    val MIN = 0x80000000L
    a.li(1, MIN); a.li(2, -1); a.li(3, 0); a.li(4, 7); a.li(5, -7)
    a.mulh(6, 1, 1); a.mulhsu(7, 2, 2); a.mulhu(8, 2, 2); a.mul(9, 1, 2)
    a.div(10, 1, 2); a.rem(11, 1, 2); a.div(12, 4, 3); a.divu(13, 4, 3); a.rem(14, 5, 3); a.remu(15, 5, 3)
    a.div(16, 5, 4); a.rem(17, 5, 4); a.divu(18, 5, 4); a.remu(19, 5, 4)
    // gcd(1071, 462) = 21
    a.li(20, 1071); a.li(21, 462)
    a.label("gcd"); a.beq(21, 0, "gcdDone"); a.rem(22, 20, 21); a.mv(20, 21); a.mv(21, 22); a.jump("gcd")
    a.label("gcdDone")
    // 10! = 3628800
    a.li(23, 1); a.li(24, 10)
    a.label("fact"); a.mul(23, 23, 24); a.addi(24, 24, -1); a.bne(24, 0, "fact")
    a.halt()
    val res = runAndCheck(a, Map(
      6 -> 0x40000000L, 7 -> 0xffffffffL, 8 -> 0xfffffffeL, 9 -> MIN,
      10 -> MIN, 11 -> 0, 12 -> 0xffffffffL, 13 -> 0xffffffffL, 14 -> 0xfffffff9L, 15 -> 0xfffffff9L,
      16 -> 0xffffffffL, 17 -> 0, 18 -> ((0xfffffff9L / 7) & M), 19 -> (0xfffffff9L % 7),
      20 -> 21, 23 -> 3628800))
    res.stallCycles should be > 0L
  }

  it should "implement Zicsr and take every exception precisely (illegal, ECALL, EBREAK, misaligned load/store/fetch)" in {
    val a = new Asm
    a.la(1, "handler"); a.csrrw(0, CsrAddr.mtvec, 1)
    a.csrrs(2, CsrAddr.misa, 0); a.csrrs(3, CsrAddr.mhartid, 0)
    a.li(4, 0x55); a.csrrw(5, CsrAddr.mscratch, 4); a.csrrsi(6, CsrAddr.mscratch, 0xa)
    a.csrrci(7, CsrAddr.mscratch, 0x3); a.csrrwi(8, CsrAddr.mscratch, 0x1f); a.csrrc(9, CsrAddr.mscratch, 0)
    a.csrrs(10, CsrAddr.minstret, 0); a.csrrs(11, CsrAddr.mcycle, 0); a.csrrs(12, CsrAddr.cycle, 0)
    a.csrrsi(0, CsrAddr.mstatus, 8)     // MIE = 1
    a.ecall()
    a.ebreak()
    a.word(0xffffffffL)                 // illegal
    a.word(0x0000100fL)                 // fence.i: illegal (no Zifencei)
    a.csrrw(0, CsrAddr.cycle, 1)        // write to a read-only CSR: illegal
    a.csrrs(0, 0x7c0, 0)                // unknown CSR: illegal
    a.li(13, Data + 1)
    a.lw(14, 0, 13)                     // load misaligned (x14 not written)
    a.sw(4, 0, 13)                      // store misaligned
    a.lh(14, 0, 13)                     // load misaligned
    a.la(15, "aligned"); a.addi(15, 15, 2); a.jalr(16, 15, 0) // fetch misaligned (x16 not written)
    a.word(Enc.b(6, 0, 0, 0))           // beq x0, x0, +6: fetch misaligned
    a.label("aligned"); a.wfi(); a.fence()
    a.csrrs(17, CsrAddr.mcause, 0); a.csrrs(18, CsrAddr.mstatus, 0)
    a.lw(19, 0, 0)                      // lw from address 0: aligned, reads 0 (no access faults)
    a.halt()
    a.label("handler")
    a.csrrs(20, CsrAddr.mcause, 0); a.csrrs(21, CsrAddr.mepc, 0); a.csrrs(22, CsrAddr.mtval, 0)
    a.csrrs(24, CsrAddr.mstatus, 0)
    a.addi(31, 31, 1)
    a.li(23, 1); a.sll(23, 23, 20); a.or(30, 30, 23)
    a.addi(21, 21, 4); a.csrrw(0, CsrAddr.mepc, 21)
    a.mret()
    val causes = Seq(Cause.EcallFromM, Cause.Breakpoint, Cause.IllegalInstruction, Cause.LoadAddrMisaligned,
      Cause.StoreAddrMisaligned, Cause.InstrAddrMisaligned).map(1L << _).reduce(_ | _)
    val res = runAndCheck(a, Map(
      2 -> 0x40001100L, 3 -> 0, 5 -> 0, 6 -> 0x55, 7 -> 0x5f, 8 -> 0x5c, 9 -> 0x1f,
      14 -> 0, 16 -> 0, 17 -> Cause.InstrAddrMisaligned, 18 -> 0x1888, 19 -> 0,
      24 -> 0x1880, 31 -> 11, 30 -> causes))
    res.traps shouldBe 11
    res.model.mscratch shouldBe 0x1f
  }

  it should "match the reference model on 3000 random instructions" in {
    val r = new Random(7)
    val a = new Asm
    a.li(16, Data)
    for (k <- 1 to 15) a.li(k, rnd32(r))
    def reg = 1 + r.nextInt(15)
    def src = r.nextInt(16)
    for (_ <- 0 until 3000) r.nextInt(30) match {
      case 0 => a.add(reg, src, src);  case 1 => a.sub(reg, src, src);  case 2 => a.sll(reg, src, src)
      case 3 => a.slt(reg, src, src);  case 4 => a.sltu(reg, src, src); case 5 => a.xor(reg, src, src)
      case 6 => a.srl(reg, src, src);  case 7 => a.sra(reg, src, src);  case 8 => a.or(reg, src, src)
      case 9 => a.and(reg, src, src);  case 10 => a.addi(reg, src, r.nextInt(4096) - 2048)
      case 11 => a.slti(reg, src, r.nextInt(4096) - 2048); case 12 => a.sltiu(reg, src, r.nextInt(4096) - 2048)
      case 13 => a.xori(reg, src, r.nextInt(4096) - 2048); case 14 => a.slli(reg, src, r.nextInt(32))
      case 15 => a.srli(reg, src, r.nextInt(32)); case 16 => a.srai(reg, src, r.nextInt(32))
      case 17 => a.lui(reg, r.nextInt(1 << 20))
      case 18 => a.mul(reg, src, src); case 19 => a.mulh(reg, src, src); case 20 => a.mulhsu(reg, src, src)
      case 21 => a.mulhu(reg, src, src); case 22 => a.div(reg, src, src); case 23 => a.divu(reg, src, src)
      case 24 => a.rem(reg, src, src); case 25 => a.remu(reg, src, src)
      case 26 => a.sw(src, 4 * r.nextInt(64), 16)
      case 27 => a.lw(reg, 4 * r.nextInt(64), 16)
      case 28 => if (r.nextBoolean()) a.sb(src, r.nextInt(256), 16) else a.lbu(reg, r.nextInt(256), 16)
      case _ => if (r.nextBoolean()) a.sh(src, 2 * r.nextInt(128), 16) else a.lh(reg, 2 * r.nextInt(128), 16)
    }
    a.halt()
    var res: CoreSim.Result = null
    test(new Core()).withAnnotations(TestUtil.waves) { c => res = CoreSim.run(c, a.words) }
    res.traps shouldBe 0
    res.retired shouldBe (2 + 30 + 3000 + 1)
  }
}
