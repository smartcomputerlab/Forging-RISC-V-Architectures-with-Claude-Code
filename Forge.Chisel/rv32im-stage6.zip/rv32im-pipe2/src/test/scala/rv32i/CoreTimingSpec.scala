package rv32i

import chiseltest._
import org.scalatest.flatspec.AnyFlatSpec
import org.scalatest.matchers.should.Matchers

/** Timing contract of the 2-stage RV32IM pipeline (IF / EX):
  *  - every instruction occupies EX for one cycle, except DIV, DIVU, REM and REMU (34 cycles, or 2 for
  *    divide-by-zero and signed overflow); a trap also takes one cycle;
  *  - static not-taken prediction: after a taken branch, JAL, JALR, a trap or MRET the next instruction
  *    arrives one cycle later (one bubble); not-taken branches cost nothing;
  *  - after reset the first instruction arrives after one fill bubble.
  */
class CoreTimingSpec extends AnyFlatSpec with ChiselScalatestTester with Matchers {
  private val Data = 0x80010000L

  /** Instruction names exercised below: all of RV32I, Zicsr, the M-mode SYSTEM instructions and the M extension. */
  private val allInstructions = Set(
    "lui", "auipc", "jal", "jalr", "beq", "bne", "blt", "bge", "bltu", "bgeu",
    "lb", "lh", "lw", "lbu", "lhu", "sb", "sh", "sw",
    "addi", "slti", "sltiu", "xori", "ori", "andi", "slli", "srli", "srai",
    "add", "sub", "sll", "slt", "sltu", "xor", "srl", "sra", "or", "and",
    "fence", "ecall", "ebreak", "mret", "wfi",
    "csrrw", "csrrs", "csrrc", "csrrwi", "csrrsi", "csrrci",
    "mul", "mulh", "mulhsu", "mulhu", "div", "divu", "rem", "remu")

  private def isDivRem(w: Long) = (w & 0x7f) == 0x33 && ((w >> 25) & 0x7f) == 1 && ((w >> 12) & 4) != 0

  "Core" should "execute every instruction in one cycle except DIV/DIVU/REM/REMU, plus one bubble per redirect" in {
    val a = new Asm
    // operands: x1 = -100, x2 = 7, x3 = 0 (divide by zero), x4 = MIN, x5 = -1 (signed overflow), x10 = data
    a.li(1, -100); a.li(2, 7); a.li(3, 0); a.li(4, 0x80000000L); a.li(5, -1); a.li(10, Data)
    a.la(6, "handler"); a.csrrw(0, CsrAddr.mtvec, 6)
    // OP-IMM, LUI, AUIPC
    a.addi(11, 1, 5); a.slti(11, 1, 5); a.sltiu(11, 1, 5); a.xori(11, 1, 5); a.ori(11, 1, 5); a.andi(11, 1, 5)
    a.slli(11, 1, 3); a.srli(11, 1, 3); a.srai(11, 1, 3); a.lui(11, 0x12345); a.auipc(11, 1)
    // OP
    a.add(11, 1, 2); a.sub(11, 1, 2); a.sll(11, 1, 2); a.slt(11, 1, 2); a.sltu(11, 1, 2)
    a.xor(11, 1, 2); a.srl(11, 1, 2); a.sra(11, 1, 2); a.or(11, 1, 2); a.and(11, 1, 2)
    // loads and stores
    a.sw(1, 0, 10); a.sh(2, 4, 10); a.sb(2, 6, 10)
    a.lw(11, 0, 10); a.lh(11, 0, 10); a.lhu(11, 2, 10); a.lb(11, 1, 10); a.lbu(11, 3, 10)
    // branches: taken (skips one instruction) and not taken
    for ((br, k) <- Seq[(Int, Int, String) => Unit](a.beq, a.bne, a.blt, a.bge, a.bltu, a.bgeu).zipWithIndex) {
      // x1 = -100 (0xffffff9c unsigned), x2 = 7
      val (tA, tB) = Seq((1, 1), (1, 2), (1, 2), (2, 1), (2, 1), (1, 2))(k) // operands that make each branch taken
      val (nA, nB) = Seq((1, 2), (1, 1), (2, 1), (1, 2), (1, 2), (2, 1))(k) // operands that make it not taken
      br(tA, tB, s"taken$k"); a.addi(20, 20, 1); a.label(s"taken$k")
      br(nA, nB, s"skip$k"); a.addi(21, 21, 1); a.label(s"skip$k")
    }
    // jumps
    a.jal(12, "after"); a.addi(20, 20, 1); a.label("after")
    a.la(13, "back"); a.jalr(14, 13, 0); a.addi(20, 20, 1); a.label("back")
    // multiplications: one cycle each
    a.mul(11, 1, 2); a.mulh(11, 1, 2); a.mulhsu(11, 1, 2); a.mulhu(11, 1, 2)
    // divisions: the only multi-cycle instructions
    a.div(11, 1, 2); a.divu(11, 1, 2); a.rem(11, 1, 2); a.remu(11, 1, 2)
    a.div(11, 1, 3); a.divu(11, 1, 3); a.rem(11, 1, 3); a.remu(11, 1, 3)   // divide by zero
    a.div(11, 4, 5); a.rem(11, 4, 5)                                       // signed overflow
    // Zicsr and SYSTEM
    a.csrrw(11, CsrAddr.mscratch, 1); a.csrrs(11, CsrAddr.mscratch, 2); a.csrrc(11, CsrAddr.mscratch, 2)
    a.csrrwi(11, CsrAddr.mscratch, 9); a.csrrsi(11, CsrAddr.mscratch, 6); a.csrrci(11, CsrAddr.mscratch, 1)
    a.fence(); a.wfi()
    a.ecall(); a.ebreak(); a.word(0xffffffffL)   // three traps
    a.halt()
    a.label("handler")
    a.csrrs(15, CsrAddr.mepc, 0); a.addi(15, 15, 4); a.csrrw(0, CsrAddr.mepc, 15); a.mret()

    var res: CoreSim.Result = null
    test(new Core()).withAnnotations(TestUtil.waves) { c => res = CoreSim.run(c, a.words) }

    val seen = scala.collection.mutable.Set.empty[String]
    var redirects = 0
    for ((e, k) <- res.events.zipWithIndex) {
      val name = Disasm(e.inst, e.pc).split(' ').head
      seen += name
      val rs1 = (e.inst >> 15) & 31; val rs2 = (e.inst >> 20) & 31; val signed = ((e.inst >> 12) & 1) == 0
      val base =
        if (e.trap || !isDivRem(e.inst)) 1
        else if (rs2 == 3 || (signed && rs1 == 4 && rs2 == 5)) 2
        else 34
      // one bubble when this instruction follows the reset fill or a redirect (trap or non-sequential next pc)
      val prevRedirected = k > 0 && { val p = res.events(k - 1); p.trap || p.pcNext != ((p.pc + 4) & 0xFFFFFFFFL) }
      val bubble = if (k == 0 || prevRedirected) 1 else 0
      if (prevRedirected) redirects += 1
      withClue(f"${Disasm(e.inst, e.pc)} at 0x${e.pc}%08x (trap=${e.trap}): ") { e.cycles shouldBe (base + bubble) }
    }
    (allInstructions -- seen) shouldBe empty
    res.traps shouldBe 3
    res.model.x(20) shouldBe 0     // every taken branch and jump skipped its instruction
    res.model.x(21) shouldBe 6     // every not-taken branch fell through
    res.cycles shouldBe res.events.map(_.cycles.toLong).sum
    // 6 taken branches + JAL + JALR + 3 traps + 3 MRETs = 14 redirects, plus the fill bubble
    redirects shouldBe 14
    res.stallCycles shouldBe (4 * 33 + 6 * 1 + 14 + 1)
  }

  it should "discard the wrong-path instruction behind a taken branch, a jump, a trap and MRET" in {
    val a = new Asm
    a.li(10, Data); a.li(1, 0x55); a.li(2, 3)
    a.la(6, "handler"); a.csrrw(0, CsrAddr.mtvec, 6)
    // each redirect is followed by an instruction that would change state if it executed
    a.beq(0, 0, "l1"); a.sw(1, 0, 10); a.label("l1")                      // store must not happen
    a.jal(0, "l2"); a.div(20, 1, 2); a.label("l2")                       // division must not start
    a.la(7, "l3"); a.jalr(0, 7, 0); a.csrrw(0, CsrAddr.mscratch, 1); a.label("l3") // CSR write must not happen
    a.ecall(); a.addi(21, 0, 1)   // after the handler returns (mepc + 4) this addi runs exactly once
    a.lw(22, 0, 10); a.csrrs(23, CsrAddr.mscratch, 0)
    a.halt()
    a.label("handler")
    a.csrrs(15, CsrAddr.mepc, 0); a.addi(15, 15, 4); a.csrrw(0, CsrAddr.mepc, 15)
    a.mret(); a.addi(24, 24, 1)   // wrong path behind MRET: must not run
    var res: CoreSim.Result = null
    test(new Core()).withAnnotations(TestUtil.waves) { c => res = CoreSim.run(c, a.words) }
    res.model.x(20) shouldBe 0
    res.model.x(21) shouldBe 1
    res.model.x(22) shouldBe 0    // memory unchanged
    res.model.x(23) shouldBe 0    // mscratch unchanged
    res.model.x(24) shouldBe 0
    res.traps shouldBe 1
    res.stallCycles shouldBe (1 + 5)  // fill bubble + beq, jal, jalr, ecall, mret
  }
}
