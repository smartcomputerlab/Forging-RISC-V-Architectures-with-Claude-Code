package rv32i

import chisel3._
import chiseltest._
import org.scalatest.flatspec.AnyFlatSpec
import TestUtil._

class DecoderSpec extends AnyFlatSpec with ChiselScalatestTester {
  /** Expected control signals for a legal instruction; unlisted flags must be false. */
  private case class Exp(
    name: String, inst: Long,
    regWrite: Boolean = false, memRead: Boolean = false, memWrite: Boolean = false,
    branch: Boolean = false, jal: Boolean = false, jalr: Boolean = false, csr: Boolean = false,
    ecall: Boolean = false, ebreak: Boolean = false, mret: Boolean = false,
    wb: WbSel.Type = WbSel.ALU, alu: Option[AluOp.Type] = None, imm: Option[ImmSel.Type] = None,
    srcA: Option[ASrc.Type] = None, srcImm: Option[Boolean] = None, size: Option[Int] = None, uns: Option[Boolean] = None)

  private val legal: Seq[Exp] = Seq(
    Exp("lui", one(_.lui(5, 0x12345)), regWrite = true, alu = Some(AluOp.ADD), imm = Some(ImmSel.U), srcA = Some(ASrc.ZERO), srcImm = Some(true)),
    Exp("auipc", one(_.auipc(5, 0x12345)), regWrite = true, alu = Some(AluOp.ADD), imm = Some(ImmSel.U), srcA = Some(ASrc.PC), srcImm = Some(true)),
    Exp("jal", Enc.j(16, 1), regWrite = true, jal = true, wb = WbSel.PC4, imm = Some(ImmSel.J)),
    Exp("jalr", one(_.jalr(1, 2, -4)), regWrite = true, jalr = true, wb = WbSel.PC4, imm = Some(ImmSel.I), srcA = Some(ASrc.RS1), srcImm = Some(true)),
    Exp("beq", Enc.b(8, 2, 1, 0), branch = true, imm = Some(ImmSel.B)),
    Exp("bne", Enc.b(8, 2, 1, 1), branch = true, imm = Some(ImmSel.B)),
    Exp("blt", Enc.b(8, 2, 1, 4), branch = true, imm = Some(ImmSel.B)),
    Exp("bge", Enc.b(8, 2, 1, 5), branch = true, imm = Some(ImmSel.B)),
    Exp("bltu", Enc.b(8, 2, 1, 6), branch = true, imm = Some(ImmSel.B)),
    Exp("bgeu", Enc.b(8, 2, 1, 7), branch = true, imm = Some(ImmSel.B)),
    Exp("lb", one(_.lb(3, 4, 2)), regWrite = true, memRead = true, wb = WbSel.MEM, size = Some(0), uns = Some(false), srcImm = Some(true)),
    Exp("lh", one(_.lh(3, 4, 2)), regWrite = true, memRead = true, wb = WbSel.MEM, size = Some(1), uns = Some(false)),
    Exp("lw", one(_.lw(3, 4, 2)), regWrite = true, memRead = true, wb = WbSel.MEM, size = Some(2)),
    Exp("lbu", one(_.lbu(3, 4, 2)), regWrite = true, memRead = true, wb = WbSel.MEM, size = Some(0), uns = Some(true)),
    Exp("lhu", one(_.lhu(3, 4, 2)), regWrite = true, memRead = true, wb = WbSel.MEM, size = Some(1), uns = Some(true)),
    Exp("sb", one(_.sb(3, 4, 2)), memWrite = true, size = Some(0), imm = Some(ImmSel.S), srcImm = Some(true)),
    Exp("sh", one(_.sh(3, 4, 2)), memWrite = true, size = Some(1), imm = Some(ImmSel.S)),
    Exp("sw", one(_.sw(3, 4, 2)), memWrite = true, size = Some(2), imm = Some(ImmSel.S)),
    Exp("addi", one(_.addi(3, 2, -1)), regWrite = true, alu = Some(AluOp.ADD), imm = Some(ImmSel.I), srcImm = Some(true)),
    Exp("slti", one(_.slti(3, 2, 1)), regWrite = true, alu = Some(AluOp.SLT), srcImm = Some(true)),
    Exp("sltiu", one(_.sltiu(3, 2, 1)), regWrite = true, alu = Some(AluOp.SLTU)),
    Exp("xori", one(_.xori(3, 2, 1)), regWrite = true, alu = Some(AluOp.XOR)),
    Exp("ori", one(_.ori(3, 2, 1)), regWrite = true, alu = Some(AluOp.OR)),
    Exp("andi", one(_.andi(3, 2, 1)), regWrite = true, alu = Some(AluOp.AND)),
    Exp("slli", one(_.slli(3, 2, 31)), regWrite = true, alu = Some(AluOp.SLL)),
    Exp("srli", one(_.srli(3, 2, 31)), regWrite = true, alu = Some(AluOp.SRL)),
    Exp("srai", one(_.srai(3, 2, 31)), regWrite = true, alu = Some(AluOp.SRA)),
    Exp("add", one(_.add(3, 1, 2)), regWrite = true, alu = Some(AluOp.ADD), srcImm = Some(false), srcA = Some(ASrc.RS1)),
    Exp("sub", one(_.sub(3, 1, 2)), regWrite = true, alu = Some(AluOp.SUB), srcImm = Some(false)),
    Exp("sll", one(_.sll(3, 1, 2)), regWrite = true, alu = Some(AluOp.SLL)),
    Exp("slt", one(_.slt(3, 1, 2)), regWrite = true, alu = Some(AluOp.SLT)),
    Exp("sltu", one(_.sltu(3, 1, 2)), regWrite = true, alu = Some(AluOp.SLTU)),
    Exp("xor", one(_.xor(3, 1, 2)), regWrite = true, alu = Some(AluOp.XOR)),
    Exp("srl", one(_.srl(3, 1, 2)), regWrite = true, alu = Some(AluOp.SRL)),
    Exp("sra", one(_.sra(3, 1, 2)), regWrite = true, alu = Some(AluOp.SRA)),
    Exp("or", one(_.or(3, 1, 2)), regWrite = true, alu = Some(AluOp.OR)),
    Exp("and", one(_.and(3, 1, 2)), regWrite = true, alu = Some(AluOp.AND)),
    Exp("fence", one(_.fence())),
    Exp("wfi", one(_.wfi())),
    Exp("ecall", one(_.ecall()), ecall = true),
    Exp("ebreak", one(_.ebreak()), ebreak = true),
    Exp("mret", one(_.mret()), mret = true),
    Exp("csrrw", one(_.csrrw(1, 0x340, 2)), regWrite = true, csr = true, wb = WbSel.CSR),
    Exp("csrrs", one(_.csrrs(1, 0x340, 2)), regWrite = true, csr = true, wb = WbSel.CSR),
    Exp("csrrc", one(_.csrrc(1, 0x340, 2)), regWrite = true, csr = true, wb = WbSel.CSR),
    Exp("csrrwi", one(_.csrrwi(1, 0x340, 7)), regWrite = true, csr = true, wb = WbSel.CSR),
    Exp("csrrsi", one(_.csrrsi(1, 0x340, 7)), regWrite = true, csr = true, wb = WbSel.CSR),
    Exp("csrrci", one(_.csrrci(1, 0x340, 7)), regWrite = true, csr = true, wb = WbSel.CSR)
  )

  /** Encodings that must be illegal. The M extension is illegal *in the decoder*: the core decodes it. */
  private val illegal: Seq[(String, Long)] = Seq(
    "all zeros" -> 0L,
    "all ones" -> 0xffffffffL,
    "custom-0 opcode" -> 0x0000000bL,
    "jalr funct3=1" -> Enc.i(0, 1, 1, 1, 0x67),
    "branch funct3=2" -> Enc.b(8, 2, 1, 2),
    "branch funct3=3" -> Enc.b(8, 2, 1, 3),
    "load funct3=3 (ld)" -> Enc.i(0, 1, 3, 2, 0x03),
    "load funct3=6 (lwu)" -> Enc.i(0, 1, 6, 2, 0x03),
    "load funct3=7" -> Enc.i(0, 1, 7, 2, 0x03),
    "store funct3=3 (sd)" -> Enc.s(0, 2, 1, 3, 0x23),
    "store funct3=4" -> Enc.s(0, 2, 1, 4, 0x23),
    "slli funct7=0100000" -> Enc.i(0x400 | 3, 1, 1, 2, 0x13),
    "srli funct7=0000001" -> Enc.i(0x020 | 3, 1, 5, 2, 0x13),
    "add funct7=0000010" -> Enc.r(2, 2, 1, 0, 3, 0x33),
    "sll funct7=0100000" -> Enc.r(0x20, 2, 1, 1, 3, 0x33),
    "xor funct7=0100000" -> Enc.r(0x20, 2, 1, 4, 3, 0x33),
    "fence.i (Zifencei not implemented)" -> 0x0000100fL,
    "ecall with rd=1" -> 0x000000f3L,
    "uret" -> 0x00200073L,
    "sret" -> 0x10200073L,
    "SYSTEM funct3=4" -> Enc.i(0x340, 1, 4, 1, 0x73)
  ) ++ (0 until 8).map(f3 => s"M extension funct3=$f3" -> Enc.r(1, 2, 1, f3, 3, 0x33))

  "Decoder" should "decode every RV32I, Zicsr and M-mode SYSTEM instruction" in {
    test(new Decoder).withAnnotations(TestUtil.waves) { c =>
      for (e <- legal) {
        c.io.inst.poke(e.inst.U(32.W))
        def is(sig: Bool, v: Boolean, what: String): Unit =
          assert(sig.peek().litToBoolean == v, s"${e.name}: $what should be $v")
        is(c.io.illegal, false, "illegal")
        is(c.io.regWrite, e.regWrite, "regWrite"); is(c.io.memRead, e.memRead, "memRead")
        is(c.io.memWrite, e.memWrite, "memWrite"); is(c.io.branch, e.branch, "branch")
        is(c.io.jal, e.jal, "jal"); is(c.io.jalr, e.jalr, "jalr"); is(c.io.csr, e.csr, "csr")
        is(c.io.ecall, e.ecall, "ecall"); is(c.io.ebreak, e.ebreak, "ebreak"); is(c.io.mret, e.mret, "mret")
        if (e.regWrite) c.io.wbSel.expect(e.wb)
        e.alu.foreach(c.io.aluOp.expect(_)); e.imm.foreach(c.io.immSel.expect(_)); e.srcA.foreach(c.io.aluSrcA.expect(_))
        e.srcImm.foreach(v => is(c.io.aluSrcImm, v, "aluSrcImm"))
        e.size.foreach(v => c.io.memSize.expect(v.U)); e.uns.foreach(v => is(c.io.memUnsigned, v, "memUnsigned"))
        c.io.rs1.expect(((e.inst >> 15) & 31).U); c.io.rs2.expect(((e.inst >> 20) & 31).U); c.io.rd.expect(((e.inst >> 7) & 31).U)
      }
    }
  }

  it should "flag illegal encodings and assert no other control signal for them" in {
    test(new Decoder).withAnnotations(TestUtil.waves) { c =>
      for ((name, inst) <- illegal) {
        c.io.inst.poke(inst.U(32.W))
        assert(c.io.illegal.peek().litToBoolean, s"$name should be illegal")
        for ((sig, what) <- Seq(c.io.regWrite -> "regWrite", c.io.memRead -> "memRead", c.io.memWrite -> "memWrite",
          c.io.branch -> "branch", c.io.jal -> "jal", c.io.jalr -> "jalr", c.io.csr -> "csr", c.io.ecall -> "ecall",
          c.io.ebreak -> "ebreak", c.io.mret -> "mret"))
          assert(!sig.peek().litToBoolean, s"$name: $what must be low")
      }
    }
  }

  it should "classify every one of the 128 major opcodes" in {
    val legalOps = Set(Opcode.LUI, Opcode.AUIPC, Opcode.JAL, Opcode.JALR, Opcode.BRANCH, Opcode.LOAD, Opcode.STORE,
      Opcode.OP_IMM, Opcode.OP, Opcode.MISC_MEM, Opcode.SYSTEM)
    test(new Decoder).withAnnotations(TestUtil.waves) { c =>
      for (op <- 0 until 128) {
        // funct3 = 0, everything else 0 except a valid-looking rd: legal for all implemented opcodes except SYSTEM
        // (where only exact ECALL/EBREAK/MRET/WFI encodings are legal) and BRANCH/STORE which accept funct3 = 0.
        val inst = (op | (1 << 7)).toLong
        c.io.inst.poke(inst.U(32.W))
        val expectLegal = legalOps(op) && op != Opcode.SYSTEM
        assert(c.io.illegal.peek().litToBoolean == !expectLegal, f"opcode 0x$op%02x")
      }
    }
  }
}
