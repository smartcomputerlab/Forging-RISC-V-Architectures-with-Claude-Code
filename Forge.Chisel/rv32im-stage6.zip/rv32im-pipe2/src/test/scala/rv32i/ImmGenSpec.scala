package rv32i

import chisel3._
import chiseltest._
import org.scalatest.flatspec.AnyFlatSpec
import scala.util.Random
import TestUtil._

class ImmGenSpec extends AnyFlatSpec with ChiselScalatestTester {
  private def sext(v: Long, bits: Int) = ((v << (64 - bits)) >> (64 - bits)) & M

  "ImmGen" should "build the I, S, B, U and J immediates from instructions the assembler encoded" in {
    test(new ImmGen).withAnnotations(TestUtil.waves) { c =>
      val r = new Random(2)
      for (_ <- 0 until 500) {
        val i12 = r.nextInt(4096) - 2048
        val b13 = (r.nextInt(4096) - 2048) * 2
        val j21 = (r.nextInt(1 << 20) - (1 << 19)) * 2
        val u20 = r.nextInt(1 << 20)
        val cases = Seq(
          (ImmSel.I, Enc.i(i12, 3, 0, 5, 0x13), sext(i12, 12)),
          (ImmSel.S, Enc.s(i12, 4, 3, 2, 0x23), sext(i12, 12)),
          (ImmSel.B, Enc.b(b13, 4, 3, 0), sext(b13, 13)),
          (ImmSel.U, Enc.u(u20, 7, 0x37), (u20.toLong << 12) & M),
          (ImmSel.J, Enc.j(j21, 1), sext(j21, 21))
        )
        for ((sel, inst, exp) <- cases) {
          c.io.sel.poke(sel); c.io.inst.poke(inst.U(32.W))
          c.io.imm.expect(exp.U(32.W))
        }
      }
    }
  }
}
