package rv32i

import chisel3._
import chiseltest._
import org.scalatest.flatspec.AnyFlatSpec
import scala.util.Random
import TestUtil._

class MultiplierSpec extends AnyFlatSpec with ChiselScalatestTester {
  private def ref(fn: Int, a: Long, b: Long): Long = {
    val sa = BigInt(s32(a)); val ua = BigInt(a); val sb = BigInt(s32(b)); val ub = BigInt(b)
    val p = fn match { case 0 => ua * ub; case 1 => sa * sb; case 2 => sa * ub; case _ => ua * ub }
    (if (fn == 0) p else p >> 32).toLong & M
  }
  private val names = Seq("MUL", "MULH", "MULHSU", "MULHU")

  "Multiplier" should "compute MUL, MULH, MULHSU and MULHU on edge values and random operands" in {
    test(new Multiplier).withAnnotations(TestUtil.waves) { c =>
      val r = new Random(3)
      val pairs = (for (a <- edges; b <- edges) yield (a, b)) ++ Seq.fill(2000)((rnd32(r), rnd32(r)))
      for ((a, b) <- pairs; fn <- 0 until 4) {
        c.io.fn.poke(fn.U); c.io.a.poke(a.U(32.W)); c.io.b.poke(b.U(32.W))
        val got = c.io.result.peek().litValue.toLong
        assert(got == ref(fn, a, b), f"${names(fn)} 0x$a%08x 0x$b%08x: got 0x$got%08x expected 0x${ref(fn, a, b)}%08x")
      }
    }
  }
}
