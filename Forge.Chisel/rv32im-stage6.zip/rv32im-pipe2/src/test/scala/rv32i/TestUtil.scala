package rv32i

import scala.util.Random

import chiseltest.WriteVcdAnnotation
import firrtl.AnnotationSeq

object TestUtil {
  /** VCD output for any test: run with `WAVES=1 sbt test` (or `sbt -Dwaves=1 test`).
    * chiseltest then writes test_run_dir/<test name>/<Module>.vcd for every test that uses these annotations.
    */
  val wavesOn: Boolean = sys.env.get("WAVES").exists(v => v.nonEmpty && v != "0") || sys.props.get("waves").exists(_ != "0")
  def waves: AnnotationSeq = if (wavesOn) Seq(WriteVcdAnnotation) else Seq.empty

  val M = 0xFFFFFFFFL
  /** Edge values for 32-bit operands. */
  val edges: Seq[Long] = Seq(0L, 1L, 2L, 3L, 5L, 31L, 32L, 0x7fL, 0x80L, 0xffL, 0x7fffL, 0x8000L, 0xffffL,
    0x12345678L, 0x55555555L, 0xaaaaaaaaL, 0x7ffffffeL, 0x7fffffffL, 0x80000000L, 0x80000001L, 0xfffffffeL, 0xffffffffL)
  def s32(v: Long): Long = v.toInt.toLong
  def rnd32(r: Random): Long = r.nextLong() & M
  /** Encode a single instruction with the assembler. */
  def one(f: Asm => Unit): Long = { val a = new Asm; f(a); a.words.head }
}
