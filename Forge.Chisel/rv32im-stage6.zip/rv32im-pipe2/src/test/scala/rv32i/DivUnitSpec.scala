package rv32i

import chisel3._
import chiseltest._
import org.scalatest.flatspec.AnyFlatSpec
import org.scalatest.matchers.should.Matchers

import scala.util.Random

class DivRefSpec extends AnyFlatSpec with Matchers {
  private val M   = (BigInt(1) << 32) - 1
  private val MIN = BigInt(1) << 31
  private def u(v: Long): BigInt = BigInt(v) & M
  private val DIV = 0; private val DIVU = 1; private val REM = 2; private val REMU = 3

  "DivRef" should "follow the RISC-V division-by-zero and overflow table" in {
    for (x <- Seq(u(0), u(5), u(-5), MIN, M)) {
      DivRef(DIV, x, 0) shouldBe M
      DivRef(DIVU, x, 0) shouldBe M
      DivRef(REM, x, 0) shouldBe x
      DivRef(REMU, x, 0) shouldBe x
    }
    DivRef(DIV, MIN, M) shouldBe MIN
    DivRef(REM, MIN, M) shouldBe 0
  }

  it should "round toward zero and give the remainder the dividend's sign" in {
    DivRef(DIV, u(-7), 2) shouldBe u(-3)
    DivRef(REM, u(-7), 2) shouldBe u(-1)
    DivRef(DIV, 7, u(-2)) shouldBe u(-3)
    DivRef(REM, 7, u(-2)) shouldBe 1
    DivRef(DIV, u(-7), u(-2)) shouldBe 3
    DivRef(REM, u(-7), u(-2)) shouldBe u(-1)
    DivRef(DIVU, u(-7), 2) shouldBe (u(-7) / 2)
    DivRef(REMU, u(-7), 2) shouldBe 1
  }

  it should "agree with the Int form" in {
    DivRef.int32(DIV, -7, 2) shouldBe -3
    DivRef.int32(REMU, -1, 10) shouldBe 5 // 0xFFFFFFFF % 10
    DivRef.int32(DIV, Int.MinValue, -1) shouldBe Int.MinValue
  }
}

class DivUnitSpec extends AnyFlatSpec with ChiselScalatestTester with Matchers {
  private val M   = (BigInt(1) << 32) - 1
  private val MIN = BigInt(1) << 31
  private def u(v: Long): BigInt = BigInt(v) & M
  private val names = Seq("DIV", "DIVU", "REM", "REMU")

  private val edge: Seq[BigInt] = Seq(
    0L, 1L, 2L, 3L, 7L, 12345L, 0xFFFFL, 0x10000L, 0x55555555L, 0xAAAAAAAAL,
    0x7FFFFFFFL, 0x80000000L, 0x80000001L, 0xFFFFFFFEL, 0xFFFFFFFFL, -7L
  ).map(u)

  /** Issues one request and waits for the response. Returns (result, edges from accept to response). */
  private def divide(c: DivUnit, op: Int, a: BigInt, b: BigInt): (BigInt, Int) = {
    c.io.req.ready.expect(true.B)
    c.io.req.valid.poke(true.B)
    c.io.req.bits.op.poke(op.U)
    c.io.req.bits.a.poke(a.U(32.W))
    c.io.req.bits.b.poke(b.U(32.W))
    c.clock.step()
    c.io.req.valid.poke(false.B)
    var edges = 1
    while (!c.io.resp.valid.peek().litToBoolean) {
      c.io.req.ready.expect(false.B)
      c.io.busy.expect(true.B)
      c.clock.step()
      edges += 1
      require(edges <= 40, s"no response after $edges cycles")
    }
    c.io.req.ready.expect(false.B) // no second start during the response cycle
    val r = c.io.resp.bits.peek().litValue
    c.clock.step()
    c.io.resp.valid.expect(false.B)
    c.io.busy.expect(false.B)
    (r, edges)
  }

  private def check(c: DivUnit, op: Int, a: BigInt, b: BigInt): Unit = {
    val (got, edges) = divide(c, op, a, b)
    val exp = DivRef(op, a, b)
    withClue(f"${names(op)} 0x$a%08x, 0x$b%08x: ") {
      got shouldBe exp
      val fast = b == 0 || ((op & 1) == 0 && a == MIN && b == M)
      edges shouldBe (if (fast) 1 else 33)
    }
  }

  "DivUnit" should "handle every edge-value pair for all four instructions" in {
    test(new DivUnit(32)).withAnnotations(TestUtil.waves) { c =>
      c.io.kill.poke(false.B)
      c.io.req.valid.poke(false.B)
      c.clock.setTimeout(0)
      for (op <- 0 until 4; a <- edge; b <- edge) check(c, op, a, b)
    }
  }

  it should "match the reference on random operands" in {
    test(new DivUnit(32)).withAnnotations(TestUtil.waves) { c =>
      c.io.kill.poke(false.B)
      c.io.req.valid.poke(false.B)
      c.clock.setTimeout(0)
      val rnd = new Random(42)
      for (_ <- 0 until 2000) {
        val op   = rnd.nextInt(4)
        val a    = BigInt(32, rnd)
        val bits = Seq(1, 4, 8, 16, 31, 32)(rnd.nextInt(6))
        var b    = BigInt(bits, rnd)
        if (rnd.nextInt(10) < 3) b = (-b) & M
        check(c, op, a, b)
      }
    }
  }

  it should "abandon a division on kill and accept the next one" in {
    test(new DivUnit(32)).withAnnotations(TestUtil.waves) { c =>
      c.io.kill.poke(false.B)
      c.io.req.valid.poke(true.B)
      c.io.req.bits.op.poke(0.U)
      c.io.req.bits.a.poke(1000.U)
      c.io.req.bits.b.poke(7.U)
      c.clock.step()
      c.io.req.valid.poke(false.B)
      c.clock.step(10)
      c.io.busy.expect(true.B)
      c.io.kill.poke(true.B)
      c.clock.step()
      c.io.kill.poke(false.B)
      c.io.busy.expect(false.B)
      c.io.resp.valid.expect(false.B)
      check(c, 2, u(-1000), 7) // REM -1000, 7 = -6
    }
  }

  it should "run back-to-back requests from a core that holds valid high" in {
    test(new DivUnit(32)).withAnnotations(TestUtil.waves) { c =>
      c.io.kill.poke(false.B)
      c.clock.setTimeout(0)
      // A stalled single-cycle core keeps valid high until the response, then moves on.
      c.io.req.valid.poke(true.B)
      c.io.req.bits.op.poke(1.U)
      c.io.req.bits.a.poke(100.U)
      c.io.req.bits.b.poke(9.U)
      var starts = 0
      var cycles = 0
      while (!c.io.resp.valid.peek().litToBoolean) {
        if (c.io.req.ready.peek().litToBoolean) starts += 1
        c.clock.step(); cycles += 1
        require(cycles < 40)
      }
      starts shouldBe 1
      c.io.resp.bits.expect(11.U)
      c.io.req.ready.expect(false.B)
      c.clock.step() // core retires the DIVU and fetches the next instruction
      c.io.req.bits.op.poke(3.U) // REMU
      c.io.req.ready.expect(true.B)
      c.clock.step()
      c.io.req.valid.poke(false.B)
      while (!c.io.resp.valid.peek().litToBoolean) c.clock.step()
      c.io.resp.bits.expect(1.U)
    }
  }
}
