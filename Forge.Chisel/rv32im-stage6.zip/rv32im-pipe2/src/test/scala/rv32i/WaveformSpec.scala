package rv32i

import chisel3._
import chiseltest._
import firrtl.options.TargetDirAnnotation
import org.scalatest.flatspec.AnyFlatSpec
import org.scalatest.matchers.should.Matchers

import java.nio.file.{Files, Path, Paths}

/** Writes VCD waveforms of short, readable demo programs into waves/<name>/ for inspection with GTKWave.
  * Every run is still checked against RefModel (CoreSim), so a waveform is only written for a correct run.
  */
class WaveformSpec extends AnyFlatSpec with ChiselScalatestTester with Matchers {
  private val Data = 0x80010000L

  private def demoCore(name: String, a: Asm): CoreSim.Result = {
    val dir = Paths.get("waves", name)
    Files.createDirectories(dir)
    var res: CoreSim.Result = null
    test(new Core()).withAnnotations(Seq(WriteVcdAnnotation, TargetDirAnnotation(dir.toString))) { c =>
      res = CoreSim.run(c, a.words)
    }
    Files.write(dir.resolve("program.lst"), Disasm.listing(a.words).getBytes("UTF-8"))
    // GTKWave: instruction-word filter for this program, divider state names, and the save file
    Gtkw.writeFilter(dir, "inst.filter",
      (a.words.zipWithIndex.map { case (w, k) => w -> Disasm(w, a.base + 4L * k) } ++
        Seq(Core.Nop -> "nop (bubble)", 0L -> "(empty)")).distinctBy(_._1), 8)
    Gtkw.writeDivStateFilter(dir)
    Gtkw.write(dir, "Core.vcd", "core.gtkw", Gtkw.coreGroups)
    res
  }

  private def vcd(dir: String, module: String): Path = Paths.get("waves", dir, s"$module.vcd")

  "Waveforms" should "show DIV/REM stalls and MUL in one cycle (waves/div_rem)" in {
    val a = new Asm
    a.li(1, -100); a.li(2, 7); a.li(7, 0); a.li(8, 0x80000000L); a.li(9, -1)
    a.div(3, 1, 2)       // -14, 34 cycles
    a.rem(4, 1, 2)       // -2
    a.divu(5, 1, 2)
    a.div(6, 1, 7)       // divide by zero: -1, 2 cycles
    a.rem(10, 8, 9)      // overflow MIN % -1: 0, 2 cycles
    a.mul(11, 1, 2)      // -700, 1 cycle
    a.add(12, 3, 4)      // uses the division results
    a.halt()
    val r = demoCore("div_rem", a)
    r.model.x(3) shouldBe ((-14L) & 0xFFFFFFFFL)
    r.model.x(4) shouldBe ((-2L) & 0xFFFFFFFFL)
    r.stallCycles shouldBe (1 + 3 * 33 + 2 * 1)   // fill bubble + divider waits
    Files.exists(vcd("div_rem", "Core")) shouldBe true
  }

  it should "show loads, stores, a loop and a call (waves/load_store_branch)" in {
    val a = new Asm
    a.li(10, Data)
    a.li(1, 0); a.li(2, 5); a.li(3, 0)
    a.label("loop"); a.addi(1, 1, 1); a.add(3, 3, 1); a.sw(3, 0, 10); a.addi(10, 10, 4); a.blt(1, 2, "loop")
    a.lw(4, -4, 10); a.lbu(5, -4, 10); a.sh(4, 2, 10); a.lh(6, 2, 10)
    a.jal(1, "func"); a.halt()
    a.label("func"); a.addi(7, 0, 42); a.jalr(0, 1, 0)
    val r = demoCore("load_store_branch", a)
    r.model.x(3) shouldBe 15
    r.model.x(7) shouldBe 42
    Files.exists(vcd("load_store_branch", "Core")) shouldBe true
  }

  it should "show an ECALL trap, the handler and MRET (waves/trap)" in {
    val a = new Asm
    a.la(1, "handler"); a.csrrw(0, CsrAddr.mtvec, 1)
    a.li(2, 5)
    a.ecall()
    a.addi(2, 2, 1)
    a.word(0xffffffffL)                 // illegal instruction
    a.addi(2, 2, 1)
    a.halt()
    a.label("handler")
    a.csrrs(3, CsrAddr.mcause, 0); a.csrrs(4, CsrAddr.mepc, 0)
    a.addi(4, 4, 4); a.csrrw(0, CsrAddr.mepc, 4)
    a.mret()
    val r = demoCore("trap", a)
    r.traps shouldBe 2
    r.model.x(2) shouldBe 7
    Files.exists(vcd("trap", "Core")) shouldBe true
  }

  it should "show the divider on its own: request, 32 iterations, response (waves/div_unit)" in {
    val dir = Paths.get("waves", "div_unit")
    Files.createDirectories(dir)
    test(new DivUnit(32)).withAnnotations(Seq(WriteVcdAnnotation, TargetDirAnnotation(dir.toString))) { c =>
      c.io.kill.poke(false.B)
      c.clock.step(2)
      for ((op, a, b) <- Seq((0, -1000L, 7L), (2, -1000L, 7L), (1, 1000L, 0L))) {
        c.io.req.valid.poke(true.B); c.io.req.bits.op.poke(op.U)
        c.io.req.bits.a.poke((a & 0xFFFFFFFFL).U(32.W)); c.io.req.bits.b.poke((b & 0xFFFFFFFFL).U(32.W))
        c.clock.step()
        c.io.req.valid.poke(false.B)
        while (!c.io.resp.valid.peek().litToBoolean) c.clock.step()
        c.io.resp.bits.expect((DivRef(op, BigInt(a & 0xFFFFFFFFL), BigInt(b)) & 0xFFFFFFFFL).U(32.W))
        c.clock.step(2)
      }
    }
    Gtkw.writeDivStateFilter(dir)
    Gtkw.write(dir, "DivUnit.vcd", "divunit.gtkw", Seq(
      Gtkw.Group("Clock", Seq(Gtkw.Sig("DivUnit.clock", 1, Gtkw.Bin), Gtkw.Sig("DivUnit.reset", 1, Gtkw.Bin),
        Gtkw.Sig("DivUnit.io_kill", 1, Gtkw.Bin))),
      Gtkw.divGroup("DivUnit"),
      Gtkw.Group("Result", Seq(Gtkw.Sig("DivUnit.result", 32, Gtkw.SDec)))))
    Files.exists(vcd("div_unit", "DivUnit")) shouldBe true
  }
}
