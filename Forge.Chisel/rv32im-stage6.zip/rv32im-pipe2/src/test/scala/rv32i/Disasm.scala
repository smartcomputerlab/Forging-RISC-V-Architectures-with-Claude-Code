package rv32i

/** Minimal RV32IM + Zicsr disassembler for program listings and GTKWave translate filters. */
object Disasm {
  private def x(r: Long) = s"x${r & 31}"
  private def sext(v: Long, bits: Int) = (v << (64 - bits)) >> (64 - bits)
  private val csrNames: Map[Int, String] = Map(
    0x300 -> "mstatus", 0x301 -> "misa", 0x304 -> "mie", 0x305 -> "mtvec", 0x310 -> "mstatush", 0x340 -> "mscratch",
    0x341 -> "mepc", 0x342 -> "mcause", 0x343 -> "mtval", 0x344 -> "mip", 0xb00 -> "mcycle", 0xb02 -> "minstret",
    0xb80 -> "mcycleh", 0xb82 -> "minstreth", 0xc00 -> "cycle", 0xc02 -> "instret", 0xc80 -> "cycleh",
    0xc82 -> "instreth", 0xf11 -> "mvendorid", 0xf12 -> "marchid", 0xf13 -> "mimpid", 0xf14 -> "mhartid")

  /** Text for one instruction word. `pc` is used to print absolute branch/jump targets. */
  def apply(w: Long, pc: Long = 0L): String = {
    val op = (w & 0x7f).toInt; val rd = (w >> 7) & 31; val f3 = ((w >> 12) & 7).toInt
    val rs1 = (w >> 15) & 31; val rs2 = (w >> 20) & 31; val f7 = ((w >> 25) & 0x7f).toInt
    val immI = sext(w >> 20, 12)
    val immS = sext(((w >> 25) << 5) | ((w >> 7) & 31), 12)
    val immB = sext((((w >> 31) & 1) << 12) | (((w >> 7) & 1) << 11) | (((w >> 25) & 0x3f) << 5) | (((w >> 8) & 0xf) << 1), 13)
    val immJ = sext((((w >> 31) & 1) << 20) | (((w >> 12) & 0xff) << 12) | (((w >> 20) & 1) << 11) | (((w >> 21) & 0x3ff) << 1), 21)
    def tgt(off: Long) = f"0x${(pc + off) & 0xFFFFFFFFL}%x"
    val csr = ((w >> 20) & 0xfff).toInt
    def csrName = csrNames.getOrElse(csr, f"0x$csr%03x")
    op match {
      case 0x37 => f"lui ${x(rd)}, 0x${(w >>> 12) & 0xfffff}%x"
      case 0x17 => f"auipc ${x(rd)}, 0x${(w >>> 12) & 0xfffff}%x"
      case 0x6f => if (w == 0x6fL) "halt (j .)" else s"jal ${x(rd)}, ${tgt(immJ)}"
      case 0x67 if f3 == 0 => s"jalr ${x(rd)}, $immI(${x(rs1)})"
      case 0x63 if f3 != 2 && f3 != 3 =>
        s"${Seq("beq", "bne", "", "", "blt", "bge", "bltu", "bgeu")(f3)} ${x(rs1)}, ${x(rs2)}, ${tgt(immB)}"
      case 0x03 if Set(0, 1, 2, 4, 5)(f3) => s"${Seq("lb", "lh", "lw", "", "lbu", "lhu")(f3)} ${x(rd)}, $immI(${x(rs1)})"
      case 0x23 if f3 <= 2 => s"${Seq("sb", "sh", "sw")(f3)} ${x(rs2)}, $immS(${x(rs1)})"
      case 0x13 =>
        f3 match {
          case 1 => s"slli ${x(rd)}, ${x(rs1)}, ${rs2}"
          case 5 => s"${if (f7 == 0x20) "srai" else "srli"} ${x(rd)}, ${x(rs1)}, ${rs2}"
          case _ =>
            if (w == 0x13L) "nop"
            else s"${Seq("addi", "", "slti", "sltiu", "xori", "", "ori", "andi")(f3)} ${x(rd)}, ${x(rs1)}, $immI"
        }
      case 0x33 if f7 == 1 =>
        s"${Seq("mul", "mulh", "mulhsu", "mulhu", "div", "divu", "rem", "remu")(f3)} ${x(rd)}, ${x(rs1)}, ${x(rs2)}"
      case 0x33 if f7 == 0 || f7 == 0x20 =>
        val n = (f3, f7) match {
          case (0, 0x20) => "sub"; case (5, 0x20) => "sra"
          case (k, _) => Seq("add", "sll", "slt", "sltu", "xor", "srl", "or", "and")(k)
        }
        s"$n ${x(rd)}, ${x(rs1)}, ${x(rs2)}"
      case 0x0f if f3 == 0 => "fence"
      case 0x73 =>
        w match {
          case 0x00000073L => "ecall"
          case 0x00100073L => "ebreak"
          case 0x30200073L => "mret"
          case 0x10500073L => "wfi"
          case _ if f3 != 0 && f3 != 4 =>
            val n = Seq("", "csrrw", "csrrs", "csrrc", "", "csrrwi", "csrrsi", "csrrci")(f3)
            val src = if (f3 >= 5) s"$rs1" else x(rs1)
            s"$n ${x(rd)}, $csrName, $src"
          case _ => f"illegal 0x$w%08x"
        }
      case _ => f"illegal 0x$w%08x"
    }
  }

  /** Address, word and text for every word of a program. */
  def listing(words: Seq[Long], base: Long = 0x80000000L): String =
    words.zipWithIndex.map { case (w, k) =>
      val pc = base + 4L * k
      f"$pc%08x:  $w%08x   ${apply(w, pc)}"
    }.mkString("", "\n", "\n")
}
