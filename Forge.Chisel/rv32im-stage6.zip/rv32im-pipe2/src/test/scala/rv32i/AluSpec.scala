package rv32i

import chisel3._
import chiseltest._
import org.scalatest.flatspec.AnyFlatSpec
import scala.util.Random
import TestUtil._

class AluSpec extends AnyFlatSpec with ChiselScalatestTester {
  private val ops: Seq[(AluOp.Type, String, (Long, Long) => Long)] = Seq(
    (AluOp.ADD, "ADD", (a, b) => a + b),
    (AluOp.SUB, "SUB", (a, b) => a - b),
    (AluOp.SLL, "SLL", (a, b) => a << (b & 31)),
    (AluOp.SLT, "SLT", (a, b) => if (s32(a) < s32(b)) 1 else 0),
    (AluOp.SLTU, "SLTU", (a, b) => if (a < b) 1 else 0),
    (AluOp.XOR, "XOR", (a, b) => a ^ b),
    (AluOp.SRL, "SRL", (a, b) => a >>> (b & 31)),
    (AluOp.SRA, "SRA", (a, b) => s32(a) >> (b & 31)),
    (AluOp.OR, "OR", (a, b) => a | b),
    (AluOp.AND, "AND", (a, b) => a & b)
  )

  "Alu" should "compute every operation on all edge-value pairs (incl. overflow, shift by 31/32, sign)" in {
    test(new Alu).withAnnotations(TestUtil.waves) { c =>
      for ((op, name, f) <- ops; a <- edges; b <- edges) {
        c.io.op.poke(op); c.io.a.poke(a.U(32.W)); c.io.b.poke(b.U(32.W))
        val got = c.io.y.peek().litValue.toLong
        assert(got == (f(a, b) & M), f"$name 0x$a%08x 0x$b%08x: got 0x$got%08x")
      }
    }
  }

  it should "match the reference on random operands" in {
    test(new Alu).withAnnotations(TestUtil.waves) { c =>
      val r = new Random(1)
      for (_ <- 0 until 3000) {
        val (op, name, f) = ops(r.nextInt(ops.length))
        val a = rnd32(r); val b = rnd32(r)
        c.io.op.poke(op); c.io.a.poke(a.U(32.W)); c.io.b.poke(b.U(32.W))
        val got = c.io.y.peek().litValue.toLong
        assert(got == (f(a, b) & M), f"$name 0x$a%08x 0x$b%08x: got 0x$got%08x")
      }
    }
  }
}
