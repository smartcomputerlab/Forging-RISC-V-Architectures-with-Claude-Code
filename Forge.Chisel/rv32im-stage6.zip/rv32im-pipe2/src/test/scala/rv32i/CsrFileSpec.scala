package rv32i

import chisel3._
import chiseltest._
import org.scalatest.flatspec.AnyFlatSpec

class CsrFileSpec extends AnyFlatSpec with ChiselScalatestTester {
  private def idle(c: CsrFile): Unit = {
    c.io.en.poke(false.B); c.io.wrEn.poke(false.B); c.io.commit.poke(false.B)
    c.io.trapEnter.poke(false.B); c.io.mretEnter.poke(false.B)
    c.io.op.poke(1.U); c.io.src.poke(0.U); c.io.addr.poke(0.U)
    c.io.trapCause.poke(0.U); c.io.trapPc.poke(0.U); c.io.trapVal.poke(0.U)
  }
  /** One CSR instruction that retires; returns the old value. */
  private def access(c: CsrFile, addr: Int, op: Int, src: Long, wrEn: Boolean = true): BigInt = {
    c.io.en.poke(true.B); c.io.addr.poke(addr.U); c.io.op.poke(op.U); c.io.src.poke(src.U(32.W))
    c.io.wrEn.poke(wrEn.B); c.io.commit.poke(true.B)
    c.io.illegal.expect(false.B)
    val old = c.io.rdata.peek().litValue
    c.clock.step(); idle(c)
    old
  }
  private def read(c: CsrFile, addr: Int): BigInt = { c.io.en.poke(true.B); c.io.addr.poke(addr.U); val v = c.io.rdata.peek().litValue; c.io.en.poke(false.B); v }

  "CsrFile" should "implement CSRRW / CSRRS / CSRRC semantics" in {
    test(new CsrFile(0)).withAnnotations(TestUtil.waves) { c =>
      idle(c)
      assert(access(c, CsrAddr.mscratch, 1, 0x12345678L) == 0)
      assert(access(c, CsrAddr.mscratch, 2, 0x0000000fL) == 0x12345678L)
      assert(read(c, CsrAddr.mscratch) == 0x1234567fL)
      assert(access(c, CsrAddr.mscratch, 3, 0x12340000L) == 0x1234567fL)
      assert(read(c, CsrAddr.mscratch) == 0x0000567fL)
      access(c, CsrAddr.mscratch, 2, 0xffffffffL, wrEn = false) // CSRRS with rs1 = x0: no write
      assert(read(c, CsrAddr.mscratch) == 0x0000567fL)
    }
  }

  it should "report misa = RV32IM, mhartid and fixed values, and apply WARL masks" in {
    test(new CsrFile(3)).withAnnotations(TestUtil.waves) { c =>
      idle(c)
      assert(read(c, CsrAddr.misa) == 0x40001100L)
      access(c, CsrAddr.misa, 1, 0)                    // writes ignored
      assert(read(c, CsrAddr.misa) == 0x40001100L)
      assert(read(c, CsrAddr.mhartid) == 3)
      assert(read(c, CsrAddr.mstatus) == 0x1800)       // MPP = 11
      access(c, CsrAddr.mtvec, 1, 0x80000107L)
      assert(read(c, CsrAddr.mtvec) == 0x80000104L)    // direct mode, aligned
      access(c, CsrAddr.mepc, 1, 0x80000003L)
      assert(read(c, CsrAddr.mepc) == 0x80000000L)
      access(c, CsrAddr.mie, 1, 0xffffffffL)
      assert(read(c, CsrAddr.mie) == 0x888)
    }
  }

  it should "flag unknown CSRs and writes to read-only CSRs as illegal, and not write them" in {
    test(new CsrFile(0)).withAnnotations(TestUtil.waves) { c =>
      idle(c)
      for ((addr, wr, ill) <- Seq((0x7c0, false, true), (0x105, true, true), (CsrAddr.mhartid, true, true),
        (CsrAddr.cycle, true, true), (CsrAddr.cycle, false, false), (CsrAddr.mvendorid, false, false))) {
        c.io.en.poke(true.B); c.io.addr.poke(addr.U); c.io.wrEn.poke(wr.B); c.io.op.poke(1.U)
        c.io.illegal.expect(ill.B, f"csr 0x$addr%03x wrEn=$wr")
      }
      idle(c)
      c.io.en.poke(false.B); c.io.addr.poke(0x7c0.U); c.io.illegal.expect(false.B) // only when en
    }
  }

  it should "count cycles always and instructions on commit, and let a write replace one half" in {
    test(new CsrFile(0)).withAnnotations(TestUtil.waves) { c =>
      idle(c)
      c.clock.step(10)
      assert(read(c, CsrAddr.mcycle) == 10)
      assert(read(c, CsrAddr.minstret) == 0)
      c.io.commit.poke(true.B); c.clock.step(4); c.io.commit.poke(false.B)
      assert(read(c, CsrAddr.minstret) == 4 && read(c, CsrAddr.instret) == 4)
      assert(read(c, CsrAddr.mcycle) == 14)
      access(c, CsrAddr.mcycle, 1, 0xfffffffeL)        // in cycle 14
      assert(read(c, CsrAddr.mcycle) == 0xfffffffeL)
      c.clock.step(3)
      assert(read(c, CsrAddr.mcycle) == 1 && read(c, CsrAddr.mcycleh) == 1 && read(c, CsrAddr.cycleh) == 1)
      access(c, CsrAddr.minstreth, 1, 7)
      assert(read(c, CsrAddr.minstreth) == 7 && read(c, CsrAddr.minstret) == 6)
    }
  }

  it should "save state on trap entry and restore it on mret" in {
    test(new CsrFile(0)).withAnnotations(TestUtil.waves) { c =>
      idle(c)
      access(c, CsrAddr.mstatus, 1, 0x8)              // MIE = 1
      assert(read(c, CsrAddr.mstatus) == 0x1808)
      c.io.trapEnter.poke(true.B); c.io.trapCause.poke(11.U); c.io.trapPc.poke("h80000010".U); c.io.trapVal.poke(0x55.U)
      c.clock.step(); idle(c)
      assert(read(c, CsrAddr.mepc) == 0x80000010L && read(c, CsrAddr.mcause) == 11 && read(c, CsrAddr.mtval) == 0x55)
      assert(read(c, CsrAddr.mstatus) == 0x1880)       // MPIE = 1, MIE = 0
      c.io.mretEnter.poke(true.B); c.clock.step(); idle(c)
      assert(read(c, CsrAddr.mstatus) == 0x1888)       // MIE = MPIE = 1, MPIE = 1
      c.io.mepc.expect("h80000010".U)
    }
  }
}
