# Stage 1: single-cycle RV32I ALU core in Chisel 3 (lab1)

The first core of the series, in package `rv32i`: a single-cycle processor that executes the 19 RV32I ALU
instructions (10 R-type, 9 register-immediate), one per clock cycle. It is the lab1 design (same modules, ports and
`memory.hex`) with the immediate path connected, plus the same test, waveform and Verilog tooling as the
Stage 4 (RV32IM) and Stage 5 (pipelined) projects.

## Requirements

- Java 11 or newer (tested with Java 21) and sbt 1.10 (https://www.scala-sbt.org/download/)
- No simulator to install: chiseltest runs on Treadle (pure Scala).
- For firtool output from `Emit`: CIRCT firtool 1.37.0 on the PATH (otherwise Chisel 3's built-in compiler is used).
- To view waveforms: GTKWave.

Pinned in `build.sbt`: Scala 2.13.12, Chisel 3.6.1 (+ chisel3-plugin), chiseltest 0.6.2; `project/build.properties`: sbt 1.10.2.

## Commands

```bash
sbt test
```

```bash
sbt "testOnly rv32i.RV32IRCoreSpec"
```

Generate SystemVerilog for `RV32IRCore` and `RV32ITestWrapper` (with `memory.hex`) into `generated/`:

```bash
sbt "runMain rv32i.Emit"
```

`sbt "runMain rv32i.GenerateRV32IRCore"` and `sbt "runMain rv32i.GenerateRV32ITestWrapper"` (lab1's names) generate one each.

## Source files (`src/main/scala/rv32i/`)

| File | Contents |
|---|---|
| `CoreParams.scala` | `xlen`, `numRegs` |
| `ALU.scala` | `ALUOp` codes and the combinational ALU |
| `Decoder.scala` | Decodes the 10 R-type and 9 I-type ALU instructions; `valid` = 0 for anything else |
| `ImmediateGenerator.scala` | Sign-extended I-type immediate |
| `RegisterFile.scala` | 32 × 32, 2 read ports, 1 write port, x0 hardwired to zero, initial values, `debugRead` |
| `InstructionMemory.scala` | ROM loaded from a hex file (comments and `_` allowed) |
| `RV32IRCore.scala` | The core: `imemAddr`/`imemInst`, `debugPC`, `debugX1..X4`, `trace` |
| `RV32ITestWrapper.scala` | Core + instruction memory from a hex file |
| `Trace.scala` | Per-cycle trace bundle (pc, inst, valid, rd, rd value) |
| `RV32IEncoding.scala` | lab1's instruction encoders |
| `RefModel.scala` | Instruction-level reference model |
| `Emit.scala` | SystemVerilog generation (`Emit`, `GenerateRV32IRCore`, `GenerateRV32ITestWrapper`, `Lab1.regs`) |

`memory.hex` is lab1's program (10 R-type instructions, run with x1 = 10, x2 = 3).

## Tests (`src/test/scala/rv32i/`)

| Suite | What it checks |
|---|---|
| `ALUSpec` | lab1's checks; every operation on all pairs of 22 edge values; 3,000 random pairs; unused codes give 0 |
| `DecoderSpec` | lab1's 10 R-type and 10 I-type cases; 27 encodings that must be rejected (other opcodes, bad funct7, M extension); all 128 major opcodes |
| `ImmediateGeneratorSpec` | lab1's values and all 4,096 12-bit immediates |
| `RegisterFileSpec` | lab1's cases; initial values (x0 stays 0); all registers; old value during a write |
| `InstructionMemorySpec` | Hex parsing with comments and separators; reads past the end; the project's `memory.hex` |
| `RV32IRCoreSpec` | lab1's `memory.hex` on `RV32ITestWrapper`; all 19 instructions on edge values; `li` constants; dependency chains and x0; unsupported words as no-ops; preset registers; 3,000 random instructions. Lockstep with `RefModel` every cycle |
| `TimingSpec` | One instruction per cycle, pc + 4 per cycle, result visible after the edge |
| `WaveformSpec` | Three demo runs (also checked against `RefModel`) that write VCDs and GTKWave sessions to `waves/` |

Helpers: `Asm.scala` (assembler, `li` with ALU instructions only), `CoreSim.scala` (lockstep harness),
`Disasm.scala`, `Gtkw.scala` (GTKWave session writer), `TestUtil.scala` (`WAVES` switch).

## Waveforms with GTKWave

```bash
sbt "testOnly rv32i.WaveformSpec"
```

| Demo | Contents |
|---|---|
| `waves/lab1_rtype/` | lab1's `memory.hex` on `RV32ITestWrapper` (x1 = 10, x2 = 3) |
| `waves/alu_imm/` | The I-type instructions and a 32-bit constant built with ADDI/SLLI/ORI |
| `waves/mixed/` | All R-type operations, a dependency chain, two unsupported words executed as no-ops |

Each folder holds the VCD, `core.gtkw` (session), `inst.filter` (instruction words as assembly), `aluop.filter`
(ALU operation names) and `program.lst`. Open from the project root:

```bash
gtkwave waves/lab1_rtype/RV32ITestWrapper.vcd waves/lab1_rtype/core.gtkw
```

```bash
gtkwave waves/alu_imm/RV32IRCore.vcd waves/alu_imm/core.gtkw
```

Groups in `core.gtkw`: Clock; Fetch (`pc`, instruction as assembly and hex); Decoder (`valid`, `aluOp` by name,
`aluSrc`, `rs1`, `rs2`, `rd`, `regWrite`); Operands and ALU (register values, immediate, ALU inputs and result);
Write-back (`rdAddr`, `rdData`); Registers x1..x15 (signed decimal).

A VCD for any test: `WAVES=1 sbt test` writes `test_run_dir/<test name>/<Module>.vcd`.

Assembly text on any instruction signal, for any program: `tools/rv32im_filter.py` is a GTKWave translate filter
process (it decodes the full RV32IM set, a superset of this stage). Make it executable (`chmod +x tools/rv32im_filter.py`),
then in GTKWave select the instruction trace → Data Format → Hex, then Data Format → Translate Filter Process → Enable
and Select → `tools/rv32im_filter.py`.

See `DESIGN_NOTES.md` for the datapath, the changes from lab1 and every design choice.
