module Decoder(
  input  [31:0] io_instr, // @[src/main/scala/rv32i/Decoder.scala 13:14]
  output [4:0]  io_rs1, // @[src/main/scala/rv32i/Decoder.scala 13:14]
  output [4:0]  io_rs2, // @[src/main/scala/rv32i/Decoder.scala 13:14]
  output [4:0]  io_rd, // @[src/main/scala/rv32i/Decoder.scala 13:14]
  output [3:0]  io_aluOp, // @[src/main/scala/rv32i/Decoder.scala 13:14]
  output        io_aluSrc, // @[src/main/scala/rv32i/Decoder.scala 13:14]
  output        io_regWrite, // @[src/main/scala/rv32i/Decoder.scala 13:14]
  output        io_valid // @[src/main/scala/rv32i/Decoder.scala 13:14]
);
  wire [6:0] opcode = io_instr[6:0]; // @[src/main/scala/rv32i/Decoder.scala 24:24]
  wire [2:0] funct3 = io_instr[14:12]; // @[src/main/scala/rv32i/Decoder.scala 25:24]
  wire [6:0] funct7 = io_instr[31:25]; // @[src/main/scala/rv32i/Decoder.scala 26:24]
  wire [9:0] _io_aluOp_T = {funct7,funct3}; // @[src/main/scala/rv32i/Decoder.scala 38:30]
  wire [3:0] _io_aluOp_T_2 = 10'h0 == _io_aluOp_T ? 4'h0 : 4'hf; // @[src/main/scala/rv32i/Decoder.scala 38:58]
  wire [3:0] _io_aluOp_T_4 = 10'h100 == _io_aluOp_T ? 4'h1 : _io_aluOp_T_2; // @[src/main/scala/rv32i/Decoder.scala 38:58]
  wire [3:0] _io_aluOp_T_6 = 10'h1 == _io_aluOp_T ? 4'h2 : _io_aluOp_T_4; // @[src/main/scala/rv32i/Decoder.scala 38:58]
  wire [3:0] _io_aluOp_T_8 = 10'h2 == _io_aluOp_T ? 4'h3 : _io_aluOp_T_6; // @[src/main/scala/rv32i/Decoder.scala 38:58]
  wire [3:0] _io_aluOp_T_10 = 10'h3 == _io_aluOp_T ? 4'h4 : _io_aluOp_T_8; // @[src/main/scala/rv32i/Decoder.scala 38:58]
  wire [3:0] _io_aluOp_T_12 = 10'h4 == _io_aluOp_T ? 4'h5 : _io_aluOp_T_10; // @[src/main/scala/rv32i/Decoder.scala 38:58]
  wire [3:0] _io_aluOp_T_14 = 10'h5 == _io_aluOp_T ? 4'h6 : _io_aluOp_T_12; // @[src/main/scala/rv32i/Decoder.scala 38:58]
  wire [3:0] _io_aluOp_T_16 = 10'h105 == _io_aluOp_T ? 4'h7 : _io_aluOp_T_14; // @[src/main/scala/rv32i/Decoder.scala 38:58]
  wire [3:0] _io_aluOp_T_18 = 10'h6 == _io_aluOp_T ? 4'h8 : _io_aluOp_T_16; // @[src/main/scala/rv32i/Decoder.scala 38:58]
  wire [3:0] _io_aluOp_T_20 = 10'h7 == _io_aluOp_T ? 4'h9 : _io_aluOp_T_18; // @[src/main/scala/rv32i/Decoder.scala 38:58]
  wire  _io_valid_T = io_aluOp != 4'hf; // @[src/main/scala/rv32i/Decoder.scala 50:26]
  wire [3:0] _GEN_0 = opcode == 7'h33 ? _io_aluOp_T_20 : 4'hf; // @[src/main/scala/rv32i/Decoder.scala 32:13 37:33 38:14]
  wire  _GEN_1 = opcode == 7'h33 & io_aluOp != 4'hf; // @[src/main/scala/rv32i/Decoder.scala 34:13 37:33 50:14]
  wire  _io_aluOp_T_21 = funct7 == 7'h0; // @[src/main/scala/rv32i/Decoder.scala 63:30]
  wire [3:0] _io_aluOp_T_22 = funct7 == 7'h0 ? 4'h2 : 4'hf; // @[src/main/scala/rv32i/Decoder.scala 63:22]
  wire [3:0] _io_aluOp_T_25 = funct7 == 7'h20 ? 4'h7 : 4'hf; // @[src/main/scala/rv32i/Decoder.scala 65:22]
  wire [3:0] _io_aluOp_T_26 = _io_aluOp_T_21 ? 4'h6 : _io_aluOp_T_25; // @[src/main/scala/rv32i/Decoder.scala 64:22]
  wire [3:0] _io_aluOp_T_28 = 3'h2 == funct3 ? 4'h3 : 4'h0; // @[src/main/scala/rv32i/Decoder.scala 56:45]
  wire [3:0] _io_aluOp_T_30 = 3'h3 == funct3 ? 4'h4 : _io_aluOp_T_28; // @[src/main/scala/rv32i/Decoder.scala 56:45]
  wire [3:0] _io_aluOp_T_32 = 3'h4 == funct3 ? 4'h5 : _io_aluOp_T_30; // @[src/main/scala/rv32i/Decoder.scala 56:45]
  wire [3:0] _io_aluOp_T_34 = 3'h6 == funct3 ? 4'h8 : _io_aluOp_T_32; // @[src/main/scala/rv32i/Decoder.scala 56:45]
  wire [3:0] _io_aluOp_T_36 = 3'h7 == funct3 ? 4'h9 : _io_aluOp_T_34; // @[src/main/scala/rv32i/Decoder.scala 56:45]
  wire [3:0] _io_aluOp_T_38 = 3'h1 == funct3 ? _io_aluOp_T_22 : _io_aluOp_T_36; // @[src/main/scala/rv32i/Decoder.scala 56:45]
  wire [3:0] _io_aluOp_T_40 = 3'h5 == funct3 ? _io_aluOp_T_26 : _io_aluOp_T_38; // @[src/main/scala/rv32i/Decoder.scala 56:45]
  assign io_rs1 = io_instr[19:15]; // @[src/main/scala/rv32i/Decoder.scala 28:21]
  assign io_rs2 = io_instr[24:20]; // @[src/main/scala/rv32i/Decoder.scala 29:21]
  assign io_rd = io_instr[11:7]; // @[src/main/scala/rv32i/Decoder.scala 30:21]
  assign io_aluOp = opcode == 7'h13 ? _io_aluOp_T_40 : _GEN_0; // @[src/main/scala/rv32i/Decoder.scala 54:33 56:14]
  assign io_aluSrc = opcode == 7'h13; // @[src/main/scala/rv32i/Decoder.scala 54:15]
  assign io_regWrite = io_valid; // @[src/main/scala/rv32i/Decoder.scala 70:15]
  assign io_valid = opcode == 7'h13 ? _io_valid_T : _GEN_1; // @[src/main/scala/rv32i/Decoder.scala 54:33 67:14]
endmodule
module ImmediateGenerator(
  input  [31:0] io_instr, // @[src/main/scala/rv32i/ImmediateGenerator.scala 7:14]
  output [31:0] io_imm // @[src/main/scala/rv32i/ImmediateGenerator.scala 7:14]
);
  wire [11:0] _io_imm_T_1 = io_instr[31:20]; // @[src/main/scala/rv32i/ImmediateGenerator.scala 11:30]
  assign io_imm = {{20{_io_imm_T_1[11]}},_io_imm_T_1}; // @[src/main/scala/rv32i/ImmediateGenerator.scala 11:49]
endmodule
module RegisterFile(
  input         clock,
  input         reset,
  input  [4:0]  io_rs1, // @[src/main/scala/rv32i/RegisterFile.scala 16:14]
  input  [4:0]  io_rs2, // @[src/main/scala/rv32i/RegisterFile.scala 16:14]
  input  [4:0]  io_rd, // @[src/main/scala/rv32i/RegisterFile.scala 16:14]
  input  [31:0] io_writeData, // @[src/main/scala/rv32i/RegisterFile.scala 16:14]
  input         io_writeEnable, // @[src/main/scala/rv32i/RegisterFile.scala 16:14]
  output [31:0] io_readData1, // @[src/main/scala/rv32i/RegisterFile.scala 16:14]
  output [31:0] io_readData2, // @[src/main/scala/rv32i/RegisterFile.scala 16:14]
  output [31:0] io_debugRead_1, // @[src/main/scala/rv32i/RegisterFile.scala 16:14]
  output [31:0] io_debugRead_2, // @[src/main/scala/rv32i/RegisterFile.scala 16:14]
  output [31:0] io_debugRead_3, // @[src/main/scala/rv32i/RegisterFile.scala 16:14]
  output [31:0] io_debugRead_4 // @[src/main/scala/rv32i/RegisterFile.scala 16:14]
);
`ifdef RANDOMIZE_REG_INIT
  reg [31:0] _RAND_0;
  reg [31:0] _RAND_1;
  reg [31:0] _RAND_2;
  reg [31:0] _RAND_3;
  reg [31:0] _RAND_4;
  reg [31:0] _RAND_5;
  reg [31:0] _RAND_6;
  reg [31:0] _RAND_7;
  reg [31:0] _RAND_8;
  reg [31:0] _RAND_9;
  reg [31:0] _RAND_10;
  reg [31:0] _RAND_11;
  reg [31:0] _RAND_12;
  reg [31:0] _RAND_13;
  reg [31:0] _RAND_14;
  reg [31:0] _RAND_15;
  reg [31:0] _RAND_16;
  reg [31:0] _RAND_17;
  reg [31:0] _RAND_18;
  reg [31:0] _RAND_19;
  reg [31:0] _RAND_20;
  reg [31:0] _RAND_21;
  reg [31:0] _RAND_22;
  reg [31:0] _RAND_23;
  reg [31:0] _RAND_24;
  reg [31:0] _RAND_25;
  reg [31:0] _RAND_26;
  reg [31:0] _RAND_27;
  reg [31:0] _RAND_28;
  reg [31:0] _RAND_29;
  reg [31:0] _RAND_30;
  reg [31:0] _RAND_31;
`endif // RANDOMIZE_REG_INIT
  reg [31:0] regs_0; // @[src/main/scala/rv32i/RegisterFile.scala 30:21]
  reg [31:0] regs_1; // @[src/main/scala/rv32i/RegisterFile.scala 30:21]
  reg [31:0] regs_2; // @[src/main/scala/rv32i/RegisterFile.scala 30:21]
  reg [31:0] regs_3; // @[src/main/scala/rv32i/RegisterFile.scala 30:21]
  reg [31:0] regs_4; // @[src/main/scala/rv32i/RegisterFile.scala 30:21]
  reg [31:0] regs_5; // @[src/main/scala/rv32i/RegisterFile.scala 30:21]
  reg [31:0] regs_6; // @[src/main/scala/rv32i/RegisterFile.scala 30:21]
  reg [31:0] regs_7; // @[src/main/scala/rv32i/RegisterFile.scala 30:21]
  reg [31:0] regs_8; // @[src/main/scala/rv32i/RegisterFile.scala 30:21]
  reg [31:0] regs_9; // @[src/main/scala/rv32i/RegisterFile.scala 30:21]
  reg [31:0] regs_10; // @[src/main/scala/rv32i/RegisterFile.scala 30:21]
  reg [31:0] regs_11; // @[src/main/scala/rv32i/RegisterFile.scala 30:21]
  reg [31:0] regs_12; // @[src/main/scala/rv32i/RegisterFile.scala 30:21]
  reg [31:0] regs_13; // @[src/main/scala/rv32i/RegisterFile.scala 30:21]
  reg [31:0] regs_14; // @[src/main/scala/rv32i/RegisterFile.scala 30:21]
  reg [31:0] regs_15; // @[src/main/scala/rv32i/RegisterFile.scala 30:21]
  reg [31:0] regs_16; // @[src/main/scala/rv32i/RegisterFile.scala 30:21]
  reg [31:0] regs_17; // @[src/main/scala/rv32i/RegisterFile.scala 30:21]
  reg [31:0] regs_18; // @[src/main/scala/rv32i/RegisterFile.scala 30:21]
  reg [31:0] regs_19; // @[src/main/scala/rv32i/RegisterFile.scala 30:21]
  reg [31:0] regs_20; // @[src/main/scala/rv32i/RegisterFile.scala 30:21]
  reg [31:0] regs_21; // @[src/main/scala/rv32i/RegisterFile.scala 30:21]
  reg [31:0] regs_22; // @[src/main/scala/rv32i/RegisterFile.scala 30:21]
  reg [31:0] regs_23; // @[src/main/scala/rv32i/RegisterFile.scala 30:21]
  reg [31:0] regs_24; // @[src/main/scala/rv32i/RegisterFile.scala 30:21]
  reg [31:0] regs_25; // @[src/main/scala/rv32i/RegisterFile.scala 30:21]
  reg [31:0] regs_26; // @[src/main/scala/rv32i/RegisterFile.scala 30:21]
  reg [31:0] regs_27; // @[src/main/scala/rv32i/RegisterFile.scala 30:21]
  reg [31:0] regs_28; // @[src/main/scala/rv32i/RegisterFile.scala 30:21]
  reg [31:0] regs_29; // @[src/main/scala/rv32i/RegisterFile.scala 30:21]
  reg [31:0] regs_30; // @[src/main/scala/rv32i/RegisterFile.scala 30:21]
  reg [31:0] regs_31; // @[src/main/scala/rv32i/RegisterFile.scala 30:21]
  wire [31:0] _GEN_1 = 5'h1 == io_rs1 ? regs_1 : regs_0; // @[src/main/scala/rv32i/RegisterFile.scala 32:{22,22}]
  wire [31:0] _GEN_2 = 5'h2 == io_rs1 ? regs_2 : _GEN_1; // @[src/main/scala/rv32i/RegisterFile.scala 32:{22,22}]
  wire [31:0] _GEN_3 = 5'h3 == io_rs1 ? regs_3 : _GEN_2; // @[src/main/scala/rv32i/RegisterFile.scala 32:{22,22}]
  wire [31:0] _GEN_4 = 5'h4 == io_rs1 ? regs_4 : _GEN_3; // @[src/main/scala/rv32i/RegisterFile.scala 32:{22,22}]
  wire [31:0] _GEN_5 = 5'h5 == io_rs1 ? regs_5 : _GEN_4; // @[src/main/scala/rv32i/RegisterFile.scala 32:{22,22}]
  wire [31:0] _GEN_6 = 5'h6 == io_rs1 ? regs_6 : _GEN_5; // @[src/main/scala/rv32i/RegisterFile.scala 32:{22,22}]
  wire [31:0] _GEN_7 = 5'h7 == io_rs1 ? regs_7 : _GEN_6; // @[src/main/scala/rv32i/RegisterFile.scala 32:{22,22}]
  wire [31:0] _GEN_8 = 5'h8 == io_rs1 ? regs_8 : _GEN_7; // @[src/main/scala/rv32i/RegisterFile.scala 32:{22,22}]
  wire [31:0] _GEN_9 = 5'h9 == io_rs1 ? regs_9 : _GEN_8; // @[src/main/scala/rv32i/RegisterFile.scala 32:{22,22}]
  wire [31:0] _GEN_10 = 5'ha == io_rs1 ? regs_10 : _GEN_9; // @[src/main/scala/rv32i/RegisterFile.scala 32:{22,22}]
  wire [31:0] _GEN_11 = 5'hb == io_rs1 ? regs_11 : _GEN_10; // @[src/main/scala/rv32i/RegisterFile.scala 32:{22,22}]
  wire [31:0] _GEN_12 = 5'hc == io_rs1 ? regs_12 : _GEN_11; // @[src/main/scala/rv32i/RegisterFile.scala 32:{22,22}]
  wire [31:0] _GEN_13 = 5'hd == io_rs1 ? regs_13 : _GEN_12; // @[src/main/scala/rv32i/RegisterFile.scala 32:{22,22}]
  wire [31:0] _GEN_14 = 5'he == io_rs1 ? regs_14 : _GEN_13; // @[src/main/scala/rv32i/RegisterFile.scala 32:{22,22}]
  wire [31:0] _GEN_15 = 5'hf == io_rs1 ? regs_15 : _GEN_14; // @[src/main/scala/rv32i/RegisterFile.scala 32:{22,22}]
  wire [31:0] _GEN_16 = 5'h10 == io_rs1 ? regs_16 : _GEN_15; // @[src/main/scala/rv32i/RegisterFile.scala 32:{22,22}]
  wire [31:0] _GEN_17 = 5'h11 == io_rs1 ? regs_17 : _GEN_16; // @[src/main/scala/rv32i/RegisterFile.scala 32:{22,22}]
  wire [31:0] _GEN_18 = 5'h12 == io_rs1 ? regs_18 : _GEN_17; // @[src/main/scala/rv32i/RegisterFile.scala 32:{22,22}]
  wire [31:0] _GEN_19 = 5'h13 == io_rs1 ? regs_19 : _GEN_18; // @[src/main/scala/rv32i/RegisterFile.scala 32:{22,22}]
  wire [31:0] _GEN_20 = 5'h14 == io_rs1 ? regs_20 : _GEN_19; // @[src/main/scala/rv32i/RegisterFile.scala 32:{22,22}]
  wire [31:0] _GEN_21 = 5'h15 == io_rs1 ? regs_21 : _GEN_20; // @[src/main/scala/rv32i/RegisterFile.scala 32:{22,22}]
  wire [31:0] _GEN_22 = 5'h16 == io_rs1 ? regs_22 : _GEN_21; // @[src/main/scala/rv32i/RegisterFile.scala 32:{22,22}]
  wire [31:0] _GEN_23 = 5'h17 == io_rs1 ? regs_23 : _GEN_22; // @[src/main/scala/rv32i/RegisterFile.scala 32:{22,22}]
  wire [31:0] _GEN_24 = 5'h18 == io_rs1 ? regs_24 : _GEN_23; // @[src/main/scala/rv32i/RegisterFile.scala 32:{22,22}]
  wire [31:0] _GEN_25 = 5'h19 == io_rs1 ? regs_25 : _GEN_24; // @[src/main/scala/rv32i/RegisterFile.scala 32:{22,22}]
  wire [31:0] _GEN_26 = 5'h1a == io_rs1 ? regs_26 : _GEN_25; // @[src/main/scala/rv32i/RegisterFile.scala 32:{22,22}]
  wire [31:0] _GEN_27 = 5'h1b == io_rs1 ? regs_27 : _GEN_26; // @[src/main/scala/rv32i/RegisterFile.scala 32:{22,22}]
  wire [31:0] _GEN_28 = 5'h1c == io_rs1 ? regs_28 : _GEN_27; // @[src/main/scala/rv32i/RegisterFile.scala 32:{22,22}]
  wire [31:0] _GEN_29 = 5'h1d == io_rs1 ? regs_29 : _GEN_28; // @[src/main/scala/rv32i/RegisterFile.scala 32:{22,22}]
  wire [31:0] _GEN_30 = 5'h1e == io_rs1 ? regs_30 : _GEN_29; // @[src/main/scala/rv32i/RegisterFile.scala 32:{22,22}]
  wire [31:0] _GEN_31 = 5'h1f == io_rs1 ? regs_31 : _GEN_30; // @[src/main/scala/rv32i/RegisterFile.scala 32:{22,22}]
  wire [31:0] _GEN_33 = 5'h1 == io_rs2 ? regs_1 : regs_0; // @[src/main/scala/rv32i/RegisterFile.scala 33:{22,22}]
  wire [31:0] _GEN_34 = 5'h2 == io_rs2 ? regs_2 : _GEN_33; // @[src/main/scala/rv32i/RegisterFile.scala 33:{22,22}]
  wire [31:0] _GEN_35 = 5'h3 == io_rs2 ? regs_3 : _GEN_34; // @[src/main/scala/rv32i/RegisterFile.scala 33:{22,22}]
  wire [31:0] _GEN_36 = 5'h4 == io_rs2 ? regs_4 : _GEN_35; // @[src/main/scala/rv32i/RegisterFile.scala 33:{22,22}]
  wire [31:0] _GEN_37 = 5'h5 == io_rs2 ? regs_5 : _GEN_36; // @[src/main/scala/rv32i/RegisterFile.scala 33:{22,22}]
  wire [31:0] _GEN_38 = 5'h6 == io_rs2 ? regs_6 : _GEN_37; // @[src/main/scala/rv32i/RegisterFile.scala 33:{22,22}]
  wire [31:0] _GEN_39 = 5'h7 == io_rs2 ? regs_7 : _GEN_38; // @[src/main/scala/rv32i/RegisterFile.scala 33:{22,22}]
  wire [31:0] _GEN_40 = 5'h8 == io_rs2 ? regs_8 : _GEN_39; // @[src/main/scala/rv32i/RegisterFile.scala 33:{22,22}]
  wire [31:0] _GEN_41 = 5'h9 == io_rs2 ? regs_9 : _GEN_40; // @[src/main/scala/rv32i/RegisterFile.scala 33:{22,22}]
  wire [31:0] _GEN_42 = 5'ha == io_rs2 ? regs_10 : _GEN_41; // @[src/main/scala/rv32i/RegisterFile.scala 33:{22,22}]
  wire [31:0] _GEN_43 = 5'hb == io_rs2 ? regs_11 : _GEN_42; // @[src/main/scala/rv32i/RegisterFile.scala 33:{22,22}]
  wire [31:0] _GEN_44 = 5'hc == io_rs2 ? regs_12 : _GEN_43; // @[src/main/scala/rv32i/RegisterFile.scala 33:{22,22}]
  wire [31:0] _GEN_45 = 5'hd == io_rs2 ? regs_13 : _GEN_44; // @[src/main/scala/rv32i/RegisterFile.scala 33:{22,22}]
  wire [31:0] _GEN_46 = 5'he == io_rs2 ? regs_14 : _GEN_45; // @[src/main/scala/rv32i/RegisterFile.scala 33:{22,22}]
  wire [31:0] _GEN_47 = 5'hf == io_rs2 ? regs_15 : _GEN_46; // @[src/main/scala/rv32i/RegisterFile.scala 33:{22,22}]
  wire [31:0] _GEN_48 = 5'h10 == io_rs2 ? regs_16 : _GEN_47; // @[src/main/scala/rv32i/RegisterFile.scala 33:{22,22}]
  wire [31:0] _GEN_49 = 5'h11 == io_rs2 ? regs_17 : _GEN_48; // @[src/main/scala/rv32i/RegisterFile.scala 33:{22,22}]
  wire [31:0] _GEN_50 = 5'h12 == io_rs2 ? regs_18 : _GEN_49; // @[src/main/scala/rv32i/RegisterFile.scala 33:{22,22}]
  wire [31:0] _GEN_51 = 5'h13 == io_rs2 ? regs_19 : _GEN_50; // @[src/main/scala/rv32i/RegisterFile.scala 33:{22,22}]
  wire [31:0] _GEN_52 = 5'h14 == io_rs2 ? regs_20 : _GEN_51; // @[src/main/scala/rv32i/RegisterFile.scala 33:{22,22}]
  wire [31:0] _GEN_53 = 5'h15 == io_rs2 ? regs_21 : _GEN_52; // @[src/main/scala/rv32i/RegisterFile.scala 33:{22,22}]
  wire [31:0] _GEN_54 = 5'h16 == io_rs2 ? regs_22 : _GEN_53; // @[src/main/scala/rv32i/RegisterFile.scala 33:{22,22}]
  wire [31:0] _GEN_55 = 5'h17 == io_rs2 ? regs_23 : _GEN_54; // @[src/main/scala/rv32i/RegisterFile.scala 33:{22,22}]
  wire [31:0] _GEN_56 = 5'h18 == io_rs2 ? regs_24 : _GEN_55; // @[src/main/scala/rv32i/RegisterFile.scala 33:{22,22}]
  wire [31:0] _GEN_57 = 5'h19 == io_rs2 ? regs_25 : _GEN_56; // @[src/main/scala/rv32i/RegisterFile.scala 33:{22,22}]
  wire [31:0] _GEN_58 = 5'h1a == io_rs2 ? regs_26 : _GEN_57; // @[src/main/scala/rv32i/RegisterFile.scala 33:{22,22}]
  wire [31:0] _GEN_59 = 5'h1b == io_rs2 ? regs_27 : _GEN_58; // @[src/main/scala/rv32i/RegisterFile.scala 33:{22,22}]
  wire [31:0] _GEN_60 = 5'h1c == io_rs2 ? regs_28 : _GEN_59; // @[src/main/scala/rv32i/RegisterFile.scala 33:{22,22}]
  wire [31:0] _GEN_61 = 5'h1d == io_rs2 ? regs_29 : _GEN_60; // @[src/main/scala/rv32i/RegisterFile.scala 33:{22,22}]
  wire [31:0] _GEN_62 = 5'h1e == io_rs2 ? regs_30 : _GEN_61; // @[src/main/scala/rv32i/RegisterFile.scala 33:{22,22}]
  wire [31:0] _GEN_63 = 5'h1f == io_rs2 ? regs_31 : _GEN_62; // @[src/main/scala/rv32i/RegisterFile.scala 33:{22,22}]
  assign io_readData1 = io_rs1 == 5'h0 ? 32'h0 : _GEN_31; // @[src/main/scala/rv32i/RegisterFile.scala 32:22]
  assign io_readData2 = io_rs2 == 5'h0 ? 32'h0 : _GEN_63; // @[src/main/scala/rv32i/RegisterFile.scala 33:22]
  assign io_debugRead_1 = regs_1; // @[src/main/scala/rv32i/RegisterFile.scala 40:21]
  assign io_debugRead_2 = regs_2; // @[src/main/scala/rv32i/RegisterFile.scala 40:21]
  assign io_debugRead_3 = regs_3; // @[src/main/scala/rv32i/RegisterFile.scala 40:21]
  assign io_debugRead_4 = regs_4; // @[src/main/scala/rv32i/RegisterFile.scala 40:21]
  always @(posedge clock) begin
    if (reset) begin // @[src/main/scala/rv32i/RegisterFile.scala 30:21]
      regs_0 <= 32'h0; // @[src/main/scala/rv32i/RegisterFile.scala 30:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[src/main/scala/rv32i/RegisterFile.scala 35:41]
      if (5'h0 == io_rd) begin // @[src/main/scala/rv32i/RegisterFile.scala 36:17]
        regs_0 <= io_writeData; // @[src/main/scala/rv32i/RegisterFile.scala 36:17]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegisterFile.scala 30:21]
      regs_1 <= 32'ha; // @[src/main/scala/rv32i/RegisterFile.scala 30:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[src/main/scala/rv32i/RegisterFile.scala 35:41]
      if (5'h1 == io_rd) begin // @[src/main/scala/rv32i/RegisterFile.scala 36:17]
        regs_1 <= io_writeData; // @[src/main/scala/rv32i/RegisterFile.scala 36:17]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegisterFile.scala 30:21]
      regs_2 <= 32'h3; // @[src/main/scala/rv32i/RegisterFile.scala 30:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[src/main/scala/rv32i/RegisterFile.scala 35:41]
      if (5'h2 == io_rd) begin // @[src/main/scala/rv32i/RegisterFile.scala 36:17]
        regs_2 <= io_writeData; // @[src/main/scala/rv32i/RegisterFile.scala 36:17]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegisterFile.scala 30:21]
      regs_3 <= 32'h0; // @[src/main/scala/rv32i/RegisterFile.scala 30:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[src/main/scala/rv32i/RegisterFile.scala 35:41]
      if (5'h3 == io_rd) begin // @[src/main/scala/rv32i/RegisterFile.scala 36:17]
        regs_3 <= io_writeData; // @[src/main/scala/rv32i/RegisterFile.scala 36:17]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegisterFile.scala 30:21]
      regs_4 <= 32'h0; // @[src/main/scala/rv32i/RegisterFile.scala 30:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[src/main/scala/rv32i/RegisterFile.scala 35:41]
      if (5'h4 == io_rd) begin // @[src/main/scala/rv32i/RegisterFile.scala 36:17]
        regs_4 <= io_writeData; // @[src/main/scala/rv32i/RegisterFile.scala 36:17]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegisterFile.scala 30:21]
      regs_5 <= 32'h0; // @[src/main/scala/rv32i/RegisterFile.scala 30:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[src/main/scala/rv32i/RegisterFile.scala 35:41]
      if (5'h5 == io_rd) begin // @[src/main/scala/rv32i/RegisterFile.scala 36:17]
        regs_5 <= io_writeData; // @[src/main/scala/rv32i/RegisterFile.scala 36:17]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegisterFile.scala 30:21]
      regs_6 <= 32'h0; // @[src/main/scala/rv32i/RegisterFile.scala 30:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[src/main/scala/rv32i/RegisterFile.scala 35:41]
      if (5'h6 == io_rd) begin // @[src/main/scala/rv32i/RegisterFile.scala 36:17]
        regs_6 <= io_writeData; // @[src/main/scala/rv32i/RegisterFile.scala 36:17]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegisterFile.scala 30:21]
      regs_7 <= 32'h0; // @[src/main/scala/rv32i/RegisterFile.scala 30:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[src/main/scala/rv32i/RegisterFile.scala 35:41]
      if (5'h7 == io_rd) begin // @[src/main/scala/rv32i/RegisterFile.scala 36:17]
        regs_7 <= io_writeData; // @[src/main/scala/rv32i/RegisterFile.scala 36:17]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegisterFile.scala 30:21]
      regs_8 <= 32'h0; // @[src/main/scala/rv32i/RegisterFile.scala 30:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[src/main/scala/rv32i/RegisterFile.scala 35:41]
      if (5'h8 == io_rd) begin // @[src/main/scala/rv32i/RegisterFile.scala 36:17]
        regs_8 <= io_writeData; // @[src/main/scala/rv32i/RegisterFile.scala 36:17]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegisterFile.scala 30:21]
      regs_9 <= 32'h0; // @[src/main/scala/rv32i/RegisterFile.scala 30:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[src/main/scala/rv32i/RegisterFile.scala 35:41]
      if (5'h9 == io_rd) begin // @[src/main/scala/rv32i/RegisterFile.scala 36:17]
        regs_9 <= io_writeData; // @[src/main/scala/rv32i/RegisterFile.scala 36:17]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegisterFile.scala 30:21]
      regs_10 <= 32'h0; // @[src/main/scala/rv32i/RegisterFile.scala 30:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[src/main/scala/rv32i/RegisterFile.scala 35:41]
      if (5'ha == io_rd) begin // @[src/main/scala/rv32i/RegisterFile.scala 36:17]
        regs_10 <= io_writeData; // @[src/main/scala/rv32i/RegisterFile.scala 36:17]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegisterFile.scala 30:21]
      regs_11 <= 32'h0; // @[src/main/scala/rv32i/RegisterFile.scala 30:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[src/main/scala/rv32i/RegisterFile.scala 35:41]
      if (5'hb == io_rd) begin // @[src/main/scala/rv32i/RegisterFile.scala 36:17]
        regs_11 <= io_writeData; // @[src/main/scala/rv32i/RegisterFile.scala 36:17]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegisterFile.scala 30:21]
      regs_12 <= 32'h0; // @[src/main/scala/rv32i/RegisterFile.scala 30:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[src/main/scala/rv32i/RegisterFile.scala 35:41]
      if (5'hc == io_rd) begin // @[src/main/scala/rv32i/RegisterFile.scala 36:17]
        regs_12 <= io_writeData; // @[src/main/scala/rv32i/RegisterFile.scala 36:17]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegisterFile.scala 30:21]
      regs_13 <= 32'h0; // @[src/main/scala/rv32i/RegisterFile.scala 30:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[src/main/scala/rv32i/RegisterFile.scala 35:41]
      if (5'hd == io_rd) begin // @[src/main/scala/rv32i/RegisterFile.scala 36:17]
        regs_13 <= io_writeData; // @[src/main/scala/rv32i/RegisterFile.scala 36:17]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegisterFile.scala 30:21]
      regs_14 <= 32'h0; // @[src/main/scala/rv32i/RegisterFile.scala 30:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[src/main/scala/rv32i/RegisterFile.scala 35:41]
      if (5'he == io_rd) begin // @[src/main/scala/rv32i/RegisterFile.scala 36:17]
        regs_14 <= io_writeData; // @[src/main/scala/rv32i/RegisterFile.scala 36:17]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegisterFile.scala 30:21]
      regs_15 <= 32'h0; // @[src/main/scala/rv32i/RegisterFile.scala 30:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[src/main/scala/rv32i/RegisterFile.scala 35:41]
      if (5'hf == io_rd) begin // @[src/main/scala/rv32i/RegisterFile.scala 36:17]
        regs_15 <= io_writeData; // @[src/main/scala/rv32i/RegisterFile.scala 36:17]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegisterFile.scala 30:21]
      regs_16 <= 32'h0; // @[src/main/scala/rv32i/RegisterFile.scala 30:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[src/main/scala/rv32i/RegisterFile.scala 35:41]
      if (5'h10 == io_rd) begin // @[src/main/scala/rv32i/RegisterFile.scala 36:17]
        regs_16 <= io_writeData; // @[src/main/scala/rv32i/RegisterFile.scala 36:17]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegisterFile.scala 30:21]
      regs_17 <= 32'h0; // @[src/main/scala/rv32i/RegisterFile.scala 30:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[src/main/scala/rv32i/RegisterFile.scala 35:41]
      if (5'h11 == io_rd) begin // @[src/main/scala/rv32i/RegisterFile.scala 36:17]
        regs_17 <= io_writeData; // @[src/main/scala/rv32i/RegisterFile.scala 36:17]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegisterFile.scala 30:21]
      regs_18 <= 32'h0; // @[src/main/scala/rv32i/RegisterFile.scala 30:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[src/main/scala/rv32i/RegisterFile.scala 35:41]
      if (5'h12 == io_rd) begin // @[src/main/scala/rv32i/RegisterFile.scala 36:17]
        regs_18 <= io_writeData; // @[src/main/scala/rv32i/RegisterFile.scala 36:17]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegisterFile.scala 30:21]
      regs_19 <= 32'h0; // @[src/main/scala/rv32i/RegisterFile.scala 30:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[src/main/scala/rv32i/RegisterFile.scala 35:41]
      if (5'h13 == io_rd) begin // @[src/main/scala/rv32i/RegisterFile.scala 36:17]
        regs_19 <= io_writeData; // @[src/main/scala/rv32i/RegisterFile.scala 36:17]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegisterFile.scala 30:21]
      regs_20 <= 32'h0; // @[src/main/scala/rv32i/RegisterFile.scala 30:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[src/main/scala/rv32i/RegisterFile.scala 35:41]
      if (5'h14 == io_rd) begin // @[src/main/scala/rv32i/RegisterFile.scala 36:17]
        regs_20 <= io_writeData; // @[src/main/scala/rv32i/RegisterFile.scala 36:17]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegisterFile.scala 30:21]
      regs_21 <= 32'h0; // @[src/main/scala/rv32i/RegisterFile.scala 30:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[src/main/scala/rv32i/RegisterFile.scala 35:41]
      if (5'h15 == io_rd) begin // @[src/main/scala/rv32i/RegisterFile.scala 36:17]
        regs_21 <= io_writeData; // @[src/main/scala/rv32i/RegisterFile.scala 36:17]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegisterFile.scala 30:21]
      regs_22 <= 32'h0; // @[src/main/scala/rv32i/RegisterFile.scala 30:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[src/main/scala/rv32i/RegisterFile.scala 35:41]
      if (5'h16 == io_rd) begin // @[src/main/scala/rv32i/RegisterFile.scala 36:17]
        regs_22 <= io_writeData; // @[src/main/scala/rv32i/RegisterFile.scala 36:17]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegisterFile.scala 30:21]
      regs_23 <= 32'h0; // @[src/main/scala/rv32i/RegisterFile.scala 30:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[src/main/scala/rv32i/RegisterFile.scala 35:41]
      if (5'h17 == io_rd) begin // @[src/main/scala/rv32i/RegisterFile.scala 36:17]
        regs_23 <= io_writeData; // @[src/main/scala/rv32i/RegisterFile.scala 36:17]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegisterFile.scala 30:21]
      regs_24 <= 32'h0; // @[src/main/scala/rv32i/RegisterFile.scala 30:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[src/main/scala/rv32i/RegisterFile.scala 35:41]
      if (5'h18 == io_rd) begin // @[src/main/scala/rv32i/RegisterFile.scala 36:17]
        regs_24 <= io_writeData; // @[src/main/scala/rv32i/RegisterFile.scala 36:17]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegisterFile.scala 30:21]
      regs_25 <= 32'h0; // @[src/main/scala/rv32i/RegisterFile.scala 30:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[src/main/scala/rv32i/RegisterFile.scala 35:41]
      if (5'h19 == io_rd) begin // @[src/main/scala/rv32i/RegisterFile.scala 36:17]
        regs_25 <= io_writeData; // @[src/main/scala/rv32i/RegisterFile.scala 36:17]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegisterFile.scala 30:21]
      regs_26 <= 32'h0; // @[src/main/scala/rv32i/RegisterFile.scala 30:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[src/main/scala/rv32i/RegisterFile.scala 35:41]
      if (5'h1a == io_rd) begin // @[src/main/scala/rv32i/RegisterFile.scala 36:17]
        regs_26 <= io_writeData; // @[src/main/scala/rv32i/RegisterFile.scala 36:17]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegisterFile.scala 30:21]
      regs_27 <= 32'h0; // @[src/main/scala/rv32i/RegisterFile.scala 30:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[src/main/scala/rv32i/RegisterFile.scala 35:41]
      if (5'h1b == io_rd) begin // @[src/main/scala/rv32i/RegisterFile.scala 36:17]
        regs_27 <= io_writeData; // @[src/main/scala/rv32i/RegisterFile.scala 36:17]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegisterFile.scala 30:21]
      regs_28 <= 32'h0; // @[src/main/scala/rv32i/RegisterFile.scala 30:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[src/main/scala/rv32i/RegisterFile.scala 35:41]
      if (5'h1c == io_rd) begin // @[src/main/scala/rv32i/RegisterFile.scala 36:17]
        regs_28 <= io_writeData; // @[src/main/scala/rv32i/RegisterFile.scala 36:17]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegisterFile.scala 30:21]
      regs_29 <= 32'h0; // @[src/main/scala/rv32i/RegisterFile.scala 30:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[src/main/scala/rv32i/RegisterFile.scala 35:41]
      if (5'h1d == io_rd) begin // @[src/main/scala/rv32i/RegisterFile.scala 36:17]
        regs_29 <= io_writeData; // @[src/main/scala/rv32i/RegisterFile.scala 36:17]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegisterFile.scala 30:21]
      regs_30 <= 32'h0; // @[src/main/scala/rv32i/RegisterFile.scala 30:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[src/main/scala/rv32i/RegisterFile.scala 35:41]
      if (5'h1e == io_rd) begin // @[src/main/scala/rv32i/RegisterFile.scala 36:17]
        regs_30 <= io_writeData; // @[src/main/scala/rv32i/RegisterFile.scala 36:17]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegisterFile.scala 30:21]
      regs_31 <= 32'h0; // @[src/main/scala/rv32i/RegisterFile.scala 30:21]
    end else if (io_writeEnable & io_rd != 5'h0) begin // @[src/main/scala/rv32i/RegisterFile.scala 35:41]
      if (5'h1f == io_rd) begin // @[src/main/scala/rv32i/RegisterFile.scala 36:17]
        regs_31 <= io_writeData; // @[src/main/scala/rv32i/RegisterFile.scala 36:17]
      end
    end
  end
// Register and memory initialization
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif
`ifndef RANDOM
`define RANDOM $random
`endif
`ifdef RANDOMIZE_MEM_INIT
  integer initvar;
`endif
`ifndef SYNTHESIS
`ifdef FIRRTL_BEFORE_INITIAL
`FIRRTL_BEFORE_INITIAL
`endif
initial begin
  `ifdef RANDOMIZE
    `ifdef INIT_RANDOM
      `INIT_RANDOM
    `endif
    `ifndef VERILATOR
      `ifdef RANDOMIZE_DELAY
        #`RANDOMIZE_DELAY begin end
      `else
        #0.002 begin end
      `endif
    `endif
`ifdef RANDOMIZE_REG_INIT
  _RAND_0 = {1{`RANDOM}};
  regs_0 = _RAND_0[31:0];
  _RAND_1 = {1{`RANDOM}};
  regs_1 = _RAND_1[31:0];
  _RAND_2 = {1{`RANDOM}};
  regs_2 = _RAND_2[31:0];
  _RAND_3 = {1{`RANDOM}};
  regs_3 = _RAND_3[31:0];
  _RAND_4 = {1{`RANDOM}};
  regs_4 = _RAND_4[31:0];
  _RAND_5 = {1{`RANDOM}};
  regs_5 = _RAND_5[31:0];
  _RAND_6 = {1{`RANDOM}};
  regs_6 = _RAND_6[31:0];
  _RAND_7 = {1{`RANDOM}};
  regs_7 = _RAND_7[31:0];
  _RAND_8 = {1{`RANDOM}};
  regs_8 = _RAND_8[31:0];
  _RAND_9 = {1{`RANDOM}};
  regs_9 = _RAND_9[31:0];
  _RAND_10 = {1{`RANDOM}};
  regs_10 = _RAND_10[31:0];
  _RAND_11 = {1{`RANDOM}};
  regs_11 = _RAND_11[31:0];
  _RAND_12 = {1{`RANDOM}};
  regs_12 = _RAND_12[31:0];
  _RAND_13 = {1{`RANDOM}};
  regs_13 = _RAND_13[31:0];
  _RAND_14 = {1{`RANDOM}};
  regs_14 = _RAND_14[31:0];
  _RAND_15 = {1{`RANDOM}};
  regs_15 = _RAND_15[31:0];
  _RAND_16 = {1{`RANDOM}};
  regs_16 = _RAND_16[31:0];
  _RAND_17 = {1{`RANDOM}};
  regs_17 = _RAND_17[31:0];
  _RAND_18 = {1{`RANDOM}};
  regs_18 = _RAND_18[31:0];
  _RAND_19 = {1{`RANDOM}};
  regs_19 = _RAND_19[31:0];
  _RAND_20 = {1{`RANDOM}};
  regs_20 = _RAND_20[31:0];
  _RAND_21 = {1{`RANDOM}};
  regs_21 = _RAND_21[31:0];
  _RAND_22 = {1{`RANDOM}};
  regs_22 = _RAND_22[31:0];
  _RAND_23 = {1{`RANDOM}};
  regs_23 = _RAND_23[31:0];
  _RAND_24 = {1{`RANDOM}};
  regs_24 = _RAND_24[31:0];
  _RAND_25 = {1{`RANDOM}};
  regs_25 = _RAND_25[31:0];
  _RAND_26 = {1{`RANDOM}};
  regs_26 = _RAND_26[31:0];
  _RAND_27 = {1{`RANDOM}};
  regs_27 = _RAND_27[31:0];
  _RAND_28 = {1{`RANDOM}};
  regs_28 = _RAND_28[31:0];
  _RAND_29 = {1{`RANDOM}};
  regs_29 = _RAND_29[31:0];
  _RAND_30 = {1{`RANDOM}};
  regs_30 = _RAND_30[31:0];
  _RAND_31 = {1{`RANDOM}};
  regs_31 = _RAND_31[31:0];
`endif // RANDOMIZE_REG_INIT
  `endif // RANDOMIZE
end // initial
`ifdef FIRRTL_AFTER_INITIAL
`FIRRTL_AFTER_INITIAL
`endif
`endif // SYNTHESIS
endmodule
module ALU(
  input  [31:0] io_a, // @[src/main/scala/rv32i/ALU.scala 24:14]
  input  [31:0] io_b, // @[src/main/scala/rv32i/ALU.scala 24:14]
  input  [3:0]  io_op, // @[src/main/scala/rv32i/ALU.scala 24:14]
  output [31:0] io_y // @[src/main/scala/rv32i/ALU.scala 24:14]
);
  wire [4:0] shamt = io_b[4:0]; // @[src/main/scala/rv32i/ALU.scala 31:19]
  wire [31:0] _io_y_T_1 = io_a + io_b; // @[src/main/scala/rv32i/ALU.scala 34:25]
  wire [31:0] _io_y_T_3 = io_a - io_b; // @[src/main/scala/rv32i/ALU.scala 35:25]
  wire [62:0] _GEN_0 = {{31'd0}, io_a}; // @[src/main/scala/rv32i/ALU.scala 36:25]
  wire [62:0] _io_y_T_4 = _GEN_0 << shamt; // @[src/main/scala/rv32i/ALU.scala 36:25]
  wire  _io_y_T_8 = $signed(io_a) < $signed(io_b); // @[src/main/scala/rv32i/ALU.scala 37:32]
  wire  _io_y_T_9 = io_a < io_b; // @[src/main/scala/rv32i/ALU.scala 38:25]
  wire [31:0] _io_y_T_10 = io_a ^ io_b; // @[src/main/scala/rv32i/ALU.scala 39:25]
  wire [31:0] _io_y_T_11 = io_a >> shamt; // @[src/main/scala/rv32i/ALU.scala 40:25]
  wire [31:0] _io_y_T_14 = $signed(io_a) >>> shamt; // @[src/main/scala/rv32i/ALU.scala 41:42]
  wire [31:0] _io_y_T_15 = io_a | io_b; // @[src/main/scala/rv32i/ALU.scala 42:25]
  wire [31:0] _io_y_T_16 = io_a & io_b; // @[src/main/scala/rv32i/ALU.scala 43:25]
  wire [31:0] _io_y_T_18 = 4'h0 == io_op ? _io_y_T_1 : 32'h0; // @[src/main/scala/rv32i/ALU.scala 33:42]
  wire [31:0] _io_y_T_20 = 4'h1 == io_op ? _io_y_T_3 : _io_y_T_18; // @[src/main/scala/rv32i/ALU.scala 33:42]
  wire [31:0] _io_y_T_22 = 4'h2 == io_op ? _io_y_T_4[31:0] : _io_y_T_20; // @[src/main/scala/rv32i/ALU.scala 33:42]
  wire [31:0] _io_y_T_24 = 4'h3 == io_op ? {{31'd0}, _io_y_T_8} : _io_y_T_22; // @[src/main/scala/rv32i/ALU.scala 33:42]
  wire [31:0] _io_y_T_26 = 4'h4 == io_op ? {{31'd0}, _io_y_T_9} : _io_y_T_24; // @[src/main/scala/rv32i/ALU.scala 33:42]
  wire [31:0] _io_y_T_28 = 4'h5 == io_op ? _io_y_T_10 : _io_y_T_26; // @[src/main/scala/rv32i/ALU.scala 33:42]
  wire [31:0] _io_y_T_30 = 4'h6 == io_op ? _io_y_T_11 : _io_y_T_28; // @[src/main/scala/rv32i/ALU.scala 33:42]
  wire [31:0] _io_y_T_32 = 4'h7 == io_op ? _io_y_T_14 : _io_y_T_30; // @[src/main/scala/rv32i/ALU.scala 33:42]
  wire [31:0] _io_y_T_34 = 4'h8 == io_op ? _io_y_T_15 : _io_y_T_32; // @[src/main/scala/rv32i/ALU.scala 33:42]
  assign io_y = 4'h9 == io_op ? _io_y_T_16 : _io_y_T_34; // @[src/main/scala/rv32i/ALU.scala 33:42]
endmodule
module RV32IRCore(
  input         clock,
  input         reset,
  output [31:0] io_imemAddr, // @[src/main/scala/rv32i/RV32IRCore.scala 23:14]
  input  [31:0] io_imemInst, // @[src/main/scala/rv32i/RV32IRCore.scala 23:14]
  output [31:0] io_debugPC, // @[src/main/scala/rv32i/RV32IRCore.scala 23:14]
  output [31:0] io_debugX1, // @[src/main/scala/rv32i/RV32IRCore.scala 23:14]
  output [31:0] io_debugX2, // @[src/main/scala/rv32i/RV32IRCore.scala 23:14]
  output [31:0] io_debugX3, // @[src/main/scala/rv32i/RV32IRCore.scala 23:14]
  output [31:0] io_debugX4, // @[src/main/scala/rv32i/RV32IRCore.scala 23:14]
  output [31:0] io_trace_pc, // @[src/main/scala/rv32i/RV32IRCore.scala 23:14]
  output [31:0] io_trace_inst, // @[src/main/scala/rv32i/RV32IRCore.scala 23:14]
  output        io_trace_valid, // @[src/main/scala/rv32i/RV32IRCore.scala 23:14]
  output [4:0]  io_trace_rdAddr, // @[src/main/scala/rv32i/RV32IRCore.scala 23:14]
  output [31:0] io_trace_rdData // @[src/main/scala/rv32i/RV32IRCore.scala 23:14]
);
`ifdef RANDOMIZE_REG_INIT
  reg [31:0] _RAND_0;
`endif // RANDOMIZE_REG_INIT
  wire [31:0] decoder_io_instr; // @[src/main/scala/rv32i/RV32IRCore.scala 43:23]
  wire [4:0] decoder_io_rs1; // @[src/main/scala/rv32i/RV32IRCore.scala 43:23]
  wire [4:0] decoder_io_rs2; // @[src/main/scala/rv32i/RV32IRCore.scala 43:23]
  wire [4:0] decoder_io_rd; // @[src/main/scala/rv32i/RV32IRCore.scala 43:23]
  wire [3:0] decoder_io_aluOp; // @[src/main/scala/rv32i/RV32IRCore.scala 43:23]
  wire  decoder_io_aluSrc; // @[src/main/scala/rv32i/RV32IRCore.scala 43:23]
  wire  decoder_io_regWrite; // @[src/main/scala/rv32i/RV32IRCore.scala 43:23]
  wire  decoder_io_valid; // @[src/main/scala/rv32i/RV32IRCore.scala 43:23]
  wire [31:0] immGen_io_instr; // @[src/main/scala/rv32i/RV32IRCore.scala 46:22]
  wire [31:0] immGen_io_imm; // @[src/main/scala/rv32i/RV32IRCore.scala 46:22]
  wire  regFile_clock; // @[src/main/scala/rv32i/RV32IRCore.scala 50:23]
  wire  regFile_reset; // @[src/main/scala/rv32i/RV32IRCore.scala 50:23]
  wire [4:0] regFile_io_rs1; // @[src/main/scala/rv32i/RV32IRCore.scala 50:23]
  wire [4:0] regFile_io_rs2; // @[src/main/scala/rv32i/RV32IRCore.scala 50:23]
  wire [4:0] regFile_io_rd; // @[src/main/scala/rv32i/RV32IRCore.scala 50:23]
  wire [31:0] regFile_io_writeData; // @[src/main/scala/rv32i/RV32IRCore.scala 50:23]
  wire  regFile_io_writeEnable; // @[src/main/scala/rv32i/RV32IRCore.scala 50:23]
  wire [31:0] regFile_io_readData1; // @[src/main/scala/rv32i/RV32IRCore.scala 50:23]
  wire [31:0] regFile_io_readData2; // @[src/main/scala/rv32i/RV32IRCore.scala 50:23]
  wire [31:0] regFile_io_debugRead_1; // @[src/main/scala/rv32i/RV32IRCore.scala 50:23]
  wire [31:0] regFile_io_debugRead_2; // @[src/main/scala/rv32i/RV32IRCore.scala 50:23]
  wire [31:0] regFile_io_debugRead_3; // @[src/main/scala/rv32i/RV32IRCore.scala 50:23]
  wire [31:0] regFile_io_debugRead_4; // @[src/main/scala/rv32i/RV32IRCore.scala 50:23]
  wire [31:0] alu_io_a; // @[src/main/scala/rv32i/RV32IRCore.scala 55:19]
  wire [31:0] alu_io_b; // @[src/main/scala/rv32i/RV32IRCore.scala 55:19]
  wire [3:0] alu_io_op; // @[src/main/scala/rv32i/RV32IRCore.scala 55:19]
  wire [31:0] alu_io_y; // @[src/main/scala/rv32i/RV32IRCore.scala 55:19]
  reg [31:0] pc; // @[src/main/scala/rv32i/RV32IRCore.scala 38:19]
  wire [31:0] _pc_T_1 = pc + 32'h4; // @[src/main/scala/rv32i/RV32IRCore.scala 66:12]
  wire  writes = decoder_io_regWrite & decoder_io_rd != 5'h0; // @[src/main/scala/rv32i/RV32IRCore.scala 74:36]
  Decoder decoder ( // @[src/main/scala/rv32i/RV32IRCore.scala 43:23]
    .io_instr(decoder_io_instr),
    .io_rs1(decoder_io_rs1),
    .io_rs2(decoder_io_rs2),
    .io_rd(decoder_io_rd),
    .io_aluOp(decoder_io_aluOp),
    .io_aluSrc(decoder_io_aluSrc),
    .io_regWrite(decoder_io_regWrite),
    .io_valid(decoder_io_valid)
  );
  ImmediateGenerator immGen ( // @[src/main/scala/rv32i/RV32IRCore.scala 46:22]
    .io_instr(immGen_io_instr),
    .io_imm(immGen_io_imm)
  );
  RegisterFile regFile ( // @[src/main/scala/rv32i/RV32IRCore.scala 50:23]
    .clock(regFile_clock),
    .reset(regFile_reset),
    .io_rs1(regFile_io_rs1),
    .io_rs2(regFile_io_rs2),
    .io_rd(regFile_io_rd),
    .io_writeData(regFile_io_writeData),
    .io_writeEnable(regFile_io_writeEnable),
    .io_readData1(regFile_io_readData1),
    .io_readData2(regFile_io_readData2),
    .io_debugRead_1(regFile_io_debugRead_1),
    .io_debugRead_2(regFile_io_debugRead_2),
    .io_debugRead_3(regFile_io_debugRead_3),
    .io_debugRead_4(regFile_io_debugRead_4)
  );
  ALU alu ( // @[src/main/scala/rv32i/RV32IRCore.scala 55:19]
    .io_a(alu_io_a),
    .io_b(alu_io_b),
    .io_op(alu_io_op),
    .io_y(alu_io_y)
  );
  assign io_imemAddr = pc; // @[src/main/scala/rv32i/RV32IRCore.scala 39:15]
  assign io_debugPC = pc; // @[src/main/scala/rv32i/RV32IRCore.scala 40:15]
  assign io_debugX1 = regFile_io_debugRead_1; // @[src/main/scala/rv32i/RV32IRCore.scala 69:14]
  assign io_debugX2 = regFile_io_debugRead_2; // @[src/main/scala/rv32i/RV32IRCore.scala 70:14]
  assign io_debugX3 = regFile_io_debugRead_3; // @[src/main/scala/rv32i/RV32IRCore.scala 71:14]
  assign io_debugX4 = regFile_io_debugRead_4; // @[src/main/scala/rv32i/RV32IRCore.scala 72:14]
  assign io_trace_pc = pc; // @[src/main/scala/rv32i/RV32IRCore.scala 75:19]
  assign io_trace_inst = io_imemInst; // @[src/main/scala/rv32i/RV32IRCore.scala 76:19]
  assign io_trace_valid = decoder_io_valid; // @[src/main/scala/rv32i/RV32IRCore.scala 77:19]
  assign io_trace_rdAddr = writes ? decoder_io_rd : 5'h0; // @[src/main/scala/rv32i/RV32IRCore.scala 78:25]
  assign io_trace_rdData = writes ? alu_io_y : 32'h0; // @[src/main/scala/rv32i/RV32IRCore.scala 79:25]
  assign decoder_io_instr = io_imemInst; // @[src/main/scala/rv32i/RV32IRCore.scala 44:20]
  assign immGen_io_instr = io_imemInst; // @[src/main/scala/rv32i/RV32IRCore.scala 47:19]
  assign regFile_clock = clock;
  assign regFile_reset = reset;
  assign regFile_io_rs1 = decoder_io_rs1; // @[src/main/scala/rv32i/RV32IRCore.scala 51:18]
  assign regFile_io_rs2 = decoder_io_rs2; // @[src/main/scala/rv32i/RV32IRCore.scala 52:18]
  assign regFile_io_rd = decoder_io_rd; // @[src/main/scala/rv32i/RV32IRCore.scala 61:26]
  assign regFile_io_writeData = alu_io_y; // @[src/main/scala/rv32i/RV32IRCore.scala 62:26]
  assign regFile_io_writeEnable = decoder_io_regWrite; // @[src/main/scala/rv32i/RV32IRCore.scala 63:26]
  assign alu_io_a = regFile_io_readData1; // @[src/main/scala/rv32i/RV32IRCore.scala 56:13]
  assign alu_io_b = decoder_io_aluSrc ? immGen_io_imm : regFile_io_readData2; // @[src/main/scala/rv32i/RV32IRCore.scala 57:19]
  assign alu_io_op = decoder_io_aluOp; // @[src/main/scala/rv32i/RV32IRCore.scala 58:13]
  always @(posedge clock) begin
    if (reset) begin // @[src/main/scala/rv32i/RV32IRCore.scala 38:19]
      pc <= 32'h0; // @[src/main/scala/rv32i/RV32IRCore.scala 38:19]
    end else begin
      pc <= _pc_T_1; // @[src/main/scala/rv32i/RV32IRCore.scala 66:6]
    end
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (~reset & ~(~(decoder_io_regWrite & ~decoder_io_valid))) begin
          $fwrite(32'h80000002,
            "Assertion failed: register write by an unrecognised instruction\n    at RV32IRCore.scala:81 assert(!(decoder.io.regWrite && !decoder.io.valid), \"register write by an unrecognised instruction\")\n"
            ); // @[src/main/scala/rv32i/RV32IRCore.scala 81:9]
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif // SYNTHESIS
  end
// Register and memory initialization
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif
`ifndef RANDOM
`define RANDOM $random
`endif
`ifdef RANDOMIZE_MEM_INIT
  integer initvar;
`endif
`ifndef SYNTHESIS
`ifdef FIRRTL_BEFORE_INITIAL
`FIRRTL_BEFORE_INITIAL
`endif
initial begin
  `ifdef RANDOMIZE
    `ifdef INIT_RANDOM
      `INIT_RANDOM
    `endif
    `ifndef VERILATOR
      `ifdef RANDOMIZE_DELAY
        #`RANDOMIZE_DELAY begin end
      `else
        #0.002 begin end
      `endif
    `endif
`ifdef RANDOMIZE_REG_INIT
  _RAND_0 = {1{`RANDOM}};
  pc = _RAND_0[31:0];
`endif // RANDOMIZE_REG_INIT
  `endif // RANDOMIZE
end // initial
`ifdef FIRRTL_AFTER_INITIAL
`FIRRTL_AFTER_INITIAL
`endif
`endif // SYNTHESIS
  always @(posedge clock) begin
    //
    if (~reset) begin
      assert(~(decoder_io_regWrite & ~decoder_io_valid)); // @[src/main/scala/rv32i/RV32IRCore.scala 81:9]
    end
  end
endmodule
