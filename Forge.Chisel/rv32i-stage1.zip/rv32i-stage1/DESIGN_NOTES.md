# Design notes: Stage 1, single-cycle RV32I ALU core (lab1)

## Architecture

| Item | Choice |
|---|---|
| ISA subset | The 19 RV32I integer ALU instructions: R-type ADD SUB SLL SLT SLTU XOR SRL SRA OR AND, I-type ADDI SLTI SLTIU XORI ORI ANDI SLLI SRLI SRAI |
| Microarchitecture | Single cycle: fetch, decode, register read, ALU and write-back in one clock |
| Control flow | None: the pc starts at 0 (`resetPc`) and advances by 4 every cycle |
| Memory | Instruction memory only (`InstructionMemory`, hex file, combinational read); no data memory |
| Registers | 32 × 32 bits, x0 hardwired to zero, optional reset values (`initialRegs`, as in lab1) |
| Unsupported instructions | Executed as no-ops: no register write, `trace.valid` = 0, pc + 4 (no exceptions in this stage) |

## Datapath (one clock)

```
pc ──► imem ──► inst ──► Decoder ── aluOp, aluSrc, rd, regWrite
                  │         └─ rs1, rs2 ──► RegisterFile ──► readData1 ───────────► ALU.a
                  └──► ImmediateGenerator ──► imm ──┐        readData2 ──┐
                                                    └── aluSrc ? imm : readData2 ──► ALU.b
ALU.y ──► RegisterFile (rd, regWrite)          pc := pc + 4
```

## Changes from lab1

| lab1 | Stage 1 project | Why |
|---|---|---|
| `alu.io.b := regFile.io.readData2` (the `ImmediateGenerator` and `aluSrc` were not connected) | `alu.io.b := Mux(aluSrc, imm, readData2)` | lab1's decoder and tests already accept the 9 I-type ALU instructions, but the core executed them with a register instead of the immediate (ADDI x1, x0, 10 read register x10). R-type behaviour is unchanged |
| `MuxLookup(key, default, seq)` | `MuxLookup(key, default)(seq)` | The 3-argument form is deprecated in Chisel 3.6 |
| ALU `SLL` result wider than xlen | Sliced to xlen bits | Explicit width |
| Register file `initialValues(0)` used for x0 | x0 always resets to 0 | x0 is hardwired to zero |
| `InstructionMemory`: whole-line `#` comments | Also trailing `# ...` comments; addresses past the memory read 0 | Annotated hex files; no out-of-range index |
| Debug ports `debugPC`, `debugX1..X4` | Kept, plus a `trace` port (pc, inst, valid, rd, rd value) | Cycle-by-cycle comparison with the reference model and readable waveforms |
| Chisel 3.5.6, Scala 2.12.17, chiseltest 0.5.6, `sbt.version=2.0.7` | Chisel 3.6.1, Scala 2.13.12, chiseltest 0.6.2, sbt 1.10.2 | sbt 2 is not a Chisel 3 setup; same toolchain as the Stage 4/5 projects |
| `GenerateRV32IRCore`, `GenerateRV32ITestWrapper` (deprecated `chisel3.stage.ChiselStage`) | Kept, now via `Emit` (firtool with `-disable-all-randomization -strip-debug-info`, legacy fallback) | Same emitter as the other stages |

The ISA-visible behaviour of the 10 R-type instructions and of lab1's `memory.hex` program is identical to lab1.

## Choices where the specification leaves an option

| Topic | Choice | Why |
|---|---|---|
| Unsupported encodings | No-op, `valid` = 0 | There are no exceptions or CSRs in this stage |
| `xlen` | `RV32IRCore` requires 32; `ALU` and `RegisterFile` stay generic | RV32I semantics (5-bit shift amounts, 12-bit immediates) |
| Constants | Built with ALU instructions in tests (`addi`, `slli`, `ori`: `Asm.li`) or preset with `initialRegs` | There is no LUI in this stage |

## Verification

- Unit tests: ALU (lab1 checks, all operations on all pairs of 22 edge values, 3,000 random, unused codes give 0),
  Decoder (lab1's 20 cases, 27 rejected encodings, all 128 major opcodes), ImmediateGenerator (all 4,096 immediates),
  RegisterFile (lab1 cases, initial values incl. x0, all registers, read during write), InstructionMemory
  (comments, separators, past the end).
- Program tests (`RV32IRCoreSpec`): lab1's `memory.hex` through `RV32ITestWrapper`; every R-type and I-type
  instruction on edge values; `li` constants; dependency chains and x0; unsupported words as no-ops; preset registers;
  3,000 random instructions and random words. Each runs in lockstep with `RefModel`: pc, instruction, valid, rd,
  rd value and x1..x4 compared every cycle; final registers also checked against independently computed values.
- Timing (`TimingSpec`): one instruction per cycle for every instruction, pc + 4 per cycle.
- Planted bugs: lab1's unconnected immediate, SRA decoded as SRL, a zero-extended immediate: all caught
  (lab1's own `memory.hex` test alone does not catch the first one, since that program has only R-type instructions).
