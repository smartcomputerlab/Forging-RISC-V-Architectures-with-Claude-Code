package rv32i

import chisel3._
import chiseltest._
import org.scalatest.flatspec.AnyFlatSpec
import org.scalatest.matchers.should.Matchers
import scala.util.Random
import TestUtil._

/** Programs on the full core. Every cycle is checked against RefModel (CoreSim: pc, instruction, valid, rd,
  * rd value, x1..x4 on the debug ports), and final register values against independently computed constants.
  */
class RV32IRCoreSpec extends AnyFlatSpec with ChiselScalatestTester with Matchers {
  private val labRegs = Lab1.regs   // x1 = 10, x2 = 3

  /** Expected values may be given as Int or Long. */
  private def runProg(a: Asm, expect: Map[Int, AnyVal], regs: Seq[BigInt] = Seq.empty): CoreSim.Result = {
    var res: CoreSim.Result = null
    test(new RV32IRCore(CoreParams(), regs)).withAnnotations(TestUtil.waves) { c => res = CoreSim.run(c, a.words, regs) }
    for ((r, v) <- expect) {
      val exp = v match { case i: Int => i.toLong; case l: Long => l; case o => sys.error(s"bad value $o") }
      withClue(s"x$r: ") { res.model.x(r) shouldBe (exp & M) }
    }
    res
  }

  "RV32ITestWrapper" should "run the lab1 memory.hex program (10 R-type instructions, x1 = 10, x2 = 3)" in {
    test(new RV32ITestWrapper(CoreParams(), "memory.hex", labRegs)).withAnnotations(TestUtil.waves) { dut =>
      val model = new RefModel(labRegs)
      val words = InstructionMemory.readHex("memory.hex").map(_.toLong)
      dut.io.debugPC.expect(0.U)
      for ((w, k) <- words.zipWithIndex) {
        dut.io.debugPC.expect((4 * k).U)
        val r = model.step(w)
        dut.io.trace.valid.expect(true.B); dut.io.trace.rdAddr.expect(r.rdAddr.U); dut.io.trace.rdData.expect(r.rdData.U(32.W))
        dut.clock.step()
      }
      dut.io.debugPC.expect(40.U)
      dut.io.debugX3.expect(13.U)   // add x3, x1, x2
      dut.io.debugX4.expect(7.U)    // sub x4, x1, x2
      dut.io.debugX1.expect(10.U); dut.io.debugX2.expect(3.U)
      // past the end of the program the memory reads 0: executed as a no-op
      dut.io.trace.valid.expect(false.B); dut.io.trace.rdAddr.expect(0.U)
      dut.clock.step(); dut.io.debugX3.expect(13.U); dut.io.debugPC.expect(44.U)
    }
  }

  "RV32IRCore" should "execute all 10 R-type instructions on edge values" in {
    val a = new Asm
    val x1 = 0x80000001L; val x2 = 0xfffffffbL; val x3 = 0x12345678L // MIN+1, -5, positive
    a.li(1, x1); a.li(2, x2); a.li(3, x3)
    a.add(10, 1, 2); a.sub(11, 1, 2); a.sll(12, 3, 2); a.slt(13, 1, 2); a.sltu(14, 1, 2)
    a.xor(15, 1, 3); a.srl(16, 1, 3); a.sra(17, 1, 3); a.or(18, 2, 3); a.and(19, 2, 3)
    a.add(20, 1, 1)                                   // overflow wraps
    runProg(a, Map(1 -> x1, 2 -> x2, 3 -> x3,
      10 -> (x1 + x2), 11 -> (x1 - x2), 12 -> (x3 << 27), 13 -> 1, 14 -> 1,
      15 -> (x1 ^ x3), 16 -> (x1 >>> 24), 17 -> (s32(x1) >> 24), 18 -> (x2 | x3), 19 -> (x2 & x3), 20 -> 2))
  }

  it should "execute all 9 I-type ALU instructions, including negative immediates and shift amounts 0 and 31" in {
    val a = new Asm
    val v = 0x87654321L
    a.li(1, v)
    a.addi(10, 1, -1); a.slti(11, 1, -2048); a.sltiu(12, 1, -1); a.xori(13, 1, -1); a.ori(14, 1, 0x7ff)
    a.andi(15, 1, -16); a.slli(16, 1, 31); a.srli(17, 1, 31); a.srai(18, 1, 31); a.srai(19, 1, 0); a.addi(20, 0, 2047)
    runProg(a, Map(10 -> (v - 1), 11 -> 1, 12 -> 1, 13 -> ~v, 14 -> (v | 0x7ff), 15 -> (v & ~15L),
      16 -> (v << 31), 17 -> 1, 18 -> 0xffffffffL, 19 -> v, 20 -> 2047))
  }

  it should "load any 32-bit constant with ALU instructions only (li)" in {
    val values = Seq(0L, 1L, -1L, 2047L, -2048L, 2048L, 0x7fffffffL, 0x80000000L, 0xdeadbeefL, 0x12345678L, 0xfffff800L)
    val a = new Asm
    for ((v, k) <- values.zipWithIndex) a.li(k + 1, v)
    runProg(a, values.zipWithIndex.map { case (v, k) => (k + 1) -> v }.toMap)
  }

  it should "use every result in the next instruction (single cycle: no hazards) and never write x0" in {
    val a = new Asm
    a.addi(1, 0, 3); a.add(2, 1, 1); a.add(3, 2, 1); a.sll(4, 3, 1); a.sub(5, 4, 3); a.sra(6, 5, 1)
    a.addi(0, 1, 100); a.add(0, 1, 1); a.add(7, 0, 0)
    runProg(a, Map(1 -> 3, 2 -> 6, 3 -> 9, 4 -> 72, 5 -> 63, 6 -> 7, 7 -> 0, 0 -> 0))
  }

  it should "execute unsupported instructions as no-ops (no register change, pc + 4)" in {
    val a = new Asm
    a.addi(1, 0, 5)
    for (w <- Seq(0L, 0xffffffffL, 0x000120b7L, 0x0000a103L, 0x0020a023L, 0x00208463L, 0x0080006fL, 0x00000073L,
      Enc.r(1, 1, 1, 0, 1), Enc.r(1, 1, 1, 4, 1), Enc.i(0x400 | 3, 1, 1, 1))) a.word(w)
    a.addi(2, 1, 1)
    val res = runProg(a, Map(1 -> 5, 2 -> 6))
    res.invalid shouldBe 11
    res.executed shouldBe 2
  }

  it should "start from preset registers (initialRegs) like lab1" in {
    val a = new Asm
    a.add(3, 1, 2); a.sub(4, 1, 2)
    runProg(a, Map(1 -> 10, 2 -> 3, 3 -> 13, 4 -> 7), regs = labRegs)
  }

  it should "match the reference model on 3000 random ALU instructions" in {
    val r = new Random(11)
    val a = new Asm
    for (k <- 1 to 15) a.li(k, rnd32(r))
    def reg = 1 + r.nextInt(15)
    def src = r.nextInt(16)
    def imm = r.nextInt(4096) - 2048
    for (_ <- 0 until 3000) r.nextInt(20) match {
      case 0 => a.add(reg, src, src);  case 1 => a.sub(reg, src, src);  case 2 => a.sll(reg, src, src)
      case 3 => a.slt(reg, src, src);  case 4 => a.sltu(reg, src, src); case 5 => a.xor(reg, src, src)
      case 6 => a.srl(reg, src, src);  case 7 => a.sra(reg, src, src);  case 8 => a.or(reg, src, src)
      case 9 => a.and(reg, src, src);  case 10 => a.addi(reg, src, imm); case 11 => a.slti(reg, src, imm)
      case 12 => a.sltiu(reg, src, imm); case 13 => a.xori(reg, src, imm); case 14 => a.ori(reg, src, imm)
      case 15 => a.andi(reg, src, imm); case 16 => a.slli(reg, src, r.nextInt(32))
      case 17 => a.srli(reg, src, r.nextInt(32)); case 18 => a.srai(reg, src, r.nextInt(32))
      case _ => a.word(r.nextLong() & M)   // random word: valid or not, both must agree
    }
    val res = runProg(a, Map.empty)
    res.executed + res.invalid shouldBe a.words.length
    res.invalid should be > 0
  }
}
