package rv32i

import chisel3._
import chiseltest._
import org.scalatest.flatspec.AnyFlatSpec
import java.nio.file.{Files, Paths}

class InstructionMemorySpec extends AnyFlatSpec with ChiselScalatestTester {
  "InstructionMemory" should "load a hex file with comments and separators, and read 0 past its end" in {
    val dir = Paths.get("test_run_dir", "imem_file"); Files.createDirectories(dir)
    val file = dir.resolve("prog.hex")
    Files.write(file, "# test program\n002081b3\n\n4020_8233   # sub\n00a00093\n".getBytes("UTF-8"))
    assert(InstructionMemory.readHex(file.toString) == Seq(BigInt("002081b3", 16), BigInt("40208233", 16), BigInt("00a00093", 16)))
    test(new InstructionMemory(file.toString, depth = 16)).withAnnotations(TestUtil.waves) { dut =>
      for ((addr, w) <- Seq(0 -> 0x002081b3L, 4 -> 0x40208233L, 8 -> 0x00a00093L, 12 -> 0L, 60 -> 0L, 64 -> 0L, 4096 -> 0L)) {
        dut.io.addr.poke(addr.U); dut.io.inst.expect(w.U(32.W), s"address $addr")
      }
      dut.io.addr.poke(5.U); dut.io.inst.expect(0x40208233L.U(32.W)) // word address = addr >> 2
    }
  }

  it should "read the project's memory.hex (lab1 program)" in {
    val words = InstructionMemory.readHex("memory.hex")
    assert(words.length == 10)
    assert(words.head == BigInt("002081b3", 16) && words.last == BigInt("00d8f733", 16))
  }
}
