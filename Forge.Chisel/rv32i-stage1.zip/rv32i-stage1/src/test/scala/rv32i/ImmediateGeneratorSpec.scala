package rv32i

import chisel3._
import chiseltest._
import org.scalatest.flatspec.AnyFlatSpec
import scala.util.Random

class ImmediateGeneratorSpec extends AnyFlatSpec with ChiselScalatestTester {
  "ImmediateGenerator" should "sign-extend every 12-bit I-type immediate (lab1 values and all 4096 values)" in {
    test(new ImmediateGenerator(CoreParams())).withAnnotations(TestUtil.waves) { dut =>
      for ((imm, exp) <- Seq(10 -> 10L, 20 -> 20L, -1 -> 0xffffffffL, -10 -> 0xfffffff6L, 127 -> 127L,
        -128 -> 0xffffff80L, 2047 -> 2047L, -2048 -> 0xfffff800L)) {
        dut.io.instr.poke(RV32IEncoding.addi(1, 0, imm).U)
        dut.io.imm.expect(exp.U(32.W))
      }
      val r = new Random(5)
      for (imm <- -2048 to 2047) {
        val rd = r.nextInt(32); val rs1 = r.nextInt(32); val f3 = Seq(0, 2, 3, 4, 6, 7)(r.nextInt(6))
        dut.io.instr.poke(Enc.i(imm, rs1, f3, rd).U(32.W))
        dut.io.imm.expect((imm.toLong & 0xFFFFFFFFL).U(32.W))
      }
    }
  }
}
