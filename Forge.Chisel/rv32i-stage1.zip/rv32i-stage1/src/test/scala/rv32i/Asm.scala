package rv32i

import scala.collection.mutable

/** Instruction encoders for the RV32I ALU instructions (all return the 32-bit word as Long). */
object Enc {
  private def m(v: Long) = v & 0xFFFFFFFFL
  def r(f7: Int, rs2: Int, rs1: Int, f3: Int, rd: Int): Long =
    m((f7.toLong << 25) | (rs2 << 20) | (rs1 << 15) | (f3 << 12) | (rd << 7) | 0x33)
  def i(imm: Long, rs1: Int, f3: Int, rd: Int): Long =
    m(((imm & 0xfff) << 20) | (rs1 << 15) | (f3 << 12) | (rd << 7) | 0x13)
}

/** Assembler for RV32IRCore programs (straight-line code: the core has no branches). */
class Asm(val base: Long = 0L) {
  import Enc._
  private val ws = mutable.ArrayBuffer.empty[Long]
  def words: Seq[Long] = ws.toSeq
  def word(w: Long): Unit = ws += (w & 0xFFFFFFFFL)

  def add(rd: Int, a: Int, b: Int): Unit  = word(r(0, b, a, 0, rd))
  def sub(rd: Int, a: Int, b: Int): Unit  = word(r(0x20, b, a, 0, rd))
  def sll(rd: Int, a: Int, b: Int): Unit  = word(r(0, b, a, 1, rd))
  def slt(rd: Int, a: Int, b: Int): Unit  = word(r(0, b, a, 2, rd))
  def sltu(rd: Int, a: Int, b: Int): Unit = word(r(0, b, a, 3, rd))
  def xor(rd: Int, a: Int, b: Int): Unit  = word(r(0, b, a, 4, rd))
  def srl(rd: Int, a: Int, b: Int): Unit  = word(r(0, b, a, 5, rd))
  def sra(rd: Int, a: Int, b: Int): Unit  = word(r(0x20, b, a, 5, rd))
  def or(rd: Int, a: Int, b: Int): Unit   = word(r(0, b, a, 6, rd))
  def and(rd: Int, a: Int, b: Int): Unit  = word(r(0, b, a, 7, rd))
  def addi(rd: Int, a: Int, imm: Long): Unit  = word(i(imm, a, 0, rd))
  def slti(rd: Int, a: Int, imm: Long): Unit  = word(i(imm, a, 2, rd))
  def sltiu(rd: Int, a: Int, imm: Long): Unit = word(i(imm, a, 3, rd))
  def xori(rd: Int, a: Int, imm: Long): Unit  = word(i(imm, a, 4, rd))
  def ori(rd: Int, a: Int, imm: Long): Unit   = word(i(imm, a, 6, rd))
  def andi(rd: Int, a: Int, imm: Long): Unit  = word(i(imm, a, 7, rd))
  def slli(rd: Int, a: Int, sh: Int): Unit    = word(i(sh & 31, a, 1, rd))
  def srli(rd: Int, a: Int, sh: Int): Unit    = word(i(sh & 31, a, 5, rd))
  def srai(rd: Int, a: Int, sh: Int): Unit    = word(i(0x400 | (sh & 31), a, 5, rd))
  def nop(): Unit = addi(0, 0, 0)
  def mv(rd: Int, rs: Int): Unit = addi(rd, rs, 0)

  /** Load any 32-bit constant with ALU instructions only (no LUI on this core):
    * addi rd, x0, bits[31:22]; slli rd, rd, 11; ori rd, rd, bits[21:11]; slli rd, rd, 11; ori rd, rd, bits[10:0]
    * (each chunk is below 2048, so the sign-extended immediates are positive). Small values take one ADDI.
    */
  def li(rd: Int, v: Long): Unit = {
    val x = v & 0xFFFFFFFFL
    val sx = x.toInt.toLong
    if (sx >= -2048 && sx <= 2047) addi(rd, 0, sx)
    else {
      addi(rd, 0, (x >>> 22) & 0x3ff); slli(rd, rd, 11)
      ori(rd, rd, (x >>> 11) & 0x7ff); slli(rd, rd, 11)
      ori(rd, rd, x & 0x7ff)
    }
  }
}
