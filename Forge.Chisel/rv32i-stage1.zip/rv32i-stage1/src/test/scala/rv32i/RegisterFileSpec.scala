package rv32i

import chisel3._
import chiseltest._
import org.scalatest.flatspec.AnyFlatSpec

class RegisterFileSpec extends AnyFlatSpec with ChiselScalatestTester {
  "RegisterFile" should "read, write and protect x0 (lab1 cases)" in {
    test(new RegisterFile(CoreParams())).withAnnotations(TestUtil.waves) { dut =>
      def write(rd: Int, data: Int, enable: Boolean = true): Unit = {
        dut.io.rd.poke(rd.U); dut.io.writeData.poke(data.U); dut.io.writeEnable.poke(enable.B); dut.clock.step()
      }
      def read(rs1: Int, rs2: Int, exp1: Int, exp2: Int): Unit = {
        dut.io.rs1.poke(rs1.U); dut.io.rs2.poke(rs2.U); dut.io.readData1.expect(exp1.U); dut.io.readData2.expect(exp2.U)
      }
      read(0, 0, 0, 0)
      write(1, 10); write(2, 20); read(1, 2, 10, 20)
      write(5, 123); read(5, 0, 123, 0)
      write(6, 999, enable = false); read(6, 0, 0, 0)
      write(0, 999); read(0, 0, 0, 0)
    }
  }

  it should "start from the initial values, keep x0 at 0 even if a value is given, and show all registers on debugRead" in {
    val values = (0 until 32).map(i => BigInt(i * 10 + 7))   // x0 gets 7 here: must still read 0
    test(new RegisterFile(CoreParams(), values)).withAnnotations(TestUtil.waves) { dut =>
      for (i <- 0 until 32) {
        val exp = if (i == 0) 0 else i * 10 + 7
        dut.io.rs1.poke(i.U); dut.io.readData1.expect(exp.U)
        dut.io.rs2.poke(i.U); dut.io.readData2.expect(exp.U)
        dut.io.debugRead(i).expect(exp.U)
      }
    }
  }

  it should "write all 31 registers and return the old value during a write" in {
    test(new RegisterFile(CoreParams())).withAnnotations(TestUtil.waves) { dut =>
      for (k <- 0 until 32) {
        dut.io.writeEnable.poke(true.B); dut.io.rd.poke(k.U); dut.io.writeData.poke((0x01010101L * k).U(32.W))
        dut.clock.step()
      }
      dut.io.writeEnable.poke(false.B)
      for (k <- 0 until 32) dut.io.debugRead(k).expect((if (k == 0) 0L else 0x01010101L * k).U(32.W))
      dut.io.rs1.poke(7.U); dut.io.rd.poke(7.U); dut.io.writeData.poke(1.U); dut.io.writeEnable.poke(true.B)
      dut.io.readData1.expect((0x01010101L * 7).U(32.W))   // same cycle: old value
      dut.clock.step(); dut.io.writeEnable.poke(false.B)
      dut.io.readData1.expect(1.U)
    }
  }
}
