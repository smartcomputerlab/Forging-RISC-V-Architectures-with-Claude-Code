package rv32i

import chisel3._
import chiseltest._
import org.scalatest.flatspec.AnyFlatSpec

/** Timing contract of the single-cycle core: every instruction, valid or not, takes exactly one clock cycle;
  * the pc starts at 0 and advances by 4 every cycle; the result is visible in the register file after that edge.
  */
class TimingSpec extends AnyFlatSpec with ChiselScalatestTester {
  "RV32IRCore" should "execute one instruction per cycle, the 19 ALU instructions and any other word alike" in {
    val a = new Asm
    a.addi(1, 0, 6); a.addi(2, 0, 4)
    a.add(3, 1, 2); a.sub(3, 1, 2); a.sll(3, 1, 2); a.slt(3, 1, 2); a.sltu(3, 1, 2)
    a.xor(3, 1, 2); a.srl(3, 1, 2); a.sra(3, 1, 2); a.or(3, 1, 2); a.and(3, 1, 2)
    a.addi(3, 1, 1); a.slti(3, 1, 1); a.sltiu(3, 1, 1); a.xori(3, 1, 1); a.ori(3, 1, 1); a.andi(3, 1, 1)
    a.slli(3, 1, 1); a.srli(3, 1, 1); a.srai(3, 1, 1)
    a.word(0x00000073L); a.word(0L); a.word(Enc.r(1, 2, 1, 0, 3))   // not supported: no-ops, still one cycle
    val model = new RefModel()
    test(new RV32IRCore()).withAnnotations(TestUtil.waves) { c =>
      for ((w, k) <- a.words.zipWithIndex) {
        c.io.imemAddr.expect((4 * k).U)
        c.io.imemInst.poke(w.U(32.W))
        val r = model.step(w)
        c.clock.step()
        // the instruction completed in this single cycle: its result is already in the register file
        c.io.imemAddr.expect((4 * (k + 1)).U)
        c.io.debugX3.expect((if (k >= 2) model.x(3) else 0L).U(32.W))
        assert(r.pc == 4L * k)
      }
    }
  }
}
