package rv32i

import chisel3._
import chiseltest._
import org.scalatest.flatspec.AnyFlatSpec
import scala.util.Random
import TestUtil._

class ALUSpec extends AnyFlatSpec with ChiselScalatestTester {
  private val ops: Seq[(UInt, String, (Long, Long) => Long)] = Seq(
    (ALUOp.ADD, "ADD", (a, b) => a + b),
    (ALUOp.SUB, "SUB", (a, b) => a - b),
    (ALUOp.SLL, "SLL", (a, b) => a << (b & 31)),
    (ALUOp.SLT, "SLT", (a, b) => if (s32(a) < s32(b)) 1 else 0),
    (ALUOp.SLTU, "SLTU", (a, b) => if (a < b) 1 else 0),
    (ALUOp.XOR, "XOR", (a, b) => a ^ b),
    (ALUOp.SRL, "SRL", (a, b) => a >>> (b & 31)),
    (ALUOp.SRA, "SRA", (a, b) => s32(a) >> (b & 31)),
    (ALUOp.OR, "OR", (a, b) => a | b),
    (ALUOp.AND, "AND", (a, b) => a & b),
    (ALUOp.NOP, "NOP", (_, _) => 0L)
  )

  "ALU" should "pass the lab1 checks" in {
    test(new ALU(CoreParams())).withAnnotations(TestUtil.waves) { dut =>
      def check(a: BigInt, b: BigInt, op: UInt, expected: BigInt): Unit = {
        dut.io.a.poke(a.U); dut.io.b.poke(b.U); dut.io.op.poke(op)
        dut.io.y.expect(expected.U)
      }
      check(10, 3, ALUOp.ADD, 13); check(10, 3, ALUOp.SUB, 7); check(10, 3, ALUOp.AND, 2)
      check(10, 3, ALUOp.OR, 11); check(10, 3, ALUOp.XOR, 9); check(1, 4, ALUOp.SLL, 16); check(16, 2, ALUOp.SRL, 4)
      check(BigInt("ffffffff", 16), 1, ALUOp.SLT, 1); check(BigInt("ffffffff", 16), 1, ALUOp.SLTU, 0)
      check(BigInt("80000000", 16), 1, ALUOp.SRA, BigInt("c0000000", 16)); check(123, 456, ALUOp.NOP, 0)
    }
  }

  it should "compute every operation on all edge-value pairs (overflow, shift by 31/32, sign)" in {
    test(new ALU(CoreParams())).withAnnotations(TestUtil.waves) { c =>
      for ((op, name, f) <- ops; a <- edges; b <- edges) {
        c.io.op.poke(op); c.io.a.poke(a.U(32.W)); c.io.b.poke(b.U(32.W))
        val got = c.io.y.peek().litValue.toLong
        assert(got == (f(a, b) & M), f"$name 0x$a%08x 0x$b%08x: got 0x$got%08x")
      }
    }
  }

  it should "match the reference on random operands and give 0 for unused operation codes" in {
    test(new ALU(CoreParams())).withAnnotations(TestUtil.waves) { c =>
      val r = new Random(1)
      for (_ <- 0 until 3000) {
        val (op, name, f) = ops(r.nextInt(ops.length))
        val a = rnd32(r); val b = rnd32(r)
        c.io.op.poke(op); c.io.a.poke(a.U(32.W)); c.io.b.poke(b.U(32.W))
        val got = c.io.y.peek().litValue.toLong
        assert(got == (f(a, b) & M), f"$name 0x$a%08x 0x$b%08x: got 0x$got%08x")
      }
      for (code <- 10 to 14) { c.io.op.poke(code.U); c.io.a.poke(5.U); c.io.b.poke(7.U); c.io.y.expect(0.U) }
    }
  }
}
