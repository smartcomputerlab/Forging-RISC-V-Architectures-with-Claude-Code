package rv32i

import chisel3._
import chiseltest._

/** Lockstep harness: runs a program on RV32IRCore (instruction words fed from a Scala array) and on RefModel,
  * one instruction per cycle, and compares pc, instruction, valid, rd and rd value every cycle.
  */
object CoreSim {
  private def check(ok: Boolean, msg: => String): Unit = if (!ok) throw new AssertionError(msg)
  final case class Result(model: RefModel, executed: Int, invalid: Int, cycles: Int)

  def run(c: RV32IRCore, prog: Seq[Long], initialRegs: Seq[BigInt] = Seq.empty, extraCycles: Int = 0): Result = {
    val model = new RefModel(initialRegs)
    val n = prog.length + extraCycles
    var executed = 0; var invalid = 0
    for (cycle <- 0 until n) {
      val pc = c.io.imemAddr.peek().litValue.toLong
      val idx = (pc / 4).toInt
      val w = if (idx < prog.length) prog(idx) else 0L
      c.io.imemInst.poke(w.U(32.W))
      val r = model.step(w)
      val t = c.io.trace
      def hw(d: UInt): Long = d.peek().litValue.toLong
      val where = f"cycle $cycle, pc 0x${r.pc}%08x, inst 0x${r.inst}%08x (${Disasm(r.inst, r.pc)})"
      check(pc == r.pc && hw(t.pc) == r.pc && hw(c.io.debugPC) == r.pc, f"$where: pc hw=0x$pc%08x")
      check(hw(t.inst) == r.inst, s"$where: inst")
      check(t.valid.peek().litToBoolean == r.valid, s"$where: valid hw=${t.valid.peek().litToBoolean} model=${r.valid}")
      check(hw(t.rdAddr) == r.rdAddr, s"$where: rdAddr hw=${hw(t.rdAddr)} model=${r.rdAddr}")
      check(hw(t.rdData) == r.rdData, f"$where: rdData hw=0x${hw(t.rdData)}%08x model=0x${r.rdData}%08x")
      if (r.valid) executed += 1 else invalid += 1
      c.clock.step()
      // after the edge, the debug ports show the registers the model now holds
      for ((port, k) <- Seq(c.io.debugX1, c.io.debugX2, c.io.debugX3, c.io.debugX4).zip(1 to 4))
        check(hw(port) == model.x(k), f"$where: after the cycle x$k hw=0x${hw(port)}%08x model=0x${model.x(k)}%08x")
    }
    Result(model, executed, invalid, n)
  }
}
