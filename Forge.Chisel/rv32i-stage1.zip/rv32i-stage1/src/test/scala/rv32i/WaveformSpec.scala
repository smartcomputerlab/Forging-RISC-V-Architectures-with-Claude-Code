package rv32i

import chisel3._
import chiseltest._
import firrtl.options.TargetDirAnnotation
import org.scalatest.flatspec.AnyFlatSpec
import org.scalatest.matchers.should.Matchers

import java.nio.file.{Files, Path, Paths}

/** Writes VCD waveforms of short demo programs into waves/<name>/, with a GTKWave session (core.gtkw), translate
  * filters for the instruction bus and the ALU operation, and a program listing. Every run is also checked against
  * RefModel, so a waveform is only written for a correct run.
  */
class WaveformSpec extends AnyFlatSpec with ChiselScalatestTester with Matchers {
  private def annos(dir: Path) = Seq(WriteVcdAnnotation, TargetDirAnnotation(dir.toString))

  private def sideFiles(dir: Path, words: Seq[Long], vcd: String, top: String): Unit = {
    Files.write(dir.resolve("program.lst"), Disasm.listing(words, 0L).getBytes("UTF-8"))
    Gtkw.writeFilter(dir, "inst.filter",
      (words.zipWithIndex.map { case (w, k) => w -> Disasm(w, 4L * k) } :+ (0L -> "(empty: no-op)")).distinctBy(_._1), 8)
    Gtkw.writeAluOpFilter(dir)
    Gtkw.write(dir, vcd, "core.gtkw", Gtkw.coreGroups(top))
  }

  /** Runs `a` on RV32IRCore (checked against RefModel) and writes waves/<name>/. */
  private def demoCore(name: String, a: Asm, regs: Seq[BigInt] = Seq.empty): CoreSim.Result = {
    val dir = Paths.get("waves", name); Files.createDirectories(dir)
    var res: CoreSim.Result = null
    test(new RV32IRCore(CoreParams(), regs)).withAnnotations(annos(dir)) { c => res = CoreSim.run(c, a.words, regs) }
    sideFiles(dir, a.words, "RV32IRCore.vcd", "RV32IRCore")
    res
  }

  "Waveforms" should "show the lab1 program from memory.hex in RV32ITestWrapper (waves/lab1_rtype)" in {
    val dir = Paths.get("waves", "lab1_rtype"); Files.createDirectories(dir)
    val words = InstructionMemory.readHex("memory.hex").map(_.toLong)
    test(new RV32ITestWrapper(CoreParams(), "memory.hex", Lab1.regs)).withAnnotations(annos(dir)) { dut =>
      val model = new RefModel(Lab1.regs)
      for (w <- words) {
        val r = model.step(w)
        dut.io.trace.rdAddr.expect(r.rdAddr.U); dut.io.trace.rdData.expect(r.rdData.U(32.W))
        dut.clock.step()
      }
      dut.io.debugX3.expect(13.U); dut.io.debugX4.expect(7.U)
      dut.clock.step(2)   // two cycles past the end: no-ops
    }
    sideFiles(dir, words, "RV32ITestWrapper.vcd", "RV32ITestWrapper.core")
    Files.exists(dir.resolve("RV32ITestWrapper.vcd")) shouldBe true
  }

  it should "show the I-type ALU instructions and constants built with ALU instructions (waves/alu_imm)" in {
    val a = new Asm
    a.li(1, 0x12345678L)            // addi / slli / ori sequence
    a.addi(2, 0, -100); a.slti(3, 2, 0); a.sltiu(4, 2, 5); a.xori(5, 1, -1); a.ori(6, 2, 0x0ff); a.andi(7, 1, 0x0f0)
    a.slli(8, 2, 4); a.srli(9, 2, 28); a.srai(10, 2, 2)
    val r = demoCore("alu_imm", a)
    r.model.x(1) shouldBe 0x12345678L
    r.model.x(10) shouldBe ((-25L) & 0xFFFFFFFFL)
    Files.exists(Paths.get("waves", "alu_imm", "RV32IRCore.vcd")) shouldBe true
  }

  it should "show R-type operations, a dependency chain and unsupported words executed as no-ops (waves/mixed)" in {
    val a = new Asm
    a.addi(1, 0, 7); a.addi(2, 0, -3)
    a.add(3, 1, 2); a.sub(4, 1, 2); a.sll(5, 1, 2); a.slt(6, 2, 1); a.sltu(7, 2, 1)
    a.xor(8, 1, 2); a.srl(9, 2, 1); a.sra(10, 2, 1); a.or(11, 1, 2); a.and(12, 1, 2)
    a.word(0x00000073L)             // ecall: not supported, no-op
    a.word(Enc.r(1, 2, 1, 0, 13))   // mul: not supported, no-op
    a.add(13, 3, 4); a.add(14, 13, 13)
    val r = demoCore("mixed", a)
    r.invalid shouldBe 2
    r.model.x(14) shouldBe 28
    Files.exists(Paths.get("waves", "mixed", "RV32IRCore.vcd")) shouldBe true
  }
}
