package rv32i

import chisel3._

/** I-type immediate (instr[31:20]) sign-extended to xlen. For SLLI/SRLI/SRAI the ALU uses only its low bits. */
class ImmediateGenerator(p: CoreParams) extends Module {
  val io = IO(new Bundle {
    val instr = Input(UInt(32.W))
    val imm   = Output(UInt(p.xlen.W))
  })
  io.imm := io.instr(31, 20).asSInt.pad(p.xlen).asUInt
}
