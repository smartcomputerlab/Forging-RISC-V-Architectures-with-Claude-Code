package rv32i

import java.io.File
import java.nio.file.{Files, Paths}
import scala.annotation.nowarn

/** SystemVerilog generation into generated/:
  *  - `sbt "runMain rv32i.Emit"`              : RV32IRCore and RV32ITestWrapper (with memory.hex)
  *  - `sbt "runMain rv32i.GenerateRV32IRCore"` / `"runMain rv32i.GenerateRV32ITestWrapper"`: one of them
  *
  * Chisel 3.6 uses CIRCT firtool when it is on the PATH (target 1.37.0); otherwise it falls back to Chisel 3's
  * built-in legacy compiler (the firtool options are then not applied).
  */
object Emit extends App {
  // (no vals here that other code reads: fields of an `App` object are only set once its main() has run)

  def emit(name: String, gen: => chisel3.RawModule): Unit = {
    val firtool = sys.env.getOrElse("PATH", "").split(File.pathSeparator).exists(d => new File(d, "firtool").canExecute)
    if (firtool)
      circt.stage.ChiselStage.emitSystemVerilogFile(gen, Array("--target-dir", "generated"),
        Array("-disable-all-randomization", "-strip-debug-info"))
    else {
      Console.err.println(s"$name: firtool not found on PATH, using the legacy Scala FIRRTL compiler (firtool options not applied).")
      legacy(name, gen)
    }
  }

  @nowarn("cat=deprecation") // the legacy compiler is deprecated in Chisel 3.6; it is only the fallback
  private def legacy(name: String, gen: => chisel3.RawModule): Unit = {
    val sv = (new chisel3.stage.ChiselStage).emitSystemVerilog(gen, Array("--target-dir", "generated"))
    Files.createDirectories(Paths.get("generated"))
    Files.write(Paths.get("generated", s"$name.sv"), sv.getBytes("UTF-8"))
  }

  emit("RV32IRCore", new RV32IRCore(CoreParams(), Lab1.regs))
  emit("RV32ITestWrapper", new RV32ITestWrapper(CoreParams(), "memory.hex", Lab1.regs))
}

/** The lab1 configuration. */
object Lab1 {
  /** x1 = 10, x2 = 3, all other registers 0. */
  val regs: Seq[BigInt] = Seq(BigInt(0), BigInt(10), BigInt(3)) ++ Seq.fill(29)(BigInt(0))
}

object GenerateRV32IRCore extends App {
  Emit.emit("RV32IRCore", new RV32IRCore(CoreParams(), Lab1.regs))
}

object GenerateRV32ITestWrapper extends App {
  Emit.emit("RV32ITestWrapper", new RV32ITestWrapper(CoreParams(), "memory.hex", Lab1.regs))
}
