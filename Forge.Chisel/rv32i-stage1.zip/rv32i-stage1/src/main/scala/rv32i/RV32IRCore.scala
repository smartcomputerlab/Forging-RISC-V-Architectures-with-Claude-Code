package rv32i

import chisel3._
import chisel3.util._

/** Single-cycle RV32I ALU core (lab1): executes the 19 RV32I ALU instructions, one per clock cycle.
  *
  *  - R-type: ADD SUB SLL SLT SLTU XOR SRL SRA OR AND        (ALU b = rs2)
  *  - I-type: ADDI SLTI SLTIU XORI ORI ANDI SLLI SRLI SRAI   (ALU b = sign-extended immediate)
  *
  * There are no loads, stores, branches or jumps: the pc always advances by 4. An instruction the decoder does not
  * recognise is executed as a no-op (no register write, trace.valid = 0). Registers can be preset with
  * `initialRegs` (x0 stays 0).
  */
class RV32IRCore(
  p: CoreParams = CoreParams(),
  initialRegs: Seq[BigInt] = Seq.empty,
  resetPc: BigInt = 0
) extends Module {
  require(p.xlen == 32, "RV32IRCore implements RV32I: xlen must be 32")
  require(p.numRegs == 32, "RV32IRCore implements RV32I: 32 registers")

  val io = IO(new Bundle {
    // Instruction-memory interface (combinational read).
    val imemAddr = Output(UInt(p.xlen.W))
    val imemInst = Input(UInt(32.W))
    // Debug outputs for laboratory verification.
    val debugPC = Output(UInt(p.xlen.W))
    val debugX1 = Output(UInt(p.xlen.W))
    val debugX2 = Output(UInt(p.xlen.W))
    val debugX3 = Output(UInt(p.xlen.W))
    val debugX4 = Output(UInt(p.xlen.W))
    // What was executed this cycle (used by the test harness and in waveforms).
    val trace = Output(new Trace(p))
  })

  // ---------------------------------------------------------------- program counter
  val pc = RegInit(resetPc.U(p.xlen.W))
  io.imemAddr := pc
  io.debugPC  := pc

  // ---------------------------------------------------------------- decode
  val decoder = Module(new Decoder)
  decoder.io.instr := io.imemInst

  val immGen = Module(new ImmediateGenerator(p))
  immGen.io.instr := io.imemInst

  // ---------------------------------------------------------------- register file
  val regFile = Module(new RegisterFile(p, initialRegs))
  regFile.io.rs1 := decoder.io.rs1
  regFile.io.rs2 := decoder.io.rs2

  // ---------------------------------------------------------------- ALU
  val alu = Module(new ALU(p))
  alu.io.a  := regFile.io.readData1
  alu.io.b  := Mux(decoder.io.aluSrc, immGen.io.imm, regFile.io.readData2)
  alu.io.op := decoder.io.aluOp

  // ---------------------------------------------------------------- write-back
  regFile.io.rd          := decoder.io.rd
  regFile.io.writeData   := alu.io.y
  regFile.io.writeEnable := decoder.io.regWrite

  // ---------------------------------------------------------------- next pc
  pc := pc + 4.U

  // ---------------------------------------------------------------- debug and trace
  io.debugX1 := regFile.io.debugRead(1)
  io.debugX2 := regFile.io.debugRead(2)
  io.debugX3 := regFile.io.debugRead(3)
  io.debugX4 := regFile.io.debugRead(4)

  val writes = decoder.io.regWrite && decoder.io.rd =/= 0.U
  io.trace.pc     := pc
  io.trace.inst   := io.imemInst
  io.trace.valid  := decoder.io.valid
  io.trace.rdAddr := Mux(writes, decoder.io.rd, 0.U)
  io.trace.rdData := Mux(writes, alu.io.y, 0.U)

  assert(!(decoder.io.regWrite && !decoder.io.valid), "register write by an unrecognised instruction")
}
