package rv32i

import chisel3._
import scala.io.Source

/** Read-only instruction memory initialised from a hex file at elaboration time (one 32-bit word per line;
  * blank lines, `#` comments and `_` separators allowed). Combinational read; word address = addr >> 2;
  * words past the end of the file read as 0 (not a valid instruction: executed as a no-op by the core).
  */
class InstructionMemory(
  fileName: String,
  depth: Int = 1024
) extends Module {
  val io = IO(new Bundle {
    val addr = Input(UInt(32.W))
    val inst = Output(UInt(32.W))
  })

  val instructions: Seq[BigInt] = InstructionMemory.readHex(fileName)
  require(instructions.nonEmpty, s"Instruction memory file '$fileName' is empty")
  require(instructions.length <= depth, s"Instruction memory contains ${instructions.length} words, but depth is only $depth")

  val mem = VecInit(instructions.map(_.U(32.W)) ++ Seq.fill(depth - instructions.length)(0.U(32.W)))
  val wordAddr = io.addr >> 2
  io.inst := Mux(wordAddr < depth.U, mem(wordAddr(chisel3.util.log2Ceil(depth) - 1, 0)), 0.U)
}

object InstructionMemory {
  /** Parse a hex file: one word per line, `#` comments, `_` separators. */
  def readHex(fileName: String): Seq[BigInt] = {
    val source = Source.fromFile(fileName)
    try {
      source.getLines().toVector
        .map(_.split("#").headOption.getOrElse("").trim)
        .filter(_.nonEmpty)
        .map(line => BigInt(line.replace("_", ""), 16))
    } finally source.close()
  }
}
