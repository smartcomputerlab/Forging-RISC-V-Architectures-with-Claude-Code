package rv32i

import chisel3._

/** What the core did this cycle (one instruction per cycle). */
class Trace(p: CoreParams) extends Bundle {
  val pc     = UInt(p.xlen.W)
  val inst   = UInt(32.W)
  val valid  = Bool()          // the instruction was recognised and executed (else: executed as a no-op)
  val rdAddr = UInt(5.W)       // 0 when no register is written
  val rdData = UInt(p.xlen.W)  // 0 when no register is written
}
