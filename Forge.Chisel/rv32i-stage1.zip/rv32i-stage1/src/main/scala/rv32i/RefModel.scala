package rv32i

/** What one instruction did (32-bit values held in Long). */
final case class TraceRecord(pc: Long, inst: Long, valid: Boolean, rdAddr: Int, rdData: Long)

/** Instruction-level reference model of RV32IRCore: the 19 RV32I ALU instructions; anything else is a no-op. */
class RefModel(initialRegs: Seq[BigInt] = Seq.empty, resetPc: Long = 0L) {
  private val M = 0xFFFFFFFFL
  val x: Array[Long] = Array.tabulate(32)(i => if (i == 0 || initialRegs.isEmpty) 0L else initialRegs(i).toLong & M)
  var pc: Long = resetPc

  private def s32(v: Long): Long = v.toInt.toLong

  /** Executes `inst` at the current pc. */
  def step(inst: Long): TraceRecord = {
    val op = (inst & 0x7f).toInt; val rd = ((inst >> 7) & 31).toInt; val f3 = ((inst >> 12) & 7).toInt
    val rs1 = ((inst >> 15) & 31).toInt; val rs2 = ((inst >> 20) & 31).toInt; val f7 = ((inst >> 25) & 0x7f).toInt
    val a = x(rs1)
    val imm = ((inst << 32) >> 52) & M // sign-extended inst[31:20]
    def alu(fn: Int, alt: Boolean, b: Long): Long = {
      val sh = (b & 31).toInt
      (fn match {
        case 0 => if (alt) a - b else a + b
        case 1 => a << sh
        case 2 => if (s32(a) < s32(b)) 1L else 0L
        case 3 => if (a < b) 1L else 0L
        case 4 => a ^ b
        case 5 => if (alt) s32(a) >> sh else a >>> sh
        case 6 => a | b
        case _ => a & b
      }) & M
    }
    val result: Option[Long] = op match {
      case 0x33 if f7 == 0 || (f7 == 0x20 && (f3 == 0 || f3 == 5)) => Some(alu(f3, f7 == 0x20, x(rs2)))
      case 0x13 if !(f3 == 1 && f7 != 0) && !(f3 == 5 && f7 != 0 && f7 != 0x20) => Some(alu(f3, f3 == 5 && f7 == 0x20, imm))
      case _ => None
    }
    val writes = result.isDefined && rd != 0
    if (writes) x(rd) = result.get
    val rec = TraceRecord(pc, inst & M, result.isDefined, if (writes) rd else 0, if (writes) result.get else 0L)
    pc = (pc + 4) & M
    rec
  }
}
