package rv32i

/** Core configuration. The instruction set is RV32I, so `xlen` must be 32 for `RV32IRCore`;
  * the ALU and the register file are written for any width and register count.
  */
case class CoreParams(
  xlen: Int = 32,
  numRegs: Int = 32
)
