# Design notes: Stage 10, 5-stage pipelined RV32IMF core

## Architecture

| Item | Choice |
|---|---|
| ISA | RV32IMF (40 + 8 + 26 instructions) + Zicsr (6) + MRET and WFI, machine mode only, no interrupts |
| Pipeline | 5 stages: IF, ID, EX, MEM, WB (the Stage 7 `rv32im-pipe5` pipeline) |
| Floating point | IEEE 754 binary32, five rounding modes + dynamic (frm), five flags accrued in fcsr, canonical NaN, tininess after rounding (the Stage 9 FPU) |
| Register files | x0..x31 (x0 = 0) and f0..f31, both read in ID with a WB→ID bypass, both forwarded into EX |
| Multi-cycle units in EX | Sequential divider (34 cycles) and sequential FPU (see the latency table): IF/ID/EX freeze, MEM/WB drain |
| Single-cycle FP | `FpMisc` in EX: sign injection, min/max, compares, class; FMV.X.W / FMV.W.X; FLW/FSW through MEM |
| Memories | Harvard, zero-wait: instruction ROM at 0x80000000, data RAM at 0x80010000 (`RV32ITestWrapper`) |

## Stage progression

| Stage | Instructions | Microarchitecture |
|---|---|---|
| 1–5 | RV32I ALU → loads/JALR → full RV32I + Zicsr → + MUL → + DIV/REM | Single cycle |
| 6 | RV32IM | 2-stage pipeline |
| 7 | RV32IM | 5-stage pipeline with forwarding |
| 8 | RV32IM | 5-stage pipeline + I-cache and D-cache |
| 9 | **RV32IMF** | Single cycle + sequential FPU |
| **10** | **RV32IMF** | **5-stage pipeline (Stage 7) + the Stage 9 FPU, f registers and fcsr** |

## Pipeline

```
  IF            ID                         EX                                 MEM             WB
fetchPc ─► IfId ─► Decoder, FDecoder ─► IdEx ─► forward x and f ─► Alu/Mul ──► ExMem ─► dmem ─► MemWb ─► RegFile and
  ▲  imem          ImmGen, RegFile and  ▲        │                 DivUnit, Fpu       load align       FRegFile write,
  │                FRegFile read (bypass)│        │                 FpMisc, CsrFile                     trace
  └──── redirect (nextPc) ◄──────────────┼────────┘                 branch, traps
                                         └── forwarding from ExMem (non-load) and MemWb, x and f separately
```

| Stage | Work | Pipeline register written |
|---|---|---|
| IF | Read the instruction at `fetchPc`; next fetch at `fetchPc + 4` | `IfId` |
| ID | Decode (integer decoder + `FDecoder` for register usage), immediate (S-type for FSW), x and f register read with WB→ID bypass, load-use detection for both files | `IdEx` (operands x rs1/rs2 and f rs1/rs2/rs3, imm, `Ctrl`) |
| EX | Forwarding (x and f), ALU, multiplier, divider, **FPU**, **FpMisc**, branch/jump resolution, CSR access, **rounding-mode resolution and F legality (with the current frm)**, exception detection, trap entry, commit (**fflags accrue here**) | `ExMem` |
| MEM | Data memory access (LW…, FLW, SW…, FSW), load alignment | `MemWb` |
| WB | x or f register write, retirement trace (with the raised flags) | – |

Pipeline control, by priority:

| Condition | fetchPc, IfId | IdEx | ExMem |
|---|---|---|---|
| `exStall` = `divStall` or `fpuStall` (a division or a rounding FP operation busy in EX) | hold | hold | bubble |
| `redirect` (taken branch, JAL, JALR, trap, MRET in EX) | fetchPc := target, IfId := bubble | bubble | the EX instruction (or its trap record) |
| `loadUse` (ID reads the destination of a load in EX, in the same register file) | hold | bubble | the load |
| otherwise | advance | advance | advance |

MEM and WB never stall.

## Hazards

| Hazard | Handling | Cost |
|---|---|---|
| RAW, distance 1 (x or f producer in MEM) | Forward `ExMem.result` into EX (not for loads) | 0 |
| RAW, distance 2 (producer in WB) | Forward `MemWb.wdata` into EX | 0 |
| RAW, distance 3 | WB→ID bypass of the x and f register reads | 0 |
| Load-use: LW… / FLW followed by a reader of its destination (x rs1/rs2, or f rs1/rs2/rs3, FSW data included) | Stall IF/ID one cycle, bubble into EX, then forward from WB | 1 cycle |
| x ↔ f: FMV.W.X, FCVT.S.W(U) read x; FMV.X.W, FCVT.W(U).S, FEQ/FLT/FLE, FCLASS write x | Ordinary x forwarding; f and x registers are separate (f5 is not x5) | 0 |
| Control | Resolved in EX; flush IfId and IdEx | 2 cycles |
| Divider | IF/ID/EX freeze; MEM/WB drain | 33 cycles (1 for x/0, overflow) |
| FPU | IF/ID/EX freeze; MEM/WB drain | the FPU latency (below) |
| CSR order (frm, fflags) | All CSR reads and writes, the rounding-mode resolution and the flag accrual happen in EX, in program order | 0 |

FPU latencies (extra cycles in EX): FADD/FSUB 5, FMUL and the fused multiply-adds 29, FDIV/FSQRT 31, FCVT.W(U).S 3,
FCVT.S.W(U) 4, special operands 2, exact-zero sums 3 (FADD/FSUB) and 27 (fused multiply-add). The FPU itself is the
Stage 9 `Fpu` unchanged: unpack, 24-step multiplier, aligner/adder with guard, round and sticky bits, 27-step divider and
square root, normalizer and rounder (see `Fpu.scala`).

## Precise exceptions

Every exception is known in EX: illegal instruction (integer decoder, or `FDecoder` in EX: bad F encodings and reserved
rounding modes, judged with the frm value that program order gives), ECALL and EBREAK; misaligned load/store addresses
(FLW/FSW included) and misaligned targets are computed in EX. The trap is taken in EX: older instructions in MEM and WB
complete, the two younger ones are flushed, the trapping instruction writes nothing and raises no flag. An FP instruction
that starts the FPU never traps, so the FPU never has to be cancelled (`kill` is tied to `trapNow` as a safety net).
Since nothing can fail after EX, an instruction that leaves EX is committed: minstret counts and fflags accrue there.

## Execution rules (trace, WB stage)

Every cycle the trace reports at most one event: a retirement (`valid`, with the x or f register written and the flags
raised), a trap (`trap`), or nothing (pipeline fill, bubbles after a redirect or load-use, cycles while the divider or the
FPU holds EX).

## Choices made where the specification leaves an option

| Topic | Choice | Why |
|---|---|---|
| Where the FPU sits | In EX, freezing IF/ID/EX like the divider | Same mechanism as the divider; precise state without a reorder buffer |
| Where fflags accrue | In EX, when the instruction commits | CSR reads and writes also happen in EX, so a following `csrr fflags` sees the flags with no extra hazard logic |
| Where the rounding mode is resolved | In EX (second `FDecoder` fed with the live frm) | A CSR write to frm right before a dynamic-mode FP instruction must apply to it; in ID frm could still be stale |
| FLW load-use | One stall, like LW, for any f source (FSW data included) | Load data arrives in MEM |
| Separate x and f hazards | Load-use and forwarding compare register numbers only within the same file | No false stalls between f5 and x5 |
| mstatus.FS | Hardwired Dirty, SD = 1 | As in Stage 9 |
| Everything else | As in Stages 7 and 9 | Unchanged |

## Verification

- The Stage 9 floating-point suites, unchanged: `FpRefSpec` (the reference against the JVM's IEEE arithmetic),
  `FpuSpec` (the FPU against the reference, bit for bit with flags, all rounding modes, latencies, corner cases),
  `FpMiscSpec`, `CsrFileSpec`.
- `CoreFpSpec` (from Stage 9) on the pipelined core in lockstep with `RefModel`: special operands in every rounding mode,
  single-cycle FP instructions, FLW/FSW and misaligned traps, fcsr, illegal encodings and rounding modes, 1,500 random
  mixed integer/FP instructions, the FPU stall of every operation.
- `CoreFpPipeSpec` (new): forwarding of f results at distances 1, 2 and 3 and between the files, FLW load-use stalls on
  each f source and on FSW data, LW → FMV.W.X, no false stalls, frm written right before a dynamic FP instruction,
  fflags read right after an FP instruction, a reserved frm, wrong-path FP instructions flushed without effect.
- The Stage 7 pipeline suites: `CoreProgramSpec`, `CoreTimingSpec` (exact cycle of every instruction, redirect
  bubbles, load-use), `CoreDivSpec`; plus the unit suites.
- `MemorySpec` runs the floating-point `program.hex` on the wrapper: every result, the flags, 51 retirements and exactly
  236 empty cycles (222 FPU + 4 fill + 4 FLW load-use + 3 × 2 branch bubbles).
- Planted bugs in the pipeline, each planted alone; every one makes the suite fail:

| Planted bug | Caught by |
|---|---|
| f results not forwarded from EX/MEM | `CoreFpPipeSpec` (2 tests) |
| No load-use stall after FLW | `CoreFpPipeSpec` |
| The rounding mode resolved with frm one cycle late | `CoreFpPipeSpec` |
| FSW storing x[rs2] instead of f[rs2] | `MemorySpec` |
| Flags accrued in every cycle, not only when the instruction commits (stale FPU flags during a stall) | `CoreFpPipeSpec` |

(The Stage 9 FPU planted bugs, caught by `FpuSpec`, apply unchanged: the FPU is the same module.)

