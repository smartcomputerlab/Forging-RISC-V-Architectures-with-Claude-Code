package rv32i

import chisel3._

/** RISC-V major opcodes (inst[6:0]) used by this core. */
object Opcode {
  val LOAD     = 0x03
  val MISC_MEM = 0x0f
  val OP_IMM   = 0x13
  val AUIPC    = 0x17
  val STORE    = 0x23
  val OP       = 0x33
  val LUI      = 0x37
  val BRANCH   = 0x63
  val JALR     = 0x67
  val JAL      = 0x6f
  val SYSTEM   = 0x73
}

/** mcause exception codes (interrupt bit = 0). */
object Cause {
  val InstrAddrMisaligned = 0
  val IllegalInstruction  = 2
  val Breakpoint          = 3
  val LoadAddrMisaligned  = 4
  val StoreAddrMisaligned = 6
  val EcallFromM          = 11
}

/** CSR addresses implemented by [[CsrFile]]. */
object CsrAddr {
  val fflags    = 0x001
  val frm       = 0x002
  val fcsr      = 0x003
  val mstatus   = 0x300
  val misa      = 0x301
  val mie       = 0x304
  val mtvec     = 0x305
  val mstatush  = 0x310
  val mscratch  = 0x340
  val mepc      = 0x341
  val mcause    = 0x342
  val mtval     = 0x343
  val mip       = 0x344
  val mcycle    = 0xb00
  val minstret  = 0xb02
  val mcycleh   = 0xb80
  val minstreth = 0xb82
  val cycle     = 0xc00
  val instret   = 0xc02
  val cycleh    = 0xc80
  val instreth  = 0xc82
  val mvendorid = 0xf11
  val marchid   = 0xf12
  val mimpid    = 0xf13
  val mhartid   = 0xf14

  /** misa for RV32IMF: MXL = 1 (bits 31:30), F = bit 5, I = bit 8, M = bit 12. */
  val MisaValue = 0x40001120L
}

/** First ALU operand. */
object ASrc extends ChiselEnum {
  val RS1, PC, ZERO = Value
}

/** Write-back source. */
object WbSel extends ChiselEnum {
  val ALU, MEM, PC4, CSR = Value
}

/** Immediate format. */
object ImmSel extends ChiselEnum {
  val I, S, B, U, J = Value
}

/** ALU operation. */
object AluOp extends ChiselEnum {
  val ADD, SUB, SLL, SLT, SLTU, XOR, SRL, SRA, OR, AND = Value
}

/** Instruction port: zero-wait, `data` is a combinational function of `addr`. */
class InstrMemPort extends Bundle {
  val addr = Output(UInt(32.W))
  val data = Input(UInt(32.W))
}

/** Data port: zero-wait. `rdata` is the aligned word at `addr & ~3`, a combinational function of `addr`.
  * A store writes the bytes selected by `wstrb` of `wdata` (already shifted into byte lanes) at the clock edge.
  */
class DataMemPort extends Bundle {
  val addr  = Output(UInt(32.W))
  val re    = Output(Bool())
  val we    = Output(Bool())
  val wdata = Output(UInt(32.W))
  val wstrb = Output(UInt(4.W))
  val rdata = Input(UInt(32.W))
}

/** Per-cycle retirement trace (WB stage). `valid`: an instruction retired. `trap`: an exception was taken.
  * Both low: a pipeline bubble, or a cycle in which the divider or the FPU holds EX (nothing retired).
  */
class Trace extends Bundle {
  val valid    = Bool()
  val trap     = Bool()
  val cause    = UInt(4.W)
  val pc       = UInt(32.W)
  val pcNext   = UInt(32.W)
  val inst     = UInt(32.W)
  val rdAddr   = UInt(5.W)   // 0 when no register is written
  val rdData   = UInt(32.W)  // 0 when no register is written
  val memAddr  = UInt(32.W)
  val memRe    = Bool()
  val memWe    = Bool()
  val memSize  = UInt(2.W)   // 0 byte, 1 half, 2 word
  val memWdata = UInt(32.W)  // store data, not shifted into lanes
  val fdWe     = Bool()       // a floating-point register was written
  val fdAddr   = UInt(5.W)    // 0 when no f register is written
  val fdData   = UInt(32.W)   // 0 when no f register is written
  val fflags   = UInt(5.W)    // exception flags raised by this instruction (ORed into fcsr.fflags)
}

// ===================== 5-stage pipeline registers =====================

/** Decoded control signals carried from ID to EX. */
class Ctrl extends Bundle {
  val aluSrcA     = ASrc()
  val aluSrcImm   = Bool()
  val aluOp       = AluOp()
  val branch      = Bool()
  val jal         = Bool()
  val jalr        = Bool()
  val memRead     = Bool()   // LB..LHU and FLW
  val memWrite    = Bool()   // SB, SH, SW and FSW
  val memSize     = UInt(2.W)
  val memUnsigned = Bool()
  val wbSel       = WbSel()
  val regWrite    = Bool()   // writes x[rd]
  val csr         = Bool()
  val ecall       = Bool()
  val ebreak      = Bool()
  val mret        = Bool()
  val illegal     = Bool()   // integer part; the F part is decided in EX (it depends on frm)
  val isMul       = Bool()   // MUL, MULH, MULHSU, MULHU
  val isDiv       = Bool()   // DIV, DIVU, REM, REMU (sequential)
  val usesRs1     = Bool()   // x sources, for hazard detection and forwarding
  val usesRs2     = Bool()
  val isF         = Bool()   // an F-extension opcode
  val fWrite      = Bool()   // writes f[rd]
  val usesFrs1    = Bool()   // f sources
  val usesFrs2    = Bool()
  val usesFrs3    = Bool()
}

/** IF/ID: the fetched instruction. */
class IfId extends Bundle {
  val valid = Bool()
  val pc    = UInt(32.W)
  val inst  = UInt(32.W)
}

/** ID/EX: decoded instruction with its register operands (read in ID, possibly overridden by forwarding in EX). */
class IdEx extends Bundle {
  val valid   = Bool()
  val pc      = UInt(32.W)
  val inst    = UInt(32.W)
  val rs1     = UInt(5.W)
  val rs2     = UInt(5.W)
  val rs3     = UInt(5.W)
  val rd      = UInt(5.W)
  val rs1Val  = UInt(32.W)
  val rs2Val  = UInt(32.W)
  val frs1Val = UInt(32.W)
  val frs2Val = UInt(32.W)
  val frs3Val = UInt(32.W)
  val imm     = UInt(32.W)
  val ctrl    = new Ctrl
}

/** EX/MEM: an executed instruction, or a trap travelling to WB to be reported in program order. */
class ExMem extends Bundle {
  val valid       = Bool()
  val trap        = Bool()
  val cause       = UInt(4.W)
  val pc          = UInt(32.W)
  val pcNext      = UInt(32.W)   // architectural successor (for the trace)
  val inst        = UInt(32.W)
  val rd          = UInt(5.W)    // x or f destination
  val regWrite    = Bool()       // x[rd]
  val fWrite      = Bool()       // f[rd]
  val result      = UInt(32.W)   // ALU / PC+4 / CSR / MUL / DIV / FP value
  val memRead     = Bool()
  val memWrite    = Bool()
  val memSize     = UInt(2.W)
  val memUnsigned = Bool()
  val addr        = UInt(32.W)
  val storeData   = UInt(32.W)
  val fflags      = UInt(5.W)    // exception flags raised (already accrued in EX; for the trace)
}

/** MEM/WB: the value to write back and the trace record. */
class MemWb extends Bundle {
  val valid    = Bool()
  val trap     = Bool()
  val cause    = UInt(4.W)
  val pc       = UInt(32.W)
  val pcNext   = UInt(32.W)
  val inst     = UInt(32.W)
  val rd       = UInt(5.W)
  val regWrite = Bool()
  val fWrite   = Bool()
  val wdata    = UInt(32.W)
  val memRe    = Bool()
  val memWe    = Bool()
  val memAddr  = UInt(32.W)
  val memSize  = UInt(2.W)
  val memWdata = UInt(32.W)
  val fflags   = UInt(5.W)
}
