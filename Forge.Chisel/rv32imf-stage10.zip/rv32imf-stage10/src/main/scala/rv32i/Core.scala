package rv32i

import chisel3._
import chisel3.util._

/** Stage 10: 5-stage pipelined RV32IMF core: IF, ID, EX, MEM, WB. Machine mode only, no interrupts.
  *
  * Stages
  *  - IF : `fetchPc` addresses the instruction memory; the word goes into [[IfId]]. Fetch continues at pc + 4
  *         (static not-taken prediction).
  *  - ID : decode, immediate, x and f register read (with a WB -> ID bypass), load-use hazard detection -> [[IdEx]].
  *  - EX : operand forwarding (x and f, from MEM and WB), ALU, multiplier (1 cycle), sequential divider, sequential
  *         FPU, single-cycle FP unit, branch/jump resolution, CSR read/write (fflags accrue here), exception
  *         detection and trap entry -> [[ExMem]].
  *  - MEM: data memory access and load alignment -> [[MemWb]].
  *  - WB : register write and the retirement trace.
  *
  * Hazards
  *  - RAW data hazards: forwarding into EX from EX/MEM (non-load results) and MEM/WB (all results); a register
  *    written in WB is bypassed to the ID read in the same cycle. A load followed by an instruction that uses its
  *    result (load-use) stalls IF/ID for one cycle and sends a bubble into EX.
  *  - Control: taken branches, JAL, JALR, traps and MRET are resolved in EX; the two younger instructions
  *    (in IF/ID and ID/EX) are flushed and fetch restarts at the target (2-cycle penalty).
  *  - Divider: DIV/DIVU/REM/REMU stay in EX for 34 cycles (2 for divide-by-zero and signed overflow); IF, ID and
  *    EX freeze, MEM and WB keep draining (bubbles).
  *  - FPU: the rounding FP instructions (FADD, FSUB, FMUL, FDIV, FSQRT, FMADD family, FCVT) stay in EX for the FPU
  *    latency + 1 cycles (FpuOp.latency), exactly like a division. FP results are forwarded like integer ones; an
  *    FLW followed by a user of its f register stalls one cycle (load-use), like LW. The rounding mode (static, or
  *    frm for rm = 7) and its legality are decided in EX, where the CSRs are always up to date in program order.
  *
  * Precise exceptions: every exception is known in EX (illegal, ECALL, EBREAK from ID; misaligned addresses and
  * targets from EX). The trap is taken there: older instructions in MEM/WB complete, younger ones are flushed, the
  * trapping instruction does not access memory or write a register. It then travels down the pipe so the trace
  * reports it in WB, in program order. CSRs (including minstret) are read and written in EX, in program order.
  *
  * The trace is produced in WB: one retirement or trap per cycle, or neither (bubble / stall).
  * Memory ports are zero-wait: read data is a combinational function of the address.
  */
class Core(resetPc: Long = 0x80000000L, hartId: Int = 0) extends Module {
  val io = IO(new Bundle {
    val imem  = new InstrMemPort
    val dmem  = new DataMemPort
    val trace = Output(new Trace)
  })

  require(resetPc >= 0 && resetPc < (1L << 32) && resetPc % 4 == 0, "reset pc must be 4-byte aligned")

  val dec  = Module(new Decoder)
  val immg = Module(new ImmGen)
  val rf   = Module(new RegFile)
  val alu  = Module(new Alu)
  val csr  = Module(new CsrFile(hartId))
  val mul  = Module(new Multiplier)
  val div  = Module(new DivUnit(32))
  val fdecId = Module(new FDecoder)   // ID: which registers an F instruction reads and writes (for hazards)
  val fdecEx = Module(new FDecoder)   // EX: legality, rounding mode, operation (with the current frm)
  val frf    = Module(new FRegFile)
  val fpu    = Module(new Fpu)
  val fmisc  = Module(new FpMisc)

  // ---------------- pipeline registers (all empty after reset) ----------------
  val ifid  = RegInit(0.U.asTypeOf(new IfId))
  val idex  = RegInit(0.U.asTypeOf(new IdEx))
  val exmem = RegInit(0.U.asTypeOf(new ExMem))
  val memwb = RegInit(0.U.asTypeOf(new MemWb))

  // =====================================================================================
  // IF
  // =====================================================================================
  val fetchPc = RegInit(resetPc.U(32.W))
  io.imem.addr := fetchPc

  // =====================================================================================
  // ID
  // =====================================================================================
  val idInst   = Mux(ifid.valid, ifid.inst, Core.Nop.U(32.W))
  val idOpcode = idInst(6, 0)
  val idF3     = idInst(14, 12)
  val idMulDiv = idOpcode === Opcode.OP.U && idInst(31, 25) === "b0000001".U
  val rs1      = idInst(19, 15)
  val rs2      = idInst(24, 20)
  val rs3      = idInst(31, 27)

  // F extension in ID: register usage only (frm does not matter here)
  fdecId.io.inst := idInst
  fdecId.io.frm  := 0.U
  val idIsF    = fdecId.io.isF
  val idFLoad  = idIsF && idOpcode === FOpcode.LOAD_FP.U
  val idFStore = idIsF && idOpcode === FOpcode.STORE_FP.U
  val idFma    = idIsF && (idOpcode === FOpcode.MADD.U || idOpcode === FOpcode.MSUB.U ||
                           idOpcode === FOpcode.NMSUB.U || idOpcode === FOpcode.NMADD.U)
  val idF7     = idInst(31, 25)
  val idFBinary = idOpcode === FOpcode.OP_FP.U &&
    Seq("h00", "h04", "h08", "h0c", "h10", "h14", "h50").map(v => idF7 === v.U).reduce(_ || _)
  val idXSrc   = idIsF && (idFLoad || idFStore || fdecId.io.intSrc)      // x[rs1] is read

  dec.io.inst  := idInst
  immg.io.inst := idInst
  immg.io.sel  := Mux(idFStore, ImmSel.S, dec.io.immSel)
  rf.io.rs1    := rs1
  rf.io.rs2    := rs2
  frf.io.rs1   := rs1
  frf.io.rs2   := rs2
  frf.io.rs3   := rs3

  // WB -> ID bypass: the register written in WB this cycle is read with its new value.
  val wbWrites = memwb.valid && !memwb.trap && memwb.regWrite && memwb.rd =/= 0.U
  val rs1Val   = Mux(wbWrites && memwb.rd === rs1, memwb.wdata, rf.io.rd1)
  val rs2Val   = Mux(wbWrites && memwb.rd === rs2, memwb.wdata, rf.io.rd2)
  val fWbWrites = memwb.valid && !memwb.trap && memwb.fWrite
  val frs1Val  = Mux(fWbWrites && memwb.rd === rs1, memwb.wdata, frf.io.rd1)
  val frs2Val  = Mux(fWbWrites && memwb.rd === rs2, memwb.wdata, frf.io.rd2)
  val frs3Val  = Mux(fWbWrites && memwb.rd === rs3, memwb.wdata, frf.io.rd3)

  val idCtrl = Wire(new Ctrl)
  idCtrl.aluSrcA     := dec.io.aluSrcA
  idCtrl.aluSrcImm   := dec.io.aluSrcImm || idFLoad || idFStore     // FLW/FSW address = rs1 + imm
  idCtrl.aluOp       := dec.io.aluOp
  idCtrl.branch      := dec.io.branch
  idCtrl.jal         := dec.io.jal
  idCtrl.jalr        := dec.io.jalr
  idCtrl.memRead     := dec.io.memRead || idFLoad
  idCtrl.memWrite    := dec.io.memWrite || idFStore
  idCtrl.memSize     := Mux(idFLoad || idFStore, 2.U, dec.io.memSize)
  idCtrl.memUnsigned := dec.io.memUnsigned
  idCtrl.wbSel       := dec.io.wbSel
  idCtrl.regWrite    := dec.io.regWrite || idMulDiv || (idIsF && fdecId.io.writesX)
  idCtrl.csr         := dec.io.csr
  idCtrl.ecall       := dec.io.ecall
  idCtrl.ebreak      := dec.io.ebreak
  idCtrl.mret        := dec.io.mret
  // The eight M-extension instructions are legal even though the RV32I decoder flags funct7 = 0000001.
  idCtrl.illegal     := dec.io.illegal && !idMulDiv && !idIsF
  idCtrl.isMul       := idMulDiv && !idF3(2)
  idCtrl.isDiv       := idMulDiv && idF3(2)
  // Which source registers the instruction really reads (no false hazards for LUI, JAL, CSR-immediate, ...).
  idCtrl.usesRs1     := (!idCtrl.illegal && (dec.io.jalr || dec.io.branch || dec.io.memRead || dec.io.memWrite ||
                        idOpcode === Opcode.OP_IMM.U || idOpcode === Opcode.OP.U || (dec.io.csr && !idF3(2)))) || idXSrc
  idCtrl.usesRs2     := !idCtrl.illegal && (dec.io.branch || dec.io.memWrite || idOpcode === Opcode.OP.U)
  idCtrl.isF         := idIsF
  idCtrl.fWrite      := idIsF && fdecId.io.writesF
  idCtrl.usesFrs1    := idIsF && !idXSrc
  idCtrl.usesFrs2    := idFStore || idFma || idFBinary
  idCtrl.usesFrs3    := idFma

  // Load-use hazard: EX holds a load (LB..LHU into x, FLW into f) whose destination is a source of the ID
  // instruction in the same register file.
  val xLoadUse = idex.ctrl.regWrite && idex.rd =/= 0.U &&
    ((idCtrl.usesRs1 && rs1 === idex.rd) || (idCtrl.usesRs2 && rs2 === idex.rd))
  val fLoadUse = idex.ctrl.fWrite &&
    ((idCtrl.usesFrs1 && rs1 === idex.rd) || (idCtrl.usesFrs2 && rs2 === idex.rd) || (idCtrl.usesFrs3 && rs3 === idex.rd))
  val loadUse = ifid.valid && idex.valid && idex.ctrl.memRead && (xLoadUse || fLoadUse)

  // =====================================================================================
  // EX
  // =====================================================================================
  val exValid = idex.valid
  val c       = idex.ctrl
  val exPc    = idex.pc
  val exInst  = idex.inst
  val exF3    = exInst(14, 12)

  // Forwarding: EX/MEM (not for loads: their data is not there yet) has priority over MEM/WB.
  private def forward(idx: UInt, idVal: UInt): UInt = {
    val fromMem = exmem.valid && !exmem.trap && exmem.regWrite && !exmem.memRead && exmem.rd === idx && idx =/= 0.U
    val fromWb  = memwb.valid && !memwb.trap && memwb.regWrite && memwb.rd === idx && idx =/= 0.U
    Mux(fromMem, exmem.result, Mux(fromWb, memwb.wdata, idVal))
  }
  val a = forward(idex.rs1, idex.rs1Val)
  val b = forward(idex.rs2, idex.rs2Val)
  // f operands: the same forwarding paths on the f register file (f0 is an ordinary register)
  private def fforward(idx: UInt, idVal: UInt): UInt = {
    val fromMem = exmem.valid && !exmem.trap && exmem.fWrite && !exmem.memRead && exmem.rd === idx
    val fromWb  = memwb.valid && !memwb.trap && memwb.fWrite && memwb.rd === idx
    Mux(fromMem, exmem.result, Mux(fromWb, memwb.wdata, idVal))
  }
  val fa = fforward(idex.rs1, idex.frs1Val)
  val fb = fforward(idex.rs2, idex.frs2Val)
  val fc = fforward(idex.rs3, idex.frs3Val)

  // ALU
  val aluA = WireDefault(a)
  switch(c.aluSrcA) {
    is(ASrc.RS1)  { aluA := a }
    is(ASrc.PC)   { aluA := exPc }
    is(ASrc.ZERO) { aluA := 0.U }
  }
  alu.io.op := c.aluOp
  alu.io.a  := aluA
  alu.io.b  := Mux(c.aluSrcImm, idex.imm, b)
  val aluY = alu.io.y

  // multiplier (combinational) and divider (sequential)
  mul.io.fn := exF3(1, 0)
  mul.io.a  := a
  mul.io.b  := b
  div.io.req.valid   := exValid && c.isDiv && !div.io.busy
  div.io.req.bits.op := exF3(1, 0)
  div.io.req.bits.a  := a
  div.io.req.bits.b  := b
  val divStall = exValid && c.isDiv && !div.io.resp.valid

  // F extension in EX: legality and rounding mode with the current frm, FPU (sequential), FpMisc (1 cycle)
  fdecEx.io.inst := exInst
  fdecEx.io.frm  := csr.io.frm
  val fOk    = exValid && c.isF && !fdecEx.io.illegal
  val useFpu = fOk && fdecEx.io.useFpu
  fpu.io.req.valid   := useFpu && !fpu.io.busy
  fpu.io.req.bits.op := fdecEx.io.fpuOp
  fpu.io.req.bits.rm := fdecEx.io.rm
  fpu.io.req.bits.a  := Mux(fdecEx.io.intSrc, a, fa)
  fpu.io.req.bits.b  := fb
  fpu.io.req.bits.c  := fc
  val fpuStall = useFpu && !fpu.io.resp.valid
  val exStall  = divStall || fpuStall
  fmisc.io.op     := fdecEx.io.miscOp
  fmisc.io.funct3 := exF3
  fmisc.io.a      := fa
  fmisc.io.b      := fb
  val fXval   = Mux(useFpu, fpu.io.resp.bits.bits, Mux(fdecEx.io.mvXW, fa, fmisc.io.result))   // -> x[rd]
  val fVal    = Mux(useFpu, fpu.io.resp.bits.bits, Mux(fdecEx.io.mvWX, a, fmisc.io.result))    // -> f[rd]
  val fRaised = Mux(fOk, Mux(useFpu, fpu.io.resp.bits.flags, Mux(fdecEx.io.useMisc, fmisc.io.flags, 0.U)), 0.U)

  // branches and jumps
  val eq  = a === b
  val lt  = a.asSInt < b.asSInt
  val ltu = a < b
  val brCond = WireDefault(false.B)
  switch(exF3) {
    is("b000".U) { brCond := eq }
    is("b001".U) { brCond := !eq }
    is("b100".U) { brCond := lt }
    is("b101".U) { brCond := !lt }
    is("b110".U) { brCond := ltu }
    is("b111".U) { brCond := !ltu }
  }
  val pcPlus4    = exPc + 4.U
  val brTarget   = exPc + idex.imm
  val jalrTarget = Cat(aluY(31, 1), 0.U(1.W))
  val ctlTaken   = (c.branch && brCond) || c.jal || c.jalr
  val ctlTarget  = Mux(c.jalr, jalrTarget, brTarget)

  // address checks
  val misalignedAccess = (c.memSize === 2.U && aluY(1, 0) =/= 0.U) || (c.memSize === 1.U && aluY(0))
  val loadMis  = c.memRead && misalignedAccess
  val storeMis = c.memWrite && misalignedAccess
  val fetchMis = ctlTaken && ctlTarget(1)

  // CSRs
  val rs1Field = exInst(19, 15)
  csr.io.addr := exInst(31, 20)
  csr.io.en   := exValid && c.csr
  csr.io.op   := exF3(1, 0)
  csr.io.src  := Mux(exF3(2), Cat(0.U(27.W), rs1Field), a)
  csr.io.wrEn := exF3(1, 0) === 1.U || rs1Field =/= 0.U

  // exceptions (all known here) and commit
  val illegal = c.illegal || (c.isF && fdecEx.io.illegal) || csr.io.illegal
  val trapNow = exValid && (illegal || c.ecall || c.ebreak || loadMis || storeMis || fetchMis)
  div.io.kill := trapNow
  fpu.io.kill := trapNow

  val cause = PriorityMux(Seq(
    illegal    -> Cause.IllegalInstruction.U(4.W),
    c.ecall    -> Cause.EcallFromM.U(4.W),
    c.ebreak   -> Cause.Breakpoint.U(4.W),
    loadMis    -> Cause.LoadAddrMisaligned.U(4.W),
    storeMis   -> Cause.StoreAddrMisaligned.U(4.W),
    fetchMis   -> Cause.InstrAddrMisaligned.U(4.W)
  ))
  val tval = PriorityMux(Seq(
    illegal               -> exInst,
    c.ecall               -> 0.U(32.W),
    c.ebreak              -> exPc,
    (loadMis || storeMis) -> aluY,
    fetchMis              -> ctlTarget
  ))

  // The EX instruction is committed here: nothing after EX can fail.
  val exCommit = exValid && !trapNow && !exStall
  csr.io.commit    := exCommit
  csr.io.fflagsSet := Mux(exCommit, fRaised, 0.U)          // flags accrue in program order, as the instruction commits
  csr.io.trapEnter := trapNow
  csr.io.trapCause := Cat(0.U(28.W), cause)
  csr.io.trapPc    := exPc
  csr.io.trapVal   := tval
  csr.io.mretEnter := exValid && c.mret && !trapNow

  val nextPc = Mux(trapNow, csr.io.mtvecBase,
               Mux(c.mret, csr.io.mepc,
               Mux(ctlTaken, ctlTarget, pcPlus4)))
  val redirect = exValid && !exStall && (trapNow || c.mret || ctlTaken)

  val exResult = WireDefault(aluY)
  switch(c.wbSel) {
    is(WbSel.ALU) { exResult := aluY }
    is(WbSel.PC4) { exResult := pcPlus4 }
    is(WbSel.CSR) { exResult := csr.io.rdata }
    is(WbSel.MEM) { exResult := aluY }        // replaced by the load data in MEM
  }
  when(c.isMul) { exResult := mul.io.result }
  when(c.isDiv) { exResult := div.io.resp.bits }
  when(c.isF && c.regWrite) { exResult := fXval }          // FCVT.W(U).S, FMV.X.W, FEQ/FLT/FLE, FCLASS
  when(c.isF && c.fWrite && !c.memRead) { exResult := fVal } // FPU results, FSGNJ*, FMIN/FMAX, FMV.W.X

  // =====================================================================================
  // pipeline control: IF, ID and EX
  // =====================================================================================
  when(exStall) {
    // freeze IF, IF/ID and ID/EX while the divider or the FPU works on the EX instruction
  }.elsewhen(redirect) {
    fetchPc    := nextPc
    ifid.valid := false.B                       // flush the two wrong-path instructions
    idex.valid := false.B
  }.elsewhen(loadUse) {
    idex.valid := false.B                       // bubble into EX; IF and IF/ID hold
  }.otherwise {
    fetchPc     := fetchPc + 4.U
    ifid.valid  := true.B
    ifid.pc     := fetchPc
    ifid.inst   := io.imem.data
    idex.valid  := ifid.valid
    idex.pc     := ifid.pc
    idex.inst   := idInst
    idex.rs1    := rs1
    idex.rs2    := rs2
    idex.rs3    := rs3
    idex.frs1Val := frs1Val
    idex.frs2Val := frs2Val
    idex.frs3Val := frs3Val
    idex.rd     := idInst(11, 7)
    idex.rs1Val := rs1Val
    idex.rs2Val := rs2Val
    idex.imm    := immg.io.imm
    idex.ctrl   := idCtrl
  }

  // EX -> MEM: a bubble while the divider or the FPU works, otherwise the executed instruction (or its trap)
  exmem.valid := exValid && !exStall
  when(!exStall) {
    exmem.trap        := trapNow
    exmem.cause       := cause
    exmem.pc          := exPc
    exmem.pcNext      := nextPc
    exmem.inst        := exInst
    exmem.rd          := idex.rd
    exmem.regWrite    := c.regWrite && !trapNow
    exmem.fWrite      := c.fWrite && !trapNow
    exmem.fflags      := Mux(trapNow, 0.U, fRaised)
    exmem.result      := exResult
    exmem.memRead     := c.memRead && !trapNow
    exmem.memWrite    := c.memWrite && !trapNow
    exmem.memSize     := c.memSize
    exmem.memUnsigned := c.memUnsigned
    exmem.addr        := aluY
    exmem.storeData   := Mux(c.isF, fb, b)               // FSW stores f[rs2]
  }

  // =====================================================================================
  // MEM
  // =====================================================================================
  val mAddr = exmem.addr
  val size  = exmem.memSize
  io.dmem.addr := mAddr
  io.dmem.re   := exmem.valid && exmem.memRead
  io.dmem.we   := exmem.valid && exmem.memWrite

  val sbyte = exmem.storeData(7, 0)
  val shalf = exmem.storeData(15, 0)
  val wdata = WireDefault(exmem.storeData)
  val wstrb = WireDefault("b1111".U(4.W))
  switch(size) {
    is(0.U) { wdata := Fill(4, sbyte); wstrb := (1.U(4.W) << mAddr(1, 0))(3, 0) }
    is(1.U) { wdata := Fill(2, shalf); wstrb := Mux(mAddr(1), "b1100".U(4.W), "b0011".U(4.W)) }
  }
  io.dmem.wdata := wdata
  io.dmem.wstrb := Mux(io.dmem.we, wstrb, 0.U)

  val rdata = io.dmem.rdata
  val bytes = VecInit(Seq.tabulate(4)(k => rdata(8 * k + 7, 8 * k)))
  val lb    = bytes(mAddr(1, 0))
  val lh    = Mux(mAddr(1), rdata(31, 16), rdata(15, 0))
  val uns   = exmem.memUnsigned
  val loadData = WireDefault(rdata)
  switch(size) {
    is(0.U) { loadData := Mux(uns, Cat(0.U(24.W), lb), Cat(Fill(24, lb(7)), lb)) }
    is(1.U) { loadData := Mux(uns, Cat(0.U(16.W), lh), Cat(Fill(16, lh(15)), lh)) }
  }

  memwb.valid    := exmem.valid
  memwb.trap     := exmem.trap
  memwb.cause    := exmem.cause
  memwb.pc       := exmem.pc
  memwb.pcNext   := exmem.pcNext
  memwb.inst     := exmem.inst
  memwb.rd       := exmem.rd
  memwb.regWrite := exmem.regWrite
  memwb.fWrite   := exmem.fWrite
  memwb.fflags   := exmem.fflags
  memwb.wdata    := Mux(exmem.memRead, loadData, exmem.result)
  memwb.memRe    := io.dmem.re
  memwb.memWe    := io.dmem.we
  memwb.memAddr  := mAddr
  memwb.memSize  := size
  memwb.memWdata := Mux(size === 0.U, Cat(0.U(24.W), sbyte), Mux(size === 1.U, Cat(0.U(16.W), shalf), exmem.storeData))

  // =====================================================================================
  // WB
  // =====================================================================================
  rf.io.we    := memwb.valid && !memwb.trap && memwb.regWrite
  rf.io.waddr := memwb.rd
  rf.io.wdata := memwb.wdata
  frf.io.we    := fWbWrites
  frf.io.waddr := memwb.rd
  frf.io.wdata := memwb.wdata

  io.trace.valid    := memwb.valid && !memwb.trap
  io.trace.trap     := memwb.valid && memwb.trap
  io.trace.cause    := memwb.cause
  io.trace.pc       := memwb.pc
  io.trace.pcNext   := memwb.pcNext
  io.trace.inst     := memwb.inst
  io.trace.rdAddr   := Mux(wbWrites, memwb.rd, 0.U)
  io.trace.rdData   := Mux(wbWrites, memwb.wdata, 0.U)
  io.trace.memAddr  := memwb.memAddr
  io.trace.memRe    := memwb.valid && memwb.memRe
  io.trace.memWe    := memwb.valid && memwb.memWe
  io.trace.memSize  := memwb.memSize
  io.trace.memWdata := memwb.memWdata
  io.trace.fdWe     := fWbWrites
  io.trace.fdAddr   := Mux(fWbWrites, memwb.rd, 0.U)
  io.trace.fdData   := Mux(fWbWrites, memwb.wdata, 0.U)
  io.trace.fflags   := Mux(memwb.valid && !memwb.trap, memwb.fflags, 0.U)

  // =====================================================================================
  // assertions (compiled out of synthesis builds)
  // =====================================================================================
  assert(fetchPc(1, 0) === 0.U, "fetch pc must stay 4-byte aligned")
  assert(!(io.dmem.we && io.dmem.re), "simultaneous load and store")
  assert(!(exmem.valid && exmem.trap && (exmem.memRead || exmem.memWrite || exmem.regWrite || exmem.fWrite)),
    "trapping instruction accesses memory or writes a register")
  assert(!(exValid && exmem.valid && exmem.memRead && exmem.regWrite && exmem.rd =/= 0.U &&
    ((c.usesRs1 && idex.rs1 === exmem.rd) || (c.usesRs2 && idex.rs2 === exmem.rd))),
    "load-use hazard reached EX (missing stall)")
  assert(!(exValid && exmem.valid && exmem.memRead && exmem.fWrite &&
    ((c.usesFrs1 && idex.rs1 === exmem.rd) || (c.usesFrs2 && idex.rs2 === exmem.rd) || (c.usesFrs3 && idex.rs3 === exmem.rd))),
    "FLW load-use hazard reached EX (missing stall)")
  assert(!(exStall && trapNow), "a division or an FPU operation cannot trap")
  assert(!(csr.io.commit && !exValid), "bubble committed")
}

object Core {
  /** `addi x0, x0, 0`: what ID decodes when IF/ID holds a bubble. */
  val Nop = 0x00000013L
  /** Cycles from EX to WB: an instruction executed in EX in cycle t is reported in the trace in cycle t + 2. */
  val ExToWb = 2
  /** Empty cycles before the first instruction reaches WB after reset. */
  val FillCycles = 4
}
