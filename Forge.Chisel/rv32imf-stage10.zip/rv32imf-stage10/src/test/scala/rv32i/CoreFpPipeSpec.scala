package rv32i

import chisel3._
import chiseltest._
import org.scalatest.flatspec.AnyFlatSpec
import org.scalatest.matchers.should.Matchers

/** Floating point in the 5-stage pipeline: forwarding of f results, FLW load-use stalls, the FPU stall, and the
  * program order of fcsr accesses (frm and fflags are read and written in EX). Every run is in lockstep with RefModel,
  * so the values are checked on every retirement; these tests add the exact cycle counts. */
class CoreFpPipeSpec extends AnyFlatSpec with ChiselScalatestTester with Matchers {
  private val Data = 0x80010000L
  private def run(a: Asm) = {
    var res: CoreSim.Result = null
    test(new Core()).withAnnotations(TestUtil.waves) { c => res = CoreSim.run(c, a.words) }
    res
  }

  "The pipeline" should "forward f results at distance 1, 2 and 3 and between the x and f files without stalls" in {
    val a = new Asm
    a.fli(1, 1.5f, 5); a.fli(2, -2.0f, 5)          // fmv.w.x right after li: x forwarding into an F instruction
    a.fsgnjn(3, 1, 1)                               // f3 = -1.5
    a.fmin(4, 3, 2)                                 // f3 at distance 1 (EX/MEM): -2.0
    a.fmax(5, 3, 4)                                 // f3 at distance 2 (MEM/WB), f4 at distance 1: -1.5
    a.fsgnjx(6, 5, 3)                               // f3 at distance 3 (WB -> ID bypass): +1.5
    a.fadd(7, 6, 6)                                 // a single-cycle result into the FPU: 3.0
    a.fmul(8, 7, 7)                                 // FPU result at distance 1: 9.0
    a.feq(10, 8, 8)                                 // f -> x: 1
    a.beq(10, 0, "skip")                            // x result of an F instruction into a branch (not taken)
    a.fmvxw(11, 2); a.add(12, 11, 11)               // FMV.X.W into the ALU
    a.li(13, 3); a.fcvtsw(9, 13)                    // x into the FPU
    a.label("skip")
    a.halt()
    val res = run(a)
    res.model.f(5) shouldBe 0xbfc00000L
    res.model.f(6) shouldBe 0x3fc00000L
    res.model.x(10) shouldBe 1
    res.model.f(9) shouldBe 0x40400000L
    res.model.f(8) shouldBe 0x41100000L
    // only the pipeline fill and the two FPU operations cost cycles
    res.stallCycles shouldBe (Core.FillCycles + FpuOp.latency(FpuOp.ADD) + FpuOp.latency(FpuOp.MUL) + FpuOp.latency(FpuOp.CVT_S_W))
  }

  it should "stall one cycle for an FLW followed by a user of its value (rs1, rs2, rs3, store data) and for LW -> FMV.W.X" in {
    val a = new Asm
    a.li(10, Data); a.fli(1, 2.5f, 5); a.fsw(1, 0, 10)
    a.flw(2, 0, 10); a.fadd(3, 2, 2)                // rs1 (and rs2): 1 stall
    a.flw(4, 0, 10); a.fsgnj(5, 1, 4)               // rs2: 1 stall
    a.flw(6, 0, 10); a.fmadd(7, 1, 1, 6)            // rs3: 1 stall
    a.flw(8, 0, 10); a.fsw(8, 4, 10)                // FSW data: 1 stall
    a.lw(11, 4, 10); a.fmvwx(9, 11)                 // x load, F instruction reading x: 1 stall
    a.flw(12, 0, 10); a.nop(); a.fadd(13, 12, 12)   // distance 2: no stall
    a.flw(14, 0, 10); a.fadd(15, 1, 1)              // FLW into f14, unrelated f sources: no stall
    a.flw(16, 0, 10); a.addi(17, 16, 1)             // f16 is not x16: no stall
    a.halt()
    val res = run(a)
    res.model.f(9) shouldBe 0x40200000L
    res.model.f(7) shouldBe 0x410c0000L             // 2.5 * 2.5 + 2.5 = 8.75
    // fill, 5 load-use stalls, and the FPU: three FADD.S and one FMADD.S
    res.stallCycles shouldBe (Core.FillCycles + 5 * 1 + 3 * FpuOp.latency(FpuOp.ADD) + FpuOp.latency(FpuOp.MADD))
  }

  it should "apply a frm write to the very next FP instruction and show its flags to the very next fflags read" in {
    val a = new Asm
    a.la(6, "handler"); a.csrrw(0, CsrAddr.mtvec, 6)
    a.fli(1, 1.0f, 5); a.fli(2, 3.0f, 5)
    a.csrrwi(0, CsrAddr.frm, Rm.RTZ); a.fdiv(3, 1, 2)          // dynamic: RTZ -> 0x3eaaaaaa
    a.csrrs(10, CsrAddr.fflags, 0)                             // NX of the division, right behind it
    a.csrrwi(0, CsrAddr.frm, Rm.RUP); a.fdiv(4, 1, 2)          // dynamic: RUP -> 0x3eaaaaab
    a.csrrwi(0, CsrAddr.fflags, 0); a.fadd(5, 1, 1); a.csrrs(11, CsrAddr.fflags, 0)  // exact: 0
    a.fdiv(7, 1, 0); a.csrrs(12, CsrAddr.fflags, 0)            // DZ = 8
    a.csrrwi(0, CsrAddr.frm, 5); a.fadd(8, 1, 1)               // frm = 5 just before: illegal instruction
    a.csrrwi(0, CsrAddr.frm, 0); a.fadd(9, 1, 1)               // legal again
    a.halt()
    a.label("handler")
    a.csrrs(13, CsrAddr.mepc, 0); a.addi(13, 13, 4); a.csrrw(0, CsrAddr.mepc, 13); a.mret()
    val res = run(a)
    res.model.f(3) shouldBe 0x3eaaaaaaL
    res.model.f(4) shouldBe 0x3eaaaaabL
    res.model.x(10) shouldBe FFlags.NX
    res.model.x(11) shouldBe 0
    res.model.x(12) shouldBe FFlags.DZ
    res.traps shouldBe 1
    res.model.f(8) shouldBe 0
    res.model.f(9) shouldBe 0x40000000L
  }

  it should "flush the wrong-path F instructions behind a taken branch: no FPU start, no f write, no flags" in {
    val a = new Asm
    a.fli(1, 1.0f, 5)
    a.beq(0, 0, "over")
    a.fdiv(2, 1, 0)                                            // wrong path: would raise DZ
    a.fsqrt(3, 1)
    a.label("over")
    a.csrrs(10, CsrAddr.fflags, 0)
    a.halt()
    val res = run(a)
    res.model.x(10) shouldBe 0
    res.model.f(2) shouldBe 0
    res.stallCycles shouldBe (Core.FillCycles + 2)            // fill + the 2 bubbles of the taken branch
  }
}
