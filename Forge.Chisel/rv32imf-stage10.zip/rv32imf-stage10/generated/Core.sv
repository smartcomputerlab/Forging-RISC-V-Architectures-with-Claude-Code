module Decoder(
  input  [31:0] io_inst, // @[src/main/scala/rv32i/Decoder.scala 15:14]
  output [2:0]  io_immSel, // @[src/main/scala/rv32i/Decoder.scala 15:14]
  output [1:0]  io_aluSrcA, // @[src/main/scala/rv32i/Decoder.scala 15:14]
  output        io_aluSrcImm, // @[src/main/scala/rv32i/Decoder.scala 15:14]
  output [3:0]  io_aluOp, // @[src/main/scala/rv32i/Decoder.scala 15:14]
  output        io_branch, // @[src/main/scala/rv32i/Decoder.scala 15:14]
  output        io_jal, // @[src/main/scala/rv32i/Decoder.scala 15:14]
  output        io_jalr, // @[src/main/scala/rv32i/Decoder.scala 15:14]
  output        io_memRead, // @[src/main/scala/rv32i/Decoder.scala 15:14]
  output        io_memWrite, // @[src/main/scala/rv32i/Decoder.scala 15:14]
  output [1:0]  io_memSize, // @[src/main/scala/rv32i/Decoder.scala 15:14]
  output        io_memUnsigned, // @[src/main/scala/rv32i/Decoder.scala 15:14]
  output [1:0]  io_wbSel, // @[src/main/scala/rv32i/Decoder.scala 15:14]
  output        io_regWrite, // @[src/main/scala/rv32i/Decoder.scala 15:14]
  output        io_csr, // @[src/main/scala/rv32i/Decoder.scala 15:14]
  output        io_ecall, // @[src/main/scala/rv32i/Decoder.scala 15:14]
  output        io_ebreak, // @[src/main/scala/rv32i/Decoder.scala 15:14]
  output        io_mret, // @[src/main/scala/rv32i/Decoder.scala 15:14]
  output        io_illegal // @[src/main/scala/rv32i/Decoder.scala 15:14]
);
  wire [6:0] opcode = io_inst[6:0]; // @[src/main/scala/rv32i/Decoder.scala 41:20]
  wire [2:0] f3 = io_inst[14:12]; // @[src/main/scala/rv32i/Decoder.scala 42:20]
  wire [6:0] f7 = io_inst[31:25]; // @[src/main/scala/rv32i/Decoder.scala 43:20]
  wire  _T_4 = f3 == 3'h0; // @[src/main/scala/rv32i/Decoder.scala 107:15]
  wire  _GEN_0 = f3 == 3'h0 ? 1'h0 : 1'h1; // @[src/main/scala/rv32i/Decoder.scala 107:24 108:22 66:18]
  wire [1:0] _GEN_2 = f3 == 3'h0 ? 2'h2 : 2'h0; // @[src/main/scala/rv32i/Decoder.scala 107:24 111:22 60:18]
  wire  _T_8 = f3 != 3'h2 & f3 != 3'h3; // @[src/main/scala/rv32i/Decoder.scala 116:23]
  wire  _GEN_3 = f3 != 3'h2 & f3 != 3'h3 ? 1'h0 : 1'h1; // @[src/main/scala/rv32i/Decoder.scala 116:38 117:20 66:18]
  wire [1:0] _GEN_5 = f3 != 3'h2 & f3 != 3'h3 ? 2'h2 : 2'h0; // @[src/main/scala/rv32i/Decoder.scala 116:38 119:20 49:18]
  wire  _T_11 = f3 == 3'h1; // @[src/main/scala/rv32i/Decoder.scala 123:29]
  wire  _T_14 = _T_4 | f3 == 3'h1 | f3 == 3'h2; // @[src/main/scala/rv32i/Decoder.scala 123:37]
  wire  _T_17 = f3 == 3'h5; // @[src/main/scala/rv32i/Decoder.scala 123:71]
  wire  _T_18 = _T_4 | f3 == 3'h1 | f3 == 3'h2 | f3 == 3'h4 | f3 == 3'h5; // @[src/main/scala/rv32i/Decoder.scala 123:65]
  wire  _GEN_6 = _T_4 | f3 == 3'h1 | f3 == 3'h2 | f3 == 3'h4 | f3 == 3'h5 ? 1'h0 : 1'h1; // @[src/main/scala/rv32i/Decoder.scala 123:80 124:22 66:18]
  wire  _GEN_8 = _T_14 ? 1'h0 : 1'h1; // @[src/main/scala/rv32i/Decoder.scala 132:52 133:22 66:18]
  wire  _shiftOk_T_1 = f7 == 7'h0; // @[src/main/scala/rv32i/Decoder.scala 140:40]
  wire  _shiftOk_T_4 = f7 == 7'h20; // @[src/main/scala/rv32i/Decoder.scala 140:82]
  wire  _shiftOk_T_6 = _T_17 ? f7 == 7'h0 | f7 == 7'h20 : 1'h1; // @[src/main/scala/rv32i/Decoder.scala 140:52]
  wire  shiftOk = _T_11 ? f7 == 7'h0 : _shiftOk_T_6; // @[src/main/scala/rv32i/Decoder.scala 140:24]
  wire  _io_aluOp_T_2 = _T_17 & f7[5]; // @[src/main/scala/rv32i/Decoder.scala 145:43]
  wire [2:0] _io_aluOp_op_T_1 = _io_aluOp_T_2 ? 3'h7 : 3'h6; // @[src/main/scala/rv32i/Decoder.scala 77:26]
  wire [3:0] _GEN_10 = 3'h7 == f3 ? 4'h9 : 4'h0; // @[src/main/scala/rv32i/Decoder.scala 71:16 79:20 70:25]
  wire [3:0] _GEN_11 = 3'h6 == f3 ? 4'h8 : _GEN_10; // @[src/main/scala/rv32i/Decoder.scala 71:16 78:20]
  wire [3:0] _GEN_12 = 3'h5 == f3 ? {{1'd0}, _io_aluOp_op_T_1} : _GEN_11; // @[src/main/scala/rv32i/Decoder.scala 71:16 77:20]
  wire [3:0] _GEN_13 = 3'h4 == f3 ? 4'h5 : _GEN_12; // @[src/main/scala/rv32i/Decoder.scala 71:16 76:20]
  wire [3:0] _GEN_14 = 3'h3 == f3 ? 4'h4 : _GEN_13; // @[src/main/scala/rv32i/Decoder.scala 71:16 75:20]
  wire [3:0] _GEN_15 = 3'h2 == f3 ? 4'h3 : _GEN_14; // @[src/main/scala/rv32i/Decoder.scala 71:16 74:20]
  wire [3:0] _GEN_16 = 3'h1 == f3 ? 4'h2 : _GEN_15; // @[src/main/scala/rv32i/Decoder.scala 71:16 73:20]
  wire [3:0] io_aluOp_op = 3'h0 == f3 ? {{3'd0}, _io_aluOp_T_2} : _GEN_16; // @[src/main/scala/rv32i/Decoder.scala 71:16 72:20]
  wire  _GEN_18 = shiftOk ? 1'h0 : 1'h1; // @[src/main/scala/rv32i/Decoder.scala 141:21 142:22 66:18]
  wire [3:0] _GEN_20 = shiftOk ? io_aluOp_op : 4'h0; // @[src/main/scala/rv32i/Decoder.scala 141:21 145:22 52:18]
  wire  altOk = _shiftOk_T_4 & (_T_4 | _T_17); // @[src/main/scala/rv32i/Decoder.scala 149:39]
  wire  _T_28 = _shiftOk_T_1 | altOk; // @[src/main/scala/rv32i/Decoder.scala 150:23]
  wire [2:0] _io_aluOp_op_T_3 = f7[5] ? 3'h7 : 3'h6; // @[src/main/scala/rv32i/Decoder.scala 77:26]
  wire [3:0] _GEN_23 = 3'h5 == f3 ? {{1'd0}, _io_aluOp_op_T_3} : _GEN_11; // @[src/main/scala/rv32i/Decoder.scala 71:16 77:20]
  wire [3:0] _GEN_24 = 3'h4 == f3 ? 4'h5 : _GEN_23; // @[src/main/scala/rv32i/Decoder.scala 71:16 76:20]
  wire [3:0] _GEN_25 = 3'h3 == f3 ? 4'h4 : _GEN_24; // @[src/main/scala/rv32i/Decoder.scala 71:16 75:20]
  wire [3:0] _GEN_26 = 3'h2 == f3 ? 4'h3 : _GEN_25; // @[src/main/scala/rv32i/Decoder.scala 71:16 74:20]
  wire [3:0] _GEN_27 = 3'h1 == f3 ? 4'h2 : _GEN_26; // @[src/main/scala/rv32i/Decoder.scala 71:16 73:20]
  wire [3:0] io_aluOp_op_1 = 3'h0 == f3 ? {{3'd0}, f7[5]} : _GEN_27; // @[src/main/scala/rv32i/Decoder.scala 71:16 72:20]
  wire  _GEN_29 = _shiftOk_T_1 | altOk ? 1'h0 : 1'h1; // @[src/main/scala/rv32i/Decoder.scala 150:33 151:21 66:18]
  wire [3:0] _GEN_31 = _shiftOk_T_1 | altOk ? io_aluOp_op_1 : 4'h0; // @[src/main/scala/rv32i/Decoder.scala 150:33 153:21 52:18]
  wire  _T_33 = io_inst == 32'h73; // @[src/main/scala/rv32i/Decoder.scala 161:19]
  wire  _GEN_33 = io_inst == 32'h73 ? 1'h0 : 1'h1; // @[src/main/scala/rv32i/Decoder.scala 161:{38,51} 66:18]
  wire  _T_34 = io_inst == 32'h100073; // @[src/main/scala/rv32i/Decoder.scala 162:19]
  wire  _GEN_35 = io_inst == 32'h100073 ? 1'h0 : _GEN_33; // @[src/main/scala/rv32i/Decoder.scala 162:{38,51}]
  wire  _T_35 = io_inst == 32'h30200073; // @[src/main/scala/rv32i/Decoder.scala 163:19]
  wire  _GEN_37 = io_inst == 32'h30200073 ? 1'h0 : _GEN_35; // @[src/main/scala/rv32i/Decoder.scala 163:{38,51}]
  wire  _GEN_39 = io_inst == 32'h10500073 ? 1'h0 : _GEN_37; // @[src/main/scala/rv32i/Decoder.scala 164:{38,51}]
  wire  _T_37 = f3 != 3'h4; // @[src/main/scala/rv32i/Decoder.scala 165:21]
  wire  _GEN_40 = f3 != 3'h4 ? 1'h0 : 1'h1; // @[src/main/scala/rv32i/Decoder.scala 165:30 166:21 66:18]
  wire [1:0] _GEN_42 = f3 != 3'h4 ? 2'h3 : 2'h0; // @[src/main/scala/rv32i/Decoder.scala 165:30 169:21 60:18]
  wire  _GEN_43 = _T_4 ? _GEN_39 : _GEN_40; // @[src/main/scala/rv32i/Decoder.scala 160:24]
  wire  _GEN_44 = _T_4 & _T_33; // @[src/main/scala/rv32i/Decoder.scala 160:24 63:18]
  wire  _GEN_45 = _T_4 & _T_34; // @[src/main/scala/rv32i/Decoder.scala 160:24 64:18]
  wire  _GEN_46 = _T_4 & _T_35; // @[src/main/scala/rv32i/Decoder.scala 160:24 65:18]
  wire  _GEN_47 = _T_4 ? 1'h0 : _T_37; // @[src/main/scala/rv32i/Decoder.scala 160:24 62:18]
  wire [1:0] _GEN_48 = _T_4 ? 2'h0 : _GEN_42; // @[src/main/scala/rv32i/Decoder.scala 160:24 60:18]
  wire  _GEN_49 = 7'h73 == opcode ? _GEN_43 : 1'h1; // @[src/main/scala/rv32i/Decoder.scala 66:18 84:18]
  wire [1:0] _GEN_54 = 7'h73 == opcode ? _GEN_48 : 2'h0; // @[src/main/scala/rv32i/Decoder.scala 60:18 84:18]
  wire  _GEN_55 = 7'hf == opcode ? _GEN_0 : _GEN_49; // @[src/main/scala/rv32i/Decoder.scala 84:18]
  wire  _GEN_56 = 7'hf == opcode ? 1'h0 : 7'h73 == opcode & _GEN_44; // @[src/main/scala/rv32i/Decoder.scala 63:18 84:18]
  wire  _GEN_57 = 7'hf == opcode ? 1'h0 : 7'h73 == opcode & _GEN_45; // @[src/main/scala/rv32i/Decoder.scala 64:18 84:18]
  wire  _GEN_58 = 7'hf == opcode ? 1'h0 : 7'h73 == opcode & _GEN_46; // @[src/main/scala/rv32i/Decoder.scala 65:18 84:18]
  wire  _GEN_59 = 7'hf == opcode ? 1'h0 : 7'h73 == opcode & _GEN_47; // @[src/main/scala/rv32i/Decoder.scala 62:18 84:18]
  wire [1:0] _GEN_60 = 7'hf == opcode ? 2'h0 : _GEN_54; // @[src/main/scala/rv32i/Decoder.scala 60:18 84:18]
  wire  _GEN_61 = 7'h33 == opcode ? _GEN_29 : _GEN_55; // @[src/main/scala/rv32i/Decoder.scala 84:18]
  wire  _GEN_62 = 7'h33 == opcode ? _T_28 : _GEN_59; // @[src/main/scala/rv32i/Decoder.scala 84:18]
  wire [3:0] _GEN_63 = 7'h33 == opcode ? _GEN_31 : 4'h0; // @[src/main/scala/rv32i/Decoder.scala 52:18 84:18]
  wire  _GEN_64 = 7'h33 == opcode ? 1'h0 : _GEN_56; // @[src/main/scala/rv32i/Decoder.scala 63:18 84:18]
  wire  _GEN_65 = 7'h33 == opcode ? 1'h0 : _GEN_57; // @[src/main/scala/rv32i/Decoder.scala 64:18 84:18]
  wire  _GEN_66 = 7'h33 == opcode ? 1'h0 : _GEN_58; // @[src/main/scala/rv32i/Decoder.scala 65:18 84:18]
  wire  _GEN_67 = 7'h33 == opcode ? 1'h0 : _GEN_59; // @[src/main/scala/rv32i/Decoder.scala 62:18 84:18]
  wire [1:0] _GEN_68 = 7'h33 == opcode ? 2'h0 : _GEN_60; // @[src/main/scala/rv32i/Decoder.scala 60:18 84:18]
  wire  _GEN_69 = 7'h13 == opcode ? _GEN_18 : _GEN_61; // @[src/main/scala/rv32i/Decoder.scala 84:18]
  wire  _GEN_70 = 7'h13 == opcode ? shiftOk : _GEN_62; // @[src/main/scala/rv32i/Decoder.scala 84:18]
  wire  _GEN_71 = 7'h13 == opcode & shiftOk; // @[src/main/scala/rv32i/Decoder.scala 51:18 84:18]
  wire [3:0] _GEN_72 = 7'h13 == opcode ? _GEN_20 : _GEN_63; // @[src/main/scala/rv32i/Decoder.scala 84:18]
  wire  _GEN_73 = 7'h13 == opcode ? 1'h0 : _GEN_64; // @[src/main/scala/rv32i/Decoder.scala 63:18 84:18]
  wire  _GEN_74 = 7'h13 == opcode ? 1'h0 : _GEN_65; // @[src/main/scala/rv32i/Decoder.scala 64:18 84:18]
  wire  _GEN_75 = 7'h13 == opcode ? 1'h0 : _GEN_66; // @[src/main/scala/rv32i/Decoder.scala 65:18 84:18]
  wire  _GEN_76 = 7'h13 == opcode ? 1'h0 : _GEN_67; // @[src/main/scala/rv32i/Decoder.scala 62:18 84:18]
  wire [1:0] _GEN_77 = 7'h13 == opcode ? 2'h0 : _GEN_68; // @[src/main/scala/rv32i/Decoder.scala 60:18 84:18]
  wire  _GEN_78 = 7'h23 == opcode ? _GEN_8 : _GEN_69; // @[src/main/scala/rv32i/Decoder.scala 84:18]
  wire  _GEN_80 = 7'h23 == opcode ? _T_14 : _GEN_71; // @[src/main/scala/rv32i/Decoder.scala 84:18]
  wire  _GEN_81 = 7'h23 == opcode ? 1'h0 : _GEN_70; // @[src/main/scala/rv32i/Decoder.scala 61:18 84:18]
  wire [3:0] _GEN_82 = 7'h23 == opcode ? 4'h0 : _GEN_72; // @[src/main/scala/rv32i/Decoder.scala 52:18 84:18]
  wire  _GEN_83 = 7'h23 == opcode ? 1'h0 : _GEN_73; // @[src/main/scala/rv32i/Decoder.scala 63:18 84:18]
  wire  _GEN_84 = 7'h23 == opcode ? 1'h0 : _GEN_74; // @[src/main/scala/rv32i/Decoder.scala 64:18 84:18]
  wire  _GEN_85 = 7'h23 == opcode ? 1'h0 : _GEN_75; // @[src/main/scala/rv32i/Decoder.scala 65:18 84:18]
  wire  _GEN_86 = 7'h23 == opcode ? 1'h0 : _GEN_76; // @[src/main/scala/rv32i/Decoder.scala 62:18 84:18]
  wire [1:0] _GEN_87 = 7'h23 == opcode ? 2'h0 : _GEN_77; // @[src/main/scala/rv32i/Decoder.scala 60:18 84:18]
  wire  _GEN_88 = 7'h3 == opcode ? _GEN_6 : _GEN_78; // @[src/main/scala/rv32i/Decoder.scala 84:18]
  wire  _GEN_90 = 7'h3 == opcode ? _T_18 : _GEN_81; // @[src/main/scala/rv32i/Decoder.scala 84:18]
  wire [1:0] _GEN_91 = 7'h3 == opcode ? {{1'd0}, _T_18} : _GEN_87; // @[src/main/scala/rv32i/Decoder.scala 84:18]
  wire  _GEN_92 = 7'h3 == opcode ? _T_18 : _GEN_80; // @[src/main/scala/rv32i/Decoder.scala 84:18]
  wire  _GEN_93 = 7'h3 == opcode ? 1'h0 : 7'h23 == opcode & _T_14; // @[src/main/scala/rv32i/Decoder.scala 57:18 84:18]
  wire [3:0] _GEN_94 = 7'h3 == opcode ? 4'h0 : _GEN_82; // @[src/main/scala/rv32i/Decoder.scala 52:18 84:18]
  wire  _GEN_95 = 7'h3 == opcode ? 1'h0 : _GEN_83; // @[src/main/scala/rv32i/Decoder.scala 63:18 84:18]
  wire  _GEN_96 = 7'h3 == opcode ? 1'h0 : _GEN_84; // @[src/main/scala/rv32i/Decoder.scala 64:18 84:18]
  wire  _GEN_97 = 7'h3 == opcode ? 1'h0 : _GEN_85; // @[src/main/scala/rv32i/Decoder.scala 65:18 84:18]
  wire  _GEN_98 = 7'h3 == opcode ? 1'h0 : _GEN_86; // @[src/main/scala/rv32i/Decoder.scala 62:18 84:18]
  wire  _GEN_99 = 7'h63 == opcode ? _GEN_3 : _GEN_88; // @[src/main/scala/rv32i/Decoder.scala 84:18]
  wire [1:0] _GEN_101 = 7'h63 == opcode ? _GEN_5 : {{1'd0}, _GEN_93}; // @[src/main/scala/rv32i/Decoder.scala 84:18]
  wire  _GEN_102 = 7'h63 == opcode ? 1'h0 : 7'h3 == opcode & _T_18; // @[src/main/scala/rv32i/Decoder.scala 56:18 84:18]
  wire  _GEN_103 = 7'h63 == opcode ? 1'h0 : _GEN_90; // @[src/main/scala/rv32i/Decoder.scala 61:18 84:18]
  wire [1:0] _GEN_104 = 7'h63 == opcode ? 2'h0 : _GEN_91; // @[src/main/scala/rv32i/Decoder.scala 60:18 84:18]
  wire  _GEN_105 = 7'h63 == opcode ? 1'h0 : _GEN_92; // @[src/main/scala/rv32i/Decoder.scala 51:18 84:18]
  wire  _GEN_106 = 7'h63 == opcode ? 1'h0 : _GEN_93; // @[src/main/scala/rv32i/Decoder.scala 57:18 84:18]
  wire [3:0] _GEN_107 = 7'h63 == opcode ? 4'h0 : _GEN_94; // @[src/main/scala/rv32i/Decoder.scala 52:18 84:18]
  wire  _GEN_108 = 7'h63 == opcode ? 1'h0 : _GEN_95; // @[src/main/scala/rv32i/Decoder.scala 63:18 84:18]
  wire  _GEN_109 = 7'h63 == opcode ? 1'h0 : _GEN_96; // @[src/main/scala/rv32i/Decoder.scala 64:18 84:18]
  wire  _GEN_110 = 7'h63 == opcode ? 1'h0 : _GEN_97; // @[src/main/scala/rv32i/Decoder.scala 65:18 84:18]
  wire  _GEN_111 = 7'h63 == opcode ? 1'h0 : _GEN_98; // @[src/main/scala/rv32i/Decoder.scala 62:18 84:18]
  wire  _GEN_112 = 7'h67 == opcode ? _GEN_0 : _GEN_99; // @[src/main/scala/rv32i/Decoder.scala 84:18]
  wire  _GEN_114 = 7'h67 == opcode ? _T_4 : _GEN_103; // @[src/main/scala/rv32i/Decoder.scala 84:18]
  wire [1:0] _GEN_115 = 7'h67 == opcode ? _GEN_2 : _GEN_104; // @[src/main/scala/rv32i/Decoder.scala 84:18]
  wire  _GEN_116 = 7'h67 == opcode ? _T_4 : _GEN_105; // @[src/main/scala/rv32i/Decoder.scala 84:18]
  wire  _GEN_117 = 7'h67 == opcode ? 1'h0 : 7'h63 == opcode & _T_8; // @[src/main/scala/rv32i/Decoder.scala 53:18 84:18]
  wire [1:0] _GEN_118 = 7'h67 == opcode ? 2'h0 : _GEN_101; // @[src/main/scala/rv32i/Decoder.scala 49:18 84:18]
  wire  _GEN_119 = 7'h67 == opcode ? 1'h0 : _GEN_102; // @[src/main/scala/rv32i/Decoder.scala 56:18 84:18]
  wire  _GEN_120 = 7'h67 == opcode ? 1'h0 : _GEN_106; // @[src/main/scala/rv32i/Decoder.scala 57:18 84:18]
  wire [3:0] _GEN_121 = 7'h67 == opcode ? 4'h0 : _GEN_107; // @[src/main/scala/rv32i/Decoder.scala 52:18 84:18]
  wire  _GEN_122 = 7'h67 == opcode ? 1'h0 : _GEN_108; // @[src/main/scala/rv32i/Decoder.scala 63:18 84:18]
  wire  _GEN_123 = 7'h67 == opcode ? 1'h0 : _GEN_109; // @[src/main/scala/rv32i/Decoder.scala 64:18 84:18]
  wire  _GEN_124 = 7'h67 == opcode ? 1'h0 : _GEN_110; // @[src/main/scala/rv32i/Decoder.scala 65:18 84:18]
  wire  _GEN_125 = 7'h67 == opcode ? 1'h0 : _GEN_111; // @[src/main/scala/rv32i/Decoder.scala 62:18 84:18]
  wire  _GEN_126 = 7'h6f == opcode ? 1'h0 : _GEN_112; // @[src/main/scala/rv32i/Decoder.scala 84:18 100:19]
  wire  _GEN_128 = 7'h6f == opcode | _GEN_114; // @[src/main/scala/rv32i/Decoder.scala 84:18 102:19]
  wire [1:0] _GEN_129 = 7'h6f == opcode ? 2'h2 : _GEN_115; // @[src/main/scala/rv32i/Decoder.scala 84:18 103:19]
  wire [2:0] _GEN_130 = 7'h6f == opcode ? 3'h4 : {{1'd0}, _GEN_118}; // @[src/main/scala/rv32i/Decoder.scala 84:18 104:19]
  wire  _GEN_131 = 7'h6f == opcode ? 1'h0 : 7'h67 == opcode & _T_4; // @[src/main/scala/rv32i/Decoder.scala 55:18 84:18]
  wire  _GEN_132 = 7'h6f == opcode ? 1'h0 : _GEN_116; // @[src/main/scala/rv32i/Decoder.scala 51:18 84:18]
  wire  _GEN_133 = 7'h6f == opcode ? 1'h0 : _GEN_117; // @[src/main/scala/rv32i/Decoder.scala 53:18 84:18]
  wire  _GEN_134 = 7'h6f == opcode ? 1'h0 : _GEN_119; // @[src/main/scala/rv32i/Decoder.scala 56:18 84:18]
  wire  _GEN_135 = 7'h6f == opcode ? 1'h0 : _GEN_120; // @[src/main/scala/rv32i/Decoder.scala 57:18 84:18]
  wire [3:0] _GEN_136 = 7'h6f == opcode ? 4'h0 : _GEN_121; // @[src/main/scala/rv32i/Decoder.scala 52:18 84:18]
  wire  _GEN_137 = 7'h6f == opcode ? 1'h0 : _GEN_122; // @[src/main/scala/rv32i/Decoder.scala 63:18 84:18]
  wire  _GEN_138 = 7'h6f == opcode ? 1'h0 : _GEN_123; // @[src/main/scala/rv32i/Decoder.scala 64:18 84:18]
  wire  _GEN_139 = 7'h6f == opcode ? 1'h0 : _GEN_124; // @[src/main/scala/rv32i/Decoder.scala 65:18 84:18]
  wire  _GEN_140 = 7'h6f == opcode ? 1'h0 : _GEN_125; // @[src/main/scala/rv32i/Decoder.scala 62:18 84:18]
  wire  _GEN_141 = 7'h17 == opcode ? 1'h0 : _GEN_126; // @[src/main/scala/rv32i/Decoder.scala 84:18 93:20]
  wire  _GEN_142 = 7'h17 == opcode | _GEN_128; // @[src/main/scala/rv32i/Decoder.scala 84:18 94:20]
  wire [2:0] _GEN_143 = 7'h17 == opcode ? 3'h3 : _GEN_130; // @[src/main/scala/rv32i/Decoder.scala 84:18 95:20]
  wire  _GEN_145 = 7'h17 == opcode | _GEN_132; // @[src/main/scala/rv32i/Decoder.scala 84:18 97:20]
  wire  _GEN_146 = 7'h17 == opcode ? 1'h0 : 7'h6f == opcode; // @[src/main/scala/rv32i/Decoder.scala 54:18 84:18]
  wire [1:0] _GEN_147 = 7'h17 == opcode ? 2'h0 : _GEN_129; // @[src/main/scala/rv32i/Decoder.scala 60:18 84:18]
  wire  _GEN_148 = 7'h17 == opcode ? 1'h0 : _GEN_131; // @[src/main/scala/rv32i/Decoder.scala 55:18 84:18]
  wire  _GEN_149 = 7'h17 == opcode ? 1'h0 : _GEN_133; // @[src/main/scala/rv32i/Decoder.scala 53:18 84:18]
  wire  _GEN_150 = 7'h17 == opcode ? 1'h0 : _GEN_134; // @[src/main/scala/rv32i/Decoder.scala 56:18 84:18]
  wire  _GEN_151 = 7'h17 == opcode ? 1'h0 : _GEN_135; // @[src/main/scala/rv32i/Decoder.scala 57:18 84:18]
  wire [3:0] _GEN_152 = 7'h17 == opcode ? 4'h0 : _GEN_136; // @[src/main/scala/rv32i/Decoder.scala 52:18 84:18]
  wire  _GEN_153 = 7'h17 == opcode ? 1'h0 : _GEN_137; // @[src/main/scala/rv32i/Decoder.scala 63:18 84:18]
  wire  _GEN_154 = 7'h17 == opcode ? 1'h0 : _GEN_138; // @[src/main/scala/rv32i/Decoder.scala 64:18 84:18]
  wire  _GEN_155 = 7'h17 == opcode ? 1'h0 : _GEN_139; // @[src/main/scala/rv32i/Decoder.scala 65:18 84:18]
  wire  _GEN_156 = 7'h17 == opcode ? 1'h0 : _GEN_140; // @[src/main/scala/rv32i/Decoder.scala 62:18 84:18]
  assign io_immSel = 7'h37 == opcode ? 3'h3 : _GEN_143; // @[src/main/scala/rv32i/Decoder.scala 84:18 88:20]
  assign io_aluSrcA = 7'h37 == opcode ? 2'h2 : {{1'd0}, 7'h17 == opcode}; // @[src/main/scala/rv32i/Decoder.scala 84:18 89:20]
  assign io_aluSrcImm = 7'h37 == opcode | _GEN_145; // @[src/main/scala/rv32i/Decoder.scala 84:18 90:20]
  assign io_aluOp = 7'h37 == opcode ? 4'h0 : _GEN_152; // @[src/main/scala/rv32i/Decoder.scala 52:18 84:18]
  assign io_branch = 7'h37 == opcode ? 1'h0 : _GEN_149; // @[src/main/scala/rv32i/Decoder.scala 53:18 84:18]
  assign io_jal = 7'h37 == opcode ? 1'h0 : _GEN_146; // @[src/main/scala/rv32i/Decoder.scala 54:18 84:18]
  assign io_jalr = 7'h37 == opcode ? 1'h0 : _GEN_148; // @[src/main/scala/rv32i/Decoder.scala 55:18 84:18]
  assign io_memRead = 7'h37 == opcode ? 1'h0 : _GEN_150; // @[src/main/scala/rv32i/Decoder.scala 56:18 84:18]
  assign io_memWrite = 7'h37 == opcode ? 1'h0 : _GEN_151; // @[src/main/scala/rv32i/Decoder.scala 57:18 84:18]
  assign io_memSize = f3[1:0]; // @[src/main/scala/rv32i/Decoder.scala 58:23]
  assign io_memUnsigned = f3[2]; // @[src/main/scala/rv32i/Decoder.scala 59:23]
  assign io_wbSel = 7'h37 == opcode ? 2'h0 : _GEN_147; // @[src/main/scala/rv32i/Decoder.scala 60:18 84:18]
  assign io_regWrite = 7'h37 == opcode | _GEN_142; // @[src/main/scala/rv32i/Decoder.scala 84:18 87:20]
  assign io_csr = 7'h37 == opcode ? 1'h0 : _GEN_156; // @[src/main/scala/rv32i/Decoder.scala 62:18 84:18]
  assign io_ecall = 7'h37 == opcode ? 1'h0 : _GEN_153; // @[src/main/scala/rv32i/Decoder.scala 63:18 84:18]
  assign io_ebreak = 7'h37 == opcode ? 1'h0 : _GEN_154; // @[src/main/scala/rv32i/Decoder.scala 64:18 84:18]
  assign io_mret = 7'h37 == opcode ? 1'h0 : _GEN_155; // @[src/main/scala/rv32i/Decoder.scala 65:18 84:18]
  assign io_illegal = 7'h37 == opcode ? 1'h0 : _GEN_141; // @[src/main/scala/rv32i/Decoder.scala 84:18 86:20]
endmodule
module ImmGen(
  input  [31:0] io_inst, // @[src/main/scala/rv32i/ImmGen.scala 8:14]
  input  [2:0]  io_sel, // @[src/main/scala/rv32i/ImmGen.scala 8:14]
  output [31:0] io_imm // @[src/main/scala/rv32i/ImmGen.scala 8:14]
);
  wire  sign = io_inst[31]; // @[src/main/scala/rv32i/ImmGen.scala 15:15]
  wire [20:0] _immI_T = sign ? 21'h1fffff : 21'h0; // @[src/main/scala/rv32i/ImmGen.scala 16:22]
  wire [31:0] immI = {_immI_T,io_inst[30:20]}; // @[src/main/scala/rv32i/ImmGen.scala 16:17]
  wire [31:0] immS = {_immI_T,io_inst[30:25],io_inst[11:7]}; // @[src/main/scala/rv32i/ImmGen.scala 17:17]
  wire [19:0] _immB_T = sign ? 20'hfffff : 20'h0; // @[src/main/scala/rv32i/ImmGen.scala 18:22]
  wire [31:0] immB = {_immB_T,io_inst[7],io_inst[30:25],io_inst[11:8],1'h0}; // @[src/main/scala/rv32i/ImmGen.scala 18:17]
  wire [31:0] immU = {io_inst[31:12],12'h0}; // @[src/main/scala/rv32i/ImmGen.scala 19:17]
  wire [11:0] _immJ_T = sign ? 12'hfff : 12'h0; // @[src/main/scala/rv32i/ImmGen.scala 20:22]
  wire [31:0] immJ = {_immJ_T,io_inst[19:12],io_inst[20],io_inst[30:21],1'h0}; // @[src/main/scala/rv32i/ImmGen.scala 20:17]
  wire [31:0] _GEN_0 = 3'h4 == io_sel ? immJ : immI; // @[src/main/scala/rv32i/ImmGen.scala 22:10 23:18 28:27]
  wire [31:0] _GEN_1 = 3'h3 == io_sel ? immU : _GEN_0; // @[src/main/scala/rv32i/ImmGen.scala 23:18 27:27]
  wire [31:0] _GEN_2 = 3'h2 == io_sel ? immB : _GEN_1; // @[src/main/scala/rv32i/ImmGen.scala 23:18 26:27]
  wire [31:0] _GEN_3 = 3'h1 == io_sel ? immS : _GEN_2; // @[src/main/scala/rv32i/ImmGen.scala 23:18 25:27]
  assign io_imm = 3'h0 == io_sel ? immI : _GEN_3; // @[src/main/scala/rv32i/ImmGen.scala 23:18 24:27]
endmodule
module RegFile(
  input         clock,
  input         reset,
  input  [4:0]  io_rs1, // @[src/main/scala/rv32i/RegFile.scala 9:14]
  input  [4:0]  io_rs2, // @[src/main/scala/rv32i/RegFile.scala 9:14]
  output [31:0] io_rd1, // @[src/main/scala/rv32i/RegFile.scala 9:14]
  output [31:0] io_rd2, // @[src/main/scala/rv32i/RegFile.scala 9:14]
  input         io_we, // @[src/main/scala/rv32i/RegFile.scala 9:14]
  input  [4:0]  io_waddr, // @[src/main/scala/rv32i/RegFile.scala 9:14]
  input  [31:0] io_wdata // @[src/main/scala/rv32i/RegFile.scala 9:14]
);
`ifdef RANDOMIZE_REG_INIT
  reg [31:0] _RAND_0;
  reg [31:0] _RAND_1;
  reg [31:0] _RAND_2;
  reg [31:0] _RAND_3;
  reg [31:0] _RAND_4;
  reg [31:0] _RAND_5;
  reg [31:0] _RAND_6;
  reg [31:0] _RAND_7;
  reg [31:0] _RAND_8;
  reg [31:0] _RAND_9;
  reg [31:0] _RAND_10;
  reg [31:0] _RAND_11;
  reg [31:0] _RAND_12;
  reg [31:0] _RAND_13;
  reg [31:0] _RAND_14;
  reg [31:0] _RAND_15;
  reg [31:0] _RAND_16;
  reg [31:0] _RAND_17;
  reg [31:0] _RAND_18;
  reg [31:0] _RAND_19;
  reg [31:0] _RAND_20;
  reg [31:0] _RAND_21;
  reg [31:0] _RAND_22;
  reg [31:0] _RAND_23;
  reg [31:0] _RAND_24;
  reg [31:0] _RAND_25;
  reg [31:0] _RAND_26;
  reg [31:0] _RAND_27;
  reg [31:0] _RAND_28;
  reg [31:0] _RAND_29;
  reg [31:0] _RAND_30;
  reg [31:0] _RAND_31;
`endif // RANDOMIZE_REG_INIT
  reg [31:0] regs_0; // @[src/main/scala/rv32i/RegFile.scala 19:21]
  reg [31:0] regs_1; // @[src/main/scala/rv32i/RegFile.scala 19:21]
  reg [31:0] regs_2; // @[src/main/scala/rv32i/RegFile.scala 19:21]
  reg [31:0] regs_3; // @[src/main/scala/rv32i/RegFile.scala 19:21]
  reg [31:0] regs_4; // @[src/main/scala/rv32i/RegFile.scala 19:21]
  reg [31:0] regs_5; // @[src/main/scala/rv32i/RegFile.scala 19:21]
  reg [31:0] regs_6; // @[src/main/scala/rv32i/RegFile.scala 19:21]
  reg [31:0] regs_7; // @[src/main/scala/rv32i/RegFile.scala 19:21]
  reg [31:0] regs_8; // @[src/main/scala/rv32i/RegFile.scala 19:21]
  reg [31:0] regs_9; // @[src/main/scala/rv32i/RegFile.scala 19:21]
  reg [31:0] regs_10; // @[src/main/scala/rv32i/RegFile.scala 19:21]
  reg [31:0] regs_11; // @[src/main/scala/rv32i/RegFile.scala 19:21]
  reg [31:0] regs_12; // @[src/main/scala/rv32i/RegFile.scala 19:21]
  reg [31:0] regs_13; // @[src/main/scala/rv32i/RegFile.scala 19:21]
  reg [31:0] regs_14; // @[src/main/scala/rv32i/RegFile.scala 19:21]
  reg [31:0] regs_15; // @[src/main/scala/rv32i/RegFile.scala 19:21]
  reg [31:0] regs_16; // @[src/main/scala/rv32i/RegFile.scala 19:21]
  reg [31:0] regs_17; // @[src/main/scala/rv32i/RegFile.scala 19:21]
  reg [31:0] regs_18; // @[src/main/scala/rv32i/RegFile.scala 19:21]
  reg [31:0] regs_19; // @[src/main/scala/rv32i/RegFile.scala 19:21]
  reg [31:0] regs_20; // @[src/main/scala/rv32i/RegFile.scala 19:21]
  reg [31:0] regs_21; // @[src/main/scala/rv32i/RegFile.scala 19:21]
  reg [31:0] regs_22; // @[src/main/scala/rv32i/RegFile.scala 19:21]
  reg [31:0] regs_23; // @[src/main/scala/rv32i/RegFile.scala 19:21]
  reg [31:0] regs_24; // @[src/main/scala/rv32i/RegFile.scala 19:21]
  reg [31:0] regs_25; // @[src/main/scala/rv32i/RegFile.scala 19:21]
  reg [31:0] regs_26; // @[src/main/scala/rv32i/RegFile.scala 19:21]
  reg [31:0] regs_27; // @[src/main/scala/rv32i/RegFile.scala 19:21]
  reg [31:0] regs_28; // @[src/main/scala/rv32i/RegFile.scala 19:21]
  reg [31:0] regs_29; // @[src/main/scala/rv32i/RegFile.scala 19:21]
  reg [31:0] regs_30; // @[src/main/scala/rv32i/RegFile.scala 19:21]
  reg [31:0] regs_31; // @[src/main/scala/rv32i/RegFile.scala 19:21]
  wire [31:0] _GEN_1 = 5'h1 == io_rs1 ? regs_1 : regs_0; // @[src/main/scala/rv32i/RegFile.scala 21:{16,16}]
  wire [31:0] _GEN_2 = 5'h2 == io_rs1 ? regs_2 : _GEN_1; // @[src/main/scala/rv32i/RegFile.scala 21:{16,16}]
  wire [31:0] _GEN_3 = 5'h3 == io_rs1 ? regs_3 : _GEN_2; // @[src/main/scala/rv32i/RegFile.scala 21:{16,16}]
  wire [31:0] _GEN_4 = 5'h4 == io_rs1 ? regs_4 : _GEN_3; // @[src/main/scala/rv32i/RegFile.scala 21:{16,16}]
  wire [31:0] _GEN_5 = 5'h5 == io_rs1 ? regs_5 : _GEN_4; // @[src/main/scala/rv32i/RegFile.scala 21:{16,16}]
  wire [31:0] _GEN_6 = 5'h6 == io_rs1 ? regs_6 : _GEN_5; // @[src/main/scala/rv32i/RegFile.scala 21:{16,16}]
  wire [31:0] _GEN_7 = 5'h7 == io_rs1 ? regs_7 : _GEN_6; // @[src/main/scala/rv32i/RegFile.scala 21:{16,16}]
  wire [31:0] _GEN_8 = 5'h8 == io_rs1 ? regs_8 : _GEN_7; // @[src/main/scala/rv32i/RegFile.scala 21:{16,16}]
  wire [31:0] _GEN_9 = 5'h9 == io_rs1 ? regs_9 : _GEN_8; // @[src/main/scala/rv32i/RegFile.scala 21:{16,16}]
  wire [31:0] _GEN_10 = 5'ha == io_rs1 ? regs_10 : _GEN_9; // @[src/main/scala/rv32i/RegFile.scala 21:{16,16}]
  wire [31:0] _GEN_11 = 5'hb == io_rs1 ? regs_11 : _GEN_10; // @[src/main/scala/rv32i/RegFile.scala 21:{16,16}]
  wire [31:0] _GEN_12 = 5'hc == io_rs1 ? regs_12 : _GEN_11; // @[src/main/scala/rv32i/RegFile.scala 21:{16,16}]
  wire [31:0] _GEN_13 = 5'hd == io_rs1 ? regs_13 : _GEN_12; // @[src/main/scala/rv32i/RegFile.scala 21:{16,16}]
  wire [31:0] _GEN_14 = 5'he == io_rs1 ? regs_14 : _GEN_13; // @[src/main/scala/rv32i/RegFile.scala 21:{16,16}]
  wire [31:0] _GEN_15 = 5'hf == io_rs1 ? regs_15 : _GEN_14; // @[src/main/scala/rv32i/RegFile.scala 21:{16,16}]
  wire [31:0] _GEN_16 = 5'h10 == io_rs1 ? regs_16 : _GEN_15; // @[src/main/scala/rv32i/RegFile.scala 21:{16,16}]
  wire [31:0] _GEN_17 = 5'h11 == io_rs1 ? regs_17 : _GEN_16; // @[src/main/scala/rv32i/RegFile.scala 21:{16,16}]
  wire [31:0] _GEN_18 = 5'h12 == io_rs1 ? regs_18 : _GEN_17; // @[src/main/scala/rv32i/RegFile.scala 21:{16,16}]
  wire [31:0] _GEN_19 = 5'h13 == io_rs1 ? regs_19 : _GEN_18; // @[src/main/scala/rv32i/RegFile.scala 21:{16,16}]
  wire [31:0] _GEN_20 = 5'h14 == io_rs1 ? regs_20 : _GEN_19; // @[src/main/scala/rv32i/RegFile.scala 21:{16,16}]
  wire [31:0] _GEN_21 = 5'h15 == io_rs1 ? regs_21 : _GEN_20; // @[src/main/scala/rv32i/RegFile.scala 21:{16,16}]
  wire [31:0] _GEN_22 = 5'h16 == io_rs1 ? regs_22 : _GEN_21; // @[src/main/scala/rv32i/RegFile.scala 21:{16,16}]
  wire [31:0] _GEN_23 = 5'h17 == io_rs1 ? regs_23 : _GEN_22; // @[src/main/scala/rv32i/RegFile.scala 21:{16,16}]
  wire [31:0] _GEN_24 = 5'h18 == io_rs1 ? regs_24 : _GEN_23; // @[src/main/scala/rv32i/RegFile.scala 21:{16,16}]
  wire [31:0] _GEN_25 = 5'h19 == io_rs1 ? regs_25 : _GEN_24; // @[src/main/scala/rv32i/RegFile.scala 21:{16,16}]
  wire [31:0] _GEN_26 = 5'h1a == io_rs1 ? regs_26 : _GEN_25; // @[src/main/scala/rv32i/RegFile.scala 21:{16,16}]
  wire [31:0] _GEN_27 = 5'h1b == io_rs1 ? regs_27 : _GEN_26; // @[src/main/scala/rv32i/RegFile.scala 21:{16,16}]
  wire [31:0] _GEN_28 = 5'h1c == io_rs1 ? regs_28 : _GEN_27; // @[src/main/scala/rv32i/RegFile.scala 21:{16,16}]
  wire [31:0] _GEN_29 = 5'h1d == io_rs1 ? regs_29 : _GEN_28; // @[src/main/scala/rv32i/RegFile.scala 21:{16,16}]
  wire [31:0] _GEN_30 = 5'h1e == io_rs1 ? regs_30 : _GEN_29; // @[src/main/scala/rv32i/RegFile.scala 21:{16,16}]
  wire [31:0] _GEN_31 = 5'h1f == io_rs1 ? regs_31 : _GEN_30; // @[src/main/scala/rv32i/RegFile.scala 21:{16,16}]
  wire [31:0] _GEN_33 = 5'h1 == io_rs2 ? regs_1 : regs_0; // @[src/main/scala/rv32i/RegFile.scala 22:{16,16}]
  wire [31:0] _GEN_34 = 5'h2 == io_rs2 ? regs_2 : _GEN_33; // @[src/main/scala/rv32i/RegFile.scala 22:{16,16}]
  wire [31:0] _GEN_35 = 5'h3 == io_rs2 ? regs_3 : _GEN_34; // @[src/main/scala/rv32i/RegFile.scala 22:{16,16}]
  wire [31:0] _GEN_36 = 5'h4 == io_rs2 ? regs_4 : _GEN_35; // @[src/main/scala/rv32i/RegFile.scala 22:{16,16}]
  wire [31:0] _GEN_37 = 5'h5 == io_rs2 ? regs_5 : _GEN_36; // @[src/main/scala/rv32i/RegFile.scala 22:{16,16}]
  wire [31:0] _GEN_38 = 5'h6 == io_rs2 ? regs_6 : _GEN_37; // @[src/main/scala/rv32i/RegFile.scala 22:{16,16}]
  wire [31:0] _GEN_39 = 5'h7 == io_rs2 ? regs_7 : _GEN_38; // @[src/main/scala/rv32i/RegFile.scala 22:{16,16}]
  wire [31:0] _GEN_40 = 5'h8 == io_rs2 ? regs_8 : _GEN_39; // @[src/main/scala/rv32i/RegFile.scala 22:{16,16}]
  wire [31:0] _GEN_41 = 5'h9 == io_rs2 ? regs_9 : _GEN_40; // @[src/main/scala/rv32i/RegFile.scala 22:{16,16}]
  wire [31:0] _GEN_42 = 5'ha == io_rs2 ? regs_10 : _GEN_41; // @[src/main/scala/rv32i/RegFile.scala 22:{16,16}]
  wire [31:0] _GEN_43 = 5'hb == io_rs2 ? regs_11 : _GEN_42; // @[src/main/scala/rv32i/RegFile.scala 22:{16,16}]
  wire [31:0] _GEN_44 = 5'hc == io_rs2 ? regs_12 : _GEN_43; // @[src/main/scala/rv32i/RegFile.scala 22:{16,16}]
  wire [31:0] _GEN_45 = 5'hd == io_rs2 ? regs_13 : _GEN_44; // @[src/main/scala/rv32i/RegFile.scala 22:{16,16}]
  wire [31:0] _GEN_46 = 5'he == io_rs2 ? regs_14 : _GEN_45; // @[src/main/scala/rv32i/RegFile.scala 22:{16,16}]
  wire [31:0] _GEN_47 = 5'hf == io_rs2 ? regs_15 : _GEN_46; // @[src/main/scala/rv32i/RegFile.scala 22:{16,16}]
  wire [31:0] _GEN_48 = 5'h10 == io_rs2 ? regs_16 : _GEN_47; // @[src/main/scala/rv32i/RegFile.scala 22:{16,16}]
  wire [31:0] _GEN_49 = 5'h11 == io_rs2 ? regs_17 : _GEN_48; // @[src/main/scala/rv32i/RegFile.scala 22:{16,16}]
  wire [31:0] _GEN_50 = 5'h12 == io_rs2 ? regs_18 : _GEN_49; // @[src/main/scala/rv32i/RegFile.scala 22:{16,16}]
  wire [31:0] _GEN_51 = 5'h13 == io_rs2 ? regs_19 : _GEN_50; // @[src/main/scala/rv32i/RegFile.scala 22:{16,16}]
  wire [31:0] _GEN_52 = 5'h14 == io_rs2 ? regs_20 : _GEN_51; // @[src/main/scala/rv32i/RegFile.scala 22:{16,16}]
  wire [31:0] _GEN_53 = 5'h15 == io_rs2 ? regs_21 : _GEN_52; // @[src/main/scala/rv32i/RegFile.scala 22:{16,16}]
  wire [31:0] _GEN_54 = 5'h16 == io_rs2 ? regs_22 : _GEN_53; // @[src/main/scala/rv32i/RegFile.scala 22:{16,16}]
  wire [31:0] _GEN_55 = 5'h17 == io_rs2 ? regs_23 : _GEN_54; // @[src/main/scala/rv32i/RegFile.scala 22:{16,16}]
  wire [31:0] _GEN_56 = 5'h18 == io_rs2 ? regs_24 : _GEN_55; // @[src/main/scala/rv32i/RegFile.scala 22:{16,16}]
  wire [31:0] _GEN_57 = 5'h19 == io_rs2 ? regs_25 : _GEN_56; // @[src/main/scala/rv32i/RegFile.scala 22:{16,16}]
  wire [31:0] _GEN_58 = 5'h1a == io_rs2 ? regs_26 : _GEN_57; // @[src/main/scala/rv32i/RegFile.scala 22:{16,16}]
  wire [31:0] _GEN_59 = 5'h1b == io_rs2 ? regs_27 : _GEN_58; // @[src/main/scala/rv32i/RegFile.scala 22:{16,16}]
  wire [31:0] _GEN_60 = 5'h1c == io_rs2 ? regs_28 : _GEN_59; // @[src/main/scala/rv32i/RegFile.scala 22:{16,16}]
  wire [31:0] _GEN_61 = 5'h1d == io_rs2 ? regs_29 : _GEN_60; // @[src/main/scala/rv32i/RegFile.scala 22:{16,16}]
  wire [31:0] _GEN_62 = 5'h1e == io_rs2 ? regs_30 : _GEN_61; // @[src/main/scala/rv32i/RegFile.scala 22:{16,16}]
  wire [31:0] _GEN_63 = 5'h1f == io_rs2 ? regs_31 : _GEN_62; // @[src/main/scala/rv32i/RegFile.scala 22:{16,16}]
  assign io_rd1 = io_rs1 == 5'h0 ? 32'h0 : _GEN_31; // @[src/main/scala/rv32i/RegFile.scala 21:16]
  assign io_rd2 = io_rs2 == 5'h0 ? 32'h0 : _GEN_63; // @[src/main/scala/rv32i/RegFile.scala 22:16]
  always @(posedge clock) begin
    if (reset) begin // @[src/main/scala/rv32i/RegFile.scala 19:21]
      regs_0 <= 32'h0; // @[src/main/scala/rv32i/RegFile.scala 19:21]
    end else if (io_we & io_waddr != 5'h0) begin // @[src/main/scala/rv32i/RegFile.scala 24:35]
      if (5'h0 == io_waddr) begin // @[src/main/scala/rv32i/RegFile.scala 25:20]
        regs_0 <= io_wdata; // @[src/main/scala/rv32i/RegFile.scala 25:20]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegFile.scala 19:21]
      regs_1 <= 32'h0; // @[src/main/scala/rv32i/RegFile.scala 19:21]
    end else if (io_we & io_waddr != 5'h0) begin // @[src/main/scala/rv32i/RegFile.scala 24:35]
      if (5'h1 == io_waddr) begin // @[src/main/scala/rv32i/RegFile.scala 25:20]
        regs_1 <= io_wdata; // @[src/main/scala/rv32i/RegFile.scala 25:20]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegFile.scala 19:21]
      regs_2 <= 32'h0; // @[src/main/scala/rv32i/RegFile.scala 19:21]
    end else if (io_we & io_waddr != 5'h0) begin // @[src/main/scala/rv32i/RegFile.scala 24:35]
      if (5'h2 == io_waddr) begin // @[src/main/scala/rv32i/RegFile.scala 25:20]
        regs_2 <= io_wdata; // @[src/main/scala/rv32i/RegFile.scala 25:20]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegFile.scala 19:21]
      regs_3 <= 32'h0; // @[src/main/scala/rv32i/RegFile.scala 19:21]
    end else if (io_we & io_waddr != 5'h0) begin // @[src/main/scala/rv32i/RegFile.scala 24:35]
      if (5'h3 == io_waddr) begin // @[src/main/scala/rv32i/RegFile.scala 25:20]
        regs_3 <= io_wdata; // @[src/main/scala/rv32i/RegFile.scala 25:20]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegFile.scala 19:21]
      regs_4 <= 32'h0; // @[src/main/scala/rv32i/RegFile.scala 19:21]
    end else if (io_we & io_waddr != 5'h0) begin // @[src/main/scala/rv32i/RegFile.scala 24:35]
      if (5'h4 == io_waddr) begin // @[src/main/scala/rv32i/RegFile.scala 25:20]
        regs_4 <= io_wdata; // @[src/main/scala/rv32i/RegFile.scala 25:20]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegFile.scala 19:21]
      regs_5 <= 32'h0; // @[src/main/scala/rv32i/RegFile.scala 19:21]
    end else if (io_we & io_waddr != 5'h0) begin // @[src/main/scala/rv32i/RegFile.scala 24:35]
      if (5'h5 == io_waddr) begin // @[src/main/scala/rv32i/RegFile.scala 25:20]
        regs_5 <= io_wdata; // @[src/main/scala/rv32i/RegFile.scala 25:20]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegFile.scala 19:21]
      regs_6 <= 32'h0; // @[src/main/scala/rv32i/RegFile.scala 19:21]
    end else if (io_we & io_waddr != 5'h0) begin // @[src/main/scala/rv32i/RegFile.scala 24:35]
      if (5'h6 == io_waddr) begin // @[src/main/scala/rv32i/RegFile.scala 25:20]
        regs_6 <= io_wdata; // @[src/main/scala/rv32i/RegFile.scala 25:20]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegFile.scala 19:21]
      regs_7 <= 32'h0; // @[src/main/scala/rv32i/RegFile.scala 19:21]
    end else if (io_we & io_waddr != 5'h0) begin // @[src/main/scala/rv32i/RegFile.scala 24:35]
      if (5'h7 == io_waddr) begin // @[src/main/scala/rv32i/RegFile.scala 25:20]
        regs_7 <= io_wdata; // @[src/main/scala/rv32i/RegFile.scala 25:20]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegFile.scala 19:21]
      regs_8 <= 32'h0; // @[src/main/scala/rv32i/RegFile.scala 19:21]
    end else if (io_we & io_waddr != 5'h0) begin // @[src/main/scala/rv32i/RegFile.scala 24:35]
      if (5'h8 == io_waddr) begin // @[src/main/scala/rv32i/RegFile.scala 25:20]
        regs_8 <= io_wdata; // @[src/main/scala/rv32i/RegFile.scala 25:20]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegFile.scala 19:21]
      regs_9 <= 32'h0; // @[src/main/scala/rv32i/RegFile.scala 19:21]
    end else if (io_we & io_waddr != 5'h0) begin // @[src/main/scala/rv32i/RegFile.scala 24:35]
      if (5'h9 == io_waddr) begin // @[src/main/scala/rv32i/RegFile.scala 25:20]
        regs_9 <= io_wdata; // @[src/main/scala/rv32i/RegFile.scala 25:20]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegFile.scala 19:21]
      regs_10 <= 32'h0; // @[src/main/scala/rv32i/RegFile.scala 19:21]
    end else if (io_we & io_waddr != 5'h0) begin // @[src/main/scala/rv32i/RegFile.scala 24:35]
      if (5'ha == io_waddr) begin // @[src/main/scala/rv32i/RegFile.scala 25:20]
        regs_10 <= io_wdata; // @[src/main/scala/rv32i/RegFile.scala 25:20]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegFile.scala 19:21]
      regs_11 <= 32'h0; // @[src/main/scala/rv32i/RegFile.scala 19:21]
    end else if (io_we & io_waddr != 5'h0) begin // @[src/main/scala/rv32i/RegFile.scala 24:35]
      if (5'hb == io_waddr) begin // @[src/main/scala/rv32i/RegFile.scala 25:20]
        regs_11 <= io_wdata; // @[src/main/scala/rv32i/RegFile.scala 25:20]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegFile.scala 19:21]
      regs_12 <= 32'h0; // @[src/main/scala/rv32i/RegFile.scala 19:21]
    end else if (io_we & io_waddr != 5'h0) begin // @[src/main/scala/rv32i/RegFile.scala 24:35]
      if (5'hc == io_waddr) begin // @[src/main/scala/rv32i/RegFile.scala 25:20]
        regs_12 <= io_wdata; // @[src/main/scala/rv32i/RegFile.scala 25:20]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegFile.scala 19:21]
      regs_13 <= 32'h0; // @[src/main/scala/rv32i/RegFile.scala 19:21]
    end else if (io_we & io_waddr != 5'h0) begin // @[src/main/scala/rv32i/RegFile.scala 24:35]
      if (5'hd == io_waddr) begin // @[src/main/scala/rv32i/RegFile.scala 25:20]
        regs_13 <= io_wdata; // @[src/main/scala/rv32i/RegFile.scala 25:20]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegFile.scala 19:21]
      regs_14 <= 32'h0; // @[src/main/scala/rv32i/RegFile.scala 19:21]
    end else if (io_we & io_waddr != 5'h0) begin // @[src/main/scala/rv32i/RegFile.scala 24:35]
      if (5'he == io_waddr) begin // @[src/main/scala/rv32i/RegFile.scala 25:20]
        regs_14 <= io_wdata; // @[src/main/scala/rv32i/RegFile.scala 25:20]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegFile.scala 19:21]
      regs_15 <= 32'h0; // @[src/main/scala/rv32i/RegFile.scala 19:21]
    end else if (io_we & io_waddr != 5'h0) begin // @[src/main/scala/rv32i/RegFile.scala 24:35]
      if (5'hf == io_waddr) begin // @[src/main/scala/rv32i/RegFile.scala 25:20]
        regs_15 <= io_wdata; // @[src/main/scala/rv32i/RegFile.scala 25:20]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegFile.scala 19:21]
      regs_16 <= 32'h0; // @[src/main/scala/rv32i/RegFile.scala 19:21]
    end else if (io_we & io_waddr != 5'h0) begin // @[src/main/scala/rv32i/RegFile.scala 24:35]
      if (5'h10 == io_waddr) begin // @[src/main/scala/rv32i/RegFile.scala 25:20]
        regs_16 <= io_wdata; // @[src/main/scala/rv32i/RegFile.scala 25:20]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegFile.scala 19:21]
      regs_17 <= 32'h0; // @[src/main/scala/rv32i/RegFile.scala 19:21]
    end else if (io_we & io_waddr != 5'h0) begin // @[src/main/scala/rv32i/RegFile.scala 24:35]
      if (5'h11 == io_waddr) begin // @[src/main/scala/rv32i/RegFile.scala 25:20]
        regs_17 <= io_wdata; // @[src/main/scala/rv32i/RegFile.scala 25:20]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegFile.scala 19:21]
      regs_18 <= 32'h0; // @[src/main/scala/rv32i/RegFile.scala 19:21]
    end else if (io_we & io_waddr != 5'h0) begin // @[src/main/scala/rv32i/RegFile.scala 24:35]
      if (5'h12 == io_waddr) begin // @[src/main/scala/rv32i/RegFile.scala 25:20]
        regs_18 <= io_wdata; // @[src/main/scala/rv32i/RegFile.scala 25:20]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegFile.scala 19:21]
      regs_19 <= 32'h0; // @[src/main/scala/rv32i/RegFile.scala 19:21]
    end else if (io_we & io_waddr != 5'h0) begin // @[src/main/scala/rv32i/RegFile.scala 24:35]
      if (5'h13 == io_waddr) begin // @[src/main/scala/rv32i/RegFile.scala 25:20]
        regs_19 <= io_wdata; // @[src/main/scala/rv32i/RegFile.scala 25:20]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegFile.scala 19:21]
      regs_20 <= 32'h0; // @[src/main/scala/rv32i/RegFile.scala 19:21]
    end else if (io_we & io_waddr != 5'h0) begin // @[src/main/scala/rv32i/RegFile.scala 24:35]
      if (5'h14 == io_waddr) begin // @[src/main/scala/rv32i/RegFile.scala 25:20]
        regs_20 <= io_wdata; // @[src/main/scala/rv32i/RegFile.scala 25:20]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegFile.scala 19:21]
      regs_21 <= 32'h0; // @[src/main/scala/rv32i/RegFile.scala 19:21]
    end else if (io_we & io_waddr != 5'h0) begin // @[src/main/scala/rv32i/RegFile.scala 24:35]
      if (5'h15 == io_waddr) begin // @[src/main/scala/rv32i/RegFile.scala 25:20]
        regs_21 <= io_wdata; // @[src/main/scala/rv32i/RegFile.scala 25:20]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegFile.scala 19:21]
      regs_22 <= 32'h0; // @[src/main/scala/rv32i/RegFile.scala 19:21]
    end else if (io_we & io_waddr != 5'h0) begin // @[src/main/scala/rv32i/RegFile.scala 24:35]
      if (5'h16 == io_waddr) begin // @[src/main/scala/rv32i/RegFile.scala 25:20]
        regs_22 <= io_wdata; // @[src/main/scala/rv32i/RegFile.scala 25:20]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegFile.scala 19:21]
      regs_23 <= 32'h0; // @[src/main/scala/rv32i/RegFile.scala 19:21]
    end else if (io_we & io_waddr != 5'h0) begin // @[src/main/scala/rv32i/RegFile.scala 24:35]
      if (5'h17 == io_waddr) begin // @[src/main/scala/rv32i/RegFile.scala 25:20]
        regs_23 <= io_wdata; // @[src/main/scala/rv32i/RegFile.scala 25:20]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegFile.scala 19:21]
      regs_24 <= 32'h0; // @[src/main/scala/rv32i/RegFile.scala 19:21]
    end else if (io_we & io_waddr != 5'h0) begin // @[src/main/scala/rv32i/RegFile.scala 24:35]
      if (5'h18 == io_waddr) begin // @[src/main/scala/rv32i/RegFile.scala 25:20]
        regs_24 <= io_wdata; // @[src/main/scala/rv32i/RegFile.scala 25:20]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegFile.scala 19:21]
      regs_25 <= 32'h0; // @[src/main/scala/rv32i/RegFile.scala 19:21]
    end else if (io_we & io_waddr != 5'h0) begin // @[src/main/scala/rv32i/RegFile.scala 24:35]
      if (5'h19 == io_waddr) begin // @[src/main/scala/rv32i/RegFile.scala 25:20]
        regs_25 <= io_wdata; // @[src/main/scala/rv32i/RegFile.scala 25:20]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegFile.scala 19:21]
      regs_26 <= 32'h0; // @[src/main/scala/rv32i/RegFile.scala 19:21]
    end else if (io_we & io_waddr != 5'h0) begin // @[src/main/scala/rv32i/RegFile.scala 24:35]
      if (5'h1a == io_waddr) begin // @[src/main/scala/rv32i/RegFile.scala 25:20]
        regs_26 <= io_wdata; // @[src/main/scala/rv32i/RegFile.scala 25:20]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegFile.scala 19:21]
      regs_27 <= 32'h0; // @[src/main/scala/rv32i/RegFile.scala 19:21]
    end else if (io_we & io_waddr != 5'h0) begin // @[src/main/scala/rv32i/RegFile.scala 24:35]
      if (5'h1b == io_waddr) begin // @[src/main/scala/rv32i/RegFile.scala 25:20]
        regs_27 <= io_wdata; // @[src/main/scala/rv32i/RegFile.scala 25:20]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegFile.scala 19:21]
      regs_28 <= 32'h0; // @[src/main/scala/rv32i/RegFile.scala 19:21]
    end else if (io_we & io_waddr != 5'h0) begin // @[src/main/scala/rv32i/RegFile.scala 24:35]
      if (5'h1c == io_waddr) begin // @[src/main/scala/rv32i/RegFile.scala 25:20]
        regs_28 <= io_wdata; // @[src/main/scala/rv32i/RegFile.scala 25:20]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegFile.scala 19:21]
      regs_29 <= 32'h0; // @[src/main/scala/rv32i/RegFile.scala 19:21]
    end else if (io_we & io_waddr != 5'h0) begin // @[src/main/scala/rv32i/RegFile.scala 24:35]
      if (5'h1d == io_waddr) begin // @[src/main/scala/rv32i/RegFile.scala 25:20]
        regs_29 <= io_wdata; // @[src/main/scala/rv32i/RegFile.scala 25:20]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegFile.scala 19:21]
      regs_30 <= 32'h0; // @[src/main/scala/rv32i/RegFile.scala 19:21]
    end else if (io_we & io_waddr != 5'h0) begin // @[src/main/scala/rv32i/RegFile.scala 24:35]
      if (5'h1e == io_waddr) begin // @[src/main/scala/rv32i/RegFile.scala 25:20]
        regs_30 <= io_wdata; // @[src/main/scala/rv32i/RegFile.scala 25:20]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/RegFile.scala 19:21]
      regs_31 <= 32'h0; // @[src/main/scala/rv32i/RegFile.scala 19:21]
    end else if (io_we & io_waddr != 5'h0) begin // @[src/main/scala/rv32i/RegFile.scala 24:35]
      if (5'h1f == io_waddr) begin // @[src/main/scala/rv32i/RegFile.scala 25:20]
        regs_31 <= io_wdata; // @[src/main/scala/rv32i/RegFile.scala 25:20]
      end
    end
  end
// Register and memory initialization
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif
`ifndef RANDOM
`define RANDOM $random
`endif
`ifdef RANDOMIZE_MEM_INIT
  integer initvar;
`endif
`ifndef SYNTHESIS
`ifdef FIRRTL_BEFORE_INITIAL
`FIRRTL_BEFORE_INITIAL
`endif
initial begin
  `ifdef RANDOMIZE
    `ifdef INIT_RANDOM
      `INIT_RANDOM
    `endif
    `ifndef VERILATOR
      `ifdef RANDOMIZE_DELAY
        #`RANDOMIZE_DELAY begin end
      `else
        #0.002 begin end
      `endif
    `endif
`ifdef RANDOMIZE_REG_INIT
  _RAND_0 = {1{`RANDOM}};
  regs_0 = _RAND_0[31:0];
  _RAND_1 = {1{`RANDOM}};
  regs_1 = _RAND_1[31:0];
  _RAND_2 = {1{`RANDOM}};
  regs_2 = _RAND_2[31:0];
  _RAND_3 = {1{`RANDOM}};
  regs_3 = _RAND_3[31:0];
  _RAND_4 = {1{`RANDOM}};
  regs_4 = _RAND_4[31:0];
  _RAND_5 = {1{`RANDOM}};
  regs_5 = _RAND_5[31:0];
  _RAND_6 = {1{`RANDOM}};
  regs_6 = _RAND_6[31:0];
  _RAND_7 = {1{`RANDOM}};
  regs_7 = _RAND_7[31:0];
  _RAND_8 = {1{`RANDOM}};
  regs_8 = _RAND_8[31:0];
  _RAND_9 = {1{`RANDOM}};
  regs_9 = _RAND_9[31:0];
  _RAND_10 = {1{`RANDOM}};
  regs_10 = _RAND_10[31:0];
  _RAND_11 = {1{`RANDOM}};
  regs_11 = _RAND_11[31:0];
  _RAND_12 = {1{`RANDOM}};
  regs_12 = _RAND_12[31:0];
  _RAND_13 = {1{`RANDOM}};
  regs_13 = _RAND_13[31:0];
  _RAND_14 = {1{`RANDOM}};
  regs_14 = _RAND_14[31:0];
  _RAND_15 = {1{`RANDOM}};
  regs_15 = _RAND_15[31:0];
  _RAND_16 = {1{`RANDOM}};
  regs_16 = _RAND_16[31:0];
  _RAND_17 = {1{`RANDOM}};
  regs_17 = _RAND_17[31:0];
  _RAND_18 = {1{`RANDOM}};
  regs_18 = _RAND_18[31:0];
  _RAND_19 = {1{`RANDOM}};
  regs_19 = _RAND_19[31:0];
  _RAND_20 = {1{`RANDOM}};
  regs_20 = _RAND_20[31:0];
  _RAND_21 = {1{`RANDOM}};
  regs_21 = _RAND_21[31:0];
  _RAND_22 = {1{`RANDOM}};
  regs_22 = _RAND_22[31:0];
  _RAND_23 = {1{`RANDOM}};
  regs_23 = _RAND_23[31:0];
  _RAND_24 = {1{`RANDOM}};
  regs_24 = _RAND_24[31:0];
  _RAND_25 = {1{`RANDOM}};
  regs_25 = _RAND_25[31:0];
  _RAND_26 = {1{`RANDOM}};
  regs_26 = _RAND_26[31:0];
  _RAND_27 = {1{`RANDOM}};
  regs_27 = _RAND_27[31:0];
  _RAND_28 = {1{`RANDOM}};
  regs_28 = _RAND_28[31:0];
  _RAND_29 = {1{`RANDOM}};
  regs_29 = _RAND_29[31:0];
  _RAND_30 = {1{`RANDOM}};
  regs_30 = _RAND_30[31:0];
  _RAND_31 = {1{`RANDOM}};
  regs_31 = _RAND_31[31:0];
`endif // RANDOMIZE_REG_INIT
  `endif // RANDOMIZE
end // initial
`ifdef FIRRTL_AFTER_INITIAL
`FIRRTL_AFTER_INITIAL
`endif
`endif // SYNTHESIS
endmodule
module Alu(
  input  [3:0]  io_op, // @[src/main/scala/rv32i/Alu.scala 8:14]
  input  [31:0] io_a, // @[src/main/scala/rv32i/Alu.scala 8:14]
  input  [31:0] io_b, // @[src/main/scala/rv32i/Alu.scala 8:14]
  output [31:0] io_y // @[src/main/scala/rv32i/Alu.scala 8:14]
);
  wire [4:0] sh = io_b[4:0]; // @[src/main/scala/rv32i/Alu.scala 15:16]
  wire [31:0] _io_y_T_1 = io_a + io_b; // @[src/main/scala/rv32i/Alu.scala 16:16]
  wire [31:0] _io_y_T_5 = io_a - io_b; // @[src/main/scala/rv32i/Alu.scala 19:35]
  wire [62:0] _GEN_9 = {{31'd0}, io_a}; // @[src/main/scala/rv32i/Alu.scala 20:36]
  wire [62:0] _io_y_T_6 = _GEN_9 << sh; // @[src/main/scala/rv32i/Alu.scala 20:36]
  wire [31:0] _io_y_T_8 = io_a; // @[src/main/scala/rv32i/Alu.scala 21:36]
  wire [31:0] _io_y_T_9 = io_b; // @[src/main/scala/rv32i/Alu.scala 21:50]
  wire [31:0] _io_y_T_12 = io_a ^ io_b; // @[src/main/scala/rv32i/Alu.scala 23:35]
  wire [31:0] _io_y_T_13 = io_a >> sh; // @[src/main/scala/rv32i/Alu.scala 24:35]
  wire [31:0] _io_y_T_16 = $signed(io_a) >>> sh; // @[src/main/scala/rv32i/Alu.scala 25:50]
  wire [31:0] _io_y_T_17 = io_a | io_b; // @[src/main/scala/rv32i/Alu.scala 26:35]
  wire [31:0] _io_y_T_18 = io_a & io_b; // @[src/main/scala/rv32i/Alu.scala 27:35]
  wire [31:0] _GEN_0 = 4'h9 == io_op ? _io_y_T_18 : _io_y_T_1; // @[src/main/scala/rv32i/Alu.scala 17:17 27:27 16:8]
  wire [31:0] _GEN_1 = 4'h8 == io_op ? _io_y_T_17 : _GEN_0; // @[src/main/scala/rv32i/Alu.scala 17:17 26:27]
  wire [31:0] _GEN_2 = 4'h7 == io_op ? _io_y_T_16 : _GEN_1; // @[src/main/scala/rv32i/Alu.scala 17:17 25:27]
  wire [31:0] _GEN_3 = 4'h6 == io_op ? _io_y_T_13 : _GEN_2; // @[src/main/scala/rv32i/Alu.scala 17:17 24:27]
  wire [31:0] _GEN_4 = 4'h5 == io_op ? _io_y_T_12 : _GEN_3; // @[src/main/scala/rv32i/Alu.scala 17:17 23:27]
  wire [31:0] _GEN_5 = 4'h4 == io_op ? {{31'd0}, io_a < io_b} : _GEN_4; // @[src/main/scala/rv32i/Alu.scala 17:17 22:27]
  wire [31:0] _GEN_6 = 4'h3 == io_op ? {{31'd0}, $signed(_io_y_T_8) < $signed(_io_y_T_9)} : _GEN_5; // @[src/main/scala/rv32i/Alu.scala 17:17 21:27]
  wire [31:0] _GEN_7 = 4'h2 == io_op ? _io_y_T_6[31:0] : _GEN_6; // @[src/main/scala/rv32i/Alu.scala 17:17 20:27]
  wire [31:0] _GEN_8 = 4'h1 == io_op ? _io_y_T_5 : _GEN_7; // @[src/main/scala/rv32i/Alu.scala 17:17 19:27]
  assign io_y = 4'h0 == io_op ? _io_y_T_1 : _GEN_8; // @[src/main/scala/rv32i/Alu.scala 17:17 18:27]
endmodule
module CsrFile(
  input         clock,
  input         reset,
  input  [11:0] io_addr, // @[src/main/scala/rv32i/CsrFile.scala 22:14]
  input         io_en, // @[src/main/scala/rv32i/CsrFile.scala 22:14]
  input  [1:0]  io_op, // @[src/main/scala/rv32i/CsrFile.scala 22:14]
  input  [31:0] io_src, // @[src/main/scala/rv32i/CsrFile.scala 22:14]
  input         io_wrEn, // @[src/main/scala/rv32i/CsrFile.scala 22:14]
  output [31:0] io_rdata, // @[src/main/scala/rv32i/CsrFile.scala 22:14]
  output        io_illegal, // @[src/main/scala/rv32i/CsrFile.scala 22:14]
  input         io_commit, // @[src/main/scala/rv32i/CsrFile.scala 22:14]
  input         io_trapEnter, // @[src/main/scala/rv32i/CsrFile.scala 22:14]
  input  [31:0] io_trapCause, // @[src/main/scala/rv32i/CsrFile.scala 22:14]
  input  [31:0] io_trapPc, // @[src/main/scala/rv32i/CsrFile.scala 22:14]
  input  [31:0] io_trapVal, // @[src/main/scala/rv32i/CsrFile.scala 22:14]
  input         io_mretEnter, // @[src/main/scala/rv32i/CsrFile.scala 22:14]
  output [31:0] io_mtvecBase, // @[src/main/scala/rv32i/CsrFile.scala 22:14]
  output [31:0] io_mepc, // @[src/main/scala/rv32i/CsrFile.scala 22:14]
  input  [4:0]  io_fflagsSet, // @[src/main/scala/rv32i/CsrFile.scala 22:14]
  output [2:0]  io_frm // @[src/main/scala/rv32i/CsrFile.scala 22:14]
);
`ifdef RANDOMIZE_REG_INIT
  reg [31:0] _RAND_0;
  reg [31:0] _RAND_1;
  reg [31:0] _RAND_2;
  reg [31:0] _RAND_3;
  reg [31:0] _RAND_4;
  reg [31:0] _RAND_5;
  reg [31:0] _RAND_6;
  reg [31:0] _RAND_7;
  reg [63:0] _RAND_8;
  reg [63:0] _RAND_9;
  reg [31:0] _RAND_10;
  reg [31:0] _RAND_11;
`endif // RANDOMIZE_REG_INIT
  reg  mie_; // @[src/main/scala/rv32i/CsrFile.scala 42:25]
  reg  mpie; // @[src/main/scala/rv32i/CsrFile.scala 43:25]
  reg [31:0] mieReg; // @[src/main/scala/rv32i/CsrFile.scala 44:25]
  reg [31:0] mtvec; // @[src/main/scala/rv32i/CsrFile.scala 45:25]
  reg [31:0] mscratch; // @[src/main/scala/rv32i/CsrFile.scala 46:25]
  reg [31:0] mepc; // @[src/main/scala/rv32i/CsrFile.scala 47:25]
  reg [31:0] mcause; // @[src/main/scala/rv32i/CsrFile.scala 48:25]
  reg [31:0] mtval; // @[src/main/scala/rv32i/CsrFile.scala 49:25]
  reg [63:0] mcycle; // @[src/main/scala/rv32i/CsrFile.scala 50:25]
  reg [63:0] minstret; // @[src/main/scala/rv32i/CsrFile.scala 51:25]
  reg [4:0] fflags; // @[src/main/scala/rv32i/CsrFile.scala 52:25]
  reg [2:0] frmReg; // @[src/main/scala/rv32i/CsrFile.scala 53:25]
  wire [31:0] mstatus = {24'h800078,mpie,3'h0,mie_,3'h0}; // @[src/main/scala/rv32i/CsrFile.scala 56:20]
  wire [31:0] _T = {27'h0,fflags}; // @[src/main/scala/rv32i/CsrFile.scala 60:23]
  wire [31:0] _T_1 = {29'h0,frmReg}; // @[src/main/scala/rv32i/CsrFile.scala 61:23]
  wire [31:0] _T_2 = {24'h0,frmReg,fflags}; // @[src/main/scala/rv32i/CsrFile.scala 62:23]
  wire  hit_0 = io_addr == 12'h1; // @[src/main/scala/rv32i/CsrFile.scala 87:53]
  wire  hit_1 = io_addr == 12'h2; // @[src/main/scala/rv32i/CsrFile.scala 87:53]
  wire  hit_2 = io_addr == 12'h3; // @[src/main/scala/rv32i/CsrFile.scala 87:53]
  wire  hit_3 = io_addr == 12'h300; // @[src/main/scala/rv32i/CsrFile.scala 87:53]
  wire  hit_4 = io_addr == 12'h301; // @[src/main/scala/rv32i/CsrFile.scala 87:53]
  wire  hit_5 = io_addr == 12'h304; // @[src/main/scala/rv32i/CsrFile.scala 87:53]
  wire  hit_6 = io_addr == 12'h305; // @[src/main/scala/rv32i/CsrFile.scala 87:53]
  wire  hit_7 = io_addr == 12'h310; // @[src/main/scala/rv32i/CsrFile.scala 87:53]
  wire  hit_8 = io_addr == 12'h340; // @[src/main/scala/rv32i/CsrFile.scala 87:53]
  wire  hit_9 = io_addr == 12'h341; // @[src/main/scala/rv32i/CsrFile.scala 87:53]
  wire  hit_10 = io_addr == 12'h342; // @[src/main/scala/rv32i/CsrFile.scala 87:53]
  wire  hit_11 = io_addr == 12'h343; // @[src/main/scala/rv32i/CsrFile.scala 87:53]
  wire  hit_12 = io_addr == 12'h344; // @[src/main/scala/rv32i/CsrFile.scala 87:53]
  wire  hit_13 = io_addr == 12'hb00; // @[src/main/scala/rv32i/CsrFile.scala 87:53]
  wire  hit_14 = io_addr == 12'hb80; // @[src/main/scala/rv32i/CsrFile.scala 87:53]
  wire  hit_15 = io_addr == 12'hb02; // @[src/main/scala/rv32i/CsrFile.scala 87:53]
  wire  hit_16 = io_addr == 12'hb82; // @[src/main/scala/rv32i/CsrFile.scala 87:53]
  wire  hit_17 = io_addr == 12'hc00; // @[src/main/scala/rv32i/CsrFile.scala 87:53]
  wire  hit_18 = io_addr == 12'hc80; // @[src/main/scala/rv32i/CsrFile.scala 87:53]
  wire  hit_19 = io_addr == 12'hc02; // @[src/main/scala/rv32i/CsrFile.scala 87:53]
  wire  hit_20 = io_addr == 12'hc82; // @[src/main/scala/rv32i/CsrFile.scala 87:53]
  wire  hit_21 = io_addr == 12'hf11; // @[src/main/scala/rv32i/CsrFile.scala 87:53]
  wire  hit_22 = io_addr == 12'hf12; // @[src/main/scala/rv32i/CsrFile.scala 87:53]
  wire  hit_23 = io_addr == 12'hf13; // @[src/main/scala/rv32i/CsrFile.scala 87:53]
  wire  hit_24 = io_addr == 12'hf14; // @[src/main/scala/rv32i/CsrFile.scala 87:53]
  wire  known = hit_0 | hit_1 | hit_2 | hit_3 | hit_4 | hit_5 | hit_6 | hit_7 | hit_8 | hit_9 | hit_10 | hit_11 | hit_12
     | hit_13 | hit_14 | hit_15 | hit_16 | hit_17 | hit_18 | hit_19 | hit_20 | hit_21 | hit_22 | hit_23 | hit_24; // @[src/main/scala/rv32i/CsrFile.scala 88:31]
  wire [31:0] _old_T = hit_0 ? _T : 32'h0; // @[src/main/scala/chisel3/util/Mux.scala 30:73]
  wire [31:0] _old_T_1 = hit_1 ? _T_1 : 32'h0; // @[src/main/scala/chisel3/util/Mux.scala 30:73]
  wire [31:0] _old_T_2 = hit_2 ? _T_2 : 32'h0; // @[src/main/scala/chisel3/util/Mux.scala 30:73]
  wire [31:0] _old_T_3 = hit_3 ? mstatus : 32'h0; // @[src/main/scala/chisel3/util/Mux.scala 30:73]
  wire [31:0] _old_T_4 = hit_4 ? 32'h40001120 : 32'h0; // @[src/main/scala/chisel3/util/Mux.scala 30:73]
  wire [31:0] _old_T_5 = hit_5 ? mieReg : 32'h0; // @[src/main/scala/chisel3/util/Mux.scala 30:73]
  wire [31:0] _old_T_6 = hit_6 ? mtvec : 32'h0; // @[src/main/scala/chisel3/util/Mux.scala 30:73]
  wire [31:0] _old_T_8 = hit_8 ? mscratch : 32'h0; // @[src/main/scala/chisel3/util/Mux.scala 30:73]
  wire [31:0] _old_T_9 = hit_9 ? mepc : 32'h0; // @[src/main/scala/chisel3/util/Mux.scala 30:73]
  wire [31:0] _old_T_10 = hit_10 ? mcause : 32'h0; // @[src/main/scala/chisel3/util/Mux.scala 30:73]
  wire [31:0] _old_T_11 = hit_11 ? mtval : 32'h0; // @[src/main/scala/chisel3/util/Mux.scala 30:73]
  wire [31:0] _old_T_13 = hit_13 ? mcycle[31:0] : 32'h0; // @[src/main/scala/chisel3/util/Mux.scala 30:73]
  wire [31:0] _old_T_14 = hit_14 ? mcycle[63:32] : 32'h0; // @[src/main/scala/chisel3/util/Mux.scala 30:73]
  wire [31:0] _old_T_15 = hit_15 ? minstret[31:0] : 32'h0; // @[src/main/scala/chisel3/util/Mux.scala 30:73]
  wire [31:0] _old_T_16 = hit_16 ? minstret[63:32] : 32'h0; // @[src/main/scala/chisel3/util/Mux.scala 30:73]
  wire [31:0] _old_T_17 = hit_17 ? mcycle[31:0] : 32'h0; // @[src/main/scala/chisel3/util/Mux.scala 30:73]
  wire [31:0] _old_T_18 = hit_18 ? mcycle[63:32] : 32'h0; // @[src/main/scala/chisel3/util/Mux.scala 30:73]
  wire [31:0] _old_T_19 = hit_19 ? minstret[31:0] : 32'h0; // @[src/main/scala/chisel3/util/Mux.scala 30:73]
  wire [31:0] _old_T_20 = hit_20 ? minstret[63:32] : 32'h0; // @[src/main/scala/chisel3/util/Mux.scala 30:73]
  wire [31:0] _old_T_25 = _old_T | _old_T_1; // @[src/main/scala/chisel3/util/Mux.scala 30:73]
  wire [31:0] _old_T_26 = _old_T_25 | _old_T_2; // @[src/main/scala/chisel3/util/Mux.scala 30:73]
  wire [31:0] _old_T_27 = _old_T_26 | _old_T_3; // @[src/main/scala/chisel3/util/Mux.scala 30:73]
  wire [31:0] _old_T_28 = _old_T_27 | _old_T_4; // @[src/main/scala/chisel3/util/Mux.scala 30:73]
  wire [31:0] _old_T_29 = _old_T_28 | _old_T_5; // @[src/main/scala/chisel3/util/Mux.scala 30:73]
  wire [31:0] _old_T_30 = _old_T_29 | _old_T_6; // @[src/main/scala/chisel3/util/Mux.scala 30:73]
  wire [31:0] _old_T_32 = _old_T_30 | _old_T_8; // @[src/main/scala/chisel3/util/Mux.scala 30:73]
  wire [31:0] _old_T_33 = _old_T_32 | _old_T_9; // @[src/main/scala/chisel3/util/Mux.scala 30:73]
  wire [31:0] _old_T_34 = _old_T_33 | _old_T_10; // @[src/main/scala/chisel3/util/Mux.scala 30:73]
  wire [31:0] _old_T_35 = _old_T_34 | _old_T_11; // @[src/main/scala/chisel3/util/Mux.scala 30:73]
  wire [31:0] _old_T_37 = _old_T_35 | _old_T_13; // @[src/main/scala/chisel3/util/Mux.scala 30:73]
  wire [31:0] _old_T_38 = _old_T_37 | _old_T_14; // @[src/main/scala/chisel3/util/Mux.scala 30:73]
  wire [31:0] _old_T_39 = _old_T_38 | _old_T_15; // @[src/main/scala/chisel3/util/Mux.scala 30:73]
  wire [31:0] _old_T_40 = _old_T_39 | _old_T_16; // @[src/main/scala/chisel3/util/Mux.scala 30:73]
  wire [31:0] _old_T_41 = _old_T_40 | _old_T_17; // @[src/main/scala/chisel3/util/Mux.scala 30:73]
  wire [31:0] _old_T_42 = _old_T_41 | _old_T_18; // @[src/main/scala/chisel3/util/Mux.scala 30:73]
  wire [31:0] _old_T_43 = _old_T_42 | _old_T_19; // @[src/main/scala/chisel3/util/Mux.scala 30:73]
  wire [31:0] old = _old_T_43 | _old_T_20; // @[src/main/scala/chisel3/util/Mux.scala 30:73]
  wire  readOnly = io_addr[11:10] == 2'h3; // @[src/main/scala/rv32i/CsrFile.scala 90:34]
  wire [31:0] _wval_T = old | io_src; // @[src/main/scala/rv32i/CsrFile.scala 96:17]
  wire [31:0] _wval_T_1 = ~io_src; // @[src/main/scala/rv32i/CsrFile.scala 97:19]
  wire [31:0] _wval_T_2 = old & _wval_T_1; // @[src/main/scala/rv32i/CsrFile.scala 97:17]
  wire [31:0] _wval_T_6 = 2'h2 == io_op ? _wval_T : io_src; // @[src/main/scala/rv32i/CsrFile.scala 94:38]
  wire [31:0] wval = 2'h3 == io_op ? _wval_T_2 : _wval_T_6; // @[src/main/scala/rv32i/CsrFile.scala 94:38]
  wire  doWrite = io_en & io_wrEn & io_commit & ~io_illegal; // @[src/main/scala/rv32i/CsrFile.scala 99:47]
  wire [63:0] cycleInc = mcycle + 64'h1; // @[src/main/scala/rv32i/CsrFile.scala 103:27]
  wire [63:0] _GEN_20 = {{63'd0}, io_commit}; // @[src/main/scala/rv32i/CsrFile.scala 104:29]
  wire [63:0] instretInc = minstret + _GEN_20; // @[src/main/scala/rv32i/CsrFile.scala 104:29]
  wire  _mcycle_T_1 = doWrite & hit_13; // @[src/main/scala/rv32i/CsrFile.scala 100:34]
  wire [63:0] _mcycle_T_3 = {cycleInc[63:32],wval}; // @[src/main/scala/rv32i/CsrFile.scala 106:24]
  wire  _mcycle_T_5 = doWrite & hit_14; // @[src/main/scala/rv32i/CsrFile.scala 100:34]
  wire [63:0] _mcycle_T_7 = {wval,cycleInc[31:0]}; // @[src/main/scala/rv32i/CsrFile.scala 107:32]
  wire  _minstret_T_1 = doWrite & hit_15; // @[src/main/scala/rv32i/CsrFile.scala 100:34]
  wire [63:0] _minstret_T_3 = {instretInc[63:32],wval}; // @[src/main/scala/rv32i/CsrFile.scala 110:26]
  wire  _minstret_T_5 = doWrite & hit_16; // @[src/main/scala/rv32i/CsrFile.scala 100:34]
  wire [63:0] _minstret_T_7 = {wval,instretInc[31:0]}; // @[src/main/scala/rv32i/CsrFile.scala 111:34]
  wire  _T_12 = doWrite & hit_3; // @[src/main/scala/rv32i/CsrFile.scala 100:34]
  wire  _GEN_1 = _T_12 ? wval[7] : mpie; // @[src/main/scala/rv32i/CsrFile.scala 115:{23,47} 43:25]
  wire  _T_14 = doWrite & hit_5; // @[src/main/scala/rv32i/CsrFile.scala 100:34]
  wire [31:0] _mieReg_T = wval & 32'h888; // @[src/main/scala/rv32i/CsrFile.scala 116:40]
  wire  _T_16 = doWrite & hit_6; // @[src/main/scala/rv32i/CsrFile.scala 100:34]
  wire [31:0] _mtvec_T_1 = {wval[31:2],2'h0}; // @[src/main/scala/rv32i/CsrFile.scala 117:37]
  wire  _T_18 = doWrite & hit_8; // @[src/main/scala/rv32i/CsrFile.scala 100:34]
  wire  _T_20 = doWrite & hit_9; // @[src/main/scala/rv32i/CsrFile.scala 100:34]
  wire  _T_22 = doWrite & hit_10; // @[src/main/scala/rv32i/CsrFile.scala 100:34]
  wire  _T_24 = doWrite & hit_11; // @[src/main/scala/rv32i/CsrFile.scala 100:34]
  wire [4:0] _fflags_T = fflags | io_fflagsSet; // @[src/main/scala/rv32i/CsrFile.scala 125:38]
  wire  _T_26 = doWrite & hit_0; // @[src/main/scala/rv32i/CsrFile.scala 100:34]
  wire  _T_28 = doWrite & hit_1; // @[src/main/scala/rv32i/CsrFile.scala 100:34]
  wire  _T_30 = doWrite & hit_2; // @[src/main/scala/rv32i/CsrFile.scala 100:34]
  wire  _GEN_14 = io_mretEnter | _GEN_1; // @[src/main/scala/rv32i/CsrFile.scala 138:28 140:10]
  assign io_rdata = known ? old : 32'h0; // @[src/main/scala/rv32i/CsrFile.scala 91:20]
  assign io_illegal = io_en & (~known | readOnly & io_wrEn); // @[src/main/scala/rv32i/CsrFile.scala 92:23]
  assign io_mtvecBase = mtvec; // @[src/main/scala/rv32i/CsrFile.scala 143:16]
  assign io_mepc = mepc; // @[src/main/scala/rv32i/CsrFile.scala 144:16]
  assign io_frm = frmReg; // @[src/main/scala/rv32i/CsrFile.scala 129:10]
  always @(posedge clock) begin
    if (reset) begin // @[src/main/scala/rv32i/CsrFile.scala 42:25]
      mie_ <= 1'h0; // @[src/main/scala/rv32i/CsrFile.scala 42:25]
    end else if (io_trapEnter) begin // @[src/main/scala/rv32i/CsrFile.scala 132:22]
      mie_ <= 1'h0; // @[src/main/scala/rv32i/CsrFile.scala 137:12]
    end else if (io_mretEnter) begin // @[src/main/scala/rv32i/CsrFile.scala 138:28]
      mie_ <= mpie; // @[src/main/scala/rv32i/CsrFile.scala 139:10]
    end else if (_T_12) begin // @[src/main/scala/rv32i/CsrFile.scala 115:23]
      mie_ <= wval[3]; // @[src/main/scala/rv32i/CsrFile.scala 115:30]
    end
    if (reset) begin // @[src/main/scala/rv32i/CsrFile.scala 43:25]
      mpie <= 1'h0; // @[src/main/scala/rv32i/CsrFile.scala 43:25]
    end else if (io_trapEnter) begin // @[src/main/scala/rv32i/CsrFile.scala 132:22]
      mpie <= mie_; // @[src/main/scala/rv32i/CsrFile.scala 136:12]
    end else begin
      mpie <= _GEN_14;
    end
    if (reset) begin // @[src/main/scala/rv32i/CsrFile.scala 44:25]
      mieReg <= 32'h0; // @[src/main/scala/rv32i/CsrFile.scala 44:25]
    end else if (_T_14) begin // @[src/main/scala/rv32i/CsrFile.scala 116:23]
      mieReg <= _mieReg_T; // @[src/main/scala/rv32i/CsrFile.scala 116:32]
    end
    if (reset) begin // @[src/main/scala/rv32i/CsrFile.scala 45:25]
      mtvec <= 32'h0; // @[src/main/scala/rv32i/CsrFile.scala 45:25]
    end else if (_T_16) begin // @[src/main/scala/rv32i/CsrFile.scala 117:23]
      mtvec <= _mtvec_T_1; // @[src/main/scala/rv32i/CsrFile.scala 117:31]
    end
    if (reset) begin // @[src/main/scala/rv32i/CsrFile.scala 46:25]
      mscratch <= 32'h0; // @[src/main/scala/rv32i/CsrFile.scala 46:25]
    end else if (_T_18) begin // @[src/main/scala/rv32i/CsrFile.scala 118:24]
      if (2'h3 == io_op) begin // @[src/main/scala/rv32i/CsrFile.scala 94:38]
        mscratch <= _wval_T_2;
      end else if (2'h2 == io_op) begin // @[src/main/scala/rv32i/CsrFile.scala 94:38]
        mscratch <= _wval_T;
      end else begin
        mscratch <= io_src;
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/CsrFile.scala 47:25]
      mepc <= 32'h0; // @[src/main/scala/rv32i/CsrFile.scala 47:25]
    end else if (io_trapEnter) begin // @[src/main/scala/rv32i/CsrFile.scala 132:22]
      mepc <= io_trapPc; // @[src/main/scala/rv32i/CsrFile.scala 133:12]
    end else if (_T_20) begin // @[src/main/scala/rv32i/CsrFile.scala 119:23]
      mepc <= _mtvec_T_1; // @[src/main/scala/rv32i/CsrFile.scala 119:30]
    end
    if (reset) begin // @[src/main/scala/rv32i/CsrFile.scala 48:25]
      mcause <= 32'h0; // @[src/main/scala/rv32i/CsrFile.scala 48:25]
    end else if (io_trapEnter) begin // @[src/main/scala/rv32i/CsrFile.scala 132:22]
      mcause <= io_trapCause; // @[src/main/scala/rv32i/CsrFile.scala 134:12]
    end else if (_T_22) begin // @[src/main/scala/rv32i/CsrFile.scala 120:23]
      if (2'h3 == io_op) begin // @[src/main/scala/rv32i/CsrFile.scala 94:38]
        mcause <= _wval_T_2;
      end else begin
        mcause <= _wval_T_6;
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/CsrFile.scala 49:25]
      mtval <= 32'h0; // @[src/main/scala/rv32i/CsrFile.scala 49:25]
    end else if (io_trapEnter) begin // @[src/main/scala/rv32i/CsrFile.scala 132:22]
      mtval <= io_trapVal; // @[src/main/scala/rv32i/CsrFile.scala 135:12]
    end else if (_T_24) begin // @[src/main/scala/rv32i/CsrFile.scala 121:23]
      if (2'h3 == io_op) begin // @[src/main/scala/rv32i/CsrFile.scala 94:38]
        mtval <= _wval_T_2;
      end else begin
        mtval <= _wval_T_6;
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/CsrFile.scala 50:25]
      mcycle <= 64'h0; // @[src/main/scala/rv32i/CsrFile.scala 50:25]
    end else if (_mcycle_T_1) begin // @[src/main/scala/chisel3/util/Mux.scala 141:16]
      mcycle <= _mcycle_T_3;
    end else if (_mcycle_T_5) begin // @[src/main/scala/chisel3/util/Mux.scala 141:16]
      mcycle <= _mcycle_T_7;
    end else begin
      mcycle <= cycleInc;
    end
    if (reset) begin // @[src/main/scala/rv32i/CsrFile.scala 51:25]
      minstret <= 64'h0; // @[src/main/scala/rv32i/CsrFile.scala 51:25]
    end else if (_minstret_T_1) begin // @[src/main/scala/chisel3/util/Mux.scala 141:16]
      minstret <= _minstret_T_3;
    end else if (_minstret_T_5) begin // @[src/main/scala/chisel3/util/Mux.scala 141:16]
      minstret <= _minstret_T_7;
    end else begin
      minstret <= instretInc;
    end
    if (reset) begin // @[src/main/scala/rv32i/CsrFile.scala 52:25]
      fflags <= 5'h0; // @[src/main/scala/rv32i/CsrFile.scala 52:25]
    end else if (_T_30) begin // @[src/main/scala/rv32i/CsrFile.scala 128:22]
      fflags <= wval[4:0]; // @[src/main/scala/rv32i/CsrFile.scala 128:53]
    end else if (_T_26) begin // @[src/main/scala/rv32i/CsrFile.scala 126:22]
      fflags <= wval[4:0]; // @[src/main/scala/rv32i/CsrFile.scala 126:31]
    end else if (io_commit) begin // @[src/main/scala/rv32i/CsrFile.scala 125:19]
      fflags <= _fflags_T; // @[src/main/scala/rv32i/CsrFile.scala 125:28]
    end
    if (reset) begin // @[src/main/scala/rv32i/CsrFile.scala 53:25]
      frmReg <= 3'h0; // @[src/main/scala/rv32i/CsrFile.scala 53:25]
    end else if (_T_30) begin // @[src/main/scala/rv32i/CsrFile.scala 128:22]
      frmReg <= wval[7:5]; // @[src/main/scala/rv32i/CsrFile.scala 128:31]
    end else if (_T_28) begin // @[src/main/scala/rv32i/CsrFile.scala 127:22]
      frmReg <= wval[2:0]; // @[src/main/scala/rv32i/CsrFile.scala 127:31]
    end
  end
// Register and memory initialization
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif
`ifndef RANDOM
`define RANDOM $random
`endif
`ifdef RANDOMIZE_MEM_INIT
  integer initvar;
`endif
`ifndef SYNTHESIS
`ifdef FIRRTL_BEFORE_INITIAL
`FIRRTL_BEFORE_INITIAL
`endif
initial begin
  `ifdef RANDOMIZE
    `ifdef INIT_RANDOM
      `INIT_RANDOM
    `endif
    `ifndef VERILATOR
      `ifdef RANDOMIZE_DELAY
        #`RANDOMIZE_DELAY begin end
      `else
        #0.002 begin end
      `endif
    `endif
`ifdef RANDOMIZE_REG_INIT
  _RAND_0 = {1{`RANDOM}};
  mie_ = _RAND_0[0:0];
  _RAND_1 = {1{`RANDOM}};
  mpie = _RAND_1[0:0];
  _RAND_2 = {1{`RANDOM}};
  mieReg = _RAND_2[31:0];
  _RAND_3 = {1{`RANDOM}};
  mtvec = _RAND_3[31:0];
  _RAND_4 = {1{`RANDOM}};
  mscratch = _RAND_4[31:0];
  _RAND_5 = {1{`RANDOM}};
  mepc = _RAND_5[31:0];
  _RAND_6 = {1{`RANDOM}};
  mcause = _RAND_6[31:0];
  _RAND_7 = {1{`RANDOM}};
  mtval = _RAND_7[31:0];
  _RAND_8 = {2{`RANDOM}};
  mcycle = _RAND_8[63:0];
  _RAND_9 = {2{`RANDOM}};
  minstret = _RAND_9[63:0];
  _RAND_10 = {1{`RANDOM}};
  fflags = _RAND_10[4:0];
  _RAND_11 = {1{`RANDOM}};
  frmReg = _RAND_11[2:0];
`endif // RANDOMIZE_REG_INIT
  `endif // RANDOMIZE
end // initial
`ifdef FIRRTL_AFTER_INITIAL
`FIRRTL_AFTER_INITIAL
`endif
`endif // SYNTHESIS
endmodule
module Multiplier(
  input  [1:0]  io_fn, // @[src/main/scala/rv32i/Multiplier.scala 17:14]
  input  [31:0] io_a, // @[src/main/scala/rv32i/Multiplier.scala 17:14]
  input  [31:0] io_b, // @[src/main/scala/rv32i/Multiplier.scala 17:14]
  output [31:0] io_result // @[src/main/scala/rv32i/Multiplier.scala 17:14]
);
  wire  _aSigned_T = io_fn == 2'h1; // @[src/main/scala/rv32i/Multiplier.scala 24:23]
  wire  aSigned = io_fn == 2'h1 | io_fn == 2'h2; // @[src/main/scala/rv32i/Multiplier.scala 24:31]
  wire  _aExt_T_1 = aSigned & io_a[31]; // @[src/main/scala/rv32i/Multiplier.scala 26:29]
  wire [32:0] aExt = {_aExt_T_1,io_a}; // @[src/main/scala/rv32i/Multiplier.scala 26:48]
  wire  _bExt_T_1 = _aSigned_T & io_b[31]; // @[src/main/scala/rv32i/Multiplier.scala 27:29]
  wire [32:0] bExt = {_bExt_T_1,io_b}; // @[src/main/scala/rv32i/Multiplier.scala 27:48]
  wire [65:0] product = $signed(aExt) * $signed(bExt); // @[src/main/scala/rv32i/Multiplier.scala 28:31]
  assign io_result = io_fn == 2'h0 ? product[31:0] : product[63:32]; // @[src/main/scala/rv32i/Multiplier.scala 30:19]
endmodule
module DivUnit(
  input         clock,
  input         reset,
  output        io_req_ready, // @[src/main/scala/rv32i/DivUnit.scala 37:14]
  input         io_req_valid, // @[src/main/scala/rv32i/DivUnit.scala 37:14]
  input  [1:0]  io_req_bits_op, // @[src/main/scala/rv32i/DivUnit.scala 37:14]
  input  [31:0] io_req_bits_a, // @[src/main/scala/rv32i/DivUnit.scala 37:14]
  input  [31:0] io_req_bits_b, // @[src/main/scala/rv32i/DivUnit.scala 37:14]
  output        io_resp_valid, // @[src/main/scala/rv32i/DivUnit.scala 37:14]
  output [31:0] io_resp_bits, // @[src/main/scala/rv32i/DivUnit.scala 37:14]
  input         io_kill, // @[src/main/scala/rv32i/DivUnit.scala 37:14]
  output        io_busy // @[src/main/scala/rv32i/DivUnit.scala 37:14]
);
`ifdef RANDOMIZE_REG_INIT
  reg [31:0] _RAND_0;
  reg [31:0] _RAND_1;
  reg [31:0] _RAND_2;
  reg [31:0] _RAND_3;
  reg [31:0] _RAND_4;
  reg [31:0] _RAND_5;
  reg [31:0] _RAND_6;
  reg [31:0] _RAND_7;
  reg [31:0] _RAND_8;
`endif // RANDOMIZE_REG_INIT
  reg [1:0] state; // @[src/main/scala/rv32i/DivUnit.scala 45:30]
  reg [31:0] quot; // @[src/main/scala/rv32i/DivUnit.scala 50:28]
  reg [31:0] rem; // @[src/main/scala/rv32i/DivUnit.scala 51:28]
  reg [31:0] divisor; // @[src/main/scala/rv32i/DivUnit.scala 52:28]
  reg [4:0] count; // @[src/main/scala/rv32i/DivUnit.scala 53:28]
  reg  negQ; // @[src/main/scala/rv32i/DivUnit.scala 54:28]
  reg  negR; // @[src/main/scala/rv32i/DivUnit.scala 55:28]
  reg  wantRem; // @[src/main/scala/rv32i/DivUnit.scala 56:28]
  reg [31:0] result; // @[src/main/scala/rv32i/DivUnit.scala 57:28]
  wire  _io_resp_valid_T = state == 2'h2; // @[src/main/scala/rv32i/DivUnit.scala 60:26]
  wire  _T = io_req_ready & io_req_valid; // @[src/main/scala/chisel3/util/Decoupled.scala 57:35]
  wire  signed_ = ~io_req_bits_op[0]; // @[src/main/scala/rv32i/DivUnit.scala 68:18]
  wire  isRem = io_req_bits_op[1]; // @[src/main/scala/rv32i/DivUnit.scala 69:32]
  wire  negA = signed_ & io_req_bits_a[31]; // @[src/main/scala/rv32i/DivUnit.scala 70:25]
  wire  negB = signed_ & io_req_bits_b[31]; // @[src/main/scala/rv32i/DivUnit.scala 71:25]
  wire [31:0] _quot_T_1 = 32'h0 - io_req_bits_a; // @[src/main/scala/rv32i/DivUnit.scala 76:38]
  wire [31:0] _divisor_T_1 = 32'h0 - io_req_bits_b; // @[src/main/scala/rv32i/DivUnit.scala 77:38]
  wire [31:0] _result_T = isRem ? io_req_bits_a : 32'hffffffff; // @[src/main/scala/rv32i/DivUnit.scala 82:20]
  wire [31:0] _result_T_1 = isRem ? 32'h0 : 32'h80000000; // @[src/main/scala/rv32i/DivUnit.scala 85:20]
  wire [31:0] _GEN_0 = signed_ & io_req_bits_a == 32'h80000000 & io_req_bits_b == 32'hffffffff ? _result_T_1 : result; // @[src/main/scala/rv32i/DivUnit.scala 84:57 85:14 57:28]
  wire [1:0] _GEN_1 = signed_ & io_req_bits_a == 32'h80000000 & io_req_bits_b == 32'hffffffff ? 2'h2 : 2'h1; // @[src/main/scala/rv32i/DivUnit.scala 84:57 86:14 88:13]
  wire [31:0] _GEN_2 = io_req_bits_b == 32'h0 ? _result_T : _GEN_0; // @[src/main/scala/rv32i/DivUnit.scala 81:21 82:14]
  wire [1:0] _GEN_3 = io_req_bits_b == 32'h0 ? 2'h2 : _GEN_1; // @[src/main/scala/rv32i/DivUnit.scala 81:21 83:14]
  wire [31:0] _GEN_11 = _T ? _GEN_2 : result; // @[src/main/scala/rv32i/DivUnit.scala 65:21 57:28]
  wire [1:0] _GEN_12 = _T ? _GEN_3 : state; // @[src/main/scala/rv32i/DivUnit.scala 65:21 45:30]
  wire [32:0] shifted = {rem,quot[31]}; // @[src/main/scala/rv32i/DivUnit.scala 94:23]
  wire [32:0] _GEN_22 = {{1'd0}, divisor}; // @[src/main/scala/rv32i/DivUnit.scala 95:28]
  wire  fits = shifted >= _GEN_22; // @[src/main/scala/rv32i/DivUnit.scala 95:28]
  wire [32:0] _nextRem_T_1 = shifted - _GEN_22; // @[src/main/scala/rv32i/DivUnit.scala 96:38]
  wire [32:0] _nextRem_T_2 = fits ? _nextRem_T_1 : shifted; // @[src/main/scala/rv32i/DivUnit.scala 96:23]
  wire [31:0] nextRem = _nextRem_T_2[31:0]; // @[src/main/scala/rv32i/DivUnit.scala 96:57]
  wire [31:0] nextQuot = {quot[30:0],fits}; // @[src/main/scala/rv32i/DivUnit.scala 97:23]
  wire [4:0] _count_T_1 = count + 5'h1; // @[src/main/scala/rv32i/DivUnit.scala 101:20]
  wire [31:0] _q_T_1 = 32'h0 - nextQuot; // @[src/main/scala/rv32i/DivUnit.scala 104:37]
  wire [31:0] _r_T_1 = 32'h0 - nextRem; // @[src/main/scala/rv32i/DivUnit.scala 105:37]
  wire [1:0] _GEN_14 = count == 5'h1f ? 2'h2 : _GEN_12; // @[src/main/scala/rv32i/DivUnit.scala 103:34 107:14]
  assign io_req_ready = state == 2'h0; // @[src/main/scala/rv32i/DivUnit.scala 59:26]
  assign io_resp_valid = state == 2'h2; // @[src/main/scala/rv32i/DivUnit.scala 60:26]
  assign io_resp_bits = result; // @[src/main/scala/rv32i/DivUnit.scala 61:17]
  assign io_busy = state != 2'h0; // @[src/main/scala/rv32i/DivUnit.scala 62:26]
  always @(posedge clock) begin
    if (reset) begin // @[src/main/scala/rv32i/DivUnit.scala 45:30]
      state <= 2'h0; // @[src/main/scala/rv32i/DivUnit.scala 45:30]
    end else if (io_kill) begin // @[src/main/scala/rv32i/DivUnit.scala 115:17]
      state <= 2'h0; // @[src/main/scala/rv32i/DivUnit.scala 116:11]
    end else if (_io_resp_valid_T) begin // @[src/main/scala/rv32i/DivUnit.scala 111:25]
      state <= 2'h0; // @[src/main/scala/rv32i/DivUnit.scala 112:11]
    end else if (state == 2'h1) begin // @[src/main/scala/rv32i/DivUnit.scala 93:25]
      state <= _GEN_14;
    end else begin
      state <= _GEN_12;
    end
    if (state == 2'h1) begin // @[src/main/scala/rv32i/DivUnit.scala 93:25]
      quot <= nextQuot; // @[src/main/scala/rv32i/DivUnit.scala 100:11]
    end else if (_T) begin // @[src/main/scala/rv32i/DivUnit.scala 65:21]
      if (negA) begin // @[src/main/scala/rv32i/DivUnit.scala 76:19]
        quot <= _quot_T_1;
      end else begin
        quot <= io_req_bits_a;
      end
    end
    if (state == 2'h1) begin // @[src/main/scala/rv32i/DivUnit.scala 93:25]
      rem <= nextRem; // @[src/main/scala/rv32i/DivUnit.scala 99:11]
    end else if (_T) begin // @[src/main/scala/rv32i/DivUnit.scala 65:21]
      rem <= 32'h0; // @[src/main/scala/rv32i/DivUnit.scala 78:13]
    end
    if (_T) begin // @[src/main/scala/rv32i/DivUnit.scala 65:21]
      if (negB) begin // @[src/main/scala/rv32i/DivUnit.scala 77:19]
        divisor <= _divisor_T_1;
      end else begin
        divisor <= io_req_bits_b;
      end
    end
    if (state == 2'h1) begin // @[src/main/scala/rv32i/DivUnit.scala 93:25]
      count <= _count_T_1; // @[src/main/scala/rv32i/DivUnit.scala 101:11]
    end else if (_T) begin // @[src/main/scala/rv32i/DivUnit.scala 65:21]
      count <= 5'h0; // @[src/main/scala/rv32i/DivUnit.scala 79:13]
    end
    if (_T) begin // @[src/main/scala/rv32i/DivUnit.scala 65:21]
      negQ <= negA != negB; // @[src/main/scala/rv32i/DivUnit.scala 74:13]
    end
    if (_T) begin // @[src/main/scala/rv32i/DivUnit.scala 65:21]
      negR <= negA; // @[src/main/scala/rv32i/DivUnit.scala 75:13]
    end
    if (_T) begin // @[src/main/scala/rv32i/DivUnit.scala 65:21]
      wantRem <= isRem; // @[src/main/scala/rv32i/DivUnit.scala 73:13]
    end
    if (state == 2'h1) begin // @[src/main/scala/rv32i/DivUnit.scala 93:25]
      if (count == 5'h1f) begin // @[src/main/scala/rv32i/DivUnit.scala 103:34]
        if (wantRem) begin // @[src/main/scala/rv32i/DivUnit.scala 106:20]
          if (negR) begin // @[src/main/scala/rv32i/DivUnit.scala 105:18]
            result <= _r_T_1;
          end else begin
            result <= nextRem;
          end
        end else if (negQ) begin // @[src/main/scala/rv32i/DivUnit.scala 104:18]
          result <= _q_T_1;
        end else begin
          result <= nextQuot;
        end
      end else begin
        result <= _GEN_11;
      end
    end else begin
      result <= _GEN_11;
    end
  end
// Register and memory initialization
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif
`ifndef RANDOM
`define RANDOM $random
`endif
`ifdef RANDOMIZE_MEM_INIT
  integer initvar;
`endif
`ifndef SYNTHESIS
`ifdef FIRRTL_BEFORE_INITIAL
`FIRRTL_BEFORE_INITIAL
`endif
initial begin
  `ifdef RANDOMIZE
    `ifdef INIT_RANDOM
      `INIT_RANDOM
    `endif
    `ifndef VERILATOR
      `ifdef RANDOMIZE_DELAY
        #`RANDOMIZE_DELAY begin end
      `else
        #0.002 begin end
      `endif
    `endif
`ifdef RANDOMIZE_REG_INIT
  _RAND_0 = {1{`RANDOM}};
  state = _RAND_0[1:0];
  _RAND_1 = {1{`RANDOM}};
  quot = _RAND_1[31:0];
  _RAND_2 = {1{`RANDOM}};
  rem = _RAND_2[31:0];
  _RAND_3 = {1{`RANDOM}};
  divisor = _RAND_3[31:0];
  _RAND_4 = {1{`RANDOM}};
  count = _RAND_4[4:0];
  _RAND_5 = {1{`RANDOM}};
  negQ = _RAND_5[0:0];
  _RAND_6 = {1{`RANDOM}};
  negR = _RAND_6[0:0];
  _RAND_7 = {1{`RANDOM}};
  wantRem = _RAND_7[0:0];
  _RAND_8 = {1{`RANDOM}};
  result = _RAND_8[31:0];
`endif // RANDOMIZE_REG_INIT
  `endif // RANDOMIZE
end // initial
`ifdef FIRRTL_AFTER_INITIAL
`FIRRTL_AFTER_INITIAL
`endif
`endif // SYNTHESIS
endmodule
module FDecoder(
  input  [31:0] io_inst, // @[src/main/scala/rv32i/FDecoder.scala 25:14]
  input  [2:0]  io_frm, // @[src/main/scala/rv32i/FDecoder.scala 25:14]
  output        io_isF, // @[src/main/scala/rv32i/FDecoder.scala 25:14]
  output        io_illegal, // @[src/main/scala/rv32i/FDecoder.scala 25:14]
  output [2:0]  io_rm, // @[src/main/scala/rv32i/FDecoder.scala 25:14]
  output        io_useFpu, // @[src/main/scala/rv32i/FDecoder.scala 25:14]
  output [3:0]  io_fpuOp, // @[src/main/scala/rv32i/FDecoder.scala 25:14]
  output        io_useMisc, // @[src/main/scala/rv32i/FDecoder.scala 25:14]
  output [2:0]  io_miscOp, // @[src/main/scala/rv32i/FDecoder.scala 25:14]
  output        io_mvXW, // @[src/main/scala/rv32i/FDecoder.scala 25:14]
  output        io_mvWX, // @[src/main/scala/rv32i/FDecoder.scala 25:14]
  output        io_intSrc, // @[src/main/scala/rv32i/FDecoder.scala 25:14]
  output        io_writesX, // @[src/main/scala/rv32i/FDecoder.scala 25:14]
  output        io_writesF // @[src/main/scala/rv32i/FDecoder.scala 25:14]
);
  wire [6:0] opcode = io_inst[6:0]; // @[src/main/scala/rv32i/FDecoder.scala 45:20]
  wire [2:0] f3 = io_inst[14:12]; // @[src/main/scala/rv32i/FDecoder.scala 46:20]
  wire [4:0] rs2 = io_inst[24:20]; // @[src/main/scala/rv32i/FDecoder.scala 47:20]
  wire [6:0] f7 = io_inst[31:25]; // @[src/main/scala/rv32i/FDecoder.scala 48:20]
  wire  fmtS = io_inst[26:25] == 2'h0; // @[src/main/scala/rv32i/FDecoder.scala 49:29]
  wire  _rmOk_T_1 = f3 == 3'h7; // @[src/main/scala/rv32i/FDecoder.scala 52:41]
  wire  rmOk = f3 <= 3'h4 | f3 == 3'h7 & io_frm <= 3'h4; // @[src/main/scala/rv32i/FDecoder.scala 52:29]
  wire  isLoad = opcode == 7'h7; // @[src/main/scala/rv32i/FDecoder.scala 55:24]
  wire  isStore = opcode == 7'h27; // @[src/main/scala/rv32i/FDecoder.scala 56:24]
  wire  isFma = opcode == 7'h43 | opcode == 7'h47 | opcode == 7'h4b | opcode == 7'h4f; // @[src/main/scala/rv32i/FDecoder.scala 57:102]
  wire  isOpFp = opcode == 7'h53; // @[src/main/scala/rv32i/FDecoder.scala 58:24]
  wire  _T = f3 == 3'h2; // @[src/main/scala/rv32i/FDecoder.scala 72:21]
  wire  _T_1 = isLoad & f3 == 3'h2; // @[src/main/scala/rv32i/FDecoder.scala 72:15]
  wire  _GEN_1 = isStore & _T | _T_1; // @[src/main/scala/rv32i/FDecoder.scala 73:{31,39}]
  wire  _T_4 = isFma & fmtS; // @[src/main/scala/rv32i/FDecoder.scala 74:14]
  wire [2:0] _op_T_3 = 7'h47 == opcode ? 3'h6 : 3'h5; // @[src/main/scala/rv32i/FDecoder.scala 75:45]
  wire [2:0] _op_T_5 = 7'h4b == opcode ? 3'h7 : _op_T_3; // @[src/main/scala/rv32i/FDecoder.scala 75:45]
  wire [3:0] op = 7'h4f == opcode ? 4'h8 : {{1'd0}, _op_T_5}; // @[src/main/scala/rv32i/FDecoder.scala 75:45]
  wire  _GEN_3 = isFma & fmtS ? rmOk : _GEN_1; // @[src/main/scala/rv32i/FDecoder.scala 74:23 78:11]
  wire [3:0] _GEN_5 = isFma & fmtS ? op : 4'h0; // @[src/main/scala/rv32i/FDecoder.scala 74:23 61:34 78:50]
  wire  _GEN_6 = isFma & fmtS | _T_1; // @[src/main/scala/rv32i/FDecoder.scala 74:23 78:68]
  wire  _T_10 = rs2 == 5'h0; // @[src/main/scala/rv32i/FDecoder.scala 86:30]
  wire  _GEN_7 = rs2 == 5'h0 ? rmOk : _GEN_3; // @[src/main/scala/rv32i/FDecoder.scala 69:11 86:39]
  wire  _GEN_8 = rs2 == 5'h0 | _T_4; // @[src/main/scala/rv32i/FDecoder.scala 86:39 69:56]
  wire [3:0] _GEN_9 = rs2 == 5'h0 ? 4'h4 : _GEN_5; // @[src/main/scala/rv32i/FDecoder.scala 86:39 69:76]
  wire  _GEN_10 = rs2 == 5'h0 | _GEN_6; // @[src/main/scala/rv32i/FDecoder.scala 86:39 69:96]
  wire  _T_12 = f3 <= 3'h2; // @[src/main/scala/rv32i/FDecoder.scala 87:29]
  wire  _GEN_11 = f3 <= 3'h2 | _GEN_3; // @[src/main/scala/rv32i/FDecoder.scala 87:{37,45}]
  wire  _GEN_14 = f3 <= 3'h2 | _GEN_6; // @[src/main/scala/rv32i/FDecoder.scala 87:{119,37}]
  wire  _T_14 = f3 <= 3'h1; // @[src/main/scala/rv32i/FDecoder.scala 88:29]
  wire  _GEN_15 = f3 <= 3'h1 | _GEN_3; // @[src/main/scala/rv32i/FDecoder.scala 88:{37,45}]
  wire  _GEN_17 = f3 <= 3'h1 | _GEN_6; // @[src/main/scala/rv32i/FDecoder.scala 88:{121,37}]
  wire [1:0] _GEN_20 = _T_12 ? 2'h2 : 2'h0; // @[src/main/scala/rv32i/FDecoder.scala 62:36 89:{37,88}]
  wire  _T_18 = rs2 <= 5'h1; // @[src/main/scala/rv32i/FDecoder.scala 91:18]
  wire [3:0] _io_fpuOp_T_1 = rs2[0] ? 4'ha : 4'h9; // @[src/main/scala/rv32i/FDecoder.scala 91:63]
  wire  _GEN_21 = rs2 <= 5'h1 ? rmOk : _GEN_3; // @[src/main/scala/rv32i/FDecoder.scala 69:11 91:26]
  wire  _GEN_22 = rs2 <= 5'h1 | _T_4; // @[src/main/scala/rv32i/FDecoder.scala 91:26 69:56]
  wire [3:0] _GEN_23 = rs2 <= 5'h1 ? _io_fpuOp_T_1 : _GEN_5; // @[src/main/scala/rv32i/FDecoder.scala 91:{26,57}]
  wire  _GEN_24 = rs2 <= 5'h1 ? 1'h0 : _GEN_6; // @[src/main/scala/rv32i/FDecoder.scala 91:{119,26}]
  wire [3:0] _io_fpuOp_T_3 = rs2[0] ? 4'hc : 4'hb; // @[src/main/scala/rv32i/FDecoder.scala 94:63]
  wire [3:0] _GEN_28 = _T_18 ? _io_fpuOp_T_3 : _GEN_5; // @[src/main/scala/rv32i/FDecoder.scala 94:{26,57}]
  wire  _GEN_29 = _T_18 | _GEN_6; // @[src/main/scala/rv32i/FDecoder.scala 94:26 69:96]
  wire  _T_24 = _T_10 & f3 == 3'h0; // @[src/main/scala/rv32i/FDecoder.scala 97:26]
  wire  _GEN_31 = _T_10 & f3 == 3'h0 | _GEN_3; // @[src/main/scala/rv32i/FDecoder.scala 97:{41,49}]
  wire  _T_27 = _T_10 & f3 == 3'h1; // @[src/main/scala/rv32i/FDecoder.scala 98:26]
  wire  _GEN_33 = _T_10 & f3 == 3'h1 | _GEN_31; // @[src/main/scala/rv32i/FDecoder.scala 98:{41,49}]
  wire [1:0] _GEN_35 = _T_10 & f3 == 3'h1 ? 2'h3 : 2'h0; // @[src/main/scala/rv32i/FDecoder.scala 62:36 98:{41,92}]
  wire  _GEN_36 = _T_10 & f3 == 3'h1 | _T_24; // @[src/main/scala/rv32i/FDecoder.scala 98:{124,41}]
  wire  _GEN_39 = _T_24 | _GEN_6; // @[src/main/scala/rv32i/FDecoder.scala 100:{102,53}]
  wire  _GEN_40 = 7'h78 == f7 ? _GEN_31 : _GEN_3; // @[src/main/scala/rv32i/FDecoder.scala 81:16]
  wire  _GEN_42 = 7'h78 == f7 ? _GEN_39 : _GEN_6; // @[src/main/scala/rv32i/FDecoder.scala 81:16]
  wire  _GEN_43 = 7'h70 == f7 ? _GEN_33 : _GEN_40; // @[src/main/scala/rv32i/FDecoder.scala 81:16]
  wire [1:0] _GEN_47 = 7'h70 == f7 ? _GEN_35 : 2'h0; // @[src/main/scala/rv32i/FDecoder.scala 81:16 62:36]
  wire  _GEN_48 = 7'h70 == f7 ? 1'h0 : 7'h78 == f7 & _T_24; // @[src/main/scala/rv32i/FDecoder.scala 81:16 63:31]
  wire  _GEN_49 = 7'h70 == f7 ? _GEN_6 : _GEN_42; // @[src/main/scala/rv32i/FDecoder.scala 81:16]
  wire  _GEN_50 = 7'h68 == f7 ? _GEN_21 : _GEN_43; // @[src/main/scala/rv32i/FDecoder.scala 81:16]
  wire  _GEN_51 = 7'h68 == f7 ? _GEN_22 : _T_4; // @[src/main/scala/rv32i/FDecoder.scala 81:16]
  wire [3:0] _GEN_52 = 7'h68 == f7 ? _GEN_28 : _GEN_5; // @[src/main/scala/rv32i/FDecoder.scala 81:16]
  wire  _GEN_53 = 7'h68 == f7 ? _GEN_29 : _GEN_49; // @[src/main/scala/rv32i/FDecoder.scala 81:16]
  wire  _GEN_54 = 7'h68 == f7 ? _T_18 : _GEN_48; // @[src/main/scala/rv32i/FDecoder.scala 81:16]
  wire  _GEN_55 = 7'h68 == f7 ? 1'h0 : 7'h70 == f7 & _T_24; // @[src/main/scala/rv32i/FDecoder.scala 63:11 81:16]
  wire  _GEN_56 = 7'h68 == f7 ? 1'h0 : 7'h70 == f7 & _GEN_36; // @[src/main/scala/rv32i/FDecoder.scala 81:16 65:36]
  wire  _GEN_57 = 7'h68 == f7 ? 1'h0 : 7'h70 == f7 & _T_27; // @[src/main/scala/rv32i/FDecoder.scala 62:14 81:16]
  wire [1:0] _GEN_58 = 7'h68 == f7 ? 2'h0 : _GEN_47; // @[src/main/scala/rv32i/FDecoder.scala 81:16 62:36]
  wire  _GEN_59 = 7'h68 == f7 ? 1'h0 : _GEN_48; // @[src/main/scala/rv32i/FDecoder.scala 81:16 63:31]
  wire  _GEN_60 = 7'h60 == f7 ? _GEN_21 : _GEN_50; // @[src/main/scala/rv32i/FDecoder.scala 81:16]
  wire  _GEN_61 = 7'h60 == f7 ? _GEN_22 : _GEN_51; // @[src/main/scala/rv32i/FDecoder.scala 81:16]
  wire [3:0] _GEN_62 = 7'h60 == f7 ? _GEN_23 : _GEN_52; // @[src/main/scala/rv32i/FDecoder.scala 81:16]
  wire  _GEN_63 = 7'h60 == f7 ? _GEN_24 : _GEN_53; // @[src/main/scala/rv32i/FDecoder.scala 81:16]
  wire  _GEN_64 = 7'h60 == f7 ? _T_18 : _GEN_56; // @[src/main/scala/rv32i/FDecoder.scala 81:16]
  wire  _GEN_65 = 7'h60 == f7 ? 1'h0 : _GEN_54; // @[src/main/scala/rv32i/FDecoder.scala 65:13 81:16]
  wire  _GEN_66 = 7'h60 == f7 ? 1'h0 : _GEN_55; // @[src/main/scala/rv32i/FDecoder.scala 63:11 81:16]
  wire  _GEN_67 = 7'h60 == f7 ? 1'h0 : _GEN_57; // @[src/main/scala/rv32i/FDecoder.scala 62:14 81:16]
  wire [1:0] _GEN_68 = 7'h60 == f7 ? 2'h0 : _GEN_58; // @[src/main/scala/rv32i/FDecoder.scala 81:16 62:36]
  wire  _GEN_69 = 7'h60 == f7 ? 1'h0 : _GEN_59; // @[src/main/scala/rv32i/FDecoder.scala 81:16 63:31]
  wire  _GEN_70 = 7'h50 == f7 ? _GEN_11 : _GEN_60; // @[src/main/scala/rv32i/FDecoder.scala 81:16]
  wire  _GEN_71 = 7'h50 == f7 ? _T_12 : _GEN_67; // @[src/main/scala/rv32i/FDecoder.scala 81:16]
  wire [1:0] _GEN_72 = 7'h50 == f7 ? _GEN_20 : _GEN_68; // @[src/main/scala/rv32i/FDecoder.scala 81:16]
  wire  _GEN_73 = 7'h50 == f7 ? _T_12 : _GEN_64; // @[src/main/scala/rv32i/FDecoder.scala 81:16]
  wire  _GEN_74 = 7'h50 == f7 ? _T_4 : _GEN_61; // @[src/main/scala/rv32i/FDecoder.scala 81:16]
  wire [3:0] _GEN_75 = 7'h50 == f7 ? _GEN_5 : _GEN_62; // @[src/main/scala/rv32i/FDecoder.scala 81:16]
  wire  _GEN_76 = 7'h50 == f7 ? _GEN_6 : _GEN_63; // @[src/main/scala/rv32i/FDecoder.scala 81:16]
  wire  _GEN_77 = 7'h50 == f7 ? 1'h0 : _GEN_65; // @[src/main/scala/rv32i/FDecoder.scala 65:13 81:16]
  wire  _GEN_78 = 7'h50 == f7 ? 1'h0 : _GEN_66; // @[src/main/scala/rv32i/FDecoder.scala 63:11 81:16]
  wire  _GEN_79 = 7'h50 == f7 ? 1'h0 : _GEN_69; // @[src/main/scala/rv32i/FDecoder.scala 81:16 63:31]
  wire  _GEN_80 = 7'h14 == f7 ? _GEN_15 : _GEN_70; // @[src/main/scala/rv32i/FDecoder.scala 81:16]
  wire  _GEN_81 = 7'h14 == f7 ? _T_14 : _GEN_71; // @[src/main/scala/rv32i/FDecoder.scala 81:16]
  wire [1:0] _GEN_82 = 7'h14 == f7 ? {{1'd0}, _T_14} : _GEN_72; // @[src/main/scala/rv32i/FDecoder.scala 81:16]
  wire  _GEN_83 = 7'h14 == f7 ? _GEN_17 : _GEN_76; // @[src/main/scala/rv32i/FDecoder.scala 81:16]
  wire  _GEN_84 = 7'h14 == f7 ? 1'h0 : _GEN_73; // @[src/main/scala/rv32i/FDecoder.scala 81:16 65:36]
  wire  _GEN_85 = 7'h14 == f7 ? _T_4 : _GEN_74; // @[src/main/scala/rv32i/FDecoder.scala 81:16]
  wire [3:0] _GEN_86 = 7'h14 == f7 ? _GEN_5 : _GEN_75; // @[src/main/scala/rv32i/FDecoder.scala 81:16]
  wire  _GEN_87 = 7'h14 == f7 ? 1'h0 : _GEN_77; // @[src/main/scala/rv32i/FDecoder.scala 65:13 81:16]
  wire  _GEN_88 = 7'h14 == f7 ? 1'h0 : _GEN_78; // @[src/main/scala/rv32i/FDecoder.scala 63:11 81:16]
  wire  _GEN_89 = 7'h14 == f7 ? 1'h0 : _GEN_79; // @[src/main/scala/rv32i/FDecoder.scala 81:16 63:31]
  wire  _GEN_90 = 7'h10 == f7 ? _GEN_11 : _GEN_80; // @[src/main/scala/rv32i/FDecoder.scala 81:16]
  wire  _GEN_91 = 7'h10 == f7 ? _T_12 : _GEN_81; // @[src/main/scala/rv32i/FDecoder.scala 81:16]
  wire [1:0] _GEN_92 = 7'h10 == f7 ? 2'h0 : _GEN_82; // @[src/main/scala/rv32i/FDecoder.scala 81:16]
  wire  _GEN_93 = 7'h10 == f7 ? _GEN_14 : _GEN_83; // @[src/main/scala/rv32i/FDecoder.scala 81:16]
  wire  _GEN_94 = 7'h10 == f7 ? 1'h0 : _GEN_84; // @[src/main/scala/rv32i/FDecoder.scala 81:16 65:36]
  wire  _GEN_95 = 7'h10 == f7 ? _T_4 : _GEN_85; // @[src/main/scala/rv32i/FDecoder.scala 81:16]
  wire [3:0] _GEN_96 = 7'h10 == f7 ? _GEN_5 : _GEN_86; // @[src/main/scala/rv32i/FDecoder.scala 81:16]
  wire  _GEN_97 = 7'h10 == f7 ? 1'h0 : _GEN_87; // @[src/main/scala/rv32i/FDecoder.scala 65:13 81:16]
  wire  _GEN_98 = 7'h10 == f7 ? 1'h0 : _GEN_88; // @[src/main/scala/rv32i/FDecoder.scala 63:11 81:16]
  wire  _GEN_99 = 7'h10 == f7 ? 1'h0 : _GEN_89; // @[src/main/scala/rv32i/FDecoder.scala 81:16 63:31]
  wire  _GEN_100 = 7'h2c == f7 ? _GEN_7 : _GEN_90; // @[src/main/scala/rv32i/FDecoder.scala 81:16]
  wire  _GEN_101 = 7'h2c == f7 ? _GEN_8 : _GEN_95; // @[src/main/scala/rv32i/FDecoder.scala 81:16]
  wire [3:0] _GEN_102 = 7'h2c == f7 ? _GEN_9 : _GEN_96; // @[src/main/scala/rv32i/FDecoder.scala 81:16]
  wire  _GEN_103 = 7'h2c == f7 ? _GEN_10 : _GEN_93; // @[src/main/scala/rv32i/FDecoder.scala 81:16]
  wire  _GEN_104 = 7'h2c == f7 ? 1'h0 : _GEN_91; // @[src/main/scala/rv32i/FDecoder.scala 62:14 81:16]
  wire [1:0] _GEN_105 = 7'h2c == f7 ? 2'h0 : _GEN_92; // @[src/main/scala/rv32i/FDecoder.scala 81:16 62:36]
  wire  _GEN_106 = 7'h2c == f7 ? 1'h0 : _GEN_94; // @[src/main/scala/rv32i/FDecoder.scala 81:16 65:36]
  wire  _GEN_107 = 7'h2c == f7 ? 1'h0 : _GEN_97; // @[src/main/scala/rv32i/FDecoder.scala 65:13 81:16]
  wire  _GEN_108 = 7'h2c == f7 ? 1'h0 : _GEN_98; // @[src/main/scala/rv32i/FDecoder.scala 63:11 81:16]
  wire  _GEN_109 = 7'h2c == f7 ? 1'h0 : _GEN_99; // @[src/main/scala/rv32i/FDecoder.scala 81:16 63:31]
  wire  _GEN_110 = 7'hc == f7 ? rmOk : _GEN_100; // @[src/main/scala/rv32i/FDecoder.scala 69:11 81:16]
  wire [3:0] _GEN_112 = 7'hc == f7 ? 4'h3 : _GEN_102; // @[src/main/scala/rv32i/FDecoder.scala 81:16 69:76]
  wire  _GEN_114 = 7'hc == f7 ? 1'h0 : _GEN_104; // @[src/main/scala/rv32i/FDecoder.scala 62:14 81:16]
  wire [1:0] _GEN_115 = 7'hc == f7 ? 2'h0 : _GEN_105; // @[src/main/scala/rv32i/FDecoder.scala 81:16 62:36]
  wire  _GEN_116 = 7'hc == f7 ? 1'h0 : _GEN_106; // @[src/main/scala/rv32i/FDecoder.scala 81:16 65:36]
  wire  _GEN_117 = 7'hc == f7 ? 1'h0 : _GEN_107; // @[src/main/scala/rv32i/FDecoder.scala 65:13 81:16]
  wire  _GEN_118 = 7'hc == f7 ? 1'h0 : _GEN_108; // @[src/main/scala/rv32i/FDecoder.scala 63:11 81:16]
  wire  _GEN_119 = 7'hc == f7 ? 1'h0 : _GEN_109; // @[src/main/scala/rv32i/FDecoder.scala 81:16 63:31]
  wire  _GEN_120 = 7'h8 == f7 ? rmOk : _GEN_110; // @[src/main/scala/rv32i/FDecoder.scala 69:11 81:16]
  wire [3:0] _GEN_122 = 7'h8 == f7 ? 4'h2 : _GEN_112; // @[src/main/scala/rv32i/FDecoder.scala 81:16 69:76]
  wire  _GEN_124 = 7'h8 == f7 ? 1'h0 : _GEN_114; // @[src/main/scala/rv32i/FDecoder.scala 62:14 81:16]
  wire [1:0] _GEN_125 = 7'h8 == f7 ? 2'h0 : _GEN_115; // @[src/main/scala/rv32i/FDecoder.scala 81:16 62:36]
  wire  _GEN_126 = 7'h8 == f7 ? 1'h0 : _GEN_116; // @[src/main/scala/rv32i/FDecoder.scala 81:16 65:36]
  wire  _GEN_127 = 7'h8 == f7 ? 1'h0 : _GEN_117; // @[src/main/scala/rv32i/FDecoder.scala 65:13 81:16]
  wire  _GEN_128 = 7'h8 == f7 ? 1'h0 : _GEN_118; // @[src/main/scala/rv32i/FDecoder.scala 63:11 81:16]
  wire  _GEN_129 = 7'h8 == f7 ? 1'h0 : _GEN_119; // @[src/main/scala/rv32i/FDecoder.scala 81:16 63:31]
  wire  _GEN_130 = 7'h4 == f7 ? rmOk : _GEN_120; // @[src/main/scala/rv32i/FDecoder.scala 69:11 81:16]
  wire [3:0] _GEN_132 = 7'h4 == f7 ? 4'h1 : _GEN_122; // @[src/main/scala/rv32i/FDecoder.scala 81:16 69:76]
  wire  _GEN_134 = 7'h4 == f7 ? 1'h0 : _GEN_124; // @[src/main/scala/rv32i/FDecoder.scala 62:14 81:16]
  wire [1:0] _GEN_135 = 7'h4 == f7 ? 2'h0 : _GEN_125; // @[src/main/scala/rv32i/FDecoder.scala 81:16 62:36]
  wire  _GEN_136 = 7'h4 == f7 ? 1'h0 : _GEN_126; // @[src/main/scala/rv32i/FDecoder.scala 81:16 65:36]
  wire  _GEN_137 = 7'h4 == f7 ? 1'h0 : _GEN_127; // @[src/main/scala/rv32i/FDecoder.scala 65:13 81:16]
  wire  _GEN_138 = 7'h4 == f7 ? 1'h0 : _GEN_128; // @[src/main/scala/rv32i/FDecoder.scala 63:11 81:16]
  wire  _GEN_139 = 7'h4 == f7 ? 1'h0 : _GEN_129; // @[src/main/scala/rv32i/FDecoder.scala 81:16 63:31]
  wire  _GEN_140 = 7'h0 == f7 ? rmOk : _GEN_130; // @[src/main/scala/rv32i/FDecoder.scala 69:11 81:16]
  wire  _GEN_141 = 7'h0 == f7 | (7'h4 == f7 | (7'h8 == f7 | (7'hc == f7 | _GEN_101))); // @[src/main/scala/rv32i/FDecoder.scala 81:16 69:56]
  wire [3:0] _GEN_142 = 7'h0 == f7 ? 4'h0 : _GEN_132; // @[src/main/scala/rv32i/FDecoder.scala 81:16 69:76]
  wire  _GEN_143 = 7'h0 == f7 | (7'h4 == f7 | (7'h8 == f7 | (7'hc == f7 | _GEN_103))); // @[src/main/scala/rv32i/FDecoder.scala 81:16 69:96]
  wire  _GEN_144 = 7'h0 == f7 ? 1'h0 : _GEN_134; // @[src/main/scala/rv32i/FDecoder.scala 62:14 81:16]
  wire [1:0] _GEN_145 = 7'h0 == f7 ? 2'h0 : _GEN_135; // @[src/main/scala/rv32i/FDecoder.scala 81:16 62:36]
  wire  _GEN_146 = 7'h0 == f7 ? 1'h0 : _GEN_136; // @[src/main/scala/rv32i/FDecoder.scala 81:16 65:36]
  wire  _GEN_147 = 7'h0 == f7 ? 1'h0 : _GEN_137; // @[src/main/scala/rv32i/FDecoder.scala 65:13 81:16]
  wire  _GEN_148 = 7'h0 == f7 ? 1'h0 : _GEN_138; // @[src/main/scala/rv32i/FDecoder.scala 63:11 81:16]
  wire  _GEN_149 = 7'h0 == f7 ? 1'h0 : _GEN_139; // @[src/main/scala/rv32i/FDecoder.scala 81:16 63:31]
  wire  valid = isOpFp ? _GEN_140 : _GEN_3; // @[src/main/scala/rv32i/FDecoder.scala 80:16]
  wire [1:0] _GEN_155 = isOpFp ? _GEN_145 : 2'h0; // @[src/main/scala/rv32i/FDecoder.scala 80:16 62:36]
  assign io_isF = isLoad | isStore | isFma | isOpFp; // @[src/main/scala/rv32i/FDecoder.scala 59:40]
  assign io_illegal = io_isF & ~valid; // @[src/main/scala/rv32i/FDecoder.scala 103:24]
  assign io_rm = _rmOk_T_1 ? io_frm : f3; // @[src/main/scala/rv32i/FDecoder.scala 53:15]
  assign io_useFpu = isOpFp ? _GEN_141 : _T_4; // @[src/main/scala/rv32i/FDecoder.scala 80:16]
  assign io_fpuOp = isOpFp ? _GEN_142 : _GEN_5; // @[src/main/scala/rv32i/FDecoder.scala 80:16]
  assign io_useMisc = isOpFp & _GEN_144; // @[src/main/scala/rv32i/FDecoder.scala 62:14 80:16]
  assign io_miscOp = {{1'd0}, _GEN_155};
  assign io_mvXW = isOpFp & _GEN_148; // @[src/main/scala/rv32i/FDecoder.scala 63:11 80:16]
  assign io_mvWX = isOpFp & _GEN_149; // @[src/main/scala/rv32i/FDecoder.scala 80:16 63:31]
  assign io_intSrc = isOpFp & _GEN_147; // @[src/main/scala/rv32i/FDecoder.scala 65:13 80:16]
  assign io_writesX = isOpFp & _GEN_146; // @[src/main/scala/rv32i/FDecoder.scala 80:16 65:36]
  assign io_writesF = isOpFp ? _GEN_143 : _GEN_6; // @[src/main/scala/rv32i/FDecoder.scala 80:16]
endmodule
module FRegFile(
  input         clock,
  input         reset,
  input  [4:0]  io_rs1, // @[src/main/scala/rv32i/FRegFile.scala 9:14]
  input  [4:0]  io_rs2, // @[src/main/scala/rv32i/FRegFile.scala 9:14]
  input  [4:0]  io_rs3, // @[src/main/scala/rv32i/FRegFile.scala 9:14]
  output [31:0] io_rd1, // @[src/main/scala/rv32i/FRegFile.scala 9:14]
  output [31:0] io_rd2, // @[src/main/scala/rv32i/FRegFile.scala 9:14]
  output [31:0] io_rd3, // @[src/main/scala/rv32i/FRegFile.scala 9:14]
  input         io_we, // @[src/main/scala/rv32i/FRegFile.scala 9:14]
  input  [4:0]  io_waddr, // @[src/main/scala/rv32i/FRegFile.scala 9:14]
  input  [31:0] io_wdata // @[src/main/scala/rv32i/FRegFile.scala 9:14]
);
`ifdef RANDOMIZE_REG_INIT
  reg [31:0] _RAND_0;
  reg [31:0] _RAND_1;
  reg [31:0] _RAND_2;
  reg [31:0] _RAND_3;
  reg [31:0] _RAND_4;
  reg [31:0] _RAND_5;
  reg [31:0] _RAND_6;
  reg [31:0] _RAND_7;
  reg [31:0] _RAND_8;
  reg [31:0] _RAND_9;
  reg [31:0] _RAND_10;
  reg [31:0] _RAND_11;
  reg [31:0] _RAND_12;
  reg [31:0] _RAND_13;
  reg [31:0] _RAND_14;
  reg [31:0] _RAND_15;
  reg [31:0] _RAND_16;
  reg [31:0] _RAND_17;
  reg [31:0] _RAND_18;
  reg [31:0] _RAND_19;
  reg [31:0] _RAND_20;
  reg [31:0] _RAND_21;
  reg [31:0] _RAND_22;
  reg [31:0] _RAND_23;
  reg [31:0] _RAND_24;
  reg [31:0] _RAND_25;
  reg [31:0] _RAND_26;
  reg [31:0] _RAND_27;
  reg [31:0] _RAND_28;
  reg [31:0] _RAND_29;
  reg [31:0] _RAND_30;
  reg [31:0] _RAND_31;
`endif // RANDOMIZE_REG_INIT
  reg [31:0] regs_0; // @[src/main/scala/rv32i/FRegFile.scala 20:21]
  reg [31:0] regs_1; // @[src/main/scala/rv32i/FRegFile.scala 20:21]
  reg [31:0] regs_2; // @[src/main/scala/rv32i/FRegFile.scala 20:21]
  reg [31:0] regs_3; // @[src/main/scala/rv32i/FRegFile.scala 20:21]
  reg [31:0] regs_4; // @[src/main/scala/rv32i/FRegFile.scala 20:21]
  reg [31:0] regs_5; // @[src/main/scala/rv32i/FRegFile.scala 20:21]
  reg [31:0] regs_6; // @[src/main/scala/rv32i/FRegFile.scala 20:21]
  reg [31:0] regs_7; // @[src/main/scala/rv32i/FRegFile.scala 20:21]
  reg [31:0] regs_8; // @[src/main/scala/rv32i/FRegFile.scala 20:21]
  reg [31:0] regs_9; // @[src/main/scala/rv32i/FRegFile.scala 20:21]
  reg [31:0] regs_10; // @[src/main/scala/rv32i/FRegFile.scala 20:21]
  reg [31:0] regs_11; // @[src/main/scala/rv32i/FRegFile.scala 20:21]
  reg [31:0] regs_12; // @[src/main/scala/rv32i/FRegFile.scala 20:21]
  reg [31:0] regs_13; // @[src/main/scala/rv32i/FRegFile.scala 20:21]
  reg [31:0] regs_14; // @[src/main/scala/rv32i/FRegFile.scala 20:21]
  reg [31:0] regs_15; // @[src/main/scala/rv32i/FRegFile.scala 20:21]
  reg [31:0] regs_16; // @[src/main/scala/rv32i/FRegFile.scala 20:21]
  reg [31:0] regs_17; // @[src/main/scala/rv32i/FRegFile.scala 20:21]
  reg [31:0] regs_18; // @[src/main/scala/rv32i/FRegFile.scala 20:21]
  reg [31:0] regs_19; // @[src/main/scala/rv32i/FRegFile.scala 20:21]
  reg [31:0] regs_20; // @[src/main/scala/rv32i/FRegFile.scala 20:21]
  reg [31:0] regs_21; // @[src/main/scala/rv32i/FRegFile.scala 20:21]
  reg [31:0] regs_22; // @[src/main/scala/rv32i/FRegFile.scala 20:21]
  reg [31:0] regs_23; // @[src/main/scala/rv32i/FRegFile.scala 20:21]
  reg [31:0] regs_24; // @[src/main/scala/rv32i/FRegFile.scala 20:21]
  reg [31:0] regs_25; // @[src/main/scala/rv32i/FRegFile.scala 20:21]
  reg [31:0] regs_26; // @[src/main/scala/rv32i/FRegFile.scala 20:21]
  reg [31:0] regs_27; // @[src/main/scala/rv32i/FRegFile.scala 20:21]
  reg [31:0] regs_28; // @[src/main/scala/rv32i/FRegFile.scala 20:21]
  reg [31:0] regs_29; // @[src/main/scala/rv32i/FRegFile.scala 20:21]
  reg [31:0] regs_30; // @[src/main/scala/rv32i/FRegFile.scala 20:21]
  reg [31:0] regs_31; // @[src/main/scala/rv32i/FRegFile.scala 20:21]
  wire [31:0] _GEN_1 = 5'h1 == io_rs1 ? regs_1 : regs_0; // @[src/main/scala/rv32i/FRegFile.scala 21:{10,10}]
  wire [31:0] _GEN_2 = 5'h2 == io_rs1 ? regs_2 : _GEN_1; // @[src/main/scala/rv32i/FRegFile.scala 21:{10,10}]
  wire [31:0] _GEN_3 = 5'h3 == io_rs1 ? regs_3 : _GEN_2; // @[src/main/scala/rv32i/FRegFile.scala 21:{10,10}]
  wire [31:0] _GEN_4 = 5'h4 == io_rs1 ? regs_4 : _GEN_3; // @[src/main/scala/rv32i/FRegFile.scala 21:{10,10}]
  wire [31:0] _GEN_5 = 5'h5 == io_rs1 ? regs_5 : _GEN_4; // @[src/main/scala/rv32i/FRegFile.scala 21:{10,10}]
  wire [31:0] _GEN_6 = 5'h6 == io_rs1 ? regs_6 : _GEN_5; // @[src/main/scala/rv32i/FRegFile.scala 21:{10,10}]
  wire [31:0] _GEN_7 = 5'h7 == io_rs1 ? regs_7 : _GEN_6; // @[src/main/scala/rv32i/FRegFile.scala 21:{10,10}]
  wire [31:0] _GEN_8 = 5'h8 == io_rs1 ? regs_8 : _GEN_7; // @[src/main/scala/rv32i/FRegFile.scala 21:{10,10}]
  wire [31:0] _GEN_9 = 5'h9 == io_rs1 ? regs_9 : _GEN_8; // @[src/main/scala/rv32i/FRegFile.scala 21:{10,10}]
  wire [31:0] _GEN_10 = 5'ha == io_rs1 ? regs_10 : _GEN_9; // @[src/main/scala/rv32i/FRegFile.scala 21:{10,10}]
  wire [31:0] _GEN_11 = 5'hb == io_rs1 ? regs_11 : _GEN_10; // @[src/main/scala/rv32i/FRegFile.scala 21:{10,10}]
  wire [31:0] _GEN_12 = 5'hc == io_rs1 ? regs_12 : _GEN_11; // @[src/main/scala/rv32i/FRegFile.scala 21:{10,10}]
  wire [31:0] _GEN_13 = 5'hd == io_rs1 ? regs_13 : _GEN_12; // @[src/main/scala/rv32i/FRegFile.scala 21:{10,10}]
  wire [31:0] _GEN_14 = 5'he == io_rs1 ? regs_14 : _GEN_13; // @[src/main/scala/rv32i/FRegFile.scala 21:{10,10}]
  wire [31:0] _GEN_15 = 5'hf == io_rs1 ? regs_15 : _GEN_14; // @[src/main/scala/rv32i/FRegFile.scala 21:{10,10}]
  wire [31:0] _GEN_16 = 5'h10 == io_rs1 ? regs_16 : _GEN_15; // @[src/main/scala/rv32i/FRegFile.scala 21:{10,10}]
  wire [31:0] _GEN_17 = 5'h11 == io_rs1 ? regs_17 : _GEN_16; // @[src/main/scala/rv32i/FRegFile.scala 21:{10,10}]
  wire [31:0] _GEN_18 = 5'h12 == io_rs1 ? regs_18 : _GEN_17; // @[src/main/scala/rv32i/FRegFile.scala 21:{10,10}]
  wire [31:0] _GEN_19 = 5'h13 == io_rs1 ? regs_19 : _GEN_18; // @[src/main/scala/rv32i/FRegFile.scala 21:{10,10}]
  wire [31:0] _GEN_20 = 5'h14 == io_rs1 ? regs_20 : _GEN_19; // @[src/main/scala/rv32i/FRegFile.scala 21:{10,10}]
  wire [31:0] _GEN_21 = 5'h15 == io_rs1 ? regs_21 : _GEN_20; // @[src/main/scala/rv32i/FRegFile.scala 21:{10,10}]
  wire [31:0] _GEN_22 = 5'h16 == io_rs1 ? regs_22 : _GEN_21; // @[src/main/scala/rv32i/FRegFile.scala 21:{10,10}]
  wire [31:0] _GEN_23 = 5'h17 == io_rs1 ? regs_23 : _GEN_22; // @[src/main/scala/rv32i/FRegFile.scala 21:{10,10}]
  wire [31:0] _GEN_24 = 5'h18 == io_rs1 ? regs_24 : _GEN_23; // @[src/main/scala/rv32i/FRegFile.scala 21:{10,10}]
  wire [31:0] _GEN_25 = 5'h19 == io_rs1 ? regs_25 : _GEN_24; // @[src/main/scala/rv32i/FRegFile.scala 21:{10,10}]
  wire [31:0] _GEN_26 = 5'h1a == io_rs1 ? regs_26 : _GEN_25; // @[src/main/scala/rv32i/FRegFile.scala 21:{10,10}]
  wire [31:0] _GEN_27 = 5'h1b == io_rs1 ? regs_27 : _GEN_26; // @[src/main/scala/rv32i/FRegFile.scala 21:{10,10}]
  wire [31:0] _GEN_28 = 5'h1c == io_rs1 ? regs_28 : _GEN_27; // @[src/main/scala/rv32i/FRegFile.scala 21:{10,10}]
  wire [31:0] _GEN_29 = 5'h1d == io_rs1 ? regs_29 : _GEN_28; // @[src/main/scala/rv32i/FRegFile.scala 21:{10,10}]
  wire [31:0] _GEN_30 = 5'h1e == io_rs1 ? regs_30 : _GEN_29; // @[src/main/scala/rv32i/FRegFile.scala 21:{10,10}]
  wire [31:0] _GEN_33 = 5'h1 == io_rs2 ? regs_1 : regs_0; // @[src/main/scala/rv32i/FRegFile.scala 22:{10,10}]
  wire [31:0] _GEN_34 = 5'h2 == io_rs2 ? regs_2 : _GEN_33; // @[src/main/scala/rv32i/FRegFile.scala 22:{10,10}]
  wire [31:0] _GEN_35 = 5'h3 == io_rs2 ? regs_3 : _GEN_34; // @[src/main/scala/rv32i/FRegFile.scala 22:{10,10}]
  wire [31:0] _GEN_36 = 5'h4 == io_rs2 ? regs_4 : _GEN_35; // @[src/main/scala/rv32i/FRegFile.scala 22:{10,10}]
  wire [31:0] _GEN_37 = 5'h5 == io_rs2 ? regs_5 : _GEN_36; // @[src/main/scala/rv32i/FRegFile.scala 22:{10,10}]
  wire [31:0] _GEN_38 = 5'h6 == io_rs2 ? regs_6 : _GEN_37; // @[src/main/scala/rv32i/FRegFile.scala 22:{10,10}]
  wire [31:0] _GEN_39 = 5'h7 == io_rs2 ? regs_7 : _GEN_38; // @[src/main/scala/rv32i/FRegFile.scala 22:{10,10}]
  wire [31:0] _GEN_40 = 5'h8 == io_rs2 ? regs_8 : _GEN_39; // @[src/main/scala/rv32i/FRegFile.scala 22:{10,10}]
  wire [31:0] _GEN_41 = 5'h9 == io_rs2 ? regs_9 : _GEN_40; // @[src/main/scala/rv32i/FRegFile.scala 22:{10,10}]
  wire [31:0] _GEN_42 = 5'ha == io_rs2 ? regs_10 : _GEN_41; // @[src/main/scala/rv32i/FRegFile.scala 22:{10,10}]
  wire [31:0] _GEN_43 = 5'hb == io_rs2 ? regs_11 : _GEN_42; // @[src/main/scala/rv32i/FRegFile.scala 22:{10,10}]
  wire [31:0] _GEN_44 = 5'hc == io_rs2 ? regs_12 : _GEN_43; // @[src/main/scala/rv32i/FRegFile.scala 22:{10,10}]
  wire [31:0] _GEN_45 = 5'hd == io_rs2 ? regs_13 : _GEN_44; // @[src/main/scala/rv32i/FRegFile.scala 22:{10,10}]
  wire [31:0] _GEN_46 = 5'he == io_rs2 ? regs_14 : _GEN_45; // @[src/main/scala/rv32i/FRegFile.scala 22:{10,10}]
  wire [31:0] _GEN_47 = 5'hf == io_rs2 ? regs_15 : _GEN_46; // @[src/main/scala/rv32i/FRegFile.scala 22:{10,10}]
  wire [31:0] _GEN_48 = 5'h10 == io_rs2 ? regs_16 : _GEN_47; // @[src/main/scala/rv32i/FRegFile.scala 22:{10,10}]
  wire [31:0] _GEN_49 = 5'h11 == io_rs2 ? regs_17 : _GEN_48; // @[src/main/scala/rv32i/FRegFile.scala 22:{10,10}]
  wire [31:0] _GEN_50 = 5'h12 == io_rs2 ? regs_18 : _GEN_49; // @[src/main/scala/rv32i/FRegFile.scala 22:{10,10}]
  wire [31:0] _GEN_51 = 5'h13 == io_rs2 ? regs_19 : _GEN_50; // @[src/main/scala/rv32i/FRegFile.scala 22:{10,10}]
  wire [31:0] _GEN_52 = 5'h14 == io_rs2 ? regs_20 : _GEN_51; // @[src/main/scala/rv32i/FRegFile.scala 22:{10,10}]
  wire [31:0] _GEN_53 = 5'h15 == io_rs2 ? regs_21 : _GEN_52; // @[src/main/scala/rv32i/FRegFile.scala 22:{10,10}]
  wire [31:0] _GEN_54 = 5'h16 == io_rs2 ? regs_22 : _GEN_53; // @[src/main/scala/rv32i/FRegFile.scala 22:{10,10}]
  wire [31:0] _GEN_55 = 5'h17 == io_rs2 ? regs_23 : _GEN_54; // @[src/main/scala/rv32i/FRegFile.scala 22:{10,10}]
  wire [31:0] _GEN_56 = 5'h18 == io_rs2 ? regs_24 : _GEN_55; // @[src/main/scala/rv32i/FRegFile.scala 22:{10,10}]
  wire [31:0] _GEN_57 = 5'h19 == io_rs2 ? regs_25 : _GEN_56; // @[src/main/scala/rv32i/FRegFile.scala 22:{10,10}]
  wire [31:0] _GEN_58 = 5'h1a == io_rs2 ? regs_26 : _GEN_57; // @[src/main/scala/rv32i/FRegFile.scala 22:{10,10}]
  wire [31:0] _GEN_59 = 5'h1b == io_rs2 ? regs_27 : _GEN_58; // @[src/main/scala/rv32i/FRegFile.scala 22:{10,10}]
  wire [31:0] _GEN_60 = 5'h1c == io_rs2 ? regs_28 : _GEN_59; // @[src/main/scala/rv32i/FRegFile.scala 22:{10,10}]
  wire [31:0] _GEN_61 = 5'h1d == io_rs2 ? regs_29 : _GEN_60; // @[src/main/scala/rv32i/FRegFile.scala 22:{10,10}]
  wire [31:0] _GEN_62 = 5'h1e == io_rs2 ? regs_30 : _GEN_61; // @[src/main/scala/rv32i/FRegFile.scala 22:{10,10}]
  wire [31:0] _GEN_65 = 5'h1 == io_rs3 ? regs_1 : regs_0; // @[src/main/scala/rv32i/FRegFile.scala 23:{10,10}]
  wire [31:0] _GEN_66 = 5'h2 == io_rs3 ? regs_2 : _GEN_65; // @[src/main/scala/rv32i/FRegFile.scala 23:{10,10}]
  wire [31:0] _GEN_67 = 5'h3 == io_rs3 ? regs_3 : _GEN_66; // @[src/main/scala/rv32i/FRegFile.scala 23:{10,10}]
  wire [31:0] _GEN_68 = 5'h4 == io_rs3 ? regs_4 : _GEN_67; // @[src/main/scala/rv32i/FRegFile.scala 23:{10,10}]
  wire [31:0] _GEN_69 = 5'h5 == io_rs3 ? regs_5 : _GEN_68; // @[src/main/scala/rv32i/FRegFile.scala 23:{10,10}]
  wire [31:0] _GEN_70 = 5'h6 == io_rs3 ? regs_6 : _GEN_69; // @[src/main/scala/rv32i/FRegFile.scala 23:{10,10}]
  wire [31:0] _GEN_71 = 5'h7 == io_rs3 ? regs_7 : _GEN_70; // @[src/main/scala/rv32i/FRegFile.scala 23:{10,10}]
  wire [31:0] _GEN_72 = 5'h8 == io_rs3 ? regs_8 : _GEN_71; // @[src/main/scala/rv32i/FRegFile.scala 23:{10,10}]
  wire [31:0] _GEN_73 = 5'h9 == io_rs3 ? regs_9 : _GEN_72; // @[src/main/scala/rv32i/FRegFile.scala 23:{10,10}]
  wire [31:0] _GEN_74 = 5'ha == io_rs3 ? regs_10 : _GEN_73; // @[src/main/scala/rv32i/FRegFile.scala 23:{10,10}]
  wire [31:0] _GEN_75 = 5'hb == io_rs3 ? regs_11 : _GEN_74; // @[src/main/scala/rv32i/FRegFile.scala 23:{10,10}]
  wire [31:0] _GEN_76 = 5'hc == io_rs3 ? regs_12 : _GEN_75; // @[src/main/scala/rv32i/FRegFile.scala 23:{10,10}]
  wire [31:0] _GEN_77 = 5'hd == io_rs3 ? regs_13 : _GEN_76; // @[src/main/scala/rv32i/FRegFile.scala 23:{10,10}]
  wire [31:0] _GEN_78 = 5'he == io_rs3 ? regs_14 : _GEN_77; // @[src/main/scala/rv32i/FRegFile.scala 23:{10,10}]
  wire [31:0] _GEN_79 = 5'hf == io_rs3 ? regs_15 : _GEN_78; // @[src/main/scala/rv32i/FRegFile.scala 23:{10,10}]
  wire [31:0] _GEN_80 = 5'h10 == io_rs3 ? regs_16 : _GEN_79; // @[src/main/scala/rv32i/FRegFile.scala 23:{10,10}]
  wire [31:0] _GEN_81 = 5'h11 == io_rs3 ? regs_17 : _GEN_80; // @[src/main/scala/rv32i/FRegFile.scala 23:{10,10}]
  wire [31:0] _GEN_82 = 5'h12 == io_rs3 ? regs_18 : _GEN_81; // @[src/main/scala/rv32i/FRegFile.scala 23:{10,10}]
  wire [31:0] _GEN_83 = 5'h13 == io_rs3 ? regs_19 : _GEN_82; // @[src/main/scala/rv32i/FRegFile.scala 23:{10,10}]
  wire [31:0] _GEN_84 = 5'h14 == io_rs3 ? regs_20 : _GEN_83; // @[src/main/scala/rv32i/FRegFile.scala 23:{10,10}]
  wire [31:0] _GEN_85 = 5'h15 == io_rs3 ? regs_21 : _GEN_84; // @[src/main/scala/rv32i/FRegFile.scala 23:{10,10}]
  wire [31:0] _GEN_86 = 5'h16 == io_rs3 ? regs_22 : _GEN_85; // @[src/main/scala/rv32i/FRegFile.scala 23:{10,10}]
  wire [31:0] _GEN_87 = 5'h17 == io_rs3 ? regs_23 : _GEN_86; // @[src/main/scala/rv32i/FRegFile.scala 23:{10,10}]
  wire [31:0] _GEN_88 = 5'h18 == io_rs3 ? regs_24 : _GEN_87; // @[src/main/scala/rv32i/FRegFile.scala 23:{10,10}]
  wire [31:0] _GEN_89 = 5'h19 == io_rs3 ? regs_25 : _GEN_88; // @[src/main/scala/rv32i/FRegFile.scala 23:{10,10}]
  wire [31:0] _GEN_90 = 5'h1a == io_rs3 ? regs_26 : _GEN_89; // @[src/main/scala/rv32i/FRegFile.scala 23:{10,10}]
  wire [31:0] _GEN_91 = 5'h1b == io_rs3 ? regs_27 : _GEN_90; // @[src/main/scala/rv32i/FRegFile.scala 23:{10,10}]
  wire [31:0] _GEN_92 = 5'h1c == io_rs3 ? regs_28 : _GEN_91; // @[src/main/scala/rv32i/FRegFile.scala 23:{10,10}]
  wire [31:0] _GEN_93 = 5'h1d == io_rs3 ? regs_29 : _GEN_92; // @[src/main/scala/rv32i/FRegFile.scala 23:{10,10}]
  wire [31:0] _GEN_94 = 5'h1e == io_rs3 ? regs_30 : _GEN_93; // @[src/main/scala/rv32i/FRegFile.scala 23:{10,10}]
  assign io_rd1 = 5'h1f == io_rs1 ? regs_31 : _GEN_30; // @[src/main/scala/rv32i/FRegFile.scala 21:{10,10}]
  assign io_rd2 = 5'h1f == io_rs2 ? regs_31 : _GEN_62; // @[src/main/scala/rv32i/FRegFile.scala 22:{10,10}]
  assign io_rd3 = 5'h1f == io_rs3 ? regs_31 : _GEN_94; // @[src/main/scala/rv32i/FRegFile.scala 23:{10,10}]
  always @(posedge clock) begin
    if (reset) begin // @[src/main/scala/rv32i/FRegFile.scala 20:21]
      regs_0 <= 32'h0; // @[src/main/scala/rv32i/FRegFile.scala 20:21]
    end else if (io_we) begin // @[src/main/scala/rv32i/FRegFile.scala 24:15]
      if (5'h0 == io_waddr) begin // @[src/main/scala/rv32i/FRegFile.scala 24:32]
        regs_0 <= io_wdata; // @[src/main/scala/rv32i/FRegFile.scala 24:32]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/FRegFile.scala 20:21]
      regs_1 <= 32'h0; // @[src/main/scala/rv32i/FRegFile.scala 20:21]
    end else if (io_we) begin // @[src/main/scala/rv32i/FRegFile.scala 24:15]
      if (5'h1 == io_waddr) begin // @[src/main/scala/rv32i/FRegFile.scala 24:32]
        regs_1 <= io_wdata; // @[src/main/scala/rv32i/FRegFile.scala 24:32]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/FRegFile.scala 20:21]
      regs_2 <= 32'h0; // @[src/main/scala/rv32i/FRegFile.scala 20:21]
    end else if (io_we) begin // @[src/main/scala/rv32i/FRegFile.scala 24:15]
      if (5'h2 == io_waddr) begin // @[src/main/scala/rv32i/FRegFile.scala 24:32]
        regs_2 <= io_wdata; // @[src/main/scala/rv32i/FRegFile.scala 24:32]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/FRegFile.scala 20:21]
      regs_3 <= 32'h0; // @[src/main/scala/rv32i/FRegFile.scala 20:21]
    end else if (io_we) begin // @[src/main/scala/rv32i/FRegFile.scala 24:15]
      if (5'h3 == io_waddr) begin // @[src/main/scala/rv32i/FRegFile.scala 24:32]
        regs_3 <= io_wdata; // @[src/main/scala/rv32i/FRegFile.scala 24:32]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/FRegFile.scala 20:21]
      regs_4 <= 32'h0; // @[src/main/scala/rv32i/FRegFile.scala 20:21]
    end else if (io_we) begin // @[src/main/scala/rv32i/FRegFile.scala 24:15]
      if (5'h4 == io_waddr) begin // @[src/main/scala/rv32i/FRegFile.scala 24:32]
        regs_4 <= io_wdata; // @[src/main/scala/rv32i/FRegFile.scala 24:32]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/FRegFile.scala 20:21]
      regs_5 <= 32'h0; // @[src/main/scala/rv32i/FRegFile.scala 20:21]
    end else if (io_we) begin // @[src/main/scala/rv32i/FRegFile.scala 24:15]
      if (5'h5 == io_waddr) begin // @[src/main/scala/rv32i/FRegFile.scala 24:32]
        regs_5 <= io_wdata; // @[src/main/scala/rv32i/FRegFile.scala 24:32]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/FRegFile.scala 20:21]
      regs_6 <= 32'h0; // @[src/main/scala/rv32i/FRegFile.scala 20:21]
    end else if (io_we) begin // @[src/main/scala/rv32i/FRegFile.scala 24:15]
      if (5'h6 == io_waddr) begin // @[src/main/scala/rv32i/FRegFile.scala 24:32]
        regs_6 <= io_wdata; // @[src/main/scala/rv32i/FRegFile.scala 24:32]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/FRegFile.scala 20:21]
      regs_7 <= 32'h0; // @[src/main/scala/rv32i/FRegFile.scala 20:21]
    end else if (io_we) begin // @[src/main/scala/rv32i/FRegFile.scala 24:15]
      if (5'h7 == io_waddr) begin // @[src/main/scala/rv32i/FRegFile.scala 24:32]
        regs_7 <= io_wdata; // @[src/main/scala/rv32i/FRegFile.scala 24:32]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/FRegFile.scala 20:21]
      regs_8 <= 32'h0; // @[src/main/scala/rv32i/FRegFile.scala 20:21]
    end else if (io_we) begin // @[src/main/scala/rv32i/FRegFile.scala 24:15]
      if (5'h8 == io_waddr) begin // @[src/main/scala/rv32i/FRegFile.scala 24:32]
        regs_8 <= io_wdata; // @[src/main/scala/rv32i/FRegFile.scala 24:32]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/FRegFile.scala 20:21]
      regs_9 <= 32'h0; // @[src/main/scala/rv32i/FRegFile.scala 20:21]
    end else if (io_we) begin // @[src/main/scala/rv32i/FRegFile.scala 24:15]
      if (5'h9 == io_waddr) begin // @[src/main/scala/rv32i/FRegFile.scala 24:32]
        regs_9 <= io_wdata; // @[src/main/scala/rv32i/FRegFile.scala 24:32]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/FRegFile.scala 20:21]
      regs_10 <= 32'h0; // @[src/main/scala/rv32i/FRegFile.scala 20:21]
    end else if (io_we) begin // @[src/main/scala/rv32i/FRegFile.scala 24:15]
      if (5'ha == io_waddr) begin // @[src/main/scala/rv32i/FRegFile.scala 24:32]
        regs_10 <= io_wdata; // @[src/main/scala/rv32i/FRegFile.scala 24:32]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/FRegFile.scala 20:21]
      regs_11 <= 32'h0; // @[src/main/scala/rv32i/FRegFile.scala 20:21]
    end else if (io_we) begin // @[src/main/scala/rv32i/FRegFile.scala 24:15]
      if (5'hb == io_waddr) begin // @[src/main/scala/rv32i/FRegFile.scala 24:32]
        regs_11 <= io_wdata; // @[src/main/scala/rv32i/FRegFile.scala 24:32]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/FRegFile.scala 20:21]
      regs_12 <= 32'h0; // @[src/main/scala/rv32i/FRegFile.scala 20:21]
    end else if (io_we) begin // @[src/main/scala/rv32i/FRegFile.scala 24:15]
      if (5'hc == io_waddr) begin // @[src/main/scala/rv32i/FRegFile.scala 24:32]
        regs_12 <= io_wdata; // @[src/main/scala/rv32i/FRegFile.scala 24:32]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/FRegFile.scala 20:21]
      regs_13 <= 32'h0; // @[src/main/scala/rv32i/FRegFile.scala 20:21]
    end else if (io_we) begin // @[src/main/scala/rv32i/FRegFile.scala 24:15]
      if (5'hd == io_waddr) begin // @[src/main/scala/rv32i/FRegFile.scala 24:32]
        regs_13 <= io_wdata; // @[src/main/scala/rv32i/FRegFile.scala 24:32]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/FRegFile.scala 20:21]
      regs_14 <= 32'h0; // @[src/main/scala/rv32i/FRegFile.scala 20:21]
    end else if (io_we) begin // @[src/main/scala/rv32i/FRegFile.scala 24:15]
      if (5'he == io_waddr) begin // @[src/main/scala/rv32i/FRegFile.scala 24:32]
        regs_14 <= io_wdata; // @[src/main/scala/rv32i/FRegFile.scala 24:32]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/FRegFile.scala 20:21]
      regs_15 <= 32'h0; // @[src/main/scala/rv32i/FRegFile.scala 20:21]
    end else if (io_we) begin // @[src/main/scala/rv32i/FRegFile.scala 24:15]
      if (5'hf == io_waddr) begin // @[src/main/scala/rv32i/FRegFile.scala 24:32]
        regs_15 <= io_wdata; // @[src/main/scala/rv32i/FRegFile.scala 24:32]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/FRegFile.scala 20:21]
      regs_16 <= 32'h0; // @[src/main/scala/rv32i/FRegFile.scala 20:21]
    end else if (io_we) begin // @[src/main/scala/rv32i/FRegFile.scala 24:15]
      if (5'h10 == io_waddr) begin // @[src/main/scala/rv32i/FRegFile.scala 24:32]
        regs_16 <= io_wdata; // @[src/main/scala/rv32i/FRegFile.scala 24:32]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/FRegFile.scala 20:21]
      regs_17 <= 32'h0; // @[src/main/scala/rv32i/FRegFile.scala 20:21]
    end else if (io_we) begin // @[src/main/scala/rv32i/FRegFile.scala 24:15]
      if (5'h11 == io_waddr) begin // @[src/main/scala/rv32i/FRegFile.scala 24:32]
        regs_17 <= io_wdata; // @[src/main/scala/rv32i/FRegFile.scala 24:32]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/FRegFile.scala 20:21]
      regs_18 <= 32'h0; // @[src/main/scala/rv32i/FRegFile.scala 20:21]
    end else if (io_we) begin // @[src/main/scala/rv32i/FRegFile.scala 24:15]
      if (5'h12 == io_waddr) begin // @[src/main/scala/rv32i/FRegFile.scala 24:32]
        regs_18 <= io_wdata; // @[src/main/scala/rv32i/FRegFile.scala 24:32]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/FRegFile.scala 20:21]
      regs_19 <= 32'h0; // @[src/main/scala/rv32i/FRegFile.scala 20:21]
    end else if (io_we) begin // @[src/main/scala/rv32i/FRegFile.scala 24:15]
      if (5'h13 == io_waddr) begin // @[src/main/scala/rv32i/FRegFile.scala 24:32]
        regs_19 <= io_wdata; // @[src/main/scala/rv32i/FRegFile.scala 24:32]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/FRegFile.scala 20:21]
      regs_20 <= 32'h0; // @[src/main/scala/rv32i/FRegFile.scala 20:21]
    end else if (io_we) begin // @[src/main/scala/rv32i/FRegFile.scala 24:15]
      if (5'h14 == io_waddr) begin // @[src/main/scala/rv32i/FRegFile.scala 24:32]
        regs_20 <= io_wdata; // @[src/main/scala/rv32i/FRegFile.scala 24:32]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/FRegFile.scala 20:21]
      regs_21 <= 32'h0; // @[src/main/scala/rv32i/FRegFile.scala 20:21]
    end else if (io_we) begin // @[src/main/scala/rv32i/FRegFile.scala 24:15]
      if (5'h15 == io_waddr) begin // @[src/main/scala/rv32i/FRegFile.scala 24:32]
        regs_21 <= io_wdata; // @[src/main/scala/rv32i/FRegFile.scala 24:32]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/FRegFile.scala 20:21]
      regs_22 <= 32'h0; // @[src/main/scala/rv32i/FRegFile.scala 20:21]
    end else if (io_we) begin // @[src/main/scala/rv32i/FRegFile.scala 24:15]
      if (5'h16 == io_waddr) begin // @[src/main/scala/rv32i/FRegFile.scala 24:32]
        regs_22 <= io_wdata; // @[src/main/scala/rv32i/FRegFile.scala 24:32]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/FRegFile.scala 20:21]
      regs_23 <= 32'h0; // @[src/main/scala/rv32i/FRegFile.scala 20:21]
    end else if (io_we) begin // @[src/main/scala/rv32i/FRegFile.scala 24:15]
      if (5'h17 == io_waddr) begin // @[src/main/scala/rv32i/FRegFile.scala 24:32]
        regs_23 <= io_wdata; // @[src/main/scala/rv32i/FRegFile.scala 24:32]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/FRegFile.scala 20:21]
      regs_24 <= 32'h0; // @[src/main/scala/rv32i/FRegFile.scala 20:21]
    end else if (io_we) begin // @[src/main/scala/rv32i/FRegFile.scala 24:15]
      if (5'h18 == io_waddr) begin // @[src/main/scala/rv32i/FRegFile.scala 24:32]
        regs_24 <= io_wdata; // @[src/main/scala/rv32i/FRegFile.scala 24:32]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/FRegFile.scala 20:21]
      regs_25 <= 32'h0; // @[src/main/scala/rv32i/FRegFile.scala 20:21]
    end else if (io_we) begin // @[src/main/scala/rv32i/FRegFile.scala 24:15]
      if (5'h19 == io_waddr) begin // @[src/main/scala/rv32i/FRegFile.scala 24:32]
        regs_25 <= io_wdata; // @[src/main/scala/rv32i/FRegFile.scala 24:32]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/FRegFile.scala 20:21]
      regs_26 <= 32'h0; // @[src/main/scala/rv32i/FRegFile.scala 20:21]
    end else if (io_we) begin // @[src/main/scala/rv32i/FRegFile.scala 24:15]
      if (5'h1a == io_waddr) begin // @[src/main/scala/rv32i/FRegFile.scala 24:32]
        regs_26 <= io_wdata; // @[src/main/scala/rv32i/FRegFile.scala 24:32]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/FRegFile.scala 20:21]
      regs_27 <= 32'h0; // @[src/main/scala/rv32i/FRegFile.scala 20:21]
    end else if (io_we) begin // @[src/main/scala/rv32i/FRegFile.scala 24:15]
      if (5'h1b == io_waddr) begin // @[src/main/scala/rv32i/FRegFile.scala 24:32]
        regs_27 <= io_wdata; // @[src/main/scala/rv32i/FRegFile.scala 24:32]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/FRegFile.scala 20:21]
      regs_28 <= 32'h0; // @[src/main/scala/rv32i/FRegFile.scala 20:21]
    end else if (io_we) begin // @[src/main/scala/rv32i/FRegFile.scala 24:15]
      if (5'h1c == io_waddr) begin // @[src/main/scala/rv32i/FRegFile.scala 24:32]
        regs_28 <= io_wdata; // @[src/main/scala/rv32i/FRegFile.scala 24:32]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/FRegFile.scala 20:21]
      regs_29 <= 32'h0; // @[src/main/scala/rv32i/FRegFile.scala 20:21]
    end else if (io_we) begin // @[src/main/scala/rv32i/FRegFile.scala 24:15]
      if (5'h1d == io_waddr) begin // @[src/main/scala/rv32i/FRegFile.scala 24:32]
        regs_29 <= io_wdata; // @[src/main/scala/rv32i/FRegFile.scala 24:32]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/FRegFile.scala 20:21]
      regs_30 <= 32'h0; // @[src/main/scala/rv32i/FRegFile.scala 20:21]
    end else if (io_we) begin // @[src/main/scala/rv32i/FRegFile.scala 24:15]
      if (5'h1e == io_waddr) begin // @[src/main/scala/rv32i/FRegFile.scala 24:32]
        regs_30 <= io_wdata; // @[src/main/scala/rv32i/FRegFile.scala 24:32]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/FRegFile.scala 20:21]
      regs_31 <= 32'h0; // @[src/main/scala/rv32i/FRegFile.scala 20:21]
    end else if (io_we) begin // @[src/main/scala/rv32i/FRegFile.scala 24:15]
      if (5'h1f == io_waddr) begin // @[src/main/scala/rv32i/FRegFile.scala 24:32]
        regs_31 <= io_wdata; // @[src/main/scala/rv32i/FRegFile.scala 24:32]
      end
    end
  end
// Register and memory initialization
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif
`ifndef RANDOM
`define RANDOM $random
`endif
`ifdef RANDOMIZE_MEM_INIT
  integer initvar;
`endif
`ifndef SYNTHESIS
`ifdef FIRRTL_BEFORE_INITIAL
`FIRRTL_BEFORE_INITIAL
`endif
initial begin
  `ifdef RANDOMIZE
    `ifdef INIT_RANDOM
      `INIT_RANDOM
    `endif
    `ifndef VERILATOR
      `ifdef RANDOMIZE_DELAY
        #`RANDOMIZE_DELAY begin end
      `else
        #0.002 begin end
      `endif
    `endif
`ifdef RANDOMIZE_REG_INIT
  _RAND_0 = {1{`RANDOM}};
  regs_0 = _RAND_0[31:0];
  _RAND_1 = {1{`RANDOM}};
  regs_1 = _RAND_1[31:0];
  _RAND_2 = {1{`RANDOM}};
  regs_2 = _RAND_2[31:0];
  _RAND_3 = {1{`RANDOM}};
  regs_3 = _RAND_3[31:0];
  _RAND_4 = {1{`RANDOM}};
  regs_4 = _RAND_4[31:0];
  _RAND_5 = {1{`RANDOM}};
  regs_5 = _RAND_5[31:0];
  _RAND_6 = {1{`RANDOM}};
  regs_6 = _RAND_6[31:0];
  _RAND_7 = {1{`RANDOM}};
  regs_7 = _RAND_7[31:0];
  _RAND_8 = {1{`RANDOM}};
  regs_8 = _RAND_8[31:0];
  _RAND_9 = {1{`RANDOM}};
  regs_9 = _RAND_9[31:0];
  _RAND_10 = {1{`RANDOM}};
  regs_10 = _RAND_10[31:0];
  _RAND_11 = {1{`RANDOM}};
  regs_11 = _RAND_11[31:0];
  _RAND_12 = {1{`RANDOM}};
  regs_12 = _RAND_12[31:0];
  _RAND_13 = {1{`RANDOM}};
  regs_13 = _RAND_13[31:0];
  _RAND_14 = {1{`RANDOM}};
  regs_14 = _RAND_14[31:0];
  _RAND_15 = {1{`RANDOM}};
  regs_15 = _RAND_15[31:0];
  _RAND_16 = {1{`RANDOM}};
  regs_16 = _RAND_16[31:0];
  _RAND_17 = {1{`RANDOM}};
  regs_17 = _RAND_17[31:0];
  _RAND_18 = {1{`RANDOM}};
  regs_18 = _RAND_18[31:0];
  _RAND_19 = {1{`RANDOM}};
  regs_19 = _RAND_19[31:0];
  _RAND_20 = {1{`RANDOM}};
  regs_20 = _RAND_20[31:0];
  _RAND_21 = {1{`RANDOM}};
  regs_21 = _RAND_21[31:0];
  _RAND_22 = {1{`RANDOM}};
  regs_22 = _RAND_22[31:0];
  _RAND_23 = {1{`RANDOM}};
  regs_23 = _RAND_23[31:0];
  _RAND_24 = {1{`RANDOM}};
  regs_24 = _RAND_24[31:0];
  _RAND_25 = {1{`RANDOM}};
  regs_25 = _RAND_25[31:0];
  _RAND_26 = {1{`RANDOM}};
  regs_26 = _RAND_26[31:0];
  _RAND_27 = {1{`RANDOM}};
  regs_27 = _RAND_27[31:0];
  _RAND_28 = {1{`RANDOM}};
  regs_28 = _RAND_28[31:0];
  _RAND_29 = {1{`RANDOM}};
  regs_29 = _RAND_29[31:0];
  _RAND_30 = {1{`RANDOM}};
  regs_30 = _RAND_30[31:0];
  _RAND_31 = {1{`RANDOM}};
  regs_31 = _RAND_31[31:0];
`endif // RANDOMIZE_REG_INIT
  `endif // RANDOMIZE
end // initial
`ifdef FIRRTL_AFTER_INITIAL
`FIRRTL_AFTER_INITIAL
`endif
`endif // SYNTHESIS
endmodule
module Fpu(
  input         clock,
  input         reset,
  output        io_req_ready, // @[src/main/scala/rv32i/Fpu.scala 101:14]
  input         io_req_valid, // @[src/main/scala/rv32i/Fpu.scala 101:14]
  input  [3:0]  io_req_bits_op, // @[src/main/scala/rv32i/Fpu.scala 101:14]
  input  [2:0]  io_req_bits_rm, // @[src/main/scala/rv32i/Fpu.scala 101:14]
  input  [31:0] io_req_bits_a, // @[src/main/scala/rv32i/Fpu.scala 101:14]
  input  [31:0] io_req_bits_b, // @[src/main/scala/rv32i/Fpu.scala 101:14]
  input  [31:0] io_req_bits_c, // @[src/main/scala/rv32i/Fpu.scala 101:14]
  output        io_resp_valid, // @[src/main/scala/rv32i/Fpu.scala 101:14]
  output [31:0] io_resp_bits_bits, // @[src/main/scala/rv32i/Fpu.scala 101:14]
  output [4:0]  io_resp_bits_flags, // @[src/main/scala/rv32i/Fpu.scala 101:14]
  input         io_kill, // @[src/main/scala/rv32i/Fpu.scala 101:14]
  output        io_busy // @[src/main/scala/rv32i/Fpu.scala 101:14]
);
`ifdef RANDOMIZE_REG_INIT
  reg [31:0] _RAND_0;
  reg [31:0] _RAND_1;
  reg [31:0] _RAND_2;
  reg [31:0] _RAND_3;
  reg [31:0] _RAND_4;
  reg [31:0] _RAND_5;
  reg [31:0] _RAND_6;
  reg [31:0] _RAND_7;
  reg [63:0] _RAND_8;
  reg [31:0] _RAND_9;
  reg [31:0] _RAND_10;
  reg [31:0] _RAND_11;
  reg [63:0] _RAND_12;
  reg [31:0] _RAND_13;
  reg [63:0] _RAND_14;
  reg [63:0] _RAND_15;
  reg [31:0] _RAND_16;
  reg [31:0] _RAND_17;
  reg [31:0] _RAND_18;
  reg [31:0] _RAND_19;
  reg [31:0] _RAND_20;
  reg [63:0] _RAND_21;
  reg [63:0] _RAND_22;
  reg [31:0] _RAND_23;
  reg [31:0] _RAND_24;
  reg [31:0] _RAND_25;
  reg [63:0] _RAND_26;
  reg [31:0] _RAND_27;
  reg [31:0] _RAND_28;
  reg [31:0] _RAND_29;
`endif // RANDOMIZE_REG_INIT
  reg [3:0] state; // @[src/main/scala/rv32i/Fpu.scala 109:22]
  reg [3:0] op; // @[src/main/scala/rv32i/Fpu.scala 111:15]
  reg [2:0] rm; // @[src/main/scala/rv32i/Fpu.scala 112:15]
  reg [31:0] ra; // @[src/main/scala/rv32i/Fpu.scala 113:15]
  reg [31:0] rb; // @[src/main/scala/rv32i/Fpu.scala 114:15]
  reg [31:0] rc; // @[src/main/scala/rv32i/Fpu.scala 115:15]
  wire  _io_resp_valid_T = state == 4'h9; // @[src/main/scala/rv32i/Fpu.scala 119:26]
  wire  _T = io_req_ready & io_req_valid; // @[src/main/scala/chisel3/util/Decoupled.scala 57:35]
  wire [3:0] _GEN_5 = _T ? 4'h1 : state; // @[src/main/scala/rv32i/Fpu.scala 121:21 124:11 109:22]
  wire [7:0] A_ef = ra[30:23]; // @[src/main/scala/rv32i/Fpu.scala 65:15]
  wire [22:0] A_f = ra[22:0]; // @[src/main/scala/rv32i/Fpu.scala 66:15]
  wire  A_sign = ra[31]; // @[src/main/scala/rv32i/Fpu.scala 67:16]
  wire  _A_w_zero_T = A_ef == 8'h0; // @[src/main/scala/rv32i/Fpu.scala 68:18]
  wire  _A_w_zero_T_1 = A_f == 23'h0; // @[src/main/scala/rv32i/Fpu.scala 68:31]
  wire  A_zero = A_ef == 8'h0 & A_f == 23'h0; // @[src/main/scala/rv32i/Fpu.scala 68:26]
  wire  _A_w_inf_T = &A_ef; // @[src/main/scala/rv32i/Fpu.scala 69:18]
  wire  A_inf = &A_ef & _A_w_zero_T_1; // @[src/main/scala/rv32i/Fpu.scala 69:23]
  wire  A_nan = _A_w_inf_T & A_f != 23'h0; // @[src/main/scala/rv32i/Fpu.scala 70:23]
  wire  A_snan = A_nan & ~A_f[22]; // @[src/main/scala/rv32i/Fpu.scala 71:21]
  wire [23:0] A_raw = {A_ef != 8'h0,A_f}; // @[src/main/scala/rv32i/Fpu.scala 72:18]
  wire [15:0] _GEN_386 = {{8'd0}, A_raw[15:8]}; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _A_lz_T_4 = _GEN_386 & 16'hff; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _A_lz_T_6 = {A_raw[7:0], 8'h0}; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _A_lz_T_8 = _A_lz_T_6 & 16'hff00; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _A_lz_T_9 = _A_lz_T_4 | _A_lz_T_8; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _GEN_387 = {{4'd0}, _A_lz_T_9[15:4]}; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _A_lz_T_14 = _GEN_387 & 16'hf0f; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _A_lz_T_16 = {_A_lz_T_9[11:0], 4'h0}; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _A_lz_T_18 = _A_lz_T_16 & 16'hf0f0; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _A_lz_T_19 = _A_lz_T_14 | _A_lz_T_18; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _GEN_388 = {{2'd0}, _A_lz_T_19[15:2]}; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _A_lz_T_24 = _GEN_388 & 16'h3333; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _A_lz_T_26 = {_A_lz_T_19[13:0], 2'h0}; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _A_lz_T_28 = _A_lz_T_26 & 16'hcccc; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _A_lz_T_29 = _A_lz_T_24 | _A_lz_T_28; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _GEN_389 = {{1'd0}, _A_lz_T_29[15:1]}; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _A_lz_T_34 = _GEN_389 & 16'h5555; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _A_lz_T_36 = {_A_lz_T_29[14:0], 1'h0}; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _A_lz_T_38 = _A_lz_T_36 & 16'haaaa; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _A_lz_T_39 = _A_lz_T_34 | _A_lz_T_38; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [7:0] _GEN_390 = {{4'd0}, A_raw[23:20]}; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [7:0] _A_lz_T_44 = _GEN_390 & 8'hf; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [7:0] _A_lz_T_46 = {A_raw[19:16], 4'h0}; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [7:0] _A_lz_T_48 = _A_lz_T_46 & 8'hf0; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [7:0] _A_lz_T_49 = _A_lz_T_44 | _A_lz_T_48; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [7:0] _GEN_391 = {{2'd0}, _A_lz_T_49[7:2]}; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [7:0] _A_lz_T_54 = _GEN_391 & 8'h33; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [7:0] _A_lz_T_56 = {_A_lz_T_49[5:0], 2'h0}; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [7:0] _A_lz_T_58 = _A_lz_T_56 & 8'hcc; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [7:0] _A_lz_T_59 = _A_lz_T_54 | _A_lz_T_58; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [7:0] _GEN_392 = {{1'd0}, _A_lz_T_59[7:1]}; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [7:0] _A_lz_T_64 = _GEN_392 & 8'h55; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [7:0] _A_lz_T_66 = {_A_lz_T_59[6:0], 1'h0}; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [7:0] _A_lz_T_68 = _A_lz_T_66 & 8'haa; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [7:0] _A_lz_T_69 = _A_lz_T_64 | _A_lz_T_68; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [23:0] _A_lz_T_70 = {_A_lz_T_39,_A_lz_T_69}; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [4:0] _A_lz_T_95 = _A_lz_T_70[22] ? 5'h16 : 5'h17; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _A_lz_T_96 = _A_lz_T_70[21] ? 5'h15 : _A_lz_T_95; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _A_lz_T_97 = _A_lz_T_70[20] ? 5'h14 : _A_lz_T_96; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _A_lz_T_98 = _A_lz_T_70[19] ? 5'h13 : _A_lz_T_97; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _A_lz_T_99 = _A_lz_T_70[18] ? 5'h12 : _A_lz_T_98; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _A_lz_T_100 = _A_lz_T_70[17] ? 5'h11 : _A_lz_T_99; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _A_lz_T_101 = _A_lz_T_70[16] ? 5'h10 : _A_lz_T_100; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _A_lz_T_102 = _A_lz_T_70[15] ? 5'hf : _A_lz_T_101; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _A_lz_T_103 = _A_lz_T_70[14] ? 5'he : _A_lz_T_102; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _A_lz_T_104 = _A_lz_T_70[13] ? 5'hd : _A_lz_T_103; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _A_lz_T_105 = _A_lz_T_70[12] ? 5'hc : _A_lz_T_104; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _A_lz_T_106 = _A_lz_T_70[11] ? 5'hb : _A_lz_T_105; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _A_lz_T_107 = _A_lz_T_70[10] ? 5'ha : _A_lz_T_106; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _A_lz_T_108 = _A_lz_T_70[9] ? 5'h9 : _A_lz_T_107; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _A_lz_T_109 = _A_lz_T_70[8] ? 5'h8 : _A_lz_T_108; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _A_lz_T_110 = _A_lz_T_70[7] ? 5'h7 : _A_lz_T_109; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _A_lz_T_111 = _A_lz_T_70[6] ? 5'h6 : _A_lz_T_110; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _A_lz_T_112 = _A_lz_T_70[5] ? 5'h5 : _A_lz_T_111; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _A_lz_T_113 = _A_lz_T_70[4] ? 5'h4 : _A_lz_T_112; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _A_lz_T_114 = _A_lz_T_70[3] ? 5'h3 : _A_lz_T_113; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _A_lz_T_115 = _A_lz_T_70[2] ? 5'h2 : _A_lz_T_114; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _A_lz_T_116 = _A_lz_T_70[1] ? 5'h1 : _A_lz_T_115; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] A_lz = _A_lz_T_70[0] ? 5'h0 : _A_lz_T_116; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [54:0] _GEN_0 = {{31'd0}, A_raw}; // @[src/main/scala/rv32i/Fpu.scala 74:19]
  wire [54:0] _A_w_sig_T = _GEN_0 << A_lz; // @[src/main/scala/rv32i/Fpu.scala 74:19]
  wire [23:0] A_sig = _A_w_sig_T[23:0]; // @[src/main/scala/rv32i/Fpu.scala 74:25]
  wire [8:0] _A_eLsb_T_1 = {1'b0,$signed(A_ef)}; // @[src/main/scala/rv32i/Fpu.scala 75:51]
  wire [12:0] _A_eLsb_T_2 = {{4{_A_eLsb_T_1[8]}},_A_eLsb_T_1}; // @[src/main/scala/rv32i/Fpu.scala 75:59]
  wire [12:0] _A_eLsb_T_5 = $signed(_A_eLsb_T_2) - 13'sh96; // @[src/main/scala/rv32i/Fpu.scala 75:64]
  wire [12:0] A_eLsb = _A_w_zero_T ? $signed(-13'sh95) : $signed(_A_eLsb_T_5); // @[src/main/scala/rv32i/Fpu.scala 75:19]
  wire [12:0] _A_w_exp_T_2 = $signed(A_eLsb) + 13'sh17; // @[src/main/scala/rv32i/Fpu.scala 76:19]
  wire [5:0] _A_w_exp_T_3 = {1'b0,$signed(A_lz)}; // @[src/main/scala/rv32i/Fpu.scala 76:37]
  wire [12:0] _A_w_exp_T_4 = {{7{_A_w_exp_T_3[5]}},_A_w_exp_T_3}; // @[src/main/scala/rv32i/Fpu.scala 76:45]
  wire [12:0] A_exp = $signed(_A_w_exp_T_2) - $signed(_A_w_exp_T_4); // @[src/main/scala/rv32i/Fpu.scala 76:32]
  wire [7:0] B_ef = rb[30:23]; // @[src/main/scala/rv32i/Fpu.scala 65:15]
  wire [22:0] B_f = rb[22:0]; // @[src/main/scala/rv32i/Fpu.scala 66:15]
  wire  B_sign = rb[31]; // @[src/main/scala/rv32i/Fpu.scala 67:16]
  wire  _B_w_zero_T = B_ef == 8'h0; // @[src/main/scala/rv32i/Fpu.scala 68:18]
  wire  _B_w_zero_T_1 = B_f == 23'h0; // @[src/main/scala/rv32i/Fpu.scala 68:31]
  wire  B_zero = B_ef == 8'h0 & B_f == 23'h0; // @[src/main/scala/rv32i/Fpu.scala 68:26]
  wire  _B_w_inf_T = &B_ef; // @[src/main/scala/rv32i/Fpu.scala 69:18]
  wire  B_inf = &B_ef & _B_w_zero_T_1; // @[src/main/scala/rv32i/Fpu.scala 69:23]
  wire  B_nan = _B_w_inf_T & B_f != 23'h0; // @[src/main/scala/rv32i/Fpu.scala 70:23]
  wire  B_snan = B_nan & ~B_f[22]; // @[src/main/scala/rv32i/Fpu.scala 71:21]
  wire [23:0] B_raw = {B_ef != 8'h0,B_f}; // @[src/main/scala/rv32i/Fpu.scala 72:18]
  wire [15:0] _GEN_393 = {{8'd0}, B_raw[15:8]}; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _B_lz_T_4 = _GEN_393 & 16'hff; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _B_lz_T_6 = {B_raw[7:0], 8'h0}; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _B_lz_T_8 = _B_lz_T_6 & 16'hff00; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _B_lz_T_9 = _B_lz_T_4 | _B_lz_T_8; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _GEN_394 = {{4'd0}, _B_lz_T_9[15:4]}; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _B_lz_T_14 = _GEN_394 & 16'hf0f; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _B_lz_T_16 = {_B_lz_T_9[11:0], 4'h0}; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _B_lz_T_18 = _B_lz_T_16 & 16'hf0f0; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _B_lz_T_19 = _B_lz_T_14 | _B_lz_T_18; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _GEN_395 = {{2'd0}, _B_lz_T_19[15:2]}; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _B_lz_T_24 = _GEN_395 & 16'h3333; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _B_lz_T_26 = {_B_lz_T_19[13:0], 2'h0}; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _B_lz_T_28 = _B_lz_T_26 & 16'hcccc; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _B_lz_T_29 = _B_lz_T_24 | _B_lz_T_28; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _GEN_396 = {{1'd0}, _B_lz_T_29[15:1]}; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _B_lz_T_34 = _GEN_396 & 16'h5555; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _B_lz_T_36 = {_B_lz_T_29[14:0], 1'h0}; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _B_lz_T_38 = _B_lz_T_36 & 16'haaaa; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _B_lz_T_39 = _B_lz_T_34 | _B_lz_T_38; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [7:0] _GEN_397 = {{4'd0}, B_raw[23:20]}; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [7:0] _B_lz_T_44 = _GEN_397 & 8'hf; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [7:0] _B_lz_T_46 = {B_raw[19:16], 4'h0}; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [7:0] _B_lz_T_48 = _B_lz_T_46 & 8'hf0; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [7:0] _B_lz_T_49 = _B_lz_T_44 | _B_lz_T_48; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [7:0] _GEN_398 = {{2'd0}, _B_lz_T_49[7:2]}; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [7:0] _B_lz_T_54 = _GEN_398 & 8'h33; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [7:0] _B_lz_T_56 = {_B_lz_T_49[5:0], 2'h0}; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [7:0] _B_lz_T_58 = _B_lz_T_56 & 8'hcc; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [7:0] _B_lz_T_59 = _B_lz_T_54 | _B_lz_T_58; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [7:0] _GEN_399 = {{1'd0}, _B_lz_T_59[7:1]}; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [7:0] _B_lz_T_64 = _GEN_399 & 8'h55; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [7:0] _B_lz_T_66 = {_B_lz_T_59[6:0], 1'h0}; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [7:0] _B_lz_T_68 = _B_lz_T_66 & 8'haa; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [7:0] _B_lz_T_69 = _B_lz_T_64 | _B_lz_T_68; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [23:0] _B_lz_T_70 = {_B_lz_T_39,_B_lz_T_69}; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [4:0] _B_lz_T_95 = _B_lz_T_70[22] ? 5'h16 : 5'h17; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _B_lz_T_96 = _B_lz_T_70[21] ? 5'h15 : _B_lz_T_95; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _B_lz_T_97 = _B_lz_T_70[20] ? 5'h14 : _B_lz_T_96; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _B_lz_T_98 = _B_lz_T_70[19] ? 5'h13 : _B_lz_T_97; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _B_lz_T_99 = _B_lz_T_70[18] ? 5'h12 : _B_lz_T_98; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _B_lz_T_100 = _B_lz_T_70[17] ? 5'h11 : _B_lz_T_99; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _B_lz_T_101 = _B_lz_T_70[16] ? 5'h10 : _B_lz_T_100; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _B_lz_T_102 = _B_lz_T_70[15] ? 5'hf : _B_lz_T_101; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _B_lz_T_103 = _B_lz_T_70[14] ? 5'he : _B_lz_T_102; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _B_lz_T_104 = _B_lz_T_70[13] ? 5'hd : _B_lz_T_103; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _B_lz_T_105 = _B_lz_T_70[12] ? 5'hc : _B_lz_T_104; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _B_lz_T_106 = _B_lz_T_70[11] ? 5'hb : _B_lz_T_105; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _B_lz_T_107 = _B_lz_T_70[10] ? 5'ha : _B_lz_T_106; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _B_lz_T_108 = _B_lz_T_70[9] ? 5'h9 : _B_lz_T_107; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _B_lz_T_109 = _B_lz_T_70[8] ? 5'h8 : _B_lz_T_108; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _B_lz_T_110 = _B_lz_T_70[7] ? 5'h7 : _B_lz_T_109; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _B_lz_T_111 = _B_lz_T_70[6] ? 5'h6 : _B_lz_T_110; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _B_lz_T_112 = _B_lz_T_70[5] ? 5'h5 : _B_lz_T_111; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _B_lz_T_113 = _B_lz_T_70[4] ? 5'h4 : _B_lz_T_112; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _B_lz_T_114 = _B_lz_T_70[3] ? 5'h3 : _B_lz_T_113; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _B_lz_T_115 = _B_lz_T_70[2] ? 5'h2 : _B_lz_T_114; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _B_lz_T_116 = _B_lz_T_70[1] ? 5'h1 : _B_lz_T_115; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] B_lz = _B_lz_T_70[0] ? 5'h0 : _B_lz_T_116; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [54:0] _GEN_1 = {{31'd0}, B_raw}; // @[src/main/scala/rv32i/Fpu.scala 74:19]
  wire [54:0] _B_w_sig_T = _GEN_1 << B_lz; // @[src/main/scala/rv32i/Fpu.scala 74:19]
  wire [23:0] B_sig = _B_w_sig_T[23:0]; // @[src/main/scala/rv32i/Fpu.scala 74:25]
  wire [8:0] _B_eLsb_T_1 = {1'b0,$signed(B_ef)}; // @[src/main/scala/rv32i/Fpu.scala 75:51]
  wire [12:0] _B_eLsb_T_2 = {{4{_B_eLsb_T_1[8]}},_B_eLsb_T_1}; // @[src/main/scala/rv32i/Fpu.scala 75:59]
  wire [12:0] _B_eLsb_T_5 = $signed(_B_eLsb_T_2) - 13'sh96; // @[src/main/scala/rv32i/Fpu.scala 75:64]
  wire [12:0] B_eLsb = _B_w_zero_T ? $signed(-13'sh95) : $signed(_B_eLsb_T_5); // @[src/main/scala/rv32i/Fpu.scala 75:19]
  wire [12:0] _B_w_exp_T_2 = $signed(B_eLsb) + 13'sh17; // @[src/main/scala/rv32i/Fpu.scala 76:19]
  wire [5:0] _B_w_exp_T_3 = {1'b0,$signed(B_lz)}; // @[src/main/scala/rv32i/Fpu.scala 76:37]
  wire [12:0] _B_w_exp_T_4 = {{7{_B_w_exp_T_3[5]}},_B_w_exp_T_3}; // @[src/main/scala/rv32i/Fpu.scala 76:45]
  wire [12:0] B_exp = $signed(_B_w_exp_T_2) - $signed(_B_w_exp_T_4); // @[src/main/scala/rv32i/Fpu.scala 76:32]
  wire [7:0] C_ef = rc[30:23]; // @[src/main/scala/rv32i/Fpu.scala 65:15]
  wire [22:0] C_f = rc[22:0]; // @[src/main/scala/rv32i/Fpu.scala 66:15]
  wire  C_sign = rc[31]; // @[src/main/scala/rv32i/Fpu.scala 67:16]
  wire  _C_w_zero_T = C_ef == 8'h0; // @[src/main/scala/rv32i/Fpu.scala 68:18]
  wire  _C_w_zero_T_1 = C_f == 23'h0; // @[src/main/scala/rv32i/Fpu.scala 68:31]
  wire  C_zero = C_ef == 8'h0 & C_f == 23'h0; // @[src/main/scala/rv32i/Fpu.scala 68:26]
  wire  _C_w_inf_T = &C_ef; // @[src/main/scala/rv32i/Fpu.scala 69:18]
  wire  C_inf = &C_ef & _C_w_zero_T_1; // @[src/main/scala/rv32i/Fpu.scala 69:23]
  wire  C_nan = _C_w_inf_T & C_f != 23'h0; // @[src/main/scala/rv32i/Fpu.scala 70:23]
  wire  C_snan = C_nan & ~C_f[22]; // @[src/main/scala/rv32i/Fpu.scala 71:21]
  wire [23:0] C_raw = {C_ef != 8'h0,C_f}; // @[src/main/scala/rv32i/Fpu.scala 72:18]
  wire [15:0] _GEN_400 = {{8'd0}, C_raw[15:8]}; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _C_lz_T_4 = _GEN_400 & 16'hff; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _C_lz_T_6 = {C_raw[7:0], 8'h0}; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _C_lz_T_8 = _C_lz_T_6 & 16'hff00; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _C_lz_T_9 = _C_lz_T_4 | _C_lz_T_8; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _GEN_401 = {{4'd0}, _C_lz_T_9[15:4]}; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _C_lz_T_14 = _GEN_401 & 16'hf0f; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _C_lz_T_16 = {_C_lz_T_9[11:0], 4'h0}; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _C_lz_T_18 = _C_lz_T_16 & 16'hf0f0; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _C_lz_T_19 = _C_lz_T_14 | _C_lz_T_18; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _GEN_402 = {{2'd0}, _C_lz_T_19[15:2]}; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _C_lz_T_24 = _GEN_402 & 16'h3333; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _C_lz_T_26 = {_C_lz_T_19[13:0], 2'h0}; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _C_lz_T_28 = _C_lz_T_26 & 16'hcccc; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _C_lz_T_29 = _C_lz_T_24 | _C_lz_T_28; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _GEN_403 = {{1'd0}, _C_lz_T_29[15:1]}; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _C_lz_T_34 = _GEN_403 & 16'h5555; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _C_lz_T_36 = {_C_lz_T_29[14:0], 1'h0}; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _C_lz_T_38 = _C_lz_T_36 & 16'haaaa; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [15:0] _C_lz_T_39 = _C_lz_T_34 | _C_lz_T_38; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [7:0] _GEN_404 = {{4'd0}, C_raw[23:20]}; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [7:0] _C_lz_T_44 = _GEN_404 & 8'hf; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [7:0] _C_lz_T_46 = {C_raw[19:16], 4'h0}; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [7:0] _C_lz_T_48 = _C_lz_T_46 & 8'hf0; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [7:0] _C_lz_T_49 = _C_lz_T_44 | _C_lz_T_48; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [7:0] _GEN_405 = {{2'd0}, _C_lz_T_49[7:2]}; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [7:0] _C_lz_T_54 = _GEN_405 & 8'h33; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [7:0] _C_lz_T_56 = {_C_lz_T_49[5:0], 2'h0}; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [7:0] _C_lz_T_58 = _C_lz_T_56 & 8'hcc; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [7:0] _C_lz_T_59 = _C_lz_T_54 | _C_lz_T_58; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [7:0] _GEN_406 = {{1'd0}, _C_lz_T_59[7:1]}; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [7:0] _C_lz_T_64 = _GEN_406 & 8'h55; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [7:0] _C_lz_T_66 = {_C_lz_T_59[6:0], 1'h0}; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [7:0] _C_lz_T_68 = _C_lz_T_66 & 8'haa; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [7:0] _C_lz_T_69 = _C_lz_T_64 | _C_lz_T_68; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [23:0] _C_lz_T_70 = {_C_lz_T_39,_C_lz_T_69}; // @[src/main/scala/rv32i/Fpu.scala 73:38]
  wire [4:0] _C_lz_T_95 = _C_lz_T_70[22] ? 5'h16 : 5'h17; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _C_lz_T_96 = _C_lz_T_70[21] ? 5'h15 : _C_lz_T_95; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _C_lz_T_97 = _C_lz_T_70[20] ? 5'h14 : _C_lz_T_96; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _C_lz_T_98 = _C_lz_T_70[19] ? 5'h13 : _C_lz_T_97; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _C_lz_T_99 = _C_lz_T_70[18] ? 5'h12 : _C_lz_T_98; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _C_lz_T_100 = _C_lz_T_70[17] ? 5'h11 : _C_lz_T_99; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _C_lz_T_101 = _C_lz_T_70[16] ? 5'h10 : _C_lz_T_100; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _C_lz_T_102 = _C_lz_T_70[15] ? 5'hf : _C_lz_T_101; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _C_lz_T_103 = _C_lz_T_70[14] ? 5'he : _C_lz_T_102; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _C_lz_T_104 = _C_lz_T_70[13] ? 5'hd : _C_lz_T_103; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _C_lz_T_105 = _C_lz_T_70[12] ? 5'hc : _C_lz_T_104; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _C_lz_T_106 = _C_lz_T_70[11] ? 5'hb : _C_lz_T_105; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _C_lz_T_107 = _C_lz_T_70[10] ? 5'ha : _C_lz_T_106; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _C_lz_T_108 = _C_lz_T_70[9] ? 5'h9 : _C_lz_T_107; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _C_lz_T_109 = _C_lz_T_70[8] ? 5'h8 : _C_lz_T_108; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _C_lz_T_110 = _C_lz_T_70[7] ? 5'h7 : _C_lz_T_109; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _C_lz_T_111 = _C_lz_T_70[6] ? 5'h6 : _C_lz_T_110; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _C_lz_T_112 = _C_lz_T_70[5] ? 5'h5 : _C_lz_T_111; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _C_lz_T_113 = _C_lz_T_70[4] ? 5'h4 : _C_lz_T_112; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _C_lz_T_114 = _C_lz_T_70[3] ? 5'h3 : _C_lz_T_113; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _C_lz_T_115 = _C_lz_T_70[2] ? 5'h2 : _C_lz_T_114; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] _C_lz_T_116 = _C_lz_T_70[1] ? 5'h1 : _C_lz_T_115; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [4:0] C_lz = _C_lz_T_70[0] ? 5'h0 : _C_lz_T_116; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [54:0] _GEN_2 = {{31'd0}, C_raw}; // @[src/main/scala/rv32i/Fpu.scala 74:19]
  wire [54:0] _C_w_sig_T = _GEN_2 << C_lz; // @[src/main/scala/rv32i/Fpu.scala 74:19]
  wire [23:0] C_sig = _C_w_sig_T[23:0]; // @[src/main/scala/rv32i/Fpu.scala 74:25]
  wire [8:0] _C_eLsb_T_1 = {1'b0,$signed(C_ef)}; // @[src/main/scala/rv32i/Fpu.scala 75:51]
  wire [12:0] _C_eLsb_T_2 = {{4{_C_eLsb_T_1[8]}},_C_eLsb_T_1}; // @[src/main/scala/rv32i/Fpu.scala 75:59]
  wire [12:0] _C_eLsb_T_5 = $signed(_C_eLsb_T_2) - 13'sh96; // @[src/main/scala/rv32i/Fpu.scala 75:64]
  wire [12:0] C_eLsb = _C_w_zero_T ? $signed(-13'sh95) : $signed(_C_eLsb_T_5); // @[src/main/scala/rv32i/Fpu.scala 75:19]
  wire [12:0] _C_w_exp_T_2 = $signed(C_eLsb) + 13'sh17; // @[src/main/scala/rv32i/Fpu.scala 76:19]
  wire [5:0] _C_w_exp_T_3 = {1'b0,$signed(C_lz)}; // @[src/main/scala/rv32i/Fpu.scala 76:37]
  wire [12:0] _C_w_exp_T_4 = {{7{_C_w_exp_T_3[5]}},_C_w_exp_T_3}; // @[src/main/scala/rv32i/Fpu.scala 76:45]
  wire [12:0] C_exp = $signed(_C_w_exp_T_2) - $signed(_C_w_exp_T_4); // @[src/main/scala/rv32i/Fpu.scala 76:32]
  wire  _isAddSub_T_1 = op == 4'h1; // @[src/main/scala/rv32i/Fpu.scala 131:44]
  wire  isAddSub = op == 4'h0 | op == 4'h1; // @[src/main/scala/rv32i/Fpu.scala 131:62]
  wire  isMul = op == 4'h2; // @[src/main/scala/rv32i/Fpu.scala 131:44]
  wire  isFma = op == 4'h5 | op == 4'h6 | op == 4'h7 | op == 4'h8; // @[src/main/scala/rv32i/Fpu.scala 131:62]
  wire  isDiv = op == 4'h3; // @[src/main/scala/rv32i/Fpu.scala 131:44]
  wire  isSqrt = op == 4'h4; // @[src/main/scala/rv32i/Fpu.scala 131:44]
  wire  _isToInt_T = op == 4'h9; // @[src/main/scala/rv32i/Fpu.scala 131:44]
  wire  isToInt = op == 4'h9 | op == 4'ha; // @[src/main/scala/rv32i/Fpu.scala 131:62]
  wire  _isFromInt_T = op == 4'hb; // @[src/main/scala/rv32i/Fpu.scala 131:44]
  wire  negProd = op == 4'h7 | op == 4'h8; // @[src/main/scala/rv32i/Fpu.scala 131:62]
  wire  negC = op == 4'h6 | op == 4'h8; // @[src/main/scala/rv32i/Fpu.scala 131:62]
  reg  xSign; // @[src/main/scala/rv32i/Fpu.scala 155:18]
  reg  xZero; // @[src/main/scala/rv32i/Fpu.scala 155:43]
  reg [47:0] xSig; // @[src/main/scala/rv32i/Fpu.scala 155:67]
  reg [12:0] xExp; // @[src/main/scala/rv32i/Fpu.scala 155:95]
  reg  ySign; // @[src/main/scala/rv32i/Fpu.scala 156:18]
  reg  yZero; // @[src/main/scala/rv32i/Fpu.scala 156:43]
  reg [47:0] ySig; // @[src/main/scala/rv32i/Fpu.scala 156:67]
  reg [12:0] yExp; // @[src/main/scala/rv32i/Fpu.scala 156:95]
  reg [47:0] acc; // @[src/main/scala/rv32i/Fpu.scala 157:21]
  reg [47:0] mcand; // @[src/main/scala/rv32i/Fpu.scala 158:21]
  reg [23:0] mplier; // @[src/main/scala/rv32i/Fpu.scala 159:21]
  reg [4:0] count; // @[src/main/scala/rv32i/Fpu.scala 160:21]
  reg [30:0] rem; // @[src/main/scala/rv32i/Fpu.scala 161:21]
  reg [26:0] quo; // @[src/main/scala/rv32i/Fpu.scala 162:21]
  reg [23:0] divisor; // @[src/main/scala/rv32i/Fpu.scala 163:21]
  reg [53:0] radicand; // @[src/main/scala/rv32i/Fpu.scala 164:21]
  reg [55:0] raw; // @[src/main/scala/rv32i/Fpu.scala 165:21]
  reg [12:0] rawE; // @[src/main/scala/rv32i/Fpu.scala 166:21]
  reg  sticky; // @[src/main/scala/rv32i/Fpu.scala 167:21]
  reg  rSign; // @[src/main/scala/rv32i/Fpu.scala 168:21]
  reg [55:0] nSig; // @[src/main/scala/rv32i/Fpu.scala 169:21]
  reg [12:0] nExp; // @[src/main/scala/rv32i/Fpu.scala 170:21]
  reg [31:0] resBits; // @[src/main/scala/rv32i/Fpu.scala 171:21]
  reg [4:0] resFlags; // @[src/main/scala/rv32i/Fpu.scala 172:21]
  wire  sb = B_sign ^ _isAddSub_T_1; // @[src/main/scala/rv32i/Fpu.scala 181:23]
  wire  _T_2 = A_nan | B_nan; // @[src/main/scala/rv32i/Fpu.scala 182:18]
  wire  _T_3 = A_snan | B_snan; // @[src/main/scala/rv32i/Fpu.scala 182:53]
  wire [4:0] _T_4 = A_snan | B_snan ? 5'h10 : 5'h0; // @[src/main/scala/rv32i/Fpu.scala 182:45]
  wire  _T_5 = A_inf & B_inf; // @[src/main/scala/rv32i/Fpu.scala 183:25]
  wire  _T_6 = A_sign == sb; // @[src/main/scala/rv32i/Fpu.scala 183:55]
  wire [31:0] _T_7 = {A_sign,31'h7f800000}; // @[src/main/scala/rv32i/Fpu.scala 143:32]
  wire [31:0] _T_8 = A_sign == sb ? _T_7 : 32'h7fc00000; // @[src/main/scala/rv32i/Fpu.scala 183:47]
  wire [4:0] _T_10 = A_sign == sb ? 5'h0 : 5'h10; // @[src/main/scala/rv32i/Fpu.scala 183:85]
  wire [31:0] _T_12 = {sb,31'h7f800000}; // @[src/main/scala/rv32i/Fpu.scala 143:32]
  wire  _T_13 = A_zero & B_zero; // @[src/main/scala/rv32i/Fpu.scala 186:26]
  wire  _T_15 = rm == 3'h2; // @[src/main/scala/rv32i/Fpu.scala 186:81]
  wire  _T_16 = _T_6 ? A_sign : rm == 3'h2; // @[src/main/scala/rv32i/Fpu.scala 186:54]
  wire [31:0] _T_17 = {_T_16,31'h0}; // @[src/main/scala/rv32i/Fpu.scala 144:32]
  wire [47:0] _xSig_T = {A_sig,24'h0}; // @[src/main/scala/rv32i/Fpu.scala 188:56]
  wire [47:0] _ySig_T = {B_sig,24'h0}; // @[src/main/scala/rv32i/Fpu.scala 189:56]
  wire [31:0] _GEN_6 = A_zero & B_zero ? _T_17 : resBits; // @[src/main/scala/rv32i/Fpu.scala 171:21 186:37 174:57]
  wire [4:0] _GEN_7 = A_zero & B_zero ? 5'h0 : resFlags; // @[src/main/scala/rv32i/Fpu.scala 172:21 186:37 174:75]
  wire [3:0] _GEN_8 = A_zero & B_zero ? 4'h9 : 4'h3; // @[src/main/scala/rv32i/Fpu.scala 186:37 174:91 190:17]
  wire  _GEN_9 = A_zero & B_zero ? xSign : A_sign; // @[src/main/scala/rv32i/Fpu.scala 155:18 186:37 188:17]
  wire  _GEN_10 = A_zero & B_zero ? xZero : A_zero; // @[src/main/scala/rv32i/Fpu.scala 186:37 155:43 188:34]
  wire [47:0] _GEN_11 = A_zero & B_zero ? xSig : _xSig_T; // @[src/main/scala/rv32i/Fpu.scala 186:37 155:67 188:50]
  wire [12:0] _GEN_12 = A_zero & B_zero ? $signed(xExp) : $signed(A_exp); // @[src/main/scala/rv32i/Fpu.scala 186:37 155:95 188:81]
  wire  _GEN_13 = A_zero & B_zero ? ySign : sb; // @[src/main/scala/rv32i/Fpu.scala 156:18 186:37 189:17]
  wire  _GEN_14 = A_zero & B_zero ? yZero : B_zero; // @[src/main/scala/rv32i/Fpu.scala 186:37 156:43 189:34]
  wire [47:0] _GEN_15 = A_zero & B_zero ? ySig : _ySig_T; // @[src/main/scala/rv32i/Fpu.scala 186:37 156:67 189:50]
  wire [12:0] _GEN_16 = A_zero & B_zero ? $signed(yExp) : $signed(B_exp); // @[src/main/scala/rv32i/Fpu.scala 186:37 156:95 189:81]
  wire [31:0] _GEN_17 = B_inf ? _T_12 : _GEN_6; // @[src/main/scala/rv32i/Fpu.scala 185:26 174:57]
  wire [4:0] _GEN_18 = B_inf ? 5'h0 : _GEN_7; // @[src/main/scala/rv32i/Fpu.scala 185:26 174:75]
  wire [3:0] _GEN_19 = B_inf ? 4'h9 : _GEN_8; // @[src/main/scala/rv32i/Fpu.scala 185:26 174:91]
  wire  _GEN_20 = B_inf ? xSign : _GEN_9; // @[src/main/scala/rv32i/Fpu.scala 155:18 185:26]
  wire  _GEN_21 = B_inf ? xZero : _GEN_10; // @[src/main/scala/rv32i/Fpu.scala 185:26 155:43]
  wire [47:0] _GEN_22 = B_inf ? xSig : _GEN_11; // @[src/main/scala/rv32i/Fpu.scala 185:26 155:67]
  wire [12:0] _GEN_23 = B_inf ? $signed(xExp) : $signed(_GEN_12); // @[src/main/scala/rv32i/Fpu.scala 185:26 155:95]
  wire  _GEN_24 = B_inf ? ySign : _GEN_13; // @[src/main/scala/rv32i/Fpu.scala 156:18 185:26]
  wire  _GEN_25 = B_inf ? yZero : _GEN_14; // @[src/main/scala/rv32i/Fpu.scala 185:26 156:43]
  wire [47:0] _GEN_26 = B_inf ? ySig : _GEN_15; // @[src/main/scala/rv32i/Fpu.scala 185:26 156:67]
  wire [12:0] _GEN_27 = B_inf ? $signed(yExp) : $signed(_GEN_16); // @[src/main/scala/rv32i/Fpu.scala 185:26 156:95]
  wire [31:0] _GEN_28 = A_inf ? _T_7 : _GEN_17; // @[src/main/scala/rv32i/Fpu.scala 184:26 174:57]
  wire [4:0] _GEN_29 = A_inf ? 5'h0 : _GEN_18; // @[src/main/scala/rv32i/Fpu.scala 184:26 174:75]
  wire [3:0] _GEN_30 = A_inf ? 4'h9 : _GEN_19; // @[src/main/scala/rv32i/Fpu.scala 184:26 174:91]
  wire  _GEN_31 = A_inf ? xSign : _GEN_20; // @[src/main/scala/rv32i/Fpu.scala 155:18 184:26]
  wire  _GEN_32 = A_inf ? xZero : _GEN_21; // @[src/main/scala/rv32i/Fpu.scala 184:26 155:43]
  wire [47:0] _GEN_33 = A_inf ? xSig : _GEN_22; // @[src/main/scala/rv32i/Fpu.scala 184:26 155:67]
  wire [12:0] _GEN_34 = A_inf ? $signed(xExp) : $signed(_GEN_23); // @[src/main/scala/rv32i/Fpu.scala 184:26 155:95]
  wire  _GEN_35 = A_inf ? ySign : _GEN_24; // @[src/main/scala/rv32i/Fpu.scala 156:18 184:26]
  wire  _GEN_36 = A_inf ? yZero : _GEN_25; // @[src/main/scala/rv32i/Fpu.scala 184:26 156:43]
  wire [47:0] _GEN_37 = A_inf ? ySig : _GEN_26; // @[src/main/scala/rv32i/Fpu.scala 184:26 156:67]
  wire [12:0] _GEN_38 = A_inf ? $signed(yExp) : $signed(_GEN_27); // @[src/main/scala/rv32i/Fpu.scala 184:26 156:95]
  wire [31:0] _GEN_39 = A_inf & B_inf ? _T_8 : _GEN_28; // @[src/main/scala/rv32i/Fpu.scala 183:35 174:57]
  wire [4:0] _GEN_40 = A_inf & B_inf ? _T_10 : _GEN_29; // @[src/main/scala/rv32i/Fpu.scala 183:35 174:75]
  wire [3:0] _GEN_41 = A_inf & B_inf ? 4'h9 : _GEN_30; // @[src/main/scala/rv32i/Fpu.scala 183:35 174:91]
  wire [31:0] _GEN_50 = A_nan | B_nan ? 32'h7fc00000 : _GEN_39; // @[src/main/scala/rv32i/Fpu.scala 182:28 174:57]
  wire [4:0] _GEN_51 = A_nan | B_nan ? _T_4 : _GEN_40; // @[src/main/scala/rv32i/Fpu.scala 182:28 174:75]
  wire [3:0] _GEN_52 = A_nan | B_nan ? 4'h9 : _GEN_41; // @[src/main/scala/rv32i/Fpu.scala 182:28 174:91]
  wire  _ps_T = A_sign ^ B_sign; // @[src/main/scala/rv32i/Fpu.scala 193:23]
  wire  ps = A_sign ^ B_sign ^ negProd; // @[src/main/scala/rv32i/Fpu.scala 193:32]
  wire  cs = C_sign ^ negC; // @[src/main/scala/rv32i/Fpu.scala 194:23]
  wire  infTimesZero = A_inf & B_zero | A_zero & B_inf; // @[src/main/scala/rv32i/Fpu.scala 195:44]
  wire [4:0] _T_25 = _T_3 | isFma & C_snan ? 5'h10 : 5'h0; // @[src/main/scala/rv32i/Fpu.scala 198:26]
  wire  _T_27 = isFma & C_inf; // @[src/main/scala/rv32i/Fpu.scala 201:22]
  wire [31:0] _T_30 = {ps,31'h7f800000}; // @[src/main/scala/rv32i/Fpu.scala 143:32]
  wire [31:0] _GEN_61 = isFma & C_inf & cs != ps ? 32'h7fc00000 : _T_30; // @[src/main/scala/rv32i/Fpu.scala 201:45 174:{57,57}]
  wire [4:0] _GEN_62 = isFma & C_inf & cs != ps ? 5'h10 : 5'h0; // @[src/main/scala/rv32i/Fpu.scala 201:45 174:{75,75}]
  wire [31:0] _T_32 = {cs,31'h7f800000}; // @[src/main/scala/rv32i/Fpu.scala 143:32]
  wire  _T_39 = isMul | ps == cs ? ps : _T_15; // @[src/main/scala/rv32i/Fpu.scala 205:26]
  wire [31:0] _T_40 = {_T_39,31'h0}; // @[src/main/scala/rv32i/Fpu.scala 144:32]
  wire [12:0] _xExp_T_2 = $signed(A_exp) + $signed(B_exp); // @[src/main/scala/rv32i/Fpu.scala 209:65]
  wire [47:0] _ySig_T_1 = {C_sig,24'h0}; // @[src/main/scala/rv32i/Fpu.scala 210:61]
  wire [31:0] _GEN_64 = (A_zero | B_zero) & (isMul | C_zero) ? _T_40 : resBits; // @[src/main/scala/rv32i/Fpu.scala 171:21 174:57 204:60]
  wire [4:0] _GEN_65 = (A_zero | B_zero) & (isMul | C_zero) ? 5'h0 : resFlags; // @[src/main/scala/rv32i/Fpu.scala 172:21 204:60 174:75]
  wire [3:0] _GEN_66 = (A_zero | B_zero) & (isMul | C_zero) ? 4'h9 : 4'h2; // @[src/main/scala/rv32i/Fpu.scala 204:60 174:91 211:17]
  wire [47:0] _GEN_67 = (A_zero | B_zero) & (isMul | C_zero) ? acc : 48'h0; // @[src/main/scala/rv32i/Fpu.scala 157:21 204:60 208:15]
  wire [47:0] _GEN_68 = (A_zero | B_zero) & (isMul | C_zero) ? mcand : {{24'd0}, A_sig}; // @[src/main/scala/rv32i/Fpu.scala 158:21 204:60 208:29]
  wire [23:0] _GEN_69 = (A_zero | B_zero) & (isMul | C_zero) ? mplier : B_sig; // @[src/main/scala/rv32i/Fpu.scala 159:21 204:60 208:46]
  wire [4:0] _GEN_70 = (A_zero | B_zero) & (isMul | C_zero) ? count : 5'h0; // @[src/main/scala/rv32i/Fpu.scala 160:21 204:60 208:62]
  wire  _GEN_71 = (A_zero | B_zero) & (isMul | C_zero) ? xSign : ps; // @[src/main/scala/rv32i/Fpu.scala 155:18 204:60 209:17]
  wire  _GEN_72 = (A_zero | B_zero) & (isMul | C_zero) ? xZero : A_zero | B_zero; // @[src/main/scala/rv32i/Fpu.scala 155:43 204:60 209:30]
  wire [12:0] _GEN_73 = (A_zero | B_zero) & (isMul | C_zero) ? $signed(xExp) : $signed(_xExp_T_2); // @[src/main/scala/rv32i/Fpu.scala 204:60 155:95 209:56]
  wire  _GEN_74 = (A_zero | B_zero) & (isMul | C_zero) ? ySign : cs; // @[src/main/scala/rv32i/Fpu.scala 156:18 204:60 210:17]
  wire  _GEN_75 = (A_zero | B_zero) & (isMul | C_zero) ? yZero : isMul | C_zero; // @[src/main/scala/rv32i/Fpu.scala 156:43 204:60 210:30]
  wire [47:0] _GEN_76 = (A_zero | B_zero) & (isMul | C_zero) ? ySig : _ySig_T_1; // @[src/main/scala/rv32i/Fpu.scala 204:60 156:67 210:55]
  wire [12:0] _GEN_77 = (A_zero | B_zero) & (isMul | C_zero) ? $signed(yExp) : $signed(C_exp); // @[src/main/scala/rv32i/Fpu.scala 204:60 156:95 210:86]
  wire [31:0] _GEN_78 = _T_27 ? _T_32 : _GEN_64; // @[src/main/scala/rv32i/Fpu.scala 203:35 174:57]
  wire [4:0] _GEN_79 = _T_27 ? 5'h0 : _GEN_65; // @[src/main/scala/rv32i/Fpu.scala 203:35 174:75]
  wire [3:0] _GEN_80 = _T_27 ? 4'h9 : _GEN_66; // @[src/main/scala/rv32i/Fpu.scala 203:35 174:91]
  wire [47:0] _GEN_81 = _T_27 ? acc : _GEN_67; // @[src/main/scala/rv32i/Fpu.scala 157:21 203:35]
  wire [47:0] _GEN_82 = _T_27 ? mcand : _GEN_68; // @[src/main/scala/rv32i/Fpu.scala 158:21 203:35]
  wire [23:0] _GEN_83 = _T_27 ? mplier : _GEN_69; // @[src/main/scala/rv32i/Fpu.scala 159:21 203:35]
  wire [4:0] _GEN_84 = _T_27 ? count : _GEN_70; // @[src/main/scala/rv32i/Fpu.scala 160:21 203:35]
  wire  _GEN_85 = _T_27 ? xSign : _GEN_71; // @[src/main/scala/rv32i/Fpu.scala 155:18 203:35]
  wire  _GEN_86 = _T_27 ? xZero : _GEN_72; // @[src/main/scala/rv32i/Fpu.scala 203:35 155:43]
  wire [12:0] _GEN_87 = _T_27 ? $signed(xExp) : $signed(_GEN_73); // @[src/main/scala/rv32i/Fpu.scala 203:35 155:95]
  wire  _GEN_88 = _T_27 ? ySign : _GEN_74; // @[src/main/scala/rv32i/Fpu.scala 156:18 203:35]
  wire  _GEN_89 = _T_27 ? yZero : _GEN_75; // @[src/main/scala/rv32i/Fpu.scala 203:35 156:43]
  wire [47:0] _GEN_90 = _T_27 ? ySig : _GEN_76; // @[src/main/scala/rv32i/Fpu.scala 203:35 156:67]
  wire [12:0] _GEN_91 = _T_27 ? $signed(yExp) : $signed(_GEN_77); // @[src/main/scala/rv32i/Fpu.scala 203:35 156:95]
  wire [31:0] _GEN_92 = A_inf | B_inf ? _GEN_61 : _GEN_78; // @[src/main/scala/rv32i/Fpu.scala 200:35]
  wire [4:0] _GEN_93 = A_inf | B_inf ? _GEN_62 : _GEN_79; // @[src/main/scala/rv32i/Fpu.scala 200:35]
  wire [3:0] _GEN_94 = A_inf | B_inf ? 4'h9 : _GEN_80; // @[src/main/scala/rv32i/Fpu.scala 200:35]
  wire [47:0] _GEN_95 = A_inf | B_inf ? acc : _GEN_81; // @[src/main/scala/rv32i/Fpu.scala 157:21 200:35]
  wire [47:0] _GEN_96 = A_inf | B_inf ? mcand : _GEN_82; // @[src/main/scala/rv32i/Fpu.scala 158:21 200:35]
  wire [23:0] _GEN_97 = A_inf | B_inf ? mplier : _GEN_83; // @[src/main/scala/rv32i/Fpu.scala 159:21 200:35]
  wire [4:0] _GEN_98 = A_inf | B_inf ? count : _GEN_84; // @[src/main/scala/rv32i/Fpu.scala 160:21 200:35]
  wire  _GEN_99 = A_inf | B_inf ? xSign : _GEN_85; // @[src/main/scala/rv32i/Fpu.scala 155:18 200:35]
  wire  _GEN_100 = A_inf | B_inf ? xZero : _GEN_86; // @[src/main/scala/rv32i/Fpu.scala 200:35 155:43]
  wire [12:0] _GEN_101 = A_inf | B_inf ? $signed(xExp) : $signed(_GEN_87); // @[src/main/scala/rv32i/Fpu.scala 200:35 155:95]
  wire  _GEN_102 = A_inf | B_inf ? ySign : _GEN_88; // @[src/main/scala/rv32i/Fpu.scala 156:18 200:35]
  wire  _GEN_103 = A_inf | B_inf ? yZero : _GEN_89; // @[src/main/scala/rv32i/Fpu.scala 200:35 156:43]
  wire [47:0] _GEN_104 = A_inf | B_inf ? ySig : _GEN_90; // @[src/main/scala/rv32i/Fpu.scala 200:35 156:67]
  wire [12:0] _GEN_105 = A_inf | B_inf ? $signed(yExp) : $signed(_GEN_91); // @[src/main/scala/rv32i/Fpu.scala 200:35 156:95]
  wire [31:0] _GEN_106 = _T_2 | isFma & C_nan ? 32'h7fc00000 : _GEN_92; // @[src/main/scala/rv32i/Fpu.scala 197:55 174:57]
  wire [4:0] _GEN_107 = _T_2 | isFma & C_nan ? _T_25 : _GEN_93; // @[src/main/scala/rv32i/Fpu.scala 197:55 174:75]
  wire [3:0] _GEN_108 = _T_2 | isFma & C_nan ? 4'h9 : _GEN_94; // @[src/main/scala/rv32i/Fpu.scala 197:55 174:91]
  wire [47:0] _GEN_109 = _T_2 | isFma & C_nan ? acc : _GEN_95; // @[src/main/scala/rv32i/Fpu.scala 157:21 197:55]
  wire [47:0] _GEN_110 = _T_2 | isFma & C_nan ? mcand : _GEN_96; // @[src/main/scala/rv32i/Fpu.scala 158:21 197:55]
  wire [23:0] _GEN_111 = _T_2 | isFma & C_nan ? mplier : _GEN_97; // @[src/main/scala/rv32i/Fpu.scala 159:21 197:55]
  wire [4:0] _GEN_112 = _T_2 | isFma & C_nan ? count : _GEN_98; // @[src/main/scala/rv32i/Fpu.scala 160:21 197:55]
  wire  _GEN_113 = _T_2 | isFma & C_nan ? xSign : _GEN_99; // @[src/main/scala/rv32i/Fpu.scala 155:18 197:55]
  wire  _GEN_114 = _T_2 | isFma & C_nan ? xZero : _GEN_100; // @[src/main/scala/rv32i/Fpu.scala 155:43 197:55]
  wire [12:0] _GEN_115 = _T_2 | isFma & C_nan ? $signed(xExp) : $signed(_GEN_101); // @[src/main/scala/rv32i/Fpu.scala 197:55 155:95]
  wire  _GEN_116 = _T_2 | isFma & C_nan ? ySign : _GEN_102; // @[src/main/scala/rv32i/Fpu.scala 156:18 197:55]
  wire  _GEN_117 = _T_2 | isFma & C_nan ? yZero : _GEN_103; // @[src/main/scala/rv32i/Fpu.scala 156:43 197:55]
  wire [47:0] _GEN_118 = _T_2 | isFma & C_nan ? ySig : _GEN_104; // @[src/main/scala/rv32i/Fpu.scala 197:55 156:67]
  wire [12:0] _GEN_119 = _T_2 | isFma & C_nan ? $signed(yExp) : $signed(_GEN_105); // @[src/main/scala/rv32i/Fpu.scala 197:55 156:95]
  wire [31:0] _GEN_120 = infTimesZero ? 32'h7fc00000 : _GEN_106; // @[src/main/scala/rv32i/Fpu.scala 196:26 174:57]
  wire [4:0] _GEN_121 = infTimesZero ? 5'h10 : _GEN_107; // @[src/main/scala/rv32i/Fpu.scala 196:26 174:75]
  wire [3:0] _GEN_122 = infTimesZero ? 4'h9 : _GEN_108; // @[src/main/scala/rv32i/Fpu.scala 196:26 174:91]
  wire [47:0] _GEN_123 = infTimesZero ? acc : _GEN_109; // @[src/main/scala/rv32i/Fpu.scala 157:21 196:26]
  wire [47:0] _GEN_124 = infTimesZero ? mcand : _GEN_110; // @[src/main/scala/rv32i/Fpu.scala 158:21 196:26]
  wire [23:0] _GEN_125 = infTimesZero ? mplier : _GEN_111; // @[src/main/scala/rv32i/Fpu.scala 159:21 196:26]
  wire [4:0] _GEN_126 = infTimesZero ? count : _GEN_112; // @[src/main/scala/rv32i/Fpu.scala 160:21 196:26]
  wire [31:0] _T_47 = {_ps_T,31'h7f800000}; // @[src/main/scala/rv32i/Fpu.scala 143:32]
  wire [31:0] _T_48 = {_ps_T,31'h0}; // @[src/main/scala/rv32i/Fpu.scala 144:32]
  wire [12:0] _rawE_T_2 = $signed(A_exp) - $signed(B_exp); // @[src/main/scala/rv32i/Fpu.scala 223:37]
  wire [12:0] _rawE_T_5 = $signed(_rawE_T_2) - 13'sh1a; // @[src/main/scala/rv32i/Fpu.scala 223:45]
  wire [31:0] _GEN_134 = A_zero ? _T_48 : resBits; // @[src/main/scala/rv32i/Fpu.scala 171:21 220:27 174:57]
  wire [4:0] _GEN_135 = A_zero ? 5'h0 : resFlags; // @[src/main/scala/rv32i/Fpu.scala 172:21 220:27 174:75]
  wire [3:0] _GEN_136 = A_zero ? 4'h9 : 4'h4; // @[src/main/scala/rv32i/Fpu.scala 220:27 174:91 224:17]
  wire [30:0] _GEN_137 = A_zero ? rem : {{7'd0}, A_sig}; // @[src/main/scala/rv32i/Fpu.scala 161:21 220:27 222:15]
  wire [23:0] _GEN_138 = A_zero ? divisor : B_sig; // @[src/main/scala/rv32i/Fpu.scala 163:21 220:27 222:33]
  wire [26:0] _GEN_139 = A_zero ? quo : 27'h0; // @[src/main/scala/rv32i/Fpu.scala 162:21 220:27 222:47]
  wire [4:0] _GEN_140 = A_zero ? count : 5'h0; // @[src/main/scala/rv32i/Fpu.scala 160:21 220:27 222:61]
  wire  _GEN_141 = A_zero ? rSign : _ps_T; // @[src/main/scala/rv32i/Fpu.scala 168:21 220:27 223:17]
  wire [12:0] _GEN_142 = A_zero ? $signed(rawE) : $signed(_rawE_T_5); // @[src/main/scala/rv32i/Fpu.scala 166:21 220:27 223:28]
  wire [31:0] _GEN_143 = B_zero ? _T_47 : _GEN_134; // @[src/main/scala/rv32i/Fpu.scala 219:27 174:57]
  wire [4:0] _GEN_144 = B_zero ? 5'h8 : _GEN_135; // @[src/main/scala/rv32i/Fpu.scala 219:27 174:75]
  wire [3:0] _GEN_145 = B_zero ? 4'h9 : _GEN_136; // @[src/main/scala/rv32i/Fpu.scala 219:27 174:91]
  wire [30:0] _GEN_146 = B_zero ? rem : _GEN_137; // @[src/main/scala/rv32i/Fpu.scala 161:21 219:27]
  wire [23:0] _GEN_147 = B_zero ? divisor : _GEN_138; // @[src/main/scala/rv32i/Fpu.scala 163:21 219:27]
  wire [26:0] _GEN_148 = B_zero ? quo : _GEN_139; // @[src/main/scala/rv32i/Fpu.scala 162:21 219:27]
  wire [4:0] _GEN_149 = B_zero ? count : _GEN_140; // @[src/main/scala/rv32i/Fpu.scala 160:21 219:27]
  wire  _GEN_150 = B_zero ? rSign : _GEN_141; // @[src/main/scala/rv32i/Fpu.scala 168:21 219:27]
  wire [12:0] _GEN_151 = B_zero ? $signed(rawE) : $signed(_GEN_142); // @[src/main/scala/rv32i/Fpu.scala 166:21 219:27]
  wire [31:0] _GEN_152 = B_inf ? _T_48 : _GEN_143; // @[src/main/scala/rv32i/Fpu.scala 218:26 174:57]
  wire [4:0] _GEN_153 = B_inf ? 5'h0 : _GEN_144; // @[src/main/scala/rv32i/Fpu.scala 218:26 174:75]
  wire [3:0] _GEN_154 = B_inf ? 4'h9 : _GEN_145; // @[src/main/scala/rv32i/Fpu.scala 218:26 174:91]
  wire [30:0] _GEN_155 = B_inf ? rem : _GEN_146; // @[src/main/scala/rv32i/Fpu.scala 161:21 218:26]
  wire [23:0] _GEN_156 = B_inf ? divisor : _GEN_147; // @[src/main/scala/rv32i/Fpu.scala 163:21 218:26]
  wire [26:0] _GEN_157 = B_inf ? quo : _GEN_148; // @[src/main/scala/rv32i/Fpu.scala 162:21 218:26]
  wire [4:0] _GEN_158 = B_inf ? count : _GEN_149; // @[src/main/scala/rv32i/Fpu.scala 160:21 218:26]
  wire  _GEN_159 = B_inf ? rSign : _GEN_150; // @[src/main/scala/rv32i/Fpu.scala 168:21 218:26]
  wire [12:0] _GEN_160 = B_inf ? $signed(rawE) : $signed(_GEN_151); // @[src/main/scala/rv32i/Fpu.scala 166:21 218:26]
  wire [31:0] _GEN_161 = A_inf ? _T_47 : _GEN_152; // @[src/main/scala/rv32i/Fpu.scala 217:26 174:57]
  wire [4:0] _GEN_162 = A_inf ? 5'h0 : _GEN_153; // @[src/main/scala/rv32i/Fpu.scala 217:26 174:75]
  wire [3:0] _GEN_163 = A_inf ? 4'h9 : _GEN_154; // @[src/main/scala/rv32i/Fpu.scala 217:26 174:91]
  wire [30:0] _GEN_164 = A_inf ? rem : _GEN_155; // @[src/main/scala/rv32i/Fpu.scala 161:21 217:26]
  wire [23:0] _GEN_165 = A_inf ? divisor : _GEN_156; // @[src/main/scala/rv32i/Fpu.scala 163:21 217:26]
  wire [26:0] _GEN_166 = A_inf ? quo : _GEN_157; // @[src/main/scala/rv32i/Fpu.scala 162:21 217:26]
  wire [4:0] _GEN_167 = A_inf ? count : _GEN_158; // @[src/main/scala/rv32i/Fpu.scala 160:21 217:26]
  wire  _GEN_168 = A_inf ? rSign : _GEN_159; // @[src/main/scala/rv32i/Fpu.scala 168:21 217:26]
  wire [12:0] _GEN_169 = A_inf ? $signed(rawE) : $signed(_GEN_160); // @[src/main/scala/rv32i/Fpu.scala 166:21 217:26]
  wire [31:0] _GEN_170 = _T_13 | _T_5 ? 32'h7fc00000 : _GEN_161; // @[src/main/scala/rv32i/Fpu.scala 174:57 216:59]
  wire [4:0] _GEN_171 = _T_13 | _T_5 ? 5'h10 : _GEN_162; // @[src/main/scala/rv32i/Fpu.scala 216:59 174:75]
  wire [3:0] _GEN_172 = _T_13 | _T_5 ? 4'h9 : _GEN_163; // @[src/main/scala/rv32i/Fpu.scala 216:59 174:91]
  wire [30:0] _GEN_173 = _T_13 | _T_5 ? rem : _GEN_164; // @[src/main/scala/rv32i/Fpu.scala 161:21 216:59]
  wire [23:0] _GEN_174 = _T_13 | _T_5 ? divisor : _GEN_165; // @[src/main/scala/rv32i/Fpu.scala 163:21 216:59]
  wire [26:0] _GEN_175 = _T_13 | _T_5 ? quo : _GEN_166; // @[src/main/scala/rv32i/Fpu.scala 162:21 216:59]
  wire [4:0] _GEN_176 = _T_13 | _T_5 ? count : _GEN_167; // @[src/main/scala/rv32i/Fpu.scala 160:21 216:59]
  wire  _GEN_177 = _T_13 | _T_5 ? rSign : _GEN_168; // @[src/main/scala/rv32i/Fpu.scala 168:21 216:59]
  wire [12:0] _GEN_178 = _T_13 | _T_5 ? $signed(rawE) : $signed(_GEN_169); // @[src/main/scala/rv32i/Fpu.scala 166:21 216:59]
  wire [31:0] _GEN_179 = _T_2 ? 32'h7fc00000 : _GEN_170; // @[src/main/scala/rv32i/Fpu.scala 215:28 174:57]
  wire [4:0] _GEN_180 = _T_2 ? _T_4 : _GEN_171; // @[src/main/scala/rv32i/Fpu.scala 215:28 174:75]
  wire [3:0] _GEN_181 = _T_2 ? 4'h9 : _GEN_172; // @[src/main/scala/rv32i/Fpu.scala 215:28 174:91]
  wire [30:0] _GEN_182 = _T_2 ? rem : _GEN_173; // @[src/main/scala/rv32i/Fpu.scala 161:21 215:28]
  wire [23:0] _GEN_183 = _T_2 ? divisor : _GEN_174; // @[src/main/scala/rv32i/Fpu.scala 163:21 215:28]
  wire [26:0] _GEN_184 = _T_2 ? quo : _GEN_175; // @[src/main/scala/rv32i/Fpu.scala 162:21 215:28]
  wire [4:0] _GEN_185 = _T_2 ? count : _GEN_176; // @[src/main/scala/rv32i/Fpu.scala 160:21 215:28]
  wire  _GEN_186 = _T_2 ? rSign : _GEN_177; // @[src/main/scala/rv32i/Fpu.scala 168:21 215:28]
  wire [12:0] _GEN_187 = _T_2 ? $signed(rawE) : $signed(_GEN_178); // @[src/main/scala/rv32i/Fpu.scala 166:21 215:28]
  wire [4:0] _T_51 = A_snan ? 5'h10 : 5'h0; // @[src/main/scala/rv32i/Fpu.scala 227:36]
  wire [12:0] e0 = $signed(A_exp) - 13'sh17; // @[src/main/scala/rv32i/Fpu.scala 232:27]
  wire  odd = e0[0]; // @[src/main/scala/rv32i/Fpu.scala 233:23]
  wire [24:0] _m_T = {A_sig,1'h0}; // @[src/main/scala/rv32i/Fpu.scala 234:33]
  wire [24:0] _m_T_1 = {1'h0,A_sig}; // @[src/main/scala/rv32i/Fpu.scala 234:55]
  wire [24:0] m = odd ? _m_T : _m_T_1; // @[src/main/scala/rv32i/Fpu.scala 234:24]
  wire [12:0] _e1_T_2 = $signed(e0) - 13'sh1; // @[src/main/scala/rv32i/Fpu.scala 235:33]
  wire [12:0] e1 = odd ? $signed(_e1_T_2) : $signed(e0); // @[src/main/scala/rv32i/Fpu.scala 235:24]
  wire [53:0] _radicand_T = {1'h0,m,28'h0}; // @[src/main/scala/rv32i/Fpu.scala 236:26]
  wire [11:0] _rawE_T_6 = e1[12:1]; // @[src/main/scala/rv32i/Fpu.scala 238:41]
  wire [12:0] _GEN_407 = {{1{_rawE_T_6[11]}},_rawE_T_6}; // @[src/main/scala/rv32i/Fpu.scala 238:47]
  wire [12:0] _rawE_T_9 = $signed(_GEN_407) - 13'she; // @[src/main/scala/rv32i/Fpu.scala 238:47]
  wire [31:0] _GEN_188 = A_inf ? 32'h7f800000 : resBits; // @[src/main/scala/rv32i/Fpu.scala 171:21 230:26 174:57]
  wire [4:0] _GEN_189 = A_inf ? 5'h0 : resFlags; // @[src/main/scala/rv32i/Fpu.scala 172:21 230:26 174:75]
  wire [3:0] _GEN_190 = A_inf ? 4'h9 : 4'h5; // @[src/main/scala/rv32i/Fpu.scala 230:26 174:91 239:17]
  wire [53:0] _GEN_191 = A_inf ? radicand : _radicand_T; // @[src/main/scala/rv32i/Fpu.scala 164:21 230:26 236:20]
  wire [30:0] _GEN_192 = A_inf ? rem : 31'h0; // @[src/main/scala/rv32i/Fpu.scala 161:21 230:26 237:15]
  wire [26:0] _GEN_193 = A_inf ? quo : 27'h0; // @[src/main/scala/rv32i/Fpu.scala 162:21 230:26 237:27]
  wire [4:0] _GEN_194 = A_inf ? count : 5'h0; // @[src/main/scala/rv32i/Fpu.scala 160:21 230:26 237:41]
  wire  _GEN_195 = A_inf & rSign; // @[src/main/scala/rv32i/Fpu.scala 168:21 230:26 238:17]
  wire [12:0] _GEN_196 = A_inf ? $signed(rawE) : $signed(_rawE_T_9); // @[src/main/scala/rv32i/Fpu.scala 166:21 230:26 238:34]
  wire [31:0] _GEN_197 = A_sign ? 32'h7fc00000 : _GEN_188; // @[src/main/scala/rv32i/Fpu.scala 229:27 174:57]
  wire [4:0] _GEN_198 = A_sign ? 5'h10 : _GEN_189; // @[src/main/scala/rv32i/Fpu.scala 229:27 174:75]
  wire [3:0] _GEN_199 = A_sign ? 4'h9 : _GEN_190; // @[src/main/scala/rv32i/Fpu.scala 229:27 174:91]
  wire [53:0] _GEN_200 = A_sign ? radicand : _GEN_191; // @[src/main/scala/rv32i/Fpu.scala 164:21 229:27]
  wire [30:0] _GEN_201 = A_sign ? rem : _GEN_192; // @[src/main/scala/rv32i/Fpu.scala 161:21 229:27]
  wire [26:0] _GEN_202 = A_sign ? quo : _GEN_193; // @[src/main/scala/rv32i/Fpu.scala 162:21 229:27]
  wire [4:0] _GEN_203 = A_sign ? count : _GEN_194; // @[src/main/scala/rv32i/Fpu.scala 160:21 229:27]
  wire  _GEN_204 = A_sign ? rSign : _GEN_195; // @[src/main/scala/rv32i/Fpu.scala 168:21 229:27]
  wire [12:0] _GEN_205 = A_sign ? $signed(rawE) : $signed(_GEN_196); // @[src/main/scala/rv32i/Fpu.scala 166:21 229:27]
  wire [31:0] _GEN_206 = A_zero ? ra : _GEN_197; // @[src/main/scala/rv32i/Fpu.scala 228:27 174:57]
  wire [4:0] _GEN_207 = A_zero ? 5'h0 : _GEN_198; // @[src/main/scala/rv32i/Fpu.scala 228:27 174:75]
  wire [3:0] _GEN_208 = A_zero ? 4'h9 : _GEN_199; // @[src/main/scala/rv32i/Fpu.scala 228:27 174:91]
  wire [53:0] _GEN_209 = A_zero ? radicand : _GEN_200; // @[src/main/scala/rv32i/Fpu.scala 164:21 228:27]
  wire [30:0] _GEN_210 = A_zero ? rem : _GEN_201; // @[src/main/scala/rv32i/Fpu.scala 161:21 228:27]
  wire [26:0] _GEN_211 = A_zero ? quo : _GEN_202; // @[src/main/scala/rv32i/Fpu.scala 162:21 228:27]
  wire [4:0] _GEN_212 = A_zero ? count : _GEN_203; // @[src/main/scala/rv32i/Fpu.scala 160:21 228:27]
  wire  _GEN_213 = A_zero ? rSign : _GEN_204; // @[src/main/scala/rv32i/Fpu.scala 168:21 228:27]
  wire [12:0] _GEN_214 = A_zero ? $signed(rawE) : $signed(_GEN_205); // @[src/main/scala/rv32i/Fpu.scala 166:21 228:27]
  wire [31:0] _GEN_215 = A_nan ? 32'h7fc00000 : _GEN_206; // @[src/main/scala/rv32i/Fpu.scala 227:19 174:57]
  wire [4:0] _GEN_216 = A_nan ? _T_51 : _GEN_207; // @[src/main/scala/rv32i/Fpu.scala 227:19 174:75]
  wire [3:0] _GEN_217 = A_nan ? 4'h9 : _GEN_208; // @[src/main/scala/rv32i/Fpu.scala 227:19 174:91]
  wire [53:0] _GEN_218 = A_nan ? radicand : _GEN_209; // @[src/main/scala/rv32i/Fpu.scala 227:19 164:21]
  wire [30:0] _GEN_219 = A_nan ? rem : _GEN_210; // @[src/main/scala/rv32i/Fpu.scala 227:19 161:21]
  wire [26:0] _GEN_220 = A_nan ? quo : _GEN_211; // @[src/main/scala/rv32i/Fpu.scala 227:19 162:21]
  wire [4:0] _GEN_221 = A_nan ? count : _GEN_212; // @[src/main/scala/rv32i/Fpu.scala 227:19 160:21]
  wire  _GEN_222 = A_nan ? rSign : _GEN_213; // @[src/main/scala/rv32i/Fpu.scala 227:19 168:21]
  wire [12:0] _GEN_223 = A_nan ? $signed(rawE) : $signed(_GEN_214); // @[src/main/scala/rv32i/Fpu.scala 227:19 166:21]
  wire  neg = _isFromInt_T & A_sign; // @[src/main/scala/rv32i/Fpu.scala 244:35]
  wire [31:0] _mag_T_1 = 32'h0 - ra; // @[src/main/scala/rv32i/Fpu.scala 245:36]
  wire [31:0] mag = neg ? _mag_T_1 : ra; // @[src/main/scala/rv32i/Fpu.scala 245:20]
  wire [31:0] _GEN_224 = mag == 32'h0 ? 32'h0 : resBits; // @[src/main/scala/rv32i/Fpu.scala 171:21 246:25 174:57]
  wire [4:0] _GEN_225 = mag == 32'h0 ? 5'h0 : resFlags; // @[src/main/scala/rv32i/Fpu.scala 172:21 246:25 174:75]
  wire [3:0] _GEN_226 = mag == 32'h0 ? 4'h9 : 4'h6; // @[src/main/scala/rv32i/Fpu.scala 246:25 174:91 248:15]
  wire [55:0] _GEN_227 = mag == 32'h0 ? raw : {{24'd0}, mag}; // @[src/main/scala/rv32i/Fpu.scala 165:21 246:25 247:13]
  wire [12:0] _GEN_228 = mag == 32'h0 ? $signed(rawE) : $signed(13'sh0); // @[src/main/scala/rv32i/Fpu.scala 166:21 246:25 247:26]
  wire  _GEN_229 = mag == 32'h0 ? rSign : neg; // @[src/main/scala/rv32i/Fpu.scala 168:21 246:25 247:41]
  wire [3:0] _GEN_230 = isToInt ? 4'h8 : _GEN_226; // @[src/main/scala/rv32i/Fpu.scala 241:25 242:13]
  wire [31:0] _GEN_231 = isToInt ? resBits : _GEN_224; // @[src/main/scala/rv32i/Fpu.scala 171:21 241:25]
  wire [4:0] _GEN_232 = isToInt ? resFlags : _GEN_225; // @[src/main/scala/rv32i/Fpu.scala 172:21 241:25]
  wire [55:0] _GEN_233 = isToInt ? raw : _GEN_227; // @[src/main/scala/rv32i/Fpu.scala 165:21 241:25]
  wire [12:0] _GEN_234 = isToInt ? $signed(rawE) : $signed(_GEN_228); // @[src/main/scala/rv32i/Fpu.scala 166:21 241:25]
  wire  _GEN_235 = isToInt ? rSign : _GEN_229; // @[src/main/scala/rv32i/Fpu.scala 168:21 241:25]
  wire [31:0] _GEN_236 = isSqrt ? _GEN_215 : _GEN_231; // @[src/main/scala/rv32i/Fpu.scala 226:24]
  wire [4:0] _GEN_237 = isSqrt ? _GEN_216 : _GEN_232; // @[src/main/scala/rv32i/Fpu.scala 226:24]
  wire [3:0] _GEN_238 = isSqrt ? _GEN_217 : _GEN_230; // @[src/main/scala/rv32i/Fpu.scala 226:24]
  wire [53:0] _GEN_239 = isSqrt ? _GEN_218 : radicand; // @[src/main/scala/rv32i/Fpu.scala 164:21 226:24]
  wire [30:0] _GEN_240 = isSqrt ? _GEN_219 : rem; // @[src/main/scala/rv32i/Fpu.scala 161:21 226:24]
  wire [26:0] _GEN_241 = isSqrt ? _GEN_220 : quo; // @[src/main/scala/rv32i/Fpu.scala 162:21 226:24]
  wire [4:0] _GEN_242 = isSqrt ? _GEN_221 : count; // @[src/main/scala/rv32i/Fpu.scala 160:21 226:24]
  wire  _GEN_243 = isSqrt ? _GEN_222 : _GEN_235; // @[src/main/scala/rv32i/Fpu.scala 226:24]
  wire [12:0] _GEN_244 = isSqrt ? $signed(_GEN_223) : $signed(_GEN_234); // @[src/main/scala/rv32i/Fpu.scala 226:24]
  wire [55:0] _GEN_245 = isSqrt ? raw : _GEN_233; // @[src/main/scala/rv32i/Fpu.scala 165:21 226:24]
  wire [31:0] _GEN_246 = isDiv ? _GEN_179 : _GEN_236; // @[src/main/scala/rv32i/Fpu.scala 213:23]
  wire [4:0] _GEN_247 = isDiv ? _GEN_180 : _GEN_237; // @[src/main/scala/rv32i/Fpu.scala 213:23]
  wire [3:0] _GEN_248 = isDiv ? _GEN_181 : _GEN_238; // @[src/main/scala/rv32i/Fpu.scala 213:23]
  wire [30:0] _GEN_249 = isDiv ? _GEN_182 : _GEN_240; // @[src/main/scala/rv32i/Fpu.scala 213:23]
  wire [26:0] _GEN_251 = isDiv ? _GEN_184 : _GEN_241; // @[src/main/scala/rv32i/Fpu.scala 213:23]
  wire [4:0] _GEN_252 = isDiv ? _GEN_185 : _GEN_242; // @[src/main/scala/rv32i/Fpu.scala 213:23]
  wire  _GEN_253 = isDiv ? _GEN_186 : _GEN_243; // @[src/main/scala/rv32i/Fpu.scala 213:23]
  wire [12:0] _GEN_254 = isDiv ? $signed(_GEN_187) : $signed(_GEN_244); // @[src/main/scala/rv32i/Fpu.scala 213:23]
  wire [53:0] _GEN_255 = isDiv ? radicand : _GEN_239; // @[src/main/scala/rv32i/Fpu.scala 164:21 213:23]
  wire [55:0] _GEN_256 = isDiv ? raw : _GEN_245; // @[src/main/scala/rv32i/Fpu.scala 165:21 213:23]
  wire [31:0] _GEN_257 = isMul | isFma ? _GEN_120 : _GEN_246; // @[src/main/scala/rv32i/Fpu.scala 192:32]
  wire [4:0] _GEN_258 = isMul | isFma ? _GEN_121 : _GEN_247; // @[src/main/scala/rv32i/Fpu.scala 192:32]
  wire [3:0] _GEN_259 = isMul | isFma ? _GEN_122 : _GEN_248; // @[src/main/scala/rv32i/Fpu.scala 192:32]
  wire [47:0] _GEN_261 = isMul | isFma ? _GEN_124 : mcand; // @[src/main/scala/rv32i/Fpu.scala 158:21 192:32]
  wire [4:0] _GEN_263 = isMul | isFma ? _GEN_126 : _GEN_252; // @[src/main/scala/rv32i/Fpu.scala 192:32]
  wire [30:0] _GEN_271 = isMul | isFma ? rem : _GEN_249; // @[src/main/scala/rv32i/Fpu.scala 161:21 192:32]
  wire [26:0] _GEN_273 = isMul | isFma ? quo : _GEN_251; // @[src/main/scala/rv32i/Fpu.scala 162:21 192:32]
  wire  _GEN_274 = isMul | isFma ? rSign : _GEN_253; // @[src/main/scala/rv32i/Fpu.scala 168:21 192:32]
  wire [12:0] _GEN_275 = isMul | isFma ? $signed(rawE) : $signed(_GEN_254); // @[src/main/scala/rv32i/Fpu.scala 166:21 192:32]
  wire [53:0] _GEN_276 = isMul | isFma ? radicand : _GEN_255; // @[src/main/scala/rv32i/Fpu.scala 164:21 192:32]
  wire [55:0] _GEN_277 = isMul | isFma ? raw : _GEN_256; // @[src/main/scala/rv32i/Fpu.scala 165:21 192:32]
  wire [31:0] _GEN_278 = isAddSub ? _GEN_50 : _GEN_257; // @[src/main/scala/rv32i/Fpu.scala 180:20]
  wire [4:0] _GEN_279 = isAddSub ? _GEN_51 : _GEN_258; // @[src/main/scala/rv32i/Fpu.scala 180:20]
  wire [3:0] _GEN_280 = isAddSub ? _GEN_52 : _GEN_259; // @[src/main/scala/rv32i/Fpu.scala 180:20]
  wire [47:0] _GEN_290 = isAddSub ? mcand : _GEN_261; // @[src/main/scala/rv32i/Fpu.scala 180:20 158:21]
  wire [4:0] _GEN_292 = isAddSub ? count : _GEN_263; // @[src/main/scala/rv32i/Fpu.scala 180:20 160:21]
  wire [30:0] _GEN_293 = isAddSub ? rem : _GEN_271; // @[src/main/scala/rv32i/Fpu.scala 180:20 161:21]
  wire  _GEN_296 = isAddSub ? rSign : _GEN_274; // @[src/main/scala/rv32i/Fpu.scala 180:20 168:21]
  wire [12:0] _GEN_297 = isAddSub ? $signed(rawE) : $signed(_GEN_275); // @[src/main/scala/rv32i/Fpu.scala 180:20 166:21]
  wire [53:0] _GEN_298 = isAddSub ? radicand : _GEN_276; // @[src/main/scala/rv32i/Fpu.scala 180:20 164:21]
  wire [55:0] _GEN_299 = isAddSub ? raw : _GEN_277; // @[src/main/scala/rv32i/Fpu.scala 180:20 165:21]
  wire  _GEN_300 = state == 4'h1 ? 1'h0 : sticky; // @[src/main/scala/rv32i/Fpu.scala 178:27 179:12 167:21]
  wire [31:0] _GEN_301 = state == 4'h1 ? _GEN_278 : resBits; // @[src/main/scala/rv32i/Fpu.scala 171:21 178:27]
  wire [4:0] _GEN_302 = state == 4'h1 ? _GEN_279 : resFlags; // @[src/main/scala/rv32i/Fpu.scala 172:21 178:27]
  wire [3:0] _GEN_303 = state == 4'h1 ? _GEN_280 : _GEN_5; // @[src/main/scala/rv32i/Fpu.scala 178:27]
  wire [47:0] _GEN_313 = state == 4'h1 ? _GEN_290 : mcand; // @[src/main/scala/rv32i/Fpu.scala 158:21 178:27]
  wire [30:0] _GEN_316 = state == 4'h1 ? _GEN_293 : rem; // @[src/main/scala/rv32i/Fpu.scala 161:21 178:27]
  wire  _GEN_319 = state == 4'h1 ? _GEN_296 : rSign; // @[src/main/scala/rv32i/Fpu.scala 168:21 178:27]
  wire [12:0] _GEN_320 = state == 4'h1 ? $signed(_GEN_297) : $signed(rawE); // @[src/main/scala/rv32i/Fpu.scala 166:21 178:27]
  wire [53:0] _GEN_321 = state == 4'h1 ? _GEN_298 : radicand; // @[src/main/scala/rv32i/Fpu.scala 164:21 178:27]
  wire [55:0] _GEN_322 = state == 4'h1 ? _GEN_299 : raw; // @[src/main/scala/rv32i/Fpu.scala 165:21 178:27]
  wire [47:0] _acc_T_1 = mplier[0] ? mcand : 48'h0; // @[src/main/scala/rv32i/Fpu.scala 255:24]
  wire [47:0] _acc_T_3 = acc + _acc_T_1; // @[src/main/scala/rv32i/Fpu.scala 255:19]
  wire [48:0] _mcand_T = {mcand, 1'h0}; // @[src/main/scala/rv32i/Fpu.scala 256:21]
  wire [4:0] _count_T_1 = count + 5'h1; // @[src/main/scala/rv32i/Fpu.scala 258:21]
  wire [3:0] _GEN_323 = count == 5'h17 ? 4'h3 : _GEN_303; // @[src/main/scala/rv32i/Fpu.scala 259:{26,34}]
  wire [48:0] _GEN_325 = state == 4'h2 ? _mcand_T : {{1'd0}, _GEN_313}; // @[src/main/scala/rv32i/Fpu.scala 254:24 256:12]
  wire [3:0] _GEN_328 = state == 4'h2 ? _GEN_323 : _GEN_303; // @[src/main/scala/rv32i/Fpu.scala 254:24]
  wire  prodTop = acc[47]; // @[src/main/scala/rv32i/Fpu.scala 264:22]
  wire [48:0] _sigX_T = {acc, 1'h0}; // @[src/main/scala/rv32i/Fpu.scala 265:58]
  wire [48:0] _sigX_T_1 = prodTop ? {{1'd0}, acc} : _sigX_T; // @[src/main/scala/rv32i/Fpu.scala 265:39]
  wire [47:0] sigX = isAddSub ? xSig : _sigX_T_1[47:0]; // @[src/main/scala/rv32i/Fpu.scala 265:19]
  wire [12:0] _expX_T_2 = $signed(xExp) + 13'sh1; // @[src/main/scala/rv32i/Fpu.scala 266:54]
  wire [12:0] _expX_T_3 = prodTop ? $signed(_expX_T_2) : $signed(xExp); // @[src/main/scala/rv32i/Fpu.scala 266:39]
  wire [12:0] expX = isAddSub ? $signed(xExp) : $signed(_expX_T_3); // @[src/main/scala/rv32i/Fpu.scala 266:19]
  wire  xBig = ~xZero & (yZero | $signed(expX) > $signed(yExp) | $signed(expX) == $signed(yExp) & sigX >= ySig); // @[src/main/scala/rv32i/Fpu.scala 267:23]
  wire [47:0] bigSig = xBig ? sigX : ySig; // @[src/main/scala/rv32i/Fpu.scala 268:23]
  wire [12:0] bigExp = xBig ? $signed(expX) : $signed(yExp); // @[src/main/scala/rv32i/Fpu.scala 269:23]
  wire  bigSign = xBig ? xSign : ySign; // @[src/main/scala/rv32i/Fpu.scala 270:23]
  wire [47:0] smallSig = xBig ? ySig : sigX; // @[src/main/scala/rv32i/Fpu.scala 271:23]
  wire [12:0] smallExp = xBig ? $signed(yExp) : $signed(expX); // @[src/main/scala/rv32i/Fpu.scala 272:23]
  wire  smallSign = xBig ? ySign : xSign; // @[src/main/scala/rv32i/Fpu.scala 273:24]
  wire  smallAbsent = xBig ? yZero : xZero; // @[src/main/scala/rv32i/Fpu.scala 274:26]
  wire [12:0] d = $signed(bigExp) - $signed(smallExp); // @[src/main/scala/rv32i/Fpu.scala 275:35]
  wire [5:0] dC = d > 13'h3f ? 6'h3f : d[5:0]; // @[src/main/scala/rv32i/Fpu.scala 276:18]
  wire [50:0] smallExt = {smallSig,3'h0}; // @[src/main/scala/rv32i/Fpu.scala 277:23]
  wire [126:0] _lost_T = 127'h1 << dC; // @[src/main/scala/rv32i/Fpu.scala 278:44]
  wire [126:0] _lost_T_2 = _lost_T - 127'h1; // @[src/main/scala/rv32i/Fpu.scala 278:51]
  wire [50:0] _lost_T_4 = smallExt & _lost_T_2[50:0]; // @[src/main/scala/rv32i/Fpu.scala 278:30]
  wire  lost = |_lost_T_4; // @[src/main/scala/rv32i/Fpu.scala 278:66]
  wire [50:0] _smallAl_T = smallExt >> dC; // @[src/main/scala/rv32i/Fpu.scala 279:52]
  wire [50:0] _GEN_408 = {{50'd0}, lost}; // @[src/main/scala/rv32i/Fpu.scala 279:59]
  wire [50:0] _smallAl_T_1 = _smallAl_T | _GEN_408; // @[src/main/scala/rv32i/Fpu.scala 279:59]
  wire [50:0] smallAl = smallAbsent ? 51'h0 : _smallAl_T_1; // @[src/main/scala/rv32i/Fpu.scala 279:23]
  wire [50:0] bigExt = {bigSig,3'h0}; // @[src/main/scala/rv32i/Fpu.scala 280:23]
  wire [50:0] _sum_T_2 = bigExt - smallAl; // @[src/main/scala/rv32i/Fpu.scala 281:49]
  wire [51:0] _sum_T_3 = bigExt + smallAl; // @[src/main/scala/rv32i/Fpu.scala 281:67]
  wire [51:0] sum = bigSign != smallSign ? {{1'd0}, _sum_T_2} : _sum_T_3; // @[src/main/scala/rv32i/Fpu.scala 281:18]
  wire [31:0] _T_59 = {_T_15,31'h0}; // @[src/main/scala/rv32i/Fpu.scala 144:32]
  wire [12:0] _rawE_T_12 = $signed(bigExp) - 13'sh32; // @[src/main/scala/rv32i/Fpu.scala 284:36]
  wire [3:0] _GEN_331 = sum == 52'h0 ? 4'h9 : 4'h6; // @[src/main/scala/rv32i/Fpu.scala 282:23 174:91 285:15]
  wire [55:0] _GEN_332 = sum == 52'h0 ? _GEN_322 : {{4'd0}, sum}; // @[src/main/scala/rv32i/Fpu.scala 282:23 284:13]
  wire [3:0] _GEN_337 = state == 4'h3 ? _GEN_331 : _GEN_328; // @[src/main/scala/rv32i/Fpu.scala 263:24]
  wire [55:0] _GEN_338 = state == 4'h3 ? _GEN_332 : _GEN_322; // @[src/main/scala/rv32i/Fpu.scala 263:24]
  wire [30:0] _GEN_409 = {{7'd0}, divisor}; // @[src/main/scala/rv32i/Fpu.scala 291:18]
  wire  ge = rem >= _GEN_409; // @[src/main/scala/rv32i/Fpu.scala 291:18]
  wire [30:0] _r1_T_1 = rem - _GEN_409; // @[src/main/scala/rv32i/Fpu.scala 292:26]
  wire [30:0] r1 = ge ? _r1_T_1 : rem; // @[src/main/scala/rv32i/Fpu.scala 292:17]
  wire [26:0] q = {quo[25:0],ge}; // @[src/main/scala/rv32i/Fpu.scala 293:17]
  wire [31:0] _rem_T = {r1, 1'h0}; // @[src/main/scala/rv32i/Fpu.scala 295:17]
  wire  _T_61 = count == 5'h1a; // @[src/main/scala/rv32i/Fpu.scala 297:16]
  wire [55:0] _GEN_341 = count == 5'h1a ? {{29'd0}, q} : _GEN_338; // @[src/main/scala/rv32i/Fpu.scala 297:{26,32}]
  wire  _GEN_342 = count == 5'h1a ? r1 != 31'h0 : _GEN_300; // @[src/main/scala/rv32i/Fpu.scala 297:{26,45}]
  wire [3:0] _GEN_343 = count == 5'h1a ? 4'h6 : _GEN_337; // @[src/main/scala/rv32i/Fpu.scala 297:{26,66}]
  wire [31:0] _GEN_345 = state == 4'h4 ? _rem_T : {{1'd0}, _GEN_316}; // @[src/main/scala/rv32i/Fpu.scala 290:24 295:11]
  wire [55:0] _GEN_347 = state == 4'h4 ? _GEN_341 : _GEN_338; // @[src/main/scala/rv32i/Fpu.scala 290:24]
  wire  _GEN_348 = state == 4'h4 ? _GEN_342 : _GEN_300; // @[src/main/scala/rv32i/Fpu.scala 290:24]
  wire [3:0] _GEN_349 = state == 4'h4 ? _GEN_343 : _GEN_337; // @[src/main/scala/rv32i/Fpu.scala 290:24]
  wire [30:0] remN = {rem[28:0],radicand[53:52]}; // @[src/main/scala/rv32i/Fpu.scala 302:19]
  wire [28:0] t = {quo,2'h1}; // @[src/main/scala/rv32i/Fpu.scala 303:19]
  wire [30:0] _GEN_411 = {{2'd0}, t}; // @[src/main/scala/rv32i/Fpu.scala 304:21]
  wire  ge_1 = remN >= _GEN_411; // @[src/main/scala/rv32i/Fpu.scala 304:21]
  wire [30:0] _remNext_T_1 = remN - _GEN_411; // @[src/main/scala/rv32i/Fpu.scala 305:32]
  wire [30:0] remNext = ge_1 ? _remNext_T_1 : remN; // @[src/main/scala/rv32i/Fpu.scala 305:22]
  wire [26:0] q_1 = {quo[25:0],ge_1}; // @[src/main/scala/rv32i/Fpu.scala 306:19]
  wire [55:0] _radicand_T_1 = {radicand, 2'h0}; // @[src/main/scala/rv32i/Fpu.scala 309:26]
  wire [3:0] _GEN_352 = _T_61 ? 4'h6 : _GEN_349; // @[src/main/scala/rv32i/Fpu.scala 311:{26,71}]
  wire [31:0] _GEN_353 = state == 4'h5 ? {{1'd0}, remNext} : _GEN_345; // @[src/main/scala/rv32i/Fpu.scala 301:25 307:14]
  wire [55:0] _GEN_355 = state == 4'h5 ? _radicand_T_1 : {{2'd0}, _GEN_321}; // @[src/main/scala/rv32i/Fpu.scala 301:25 309:14]
  wire [3:0] _GEN_359 = state == 4'h5 ? _GEN_352 : _GEN_349; // @[src/main/scala/rv32i/Fpu.scala 301:25]
  wire [31:0] _GEN_413 = {{16'd0}, raw[31:16]}; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [31:0] _lz_T_4 = _GEN_413 & 32'hffff; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [31:0] _lz_T_6 = {raw[15:0], 16'h0}; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [31:0] _lz_T_8 = _lz_T_6 & 32'hffff0000; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [31:0] _lz_T_9 = _lz_T_4 | _lz_T_8; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [31:0] _GEN_414 = {{8'd0}, _lz_T_9[31:8]}; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [31:0] _lz_T_14 = _GEN_414 & 32'hff00ff; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [31:0] _lz_T_16 = {_lz_T_9[23:0], 8'h0}; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [31:0] _lz_T_18 = _lz_T_16 & 32'hff00ff00; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [31:0] _lz_T_19 = _lz_T_14 | _lz_T_18; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [31:0] _GEN_415 = {{4'd0}, _lz_T_19[31:4]}; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [31:0] _lz_T_24 = _GEN_415 & 32'hf0f0f0f; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [31:0] _lz_T_26 = {_lz_T_19[27:0], 4'h0}; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [31:0] _lz_T_28 = _lz_T_26 & 32'hf0f0f0f0; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [31:0] _lz_T_29 = _lz_T_24 | _lz_T_28; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [31:0] _GEN_416 = {{2'd0}, _lz_T_29[31:2]}; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [31:0] _lz_T_34 = _GEN_416 & 32'h33333333; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [31:0] _lz_T_36 = {_lz_T_29[29:0], 2'h0}; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [31:0] _lz_T_38 = _lz_T_36 & 32'hcccccccc; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [31:0] _lz_T_39 = _lz_T_34 | _lz_T_38; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [31:0] _GEN_417 = {{1'd0}, _lz_T_39[31:1]}; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [31:0] _lz_T_44 = _GEN_417 & 32'h55555555; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [31:0] _lz_T_46 = {_lz_T_39[30:0], 1'h0}; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [31:0] _lz_T_48 = _lz_T_46 & 32'haaaaaaaa; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [31:0] _lz_T_49 = _lz_T_44 | _lz_T_48; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [15:0] _GEN_418 = {{8'd0}, raw[47:40]}; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [15:0] _lz_T_55 = _GEN_418 & 16'hff; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [15:0] _lz_T_57 = {raw[39:32], 8'h0}; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [15:0] _lz_T_59 = _lz_T_57 & 16'hff00; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [15:0] _lz_T_60 = _lz_T_55 | _lz_T_59; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [15:0] _GEN_419 = {{4'd0}, _lz_T_60[15:4]}; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [15:0] _lz_T_65 = _GEN_419 & 16'hf0f; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [15:0] _lz_T_67 = {_lz_T_60[11:0], 4'h0}; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [15:0] _lz_T_69 = _lz_T_67 & 16'hf0f0; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [15:0] _lz_T_70 = _lz_T_65 | _lz_T_69; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [15:0] _GEN_420 = {{2'd0}, _lz_T_70[15:2]}; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [15:0] _lz_T_75 = _GEN_420 & 16'h3333; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [15:0] _lz_T_77 = {_lz_T_70[13:0], 2'h0}; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [15:0] _lz_T_79 = _lz_T_77 & 16'hcccc; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [15:0] _lz_T_80 = _lz_T_75 | _lz_T_79; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [15:0] _GEN_421 = {{1'd0}, _lz_T_80[15:1]}; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [15:0] _lz_T_85 = _GEN_421 & 16'h5555; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [15:0] _lz_T_87 = {_lz_T_80[14:0], 1'h0}; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [15:0] _lz_T_89 = _lz_T_87 & 16'haaaa; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [15:0] _lz_T_90 = _lz_T_85 | _lz_T_89; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [7:0] _GEN_422 = {{4'd0}, raw[55:52]}; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [7:0] _lz_T_95 = _GEN_422 & 8'hf; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [7:0] _lz_T_97 = {raw[51:48], 4'h0}; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [7:0] _lz_T_99 = _lz_T_97 & 8'hf0; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [7:0] _lz_T_100 = _lz_T_95 | _lz_T_99; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [7:0] _GEN_423 = {{2'd0}, _lz_T_100[7:2]}; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [7:0] _lz_T_105 = _GEN_423 & 8'h33; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [7:0] _lz_T_107 = {_lz_T_100[5:0], 2'h0}; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [7:0] _lz_T_109 = _lz_T_107 & 8'hcc; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [7:0] _lz_T_110 = _lz_T_105 | _lz_T_109; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [7:0] _GEN_424 = {{1'd0}, _lz_T_110[7:1]}; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [7:0] _lz_T_115 = _GEN_424 & 8'h55; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [7:0] _lz_T_117 = {_lz_T_110[6:0], 1'h0}; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [7:0] _lz_T_119 = _lz_T_117 & 8'haa; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [7:0] _lz_T_120 = _lz_T_115 | _lz_T_119; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [55:0] _lz_T_122 = {_lz_T_49,_lz_T_90,_lz_T_120}; // @[src/main/scala/rv32i/Fpu.scala 316:37]
  wire [5:0] _lz_T_179 = _lz_T_122[54] ? 6'h36 : 6'h37; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_180 = _lz_T_122[53] ? 6'h35 : _lz_T_179; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_181 = _lz_T_122[52] ? 6'h34 : _lz_T_180; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_182 = _lz_T_122[51] ? 6'h33 : _lz_T_181; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_183 = _lz_T_122[50] ? 6'h32 : _lz_T_182; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_184 = _lz_T_122[49] ? 6'h31 : _lz_T_183; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_185 = _lz_T_122[48] ? 6'h30 : _lz_T_184; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_186 = _lz_T_122[47] ? 6'h2f : _lz_T_185; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_187 = _lz_T_122[46] ? 6'h2e : _lz_T_186; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_188 = _lz_T_122[45] ? 6'h2d : _lz_T_187; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_189 = _lz_T_122[44] ? 6'h2c : _lz_T_188; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_190 = _lz_T_122[43] ? 6'h2b : _lz_T_189; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_191 = _lz_T_122[42] ? 6'h2a : _lz_T_190; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_192 = _lz_T_122[41] ? 6'h29 : _lz_T_191; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_193 = _lz_T_122[40] ? 6'h28 : _lz_T_192; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_194 = _lz_T_122[39] ? 6'h27 : _lz_T_193; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_195 = _lz_T_122[38] ? 6'h26 : _lz_T_194; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_196 = _lz_T_122[37] ? 6'h25 : _lz_T_195; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_197 = _lz_T_122[36] ? 6'h24 : _lz_T_196; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_198 = _lz_T_122[35] ? 6'h23 : _lz_T_197; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_199 = _lz_T_122[34] ? 6'h22 : _lz_T_198; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_200 = _lz_T_122[33] ? 6'h21 : _lz_T_199; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_201 = _lz_T_122[32] ? 6'h20 : _lz_T_200; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_202 = _lz_T_122[31] ? 6'h1f : _lz_T_201; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_203 = _lz_T_122[30] ? 6'h1e : _lz_T_202; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_204 = _lz_T_122[29] ? 6'h1d : _lz_T_203; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_205 = _lz_T_122[28] ? 6'h1c : _lz_T_204; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_206 = _lz_T_122[27] ? 6'h1b : _lz_T_205; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_207 = _lz_T_122[26] ? 6'h1a : _lz_T_206; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_208 = _lz_T_122[25] ? 6'h19 : _lz_T_207; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_209 = _lz_T_122[24] ? 6'h18 : _lz_T_208; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_210 = _lz_T_122[23] ? 6'h17 : _lz_T_209; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_211 = _lz_T_122[22] ? 6'h16 : _lz_T_210; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_212 = _lz_T_122[21] ? 6'h15 : _lz_T_211; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_213 = _lz_T_122[20] ? 6'h14 : _lz_T_212; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_214 = _lz_T_122[19] ? 6'h13 : _lz_T_213; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_215 = _lz_T_122[18] ? 6'h12 : _lz_T_214; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_216 = _lz_T_122[17] ? 6'h11 : _lz_T_215; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_217 = _lz_T_122[16] ? 6'h10 : _lz_T_216; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_218 = _lz_T_122[15] ? 6'hf : _lz_T_217; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_219 = _lz_T_122[14] ? 6'he : _lz_T_218; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_220 = _lz_T_122[13] ? 6'hd : _lz_T_219; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_221 = _lz_T_122[12] ? 6'hc : _lz_T_220; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_222 = _lz_T_122[11] ? 6'hb : _lz_T_221; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_223 = _lz_T_122[10] ? 6'ha : _lz_T_222; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_224 = _lz_T_122[9] ? 6'h9 : _lz_T_223; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_225 = _lz_T_122[8] ? 6'h8 : _lz_T_224; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_226 = _lz_T_122[7] ? 6'h7 : _lz_T_225; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_227 = _lz_T_122[6] ? 6'h6 : _lz_T_226; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_228 = _lz_T_122[5] ? 6'h5 : _lz_T_227; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_229 = _lz_T_122[4] ? 6'h4 : _lz_T_228; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_230 = _lz_T_122[3] ? 6'h3 : _lz_T_229; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_231 = _lz_T_122[2] ? 6'h2 : _lz_T_230; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] _lz_T_232 = _lz_T_122[1] ? 6'h1 : _lz_T_231; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [5:0] lz = _lz_T_122[0] ? 6'h0 : _lz_T_232; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [118:0] _GEN_3 = {{63'd0}, raw}; // @[src/main/scala/rv32i/Fpu.scala 317:19]
  wire [118:0] _nSig_T = _GEN_3 << lz; // @[src/main/scala/rv32i/Fpu.scala 317:19]
  wire [12:0] _nExp_T_2 = $signed(rawE) + 13'sh37; // @[src/main/scala/rv32i/Fpu.scala 318:19]
  wire [6:0] _nExp_T_3 = {1'b0,$signed(lz)}; // @[src/main/scala/rv32i/Fpu.scala 318:32]
  wire [12:0] _nExp_T_4 = {{6{_nExp_T_3[6]}},_nExp_T_3}; // @[src/main/scala/rv32i/Fpu.scala 318:40]
  wire [12:0] _nExp_T_7 = $signed(_nExp_T_2) - $signed(_nExp_T_4); // @[src/main/scala/rv32i/Fpu.scala 318:27]
  wire [3:0] _GEN_362 = state == 4'h6 ? 4'h7 : _GEN_359; // @[src/main/scala/rv32i/Fpu.scala 315:25 319:11]
  wire [23:0] keep = nSig[55:32]; // @[src/main/scala/rv32i/Fpu.scala 325:20]
  wire  rb_1 = nSig[31]; // @[src/main/scala/rv32i/Fpu.scala 326:20]
  wire  st = |nSig[30:0] | sticky; // @[src/main/scala/rv32i/Fpu.scala 327:32]
  wire  _k25_T_2 = rb_1 & (st | keep[0]); // @[src/main/scala/rv32i/Fpu.scala 147:20]
  wire  _k25_T_3 = rb_1 | st; // @[src/main/scala/rv32i/Fpu.scala 149:29]
  wire  _k25_T_4 = rSign & (rb_1 | st); // @[src/main/scala/rv32i/Fpu.scala 149:23]
  wire  _k25_T_5 = ~rSign; // @[src/main/scala/rv32i/Fpu.scala 150:18]
  wire  _k25_T_7 = ~rSign & _k25_T_3; // @[src/main/scala/rv32i/Fpu.scala 150:24]
  wire  _k25_T_10 = 3'h1 == rm; // @[src/main/scala/rv32i/Fpu.scala 146:88]
  wire  _k25_T_11 = 3'h1 == rm ? 1'h0 : 3'h0 == rm & _k25_T_2; // @[src/main/scala/rv32i/Fpu.scala 146:88]
  wire  _k25_T_12 = 3'h2 == rm; // @[src/main/scala/rv32i/Fpu.scala 146:88]
  wire  _k25_T_13 = 3'h2 == rm ? _k25_T_4 : _k25_T_11; // @[src/main/scala/rv32i/Fpu.scala 146:88]
  wire  _k25_T_14 = 3'h3 == rm; // @[src/main/scala/rv32i/Fpu.scala 146:88]
  wire  _k25_T_15 = 3'h3 == rm ? _k25_T_7 : _k25_T_13; // @[src/main/scala/rv32i/Fpu.scala 146:88]
  wire  _k25_T_17 = 3'h4 == rm ? rb_1 : _k25_T_15; // @[src/main/scala/rv32i/Fpu.scala 146:88]
  wire [23:0] _GEN_425 = {{23'd0}, _k25_T_17}; // @[src/main/scala/rv32i/Fpu.scala 328:21]
  wire [24:0] k25 = keep + _GEN_425; // @[src/main/scala/rv32i/Fpu.scala 328:21]
  wire  carry = k25[24]; // @[src/main/scala/rv32i/Fpu.scala 329:20]
  wire [12:0] _eU_T = carry ? $signed(13'sh1) : $signed(13'sh0); // @[src/main/scala/rv32i/Fpu.scala 330:26]
  wire [12:0] eU = $signed(nExp) + $signed(_eU_T); // @[src/main/scala/rv32i/Fpu.scala 330:21]
  wire  tiny = $signed(eU) < -13'sh7e; // @[src/main/scala/rv32i/Fpu.scala 331:19]
  wire  _toInf_T_2 = _k25_T_10 ? 1'h0 : 1'h1; // @[src/main/scala/rv32i/Fpu.scala 333:38]
  wire  _toInf_T_4 = _k25_T_12 ? rSign : _toInf_T_2; // @[src/main/scala/rv32i/Fpu.scala 333:38]
  wire  toInf = _k25_T_14 ? _k25_T_5 : _toInf_T_4; // @[src/main/scala/rv32i/Fpu.scala 333:38]
  wire [30:0] _ovBits_T = toInf ? 31'h7f800000 : 31'h7f7fffff; // @[src/main/scala/rv32i/Fpu.scala 334:32]
  wire [31:0] ovBits = {rSign,_ovBits_T}; // @[src/main/scala/rv32i/Fpu.scala 334:21]
  wire [12:0] biased = $signed(eU) + 13'sh7f; // @[src/main/scala/rv32i/Fpu.scala 336:23]
  wire [12:0] _T_68 = $signed(eU) + 13'sh7f; // @[src/main/scala/rv32i/Fpu.scala 340:36]
  wire [22:0] _T_71 = carry ? 23'h0 : k25[22:0]; // @[src/main/scala/rv32i/Fpu.scala 340:53]
  wire [31:0] _T_72 = {rSign,_T_68[7:0],_T_71}; // @[src/main/scala/rv32i/Fpu.scala 340:21]
  wire [4:0] _T_73 = _k25_T_3 ? 5'h1 : 5'h0; // @[src/main/scala/rv32i/Fpu.scala 340:89]
  wire [12:0] sh = -13'sh7e - $signed(nExp); // @[src/main/scala/rv32i/Fpu.scala 344:34]
  wire [4:0] shC = sh > 13'h1f ? 5'h1f : sh[4:0]; // @[src/main/scala/rv32i/Fpu.scala 345:20]
  wire [87:0] _lostS_T = 88'h1 << shC; // @[src/main/scala/rv32i/Fpu.scala 346:39]
  wire [87:0] _lostS_T_2 = _lostS_T - 88'h1; // @[src/main/scala/rv32i/Fpu.scala 346:47]
  wire [55:0] _lostS_T_4 = nSig & _lostS_T_2[55:0]; // @[src/main/scala/rv32i/Fpu.scala 346:25]
  wire  lostS = |_lostS_T_4; // @[src/main/scala/rv32i/Fpu.scala 346:62]
  wire [55:0] shifted = nSig >> shC; // @[src/main/scala/rv32i/Fpu.scala 347:26]
  wire [23:0] sKeep = shifted[55:32]; // @[src/main/scala/rv32i/Fpu.scala 348:26]
  wire  sRb = shifted[31]; // @[src/main/scala/rv32i/Fpu.scala 349:26]
  wire  sSt = |shifted[30:0] | lostS | sticky; // @[src/main/scala/rv32i/Fpu.scala 350:47]
  wire  _q_T_4 = sRb & (sSt | sKeep[0]); // @[src/main/scala/rv32i/Fpu.scala 147:20]
  wire  _q_T_5 = sRb | sSt; // @[src/main/scala/rv32i/Fpu.scala 149:29]
  wire  _q_T_6 = rSign & (sRb | sSt); // @[src/main/scala/rv32i/Fpu.scala 149:23]
  wire  _q_T_9 = ~rSign & _q_T_5; // @[src/main/scala/rv32i/Fpu.scala 150:24]
  wire  _q_T_13 = 3'h1 == rm ? 1'h0 : 3'h0 == rm & _q_T_4; // @[src/main/scala/rv32i/Fpu.scala 146:88]
  wire  _q_T_15 = 3'h2 == rm ? _q_T_6 : _q_T_13; // @[src/main/scala/rv32i/Fpu.scala 146:88]
  wire  _q_T_17 = 3'h3 == rm ? _q_T_9 : _q_T_15; // @[src/main/scala/rv32i/Fpu.scala 146:88]
  wire  _q_T_19 = 3'h4 == rm ? sRb : _q_T_17; // @[src/main/scala/rv32i/Fpu.scala 146:88]
  wire [23:0] _GEN_426 = {{23'd0}, _q_T_19}; // @[src/main/scala/rv32i/Fpu.scala 351:25]
  wire [24:0] q_2 = sKeep + _GEN_426; // @[src/main/scala/rv32i/Fpu.scala 351:25]
  wire [30:0] _T_74 = {{6'd0}, q_2}; // @[src/main/scala/rv32i/Fpu.scala 353:30]
  wire [31:0] _T_76 = {rSign,_T_74}; // @[src/main/scala/rv32i/Fpu.scala 353:17]
  wire [4:0] _T_77 = _q_T_5 ? 5'h1 : 5'h0; // @[src/main/scala/rv32i/Fpu.scala 354:12]
  wire [4:0] _T_79 = tiny & _q_T_5 ? 5'h2 : 5'h0; // @[src/main/scala/rv32i/Fpu.scala 354:49]
  wire [4:0] _T_80 = _T_77 | _T_79; // @[src/main/scala/rv32i/Fpu.scala 354:44]
  wire [3:0] _GEN_371 = state == 4'h7 ? 4'h9 : _GEN_362; // @[src/main/scala/rv32i/Fpu.scala 323:26]
  wire [31:0] _T_82 = _isToInt_T ? 32'h7fffffff : 32'hffffffff; // @[src/main/scala/rv32i/Fpu.scala 363:29]
  wire [31:0] _T_83 = _isToInt_T ? 32'h80000000 : 32'h0; // @[src/main/scala/rv32i/Fpu.scala 364:43]
  wire  huge = $signed(A_exp) >= 13'sh21; // @[src/main/scala/rv32i/Fpu.scala 368:22]
  wire  left = $signed(A_exp) >= 13'sh17; // @[src/main/scala/rv32i/Fpu.scala 369:22]
  wire [12:0] _magL_T_3 = $signed(A_exp) - 13'sh17; // @[src/main/scala/rv32i/Fpu.scala 370:42]
  wire [38:0] _GEN_4 = {{15'd0}, A_sig}; // @[src/main/scala/rv32i/Fpu.scala 370:27]
  wire [38:0] _magL_T_5 = _GEN_4 << _magL_T_3[3:0]; // @[src/main/scala/rv32i/Fpu.scala 370:27]
  wire [33:0] magL = _magL_T_5[33:0]; // @[src/main/scala/rv32i/Fpu.scala 370:55]
  wire [12:0] rsh = 13'sh17 - $signed(A_exp); // @[src/main/scala/rv32i/Fpu.scala 371:32]
  wire [4:0] rshC = rsh > 13'h19 ? 5'h19 : rsh[4:0]; // @[src/main/scala/rv32i/Fpu.scala 372:23]
  wire [49:0] _ext_T = {A_sig,26'h0}; // @[src/main/scala/rv32i/Fpu.scala 373:23]
  wire [49:0] ext = _ext_T >> rshC; // @[src/main/scala/rv32i/Fpu.scala 373:42]
  wire [23:0] kept = ext[49:26]; // @[src/main/scala/rv32i/Fpu.scala 374:23]
  wire  rbit = ext[25]; // @[src/main/scala/rv32i/Fpu.scala 375:23]
  wire  stl = |ext[24:0]; // @[src/main/scala/rv32i/Fpu.scala 376:31]
  wire  _magR_T_2 = rbit & (stl | kept[0]); // @[src/main/scala/rv32i/Fpu.scala 147:20]
  wire  _magR_T_3 = rbit | stl; // @[src/main/scala/rv32i/Fpu.scala 149:29]
  wire  _magR_T_4 = A_sign & (rbit | stl); // @[src/main/scala/rv32i/Fpu.scala 149:23]
  wire  _magR_T_7 = ~A_sign & _magR_T_3; // @[src/main/scala/rv32i/Fpu.scala 150:24]
  wire  _magR_T_11 = 3'h1 == rm ? 1'h0 : 3'h0 == rm & _magR_T_2; // @[src/main/scala/rv32i/Fpu.scala 146:88]
  wire  _magR_T_13 = 3'h2 == rm ? _magR_T_4 : _magR_T_11; // @[src/main/scala/rv32i/Fpu.scala 146:88]
  wire  _magR_T_15 = 3'h3 == rm ? _magR_T_7 : _magR_T_13; // @[src/main/scala/rv32i/Fpu.scala 146:88]
  wire  _magR_T_17 = 3'h4 == rm ? rbit : _magR_T_15; // @[src/main/scala/rv32i/Fpu.scala 146:88]
  wire [23:0] _GEN_427 = {{23'd0}, _magR_T_17}; // @[src/main/scala/rv32i/Fpu.scala 377:25]
  wire [24:0] magR = kept + _GEN_427; // @[src/main/scala/rv32i/Fpu.scala 377:25]
  wire [33:0] _mag_T_2 = {{9'd0}, magR}; // @[src/main/scala/rv32i/Fpu.scala 378:44]
  wire [33:0] mag_1 = left ? magL : _mag_T_2; // @[src/main/scala/rv32i/Fpu.scala 378:23]
  wire  inexact_2 = ~left & _magR_T_3; // @[src/main/scala/rv32i/Fpu.scala 379:29]
  wire  _nv_T_2 = A_sign ? mag_1 > 34'h80000000 : mag_1 > 34'h7fffffff; // @[src/main/scala/rv32i/Fpu.scala 380:41]
  wire  _nv_T_5 = A_sign ? mag_1 != 34'h0 : mag_1 > 34'hffffffff; // @[src/main/scala/rv32i/Fpu.scala 381:41]
  wire  _nv_T_6 = _isToInt_T ? _nv_T_2 : _nv_T_5; // @[src/main/scala/rv32i/Fpu.scala 380:29]
  wire  nv = huge | _nv_T_6; // @[src/main/scala/rv32i/Fpu.scala 380:23]
  wire [31:0] _sat_T = A_sign ? 32'h80000000 : 32'h7fffffff; // @[src/main/scala/rv32i/Fpu.scala 382:34]
  wire [31:0] _sat_T_1 = A_sign ? 32'h0 : 32'hffffffff; // @[src/main/scala/rv32i/Fpu.scala 382:54]
  wire [31:0] sat = _isToInt_T ? _sat_T : _sat_T_1; // @[src/main/scala/rv32i/Fpu.scala 382:22]
  wire [33:0] _value_T_1 = 34'h0 - mag_1; // @[src/main/scala/rv32i/Fpu.scala 383:39]
  wire [31:0] value = A_sign ? _value_T_1[31:0] : mag_1[31:0]; // @[src/main/scala/rv32i/Fpu.scala 383:24]
  wire [31:0] _T_86 = nv ? sat : value; // @[src/main/scala/rv32i/Fpu.scala 384:19]
  wire [4:0] _T_87 = inexact_2 ? 5'h1 : 5'h0; // @[src/main/scala/rv32i/Fpu.scala 384:65]
  wire [4:0] _T_88 = nv ? 5'h10 : _T_87; // @[src/main/scala/rv32i/Fpu.scala 384:40]
  assign io_req_ready = state == 4'h0; // @[src/main/scala/rv32i/Fpu.scala 117:26]
  assign io_resp_valid = state == 4'h9; // @[src/main/scala/rv32i/Fpu.scala 119:26]
  assign io_resp_bits_bits = resBits; // @[src/main/scala/rv32i/Fpu.scala 391:22]
  assign io_resp_bits_flags = resFlags; // @[src/main/scala/rv32i/Fpu.scala 392:22]
  assign io_busy = state != 4'h0; // @[src/main/scala/rv32i/Fpu.scala 118:26]
  always @(posedge clock) begin
    if (reset) begin // @[src/main/scala/rv32i/Fpu.scala 109:22]
      state <= 4'h0; // @[src/main/scala/rv32i/Fpu.scala 109:22]
    end else if (io_kill) begin // @[src/main/scala/rv32i/Fpu.scala 389:17]
      state <= 4'h0; // @[src/main/scala/rv32i/Fpu.scala 389:25]
    end else if (_io_resp_valid_T) begin // @[src/main/scala/rv32i/Fpu.scala 388:25]
      state <= 4'h0; // @[src/main/scala/rv32i/Fpu.scala 388:33]
    end else if (state == 4'h8) begin // @[src/main/scala/rv32i/Fpu.scala 359:26]
      state <= 4'h9;
    end else begin
      state <= _GEN_371;
    end
    if (_T) begin // @[src/main/scala/rv32i/Fpu.scala 121:21]
      op <= io_req_bits_op; // @[src/main/scala/rv32i/Fpu.scala 122:8]
    end
    if (_T) begin // @[src/main/scala/rv32i/Fpu.scala 121:21]
      rm <= io_req_bits_rm; // @[src/main/scala/rv32i/Fpu.scala 122:30]
    end
    if (_T) begin // @[src/main/scala/rv32i/Fpu.scala 121:21]
      ra <= io_req_bits_a; // @[src/main/scala/rv32i/Fpu.scala 123:8]
    end
    if (_T) begin // @[src/main/scala/rv32i/Fpu.scala 121:21]
      rb <= io_req_bits_b; // @[src/main/scala/rv32i/Fpu.scala 123:29]
    end
    if (_T) begin // @[src/main/scala/rv32i/Fpu.scala 121:21]
      rc <= io_req_bits_c; // @[src/main/scala/rv32i/Fpu.scala 123:50]
    end
    if (state == 4'h1) begin // @[src/main/scala/rv32i/Fpu.scala 178:27]
      if (isAddSub) begin // @[src/main/scala/rv32i/Fpu.scala 180:20]
        if (!(A_nan | B_nan)) begin // @[src/main/scala/rv32i/Fpu.scala 182:28]
          if (!(A_inf & B_inf)) begin // @[src/main/scala/rv32i/Fpu.scala 183:35]
            xSign <= _GEN_31;
          end
        end
      end else if (isMul | isFma) begin // @[src/main/scala/rv32i/Fpu.scala 192:32]
        if (!(infTimesZero)) begin // @[src/main/scala/rv32i/Fpu.scala 196:26]
          xSign <= _GEN_113;
        end
      end
    end
    if (state == 4'h1) begin // @[src/main/scala/rv32i/Fpu.scala 178:27]
      if (isAddSub) begin // @[src/main/scala/rv32i/Fpu.scala 180:20]
        if (!(A_nan | B_nan)) begin // @[src/main/scala/rv32i/Fpu.scala 182:28]
          if (!(A_inf & B_inf)) begin // @[src/main/scala/rv32i/Fpu.scala 183:35]
            xZero <= _GEN_32;
          end
        end
      end else if (isMul | isFma) begin // @[src/main/scala/rv32i/Fpu.scala 192:32]
        if (!(infTimesZero)) begin // @[src/main/scala/rv32i/Fpu.scala 196:26]
          xZero <= _GEN_114;
        end
      end
    end
    if (state == 4'h1) begin // @[src/main/scala/rv32i/Fpu.scala 178:27]
      if (isAddSub) begin // @[src/main/scala/rv32i/Fpu.scala 180:20]
        if (!(A_nan | B_nan)) begin // @[src/main/scala/rv32i/Fpu.scala 182:28]
          if (!(A_inf & B_inf)) begin // @[src/main/scala/rv32i/Fpu.scala 183:35]
            xSig <= _GEN_33;
          end
        end
      end
    end
    if (state == 4'h1) begin // @[src/main/scala/rv32i/Fpu.scala 178:27]
      if (isAddSub) begin // @[src/main/scala/rv32i/Fpu.scala 180:20]
        if (!(A_nan | B_nan)) begin // @[src/main/scala/rv32i/Fpu.scala 182:28]
          if (!(A_inf & B_inf)) begin // @[src/main/scala/rv32i/Fpu.scala 183:35]
            xExp <= _GEN_34;
          end
        end
      end else if (isMul | isFma) begin // @[src/main/scala/rv32i/Fpu.scala 192:32]
        if (!(infTimesZero)) begin // @[src/main/scala/rv32i/Fpu.scala 196:26]
          xExp <= _GEN_115;
        end
      end
    end
    if (state == 4'h1) begin // @[src/main/scala/rv32i/Fpu.scala 178:27]
      if (isAddSub) begin // @[src/main/scala/rv32i/Fpu.scala 180:20]
        if (!(A_nan | B_nan)) begin // @[src/main/scala/rv32i/Fpu.scala 182:28]
          if (!(A_inf & B_inf)) begin // @[src/main/scala/rv32i/Fpu.scala 183:35]
            ySign <= _GEN_35;
          end
        end
      end else if (isMul | isFma) begin // @[src/main/scala/rv32i/Fpu.scala 192:32]
        if (!(infTimesZero)) begin // @[src/main/scala/rv32i/Fpu.scala 196:26]
          ySign <= _GEN_116;
        end
      end
    end
    if (state == 4'h1) begin // @[src/main/scala/rv32i/Fpu.scala 178:27]
      if (isAddSub) begin // @[src/main/scala/rv32i/Fpu.scala 180:20]
        if (!(A_nan | B_nan)) begin // @[src/main/scala/rv32i/Fpu.scala 182:28]
          if (!(A_inf & B_inf)) begin // @[src/main/scala/rv32i/Fpu.scala 183:35]
            yZero <= _GEN_36;
          end
        end
      end else if (isMul | isFma) begin // @[src/main/scala/rv32i/Fpu.scala 192:32]
        if (!(infTimesZero)) begin // @[src/main/scala/rv32i/Fpu.scala 196:26]
          yZero <= _GEN_117;
        end
      end
    end
    if (state == 4'h1) begin // @[src/main/scala/rv32i/Fpu.scala 178:27]
      if (isAddSub) begin // @[src/main/scala/rv32i/Fpu.scala 180:20]
        if (!(A_nan | B_nan)) begin // @[src/main/scala/rv32i/Fpu.scala 182:28]
          if (!(A_inf & B_inf)) begin // @[src/main/scala/rv32i/Fpu.scala 183:35]
            ySig <= _GEN_37;
          end
        end
      end else if (isMul | isFma) begin // @[src/main/scala/rv32i/Fpu.scala 192:32]
        if (!(infTimesZero)) begin // @[src/main/scala/rv32i/Fpu.scala 196:26]
          ySig <= _GEN_118;
        end
      end
    end
    if (state == 4'h1) begin // @[src/main/scala/rv32i/Fpu.scala 178:27]
      if (isAddSub) begin // @[src/main/scala/rv32i/Fpu.scala 180:20]
        if (!(A_nan | B_nan)) begin // @[src/main/scala/rv32i/Fpu.scala 182:28]
          if (!(A_inf & B_inf)) begin // @[src/main/scala/rv32i/Fpu.scala 183:35]
            yExp <= _GEN_38;
          end
        end
      end else if (isMul | isFma) begin // @[src/main/scala/rv32i/Fpu.scala 192:32]
        if (!(infTimesZero)) begin // @[src/main/scala/rv32i/Fpu.scala 196:26]
          yExp <= _GEN_119;
        end
      end
    end
    if (state == 4'h2) begin // @[src/main/scala/rv32i/Fpu.scala 254:24]
      acc <= _acc_T_3; // @[src/main/scala/rv32i/Fpu.scala 255:12]
    end else if (state == 4'h1) begin // @[src/main/scala/rv32i/Fpu.scala 178:27]
      if (!(isAddSub)) begin // @[src/main/scala/rv32i/Fpu.scala 180:20]
        if (isMul | isFma) begin // @[src/main/scala/rv32i/Fpu.scala 192:32]
          acc <= _GEN_123;
        end
      end
    end
    mcand <= _GEN_325[47:0];
    if (state == 4'h2) begin // @[src/main/scala/rv32i/Fpu.scala 254:24]
      mplier <= {{1'd0}, mplier[23:1]}; // @[src/main/scala/rv32i/Fpu.scala 257:12]
    end else if (state == 4'h1) begin // @[src/main/scala/rv32i/Fpu.scala 178:27]
      if (!(isAddSub)) begin // @[src/main/scala/rv32i/Fpu.scala 180:20]
        if (isMul | isFma) begin // @[src/main/scala/rv32i/Fpu.scala 192:32]
          mplier <= _GEN_125;
        end
      end
    end
    if (state == 4'h5) begin // @[src/main/scala/rv32i/Fpu.scala 301:25]
      count <= _count_T_1; // @[src/main/scala/rv32i/Fpu.scala 310:14]
    end else if (state == 4'h4) begin // @[src/main/scala/rv32i/Fpu.scala 290:24]
      count <= _count_T_1; // @[src/main/scala/rv32i/Fpu.scala 296:11]
    end else if (state == 4'h2) begin // @[src/main/scala/rv32i/Fpu.scala 254:24]
      count <= _count_T_1; // @[src/main/scala/rv32i/Fpu.scala 258:12]
    end else if (state == 4'h1) begin // @[src/main/scala/rv32i/Fpu.scala 178:27]
      count <= _GEN_292;
    end
    rem <= _GEN_353[30:0];
    if (state == 4'h5) begin // @[src/main/scala/rv32i/Fpu.scala 301:25]
      quo <= q_1; // @[src/main/scala/rv32i/Fpu.scala 308:14]
    end else if (state == 4'h4) begin // @[src/main/scala/rv32i/Fpu.scala 290:24]
      quo <= q; // @[src/main/scala/rv32i/Fpu.scala 294:11]
    end else if (state == 4'h1) begin // @[src/main/scala/rv32i/Fpu.scala 178:27]
      if (!(isAddSub)) begin // @[src/main/scala/rv32i/Fpu.scala 180:20]
        quo <= _GEN_273;
      end
    end
    if (state == 4'h1) begin // @[src/main/scala/rv32i/Fpu.scala 178:27]
      if (!(isAddSub)) begin // @[src/main/scala/rv32i/Fpu.scala 180:20]
        if (!(isMul | isFma)) begin // @[src/main/scala/rv32i/Fpu.scala 192:32]
          if (isDiv) begin // @[src/main/scala/rv32i/Fpu.scala 213:23]
            divisor <= _GEN_183;
          end
        end
      end
    end
    radicand <= _GEN_355[53:0];
    if (state == 4'h5) begin // @[src/main/scala/rv32i/Fpu.scala 301:25]
      if (_T_61) begin // @[src/main/scala/rv32i/Fpu.scala 311:26]
        raw <= {{29'd0}, q_1}; // @[src/main/scala/rv32i/Fpu.scala 311:32]
      end else begin
        raw <= _GEN_347;
      end
    end else begin
      raw <= _GEN_347;
    end
    if (state == 4'h3) begin // @[src/main/scala/rv32i/Fpu.scala 263:24]
      if (sum == 52'h0) begin // @[src/main/scala/rv32i/Fpu.scala 282:23]
        rawE <= _GEN_320;
      end else begin
        rawE <= _rawE_T_12; // @[src/main/scala/rv32i/Fpu.scala 284:26]
      end
    end else begin
      rawE <= _GEN_320;
    end
    if (state == 4'h5) begin // @[src/main/scala/rv32i/Fpu.scala 301:25]
      if (_T_61) begin // @[src/main/scala/rv32i/Fpu.scala 311:26]
        sticky <= remNext != 31'h0; // @[src/main/scala/rv32i/Fpu.scala 311:45]
      end else begin
        sticky <= _GEN_348;
      end
    end else begin
      sticky <= _GEN_348;
    end
    if (state == 4'h3) begin // @[src/main/scala/rv32i/Fpu.scala 263:24]
      if (sum == 52'h0) begin // @[src/main/scala/rv32i/Fpu.scala 282:23]
        rSign <= _GEN_319;
      end else if (xBig) begin // @[src/main/scala/rv32i/Fpu.scala 270:23]
        rSign <= xSign;
      end else begin
        rSign <= ySign;
      end
    end else begin
      rSign <= _GEN_319;
    end
    if (state == 4'h6) begin // @[src/main/scala/rv32i/Fpu.scala 315:25]
      nSig <= _nSig_T[55:0]; // @[src/main/scala/rv32i/Fpu.scala 317:11]
    end
    if (state == 4'h6) begin // @[src/main/scala/rv32i/Fpu.scala 315:25]
      nExp <= _nExp_T_7; // @[src/main/scala/rv32i/Fpu.scala 318:11]
    end
    if (state == 4'h8) begin // @[src/main/scala/rv32i/Fpu.scala 359:26]
      if (A_nan) begin // @[src/main/scala/rv32i/Fpu.scala 363:17]
        resBits <= _T_82; // @[src/main/scala/rv32i/Fpu.scala 174:57]
      end else if (A_inf) begin // @[src/main/scala/rv32i/Fpu.scala 364:24]
        if (A_sign) begin // @[src/main/scala/rv32i/Fpu.scala 364:36]
          resBits <= _T_83;
        end else begin
          resBits <= _T_82;
        end
      end else if (A_zero) begin // @[src/main/scala/rv32i/Fpu.scala 365:25]
        resBits <= 32'h0; // @[src/main/scala/rv32i/Fpu.scala 174:57]
      end else begin
        resBits <= _T_86; // @[src/main/scala/rv32i/Fpu.scala 174:57]
      end
    end else if (state == 4'h7) begin // @[src/main/scala/rv32i/Fpu.scala 323:26]
      if ($signed(nExp) >= -13'sh7e) begin // @[src/main/scala/rv32i/Fpu.scala 335:27]
        if ($signed(biased) >= 13'shff) begin // @[src/main/scala/rv32i/Fpu.scala 338:30]
          resBits <= ovBits; // @[src/main/scala/rv32i/Fpu.scala 174:57]
        end else begin
          resBits <= _T_72; // @[src/main/scala/rv32i/Fpu.scala 174:57]
        end
      end else begin
        resBits <= _T_76; // @[src/main/scala/rv32i/Fpu.scala 174:57]
      end
    end else if (state == 4'h3) begin // @[src/main/scala/rv32i/Fpu.scala 263:24]
      if (sum == 52'h0) begin // @[src/main/scala/rv32i/Fpu.scala 282:23]
        resBits <= _T_59; // @[src/main/scala/rv32i/Fpu.scala 174:57]
      end else begin
        resBits <= _GEN_301;
      end
    end else begin
      resBits <= _GEN_301;
    end
    if (state == 4'h8) begin // @[src/main/scala/rv32i/Fpu.scala 359:26]
      if (A_nan) begin // @[src/main/scala/rv32i/Fpu.scala 363:17]
        resFlags <= 5'h10; // @[src/main/scala/rv32i/Fpu.scala 174:75]
      end else if (A_inf) begin // @[src/main/scala/rv32i/Fpu.scala 364:24]
        resFlags <= 5'h10; // @[src/main/scala/rv32i/Fpu.scala 174:75]
      end else if (A_zero) begin // @[src/main/scala/rv32i/Fpu.scala 365:25]
        resFlags <= 5'h0; // @[src/main/scala/rv32i/Fpu.scala 174:75]
      end else begin
        resFlags <= _T_88; // @[src/main/scala/rv32i/Fpu.scala 174:75]
      end
    end else if (state == 4'h7) begin // @[src/main/scala/rv32i/Fpu.scala 323:26]
      if ($signed(nExp) >= -13'sh7e) begin // @[src/main/scala/rv32i/Fpu.scala 335:27]
        if ($signed(biased) >= 13'shff) begin // @[src/main/scala/rv32i/Fpu.scala 338:30]
          resFlags <= 5'h5; // @[src/main/scala/rv32i/Fpu.scala 174:75]
        end else begin
          resFlags <= _T_73; // @[src/main/scala/rv32i/Fpu.scala 174:75]
        end
      end else begin
        resFlags <= _T_80; // @[src/main/scala/rv32i/Fpu.scala 174:75]
      end
    end else if (state == 4'h3) begin // @[src/main/scala/rv32i/Fpu.scala 263:24]
      if (sum == 52'h0) begin // @[src/main/scala/rv32i/Fpu.scala 282:23]
        resFlags <= 5'h0; // @[src/main/scala/rv32i/Fpu.scala 174:75]
      end else begin
        resFlags <= _GEN_302;
      end
    end else begin
      resFlags <= _GEN_302;
    end
  end
// Register and memory initialization
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif
`ifndef RANDOM
`define RANDOM $random
`endif
`ifdef RANDOMIZE_MEM_INIT
  integer initvar;
`endif
`ifndef SYNTHESIS
`ifdef FIRRTL_BEFORE_INITIAL
`FIRRTL_BEFORE_INITIAL
`endif
initial begin
  `ifdef RANDOMIZE
    `ifdef INIT_RANDOM
      `INIT_RANDOM
    `endif
    `ifndef VERILATOR
      `ifdef RANDOMIZE_DELAY
        #`RANDOMIZE_DELAY begin end
      `else
        #0.002 begin end
      `endif
    `endif
`ifdef RANDOMIZE_REG_INIT
  _RAND_0 = {1{`RANDOM}};
  state = _RAND_0[3:0];
  _RAND_1 = {1{`RANDOM}};
  op = _RAND_1[3:0];
  _RAND_2 = {1{`RANDOM}};
  rm = _RAND_2[2:0];
  _RAND_3 = {1{`RANDOM}};
  ra = _RAND_3[31:0];
  _RAND_4 = {1{`RANDOM}};
  rb = _RAND_4[31:0];
  _RAND_5 = {1{`RANDOM}};
  rc = _RAND_5[31:0];
  _RAND_6 = {1{`RANDOM}};
  xSign = _RAND_6[0:0];
  _RAND_7 = {1{`RANDOM}};
  xZero = _RAND_7[0:0];
  _RAND_8 = {2{`RANDOM}};
  xSig = _RAND_8[47:0];
  _RAND_9 = {1{`RANDOM}};
  xExp = _RAND_9[12:0];
  _RAND_10 = {1{`RANDOM}};
  ySign = _RAND_10[0:0];
  _RAND_11 = {1{`RANDOM}};
  yZero = _RAND_11[0:0];
  _RAND_12 = {2{`RANDOM}};
  ySig = _RAND_12[47:0];
  _RAND_13 = {1{`RANDOM}};
  yExp = _RAND_13[12:0];
  _RAND_14 = {2{`RANDOM}};
  acc = _RAND_14[47:0];
  _RAND_15 = {2{`RANDOM}};
  mcand = _RAND_15[47:0];
  _RAND_16 = {1{`RANDOM}};
  mplier = _RAND_16[23:0];
  _RAND_17 = {1{`RANDOM}};
  count = _RAND_17[4:0];
  _RAND_18 = {1{`RANDOM}};
  rem = _RAND_18[30:0];
  _RAND_19 = {1{`RANDOM}};
  quo = _RAND_19[26:0];
  _RAND_20 = {1{`RANDOM}};
  divisor = _RAND_20[23:0];
  _RAND_21 = {2{`RANDOM}};
  radicand = _RAND_21[53:0];
  _RAND_22 = {2{`RANDOM}};
  raw = _RAND_22[55:0];
  _RAND_23 = {1{`RANDOM}};
  rawE = _RAND_23[12:0];
  _RAND_24 = {1{`RANDOM}};
  sticky = _RAND_24[0:0];
  _RAND_25 = {1{`RANDOM}};
  rSign = _RAND_25[0:0];
  _RAND_26 = {2{`RANDOM}};
  nSig = _RAND_26[55:0];
  _RAND_27 = {1{`RANDOM}};
  nExp = _RAND_27[12:0];
  _RAND_28 = {1{`RANDOM}};
  resBits = _RAND_28[31:0];
  _RAND_29 = {1{`RANDOM}};
  resFlags = _RAND_29[4:0];
`endif // RANDOMIZE_REG_INIT
  `endif // RANDOMIZE
end // initial
`ifdef FIRRTL_AFTER_INITIAL
`FIRRTL_AFTER_INITIAL
`endif
`endif // SYNTHESIS
endmodule
module FpMisc(
  input  [2:0]  io_op, // @[src/main/scala/rv32i/FpMisc.scala 23:14]
  input  [2:0]  io_funct3, // @[src/main/scala/rv32i/FpMisc.scala 23:14]
  input  [31:0] io_a, // @[src/main/scala/rv32i/FpMisc.scala 23:14]
  input  [31:0] io_b, // @[src/main/scala/rv32i/FpMisc.scala 23:14]
  output [31:0] io_result, // @[src/main/scala/rv32i/FpMisc.scala 23:14]
  output [4:0]  io_flags // @[src/main/scala/rv32i/FpMisc.scala 23:14]
);
  wire [7:0] A_ef = io_a[30:23]; // @[src/main/scala/rv32i/Fpu.scala 65:15]
  wire [22:0] A_f = io_a[22:0]; // @[src/main/scala/rv32i/Fpu.scala 66:15]
  wire  A_sign = io_a[31]; // @[src/main/scala/rv32i/Fpu.scala 67:16]
  wire  _A_w_zero_T = A_ef == 8'h0; // @[src/main/scala/rv32i/Fpu.scala 68:18]
  wire  _A_w_zero_T_1 = A_f == 23'h0; // @[src/main/scala/rv32i/Fpu.scala 68:31]
  wire  A_zero = A_ef == 8'h0 & A_f == 23'h0; // @[src/main/scala/rv32i/Fpu.scala 68:26]
  wire  _A_w_inf_T = &A_ef; // @[src/main/scala/rv32i/Fpu.scala 69:18]
  wire  A_inf = &A_ef & _A_w_zero_T_1; // @[src/main/scala/rv32i/Fpu.scala 69:23]
  wire  A_nan = _A_w_inf_T & A_f != 23'h0; // @[src/main/scala/rv32i/Fpu.scala 70:23]
  wire  A_snan = A_nan & ~A_f[22]; // @[src/main/scala/rv32i/Fpu.scala 71:21]
  wire [7:0] B_ef = io_b[30:23]; // @[src/main/scala/rv32i/Fpu.scala 65:15]
  wire [22:0] B_f = io_b[22:0]; // @[src/main/scala/rv32i/Fpu.scala 66:15]
  wire  B_sign = io_b[31]; // @[src/main/scala/rv32i/Fpu.scala 67:16]
  wire  B_zero = B_ef == 8'h0 & B_f == 23'h0; // @[src/main/scala/rv32i/Fpu.scala 68:26]
  wire  _B_w_inf_T = &B_ef; // @[src/main/scala/rv32i/Fpu.scala 69:18]
  wire  B_nan = _B_w_inf_T & B_f != 23'h0; // @[src/main/scala/rv32i/Fpu.scala 70:23]
  wire  B_snan = B_nan & ~B_f[22]; // @[src/main/scala/rv32i/Fpu.scala 71:21]
  wire [30:0] magA = io_a[30:0]; // @[src/main/scala/rv32i/FpMisc.scala 35:18]
  wire [30:0] magB = io_b[30:0]; // @[src/main/scala/rv32i/FpMisc.scala 35:42]
  wire  bothZero = A_zero & B_zero; // @[src/main/scala/rv32i/FpMisc.scala 36:25]
  wire  anyNaN = A_nan | B_nan; // @[src/main/scala/rv32i/FpMisc.scala 37:24]
  wire  anySNaN = A_snan | B_snan; // @[src/main/scala/rv32i/FpMisc.scala 38:25]
  wire  _ltOrdered_T_3 = A_sign ? magA > magB : magA < magB; // @[src/main/scala/rv32i/FpMisc.scala 41:41]
  wire  ltOrdered = A_sign != B_sign ? A_sign : _ltOrdered_T_3; // @[src/main/scala/rv32i/FpMisc.scala 41:22]
  wire  eqBits = io_a == io_b; // @[src/main/scala/rv32i/FpMisc.scala 42:24]
  wire  _s_T_2 = 3'h0 == io_funct3; // @[src/main/scala/rv32i/FpMisc.scala 48:39]
  wire  _s_T_4 = 3'h1 == io_funct3; // @[src/main/scala/rv32i/FpMisc.scala 48:39]
  wire  _s_T_5 = 3'h1 == io_funct3 ? ~B_sign : B_sign; // @[src/main/scala/rv32i/FpMisc.scala 48:39]
  wire  _s_T_6 = 3'h2 == io_funct3; // @[src/main/scala/rv32i/FpMisc.scala 48:39]
  wire  s = 3'h2 == io_funct3 ? A_sign ^ B_sign : _s_T_5; // @[src/main/scala/rv32i/FpMisc.scala 48:39]
  wire [31:0] _io_result_T = {s,magA}; // @[src/main/scala/rv32i/FpMisc.scala 49:23]
  wire  isMax = io_funct3[0]; // @[src/main/scala/rv32i/FpMisc.scala 52:28]
  wire  _pickA_T_1 = isMax ? ~ltOrdered : ltOrdered; // @[src/main/scala/rv32i/FpMisc.scala 53:22]
  wire  pickA = _pickA_T_1 | eqBits; // @[src/main/scala/rv32i/FpMisc.scala 53:53]
  wire [31:0] _io_result_T_2 = pickA ? io_a : io_b; // @[src/main/scala/rv32i/FpMisc.scala 54:92]
  wire [31:0] _io_result_T_3 = B_nan ? io_a : _io_result_T_2; // @[src/main/scala/rv32i/FpMisc.scala 54:75]
  wire [31:0] _io_result_T_4 = A_nan ? io_b : _io_result_T_3; // @[src/main/scala/rv32i/FpMisc.scala 54:58]
  wire [31:0] _io_result_T_5 = A_nan & B_nan ? 32'h7fc00000 : _io_result_T_4; // @[src/main/scala/rv32i/FpMisc.scala 54:23]
  wire  _eq_T = ~anyNaN; // @[src/main/scala/rv32i/FpMisc.scala 58:16]
  wire  eq = ~anyNaN & (eqBits | bothZero); // @[src/main/scala/rv32i/FpMisc.scala 58:24]
  wire  lt = _eq_T & ~bothZero & ltOrdered; // @[src/main/scala/rv32i/FpMisc.scala 59:37]
  wire  _io_result_T_10 = _s_T_4 ? lt : _s_T_6 & eq; // @[src/main/scala/rv32i/FpMisc.scala 60:45]
  wire  _io_result_T_12 = _s_T_2 ? lt | eq : _io_result_T_10; // @[src/main/scala/rv32i/FpMisc.scala 60:45]
  wire  _nv_T_1 = io_funct3 == 3'h2 ? anySNaN : anyNaN; // @[src/main/scala/rv32i/FpMisc.scala 61:16]
  wire  _sub_T_2 = ~A_zero; // @[src/main/scala/rv32i/FpMisc.scala 64:41]
  wire  sub = _A_w_zero_T & ~A_zero; // @[src/main/scala/rv32i/FpMisc.scala 64:38]
  wire  normal = _sub_T_2 & ~sub & ~A_inf & ~A_nan; // @[src/main/scala/rv32i/FpMisc.scala 65:46]
  wire  _io_result_T_14 = A_nan & ~A_snan; // @[src/main/scala/rv32i/FpMisc.scala 66:30]
  wire  _io_result_T_16 = A_inf & ~A_sign; // @[src/main/scala/rv32i/FpMisc.scala 66:56]
  wire  _io_result_T_18 = normal & ~A_sign; // @[src/main/scala/rv32i/FpMisc.scala 66:71]
  wire  _io_result_T_20 = sub & ~A_sign; // @[src/main/scala/rv32i/FpMisc.scala 66:83]
  wire  _io_result_T_22 = A_zero & ~A_sign; // @[src/main/scala/rv32i/FpMisc.scala 66:98]
  wire  _io_result_T_23 = A_zero & A_sign; // @[src/main/scala/rv32i/FpMisc.scala 67:31]
  wire  _io_result_T_24 = sub & A_sign; // @[src/main/scala/rv32i/FpMisc.scala 67:42]
  wire  _io_result_T_25 = normal & A_sign; // @[src/main/scala/rv32i/FpMisc.scala 67:56]
  wire  _io_result_T_26 = A_inf & A_sign; // @[src/main/scala/rv32i/FpMisc.scala 67:69]
  wire [9:0] _io_result_T_27 = {_io_result_T_14,A_snan,_io_result_T_16,_io_result_T_18,_io_result_T_20,_io_result_T_22,
    _io_result_T_23,_io_result_T_24,_io_result_T_25,_io_result_T_26}; // @[src/main/scala/rv32i/FpMisc.scala 66:23]
  wire [9:0] _GEN_0 = 3'h3 == io_op ? _io_result_T_27 : 10'h0; // @[src/main/scala/rv32i/FpMisc.scala 45:13 46:17 66:17]
  wire [9:0] _GEN_1 = 3'h2 == io_op ? {{9'd0}, _io_result_T_12} : _GEN_0; // @[src/main/scala/rv32i/FpMisc.scala 46:17 60:17]
  wire  _GEN_2 = 3'h2 == io_op & _nv_T_1; // @[src/main/scala/rv32i/FpMisc.scala 46:17 61:10 44:23]
  wire [31:0] _GEN_3 = 3'h1 == io_op ? _io_result_T_5 : {{22'd0}, _GEN_1}; // @[src/main/scala/rv32i/FpMisc.scala 46:17 54:17]
  wire  _GEN_4 = 3'h1 == io_op ? anySNaN : _GEN_2; // @[src/main/scala/rv32i/FpMisc.scala 46:17 55:10]
  wire  nv = 3'h0 == io_op ? 1'h0 : _GEN_4; // @[src/main/scala/rv32i/FpMisc.scala 46:17 44:23]
  assign io_result = 3'h0 == io_op ? _io_result_T : _GEN_3; // @[src/main/scala/rv32i/FpMisc.scala 46:17 49:17]
  assign io_flags = nv ? 5'h10 : 5'h0; // @[src/main/scala/rv32i/FpMisc.scala 70:18]
endmodule
module Core(
  input         clock,
  input         reset,
  output [31:0] io_imem_addr, // @[src/main/scala/rv32i/Core.scala 40:14]
  input  [31:0] io_imem_data, // @[src/main/scala/rv32i/Core.scala 40:14]
  output [31:0] io_dmem_addr, // @[src/main/scala/rv32i/Core.scala 40:14]
  output        io_dmem_re, // @[src/main/scala/rv32i/Core.scala 40:14]
  output        io_dmem_we, // @[src/main/scala/rv32i/Core.scala 40:14]
  output [31:0] io_dmem_wdata, // @[src/main/scala/rv32i/Core.scala 40:14]
  output [3:0]  io_dmem_wstrb, // @[src/main/scala/rv32i/Core.scala 40:14]
  input  [31:0] io_dmem_rdata, // @[src/main/scala/rv32i/Core.scala 40:14]
  output        io_trace_valid, // @[src/main/scala/rv32i/Core.scala 40:14]
  output        io_trace_trap, // @[src/main/scala/rv32i/Core.scala 40:14]
  output [3:0]  io_trace_cause, // @[src/main/scala/rv32i/Core.scala 40:14]
  output [31:0] io_trace_pc, // @[src/main/scala/rv32i/Core.scala 40:14]
  output [31:0] io_trace_pcNext, // @[src/main/scala/rv32i/Core.scala 40:14]
  output [31:0] io_trace_inst, // @[src/main/scala/rv32i/Core.scala 40:14]
  output [4:0]  io_trace_rdAddr, // @[src/main/scala/rv32i/Core.scala 40:14]
  output [31:0] io_trace_rdData, // @[src/main/scala/rv32i/Core.scala 40:14]
  output [31:0] io_trace_memAddr, // @[src/main/scala/rv32i/Core.scala 40:14]
  output        io_trace_memRe, // @[src/main/scala/rv32i/Core.scala 40:14]
  output        io_trace_memWe, // @[src/main/scala/rv32i/Core.scala 40:14]
  output [1:0]  io_trace_memSize, // @[src/main/scala/rv32i/Core.scala 40:14]
  output [31:0] io_trace_memWdata, // @[src/main/scala/rv32i/Core.scala 40:14]
  output        io_trace_fdWe, // @[src/main/scala/rv32i/Core.scala 40:14]
  output [4:0]  io_trace_fdAddr, // @[src/main/scala/rv32i/Core.scala 40:14]
  output [31:0] io_trace_fdData, // @[src/main/scala/rv32i/Core.scala 40:14]
  output [4:0]  io_trace_fflags // @[src/main/scala/rv32i/Core.scala 40:14]
);
`ifdef RANDOMIZE_REG_INIT
  reg [31:0] _RAND_0;
  reg [31:0] _RAND_1;
  reg [31:0] _RAND_2;
  reg [31:0] _RAND_3;
  reg [31:0] _RAND_4;
  reg [31:0] _RAND_5;
  reg [31:0] _RAND_6;
  reg [31:0] _RAND_7;
  reg [31:0] _RAND_8;
  reg [31:0] _RAND_9;
  reg [31:0] _RAND_10;
  reg [31:0] _RAND_11;
  reg [31:0] _RAND_12;
  reg [31:0] _RAND_13;
  reg [31:0] _RAND_14;
  reg [31:0] _RAND_15;
  reg [31:0] _RAND_16;
  reg [31:0] _RAND_17;
  reg [31:0] _RAND_18;
  reg [31:0] _RAND_19;
  reg [31:0] _RAND_20;
  reg [31:0] _RAND_21;
  reg [31:0] _RAND_22;
  reg [31:0] _RAND_23;
  reg [31:0] _RAND_24;
  reg [31:0] _RAND_25;
  reg [31:0] _RAND_26;
  reg [31:0] _RAND_27;
  reg [31:0] _RAND_28;
  reg [31:0] _RAND_29;
  reg [31:0] _RAND_30;
  reg [31:0] _RAND_31;
  reg [31:0] _RAND_32;
  reg [31:0] _RAND_33;
  reg [31:0] _RAND_34;
  reg [31:0] _RAND_35;
  reg [31:0] _RAND_36;
  reg [31:0] _RAND_37;
  reg [31:0] _RAND_38;
  reg [31:0] _RAND_39;
  reg [31:0] _RAND_40;
  reg [31:0] _RAND_41;
  reg [31:0] _RAND_42;
  reg [31:0] _RAND_43;
  reg [31:0] _RAND_44;
  reg [31:0] _RAND_45;
  reg [31:0] _RAND_46;
  reg [31:0] _RAND_47;
  reg [31:0] _RAND_48;
  reg [31:0] _RAND_49;
  reg [31:0] _RAND_50;
  reg [31:0] _RAND_51;
  reg [31:0] _RAND_52;
  reg [31:0] _RAND_53;
  reg [31:0] _RAND_54;
  reg [31:0] _RAND_55;
  reg [31:0] _RAND_56;
  reg [31:0] _RAND_57;
  reg [31:0] _RAND_58;
  reg [31:0] _RAND_59;
  reg [31:0] _RAND_60;
  reg [31:0] _RAND_61;
  reg [31:0] _RAND_62;
  reg [31:0] _RAND_63;
  reg [31:0] _RAND_64;
  reg [31:0] _RAND_65;
  reg [31:0] _RAND_66;
  reg [31:0] _RAND_67;
  reg [31:0] _RAND_68;
  reg [31:0] _RAND_69;
  reg [31:0] _RAND_70;
  reg [31:0] _RAND_71;
  reg [31:0] _RAND_72;
  reg [31:0] _RAND_73;
  reg [31:0] _RAND_74;
  reg [31:0] _RAND_75;
`endif // RANDOMIZE_REG_INIT
  wire [31:0] dec_io_inst; // @[src/main/scala/rv32i/Core.scala 48:20]
  wire [2:0] dec_io_immSel; // @[src/main/scala/rv32i/Core.scala 48:20]
  wire [1:0] dec_io_aluSrcA; // @[src/main/scala/rv32i/Core.scala 48:20]
  wire  dec_io_aluSrcImm; // @[src/main/scala/rv32i/Core.scala 48:20]
  wire [3:0] dec_io_aluOp; // @[src/main/scala/rv32i/Core.scala 48:20]
  wire  dec_io_branch; // @[src/main/scala/rv32i/Core.scala 48:20]
  wire  dec_io_jal; // @[src/main/scala/rv32i/Core.scala 48:20]
  wire  dec_io_jalr; // @[src/main/scala/rv32i/Core.scala 48:20]
  wire  dec_io_memRead; // @[src/main/scala/rv32i/Core.scala 48:20]
  wire  dec_io_memWrite; // @[src/main/scala/rv32i/Core.scala 48:20]
  wire [1:0] dec_io_memSize; // @[src/main/scala/rv32i/Core.scala 48:20]
  wire  dec_io_memUnsigned; // @[src/main/scala/rv32i/Core.scala 48:20]
  wire [1:0] dec_io_wbSel; // @[src/main/scala/rv32i/Core.scala 48:20]
  wire  dec_io_regWrite; // @[src/main/scala/rv32i/Core.scala 48:20]
  wire  dec_io_csr; // @[src/main/scala/rv32i/Core.scala 48:20]
  wire  dec_io_ecall; // @[src/main/scala/rv32i/Core.scala 48:20]
  wire  dec_io_ebreak; // @[src/main/scala/rv32i/Core.scala 48:20]
  wire  dec_io_mret; // @[src/main/scala/rv32i/Core.scala 48:20]
  wire  dec_io_illegal; // @[src/main/scala/rv32i/Core.scala 48:20]
  wire [31:0] immg_io_inst; // @[src/main/scala/rv32i/Core.scala 49:20]
  wire [2:0] immg_io_sel; // @[src/main/scala/rv32i/Core.scala 49:20]
  wire [31:0] immg_io_imm; // @[src/main/scala/rv32i/Core.scala 49:20]
  wire  rf_clock; // @[src/main/scala/rv32i/Core.scala 50:20]
  wire  rf_reset; // @[src/main/scala/rv32i/Core.scala 50:20]
  wire [4:0] rf_io_rs1; // @[src/main/scala/rv32i/Core.scala 50:20]
  wire [4:0] rf_io_rs2; // @[src/main/scala/rv32i/Core.scala 50:20]
  wire [31:0] rf_io_rd1; // @[src/main/scala/rv32i/Core.scala 50:20]
  wire [31:0] rf_io_rd2; // @[src/main/scala/rv32i/Core.scala 50:20]
  wire  rf_io_we; // @[src/main/scala/rv32i/Core.scala 50:20]
  wire [4:0] rf_io_waddr; // @[src/main/scala/rv32i/Core.scala 50:20]
  wire [31:0] rf_io_wdata; // @[src/main/scala/rv32i/Core.scala 50:20]
  wire [3:0] alu_io_op; // @[src/main/scala/rv32i/Core.scala 51:20]
  wire [31:0] alu_io_a; // @[src/main/scala/rv32i/Core.scala 51:20]
  wire [31:0] alu_io_b; // @[src/main/scala/rv32i/Core.scala 51:20]
  wire [31:0] alu_io_y; // @[src/main/scala/rv32i/Core.scala 51:20]
  wire  csr_clock; // @[src/main/scala/rv32i/Core.scala 52:20]
  wire  csr_reset; // @[src/main/scala/rv32i/Core.scala 52:20]
  wire [11:0] csr_io_addr; // @[src/main/scala/rv32i/Core.scala 52:20]
  wire  csr_io_en; // @[src/main/scala/rv32i/Core.scala 52:20]
  wire [1:0] csr_io_op; // @[src/main/scala/rv32i/Core.scala 52:20]
  wire [31:0] csr_io_src; // @[src/main/scala/rv32i/Core.scala 52:20]
  wire  csr_io_wrEn; // @[src/main/scala/rv32i/Core.scala 52:20]
  wire [31:0] csr_io_rdata; // @[src/main/scala/rv32i/Core.scala 52:20]
  wire  csr_io_illegal; // @[src/main/scala/rv32i/Core.scala 52:20]
  wire  csr_io_commit; // @[src/main/scala/rv32i/Core.scala 52:20]
  wire  csr_io_trapEnter; // @[src/main/scala/rv32i/Core.scala 52:20]
  wire [31:0] csr_io_trapCause; // @[src/main/scala/rv32i/Core.scala 52:20]
  wire [31:0] csr_io_trapPc; // @[src/main/scala/rv32i/Core.scala 52:20]
  wire [31:0] csr_io_trapVal; // @[src/main/scala/rv32i/Core.scala 52:20]
  wire  csr_io_mretEnter; // @[src/main/scala/rv32i/Core.scala 52:20]
  wire [31:0] csr_io_mtvecBase; // @[src/main/scala/rv32i/Core.scala 52:20]
  wire [31:0] csr_io_mepc; // @[src/main/scala/rv32i/Core.scala 52:20]
  wire [4:0] csr_io_fflagsSet; // @[src/main/scala/rv32i/Core.scala 52:20]
  wire [2:0] csr_io_frm; // @[src/main/scala/rv32i/Core.scala 52:20]
  wire [1:0] mul_io_fn; // @[src/main/scala/rv32i/Core.scala 53:20]
  wire [31:0] mul_io_a; // @[src/main/scala/rv32i/Core.scala 53:20]
  wire [31:0] mul_io_b; // @[src/main/scala/rv32i/Core.scala 53:20]
  wire [31:0] mul_io_result; // @[src/main/scala/rv32i/Core.scala 53:20]
  wire  div_clock; // @[src/main/scala/rv32i/Core.scala 54:20]
  wire  div_reset; // @[src/main/scala/rv32i/Core.scala 54:20]
  wire  div_io_req_ready; // @[src/main/scala/rv32i/Core.scala 54:20]
  wire  div_io_req_valid; // @[src/main/scala/rv32i/Core.scala 54:20]
  wire [1:0] div_io_req_bits_op; // @[src/main/scala/rv32i/Core.scala 54:20]
  wire [31:0] div_io_req_bits_a; // @[src/main/scala/rv32i/Core.scala 54:20]
  wire [31:0] div_io_req_bits_b; // @[src/main/scala/rv32i/Core.scala 54:20]
  wire  div_io_resp_valid; // @[src/main/scala/rv32i/Core.scala 54:20]
  wire [31:0] div_io_resp_bits; // @[src/main/scala/rv32i/Core.scala 54:20]
  wire  div_io_kill; // @[src/main/scala/rv32i/Core.scala 54:20]
  wire  div_io_busy; // @[src/main/scala/rv32i/Core.scala 54:20]
  wire [31:0] fdecId_io_inst; // @[src/main/scala/rv32i/Core.scala 55:22]
  wire [2:0] fdecId_io_frm; // @[src/main/scala/rv32i/Core.scala 55:22]
  wire  fdecId_io_isF; // @[src/main/scala/rv32i/Core.scala 55:22]
  wire  fdecId_io_illegal; // @[src/main/scala/rv32i/Core.scala 55:22]
  wire [2:0] fdecId_io_rm; // @[src/main/scala/rv32i/Core.scala 55:22]
  wire  fdecId_io_useFpu; // @[src/main/scala/rv32i/Core.scala 55:22]
  wire [3:0] fdecId_io_fpuOp; // @[src/main/scala/rv32i/Core.scala 55:22]
  wire  fdecId_io_useMisc; // @[src/main/scala/rv32i/Core.scala 55:22]
  wire [2:0] fdecId_io_miscOp; // @[src/main/scala/rv32i/Core.scala 55:22]
  wire  fdecId_io_mvXW; // @[src/main/scala/rv32i/Core.scala 55:22]
  wire  fdecId_io_mvWX; // @[src/main/scala/rv32i/Core.scala 55:22]
  wire  fdecId_io_intSrc; // @[src/main/scala/rv32i/Core.scala 55:22]
  wire  fdecId_io_writesX; // @[src/main/scala/rv32i/Core.scala 55:22]
  wire  fdecId_io_writesF; // @[src/main/scala/rv32i/Core.scala 55:22]
  wire [31:0] fdecEx_io_inst; // @[src/main/scala/rv32i/Core.scala 56:22]
  wire [2:0] fdecEx_io_frm; // @[src/main/scala/rv32i/Core.scala 56:22]
  wire  fdecEx_io_isF; // @[src/main/scala/rv32i/Core.scala 56:22]
  wire  fdecEx_io_illegal; // @[src/main/scala/rv32i/Core.scala 56:22]
  wire [2:0] fdecEx_io_rm; // @[src/main/scala/rv32i/Core.scala 56:22]
  wire  fdecEx_io_useFpu; // @[src/main/scala/rv32i/Core.scala 56:22]
  wire [3:0] fdecEx_io_fpuOp; // @[src/main/scala/rv32i/Core.scala 56:22]
  wire  fdecEx_io_useMisc; // @[src/main/scala/rv32i/Core.scala 56:22]
  wire [2:0] fdecEx_io_miscOp; // @[src/main/scala/rv32i/Core.scala 56:22]
  wire  fdecEx_io_mvXW; // @[src/main/scala/rv32i/Core.scala 56:22]
  wire  fdecEx_io_mvWX; // @[src/main/scala/rv32i/Core.scala 56:22]
  wire  fdecEx_io_intSrc; // @[src/main/scala/rv32i/Core.scala 56:22]
  wire  fdecEx_io_writesX; // @[src/main/scala/rv32i/Core.scala 56:22]
  wire  fdecEx_io_writesF; // @[src/main/scala/rv32i/Core.scala 56:22]
  wire  frf_clock; // @[src/main/scala/rv32i/Core.scala 57:22]
  wire  frf_reset; // @[src/main/scala/rv32i/Core.scala 57:22]
  wire [4:0] frf_io_rs1; // @[src/main/scala/rv32i/Core.scala 57:22]
  wire [4:0] frf_io_rs2; // @[src/main/scala/rv32i/Core.scala 57:22]
  wire [4:0] frf_io_rs3; // @[src/main/scala/rv32i/Core.scala 57:22]
  wire [31:0] frf_io_rd1; // @[src/main/scala/rv32i/Core.scala 57:22]
  wire [31:0] frf_io_rd2; // @[src/main/scala/rv32i/Core.scala 57:22]
  wire [31:0] frf_io_rd3; // @[src/main/scala/rv32i/Core.scala 57:22]
  wire  frf_io_we; // @[src/main/scala/rv32i/Core.scala 57:22]
  wire [4:0] frf_io_waddr; // @[src/main/scala/rv32i/Core.scala 57:22]
  wire [31:0] frf_io_wdata; // @[src/main/scala/rv32i/Core.scala 57:22]
  wire  fpu_clock; // @[src/main/scala/rv32i/Core.scala 58:22]
  wire  fpu_reset; // @[src/main/scala/rv32i/Core.scala 58:22]
  wire  fpu_io_req_ready; // @[src/main/scala/rv32i/Core.scala 58:22]
  wire  fpu_io_req_valid; // @[src/main/scala/rv32i/Core.scala 58:22]
  wire [3:0] fpu_io_req_bits_op; // @[src/main/scala/rv32i/Core.scala 58:22]
  wire [2:0] fpu_io_req_bits_rm; // @[src/main/scala/rv32i/Core.scala 58:22]
  wire [31:0] fpu_io_req_bits_a; // @[src/main/scala/rv32i/Core.scala 58:22]
  wire [31:0] fpu_io_req_bits_b; // @[src/main/scala/rv32i/Core.scala 58:22]
  wire [31:0] fpu_io_req_bits_c; // @[src/main/scala/rv32i/Core.scala 58:22]
  wire  fpu_io_resp_valid; // @[src/main/scala/rv32i/Core.scala 58:22]
  wire [31:0] fpu_io_resp_bits_bits; // @[src/main/scala/rv32i/Core.scala 58:22]
  wire [4:0] fpu_io_resp_bits_flags; // @[src/main/scala/rv32i/Core.scala 58:22]
  wire  fpu_io_kill; // @[src/main/scala/rv32i/Core.scala 58:22]
  wire  fpu_io_busy; // @[src/main/scala/rv32i/Core.scala 58:22]
  wire [2:0] fmisc_io_op; // @[src/main/scala/rv32i/Core.scala 59:22]
  wire [2:0] fmisc_io_funct3; // @[src/main/scala/rv32i/Core.scala 59:22]
  wire [31:0] fmisc_io_a; // @[src/main/scala/rv32i/Core.scala 59:22]
  wire [31:0] fmisc_io_b; // @[src/main/scala/rv32i/Core.scala 59:22]
  wire [31:0] fmisc_io_result; // @[src/main/scala/rv32i/Core.scala 59:22]
  wire [4:0] fmisc_io_flags; // @[src/main/scala/rv32i/Core.scala 59:22]
  reg  ifid_valid; // @[src/main/scala/rv32i/Core.scala 62:22]
  reg [31:0] ifid_pc; // @[src/main/scala/rv32i/Core.scala 62:22]
  reg [31:0] ifid_inst; // @[src/main/scala/rv32i/Core.scala 62:22]
  reg  idex_valid; // @[src/main/scala/rv32i/Core.scala 63:22]
  reg [31:0] idex_pc; // @[src/main/scala/rv32i/Core.scala 63:22]
  reg [31:0] idex_inst; // @[src/main/scala/rv32i/Core.scala 63:22]
  reg [4:0] idex_rs1; // @[src/main/scala/rv32i/Core.scala 63:22]
  reg [4:0] idex_rs2; // @[src/main/scala/rv32i/Core.scala 63:22]
  reg [4:0] idex_rs3; // @[src/main/scala/rv32i/Core.scala 63:22]
  reg [4:0] idex_rd; // @[src/main/scala/rv32i/Core.scala 63:22]
  reg [31:0] idex_rs1Val; // @[src/main/scala/rv32i/Core.scala 63:22]
  reg [31:0] idex_rs2Val; // @[src/main/scala/rv32i/Core.scala 63:22]
  reg [31:0] idex_frs1Val; // @[src/main/scala/rv32i/Core.scala 63:22]
  reg [31:0] idex_frs2Val; // @[src/main/scala/rv32i/Core.scala 63:22]
  reg [31:0] idex_frs3Val; // @[src/main/scala/rv32i/Core.scala 63:22]
  reg [31:0] idex_imm; // @[src/main/scala/rv32i/Core.scala 63:22]
  reg [1:0] idex_ctrl_aluSrcA; // @[src/main/scala/rv32i/Core.scala 63:22]
  reg  idex_ctrl_aluSrcImm; // @[src/main/scala/rv32i/Core.scala 63:22]
  reg [3:0] idex_ctrl_aluOp; // @[src/main/scala/rv32i/Core.scala 63:22]
  reg  idex_ctrl_branch; // @[src/main/scala/rv32i/Core.scala 63:22]
  reg  idex_ctrl_jal; // @[src/main/scala/rv32i/Core.scala 63:22]
  reg  idex_ctrl_jalr; // @[src/main/scala/rv32i/Core.scala 63:22]
  reg  idex_ctrl_memRead; // @[src/main/scala/rv32i/Core.scala 63:22]
  reg  idex_ctrl_memWrite; // @[src/main/scala/rv32i/Core.scala 63:22]
  reg [1:0] idex_ctrl_memSize; // @[src/main/scala/rv32i/Core.scala 63:22]
  reg  idex_ctrl_memUnsigned; // @[src/main/scala/rv32i/Core.scala 63:22]
  reg [1:0] idex_ctrl_wbSel; // @[src/main/scala/rv32i/Core.scala 63:22]
  reg  idex_ctrl_regWrite; // @[src/main/scala/rv32i/Core.scala 63:22]
  reg  idex_ctrl_csr; // @[src/main/scala/rv32i/Core.scala 63:22]
  reg  idex_ctrl_ecall; // @[src/main/scala/rv32i/Core.scala 63:22]
  reg  idex_ctrl_ebreak; // @[src/main/scala/rv32i/Core.scala 63:22]
  reg  idex_ctrl_mret; // @[src/main/scala/rv32i/Core.scala 63:22]
  reg  idex_ctrl_illegal; // @[src/main/scala/rv32i/Core.scala 63:22]
  reg  idex_ctrl_isMul; // @[src/main/scala/rv32i/Core.scala 63:22]
  reg  idex_ctrl_isDiv; // @[src/main/scala/rv32i/Core.scala 63:22]
  reg  idex_ctrl_usesRs1; // @[src/main/scala/rv32i/Core.scala 63:22]
  reg  idex_ctrl_usesRs2; // @[src/main/scala/rv32i/Core.scala 63:22]
  reg  idex_ctrl_isF; // @[src/main/scala/rv32i/Core.scala 63:22]
  reg  idex_ctrl_fWrite; // @[src/main/scala/rv32i/Core.scala 63:22]
  reg  idex_ctrl_usesFrs1; // @[src/main/scala/rv32i/Core.scala 63:22]
  reg  idex_ctrl_usesFrs2; // @[src/main/scala/rv32i/Core.scala 63:22]
  reg  idex_ctrl_usesFrs3; // @[src/main/scala/rv32i/Core.scala 63:22]
  reg  exmem_valid; // @[src/main/scala/rv32i/Core.scala 64:22]
  reg  exmem_trap; // @[src/main/scala/rv32i/Core.scala 64:22]
  reg [3:0] exmem_cause; // @[src/main/scala/rv32i/Core.scala 64:22]
  reg [31:0] exmem_pc; // @[src/main/scala/rv32i/Core.scala 64:22]
  reg [31:0] exmem_pcNext; // @[src/main/scala/rv32i/Core.scala 64:22]
  reg [31:0] exmem_inst; // @[src/main/scala/rv32i/Core.scala 64:22]
  reg [4:0] exmem_rd; // @[src/main/scala/rv32i/Core.scala 64:22]
  reg  exmem_regWrite; // @[src/main/scala/rv32i/Core.scala 64:22]
  reg  exmem_fWrite; // @[src/main/scala/rv32i/Core.scala 64:22]
  reg [31:0] exmem_result; // @[src/main/scala/rv32i/Core.scala 64:22]
  reg  exmem_memRead; // @[src/main/scala/rv32i/Core.scala 64:22]
  reg  exmem_memWrite; // @[src/main/scala/rv32i/Core.scala 64:22]
  reg [1:0] exmem_memSize; // @[src/main/scala/rv32i/Core.scala 64:22]
  reg  exmem_memUnsigned; // @[src/main/scala/rv32i/Core.scala 64:22]
  reg [31:0] exmem_addr; // @[src/main/scala/rv32i/Core.scala 64:22]
  reg [31:0] exmem_storeData; // @[src/main/scala/rv32i/Core.scala 64:22]
  reg [4:0] exmem_fflags; // @[src/main/scala/rv32i/Core.scala 64:22]
  reg  memwb_valid; // @[src/main/scala/rv32i/Core.scala 65:22]
  reg  memwb_trap; // @[src/main/scala/rv32i/Core.scala 65:22]
  reg [3:0] memwb_cause; // @[src/main/scala/rv32i/Core.scala 65:22]
  reg [31:0] memwb_pc; // @[src/main/scala/rv32i/Core.scala 65:22]
  reg [31:0] memwb_pcNext; // @[src/main/scala/rv32i/Core.scala 65:22]
  reg [31:0] memwb_inst; // @[src/main/scala/rv32i/Core.scala 65:22]
  reg [4:0] memwb_rd; // @[src/main/scala/rv32i/Core.scala 65:22]
  reg  memwb_regWrite; // @[src/main/scala/rv32i/Core.scala 65:22]
  reg  memwb_fWrite; // @[src/main/scala/rv32i/Core.scala 65:22]
  reg [31:0] memwb_wdata; // @[src/main/scala/rv32i/Core.scala 65:22]
  reg  memwb_memRe; // @[src/main/scala/rv32i/Core.scala 65:22]
  reg  memwb_memWe; // @[src/main/scala/rv32i/Core.scala 65:22]
  reg [31:0] memwb_memAddr; // @[src/main/scala/rv32i/Core.scala 65:22]
  reg [1:0] memwb_memSize; // @[src/main/scala/rv32i/Core.scala 65:22]
  reg [31:0] memwb_memWdata; // @[src/main/scala/rv32i/Core.scala 65:22]
  reg [4:0] memwb_fflags; // @[src/main/scala/rv32i/Core.scala 65:22]
  reg [31:0] fetchPc; // @[src/main/scala/rv32i/Core.scala 70:24]
  wire [31:0] idInst = ifid_valid ? ifid_inst : 32'h13; // @[src/main/scala/rv32i/Core.scala 76:21]
  wire [6:0] idOpcode = idInst[6:0]; // @[src/main/scala/rv32i/Core.scala 77:24]
  wire [2:0] idF3 = idInst[14:12]; // @[src/main/scala/rv32i/Core.scala 78:24]
  wire  _idMulDiv_T = idOpcode == 7'h33; // @[src/main/scala/rv32i/Core.scala 79:27]
  wire  idMulDiv = idOpcode == 7'h33 & idInst[31:25] == 7'h1; // @[src/main/scala/rv32i/Core.scala 79:43]
  wire [4:0] rs1 = idInst[19:15]; // @[src/main/scala/rv32i/Core.scala 80:24]
  wire [4:0] rs2 = idInst[24:20]; // @[src/main/scala/rv32i/Core.scala 81:24]
  wire [4:0] rs3 = idInst[31:27]; // @[src/main/scala/rv32i/Core.scala 82:24]
  wire  idFLoad = fdecId_io_isF & idOpcode == 7'h7; // @[src/main/scala/rv32i/Core.scala 88:24]
  wire  idFStore = fdecId_io_isF & idOpcode == 7'h27; // @[src/main/scala/rv32i/Core.scala 89:24]
  wire  _idFma_T_3 = idOpcode == 7'h4b; // @[src/main/scala/rv32i/Core.scala 91:37]
  wire  _idFma_T_4 = idOpcode == 7'h43 | idOpcode == 7'h47 | _idFma_T_3; // @[src/main/scala/rv32i/Core.scala 90:87]
  wire  _idFma_T_6 = _idFma_T_4 | idOpcode == 7'h4f; // @[src/main/scala/rv32i/Core.scala 91:57]
  wire  idFma = fdecId_io_isF & _idFma_T_6; // @[src/main/scala/rv32i/Core.scala 90:24]
  wire  _idFBinary_T_13 = idInst[31:25] == 7'h0 | idInst[31:25] == 7'h4 | idInst[31:25] == 7'h8 | idInst[31:25] == 7'hc
     | idInst[31:25] == 7'h10 | idInst[31:25] == 7'h14 | idInst[31:25] == 7'h50; // @[src/main/scala/rv32i/Core.scala 94:90]
  wire  idFBinary = idOpcode == 7'h53 & _idFBinary_T_13; // @[src/main/scala/rv32i/Core.scala 93:48]
  wire  _idXSrc_T = idFLoad | idFStore; // @[src/main/scala/rv32i/Core.scala 95:36]
  wire  idXSrc = fdecId_io_isF & (idFLoad | idFStore | fdecId_io_intSrc); // @[src/main/scala/rv32i/Core.scala 95:24]
  wire  _wbWrites_T = ~memwb_trap; // @[src/main/scala/rv32i/Core.scala 107:33]
  wire  _wbWrites_T_1 = memwb_valid & ~memwb_trap; // @[src/main/scala/rv32i/Core.scala 107:30]
  wire  _wbWrites_T_2 = memwb_valid & ~memwb_trap & memwb_regWrite; // @[src/main/scala/rv32i/Core.scala 107:45]
  wire  wbWrites = memwb_valid & ~memwb_trap & memwb_regWrite & memwb_rd != 5'h0; // @[src/main/scala/rv32i/Core.scala 107:63]
  wire  _rs1Val_T = memwb_rd == rs1; // @[src/main/scala/rv32i/Core.scala 108:43]
  wire [31:0] rs1Val = wbWrites & memwb_rd == rs1 ? memwb_wdata : rf_io_rd1; // @[src/main/scala/rv32i/Core.scala 108:21]
  wire  _rs2Val_T = memwb_rd == rs2; // @[src/main/scala/rv32i/Core.scala 109:43]
  wire [31:0] rs2Val = wbWrites & memwb_rd == rs2 ? memwb_wdata : rf_io_rd2; // @[src/main/scala/rv32i/Core.scala 109:21]
  wire  fWbWrites = _wbWrites_T_1 & memwb_fWrite; // @[src/main/scala/rv32i/Core.scala 110:46]
  wire [31:0] frs1Val = fWbWrites & _rs1Val_T ? memwb_wdata : frf_io_rd1; // @[src/main/scala/rv32i/Core.scala 111:21]
  wire [31:0] frs2Val = fWbWrites & _rs2Val_T ? memwb_wdata : frf_io_rd2; // @[src/main/scala/rv32i/Core.scala 112:21]
  wire [31:0] frs3Val = fWbWrites & memwb_rd == rs3 ? memwb_wdata : frf_io_rd3; // @[src/main/scala/rv32i/Core.scala 113:21]
  wire  idCtrl_aluSrcImm = dec_io_aluSrcImm | idFLoad | idFStore; // @[src/main/scala/rv32i/Core.scala 117:53]
  wire  idCtrl_memRead = dec_io_memRead | idFLoad; // @[src/main/scala/rv32i/Core.scala 122:40]
  wire  idCtrl_memWrite = dec_io_memWrite | idFStore; // @[src/main/scala/rv32i/Core.scala 123:41]
  wire [1:0] idCtrl_memSize = _idXSrc_T ? 2'h2 : dec_io_memSize; // @[src/main/scala/rv32i/Core.scala 124:28]
  wire  idCtrl_regWrite = dec_io_regWrite | idMulDiv | fdecId_io_isF & fdecId_io_writesX; // @[src/main/scala/rv32i/Core.scala 127:53]
  wire  idCtrl_illegal = dec_io_illegal & ~idMulDiv & ~fdecId_io_isF; // @[src/main/scala/rv32i/Core.scala 133:53]
  wire  _idCtrl_isMul_T_1 = ~idF3[2]; // @[src/main/scala/rv32i/Core.scala 134:37]
  wire  idCtrl_isMul = idMulDiv & ~idF3[2]; // @[src/main/scala/rv32i/Core.scala 134:34]
  wire  idCtrl_isDiv = idMulDiv & idF3[2]; // @[src/main/scala/rv32i/Core.scala 135:34]
  wire  _idCtrl_usesRs1_T = ~idCtrl_illegal; // @[src/main/scala/rv32i/Core.scala 137:26]
  wire  _idCtrl_usesRs1_T_4 = idOpcode == 7'h13; // @[src/main/scala/rv32i/Core.scala 138:34]
  wire  _idCtrl_usesRs1_T_5 = dec_io_jalr | dec_io_branch | dec_io_memRead | dec_io_memWrite | _idCtrl_usesRs1_T_4; // @[src/main/scala/rv32i/Core.scala 137:112]
  wire  _idCtrl_usesRs1_T_11 = _idCtrl_usesRs1_T_5 | _idMulDiv_T | dec_io_csr & _idCtrl_isMul_T_1; // @[src/main/scala/rv32i/Core.scala 138:82]
  wire  _idCtrl_usesRs1_T_12 = ~idCtrl_illegal & _idCtrl_usesRs1_T_11; // @[src/main/scala/rv32i/Core.scala 137:42]
  wire  idCtrl_usesRs1 = _idCtrl_usesRs1_T_12 | idXSrc; // @[src/main/scala/rv32i/Core.scala 138:112]
  wire  idCtrl_usesRs2 = _idCtrl_usesRs1_T & (dec_io_branch | dec_io_memWrite | _idMulDiv_T); // @[src/main/scala/rv32i/Core.scala 139:41]
  wire  idCtrl_fWrite = fdecId_io_isF & fdecId_io_writesF; // @[src/main/scala/rv32i/Core.scala 141:31]
  wire  idCtrl_usesFrs1 = fdecId_io_isF & ~idXSrc; // @[src/main/scala/rv32i/Core.scala 142:31]
  wire  idCtrl_usesFrs2 = idFStore | idFma | idFBinary; // @[src/main/scala/rv32i/Core.scala 143:43]
  wire  _xLoadUse_T_2 = rs1 == idex_rd; // @[src/main/scala/rv32i/Core.scala 149:29]
  wire  _xLoadUse_T_4 = rs2 == idex_rd; // @[src/main/scala/rv32i/Core.scala 149:68]
  wire  _xLoadUse_T_6 = idCtrl_usesRs1 & rs1 == idex_rd | idCtrl_usesRs2 & rs2 == idex_rd; // @[src/main/scala/rv32i/Core.scala 149:42]
  wire  xLoadUse = idex_ctrl_regWrite & idex_rd != 5'h0 & _xLoadUse_T_6; // @[src/main/scala/rv32i/Core.scala 148:56]
  wire  _fLoadUse_T_7 = idCtrl_usesFrs1 & _xLoadUse_T_2 | idCtrl_usesFrs2 & _xLoadUse_T_4 | idFma & rs3 == idex_rd; // @[src/main/scala/rv32i/Core.scala 151:83]
  wire  fLoadUse = idex_ctrl_fWrite & _fLoadUse_T_7; // @[src/main/scala/rv32i/Core.scala 150:35]
  wire  loadUse = ifid_valid & idex_valid & idex_ctrl_memRead & (xLoadUse | fLoadUse); // @[src/main/scala/rv32i/Core.scala 152:63]
  wire [2:0] exF3 = idex_inst[14:12]; // @[src/main/scala/rv32i/Core.scala 161:23]
  wire  _a_fromMem_T_1 = exmem_valid & ~exmem_trap; // @[src/main/scala/rv32i/Core.scala 165:31]
  wire  _a_fromMem_T_3 = ~exmem_memRead; // @[src/main/scala/rv32i/Core.scala 165:67]
  wire  _a_fromMem_T_5 = exmem_rd == idex_rs1; // @[src/main/scala/rv32i/Core.scala 165:94]
  wire  _a_fromMem_T_7 = idex_rs1 != 5'h0; // @[src/main/scala/rv32i/Core.scala 165:109]
  wire  a_fromMem = exmem_valid & ~exmem_trap & exmem_regWrite & ~exmem_memRead & exmem_rd == idex_rs1 & idex_rs1 != 5'h0
    ; // @[src/main/scala/rv32i/Core.scala 165:102]
  wire  _a_fromWb_T_3 = memwb_rd == idex_rs1; // @[src/main/scala/rv32i/Core.scala 166:76]
  wire  a_fromWb = _wbWrites_T_2 & memwb_rd == idex_rs1 & _a_fromMem_T_7; // @[src/main/scala/rv32i/Core.scala 166:84]
  wire [31:0] _a_T = a_fromWb ? memwb_wdata : idex_rs1Val; // @[src/main/scala/rv32i/Core.scala 167:35]
  wire [31:0] a = a_fromMem ? exmem_result : _a_T; // @[src/main/scala/rv32i/Core.scala 167:8]
  wire  _b_fromMem_T_5 = exmem_rd == idex_rs2; // @[src/main/scala/rv32i/Core.scala 165:94]
  wire  _b_fromMem_T_7 = idex_rs2 != 5'h0; // @[src/main/scala/rv32i/Core.scala 165:109]
  wire  b_fromMem = exmem_valid & ~exmem_trap & exmem_regWrite & ~exmem_memRead & exmem_rd == idex_rs2 & idex_rs2 != 5'h0
    ; // @[src/main/scala/rv32i/Core.scala 165:102]
  wire  _b_fromWb_T_3 = memwb_rd == idex_rs2; // @[src/main/scala/rv32i/Core.scala 166:76]
  wire  b_fromWb = _wbWrites_T_2 & memwb_rd == idex_rs2 & _b_fromMem_T_7; // @[src/main/scala/rv32i/Core.scala 166:84]
  wire [31:0] _b_T = b_fromWb ? memwb_wdata : idex_rs2Val; // @[src/main/scala/rv32i/Core.scala 167:35]
  wire [31:0] b = b_fromMem ? exmem_result : _b_T; // @[src/main/scala/rv32i/Core.scala 167:8]
  wire  fa_fromMem = _a_fromMem_T_1 & exmem_fWrite & _a_fromMem_T_3 & _a_fromMem_T_5; // @[src/main/scala/rv32i/Core.scala 173:80]
  wire  fa_fromWb = fWbWrites & _a_fromWb_T_3; // @[src/main/scala/rv32i/Core.scala 174:62]
  wire [31:0] _fa_T = fa_fromWb ? memwb_wdata : idex_frs1Val; // @[src/main/scala/rv32i/Core.scala 175:35]
  wire [31:0] fa = fa_fromMem ? exmem_result : _fa_T; // @[src/main/scala/rv32i/Core.scala 175:8]
  wire  fb_fromMem = _a_fromMem_T_1 & exmem_fWrite & _a_fromMem_T_3 & _b_fromMem_T_5; // @[src/main/scala/rv32i/Core.scala 173:80]
  wire  fb_fromWb = fWbWrites & _b_fromWb_T_3; // @[src/main/scala/rv32i/Core.scala 174:62]
  wire [31:0] _fb_T = fb_fromWb ? memwb_wdata : idex_frs2Val; // @[src/main/scala/rv32i/Core.scala 175:35]
  wire  fc_fromMem = _a_fromMem_T_1 & exmem_fWrite & _a_fromMem_T_3 & exmem_rd == idex_rs3; // @[src/main/scala/rv32i/Core.scala 173:80]
  wire  fc_fromWb = fWbWrites & memwb_rd == idex_rs3; // @[src/main/scala/rv32i/Core.scala 174:62]
  wire [31:0] _fc_T = fc_fromWb ? memwb_wdata : idex_frs3Val; // @[src/main/scala/rv32i/Core.scala 175:35]
  wire [31:0] _GEN_0 = 2'h2 == idex_ctrl_aluSrcA ? 32'h0 : a; // @[src/main/scala/rv32i/Core.scala 183:21 182:25 186:26]
  wire [31:0] _GEN_1 = 2'h1 == idex_ctrl_aluSrcA ? idex_pc : _GEN_0; // @[src/main/scala/rv32i/Core.scala 183:21 185:26]
  wire  _div_io_req_valid_T = idex_valid & idex_ctrl_isDiv; // @[src/main/scala/rv32i/Core.scala 197:33]
  wire  divStall = _div_io_req_valid_T & ~div_io_resp_valid; // @[src/main/scala/rv32i/Core.scala 201:37]
  wire  fOk = idex_valid & idex_ctrl_isF & ~fdecEx_io_illegal; // @[src/main/scala/rv32i/Core.scala 206:33]
  wire  useFpu = fOk & fdecEx_io_useFpu; // @[src/main/scala/rv32i/Core.scala 207:20]
  wire  fpuStall = useFpu & ~fpu_io_resp_valid; // @[src/main/scala/rv32i/Core.scala 214:25]
  wire  exStall = divStall | fpuStall; // @[src/main/scala/rv32i/Core.scala 215:27]
  wire [31:0] _fXval_T = fdecEx_io_mvXW ? fa : fmisc_io_result; // @[src/main/scala/rv32i/Core.scala 220:55]
  wire [31:0] fXval = useFpu ? fpu_io_resp_bits_bits : _fXval_T; // @[src/main/scala/rv32i/Core.scala 220:20]
  wire [31:0] _fVal_T = fdecEx_io_mvWX ? a : fmisc_io_result; // @[src/main/scala/rv32i/Core.scala 221:55]
  wire [4:0] _fRaised_T = fdecEx_io_useMisc ? fmisc_io_flags : 5'h0; // @[src/main/scala/rv32i/Core.scala 222:65]
  wire [4:0] _fRaised_T_1 = useFpu ? fpu_io_resp_bits_flags : _fRaised_T; // @[src/main/scala/rv32i/Core.scala 222:29]
  wire [4:0] fRaised = fOk ? _fRaised_T_1 : 5'h0; // @[src/main/scala/rv32i/Core.scala 222:20]
  wire  eq = a == b; // @[src/main/scala/rv32i/Core.scala 225:15]
  wire [31:0] _lt_T = a_fromMem ? exmem_result : _a_T; // @[src/main/scala/rv32i/Core.scala 226:15]
  wire [31:0] _lt_T_1 = b_fromMem ? exmem_result : _b_T; // @[src/main/scala/rv32i/Core.scala 226:26]
  wire  lt = $signed(_lt_T) < $signed(_lt_T_1); // @[src/main/scala/rv32i/Core.scala 226:22]
  wire  ltu = a < b; // @[src/main/scala/rv32i/Core.scala 227:15]
  wire  _GEN_3 = 3'h7 == exF3 & ~ltu; // @[src/main/scala/rv32i/Core.scala 229:16 228:27 235:27]
  wire  _GEN_4 = 3'h6 == exF3 ? ltu : _GEN_3; // @[src/main/scala/rv32i/Core.scala 229:16 234:27]
  wire  _GEN_5 = 3'h5 == exF3 ? ~lt : _GEN_4; // @[src/main/scala/rv32i/Core.scala 229:16 233:27]
  wire  _GEN_6 = 3'h4 == exF3 ? lt : _GEN_5; // @[src/main/scala/rv32i/Core.scala 229:16 232:27]
  wire  _GEN_7 = 3'h1 == exF3 ? ~eq : _GEN_6; // @[src/main/scala/rv32i/Core.scala 229:16 231:27]
  wire  brCond = 3'h0 == exF3 ? eq : _GEN_7; // @[src/main/scala/rv32i/Core.scala 229:16 230:27]
  wire [31:0] pcPlus4 = idex_pc + 32'h4; // @[src/main/scala/rv32i/Core.scala 237:25]
  wire [31:0] brTarget = idex_pc + idex_imm; // @[src/main/scala/rv32i/Core.scala 238:25]
  wire [31:0] jalrTarget = {alu_io_y[31:1],1'h0}; // @[src/main/scala/rv32i/Core.scala 239:23]
  wire  ctlTaken = idex_ctrl_branch & brCond | idex_ctrl_jal | idex_ctrl_jalr; // @[src/main/scala/rv32i/Core.scala 240:50]
  wire [31:0] ctlTarget = idex_ctrl_jalr ? jalrTarget : brTarget; // @[src/main/scala/rv32i/Core.scala 241:23]
  wire  misalignedAccess = idex_ctrl_memSize == 2'h2 & alu_io_y[1:0] != 2'h0 | idex_ctrl_memSize == 2'h1 & alu_io_y[0]; // @[src/main/scala/rv32i/Core.scala 244:68]
  wire  loadMis = idex_ctrl_memRead & misalignedAccess; // @[src/main/scala/rv32i/Core.scala 245:28]
  wire  storeMis = idex_ctrl_memWrite & misalignedAccess; // @[src/main/scala/rv32i/Core.scala 246:29]
  wire  fetchMis = ctlTaken & ctlTarget[1]; // @[src/main/scala/rv32i/Core.scala 247:27]
  wire [4:0] rs1Field = idex_inst[19:15]; // @[src/main/scala/rv32i/Core.scala 250:24]
  wire [31:0] _csr_io_src_T_1 = {27'h0,rs1Field}; // @[src/main/scala/rv32i/Core.scala 254:34]
  wire  illegal = idex_ctrl_illegal | idex_ctrl_isF & fdecEx_io_illegal | csr_io_illegal; // @[src/main/scala/rv32i/Core.scala 258:59]
  wire  trapNow = idex_valid & (illegal | idex_ctrl_ecall | idex_ctrl_ebreak | loadMis | storeMis | fetchMis); // @[src/main/scala/rv32i/Core.scala 259:25]
  wire [3:0] _cause_T = storeMis ? 4'h6 : 4'h0; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [3:0] _cause_T_1 = loadMis ? 4'h4 : _cause_T; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [3:0] _cause_T_2 = idex_ctrl_ebreak ? 4'h3 : _cause_T_1; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [3:0] _cause_T_3 = idex_ctrl_ecall ? 4'hb : _cause_T_2; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [3:0] cause = illegal ? 4'h2 : _cause_T_3; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire  _tval_T = loadMis | storeMis; // @[src/main/scala/rv32i/Core.scala 275:14]
  wire [31:0] _tval_T_1 = _tval_T ? alu_io_y : ctlTarget; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [31:0] _tval_T_2 = idex_ctrl_ebreak ? idex_pc : _tval_T_1; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire [31:0] _tval_T_3 = idex_ctrl_ecall ? 32'h0 : _tval_T_2; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  wire  _exCommit_T = ~trapNow; // @[src/main/scala/rv32i/Core.scala 280:29]
  wire  _exCommit_T_2 = ~exStall; // @[src/main/scala/rv32i/Core.scala 280:41]
  wire  exCommit = idex_valid & ~trapNow & ~exStall; // @[src/main/scala/rv32i/Core.scala 280:38]
  wire [31:0] _nextPc_T = ctlTaken ? ctlTarget : pcPlus4; // @[src/main/scala/rv32i/Core.scala 291:19]
  wire [31:0] _nextPc_T_1 = idex_ctrl_mret ? csr_io_mepc : _nextPc_T; // @[src/main/scala/rv32i/Core.scala 290:19]
  wire  _redirect_T_1 = idex_valid & _exCommit_T_2; // @[src/main/scala/rv32i/Core.scala 292:26]
  wire  redirect = idex_valid & _exCommit_T_2 & (trapNow | idex_ctrl_mret | ctlTaken); // @[src/main/scala/rv32i/Core.scala 292:38]
  wire [31:0] _GEN_9 = alu_io_y; // @[src/main/scala/rv32i/Core.scala 295:19 294:29 299:30]
  wire [31:0] _GEN_10 = 2'h3 == idex_ctrl_wbSel ? csr_io_rdata : _GEN_9; // @[src/main/scala/rv32i/Core.scala 295:19 298:30]
  wire [31:0] _GEN_11 = 2'h2 == idex_ctrl_wbSel ? pcPlus4 : _GEN_10; // @[src/main/scala/rv32i/Core.scala 295:19 297:30]
  wire [31:0] _GEN_12 = 2'h0 == idex_ctrl_wbSel ? alu_io_y : _GEN_11; // @[src/main/scala/rv32i/Core.scala 295:19 296:30]
  wire [31:0] _GEN_13 = idex_ctrl_isMul ? mul_io_result : _GEN_12; // @[src/main/scala/rv32i/Core.scala 301:{17,28}]
  wire [31:0] _GEN_14 = idex_ctrl_isDiv ? div_io_resp_bits : _GEN_13; // @[src/main/scala/rv32i/Core.scala 302:{17,28}]
  wire [31:0] _fetchPc_T_1 = fetchPc + 32'h4; // @[src/main/scala/rv32i/Core.scala 318:28]
  wire [1:0] idCtrl_aluSrcA = dec_io_aluSrcA; // @[src/main/scala/rv32i/Core.scala 115:20 116:22]
  wire [3:0] idCtrl_aluOp = dec_io_aluOp; // @[src/main/scala/rv32i/Core.scala 115:20 118:22]
  wire  idCtrl_branch = dec_io_branch; // @[src/main/scala/rv32i/Core.scala 115:20 119:22]
  wire  idCtrl_jal = dec_io_jal; // @[src/main/scala/rv32i/Core.scala 115:20 120:22]
  wire  idCtrl_jalr = dec_io_jalr; // @[src/main/scala/rv32i/Core.scala 115:20 121:22]
  wire  idCtrl_memUnsigned = dec_io_memUnsigned; // @[src/main/scala/rv32i/Core.scala 115:20 125:22]
  wire [1:0] idCtrl_wbSel = dec_io_wbSel; // @[src/main/scala/rv32i/Core.scala 115:20 126:22]
  wire  idCtrl_csr = dec_io_csr; // @[src/main/scala/rv32i/Core.scala 115:20 128:22]
  wire  idCtrl_ecall = dec_io_ecall; // @[src/main/scala/rv32i/Core.scala 115:20 129:22]
  wire  idCtrl_ebreak = dec_io_ebreak; // @[src/main/scala/rv32i/Core.scala 115:20 130:22]
  wire  idCtrl_mret = dec_io_mret; // @[src/main/scala/rv32i/Core.scala 115:20 131:22]
  wire  idCtrl_isF = fdecId_io_isF; // @[src/main/scala/rv32i/Core.scala 115:20 140:22]
  wire [7:0] sbyte = exmem_storeData[7:0]; // @[src/main/scala/rv32i/Core.scala 368:30]
  wire [15:0] shalf = exmem_storeData[15:0]; // @[src/main/scala/rv32i/Core.scala 369:30]
  wire  _T_32 = 2'h0 == exmem_memSize; // @[src/main/scala/rv32i/Core.scala 372:16]
  wire [31:0] _wdata_T_1 = {sbyte,sbyte,sbyte,sbyte}; // @[src/main/scala/rv32i/Core.scala 373:28]
  wire [6:0] _wstrb_T_1 = 7'h1 << exmem_addr[1:0]; // @[src/main/scala/rv32i/Core.scala 373:59]
  wire  _T_33 = 2'h1 == exmem_memSize; // @[src/main/scala/rv32i/Core.scala 372:16]
  wire [31:0] _wdata_T_2 = {shalf,shalf}; // @[src/main/scala/rv32i/Core.scala 374:28]
  wire [3:0] _wstrb_T_4 = exmem_addr[1] ? 4'hc : 4'h3; // @[src/main/scala/rv32i/Core.scala 374:52]
  wire [31:0] _GEN_162 = 2'h1 == exmem_memSize ? _wdata_T_2 : exmem_storeData; // @[src/main/scala/rv32i/Core.scala 372:16 374:21 370:26]
  wire [3:0] _GEN_163 = 2'h1 == exmem_memSize ? _wstrb_T_4 : 4'hf; // @[src/main/scala/rv32i/Core.scala 372:16 371:26 374:46]
  wire [3:0] wstrb = 2'h0 == exmem_memSize ? _wstrb_T_1[3:0] : _GEN_163; // @[src/main/scala/rv32i/Core.scala 372:16 373:46]
  wire [7:0] bytes_0 = io_dmem_rdata[7:0]; // @[src/main/scala/rv32i/Core.scala 380:49]
  wire [7:0] bytes_1 = io_dmem_rdata[15:8]; // @[src/main/scala/rv32i/Core.scala 380:49]
  wire [7:0] bytes_2 = io_dmem_rdata[23:16]; // @[src/main/scala/rv32i/Core.scala 380:49]
  wire [7:0] bytes_3 = io_dmem_rdata[31:24]; // @[src/main/scala/rv32i/Core.scala 380:49]
  wire [15:0] lh = exmem_addr[1] ? io_dmem_rdata[31:16] : io_dmem_rdata[15:0]; // @[src/main/scala/rv32i/Core.scala 382:18]
  wire [7:0] _GEN_167 = 2'h1 == exmem_addr[1:0] ? bytes_1 : bytes_0; // @[src/main/scala/rv32i/Core.scala 386:{39,39}]
  wire [7:0] _GEN_168 = 2'h2 == exmem_addr[1:0] ? bytes_2 : _GEN_167; // @[src/main/scala/rv32i/Core.scala 386:{39,39}]
  wire [7:0] _GEN_169 = 2'h3 == exmem_addr[1:0] ? bytes_3 : _GEN_168; // @[src/main/scala/rv32i/Core.scala 386:{39,39}]
  wire [31:0] _loadData_T = {24'h0,_GEN_169}; // @[src/main/scala/rv32i/Core.scala 386:39]
  wire [23:0] _loadData_T_2 = _GEN_169[7] ? 24'hffffff : 24'h0; // @[src/main/scala/rv32i/Core.scala 386:64]
  wire [31:0] _loadData_T_3 = {_loadData_T_2,_GEN_169}; // @[src/main/scala/rv32i/Core.scala 386:59]
  wire [31:0] _loadData_T_5 = {16'h0,lh}; // @[src/main/scala/rv32i/Core.scala 387:39]
  wire [15:0] _loadData_T_7 = lh[15] ? 16'hffff : 16'h0; // @[src/main/scala/rv32i/Core.scala 387:64]
  wire [31:0] _loadData_T_8 = {_loadData_T_7,lh}; // @[src/main/scala/rv32i/Core.scala 387:59]
  wire [31:0] _loadData_T_9 = exmem_memUnsigned ? _loadData_T_5 : _loadData_T_8; // @[src/main/scala/rv32i/Core.scala 387:30]
  wire [31:0] _memwb_memWdata_T_1 = {24'h0,sbyte}; // @[src/main/scala/rv32i/Core.scala 405:42]
  wire [31:0] _memwb_memWdata_T_3 = {16'h0,shalf}; // @[src/main/scala/rv32i/Core.scala 405:83]
  wire  _T_38 = ~reset; // @[src/main/scala/rv32i/Core.scala 438:9]
  wire  _T_53 = idex_valid & exmem_valid & exmem_memRead; // @[src/main/scala/rv32i/Core.scala 442:35]
  wire  _T_57 = idex_rs1 == exmem_rd; // @[src/main/scala/rv32i/Core.scala 443:29]
  wire  _T_59 = idex_rs2 == exmem_rd; // @[src/main/scala/rv32i/Core.scala 443:69]
  wire  _T_61 = idex_ctrl_usesRs1 & idex_rs1 == exmem_rd | idex_ctrl_usesRs2 & idex_rs2 == exmem_rd; // @[src/main/scala/rv32i/Core.scala 443:43]
  wire  _T_76 = idex_ctrl_usesFrs1 & _T_57 | idex_ctrl_usesFrs2 & _T_59 | idex_ctrl_usesFrs3 & idex_rs3 == exmem_rd; // @[src/main/scala/rv32i/Core.scala 446:85]
  Decoder dec ( // @[src/main/scala/rv32i/Core.scala 48:20]
    .io_inst(dec_io_inst),
    .io_immSel(dec_io_immSel),
    .io_aluSrcA(dec_io_aluSrcA),
    .io_aluSrcImm(dec_io_aluSrcImm),
    .io_aluOp(dec_io_aluOp),
    .io_branch(dec_io_branch),
    .io_jal(dec_io_jal),
    .io_jalr(dec_io_jalr),
    .io_memRead(dec_io_memRead),
    .io_memWrite(dec_io_memWrite),
    .io_memSize(dec_io_memSize),
    .io_memUnsigned(dec_io_memUnsigned),
    .io_wbSel(dec_io_wbSel),
    .io_regWrite(dec_io_regWrite),
    .io_csr(dec_io_csr),
    .io_ecall(dec_io_ecall),
    .io_ebreak(dec_io_ebreak),
    .io_mret(dec_io_mret),
    .io_illegal(dec_io_illegal)
  );
  ImmGen immg ( // @[src/main/scala/rv32i/Core.scala 49:20]
    .io_inst(immg_io_inst),
    .io_sel(immg_io_sel),
    .io_imm(immg_io_imm)
  );
  RegFile rf ( // @[src/main/scala/rv32i/Core.scala 50:20]
    .clock(rf_clock),
    .reset(rf_reset),
    .io_rs1(rf_io_rs1),
    .io_rs2(rf_io_rs2),
    .io_rd1(rf_io_rd1),
    .io_rd2(rf_io_rd2),
    .io_we(rf_io_we),
    .io_waddr(rf_io_waddr),
    .io_wdata(rf_io_wdata)
  );
  Alu alu ( // @[src/main/scala/rv32i/Core.scala 51:20]
    .io_op(alu_io_op),
    .io_a(alu_io_a),
    .io_b(alu_io_b),
    .io_y(alu_io_y)
  );
  CsrFile csr ( // @[src/main/scala/rv32i/Core.scala 52:20]
    .clock(csr_clock),
    .reset(csr_reset),
    .io_addr(csr_io_addr),
    .io_en(csr_io_en),
    .io_op(csr_io_op),
    .io_src(csr_io_src),
    .io_wrEn(csr_io_wrEn),
    .io_rdata(csr_io_rdata),
    .io_illegal(csr_io_illegal),
    .io_commit(csr_io_commit),
    .io_trapEnter(csr_io_trapEnter),
    .io_trapCause(csr_io_trapCause),
    .io_trapPc(csr_io_trapPc),
    .io_trapVal(csr_io_trapVal),
    .io_mretEnter(csr_io_mretEnter),
    .io_mtvecBase(csr_io_mtvecBase),
    .io_mepc(csr_io_mepc),
    .io_fflagsSet(csr_io_fflagsSet),
    .io_frm(csr_io_frm)
  );
  Multiplier mul ( // @[src/main/scala/rv32i/Core.scala 53:20]
    .io_fn(mul_io_fn),
    .io_a(mul_io_a),
    .io_b(mul_io_b),
    .io_result(mul_io_result)
  );
  DivUnit div ( // @[src/main/scala/rv32i/Core.scala 54:20]
    .clock(div_clock),
    .reset(div_reset),
    .io_req_ready(div_io_req_ready),
    .io_req_valid(div_io_req_valid),
    .io_req_bits_op(div_io_req_bits_op),
    .io_req_bits_a(div_io_req_bits_a),
    .io_req_bits_b(div_io_req_bits_b),
    .io_resp_valid(div_io_resp_valid),
    .io_resp_bits(div_io_resp_bits),
    .io_kill(div_io_kill),
    .io_busy(div_io_busy)
  );
  FDecoder fdecId ( // @[src/main/scala/rv32i/Core.scala 55:22]
    .io_inst(fdecId_io_inst),
    .io_frm(fdecId_io_frm),
    .io_isF(fdecId_io_isF),
    .io_illegal(fdecId_io_illegal),
    .io_rm(fdecId_io_rm),
    .io_useFpu(fdecId_io_useFpu),
    .io_fpuOp(fdecId_io_fpuOp),
    .io_useMisc(fdecId_io_useMisc),
    .io_miscOp(fdecId_io_miscOp),
    .io_mvXW(fdecId_io_mvXW),
    .io_mvWX(fdecId_io_mvWX),
    .io_intSrc(fdecId_io_intSrc),
    .io_writesX(fdecId_io_writesX),
    .io_writesF(fdecId_io_writesF)
  );
  FDecoder fdecEx ( // @[src/main/scala/rv32i/Core.scala 56:22]
    .io_inst(fdecEx_io_inst),
    .io_frm(fdecEx_io_frm),
    .io_isF(fdecEx_io_isF),
    .io_illegal(fdecEx_io_illegal),
    .io_rm(fdecEx_io_rm),
    .io_useFpu(fdecEx_io_useFpu),
    .io_fpuOp(fdecEx_io_fpuOp),
    .io_useMisc(fdecEx_io_useMisc),
    .io_miscOp(fdecEx_io_miscOp),
    .io_mvXW(fdecEx_io_mvXW),
    .io_mvWX(fdecEx_io_mvWX),
    .io_intSrc(fdecEx_io_intSrc),
    .io_writesX(fdecEx_io_writesX),
    .io_writesF(fdecEx_io_writesF)
  );
  FRegFile frf ( // @[src/main/scala/rv32i/Core.scala 57:22]
    .clock(frf_clock),
    .reset(frf_reset),
    .io_rs1(frf_io_rs1),
    .io_rs2(frf_io_rs2),
    .io_rs3(frf_io_rs3),
    .io_rd1(frf_io_rd1),
    .io_rd2(frf_io_rd2),
    .io_rd3(frf_io_rd3),
    .io_we(frf_io_we),
    .io_waddr(frf_io_waddr),
    .io_wdata(frf_io_wdata)
  );
  Fpu fpu ( // @[src/main/scala/rv32i/Core.scala 58:22]
    .clock(fpu_clock),
    .reset(fpu_reset),
    .io_req_ready(fpu_io_req_ready),
    .io_req_valid(fpu_io_req_valid),
    .io_req_bits_op(fpu_io_req_bits_op),
    .io_req_bits_rm(fpu_io_req_bits_rm),
    .io_req_bits_a(fpu_io_req_bits_a),
    .io_req_bits_b(fpu_io_req_bits_b),
    .io_req_bits_c(fpu_io_req_bits_c),
    .io_resp_valid(fpu_io_resp_valid),
    .io_resp_bits_bits(fpu_io_resp_bits_bits),
    .io_resp_bits_flags(fpu_io_resp_bits_flags),
    .io_kill(fpu_io_kill),
    .io_busy(fpu_io_busy)
  );
  FpMisc fmisc ( // @[src/main/scala/rv32i/Core.scala 59:22]
    .io_op(fmisc_io_op),
    .io_funct3(fmisc_io_funct3),
    .io_a(fmisc_io_a),
    .io_b(fmisc_io_b),
    .io_result(fmisc_io_result),
    .io_flags(fmisc_io_flags)
  );
  assign io_imem_addr = fetchPc; // @[src/main/scala/rv32i/Core.scala 71:16]
  assign io_dmem_addr = exmem_addr; // @[src/main/scala/rv32i/Core.scala 364:16]
  assign io_dmem_re = exmem_valid & exmem_memRead; // @[src/main/scala/rv32i/Core.scala 365:31]
  assign io_dmem_we = exmem_valid & exmem_memWrite; // @[src/main/scala/rv32i/Core.scala 366:31]
  assign io_dmem_wdata = 2'h0 == exmem_memSize ? _wdata_T_1 : _GEN_162; // @[src/main/scala/rv32i/Core.scala 372:16 373:21]
  assign io_dmem_wstrb = io_dmem_we ? wstrb : 4'h0; // @[src/main/scala/rv32i/Core.scala 377:23]
  assign io_trace_valid = memwb_valid & _wbWrites_T; // @[src/main/scala/rv32i/Core.scala 417:36]
  assign io_trace_trap = memwb_valid & memwb_trap; // @[src/main/scala/rv32i/Core.scala 418:36]
  assign io_trace_cause = memwb_cause; // @[src/main/scala/rv32i/Core.scala 419:21]
  assign io_trace_pc = memwb_pc; // @[src/main/scala/rv32i/Core.scala 420:21]
  assign io_trace_pcNext = memwb_pcNext; // @[src/main/scala/rv32i/Core.scala 421:21]
  assign io_trace_inst = memwb_inst; // @[src/main/scala/rv32i/Core.scala 422:21]
  assign io_trace_rdAddr = wbWrites ? memwb_rd : 5'h0; // @[src/main/scala/rv32i/Core.scala 423:27]
  assign io_trace_rdData = wbWrites ? memwb_wdata : 32'h0; // @[src/main/scala/rv32i/Core.scala 424:27]
  assign io_trace_memAddr = memwb_memAddr; // @[src/main/scala/rv32i/Core.scala 425:21]
  assign io_trace_memRe = memwb_valid & memwb_memRe; // @[src/main/scala/rv32i/Core.scala 426:36]
  assign io_trace_memWe = memwb_valid & memwb_memWe; // @[src/main/scala/rv32i/Core.scala 427:36]
  assign io_trace_memSize = memwb_memSize; // @[src/main/scala/rv32i/Core.scala 428:21]
  assign io_trace_memWdata = memwb_memWdata; // @[src/main/scala/rv32i/Core.scala 429:21]
  assign io_trace_fdWe = _wbWrites_T_1 & memwb_fWrite; // @[src/main/scala/rv32i/Core.scala 110:46]
  assign io_trace_fdAddr = fWbWrites ? memwb_rd : 5'h0; // @[src/main/scala/rv32i/Core.scala 431:27]
  assign io_trace_fdData = fWbWrites ? memwb_wdata : 32'h0; // @[src/main/scala/rv32i/Core.scala 432:27]
  assign io_trace_fflags = _wbWrites_T_1 ? memwb_fflags : 5'h0; // @[src/main/scala/rv32i/Core.scala 433:27]
  assign dec_io_inst = ifid_valid ? ifid_inst : 32'h13; // @[src/main/scala/rv32i/Core.scala 76:21]
  assign immg_io_inst = ifid_valid ? ifid_inst : 32'h13; // @[src/main/scala/rv32i/Core.scala 76:21]
  assign immg_io_sel = idFStore ? 3'h1 : dec_io_immSel; // @[src/main/scala/rv32i/Core.scala 99:22]
  assign rf_clock = clock;
  assign rf_reset = reset;
  assign rf_io_rs1 = idInst[19:15]; // @[src/main/scala/rv32i/Core.scala 80:24]
  assign rf_io_rs2 = idInst[24:20]; // @[src/main/scala/rv32i/Core.scala 81:24]
  assign rf_io_we = _wbWrites_T_1 & memwb_regWrite; // @[src/main/scala/rv32i/Core.scala 410:45]
  assign rf_io_waddr = memwb_rd; // @[src/main/scala/rv32i/Core.scala 411:15]
  assign rf_io_wdata = memwb_wdata; // @[src/main/scala/rv32i/Core.scala 412:15]
  assign alu_io_op = idex_ctrl_aluOp; // @[src/main/scala/rv32i/Core.scala 188:13]
  assign alu_io_a = 2'h0 == idex_ctrl_aluSrcA ? a : _GEN_1; // @[src/main/scala/rv32i/Core.scala 183:21 184:26]
  assign alu_io_b = idex_ctrl_aluSrcImm ? idex_imm : b; // @[src/main/scala/rv32i/Core.scala 190:19]
  assign csr_clock = clock;
  assign csr_reset = reset;
  assign csr_io_addr = idex_inst[31:20]; // @[src/main/scala/rv32i/Core.scala 251:24]
  assign csr_io_en = idex_valid & idex_ctrl_csr; // @[src/main/scala/rv32i/Core.scala 252:26]
  assign csr_io_op = exF3[1:0]; // @[src/main/scala/rv32i/Core.scala 253:22]
  assign csr_io_src = exF3[2] ? _csr_io_src_T_1 : a; // @[src/main/scala/rv32i/Core.scala 254:21]
  assign csr_io_wrEn = exF3[1:0] == 2'h1 | rs1Field != 5'h0; // @[src/main/scala/rv32i/Core.scala 255:37]
  assign csr_io_commit = idex_valid & ~trapNow & ~exStall; // @[src/main/scala/rv32i/Core.scala 280:38]
  assign csr_io_trapEnter = idex_valid & (illegal | idex_ctrl_ecall | idex_ctrl_ebreak | loadMis | storeMis | fetchMis); // @[src/main/scala/rv32i/Core.scala 259:25]
  assign csr_io_trapCause = {28'h0,cause}; // @[src/main/scala/rv32i/Core.scala 284:26]
  assign csr_io_trapPc = idex_pc; // @[src/main/scala/rv32i/Core.scala 285:20]
  assign csr_io_trapVal = illegal ? idex_inst : _tval_T_3; // @[src/main/scala/chisel3/util/Mux.scala 50:70]
  assign csr_io_mretEnter = idex_valid & idex_ctrl_mret & _exCommit_T; // @[src/main/scala/rv32i/Core.scala 287:41]
  assign csr_io_fflagsSet = exCommit ? fRaised : 5'h0; // @[src/main/scala/rv32i/Core.scala 282:26]
  assign mul_io_fn = exF3[1:0]; // @[src/main/scala/rv32i/Core.scala 194:20]
  assign mul_io_a = a_fromMem ? exmem_result : _a_T; // @[src/main/scala/rv32i/Core.scala 167:8]
  assign mul_io_b = b_fromMem ? exmem_result : _b_T; // @[src/main/scala/rv32i/Core.scala 167:8]
  assign div_clock = clock;
  assign div_reset = reset;
  assign div_io_req_valid = idex_valid & idex_ctrl_isDiv & ~div_io_busy; // @[src/main/scala/rv32i/Core.scala 197:44]
  assign div_io_req_bits_op = exF3[1:0]; // @[src/main/scala/rv32i/Core.scala 198:29]
  assign div_io_req_bits_a = a_fromMem ? exmem_result : _a_T; // @[src/main/scala/rv32i/Core.scala 167:8]
  assign div_io_req_bits_b = b_fromMem ? exmem_result : _b_T; // @[src/main/scala/rv32i/Core.scala 167:8]
  assign div_io_kill = idex_valid & (illegal | idex_ctrl_ecall | idex_ctrl_ebreak | loadMis | storeMis | fetchMis); // @[src/main/scala/rv32i/Core.scala 259:25]
  assign fdecId_io_inst = ifid_valid ? ifid_inst : 32'h13; // @[src/main/scala/rv32i/Core.scala 76:21]
  assign fdecId_io_frm = 3'h0; // @[src/main/scala/rv32i/Core.scala 86:18]
  assign fdecEx_io_inst = idex_inst; // @[src/main/scala/rv32i/Core.scala 204:18]
  assign fdecEx_io_frm = csr_io_frm; // @[src/main/scala/rv32i/Core.scala 205:18]
  assign frf_clock = clock;
  assign frf_reset = reset;
  assign frf_io_rs1 = idInst[19:15]; // @[src/main/scala/rv32i/Core.scala 80:24]
  assign frf_io_rs2 = idInst[24:20]; // @[src/main/scala/rv32i/Core.scala 81:24]
  assign frf_io_rs3 = idInst[31:27]; // @[src/main/scala/rv32i/Core.scala 82:24]
  assign frf_io_we = _wbWrites_T_1 & memwb_fWrite; // @[src/main/scala/rv32i/Core.scala 110:46]
  assign frf_io_waddr = memwb_rd; // @[src/main/scala/rv32i/Core.scala 414:16]
  assign frf_io_wdata = memwb_wdata; // @[src/main/scala/rv32i/Core.scala 415:16]
  assign fpu_clock = clock;
  assign fpu_reset = reset;
  assign fpu_io_req_valid = useFpu & ~fpu_io_busy; // @[src/main/scala/rv32i/Core.scala 208:32]
  assign fpu_io_req_bits_op = fdecEx_io_fpuOp; // @[src/main/scala/rv32i/Core.scala 209:22]
  assign fpu_io_req_bits_rm = fdecEx_io_rm; // @[src/main/scala/rv32i/Core.scala 210:22]
  assign fpu_io_req_bits_a = fdecEx_io_intSrc ? a : fa; // @[src/main/scala/rv32i/Core.scala 211:28]
  assign fpu_io_req_bits_b = fb_fromMem ? exmem_result : _fb_T; // @[src/main/scala/rv32i/Core.scala 175:8]
  assign fpu_io_req_bits_c = fc_fromMem ? exmem_result : _fc_T; // @[src/main/scala/rv32i/Core.scala 175:8]
  assign fpu_io_kill = idex_valid & (illegal | idex_ctrl_ecall | idex_ctrl_ebreak | loadMis | storeMis | fetchMis); // @[src/main/scala/rv32i/Core.scala 259:25]
  assign fmisc_io_op = fdecEx_io_miscOp; // @[src/main/scala/rv32i/Core.scala 216:19]
  assign fmisc_io_funct3 = idex_inst[14:12]; // @[src/main/scala/rv32i/Core.scala 161:23]
  assign fmisc_io_a = fa_fromMem ? exmem_result : _fa_T; // @[src/main/scala/rv32i/Core.scala 175:8]
  assign fmisc_io_b = fb_fromMem ? exmem_result : _fb_T; // @[src/main/scala/rv32i/Core.scala 175:8]
  always @(posedge clock) begin
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 62:22]
      ifid_valid <= 1'h0; // @[src/main/scala/rv32i/Core.scala 62:22]
    end else if (!(exStall)) begin // @[src/main/scala/rv32i/Core.scala 309:17]
      if (redirect) begin // @[src/main/scala/rv32i/Core.scala 311:24]
        ifid_valid <= 1'h0; // @[src/main/scala/rv32i/Core.scala 313:16]
      end else if (!(loadUse)) begin // @[src/main/scala/rv32i/Core.scala 315:23]
        ifid_valid <= 1'h1; // @[src/main/scala/rv32i/Core.scala 319:17]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 62:22]
      ifid_pc <= 32'h0; // @[src/main/scala/rv32i/Core.scala 62:22]
    end else if (!(exStall)) begin // @[src/main/scala/rv32i/Core.scala 309:17]
      if (!(redirect)) begin // @[src/main/scala/rv32i/Core.scala 311:24]
        if (!(loadUse)) begin // @[src/main/scala/rv32i/Core.scala 315:23]
          ifid_pc <= fetchPc; // @[src/main/scala/rv32i/Core.scala 320:17]
        end
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 62:22]
      ifid_inst <= 32'h0; // @[src/main/scala/rv32i/Core.scala 62:22]
    end else if (!(exStall)) begin // @[src/main/scala/rv32i/Core.scala 309:17]
      if (!(redirect)) begin // @[src/main/scala/rv32i/Core.scala 311:24]
        if (!(loadUse)) begin // @[src/main/scala/rv32i/Core.scala 315:23]
          ifid_inst <= io_imem_data; // @[src/main/scala/rv32i/Core.scala 321:17]
        end
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 63:22]
      idex_valid <= 1'h0; // @[src/main/scala/rv32i/Core.scala 63:22]
    end else if (!(exStall)) begin // @[src/main/scala/rv32i/Core.scala 309:17]
      if (redirect) begin // @[src/main/scala/rv32i/Core.scala 311:24]
        idex_valid <= 1'h0; // @[src/main/scala/rv32i/Core.scala 314:16]
      end else if (loadUse) begin // @[src/main/scala/rv32i/Core.scala 315:23]
        idex_valid <= 1'h0; // @[src/main/scala/rv32i/Core.scala 316:16]
      end else begin
        idex_valid <= ifid_valid; // @[src/main/scala/rv32i/Core.scala 322:17]
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 63:22]
      idex_pc <= 32'h0; // @[src/main/scala/rv32i/Core.scala 63:22]
    end else if (!(exStall)) begin // @[src/main/scala/rv32i/Core.scala 309:17]
      if (!(redirect)) begin // @[src/main/scala/rv32i/Core.scala 311:24]
        if (!(loadUse)) begin // @[src/main/scala/rv32i/Core.scala 315:23]
          idex_pc <= ifid_pc; // @[src/main/scala/rv32i/Core.scala 323:17]
        end
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 63:22]
      idex_inst <= 32'h0; // @[src/main/scala/rv32i/Core.scala 63:22]
    end else if (!(exStall)) begin // @[src/main/scala/rv32i/Core.scala 309:17]
      if (!(redirect)) begin // @[src/main/scala/rv32i/Core.scala 311:24]
        if (!(loadUse)) begin // @[src/main/scala/rv32i/Core.scala 315:23]
          idex_inst <= idInst; // @[src/main/scala/rv32i/Core.scala 324:17]
        end
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 63:22]
      idex_rs1 <= 5'h0; // @[src/main/scala/rv32i/Core.scala 63:22]
    end else if (!(exStall)) begin // @[src/main/scala/rv32i/Core.scala 309:17]
      if (!(redirect)) begin // @[src/main/scala/rv32i/Core.scala 311:24]
        if (!(loadUse)) begin // @[src/main/scala/rv32i/Core.scala 315:23]
          idex_rs1 <= rs1; // @[src/main/scala/rv32i/Core.scala 325:17]
        end
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 63:22]
      idex_rs2 <= 5'h0; // @[src/main/scala/rv32i/Core.scala 63:22]
    end else if (!(exStall)) begin // @[src/main/scala/rv32i/Core.scala 309:17]
      if (!(redirect)) begin // @[src/main/scala/rv32i/Core.scala 311:24]
        if (!(loadUse)) begin // @[src/main/scala/rv32i/Core.scala 315:23]
          idex_rs2 <= rs2; // @[src/main/scala/rv32i/Core.scala 326:17]
        end
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 63:22]
      idex_rs3 <= 5'h0; // @[src/main/scala/rv32i/Core.scala 63:22]
    end else if (!(exStall)) begin // @[src/main/scala/rv32i/Core.scala 309:17]
      if (!(redirect)) begin // @[src/main/scala/rv32i/Core.scala 311:24]
        if (!(loadUse)) begin // @[src/main/scala/rv32i/Core.scala 315:23]
          idex_rs3 <= rs3; // @[src/main/scala/rv32i/Core.scala 327:17]
        end
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 63:22]
      idex_rd <= 5'h0; // @[src/main/scala/rv32i/Core.scala 63:22]
    end else if (!(exStall)) begin // @[src/main/scala/rv32i/Core.scala 309:17]
      if (!(redirect)) begin // @[src/main/scala/rv32i/Core.scala 311:24]
        if (!(loadUse)) begin // @[src/main/scala/rv32i/Core.scala 315:23]
          idex_rd <= idInst[11:7]; // @[src/main/scala/rv32i/Core.scala 331:17]
        end
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 63:22]
      idex_rs1Val <= 32'h0; // @[src/main/scala/rv32i/Core.scala 63:22]
    end else if (!(exStall)) begin // @[src/main/scala/rv32i/Core.scala 309:17]
      if (!(redirect)) begin // @[src/main/scala/rv32i/Core.scala 311:24]
        if (!(loadUse)) begin // @[src/main/scala/rv32i/Core.scala 315:23]
          idex_rs1Val <= rs1Val; // @[src/main/scala/rv32i/Core.scala 332:17]
        end
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 63:22]
      idex_rs2Val <= 32'h0; // @[src/main/scala/rv32i/Core.scala 63:22]
    end else if (!(exStall)) begin // @[src/main/scala/rv32i/Core.scala 309:17]
      if (!(redirect)) begin // @[src/main/scala/rv32i/Core.scala 311:24]
        if (!(loadUse)) begin // @[src/main/scala/rv32i/Core.scala 315:23]
          idex_rs2Val <= rs2Val; // @[src/main/scala/rv32i/Core.scala 333:17]
        end
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 63:22]
      idex_frs1Val <= 32'h0; // @[src/main/scala/rv32i/Core.scala 63:22]
    end else if (!(exStall)) begin // @[src/main/scala/rv32i/Core.scala 309:17]
      if (!(redirect)) begin // @[src/main/scala/rv32i/Core.scala 311:24]
        if (!(loadUse)) begin // @[src/main/scala/rv32i/Core.scala 315:23]
          idex_frs1Val <= frs1Val; // @[src/main/scala/rv32i/Core.scala 328:18]
        end
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 63:22]
      idex_frs2Val <= 32'h0; // @[src/main/scala/rv32i/Core.scala 63:22]
    end else if (!(exStall)) begin // @[src/main/scala/rv32i/Core.scala 309:17]
      if (!(redirect)) begin // @[src/main/scala/rv32i/Core.scala 311:24]
        if (!(loadUse)) begin // @[src/main/scala/rv32i/Core.scala 315:23]
          idex_frs2Val <= frs2Val; // @[src/main/scala/rv32i/Core.scala 329:18]
        end
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 63:22]
      idex_frs3Val <= 32'h0; // @[src/main/scala/rv32i/Core.scala 63:22]
    end else if (!(exStall)) begin // @[src/main/scala/rv32i/Core.scala 309:17]
      if (!(redirect)) begin // @[src/main/scala/rv32i/Core.scala 311:24]
        if (!(loadUse)) begin // @[src/main/scala/rv32i/Core.scala 315:23]
          idex_frs3Val <= frs3Val; // @[src/main/scala/rv32i/Core.scala 330:18]
        end
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 63:22]
      idex_imm <= 32'h0; // @[src/main/scala/rv32i/Core.scala 63:22]
    end else if (!(exStall)) begin // @[src/main/scala/rv32i/Core.scala 309:17]
      if (!(redirect)) begin // @[src/main/scala/rv32i/Core.scala 311:24]
        if (!(loadUse)) begin // @[src/main/scala/rv32i/Core.scala 315:23]
          idex_imm <= immg_io_imm; // @[src/main/scala/rv32i/Core.scala 334:17]
        end
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 63:22]
      idex_ctrl_aluSrcA <= 2'h0; // @[src/main/scala/rv32i/Core.scala 63:22]
    end else if (!(exStall)) begin // @[src/main/scala/rv32i/Core.scala 309:17]
      if (!(redirect)) begin // @[src/main/scala/rv32i/Core.scala 311:24]
        if (!(loadUse)) begin // @[src/main/scala/rv32i/Core.scala 315:23]
          idex_ctrl_aluSrcA <= idCtrl_aluSrcA; // @[src/main/scala/rv32i/Core.scala 335:17]
        end
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 63:22]
      idex_ctrl_aluSrcImm <= 1'h0; // @[src/main/scala/rv32i/Core.scala 63:22]
    end else if (!(exStall)) begin // @[src/main/scala/rv32i/Core.scala 309:17]
      if (!(redirect)) begin // @[src/main/scala/rv32i/Core.scala 311:24]
        if (!(loadUse)) begin // @[src/main/scala/rv32i/Core.scala 315:23]
          idex_ctrl_aluSrcImm <= idCtrl_aluSrcImm; // @[src/main/scala/rv32i/Core.scala 335:17]
        end
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 63:22]
      idex_ctrl_aluOp <= 4'h0; // @[src/main/scala/rv32i/Core.scala 63:22]
    end else if (!(exStall)) begin // @[src/main/scala/rv32i/Core.scala 309:17]
      if (!(redirect)) begin // @[src/main/scala/rv32i/Core.scala 311:24]
        if (!(loadUse)) begin // @[src/main/scala/rv32i/Core.scala 315:23]
          idex_ctrl_aluOp <= idCtrl_aluOp; // @[src/main/scala/rv32i/Core.scala 335:17]
        end
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 63:22]
      idex_ctrl_branch <= 1'h0; // @[src/main/scala/rv32i/Core.scala 63:22]
    end else if (!(exStall)) begin // @[src/main/scala/rv32i/Core.scala 309:17]
      if (!(redirect)) begin // @[src/main/scala/rv32i/Core.scala 311:24]
        if (!(loadUse)) begin // @[src/main/scala/rv32i/Core.scala 315:23]
          idex_ctrl_branch <= idCtrl_branch; // @[src/main/scala/rv32i/Core.scala 335:17]
        end
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 63:22]
      idex_ctrl_jal <= 1'h0; // @[src/main/scala/rv32i/Core.scala 63:22]
    end else if (!(exStall)) begin // @[src/main/scala/rv32i/Core.scala 309:17]
      if (!(redirect)) begin // @[src/main/scala/rv32i/Core.scala 311:24]
        if (!(loadUse)) begin // @[src/main/scala/rv32i/Core.scala 315:23]
          idex_ctrl_jal <= idCtrl_jal; // @[src/main/scala/rv32i/Core.scala 335:17]
        end
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 63:22]
      idex_ctrl_jalr <= 1'h0; // @[src/main/scala/rv32i/Core.scala 63:22]
    end else if (!(exStall)) begin // @[src/main/scala/rv32i/Core.scala 309:17]
      if (!(redirect)) begin // @[src/main/scala/rv32i/Core.scala 311:24]
        if (!(loadUse)) begin // @[src/main/scala/rv32i/Core.scala 315:23]
          idex_ctrl_jalr <= idCtrl_jalr; // @[src/main/scala/rv32i/Core.scala 335:17]
        end
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 63:22]
      idex_ctrl_memRead <= 1'h0; // @[src/main/scala/rv32i/Core.scala 63:22]
    end else if (!(exStall)) begin // @[src/main/scala/rv32i/Core.scala 309:17]
      if (!(redirect)) begin // @[src/main/scala/rv32i/Core.scala 311:24]
        if (!(loadUse)) begin // @[src/main/scala/rv32i/Core.scala 315:23]
          idex_ctrl_memRead <= idCtrl_memRead; // @[src/main/scala/rv32i/Core.scala 335:17]
        end
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 63:22]
      idex_ctrl_memWrite <= 1'h0; // @[src/main/scala/rv32i/Core.scala 63:22]
    end else if (!(exStall)) begin // @[src/main/scala/rv32i/Core.scala 309:17]
      if (!(redirect)) begin // @[src/main/scala/rv32i/Core.scala 311:24]
        if (!(loadUse)) begin // @[src/main/scala/rv32i/Core.scala 315:23]
          idex_ctrl_memWrite <= idCtrl_memWrite; // @[src/main/scala/rv32i/Core.scala 335:17]
        end
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 63:22]
      idex_ctrl_memSize <= 2'h0; // @[src/main/scala/rv32i/Core.scala 63:22]
    end else if (!(exStall)) begin // @[src/main/scala/rv32i/Core.scala 309:17]
      if (!(redirect)) begin // @[src/main/scala/rv32i/Core.scala 311:24]
        if (!(loadUse)) begin // @[src/main/scala/rv32i/Core.scala 315:23]
          idex_ctrl_memSize <= idCtrl_memSize; // @[src/main/scala/rv32i/Core.scala 335:17]
        end
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 63:22]
      idex_ctrl_memUnsigned <= 1'h0; // @[src/main/scala/rv32i/Core.scala 63:22]
    end else if (!(exStall)) begin // @[src/main/scala/rv32i/Core.scala 309:17]
      if (!(redirect)) begin // @[src/main/scala/rv32i/Core.scala 311:24]
        if (!(loadUse)) begin // @[src/main/scala/rv32i/Core.scala 315:23]
          idex_ctrl_memUnsigned <= idCtrl_memUnsigned; // @[src/main/scala/rv32i/Core.scala 335:17]
        end
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 63:22]
      idex_ctrl_wbSel <= 2'h0; // @[src/main/scala/rv32i/Core.scala 63:22]
    end else if (!(exStall)) begin // @[src/main/scala/rv32i/Core.scala 309:17]
      if (!(redirect)) begin // @[src/main/scala/rv32i/Core.scala 311:24]
        if (!(loadUse)) begin // @[src/main/scala/rv32i/Core.scala 315:23]
          idex_ctrl_wbSel <= idCtrl_wbSel; // @[src/main/scala/rv32i/Core.scala 335:17]
        end
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 63:22]
      idex_ctrl_regWrite <= 1'h0; // @[src/main/scala/rv32i/Core.scala 63:22]
    end else if (!(exStall)) begin // @[src/main/scala/rv32i/Core.scala 309:17]
      if (!(redirect)) begin // @[src/main/scala/rv32i/Core.scala 311:24]
        if (!(loadUse)) begin // @[src/main/scala/rv32i/Core.scala 315:23]
          idex_ctrl_regWrite <= idCtrl_regWrite; // @[src/main/scala/rv32i/Core.scala 335:17]
        end
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 63:22]
      idex_ctrl_csr <= 1'h0; // @[src/main/scala/rv32i/Core.scala 63:22]
    end else if (!(exStall)) begin // @[src/main/scala/rv32i/Core.scala 309:17]
      if (!(redirect)) begin // @[src/main/scala/rv32i/Core.scala 311:24]
        if (!(loadUse)) begin // @[src/main/scala/rv32i/Core.scala 315:23]
          idex_ctrl_csr <= idCtrl_csr; // @[src/main/scala/rv32i/Core.scala 335:17]
        end
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 63:22]
      idex_ctrl_ecall <= 1'h0; // @[src/main/scala/rv32i/Core.scala 63:22]
    end else if (!(exStall)) begin // @[src/main/scala/rv32i/Core.scala 309:17]
      if (!(redirect)) begin // @[src/main/scala/rv32i/Core.scala 311:24]
        if (!(loadUse)) begin // @[src/main/scala/rv32i/Core.scala 315:23]
          idex_ctrl_ecall <= idCtrl_ecall; // @[src/main/scala/rv32i/Core.scala 335:17]
        end
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 63:22]
      idex_ctrl_ebreak <= 1'h0; // @[src/main/scala/rv32i/Core.scala 63:22]
    end else if (!(exStall)) begin // @[src/main/scala/rv32i/Core.scala 309:17]
      if (!(redirect)) begin // @[src/main/scala/rv32i/Core.scala 311:24]
        if (!(loadUse)) begin // @[src/main/scala/rv32i/Core.scala 315:23]
          idex_ctrl_ebreak <= idCtrl_ebreak; // @[src/main/scala/rv32i/Core.scala 335:17]
        end
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 63:22]
      idex_ctrl_mret <= 1'h0; // @[src/main/scala/rv32i/Core.scala 63:22]
    end else if (!(exStall)) begin // @[src/main/scala/rv32i/Core.scala 309:17]
      if (!(redirect)) begin // @[src/main/scala/rv32i/Core.scala 311:24]
        if (!(loadUse)) begin // @[src/main/scala/rv32i/Core.scala 315:23]
          idex_ctrl_mret <= idCtrl_mret; // @[src/main/scala/rv32i/Core.scala 335:17]
        end
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 63:22]
      idex_ctrl_illegal <= 1'h0; // @[src/main/scala/rv32i/Core.scala 63:22]
    end else if (!(exStall)) begin // @[src/main/scala/rv32i/Core.scala 309:17]
      if (!(redirect)) begin // @[src/main/scala/rv32i/Core.scala 311:24]
        if (!(loadUse)) begin // @[src/main/scala/rv32i/Core.scala 315:23]
          idex_ctrl_illegal <= idCtrl_illegal; // @[src/main/scala/rv32i/Core.scala 335:17]
        end
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 63:22]
      idex_ctrl_isMul <= 1'h0; // @[src/main/scala/rv32i/Core.scala 63:22]
    end else if (!(exStall)) begin // @[src/main/scala/rv32i/Core.scala 309:17]
      if (!(redirect)) begin // @[src/main/scala/rv32i/Core.scala 311:24]
        if (!(loadUse)) begin // @[src/main/scala/rv32i/Core.scala 315:23]
          idex_ctrl_isMul <= idCtrl_isMul; // @[src/main/scala/rv32i/Core.scala 335:17]
        end
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 63:22]
      idex_ctrl_isDiv <= 1'h0; // @[src/main/scala/rv32i/Core.scala 63:22]
    end else if (!(exStall)) begin // @[src/main/scala/rv32i/Core.scala 309:17]
      if (!(redirect)) begin // @[src/main/scala/rv32i/Core.scala 311:24]
        if (!(loadUse)) begin // @[src/main/scala/rv32i/Core.scala 315:23]
          idex_ctrl_isDiv <= idCtrl_isDiv; // @[src/main/scala/rv32i/Core.scala 335:17]
        end
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 63:22]
      idex_ctrl_usesRs1 <= 1'h0; // @[src/main/scala/rv32i/Core.scala 63:22]
    end else if (!(exStall)) begin // @[src/main/scala/rv32i/Core.scala 309:17]
      if (!(redirect)) begin // @[src/main/scala/rv32i/Core.scala 311:24]
        if (!(loadUse)) begin // @[src/main/scala/rv32i/Core.scala 315:23]
          idex_ctrl_usesRs1 <= idCtrl_usesRs1; // @[src/main/scala/rv32i/Core.scala 335:17]
        end
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 63:22]
      idex_ctrl_usesRs2 <= 1'h0; // @[src/main/scala/rv32i/Core.scala 63:22]
    end else if (!(exStall)) begin // @[src/main/scala/rv32i/Core.scala 309:17]
      if (!(redirect)) begin // @[src/main/scala/rv32i/Core.scala 311:24]
        if (!(loadUse)) begin // @[src/main/scala/rv32i/Core.scala 315:23]
          idex_ctrl_usesRs2 <= idCtrl_usesRs2; // @[src/main/scala/rv32i/Core.scala 335:17]
        end
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 63:22]
      idex_ctrl_isF <= 1'h0; // @[src/main/scala/rv32i/Core.scala 63:22]
    end else if (!(exStall)) begin // @[src/main/scala/rv32i/Core.scala 309:17]
      if (!(redirect)) begin // @[src/main/scala/rv32i/Core.scala 311:24]
        if (!(loadUse)) begin // @[src/main/scala/rv32i/Core.scala 315:23]
          idex_ctrl_isF <= idCtrl_isF; // @[src/main/scala/rv32i/Core.scala 335:17]
        end
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 63:22]
      idex_ctrl_fWrite <= 1'h0; // @[src/main/scala/rv32i/Core.scala 63:22]
    end else if (!(exStall)) begin // @[src/main/scala/rv32i/Core.scala 309:17]
      if (!(redirect)) begin // @[src/main/scala/rv32i/Core.scala 311:24]
        if (!(loadUse)) begin // @[src/main/scala/rv32i/Core.scala 315:23]
          idex_ctrl_fWrite <= idCtrl_fWrite; // @[src/main/scala/rv32i/Core.scala 335:17]
        end
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 63:22]
      idex_ctrl_usesFrs1 <= 1'h0; // @[src/main/scala/rv32i/Core.scala 63:22]
    end else if (!(exStall)) begin // @[src/main/scala/rv32i/Core.scala 309:17]
      if (!(redirect)) begin // @[src/main/scala/rv32i/Core.scala 311:24]
        if (!(loadUse)) begin // @[src/main/scala/rv32i/Core.scala 315:23]
          idex_ctrl_usesFrs1 <= idCtrl_usesFrs1; // @[src/main/scala/rv32i/Core.scala 335:17]
        end
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 63:22]
      idex_ctrl_usesFrs2 <= 1'h0; // @[src/main/scala/rv32i/Core.scala 63:22]
    end else if (!(exStall)) begin // @[src/main/scala/rv32i/Core.scala 309:17]
      if (!(redirect)) begin // @[src/main/scala/rv32i/Core.scala 311:24]
        if (!(loadUse)) begin // @[src/main/scala/rv32i/Core.scala 315:23]
          idex_ctrl_usesFrs2 <= idCtrl_usesFrs2; // @[src/main/scala/rv32i/Core.scala 335:17]
        end
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 63:22]
      idex_ctrl_usesFrs3 <= 1'h0; // @[src/main/scala/rv32i/Core.scala 63:22]
    end else if (!(exStall)) begin // @[src/main/scala/rv32i/Core.scala 309:17]
      if (!(redirect)) begin // @[src/main/scala/rv32i/Core.scala 311:24]
        if (!(loadUse)) begin // @[src/main/scala/rv32i/Core.scala 315:23]
          idex_ctrl_usesFrs3 <= idFma; // @[src/main/scala/rv32i/Core.scala 335:17]
        end
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 64:22]
      exmem_valid <= 1'h0; // @[src/main/scala/rv32i/Core.scala 64:22]
    end else begin
      exmem_valid <= _redirect_T_1; // @[src/main/scala/rv32i/Core.scala 339:15]
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 64:22]
      exmem_trap <= 1'h0; // @[src/main/scala/rv32i/Core.scala 64:22]
    end else if (_exCommit_T_2) begin // @[src/main/scala/rv32i/Core.scala 340:18]
      exmem_trap <= trapNow; // @[src/main/scala/rv32i/Core.scala 341:23]
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 64:22]
      exmem_cause <= 4'h0; // @[src/main/scala/rv32i/Core.scala 64:22]
    end else if (_exCommit_T_2) begin // @[src/main/scala/rv32i/Core.scala 340:18]
      if (illegal) begin // @[src/main/scala/chisel3/util/Mux.scala 50:70]
        exmem_cause <= 4'h2;
      end else if (idex_ctrl_ecall) begin // @[src/main/scala/chisel3/util/Mux.scala 50:70]
        exmem_cause <= 4'hb;
      end else begin
        exmem_cause <= _cause_T_2;
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 64:22]
      exmem_pc <= 32'h0; // @[src/main/scala/rv32i/Core.scala 64:22]
    end else if (_exCommit_T_2) begin // @[src/main/scala/rv32i/Core.scala 340:18]
      exmem_pc <= idex_pc; // @[src/main/scala/rv32i/Core.scala 343:23]
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 64:22]
      exmem_pcNext <= 32'h0; // @[src/main/scala/rv32i/Core.scala 64:22]
    end else if (_exCommit_T_2) begin // @[src/main/scala/rv32i/Core.scala 340:18]
      if (trapNow) begin // @[src/main/scala/rv32i/Core.scala 289:19]
        exmem_pcNext <= csr_io_mtvecBase;
      end else if (idex_ctrl_mret) begin // @[src/main/scala/rv32i/Core.scala 290:19]
        exmem_pcNext <= csr_io_mepc;
      end else begin
        exmem_pcNext <= _nextPc_T;
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 64:22]
      exmem_inst <= 32'h0; // @[src/main/scala/rv32i/Core.scala 64:22]
    end else if (_exCommit_T_2) begin // @[src/main/scala/rv32i/Core.scala 340:18]
      exmem_inst <= idex_inst; // @[src/main/scala/rv32i/Core.scala 345:23]
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 64:22]
      exmem_rd <= 5'h0; // @[src/main/scala/rv32i/Core.scala 64:22]
    end else if (_exCommit_T_2) begin // @[src/main/scala/rv32i/Core.scala 340:18]
      exmem_rd <= idex_rd; // @[src/main/scala/rv32i/Core.scala 346:23]
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 64:22]
      exmem_regWrite <= 1'h0; // @[src/main/scala/rv32i/Core.scala 64:22]
    end else if (_exCommit_T_2) begin // @[src/main/scala/rv32i/Core.scala 340:18]
      exmem_regWrite <= idex_ctrl_regWrite & _exCommit_T; // @[src/main/scala/rv32i/Core.scala 347:23]
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 64:22]
      exmem_fWrite <= 1'h0; // @[src/main/scala/rv32i/Core.scala 64:22]
    end else if (_exCommit_T_2) begin // @[src/main/scala/rv32i/Core.scala 340:18]
      exmem_fWrite <= idex_ctrl_fWrite & _exCommit_T; // @[src/main/scala/rv32i/Core.scala 348:23]
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 64:22]
      exmem_result <= 32'h0; // @[src/main/scala/rv32i/Core.scala 64:22]
    end else if (_exCommit_T_2) begin // @[src/main/scala/rv32i/Core.scala 340:18]
      if (idex_ctrl_isF & idex_ctrl_fWrite & ~idex_ctrl_memRead) begin // @[src/main/scala/rv32i/Core.scala 304:41]
        if (useFpu) begin // @[src/main/scala/rv32i/Core.scala 221:20]
          exmem_result <= fpu_io_resp_bits_bits;
        end else begin
          exmem_result <= _fVal_T;
        end
      end else if (idex_ctrl_isF & idex_ctrl_regWrite) begin // @[src/main/scala/rv32i/Core.scala 303:29]
        exmem_result <= fXval; // @[src/main/scala/rv32i/Core.scala 303:40]
      end else begin
        exmem_result <= _GEN_14;
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 64:22]
      exmem_memRead <= 1'h0; // @[src/main/scala/rv32i/Core.scala 64:22]
    end else if (_exCommit_T_2) begin // @[src/main/scala/rv32i/Core.scala 340:18]
      exmem_memRead <= idex_ctrl_memRead & _exCommit_T; // @[src/main/scala/rv32i/Core.scala 351:23]
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 64:22]
      exmem_memWrite <= 1'h0; // @[src/main/scala/rv32i/Core.scala 64:22]
    end else if (_exCommit_T_2) begin // @[src/main/scala/rv32i/Core.scala 340:18]
      exmem_memWrite <= idex_ctrl_memWrite & _exCommit_T; // @[src/main/scala/rv32i/Core.scala 352:23]
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 64:22]
      exmem_memSize <= 2'h0; // @[src/main/scala/rv32i/Core.scala 64:22]
    end else if (_exCommit_T_2) begin // @[src/main/scala/rv32i/Core.scala 340:18]
      exmem_memSize <= idex_ctrl_memSize; // @[src/main/scala/rv32i/Core.scala 353:23]
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 64:22]
      exmem_memUnsigned <= 1'h0; // @[src/main/scala/rv32i/Core.scala 64:22]
    end else if (_exCommit_T_2) begin // @[src/main/scala/rv32i/Core.scala 340:18]
      exmem_memUnsigned <= idex_ctrl_memUnsigned; // @[src/main/scala/rv32i/Core.scala 354:23]
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 64:22]
      exmem_addr <= 32'h0; // @[src/main/scala/rv32i/Core.scala 64:22]
    end else if (_exCommit_T_2) begin // @[src/main/scala/rv32i/Core.scala 340:18]
      exmem_addr <= alu_io_y; // @[src/main/scala/rv32i/Core.scala 355:23]
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 64:22]
      exmem_storeData <= 32'h0; // @[src/main/scala/rv32i/Core.scala 64:22]
    end else if (_exCommit_T_2) begin // @[src/main/scala/rv32i/Core.scala 340:18]
      if (idex_ctrl_isF) begin // @[src/main/scala/rv32i/Core.scala 356:29]
        if (fb_fromMem) begin // @[src/main/scala/rv32i/Core.scala 175:8]
          exmem_storeData <= exmem_result;
        end else begin
          exmem_storeData <= _fb_T;
        end
      end else if (b_fromMem) begin // @[src/main/scala/rv32i/Core.scala 167:8]
        exmem_storeData <= exmem_result;
      end else begin
        exmem_storeData <= _b_T;
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 64:22]
      exmem_fflags <= 5'h0; // @[src/main/scala/rv32i/Core.scala 64:22]
    end else if (_exCommit_T_2) begin // @[src/main/scala/rv32i/Core.scala 340:18]
      if (trapNow) begin // @[src/main/scala/rv32i/Core.scala 349:29]
        exmem_fflags <= 5'h0;
      end else if (fOk) begin // @[src/main/scala/rv32i/Core.scala 222:20]
        exmem_fflags <= _fRaised_T_1;
      end else begin
        exmem_fflags <= 5'h0;
      end
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 65:22]
      memwb_valid <= 1'h0; // @[src/main/scala/rv32i/Core.scala 65:22]
    end else begin
      memwb_valid <= exmem_valid; // @[src/main/scala/rv32i/Core.scala 390:18]
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 65:22]
      memwb_trap <= 1'h0; // @[src/main/scala/rv32i/Core.scala 65:22]
    end else begin
      memwb_trap <= exmem_trap; // @[src/main/scala/rv32i/Core.scala 391:18]
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 65:22]
      memwb_cause <= 4'h0; // @[src/main/scala/rv32i/Core.scala 65:22]
    end else begin
      memwb_cause <= exmem_cause; // @[src/main/scala/rv32i/Core.scala 392:18]
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 65:22]
      memwb_pc <= 32'h0; // @[src/main/scala/rv32i/Core.scala 65:22]
    end else begin
      memwb_pc <= exmem_pc; // @[src/main/scala/rv32i/Core.scala 393:18]
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 65:22]
      memwb_pcNext <= 32'h0; // @[src/main/scala/rv32i/Core.scala 65:22]
    end else begin
      memwb_pcNext <= exmem_pcNext; // @[src/main/scala/rv32i/Core.scala 394:18]
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 65:22]
      memwb_inst <= 32'h0; // @[src/main/scala/rv32i/Core.scala 65:22]
    end else begin
      memwb_inst <= exmem_inst; // @[src/main/scala/rv32i/Core.scala 395:18]
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 65:22]
      memwb_rd <= 5'h0; // @[src/main/scala/rv32i/Core.scala 65:22]
    end else begin
      memwb_rd <= exmem_rd; // @[src/main/scala/rv32i/Core.scala 396:18]
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 65:22]
      memwb_regWrite <= 1'h0; // @[src/main/scala/rv32i/Core.scala 65:22]
    end else begin
      memwb_regWrite <= exmem_regWrite; // @[src/main/scala/rv32i/Core.scala 397:18]
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 65:22]
      memwb_fWrite <= 1'h0; // @[src/main/scala/rv32i/Core.scala 65:22]
    end else begin
      memwb_fWrite <= exmem_fWrite; // @[src/main/scala/rv32i/Core.scala 398:18]
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 65:22]
      memwb_wdata <= 32'h0; // @[src/main/scala/rv32i/Core.scala 65:22]
    end else if (exmem_memRead) begin // @[src/main/scala/rv32i/Core.scala 400:24]
      if (_T_32) begin // @[src/main/scala/rv32i/Core.scala 385:16]
        if (exmem_memUnsigned) begin // @[src/main/scala/rv32i/Core.scala 386:30]
          memwb_wdata <= _loadData_T;
        end else begin
          memwb_wdata <= _loadData_T_3;
        end
      end else if (_T_33) begin // @[src/main/scala/rv32i/Core.scala 385:16]
        memwb_wdata <= _loadData_T_9; // @[src/main/scala/rv32i/Core.scala 387:24]
      end else begin
        memwb_wdata <= io_dmem_rdata; // @[src/main/scala/rv32i/Core.scala 384:29]
      end
    end else begin
      memwb_wdata <= exmem_result;
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 65:22]
      memwb_memRe <= 1'h0; // @[src/main/scala/rv32i/Core.scala 65:22]
    end else begin
      memwb_memRe <= io_dmem_re; // @[src/main/scala/rv32i/Core.scala 401:18]
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 65:22]
      memwb_memWe <= 1'h0; // @[src/main/scala/rv32i/Core.scala 65:22]
    end else begin
      memwb_memWe <= io_dmem_we; // @[src/main/scala/rv32i/Core.scala 402:18]
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 65:22]
      memwb_memAddr <= 32'h0; // @[src/main/scala/rv32i/Core.scala 65:22]
    end else begin
      memwb_memAddr <= exmem_addr; // @[src/main/scala/rv32i/Core.scala 403:18]
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 65:22]
      memwb_memSize <= 2'h0; // @[src/main/scala/rv32i/Core.scala 65:22]
    end else begin
      memwb_memSize <= exmem_memSize; // @[src/main/scala/rv32i/Core.scala 404:18]
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 65:22]
      memwb_memWdata <= 32'h0; // @[src/main/scala/rv32i/Core.scala 65:22]
    end else if (exmem_memSize == 2'h0) begin // @[src/main/scala/rv32i/Core.scala 405:24]
      memwb_memWdata <= _memwb_memWdata_T_1;
    end else if (exmem_memSize == 2'h1) begin // @[src/main/scala/rv32i/Core.scala 405:65]
      memwb_memWdata <= _memwb_memWdata_T_3;
    end else begin
      memwb_memWdata <= exmem_storeData;
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 65:22]
      memwb_fflags <= 5'h0; // @[src/main/scala/rv32i/Core.scala 65:22]
    end else begin
      memwb_fflags <= exmem_fflags; // @[src/main/scala/rv32i/Core.scala 399:18]
    end
    if (reset) begin // @[src/main/scala/rv32i/Core.scala 70:24]
      fetchPc <= 32'h80000000; // @[src/main/scala/rv32i/Core.scala 70:24]
    end else if (!(exStall)) begin // @[src/main/scala/rv32i/Core.scala 309:17]
      if (redirect) begin // @[src/main/scala/rv32i/Core.scala 311:24]
        if (trapNow) begin // @[src/main/scala/rv32i/Core.scala 289:19]
          fetchPc <= csr_io_mtvecBase;
        end else begin
          fetchPc <= _nextPc_T_1;
        end
      end else if (!(loadUse)) begin // @[src/main/scala/rv32i/Core.scala 315:23]
        fetchPc <= _fetchPc_T_1; // @[src/main/scala/rv32i/Core.scala 318:17]
      end
    end
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (~reset & ~(fetchPc[1:0] == 2'h0)) begin
          $fwrite(32'h80000002,
            "Assertion failed: fetch pc must stay 4-byte aligned\n    at Core.scala:438 assert(fetchPc(1, 0) === 0.U, \"fetch pc must stay 4-byte aligned\")\n"
            ); // @[src/main/scala/rv32i/Core.scala 438:9]
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif // SYNTHESIS
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_T_38 & ~(~(io_dmem_we & io_dmem_re))) begin
          $fwrite(32'h80000002,
            "Assertion failed: simultaneous load and store\n    at Core.scala:439 assert(!(io.dmem.we && io.dmem.re), \"simultaneous load and store\")\n"
            ); // @[src/main/scala/rv32i/Core.scala 439:9]
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif // SYNTHESIS
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_T_38 & ~(~(exmem_valid & exmem_trap & (exmem_memRead | exmem_memWrite | exmem_regWrite | exmem_fWrite)))
          ) begin
          $fwrite(32'h80000002,
            "Assertion failed: trapping instruction accesses memory or writes a register\n    at Core.scala:440 assert(!(exmem.valid && exmem.trap && (exmem.memRead || exmem.memWrite || exmem.regWrite || exmem.fWrite)),\n"
            ); // @[src/main/scala/rv32i/Core.scala 440:9]
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif // SYNTHESIS
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_T_38 & ~(~(idex_valid & exmem_valid & exmem_memRead & exmem_regWrite & exmem_rd != 5'h0 & _T_61))) begin
          $fwrite(32'h80000002,
            "Assertion failed: load-use hazard reached EX (missing stall)\n    at Core.scala:442 assert(!(exValid && exmem.valid && exmem.memRead && exmem.regWrite && exmem.rd =/= 0.U &&\n"
            ); // @[src/main/scala/rv32i/Core.scala 442:9]
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif // SYNTHESIS
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_T_38 & ~(~(_T_53 & exmem_fWrite & _T_76))) begin
          $fwrite(32'h80000002,
            "Assertion failed: FLW load-use hazard reached EX (missing stall)\n    at Core.scala:445 assert(!(exValid && exmem.valid && exmem.memRead && exmem.fWrite &&\n"
            ); // @[src/main/scala/rv32i/Core.scala 445:9]
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif // SYNTHESIS
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_T_38 & ~(~(exStall & trapNow))) begin
          $fwrite(32'h80000002,
            "Assertion failed: a division or an FPU operation cannot trap\n    at Core.scala:448 assert(!(exStall && trapNow), \"a division or an FPU operation cannot trap\")\n"
            ); // @[src/main/scala/rv32i/Core.scala 448:9]
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif // SYNTHESIS
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_T_38 & ~(~(csr_io_commit & ~idex_valid))) begin
          $fwrite(32'h80000002,
            "Assertion failed: bubble committed\n    at Core.scala:449 assert(!(csr.io.commit && !exValid), \"bubble committed\")\n"
            ); // @[src/main/scala/rv32i/Core.scala 449:9]
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif // SYNTHESIS
  end
// Register and memory initialization
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif
`ifndef RANDOM
`define RANDOM $random
`endif
`ifdef RANDOMIZE_MEM_INIT
  integer initvar;
`endif
`ifndef SYNTHESIS
`ifdef FIRRTL_BEFORE_INITIAL
`FIRRTL_BEFORE_INITIAL
`endif
initial begin
  `ifdef RANDOMIZE
    `ifdef INIT_RANDOM
      `INIT_RANDOM
    `endif
    `ifndef VERILATOR
      `ifdef RANDOMIZE_DELAY
        #`RANDOMIZE_DELAY begin end
      `else
        #0.002 begin end
      `endif
    `endif
`ifdef RANDOMIZE_REG_INIT
  _RAND_0 = {1{`RANDOM}};
  ifid_valid = _RAND_0[0:0];
  _RAND_1 = {1{`RANDOM}};
  ifid_pc = _RAND_1[31:0];
  _RAND_2 = {1{`RANDOM}};
  ifid_inst = _RAND_2[31:0];
  _RAND_3 = {1{`RANDOM}};
  idex_valid = _RAND_3[0:0];
  _RAND_4 = {1{`RANDOM}};
  idex_pc = _RAND_4[31:0];
  _RAND_5 = {1{`RANDOM}};
  idex_inst = _RAND_5[31:0];
  _RAND_6 = {1{`RANDOM}};
  idex_rs1 = _RAND_6[4:0];
  _RAND_7 = {1{`RANDOM}};
  idex_rs2 = _RAND_7[4:0];
  _RAND_8 = {1{`RANDOM}};
  idex_rs3 = _RAND_8[4:0];
  _RAND_9 = {1{`RANDOM}};
  idex_rd = _RAND_9[4:0];
  _RAND_10 = {1{`RANDOM}};
  idex_rs1Val = _RAND_10[31:0];
  _RAND_11 = {1{`RANDOM}};
  idex_rs2Val = _RAND_11[31:0];
  _RAND_12 = {1{`RANDOM}};
  idex_frs1Val = _RAND_12[31:0];
  _RAND_13 = {1{`RANDOM}};
  idex_frs2Val = _RAND_13[31:0];
  _RAND_14 = {1{`RANDOM}};
  idex_frs3Val = _RAND_14[31:0];
  _RAND_15 = {1{`RANDOM}};
  idex_imm = _RAND_15[31:0];
  _RAND_16 = {1{`RANDOM}};
  idex_ctrl_aluSrcA = _RAND_16[1:0];
  _RAND_17 = {1{`RANDOM}};
  idex_ctrl_aluSrcImm = _RAND_17[0:0];
  _RAND_18 = {1{`RANDOM}};
  idex_ctrl_aluOp = _RAND_18[3:0];
  _RAND_19 = {1{`RANDOM}};
  idex_ctrl_branch = _RAND_19[0:0];
  _RAND_20 = {1{`RANDOM}};
  idex_ctrl_jal = _RAND_20[0:0];
  _RAND_21 = {1{`RANDOM}};
  idex_ctrl_jalr = _RAND_21[0:0];
  _RAND_22 = {1{`RANDOM}};
  idex_ctrl_memRead = _RAND_22[0:0];
  _RAND_23 = {1{`RANDOM}};
  idex_ctrl_memWrite = _RAND_23[0:0];
  _RAND_24 = {1{`RANDOM}};
  idex_ctrl_memSize = _RAND_24[1:0];
  _RAND_25 = {1{`RANDOM}};
  idex_ctrl_memUnsigned = _RAND_25[0:0];
  _RAND_26 = {1{`RANDOM}};
  idex_ctrl_wbSel = _RAND_26[1:0];
  _RAND_27 = {1{`RANDOM}};
  idex_ctrl_regWrite = _RAND_27[0:0];
  _RAND_28 = {1{`RANDOM}};
  idex_ctrl_csr = _RAND_28[0:0];
  _RAND_29 = {1{`RANDOM}};
  idex_ctrl_ecall = _RAND_29[0:0];
  _RAND_30 = {1{`RANDOM}};
  idex_ctrl_ebreak = _RAND_30[0:0];
  _RAND_31 = {1{`RANDOM}};
  idex_ctrl_mret = _RAND_31[0:0];
  _RAND_32 = {1{`RANDOM}};
  idex_ctrl_illegal = _RAND_32[0:0];
  _RAND_33 = {1{`RANDOM}};
  idex_ctrl_isMul = _RAND_33[0:0];
  _RAND_34 = {1{`RANDOM}};
  idex_ctrl_isDiv = _RAND_34[0:0];
  _RAND_35 = {1{`RANDOM}};
  idex_ctrl_usesRs1 = _RAND_35[0:0];
  _RAND_36 = {1{`RANDOM}};
  idex_ctrl_usesRs2 = _RAND_36[0:0];
  _RAND_37 = {1{`RANDOM}};
  idex_ctrl_isF = _RAND_37[0:0];
  _RAND_38 = {1{`RANDOM}};
  idex_ctrl_fWrite = _RAND_38[0:0];
  _RAND_39 = {1{`RANDOM}};
  idex_ctrl_usesFrs1 = _RAND_39[0:0];
  _RAND_40 = {1{`RANDOM}};
  idex_ctrl_usesFrs2 = _RAND_40[0:0];
  _RAND_41 = {1{`RANDOM}};
  idex_ctrl_usesFrs3 = _RAND_41[0:0];
  _RAND_42 = {1{`RANDOM}};
  exmem_valid = _RAND_42[0:0];
  _RAND_43 = {1{`RANDOM}};
  exmem_trap = _RAND_43[0:0];
  _RAND_44 = {1{`RANDOM}};
  exmem_cause = _RAND_44[3:0];
  _RAND_45 = {1{`RANDOM}};
  exmem_pc = _RAND_45[31:0];
  _RAND_46 = {1{`RANDOM}};
  exmem_pcNext = _RAND_46[31:0];
  _RAND_47 = {1{`RANDOM}};
  exmem_inst = _RAND_47[31:0];
  _RAND_48 = {1{`RANDOM}};
  exmem_rd = _RAND_48[4:0];
  _RAND_49 = {1{`RANDOM}};
  exmem_regWrite = _RAND_49[0:0];
  _RAND_50 = {1{`RANDOM}};
  exmem_fWrite = _RAND_50[0:0];
  _RAND_51 = {1{`RANDOM}};
  exmem_result = _RAND_51[31:0];
  _RAND_52 = {1{`RANDOM}};
  exmem_memRead = _RAND_52[0:0];
  _RAND_53 = {1{`RANDOM}};
  exmem_memWrite = _RAND_53[0:0];
  _RAND_54 = {1{`RANDOM}};
  exmem_memSize = _RAND_54[1:0];
  _RAND_55 = {1{`RANDOM}};
  exmem_memUnsigned = _RAND_55[0:0];
  _RAND_56 = {1{`RANDOM}};
  exmem_addr = _RAND_56[31:0];
  _RAND_57 = {1{`RANDOM}};
  exmem_storeData = _RAND_57[31:0];
  _RAND_58 = {1{`RANDOM}};
  exmem_fflags = _RAND_58[4:0];
  _RAND_59 = {1{`RANDOM}};
  memwb_valid = _RAND_59[0:0];
  _RAND_60 = {1{`RANDOM}};
  memwb_trap = _RAND_60[0:0];
  _RAND_61 = {1{`RANDOM}};
  memwb_cause = _RAND_61[3:0];
  _RAND_62 = {1{`RANDOM}};
  memwb_pc = _RAND_62[31:0];
  _RAND_63 = {1{`RANDOM}};
  memwb_pcNext = _RAND_63[31:0];
  _RAND_64 = {1{`RANDOM}};
  memwb_inst = _RAND_64[31:0];
  _RAND_65 = {1{`RANDOM}};
  memwb_rd = _RAND_65[4:0];
  _RAND_66 = {1{`RANDOM}};
  memwb_regWrite = _RAND_66[0:0];
  _RAND_67 = {1{`RANDOM}};
  memwb_fWrite = _RAND_67[0:0];
  _RAND_68 = {1{`RANDOM}};
  memwb_wdata = _RAND_68[31:0];
  _RAND_69 = {1{`RANDOM}};
  memwb_memRe = _RAND_69[0:0];
  _RAND_70 = {1{`RANDOM}};
  memwb_memWe = _RAND_70[0:0];
  _RAND_71 = {1{`RANDOM}};
  memwb_memAddr = _RAND_71[31:0];
  _RAND_72 = {1{`RANDOM}};
  memwb_memSize = _RAND_72[1:0];
  _RAND_73 = {1{`RANDOM}};
  memwb_memWdata = _RAND_73[31:0];
  _RAND_74 = {1{`RANDOM}};
  memwb_fflags = _RAND_74[4:0];
  _RAND_75 = {1{`RANDOM}};
  fetchPc = _RAND_75[31:0];
`endif // RANDOMIZE_REG_INIT
  `endif // RANDOMIZE
end // initial
`ifdef FIRRTL_AFTER_INITIAL
`FIRRTL_AFTER_INITIAL
`endif
`endif // SYNTHESIS
  always @(posedge clock) begin
    //
    if (~reset) begin
      assert(fetchPc[1:0] == 2'h0); // @[src/main/scala/rv32i/Core.scala 438:9]
    end
    //
    if (_T_38) begin
      assert(~(io_dmem_we & io_dmem_re)); // @[src/main/scala/rv32i/Core.scala 439:9]
    end
    //
    if (_T_38) begin
      assert(~(exmem_valid & exmem_trap & (exmem_memRead | exmem_memWrite | exmem_regWrite | exmem_fWrite))); // @[src/main/scala/rv32i/Core.scala 440:9]
    end
    //
    if (_T_38) begin
      assert(~(idex_valid & exmem_valid & exmem_memRead & exmem_regWrite & exmem_rd != 5'h0 & _T_61)); // @[src/main/scala/rv32i/Core.scala 442:9]
    end
    //
    if (_T_38) begin
      assert(~(_T_53 & exmem_fWrite & _T_76)); // @[src/main/scala/rv32i/Core.scala 445:9]
    end
    //
    if (_T_38) begin
      assert(~(exStall & trapNow)); // @[src/main/scala/rv32i/Core.scala 448:9]
    end
    //
    if (_T_38) begin
      assert(~(csr_io_commit & ~idex_valid)); // @[src/main/scala/rv32i/Core.scala 449:9]
    end
  end
endmodule
