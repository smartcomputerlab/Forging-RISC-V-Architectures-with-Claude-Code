# FreeRTOS on the RV32IMA core on the iCESugar-Pro: three independent tasks

The second FreeRTOS example for the Stage 11 core (RV32IMA, 5-stage pipeline, written in Chisel, with the machine
timer interrupt) on the **iCESugar-Pro** board (Lattice ECP5 LFE5U-25F). The hardware is the same as in the first
example (`rv32ima-freertos-icesugar-pro`, where three copies of one blink task run). Here, **three independent
tasks** run: three different functions, each with its own timing method, sharing no data. Each owns one colour of
the on-board **RGB LED**:

| Task | Colour | What it does | How it keeps time | Priority |
|---|---|---|---|---|
| `vHeartbeatTask` | red | a heartbeat: two short flashes, then a pause, once per second | `vTaskDelayUntil` (drift-free, 10 ms steps) | 3 |
| `vCounterTask` | blue | counts 1, 2, 3, 4: n flashes, a 1 s pause, then n + 1 flashes | `vTaskDelay` | 2 |
| `vBreatheTask` | green | "breathes": fades in for 2 s and out for 2 s | software PWM at 1 kHz from the 1 MHz `mtime` counter; never blocks | 1 |

A ready-made bitstream is included: `fpga/IceSugarProTop.bit`.

## 1. Quick start with the ready-made bitstream

1. Connect the iCESugar-Pro with a USB-C cable. The on-board iCELink appears as a USB drive called **iCELink** and as a
   serial port (`/dev/ttyACM0` on Linux).
2. Optional: open a terminal at **115200 baud, 8N1** before programming, to see the start-up message:

   ```bash
   picocom -b 115200 /dev/ttyACM0
   ```

3. Copy `fpga/IceSugarProTop.bit` onto the iCELink drive, or run:

   ```bash
   icesprog fpga/IceSugarProTop.bit
   ```

The terminal shows:

```
FreeRTOS V11.1.0 on RV32IMA (5-stage pipeline, Chisel) on iCESugar-Pro: 3 independent tasks: red heartbeat, blue counter, green breathing
```

On the LED you see the three effects at the same time, mixing where they overlap:

- **red** beats like a heart: on 100 ms, off 150 ms, on 100 ms, off 650 ms, every second;
- **blue** counts: 1 flash, pause, 2 flashes, pause, 3, pause, 4, pause, then from 1 again (200 ms on, 200 ms off,
  1 s pause; one round takes 8 s);
- **green** slowly fades in and out, a 4 s cycle.

If all three colours **blink fast together**, the firmware has stopped on a fault (failed assertion, stack overflow,
out of heap, or an unexpected exception): see `prvFault` in `firmware/main.c`.

## 2. The application (`firmware/main.c`)

Each task changes only its own LED bit, with one atomic instruction (A extension): **AMOOR.W** sets the bit,
**AMOAND.W** clears it.

```c
static inline void prvLedOn( uint32_t mask )  { __asm volatile ( "amoor.w  zero, %1, (%0)" : : "r" ( &LED ), "r" ( mask )  : "memory" ); }
static inline void prvLedOff( uint32_t mask ) { __asm volatile ( "amoand.w zero, %1, (%0)" : : "r" ( &LED ), "r" ( ~mask ) : "memory" ); }
```

**Red, the heartbeat.** Every step is measured from the previous wake-up with `vTaskDelayUntil`, so the beat
stays exactly at one per second:

```c
for( ; ; )
{
    prvLedOn( LED_RED );   vTaskDelayUntil( &xWake, pdMS_TO_TICKS( 100 ) );
    prvLedOff( LED_RED );  vTaskDelayUntil( &xWake, pdMS_TO_TICKS( 150 ) );
    prvLedOn( LED_RED );   vTaskDelayUntil( &xWake, pdMS_TO_TICKS( 100 ) );
    prvLedOff( LED_RED );  vTaskDelayUntil( &xWake, pdMS_TO_TICKS( 650 ) );
}
```

**Blue, the counter.** It keeps its own state (the count `n`) in a local variable and blocks with `vTaskDelay`:

```c
for( ; ; )
{
    for( uint32_t i = 0; i < n; i++ )
    {
        prvLedOn( LED_BLUE );  vTaskDelay( pdMS_TO_TICKS( 200 ) );
        prvLedOff( LED_BLUE ); vTaskDelay( pdMS_TO_TICKS( 200 ) );
    }
    vTaskDelay( pdMS_TO_TICKS( 1000 ) );
    n = ( n == 4 ) ? 1 : n + 1;
}
```

**Green, the breathing.** The FreeRTOS tick (10 ms) is far too coarse for dimming, so this task makes its own PWM:
1 ms periods (1 kHz, no visible flicker). In each period the LED is on for `ulBreatheDutyUs(t)` microseconds.
The brightness rises for 2 s and falls for 2 s, and the on-time is its square, because the eye sees brightness
roughly as the square root of the duty cycle. The task reads the time from `mtime` (microseconds) and writes the LED
only when the level changes:

```c
for( ; ; )
{
    uint32_t t = MTIME_LO;
    uint32_t want = ( t % PWM_PERIOD_US ) < ulBreatheDutyUs( t );
    if( want != on ) { if( want ) prvLedOn( LED_GREEN ); else prvLedOff( LED_GREEN ); on = want; }
}
```

**How the three share the CPU.** Red and blue are blocked almost all the time. Green never blocks, so it gets the
CPU whenever they wait. At a tick where red or blue is due, the scheduler preempts green at once (higher
priority); the task changes its LED bit in a few microseconds and blocks again, and green continues. Green computes
everything from the absolute time, so a preemption only delays one PWM edge a little. Because green always runs, the
idle task never does; this application does not need it (no task is ever deleted).

**Why atomic AMOs.** The three tasks are independent, but the LED register is one word holding all three colours.
With a plain load / or / store, a preemption between the load and the store would make the task write back an old
value of the other two bits, undoing another task's change. AMOOR.W and AMOAND.W read, modify and write as one
indivisible instruction, so no task ever has to wait for another (no mutex, no critical section).

## 3. The system

Unchanged from the first example:

| Block | Details |
|---|---|
| Clock | 25 MHz oscillator (P6), used directly: **25 MHz** system clock |
| Core | Stage 11 RV32IMA 5-stage pipeline + the machine timer interrupt; reset pc 0x80000000 |
| RAM | **32 KiB at 0x80000000**: one memory for instructions and data, block RAM, loaded with the firmware by the bitstream |
| CLINT | mtimecmp at 0x02004000, mtime at 0x0200BFF8; mtime counts at **1 MHz** (the green PWM reads it); MTIP = mtime >= mtimecmp |
| LED | 0x10000000: bits 2:0 = {blue, green, red}, 1 = on (pins B11 red, A11 green, A12 blue) |
| UART | 0x10000004 TX, 0x10000008 status, 0x1000000C RX; 115200 baud 8N1 on the iCELink serial port (B9 TX, A9 RX) |

FreeRTOS configuration (`firmware/FreeRTOSConfig.h`, unchanged): preemptive, 5 priorities, tick 100 Hz, heap_4 with
12 KiB, stack overflow checking, assertions on.

Memory use: the image (code, read-only data, data) is 6,700 bytes: 6,400 code, 288 read-only data, 12 data. Then
`.bss` (12,552 bytes, mostly the 12 KiB heap with the four task control blocks and 512-byte stacks) and the 1 KiB
interrupt stack: about 20 KiB of the 32 KiB.

The one hardware change: the CLINT has a new parameter for the start value of `mtime`. It is used only by the
simulation test, to start half-way into the green fade, and is 0 in the bitstream, so the generated Verilog is
unchanged.

Last build (Yosys 0.71, nextpnr-ecp5 0.11.1). Only the RAM contents differ from the first example:

| Resource | Used | Of |
|---|---|---|
| LUT4 / logic cells | 9,088 | 24,288 (37 %) |
| Flip-flops | 2,158 | 24,288 (9 %) |
| DP16KD block RAM | 32 (all 32 carry the firmware image) | 56 |
| MULT18X18D | 4 | 28 |

Maximum frequency **38.80 MHz**, constraint 25 MHz: **PASS**.

## 4. Building it yourself

Tools:

- **Firmware:** clang and ld.lld with the RISC-V target (LLVM 14 or newer; Ubuntu: `sudo apt install clang lld llvm`),
  or a GNU RISC-V toolchain (`make GCC=1`), and Python 3
- **Hardware:** Java 11+ and sbt for Chisel; Yosys, nextpnr-ecp5 and ecppack (the YosysHQ oss-cad-suite, or
  `make YOWASP=1` with `pip install yowasp-yosys yowasp-nextpnr-ecp5`)

Everything at once, from the `fpga` folder:

```bash
make
```

This builds the firmware (`firmware/freertos.hex`), generates the Verilog with the firmware in the RAM
(`sbt "runMain rv32i.EmitFpga"`), then runs Yosys, nextpnr-ecp5 and ecppack and leaves `fpga/build/IceSugarProTop.bit`.

Only the firmware, from the `firmware` folder:

```bash
make
```

After changing the application, run `make` in `fpga` again: the new firmware has to go into the bitstream. Check it
first at instruction level (a few seconds to minutes):

```bash
python3 tools/rvsim.py firmware/freertos.hex
```

## 5. How it was checked

The checks compare every LED change against the intended pattern (`tools/led3check.py`):

- every change switches exactly one colour;
- red and blue: every switch-on and switch-off at its planned time, within 1 ms (the tick is 10 ms);
- green: the on-time in every 1 ms PWM period against the formula of `ulBreatheDutyUs`.

To make sure the checks can fail, they were fed six broken versions of a correct log. All six were caught: a red
edge 20 ms late, a blue edge 15 ms early, a missing heartbeat, two colours changing at once, green on-time 10 % too
long, and green inverted.

1. **The core:** unchanged from the first example (48 tests passing, including `CoreIrqSpec` for the timer
   interrupt).
2. **The firmware at instruction level** (`tools/rvsim.py`, a separate simulator of the whole system, in Python):
   FreeRTOS boots, prints its message and runs the three tasks; all checks pass:

   | Run | CPU speed | Red / blue edges, worst timing error | Green PWM periods, mean / worst on-time error |
   |---|---|---|---|
   | 17 s (two rounds of the blue count), the default | 5 instructions / µs | 68 / 42 edges, 45 µs | 16,994 periods, 1.4 / 120 µs |
   | 9 s at the **board's rate** (225 million instructions) | 25 instructions / µs | 36 / 22 edges, 9 µs | 8,998 periods, 0.6 / 21 µs |

   The edges land a few microseconds after their tick; the few larger green errors are PWM periods where the tick
   interrupt and a task switch delayed one edge.

   ```bash
   python3 tools/rvsim.py firmware/freertos.hex
   ```

   ```bash
   python3 tools/rvsim.py firmware/freertos.hex --seconds 9 --div 25
   ```
3. **The whole system, cycle by cycle** (`FpgaFreeRtosSpec`): the generated hardware (core, RAM with the firmware
   image, CLINT, LED, UART) runs the real firmware in the Chisel simulator. To make it feasible, the CPU runs at
   1 instruction per µs instead of 25 (mtime counts once per cycle). The run is 390,000 cycles: the boot and the
   first 0.34 s of the application. mtime starts at 1 s, so the green on-time is already large. **Passes**
   (90 minutes, 73 cycles/s):

   - the start-up message on the UART, and 687 LED changes, each switching exactly one colour;
   - red on at +0, off at +100.3 ms, on again at +250.3 ms (the run ends before the off at +350 ms);
   - blue on at +0, off at +199.8 ms;
   - green: 341 PWM periods with on-times from 274 to 483 µs, mean error 16.9 µs. Three periods are off by more
     than 150 µs (worst 637 µs): those where a tick interrupt and a task switch delayed an edge. At this slowed CPU
     speed that costs 25 times more time than on the board.

   ```bash
   sbt "testOnly rv32i.FpgaFreeRtosSpec"
   ```

4. **The hardware build:** synthesis, placement and routing complete, timing passes at 25 MHz, all 32 block RAMs carry
   the firmware image, and ecppack produces the bitstream.

**Not done:** this bitstream has not been run on a real board yet (the first example, with the same hardware, has),
and the routed netlist was not simulated (no gate-level simulator was available).

## 6. Files

| Path | Contents |
|---|---|
| `firmware/main.c` | **The application**: `vHeartbeatTask`, `vCounterTask`, `vBreatheTask`, start-up message, fault handler |
| `firmware/` | Also `FreeRTOSConfig.h`, `start.S`, `link.ld`, `lib.c` + `include/` (minimal C library), `Makefile`, `tohex.py`, `FreeRTOS-Kernel/` (V11.1.0: kernel, RISC-V port, heap_4, MIT licence), and the built `freertos.elf` / `.hex` / `.lst` |
| `src/main/scala/rv32i/` | The core (`Core`, `CsrFile`, `Decoder`, …, see `CORE.md`), the system and top level (`IceSugarPro.scala`: `IceSugarSoC`, `Clint`, `IceSugarProTop`, `EmitFpga`), the UART |
| `src/test/scala/rv32i/` | Core tests, `FpgaFreeRtosSpec` (this application on the whole system) |
| `fpga/` | `Makefile`, `icesugar_pro.lpf` (pins), `IceSugarProTop.bit`, `build/` (Verilog, logs) |
| `tools/rvsim.py`, `tools/led3check.py` | Instruction-level simulator of the system; the LED pattern checks |
| `CORE.md`, `DESIGN_NOTES.md` | The core: instructions, tests, interface, waveforms; design choices, including the interrupt |
