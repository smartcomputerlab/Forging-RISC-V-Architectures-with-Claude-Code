"""Checks the LED pattern of the three-task application (firmware/main.c) from a log of LED changes.

The log is a list of (mtime, LED value) pairs, mtime in microseconds (1 MHz, as on the board). It is used by
tools/rvsim.py (instruction-level simulation). The cycle-accurate FpgaFreeRtosSpec does the same checks in Scala.

  red   heartbeat: on 0-100 ms and 250-350 ms of every second (from its first switch-on)
  blue  counter:   n flashes of 200 ms on / 200 ms off, then 1 s off; n = 1, 2, 3, 4, 1, ...
  green breathing: software PWM, 1 ms period, on-time ulBreatheDutyUs(t) in each period
  and: every LED change changes exactly one colour.
"""

EDGE_TOL_US = 1000          # red / blue edges: at a tick (10 ms grid) plus the wake-up latency
PWM_US, BREATH_US = 1000, 4000000


def breathe_duty_us(t):
    """Same integer computation as ulBreatheDutyUs() in main.c."""
    b = t % BREATH_US
    r = b // 2000 if b < BREATH_US // 2 else (BREATH_US - b) // 2000
    return r * r // 1000


def red_expected(t0, t_end):
    out, k = [], 0
    while True:
        for off, v in ((0, 1), (100000, 0), (250000, 1), (350000, 0)):
            t = t0 + k * 1000000 + off
            if t > t_end:
                return out
            out.append((t, v))
        k += 1


def blue_expected(t0, t_end):
    out, t, n = [], t0, 1
    while True:
        for _ in range(n):
            for v, d in ((1, 200000), (0, 200000)):
                if t > t_end:
                    return out
                out.append((t, v))
                t += d
        t += 1000000
        n = 1 if n == 4 else n + 1


def edges(log, bit):
    out, prev = [], 0
    for t, v in log:
        if (v ^ prev) & bit:
            out.append((t, 1 if v & bit else 0))
        prev = v
    return out


def compare_edges(name, got, want_fn, t_end, report):
    if not got:
        report.append("%s: never switched on" % name)
        return False, None
    want = want_fn(got[0][0], t_end - EDGE_TOL_US)
    ok = len(got) >= len(want)
    worst = 0
    for (tg, vg), (tw, vw) in zip(got, want):
        worst = max(worst, abs(tg - tw))
        if vg != vw or abs(tg - tw) > EDGE_TOL_US:
            ok = False
    if len(got) > len(want) + 1:
        ok = False
    report.append("%-5s %3d edges (expected %d), worst timing error %d us  %s" %
                  (name, len(got), len(want), worst, "OK" if ok else "MISMATCH"))
    if not ok:
        report.append("      got  %s" % got[:12])
        report.append("      want %s" % want[:12])
    return ok, got[0][0]


def check(log, t_start, t_end, pwm_tol_us=50, pwm_bad_frac=0.02):
    """log: [(mtime, value)] sorted; t_start: mtime when the scheduler started (LED 0 before it).
    Returns (ok, list of report lines)."""
    report, ok = [], True
    prev = 0
    for t, v in log:
        if bin(v ^ prev).count("1") != 1:
            report.append("mtime %d: LED %s -> %s changes more than one colour" % (t, format(prev, "03b"), format(v, "03b")))
            ok = False
        prev = v
    r_ok, _ = compare_edges("red", edges(log, 1), red_expected, t_end, report)
    b_ok, _ = compare_edges("blue", edges(log, 4), blue_expected, t_end, report)
    ok &= r_ok and b_ok

    # green: on-time in every complete 1 ms PWM period, against the formula
    g = edges(log, 2)
    w = (t_start // PWM_US + 1) * PWM_US
    i, level, n, bad, worst, sum_err = 0, 0, 0, 0, 0, 0
    while w + PWM_US <= t_end:
        while i < len(g) and g[i][0] <= w:
            level = g[i][1]; i += 1
        on, t, lv, j = 0, w, level, i
        while j < len(g) and g[j][0] < w + PWM_US:
            if lv: on += g[j][0] - t
            t, lv = g[j][0], g[j][1]; j += 1
        if lv: on += w + PWM_US - t
        err = on - breathe_duty_us(w)
        n += 1; sum_err += abs(err); worst = max(worst, abs(err))
        if abs(err) > pwm_tol_us: bad += 1
        w += PWM_US
    g_ok = n > 0 and bad <= pwm_bad_frac * n
    ok &= g_ok
    report.append("green %d PWM periods, mean |on-time error| %.1f us, worst %d us, %d (%.2f %%) over %d us  %s" %
                  (n, sum_err / max(n, 1), worst, bad, 100.0 * bad / max(n, 1), pwm_tol_us, "OK" if g_ok else "MISMATCH"))
    return ok, report
