/* FreeRTOS application for the RV32IMA core on the iCESugar-Pro: three independent tasks on the RGB LED.
 *
 * The tasks are three different functions. They share no variables and never wait for each other; each one owns
 * one colour of the LED and has its own timing method:
 *
 *   red    vHeartbeatTask  priority 3   a heartbeat: two short flashes, then a pause, once per second
 *                                        (blocks with vTaskDelayUntil, drift-free, 10 ms resolution)
 *   blue   vCounterTask    priority 2   counts 1, 2, 3, 4: n flashes, a 1 s pause, then n + 1 flashes
 *                                        (blocks with vTaskDelay)
 *   green  vBreatheTask    priority 1   "breathes": fades in and out over 4 s, by software PWM at 1 kHz
 *                                        (never blocks: it polls the 1 MHz mtime counter and runs whenever
 *                                        the two others are waiting)
 *
 * The only thing the tasks have in common is the LED register. Each task changes only its own bit, with one atomic
 * instruction from the A extension: AMOOR.W sets the bit, AMOAND.W clears it. A plain read-modify-write
 * (load, or/and, store) could be preempted between the load and the store, and the other task's change would be
 * lost; the AMO reads and writes as one indivisible step, so no lock is needed and no task ever waits for another.
 *
 * Priorities: red and blue spend almost all their time blocked, so the busy green task gets nearly all of the CPU.
 * When red or blue wakes up (on a tick), it preempts green at once, changes its LED bit in a few microseconds and
 * blocks again. Because green runs continuously, the idle task (priority 0) never runs; this application does
 * not need it (no task is ever deleted).
 */
#include <stdint.h>
#include "FreeRTOS.h"
#include "task.h"

#define IO_BASE      0x10000000UL
#define LED          ( *( volatile uint32_t * ) ( IO_BASE + 0x00 ) )   /* bits 2:0 = {blue, green, red} */
#define UART_TX      ( *( volatile uint32_t * ) ( IO_BASE + 0x04 ) )
#define UART_STATUS  ( *( volatile uint32_t * ) ( IO_BASE + 0x08 ) )   /* bit 0: transmitter ready */
#define MTIME_LO     ( *( volatile uint32_t * ) ( configMTIME_BASE_ADDRESS ) )   /* 1 MHz: microseconds */

#define LED_RED      1u
#define LED_GREEN    2u
#define LED_BLUE     4u

/* Switch the bits of `mask` on / off in the LED register, atomically. */
static inline void prvLedOn( uint32_t mask )
{
    __asm volatile ( "amoor.w zero, %1, (%0)" : : "r" ( &LED ), "r" ( mask ) : "memory" );
}

static inline void prvLedOff( uint32_t mask )
{
    __asm volatile ( "amoand.w zero, %1, (%0)" : : "r" ( &LED ), "r" ( ~mask ) : "memory" );
}

/* ---- red: heartbeat --------------------------------------------------------------------------------------------
 * One beat per second: on 100 ms, off 150 ms, on 100 ms, off 650 ms. vTaskDelayUntil measures every step from the
 * previous wake-up time, so the beat never drifts. */
static void vHeartbeatTask( void * pvParameters )
{
    ( void ) pvParameters;
    TickType_t xWake = xTaskGetTickCount();

    for( ; ; )
    {
        prvLedOn( LED_RED );
        vTaskDelayUntil( &xWake, pdMS_TO_TICKS( 100 ) );
        prvLedOff( LED_RED );
        vTaskDelayUntil( &xWake, pdMS_TO_TICKS( 150 ) );
        prvLedOn( LED_RED );
        vTaskDelayUntil( &xWake, pdMS_TO_TICKS( 100 ) );
        prvLedOff( LED_RED );
        vTaskDelayUntil( &xWake, pdMS_TO_TICKS( 650 ) );
    }
}

/* ---- blue: counter ---------------------------------------------------------------------------------------------
 * Flashes n times (200 ms on, 200 ms off), pauses 1 s more, then counts on: n = 1, 2, 3, 4, 1, 2, ...
 * One round of 1 to 4 takes 4 x 1 s of pauses + 10 flashes x 0.4 s = 8 s. */
static void vCounterTask( void * pvParameters )
{
    ( void ) pvParameters;
    uint32_t n = 1;

    for( ; ; )
    {
        for( uint32_t i = 0; i < n; i++ )
        {
            prvLedOn( LED_BLUE );
            vTaskDelay( pdMS_TO_TICKS( 200 ) );
            prvLedOff( LED_BLUE );
            vTaskDelay( pdMS_TO_TICKS( 200 ) );
        }
        vTaskDelay( pdMS_TO_TICKS( 1000 ) );
        n = ( n == 4 ) ? 1 : n + 1;
    }
}

/* ---- green: breathing ------------------------------------------------------------------------------------------
 * Software PWM with a 1 ms period (1 kHz, too fast to see flicker). The brightness follows a triangle that rises
 * for 2 s and falls for 2 s; the on-time is the square of it, because the eye sees brightness roughly as the
 * square root of the duty cycle, so the fade looks even.
 * Everything is computed from mtime (microseconds since reset), so the pattern does not depend on how often the
 * task gets the CPU: being preempted only delays one edge a little. The low 32 bits of mtime wrap every 71 min,
 * which makes one visible jump in the fade. */
#define PWM_PERIOD_US      1000u
#define BREATH_PERIOD_US   4000000u

uint32_t ulBreatheDutyUs( uint32_t t )      /* on-time in each 1 ms PWM period at time t (us); also used by tests */
{
    uint32_t b = t % BREATH_PERIOD_US;
    uint32_t r = ( b < BREATH_PERIOD_US / 2 ) ? b / 2000u : ( BREATH_PERIOD_US - b ) / 2000u;   /* 0 .. 1000 */
    return ( r * r ) / 1000u;                                                                     /* 0 .. 1000 */
}

static void vBreatheTask( void * pvParameters )
{
    ( void ) pvParameters;
    uint32_t on = 0;

    for( ; ; )
    {
        uint32_t t = MTIME_LO;
        uint32_t want = ( t % PWM_PERIOD_US ) < ulBreatheDutyUs( t );

        if( want != on )                        /* write only on a change */
        {
            if( want ) { prvLedOn( LED_GREEN ); }
            else       { prvLedOff( LED_GREEN ); }
            on = want;
        }
    }
}

/* ---- start-up message on the UART (polled, before the scheduler starts) ---- */
static void prvPuts( const char * s )
{
    for( ; *s != 0; s++ )
    {
        while( ( UART_STATUS & 1u ) == 0 ) { }
        UART_TX = ( uint32_t ) ( uint8_t ) *s;
    }
}

/* ---- faults: stop everything and show it on the LED (all three colours blink fast) ---- */
static void prvFault( void )
{
    __asm volatile ( "csrc mstatus, 8" );           /* interrupts off */
    for( ; ; )
    {
        LED = LED_RED | LED_GREEN | LED_BLUE;
        for( volatile uint32_t i = 0; i < 200000u; i++ ) { }
        LED = 0;
        for( volatile uint32_t i = 0; i < 200000u; i++ ) { }
    }
}

void vAssertCalled( const char * file, int line )                      { ( void ) file; ( void ) line; prvFault(); }
void vApplicationMallocFailedHook( void )                               { prvFault(); }
void vApplicationStackOverflowHook( TaskHandle_t xTask, char * pcName ) { ( void ) xTask; ( void ) pcName; prvFault(); }
/* Exceptions other than ECALL (illegal instruction, misaligned access, ...) and unexpected interrupts. */
void freertos_risc_v_application_exception_handler( void )              { prvFault(); }
void freertos_risc_v_application_interrupt_handler( void )              { prvFault(); }

extern void freertos_risc_v_trap_handler( void );

int main( void )
{
    LED = 0;
    __asm volatile ( "csrw mtvec, %0" : : "r" ( freertos_risc_v_trap_handler ) );

    prvPuts( "\r\nFreeRTOS " tskKERNEL_VERSION_NUMBER " on RV32IMA (5-stage pipeline, Chisel) on iCESugar-Pro: "
             "3 independent tasks: red heartbeat, blue counter, green breathing\r\n" );

    xTaskCreate( vHeartbeatTask, "heart",   configMINIMAL_STACK_SIZE, NULL, 3, NULL );
    xTaskCreate( vCounterTask,   "count",   configMINIMAL_STACK_SIZE, NULL, 2, NULL );
    xTaskCreate( vBreatheTask,   "breathe", configMINIMAL_STACK_SIZE, NULL, 1, NULL );

    vTaskStartScheduler();          /* does not return */
    prvFault();
    return 0;
}
