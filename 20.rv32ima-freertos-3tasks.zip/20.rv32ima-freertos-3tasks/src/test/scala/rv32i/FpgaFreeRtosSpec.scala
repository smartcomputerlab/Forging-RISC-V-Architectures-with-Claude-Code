package rv32i

import chisel3._
import chiseltest._
import org.scalatest.flatspec.AnyFlatSpec
import org.scalatest.matchers.should.Matchers

/** The real FreeRTOS firmware (firmware/freertos.hex, the three independent tasks) on the whole FPGA system, cycle by
  * cycle: the RV32IMA core with its timer interrupt, the 32 KiB RAM preloaded with the image, the CLINT, the LED
  * register and the UART.
  *
  * Treadle simulates this system at about 80 cycles per second, so the clock is slowed relative to time: mtime
  * counts 1 per clock cycle here (1 MHz CPU) instead of 1 per 25 cycles on the board, and the run covers the boot and
  * about the first 0.34 s of the application. mtime starts at 1,000,000 (1 s), so that the green fade is half-way up and its PWM has
  * a large on-time. The firmware is exactly the one in the bitstream. The test decodes the UART, records every LED
  * change and checks (the same checks as tools/led3check.py):
  *  - the start-up banner, and that every LED change changes exactly one colour;
  *  - red heartbeat: on at the start, off at +100 ms, on at +250 ms (off at +350 ms when the run is long enough:
  *    every planned edge before the end of the run is checked);
  *  - blue counter: on at the start, off at +200 ms;
  *  - green breathing: the on-time in every 1 ms PWM period against the formula of main.c. With the CPU 25 times
  *    slower than on the board, a period that contains a tick interrupt and a task switch can be off by a few
  *    hundred microseconds, so the limits are: mean error under 25 us, at most 3 % of the periods over 150 us.
  * Set FREERTOS_CYCLES to change the length (default 390,000 cycles, about 85 minutes).
  */
class FpgaFreeRtosSpec extends AnyFlatSpec with ChiselScalatestTester with Matchers {
  private val Div = 8                  // UART: 8 clock cycles per bit
  private val MtimeInit = 1000000L     // 1 s into the green fade

  private def breatheDutyUs(t: Long): Long = {     // ulBreatheDutyUs() of main.c
    val b = t % 4000000L
    val r = if (b < 2000000L) b / 2000 else (4000000L - b) / 2000
    r * r / 1000
  }

  "FreeRTOS" should "boot and run the three independent LED tasks: heartbeat, counter, breathing" in {
    val firmware = FpgaMap.readHex("firmware/freertos.hex")
    val total = sys.env.get("FREERTOS_CYCLES").map(_.toLong).getOrElse(390000L)
    test(new IceSugarSoC(firmware, Div, mtimeDiv = 1, mtimeInc = 1, mtimeInit = MtimeInit))
      .withAnnotations(TestUtil.waves) { c =>
      c.clock.setTimeout(0)
      c.io.uartRx.poke(true.B)
      val uart = new StringBuilder
      var rxBusy = false; var cnt = 0; var bit = 0; var shift = 0
      var led = 0
      val changes = scala.collection.mutable.ArrayBuffer.empty[(Long, Int)]   // (mtime, new LED value)
      val t0 = System.nanoTime()
      var cycle = 0L
      while (cycle < total) {
        val tx = c.io.uartTx.peek().litToBoolean
        if (!rxBusy) { if (!tx) { rxBusy = true; cnt = Div + Div / 2 - 1; bit = 0; shift = 0 } }
        else if (cnt == 0) {
          if (bit < 8) { shift |= (if (tx) 1 << bit else 0); bit += 1; cnt = Div - 1 }
          else { tx shouldBe true; uart += shift.toChar; rxBusy = false }
        } else cnt -= 1
        val l = c.io.led.peek().litValue.toInt
        if (l != led) { changes += ((MtimeInit + cycle, l)); led = l }   // mtime = MtimeInit + cycles since reset
        c.clock.step()
        cycle += 1
      }
      val secs = (System.nanoTime() - t0) / 1e9
      val tEnd = MtimeInit + total
      info(f"$total cycles in $secs%.0f s (${total / secs}%.0f cycles/s), ${changes.length} LED changes")
      info("UART: " + uart.toString.trim)
      uart.toString should include("3 independent tasks")

      var prev = 0
      for ((t, v) <- changes) { withClue(s"mtime $t: ") { Integer.bitCount(v ^ prev) shouldBe 1 }; prev = v }

      def edges(b: Int): Seq[(Long, Int)] = {
        var p = 0
        changes.toSeq.flatMap { case (t, v) => val e = if (((v ^ p) & b) != 0) Some((t, (v & b).sign)) else None; p = v; e }
      }
      def checkEdges(name: String, b: Int, offsets: Seq[(Long, Int)]): Unit = {
        val got = edges(b)
        got should not be empty
        val start = got.head._1
        val want = offsets.map { case (o, v) => (start + o, v) }.filter(_._1 <= tEnd - 1000)
        info(s"$name: edges at +" + got.map(e => f"${(e._1 - start) / 1000.0}%.1f ms ${if (e._2 == 1) "on" else "off"}").mkString(", +"))
        got.length shouldBe want.length
        for (((tg, vg), (tw, vw)) <- got.zip(want)) withClue(s"$name edge at $tg, expected $tw: ") {
          vg shouldBe vw
          math.abs(tg - tw) should be <= 1000L
        }
      }
      checkEdges("red  ", 1, Seq((0L, 1), (100000L, 0), (250000L, 1), (350000L, 0), (1000000L, 1)))
      checkEdges("blue ", 4, Seq((0L, 1), (200000L, 0), (1400000L, 1)))

      // green: the on-time in every complete 1 ms PWM period after the first LED change
      val g = edges(2)
      g.length should be > 100
      var w = (changes.head._1 / 1000 + 1) * 1000
      var i = 0; var level = 0; var n = 0; var bad = 0; var worst = 0L; var sumErr = 0L
      while (w + 1000 <= tEnd) {
        while (i < g.length && g(i)._1 <= w) { level = g(i)._2; i += 1 }
        var on = 0L; var t = w; var lv = level; var j = i
        while (j < g.length && g(j)._1 < w + 1000) { if (lv == 1) on += g(j)._1 - t; t = g(j)._1; lv = g(j)._2; j += 1 }
        if (lv == 1) on += w + 1000 - t
        val err = math.abs(on - breatheDutyUs(w))
        n += 1; sumErr += err; worst = worst max err; if (err > 150) bad += 1
        w += 1000
      }
      info(f"green: $n PWM periods, on-time ${breatheDutyUs(changes.head._1)} to ${breatheDutyUs(tEnd)} us, " +
        f"mean error ${sumErr.toDouble / n}%.1f us, worst $worst us, $bad over 150 us")
      (sumErr.toDouble / n) should be < 25.0
      bad.toDouble should be <= (0.03 * n)
    }
  }
}
