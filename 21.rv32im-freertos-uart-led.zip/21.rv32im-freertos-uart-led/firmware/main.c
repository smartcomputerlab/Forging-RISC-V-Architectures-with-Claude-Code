/* FreeRTOS application for the RV32IM core on the iCESugar-Pro: the user chooses the colour of the RGB LED from a
 * terminal on the board's USB serial port (115200 baud, 8N1).
 *
 *     > red                  LED red
 *     > c                    LED cyan (green+blue)         any unique prefix of a name works
 *     > red + green          LED yellow (red+green)        names combine with '+', ',' or spaces
 *     > 101                  LED magenta (red+blue)        three binary digits: R G B
 *     > off                  LED off
 *     > status               the current colour
 *     > help                 the list of commands
 *
 * Colours: off, red, green, blue, yellow, cyan, magenta, white. Upper and lower case are the same. Backspace / DEL
 * delete the last character, Ctrl-U the whole line; the line ends with CR, LF or CR LF.
 *
 * Two tasks:
 *
 *  - console (priority 1): owns the UART. The system has no UART interrupt (the core only takes the timer
 *    interrupt) and the receiver holds one byte, so this task polls the UART all the time: it runs whenever the
 *    other task does not, and FreeRTOS takes it away only for the tick and for the led task. It edits the line
 *    being typed (echo, backspace), passes each finished line to the led task through a queue, and sends that
 *    task's replies, each followed by the prompt.
 *  - led (priority 2): blocks on the line queue. For each line it parses the command, writes the LED register and
 *    hands its reply to the console through a second queue, then waits (task notification) until the reply has
 *    gone out, because the reply text is in its own buffer.
 *
 * Only the led task writes the LED, only the console touches the UART. The queues protect their data with
 * FreeRTOS critical sections (interrupts off on one core), so no atomic instruction is needed: rv32im.
 */
#include <stdint.h>
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"

#define IO_BASE      0x10000000UL
#define LED          ( *( volatile uint32_t * ) ( IO_BASE + 0x00 ) )   /* bits 2:0 = {blue, green, red} */
#define UART_TX      ( *( volatile uint32_t * ) ( IO_BASE + 0x04 ) )
#define UART_STATUS  ( *( volatile uint32_t * ) ( IO_BASE + 0x08 ) )   /* bit 0: TX ready, bit 1: byte received */
#define UART_RX      ( *( volatile uint32_t * ) ( IO_BASE + 0x0c ) )   /* reading it clears status bit 1 */

#define TX_READY     1u
#define RX_FULL      2u

#define LED_RED      1u
#define LED_GREEN    2u
#define LED_BLUE     4u

#define LINE_LEN     40u            /* longest command line, including the terminating 0 */
#define LINE_QUEUE   32u            /* lines typed ahead (or pasted) before the led task has handled them */
#define ECHO_SIZE    256u           /* echo characters waiting while a reply is being sent (power of two) */
#define LINE_BUFS    ( LINE_QUEUE + 2u )   /* in the queue + being handled by the led task + being typed */
#define REPLY_LEN    80u

/* Nothing is copied between the two tasks, only indexes and pointers, so that handing over a line takes little
 * time: the console must be back at the receiver before the next byte arrives (see vConsoleTask). */
static char pcLines[ LINE_BUFS ][ LINE_LEN ];   /* written by the console, read by the led task once queued */
static QueueHandle_t xLineQueue;    /* console -> led: index of a finished line in pcLines (uint8_t) */
static QueueHandle_t xReplyQueue;   /* led -> console: pointer to the reply text (without the prompt) */
static TaskHandle_t xLedTask;

/* Names by LED value (bit 0 red, bit 1 green, bit 2 blue). */
static const char * const pcName[ 8 ] =
{
    "off", "red", "green", "yellow", "blue", "magenta", "cyan", "white"
};

static const char pcHelp[] =
    "Commands (upper or lower case, any unique prefix of a name):\r\n"
    "  off red green blue yellow cyan magenta white   set the LED\r\n"
    "  red+blue, red green ...                        mix: names joined by '+', ',' or spaces\r\n"
    "  RGB as three binary digits, e.g. 110           = yellow\r\n"
    "  status                                         show the current colour\r\n"
    "  help or ?                                      this list\r\n";

#define PROMPT       "> "

static const char pcBanner[] =
    "\r\nFreeRTOS " tskKERNEL_VERSION_NUMBER " on RV32IM (5-stage pipeline, Chisel) on iCESugar-Pro: "
    "RGB LED colour from the terminal\r\n"
    "Type a colour (off red green blue yellow cyan magenta white) and Enter; help for more.\r\n" PROMPT;

/* ===================================================================================================== led task */

static char * prvAppend( char * d, const char * s, const char * end )
{
    while( *s != 0 && d < end - 1 ) *d++ = *s++;
    *d = 0;
    return d;
}

static char prvLower( char c )
{
    return ( c >= 'A' && c <= 'Z' ) ? ( char ) ( c + 'a' - 'A' ) : c;
}

static int prvIsSeparator( char c )
{
    return c == ' ' || c == '\t' || c == '+' || c == ',';
}

static int prvStrEq( const char * a, const char * b )
{
    while( *a != 0 && *a == *b ) { a++; b++; }
    return *a == *b;
}

/* The LED value for one word: a unique prefix of a colour name, or three binary digits R G B. -1: unknown. */
static int prvParseWord( const char * w, uint32_t n )
{
    if( n == 3 && ( w[ 0 ] | 1 ) == '1' && ( w[ 1 ] | 1 ) == '1' && ( w[ 2 ] | 1 ) == '1' )
    {
        return ( w[ 0 ] - '0' ) * LED_RED + ( w[ 1 ] - '0' ) * LED_GREEN + ( w[ 2 ] - '0' ) * LED_BLUE;
    }
    int found = -1;
    for( int v = 0; v < 8; v++ )
    {
        uint32_t k = 0;
        while( k < n && pcName[ v ][ k ] == w[ k ] ) k++;
        if( k == n )
        {
            if( found >= 0 ) return -1;          /* ambiguous (cannot happen with these names) */
            found = v;
        }
    }
    return found;
}

/* Executes one command line. Returns the reply: pcHelp, or the text written into pcReply ("" for an empty line). */
static const char * prvExecute( char * pcLine, char * pcReply )
{
    char * const end = pcReply + REPLY_LEN;
    char * r = pcReply;
    *r = 0;

    for( char * p = pcLine; *p != 0; p++ ) *p = prvLower( *p );
    while( prvIsSeparator( *pcLine ) && *pcLine != '+' && *pcLine != ',' ) pcLine++;   /* leading blanks */
    char * e = pcLine;
    while( *e != 0 ) e++;
    while( e > pcLine && ( e[ -1 ] == ' ' || e[ -1 ] == '\t' ) ) *--e = 0;           /* trailing blanks */

    if( *pcLine == 0 )
    {
        /* empty line: only the prompt */
    }
    else if( prvStrEq( pcLine, "help" ) || prvStrEq( pcLine, "?" ) )
    {
        return pcHelp;                                     /* sent from where it is: nothing to copy */
    }
    else if( prvStrEq( pcLine, "status" ) )
    {
        r = prvAppend( r, "LED is ", end );
        r = prvAppend( r, pcName[ LED & 7u ], end );
        r = prvAppend( r, "\r\n", end );
    }
    else
    {
        uint32_t value = 0;
        int words = 0;
        char * p = pcLine;
        for( ; ; )
        {
            while( prvIsSeparator( *p ) ) p++;
            if( *p == 0 ) break;
            char * w = p;
            while( *p != 0 && !prvIsSeparator( *p ) ) p++;
            int v = prvParseWord( w, ( uint32_t ) ( p - w ) );
            if( v < 0 )
            {
                char c = *p;
                *p = 0;
                r = prvAppend( r, "unknown colour '", end );
                r = prvAppend( r, w, end );
                r = prvAppend( r, "' (type help)\r\n", end );
                *p = c;
                words = -1;
                break;
            }
            value |= ( uint32_t ) v;
            words++;
        }

        if( words > 0 )
        {
            LED = value;                                   /* the only place that writes the LED */
            r = prvAppend( r, "LED ", end );
            r = prvAppend( r, pcName[ value ], end );
            if( value == 3u || value == 5u || value == 6u )        /* mixed colours: say what is on */
            {
                r = prvAppend( r, " (", end );
                const char * sep = "";
                for( uint32_t b = 1; b <= 4u; b <<= 1 )
                {
                    if( value & b ) { r = prvAppend( r, sep, end ); r = prvAppend( r, pcName[ b ], end ); sep = "+"; }
                }
                r = prvAppend( r, ")", end );
            }
            r = prvAppend( r, "\r\n", end );
        }
    }
    return pcReply;
}

static void vLedTask( void * pvParameters )
{
    static char pcReply[ REPLY_LEN ];
    uint8_t ucIndex;
    ( void ) pvParameters;

    for( ; ; )
    {
        /* (portMAX_DELAY is a very long finite wait here, hence the loops.) */
        while( xQueueReceive( xLineQueue, &ucIndex, portMAX_DELAY ) != pdPASS ) { }
        const char * pcOut = prvExecute( pcLines[ ucIndex ], pcReply );

        while( xQueueSend( xReplyQueue, &pcOut, portMAX_DELAY ) != pdPASS ) { }
        while( ulTaskNotifyTake( pdTRUE, portMAX_DELAY ) == 0 ) { }      /* the console has sent it all */
    }
}

/* ================================================================================================= console task */

static char pcEcho[ ECHO_SIZE ];
static uint32_t ulEchoHead, ulEchoTail;    /* used by the console task only: no locking needed */

static void prvEcho( const char * s )
{
    for( ; *s != 0; s++ )
    {
        if( ulEchoHead - ulEchoTail < ECHO_SIZE )         /* full (only when far too much is pasted): drop */
        {
            pcEcho[ ulEchoHead++ % ECHO_SIZE ] = *s;
        }
    }
}

/* The receiver holds one byte, so the loop must come back to it within one byte time (10 bits: 2170 cycles at
 * 115200 baud and 25 MHz). Everything between two looks is short: one byte of output, or one character of line
 * editing, or a tick interrupt, or the led task handling a line (a few hundred instructions, because the line and
 * the reply are passed by index / pointer). tools/rvsim.py and FpgaFreeRtosSpec paste input at that rate. */
static void vConsoleTask( void * pvParameters )
{
    uint8_t ucCur = 0;                    /* the line buffer being typed into */
    char * pcLine = pcLines[ 0 ];
    uint32_t ulLen = 0;
    int lastWasCR = 0;
    int escape = 0;                       /* 1: after ESC, 2: inside ESC [ ... (arrow keys etc.): ignored */
    const char * pcReply = pcBanner;      /* the text being sent, NULL: none. First the banner and prompt: they
                                           * come from here, so the prompt appears once input is being read */
    int fromLed = 0;                      /* 1: pcReply is the led task's reply (then comes the prompt) */
    ( void ) pvParameters;

    for( ; ; )
    {
        const uint32_t st = UART_STATUS;

        if( st & RX_FULL )
        {
            const char c = ( char ) UART_RX;
            const int cr = ( c == '\r' );
            const int afterCR = lastWasCR;
            lastWasCR = cr;

            if( escape == 1 )
            {
                escape = ( c == '[' || c == 'O' ) ? 2 : 0;
            }
            else if( escape == 2 )
            {
                if( c >= 0x40 && c <= 0x7e ) escape = 0;   /* final byte of the sequence */
            }
            else if( c == 0x1b )
            {
                escape = 1;
            }
            else if( cr || c == '\n' )
            {
                if( !( c == '\n' && afterCR ) )              /* CR LF counts once */
                {
                    prvEcho( "\r\n" );
                    pcLine[ ulLen ] = 0;
                    ulLen = 0;
                    if( xQueueSend( xLineQueue, &ucCur, 0 ) == pdPASS )
                    {
                        ucCur = ( uint8_t ) ( ( ucCur + 1u ) % LINE_BUFS );   /* this one now belongs to led */
                        pcLine = pcLines[ ucCur ];
                    }
                    else
                    {
                        prvEcho( "(too many lines waiting, line dropped)\r\n" );
                    }
                }
            }
            else if( c == 0x08 || c == 0x7f )               /* backspace, DEL */
            {
                if( ulLen > 0 ) { ulLen--; prvEcho( "\b \b" ); }
            }
            else if( c == 0x15 )                             /* Ctrl-U: delete the line */
            {
                while( ulLen > 0 ) { ulLen--; prvEcho( "\b \b" ); }
            }
            else if( c >= 0x20 && c <= 0x7e )
            {
                if( ulLen < LINE_LEN - 1 )
                {
                    const char s[ 2 ] = { c, 0 };
                    pcLine[ ulLen++ ] = c;
                    prvEcho( s );
                }
                else
                {
                    prvEcho( "\a" );                         /* line full: bell */
                }
            }
            continue;                                        /* look at the receiver again first */
        }

        if( st & TX_READY )
        {
            if( pcReply != NULL )                            /* a reply goes out in one piece */
            {
                if( *pcReply != 0 ) UART_TX = ( uint8_t ) *pcReply++;
                if( *pcReply == 0 )
                {
                    if( fromLed )                            /* reply done: its buffer is free, then the prompt */
                    {
                        fromLed = 0;
                        pcReply = PROMPT;
                        xTaskNotifyGive( xLedTask );
                    }
                    else
                    {
                        pcReply = NULL;
                    }
                }
            }
            else if( ulEchoTail != ulEchoHead )
            {
                UART_TX = ( uint8_t ) pcEcho[ ulEchoTail++ % ECHO_SIZE ];
            }
            else if( xQueueReceive( xReplyQueue, &pcReply, 0 ) == pdPASS )
            {
                fromLed = 1;
            }
        }
    }
}

/* ===================================================================================================== start-up */

/* Faults: stop everything and show it on the LED (all three colours blink fast). */
static void prvFault( void )
{
    __asm volatile ( "csrc mstatus, 8" );           /* interrupts off */
    for( ; ; )
    {
        LED = LED_RED | LED_GREEN | LED_BLUE;
        for( volatile uint32_t i = 0; i < 200000u; i++ ) { }
        LED = 0;
        for( volatile uint32_t i = 0; i < 200000u; i++ ) { }
    }
}

void vAssertCalled( const char * file, int line )                      { ( void ) file; ( void ) line; prvFault(); }
void vApplicationMallocFailedHook( void )                               { prvFault(); }
void vApplicationStackOverflowHook( TaskHandle_t xTask, char * pcName ) { ( void ) xTask; ( void ) pcName; prvFault(); }
/* Exceptions other than ECALL (illegal instruction, misaligned access, ...) and unexpected interrupts. */
void freertos_risc_v_application_exception_handler( void )              { prvFault(); }
void freertos_risc_v_application_interrupt_handler( void )              { prvFault(); }

extern void freertos_risc_v_trap_handler( void );

int main( void )
{
    LED = 0;
    __asm volatile ( "csrw mtvec, %0" : : "r" ( freertos_risc_v_trap_handler ) );

    xLineQueue  = xQueueCreate( LINE_QUEUE, sizeof( uint8_t ) );
    xReplyQueue = xQueueCreate( 1, sizeof( const char * ) );
    configASSERT( xLineQueue != NULL && xReplyQueue != NULL );

    xTaskCreate( vLedTask,     "led",     256, NULL, 2, &xLedTask );
    xTaskCreate( vConsoleTask, "console", 192, NULL, 1, NULL );

    vTaskStartScheduler();          /* does not return */
    prvFault();
    return 0;
}
