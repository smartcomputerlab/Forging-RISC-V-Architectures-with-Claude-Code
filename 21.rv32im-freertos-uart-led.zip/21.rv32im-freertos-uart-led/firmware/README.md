# Firmware: FreeRTOS V11.1.0 for the RV32IM system

| File | Contents |
|---|---|
| `main.c` | The application: the RGB LED colour typed on the terminal. Task `console` (polls the UART, line editing, echo, sends replies) and task `led` (parses each line, writes the LED), connected by two queues and a task notification; fault handler (all colours blink fast) |
| `FreeRTOSConfig.h` | Kernel configuration: CLINT addresses, mtime at 1 MHz, 100 Hz tick, 5 priorities, 12 KiB heap (heap_4), stack overflow check, assertions |
| `start.S` | Reset entry at 0x80000000: stack pointer, clear `.bss`, call `main` |
| `link.ld` | One 32 KiB RAM at 0x80000000; the stack of `main` becomes the interrupt stack (`__freertos_irq_stack_top`) |
| `lib.c`, `include/` | The C library functions FreeRTOS uses (`memset`, `memcpy`, `memcmp`, `strlen`) and stub headers: there is no C library |
| `tohex.py` | Binary image to hex (one 32-bit word per line), the format `EmitFpga` reads |
| `FreeRTOS-Kernel/` | FreeRTOS-Kernel V11.1.0, unchanged: `tasks.c`, `list.c`, `queue.c`, `include/`, the GCC RISC-V port with the `RISCV_MTIME_CLINT_no_extensions` chip header, `heap_4.c`; MIT licence in `LICENSE.md` |
| `freertos.elf`, `freertos.hex`, `freertos.lst` | The built firmware (in the bitstream) |

Build with clang (default) or GCC:

```bash
make
```

```bash
make GCC=1
```

Compiler flags: `-march=rv32im -mabi=ilp32 -Os -ffreestanding`, linked without a C library. The core has no
compressed instructions (no C extension), no floating point and no FENCE.I. The firmware uses only RV32IM + Zicsr
instructions: the core has no A extension, and the compiler is told so, so it never emits an LR, SC or AMO
(the listing `freertos.lst` contains none).

How FreeRTOS uses the hardware:

- **Tick:** the RISC-V port's trap handler (`freertos_risc_v_trap_handler`, installed in `mtvec` by `main`) handles
  the machine timer interrupt. It writes the next compare value to mtimecmp (two 32-bit stores), calls
  `xTaskIncrementTick` and switches tasks when needed.
- **Yield:** `portYIELD` is an ECALL; the same handler switches context and returns to mepc + 4.
- **Critical sections:** `csrc mstatus, 8` / `csrs mstatus, 8` (MIE).
- **Context:** 31 integer registers, mstatus and the critical-nesting count on each task's stack; the interrupt
  stack is separate.

- **UART:** polled by the `console` task (the system has no UART interrupt). The receiver holds one byte, so that
  task must look at it at least once per byte time (86.8 µs at 115200 baud); see the comment above `vConsoleTask`.

To change the commands, edit `main.c`, then rebuild the bitstream (`make` in `../fpga`). Check the result quickly at
instruction level first, typed and pasted:

```bash
python3 ../tools/rvsim.py freertos.hex
```

```bash
python3 ../tools/rvsim.py freertos.hex --mode pasted
```

(`rvsim.py` types the test session of `tools/uartled_check.py` and checks the replies and the LED; change the
session there, and in `FpgaFreeRtosSpec`, when the commands change.)
