# FreeRTOS on the RV32IM core on the iCESugar-Pro: LED colour from the terminal

A FreeRTOS application on the **RV32IM** core (the 5-stage Chisel pipeline with the machine timer interrupt, without
the A extension) on the **iCESugar-Pro** board (Lattice ECP5 LFE5U-25F). You type a colour in a terminal on the
board's USB serial port and the on-board **RGB LED** shows it:

```
FreeRTOS V11.1.0 on RV32IM (5-stage pipeline, Chisel) on iCESugar-Pro: RGB LED colour from the terminal
Type a colour (off red green blue yellow cyan magenta white) and Enter; help for more.
> red
LED red
> c
LED cyan (green+blue)
> red + green
LED yellow (red+green)
> 101
LED magenta (red+blue)
> purple
unknown colour 'purple' (type help)
> status
LED is magenta
> off
LED off
>
```

The hardware is the same as in the RV32IM colour-cycle example: same core, same system and same memory map. The
UART receiver was already there. Only the firmware is new, so the new bitstream differs only in the RAM contents.
A ready-made bitstream is included: `fpga/IceSugarProTop.bit`.

## 1. Quick start with the ready-made bitstream

1. Connect the iCESugar-Pro with a USB-C cable. The on-board iCELink appears as a USB drive called **iCELink** and as a
   serial port (`/dev/ttyACM0` on Linux, a COM port on Windows).
2. Open a terminal at **115200 baud, 8N1**, no flow control. Use one of these:

   ```bash
   picocom -b 115200 /dev/ttyACM0
   ```

   ```bash
   screen /dev/ttyACM0 115200
   ```

   On Windows, PuTTY or Tera Term on the COM port also works. The terminal should not echo locally: the board echoes
   what you type.
3. Copy `fpga/IceSugarProTop.bit` onto the iCELink drive, or run:

   ```bash
   icesprog fpga/IceSugarProTop.bit
   ```

The banner and the prompt `> ` appear, and the LED is off. Type a command and press Enter. If the terminal was opened
after programming, press Enter once to get a prompt. If all three colours **blink fast together**, the firmware has
stopped on a fault (failed assertion, stack overflow, out of heap, or an unexpected exception): see `prvFault` in
`firmware/main.c`.

## 2. Commands

| You type | The LED |
|---|---|
| `off` `red` `green` `blue` `yellow` `cyan` `magenta` `white` | that colour (yellow = red + green, cyan = green + blue, magenta = red + blue, white = all three) |
| any unique prefix: `r`, `gr`, `b`, `y`, `c`, `m`, `w`, `o` ... | the same as the full name (every name starts with a different letter) |
| `red+blue`, `red, green`, `green blue` | the colours mixed: names joined by `+`, `,` or spaces |
| three binary digits R G B: `100` `010` `001` `110` `111` `000` ... | red, green, blue, yellow, white, off ... |
| `status` | unchanged; shows the current colour |
| `help` or `?` | unchanged; lists the commands |

Upper and lower case are the same, and spaces before and after are ignored. An unknown word leaves the LED as it is
and says so. Line editing: Backspace or DEL deletes a character, Ctrl-U deletes the line, and arrow keys and other
escape sequences are ignored. A line holds up to 39 characters, and the board rings the bell when it is full. Enter
may send CR, LF or CR LF.

The LED is a single RGB LED that is either on or off in each colour, so it has 8 states. (There are no brightness
levels: the LED register has one bit per colour.)

## 3. The application (`firmware/main.c`)

Two tasks:

```
               UART RX                 xLineQueue (index of a line)
  terminal  ----------->  console  ------------------------------>  led
            <-----------  task     <------------------------------  task  -----> LED register
               UART TX   (prio 1)       xReplyQueue (pointer to the reply)  (prio 2)
                                   <- - - - - - - - - - - - - - - -
                                     task notification: reply sent
```

- **console** (priority 1) owns the UART. The system has no UART interrupt, because the core only takes the timer
  interrupt. The receiver holds one byte, and a byte that arrives before the previous one was read overwrites it. So
  this task polls the UART all the time. It runs whenever the `led` task does not, and FreeRTOS only takes the CPU
  away from it for the 10 ms tick and for the `led` task. It does three jobs:
  - It edits the line being typed: echo, backspace, Ctrl-U.
  - It puts each finished line into the queue `xLineQueue`.
  - It sends the replies of the `led` task, each followed by the prompt.
- **led** (priority 2) blocks on `xLineQueue`. For each line, it parses the command, writes the LED register and
  passes its reply to the console through `xReplyQueue`. It then waits for a task notification from the console
  saying that the reply has been sent, because the reply text is in the `led` task's own buffer.

Only the `led` task writes the LED, and only the console touches the UART, so neither needs a lock.

**Why the handover is by index and pointer.** While the `led` task runs, the console cannot read the receiver. If the
user pastes several lines, the next byte arrives one byte time (10 bits at 115200 baud = 86.8 µs = 2,170 cycles)
after the Enter. Everything that runs in between has to fit in that time:
- the queue handover;
- two task switches;
- parsing the command and formatting the reply.

So nothing is copied between the tasks:
- The lines live in a ring of `LINE_QUEUE + 2` buffers, and the queue carries only the index (1 byte).
- The reply travels as a pointer, so `help` is sent straight from its constant string.
- The banner and the first prompt also come from the console task, so the prompt appears only once input is being
  read.

Measured at instruction level: a received byte waits at most about 950 instructions (the longest line, with three
words), and 74 instructions when typing normally.

The handover was checked as follows:
- **Instruction-level simulator:** it pastes the whole test session at one byte per 1,200 instructions and loses
  nothing.
- **Cycle-accurate test:** it pastes on the real pipeline at the board's exact 2,170 cycles per byte (see section 6).
- **Limits:**
  - Lines pasted while replies are still going out wait in the queue, up to 32 of them. A line beyond that is
    dropped with a message.
  - The echo buffer holds 256 characters.

**Why FreeRTOS does not need the A extension.** FreeRTOS runs on a single core (one hart). The kernel and the queues
protect their data with critical sections, and in the RISC-V port these switch interrupts off: `csrc mstatus, 8` /
`csrs mstatus, 8`. With one hart and interrupts off, nothing else can run between a read and the write that follows.
The firmware is compiled with `-march=rv32im` and contains no LR, SC or AMO instruction (`freertos.lst`). The core
would trap on one as an illegal instruction, and `tools/rvsim.py` would stop.

**Changing it:**
- **Names and commands:** edit `pcName`, `pcHelp` and `prvExecute`. Names must keep distinct first letters, or a
  one-letter prefix becomes ambiguous; `prvParseWord` then reports the word as unknown.
- **Line length, queue depth and echo buffer:** change `LINE_LEN`, `LINE_QUEUE` and `ECHO_SIZE`.
- **After a change:** run the instruction-level check (section 5), then rebuild the bitstream. The test session and
  its expected replies are in `tools/uartled_check.py` and, for the cycle-accurate test, in `FpgaFreeRtosSpec`:
  update both.

## 4. The system

Unchanged from the RV32IM colour-cycle example:

| Block | Details |
|---|---|
| Clock | 25 MHz oscillator (P6), used directly: **25 MHz** system clock |
| Core | RV32IM 5-stage pipeline + the machine timer interrupt (no A extension); reset pc 0x80000000 |
| RAM | **32 KiB at 0x80000000**: one memory for instructions and data, block RAM, loaded with the firmware by the bitstream |
| CLINT | mtimecmp at 0x02004000, mtime at 0x0200BFF8; mtime counts at **1 MHz**; MTIP = mtime >= mtimecmp |
| LED | 0x10000000: bits 2:0 = {blue, green, red}, 1 = on (pins B11 red, A11 green, A12 blue) |
| UART | 115200 baud 8N1 on the iCELink serial port (B9 TX, A9 RX), registers below |

| UART register | Address | Access | Meaning |
|---|---|---|---|
| `UART_TX` | 0x10000004 | W | byte to send (only when status bit 0 is 1) |
| `UART_STATUS` | 0x10000008 | R | bit 0: transmitter ready; bit 1: a received byte is waiting |
| `UART_RX` | 0x1000000C | R | the received byte; reading it clears status bit 1 |

FreeRTOS configuration (`firmware/FreeRTOSConfig.h`, unchanged): preemptive, 5 priorities, tick 100 Hz (10 ms),
task notifications on, heap_4 with 12 KiB, stack overflow checking, assertions on. Queues come from `queue.c`, which
was already linked in.

Memory use:
- **The image:** 13,796 bytes (12,800 code, 984 read-only data, 12 data).
- **`.bss`:** 14,264 bytes: the 12 KiB heap (with the three task control blocks, the task stacks and the two queues),
  the 34 line buffers and the echo buffer.
- **Interrupt stack:** 1 KiB.

In total 29,088 bytes of the 32,768.

Last build (Yosys 0.71, nextpnr-ecp5 0.11.1):

| Resource | Used | Of |
|---|---|---|
| Logic cells (nextpnr) | 8,450 (34 %) | 24,288 |
| Flip-flops | 2,116 (8 %) | 24,288 |
| DP16KD block RAM | 32 (all 32 carry the firmware image) | 56 |
| MULT18X18D | 4 | 28 |

The logic is the same as in the colour-cycle build (8,410 cells); the difference comes from the RAM contents
changing what Yosys and nextpnr do. Maximum frequency **39.28 MHz**, constraint 25 MHz: **PASS**.

## 5. Building it yourself

Tools:

- **Firmware:** clang and ld.lld with the RISC-V target (LLVM 14 or newer; Ubuntu: `sudo apt install clang lld llvm`),
  or a GNU RISC-V toolchain (`make GCC=1`), and Python 3
- **Hardware:** Java 11+ and sbt for Chisel; Yosys, nextpnr-ecp5 and ecppack (the YosysHQ oss-cad-suite, or
  `make YOWASP=1` with `pip install yowasp-yosys yowasp-nextpnr-ecp5`)

Everything at once, from the `fpga` folder:

```bash
make
```

This builds the firmware (`firmware/freertos.hex`), generates the Verilog with the firmware in the RAM
(`sbt "runMain rv32i.EmitFpga"`), then runs Yosys, nextpnr-ecp5 and ecppack and leaves `fpga/build/IceSugarProTop.bit`.

Only the firmware, from the `firmware` folder:

```bash
make
```

After changing the application, check it at instruction level (20 s each), then run `make` in `fpga` again: the new
firmware has to go into the bitstream.

```bash
python3 tools/rvsim.py firmware/freertos.hex
```

```bash
python3 tools/rvsim.py firmware/freertos.hex --mode pasted
```

## 6. How it was checked

All the checks run the same **test session** of 19 lines (`tools/uartled_check.py`). It covers:
- every colour, and full names, prefixes and upper case;
- mixes with `+` and with commas and spaces, and a binary code;
- an unknown word, `status`, an empty line and `help`;
- Backspace (DEL), an arrow key (`ESC [ A`) and Ctrl-U;
- LF and CR LF line endings.

The checks are:
- every reply, in order;
- the number of prompts (one at start-up and one per line, so an LF after a CR must not count as a second line);
- every LED change: the 15 changes red, green, blue, yellow, cyan, magenta, white, off, magenta, cyan, yellow, red,
  blue, white, off;
- that no line was dropped;
- that no received byte was lost.

To make sure the checker can fail, it was given 8 broken variants of a good run, and all 8 were caught:
- a missing reply;
- a wrong mix text;
- a missing LED change;
- a wrong LED value;
- two replies swapped;
- an extra prompt;
- no banner;
- a dropped line.

1. **The firmware at instruction level** (`tools/rvsim.py`, an independent simulator of the whole system in Python,
   with the one-byte receiver modelled: a byte that arrives before the previous one was read counts as lost):
   **pass**, typed and pasted, at the fast setting and at the board rate (`--div 25`):

   | Run | Lost bytes | Longest wait for a received byte | Result |
   |---|---|---|---|
   | typed, one character per 20 ms | 0 | 74 instructions | 18 replies in order, 20 prompts, 15 LED changes: pass |
   | typed, board rate | 0 | 73 instructions | pass |
   | pasted, one byte per 1,200 instructions | 0 | about 950 instructions | pass |
   | pasted, board rate | 0 | 875 instructions | pass |

   For comparison: pasting at one byte per 1,000 instructions loses a byte (after the longest line), so the margin
   is known. Before the handover was changed to indexes and pointers, the first byte after every Enter was lost
   when pasting.

   ```bash
   python3 tools/rvsim.py firmware/freertos.hex                           # typed, 20 s
   python3 tools/rvsim.py firmware/freertos.hex --mode pasted             # pasted, 20 s
   python3 tools/rvsim.py firmware/freertos.hex --div 25                  # typed, board rate, 2 minutes
   ```

2. **The whole system, cycle by cycle** (`FpgaFreeRtosSpec`): the generated hardware (core, RAM with the firmware
   image, CLINT, LED, UART) runs the real firmware in the Chisel simulator. The test acts as the terminal: it sends
   the session bit by bit on the `uart_rx` input and decodes `uart_tx`. To make the run feasible:
   - the UART runs at 8 clock cycles per bit (the board: 217);
   - a tick is 10,000 cycles (the board: 250,000).

   It runs twice:
   - **typed:** each line after the prompt;
   - **pasted:** the whole session in one go, one byte every **2,170 cycles**, exactly the board's byte time. This
     checks on the real pipeline that the console reads every byte before the next one arrives.

   Both runs pass. In each, the banner and first prompt appear after 62,934 cycles; all 18 replies come in order; there are 20 prompts, no "dropped", and the 15 LED changes are 1 2 4 3 6 5 7 0 5 6 3 1 4 7 0.

   | run | session | whole run | time (Treadle) |
   |---|---|---|---|
   | typed | 190,556 cycles | 255,490 cycles | 42 min |
   | pasted | 278,083 cycles | 343,017 cycles | 67 min |

   When pasting, echoes and replies interleave on the terminal (for example `> yellow | cLED yellow`): the next
   line's echo is sent while the LED task works. Every byte is still received.

   Run only one with `FREERTOS_RUNS=typed` or `FREERTOS_RUNS=pasted`. A progress line is printed every 20,000 cycles.

   ```bash
   sbt "testOnly rv32i.FpgaFreeRtosSpec"
   ```

3. **The core:** the core is unchanged from the RV32IM colour-cycle example, where all 40 core tests pass. They are
   still here:

   ```bash
   sbt "testOnly rv32i.AluSpec rv32i.CoreDivSpec rv32i.CoreIrqSpec rv32i.CoreNoAmoSpec rv32i.CoreProgramSpec rv32i.CoreTimingSpec rv32i.CsrFileSpec rv32i.DecoderSpec rv32i.DivUnitSpec rv32i.ImmGenSpec rv32i.MultiplierSpec rv32i.RegFileSpec rv32i.WaveformSpec"
   ```

4. **The hardware build:** synthesis, placement and routing complete, timing passes at 25 MHz, all 32 block RAMs carry
   the firmware image, and ecppack produces the bitstream.

**Not done:**
- This bitstream has not been run on a real board yet. The earlier examples, with the same system, have, but they
  never used the UART receiver.
- The routed netlist was not simulated (no gate-level simulator was available).

## 7. Files

| Path | Contents |
|---|---|
| `firmware/main.c` | **The application**: the `console` and `led` tasks, the command parser, line editing, fault handler |
| `firmware/` | Also `FreeRTOSConfig.h`, `start.S`, `link.ld`, `lib.c` + `include/` (minimal C library), `Makefile`, `tohex.py`, `FreeRTOS-Kernel/` (V11.1.0: kernel, queues, RISC-V port, heap_4, MIT licence), and the built `freertos.elf` / `.hex` / `.lst` |
| `src/main/scala/rv32i/` | The core (`Core`, `CsrFile`, `Decoder`, …, see `CORE.md`), the system and top level (`IceSugarPro.scala`: `IceSugarSoC`, `Clint`, `IceSugarProTop`, `EmitFpga`), the UART (`Uart.scala`) |
| `src/test/scala/rv32i/` | Core tests (including `CoreNoAmoSpec`: no A extension), `FpgaFreeRtosSpec` (this application on the whole system, typed and pasted) |
| `fpga/` | `Makefile`, `icesugar_pro.lpf` (pins), `IceSugarProTop.bit`, `build/` (Verilog, logs) |
| `tools/rvsim.py`, `tools/uartled_check.py`, `tools/rv32im_filter.py` | Instruction-level simulator of the system (with the UART receiver; stops on any AMO); the test session and its check; GTKWave disassembly filter |
| `CORE.md`, `DESIGN_NOTES.md` | The core: instructions, tests, interface, waveforms; design choices, including the interrupt |
