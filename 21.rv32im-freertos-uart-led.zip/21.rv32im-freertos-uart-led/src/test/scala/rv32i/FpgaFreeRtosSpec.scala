package rv32i

import chisel3._
import chiseltest._
import org.scalatest.flatspec.AnyFlatSpec
import org.scalatest.matchers.should.Matchers

/** The real FreeRTOS firmware (firmware/freertos.hex: the LED colour chosen from the terminal) on the whole FPGA
  * system, cycle by cycle: the RV32IM core with its timer interrupt, the 32 KiB RAM preloaded with the image, the
  * CLINT, the LED register and the UART. The test is the terminal: it sends the session of tools/uartled_check.py
  * bit by bit on the `uartRx` pin, decodes `uartTx`, and checks the replies (in order), the prompts and every LED
  * change.
  *
  * Treadle simulates this system at about 100 cycles per second, so the UART runs at 8 clock cycles per bit here
  * (the board: 217) and a FreeRTOS tick is 10,000 cycles (mtime counts one per cycle; the board: 250,000). Two runs:
  *  - typed: each line after the prompt of the previous one, a pause of 400 cycles after each byte;
  *  - pasted: the whole session in one go, one byte every 2,170 cycles. That is the board's rate (10 bits at 115200
  *    baud = 2,170 cycles of the 25 MHz clock): the console task must read every byte before the next one arrives,
  *    because the receiver holds only one. (The replies go out faster than on the board, so less is waiting.)
  * About 42 and 67 minutes. Set FREERTOS_RUNS=typed or FREERTOS_RUNS=pasted to run only one.
  */
class FpgaFreeRtosSpec extends AnyFlatSpec with ChiselScalatestTester with Matchers {
  private val Div = 8                   // UART: clock cycles per bit
  private val TypedGap = 400            // typed: idle cycles after each byte
  private val PastedByte = 2170         // pasted: cycles from the start of one byte to the start of the next

  // (bytes sent, reply expected (regular expression) or null, LED afterwards): as tools/uartled_check.py
  private val Session: Seq[(String, String, Int)] = Seq(
    ("red\r",              "LED red\r\n",                     1),
    ("g\r",                "LED green\r\n",                   2),
    ("BLUE\r",             "LED blue\r\n",                    4),
    ("yellow\r",           "LED yellow \\(red\\+green\\)\r\n",  3),
    ("cyan\n",             "LED cyan \\(green\\+blue\\)\r\n",   6),
    ("Magenta\r",          "LED magenta \\(red\\+blue\\)\r\n",  5),
    ("white\r",            "LED white\r\n",                   7),
    ("off\r",              "LED off\r\n",                     0),
    ("red+blue\r",         "LED magenta \\(red\\+blue\\)\r\n",  5),
    ("  Green , blue  \r", "LED cyan \\(green\\+blue\\)\r\n",   6),
    ("110\r",              "LED yellow \\(red\\+green\\)\r\n",  3),
    ("purple\r",           "unknown colour 'purple' \\(type help\\)\r\n", 3),
    ("status\r",           "LED is yellow\r\n",               3),
    ("reX\u007fd\r",       "LED red\r\n",                     1),
    ("\u001b[Ab\r",        "LED blue\r\n",                    4),
    ("\r",                 null,                              4),
    ("help\r",             "(?s)Commands \\(.*?this list\r\n", 4),
    ("w\r\n",              "LED white\r\n",                   7),
    ("xyz\u0015o\r",       "LED off\r\n",                     0)
  )
  private val Prompt = "> "

  private def runSession(pasted: Boolean): Unit = {
    val firmware = FpgaMap.readHex("firmware/freertos.hex")
    test(new IceSugarSoC(firmware, Div, mtimeDiv = 1, mtimeInc = 1)).withAnnotations(TestUtil.waves) { c =>
      c.clock.setTimeout(0)
      c.io.uartRx.poke(true.B)
      val uart = new StringBuilder
      var rxBusy = false; var cnt = 0; var bit = 0; var shift = 0          // decoder of uartTx
      var led = 0
      val changes = scala.collection.mutable.ArrayBuffer.empty[(Long, Int)]
      var cycle = 0L
      var txBits: List[Boolean] = Nil                                       // bits still to send on uartRx
      var rxPin = true                                                      // poked only when it changes (faster)
      var prompts = 0                                                       // "> " seen so far

      def step(): Unit = {
        val tx = c.io.uartTx.peek().litToBoolean
        if (!rxBusy) { if (!tx) { rxBusy = true; cnt = Div + Div / 2 - 1; bit = 0; shift = 0 } }
        else if (cnt == 0) {
          if (bit < 8) { shift |= (if (tx) 1 << bit else 0); bit += 1; cnt = Div - 1 }
          else {
            tx shouldBe true
            if (shift.toChar == ' ' && uart.nonEmpty && uart.last == '>') prompts += 1
            uart += shift.toChar; rxBusy = false
          }
        } else cnt -= 1
        val l = c.io.led.peek().litValue.toInt
        if (l != led) { changes += ((cycle, l)); led = l }
        val pin = txBits match { case b :: rest => txBits = rest; b; case Nil => true }
        if (pin != rxPin) { c.io.uartRx.poke(pin.B); rxPin = pin }
        c.clock.step()
        cycle += 1
        if (cycle % 20000 == 0) {                                           // progress, on the console
          val tail = uart.takeRight(40).toString.replace("\r", "\\r").replace("\n", "\\n")
          println(f"  cycle $cycle%7d: ${uart.length}%4d bytes out, LED $led, last: $tail")
        }
      }
      def frame(ch: Char): List[Boolean] =
        (false :: (0 until 8).map(k => ((ch >> k) & 1) == 1).toList ::: List(true)).flatMap(b => List.fill(Div)(b))
      def until(limit: Long)(cond: => Boolean): Unit = {
        while (!cond) {
          step()
          if (cycle > limit) fail(s"time limit at cycle $cycle; UART so far:\n$uart")
        }
      }

      val t0 = System.nanoTime()
      val limit = if (pasted) 600000L else 400000L
      until(limit)(prompts >= 1)
      val tStart = cycle
      info(s"banner and first prompt after $cycle cycles")
      if (!pasted) {
        for (((line, _, _), k) <- Session.zipWithIndex) {
          until(limit)(prompts >= k + 1)
          for (ch <- line) { txBits = frame(ch); until(limit)(txBits.isEmpty); for (_ <- 0 until TypedGap) step() }
        }
      } else {
        for (ch <- Session.map(_._1).mkString) {
          val t = cycle
          txBits = frame(ch)
          until(limit)(cycle - t >= PastedByte)
        }
      }
      until(limit)(prompts >= Session.length + 1)
      val tDone = cycle
      for (_ <- 0 until 2000) step()                                        // nothing more may come
      val secs = (System.nanoTime() - t0) / 1e9
      info(f"${if (pasted) "pasted" else "typed"}: session in ${tDone - tStart} cycles; $cycle cycles in $secs%.0f s")
      val text = uart.toString
      info("UART: " + text.replace("\r\n", " | ").replace("\r", "\\r").replace("\b", "<BS>"))

      text should include("RGB LED colour from the terminal")
      var pos = text.indexOf(Prompt) + Prompt.length
      for (((line, reply, _), k) <- Session.zipWithIndex if reply != null) {
        val m = java.util.regex.Pattern.compile(reply).matcher(text)
        withClue(s"line ${k + 1} ${line.replace("\r", "\\r")}: reply /$reply/ after position $pos: ") {
          m.find(pos) shouldBe true
        }
        pos = m.end()
      }
      prompts shouldBe Session.length + 1
      (text.split(java.util.regex.Pattern.quote(Prompt), -1).length - 1) shouldBe prompts
      text should not include "dropped"
      val want = Session.map(_._3).foldLeft((0, Vector.empty[Int])) { case ((l, acc), v) =>
        if (v != l) (v, acc :+ v) else (l, acc)
      }._2
      changes.map(_._2).toVector shouldBe want
      info("LED: " + changes.map { case (t, v) => s"$v at $t" }.mkString(", "))
    }
  }

  private val runs = sys.env.getOrElse("FREERTOS_RUNS", "typed,pasted").split(",").map(_.trim).toSet

  "FreeRTOS" should "set the RGB LED to the colour typed on the terminal" in {
    assume(runs("typed"))
    runSession(pasted = false)
  }
  it should "lose no byte when the whole session is pasted at the board's line rate" in {
    assume(runs("pasted"))
    runSession(pasted = true)
  }
}
