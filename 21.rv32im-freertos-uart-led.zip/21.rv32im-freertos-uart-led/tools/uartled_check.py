"""The test session for the terminal-controlled LED application (firmware/main.c): what is typed, and what must
come back. Used by tools/rvsim.py; the cycle-accurate FpgaFreeRtosSpec sends the same session (in Scala).

Each entry: (bytes sent, the reply expected, the LED value afterwards: bit 0 red, bit 1 green, bit 2 blue).
The reply is matched as a regular expression in the UART output, in order: echoes of what is typed can come in
between (when input is pasted, the next line is echoed while the replies go out), so the check looks for the reply
texts one after the other, and counts the prompts.
"""
import re

SESSION = [
    ("red\r",                 r"LED red\r\n",                       1),
    ("g\r",                   r"LED green\r\n",                     2),
    ("BLUE\r",                r"LED blue\r\n",                      4),
    ("yellow\r",              r"LED yellow \(red\+green\)\r\n",     3),
    ("cyan\n",                r"LED cyan \(green\+blue\)\r\n",      6),    # LF alone ends a line too
    ("Magenta\r",             r"LED magenta \(red\+blue\)\r\n",     5),
    ("white\r",               r"LED white\r\n",                     7),
    ("off\r",                 r"LED off\r\n",                       0),
    ("red+blue\r",            r"LED magenta \(red\+blue\)\r\n",     5),
    ("  Green , blue  \r",    r"LED cyan \(green\+blue\)\r\n",      6),
    ("110\r",                 r"LED yellow \(red\+green\)\r\n",     3),
    ("purple\r",              r"unknown colour 'purple' \(type help\)\r\n", 3),   # LED unchanged
    ("status\r",              r"LED is yellow\r\n",                 3),
    ("reX\x7fd\r",            r"LED red\r\n",                       1),    # DEL deletes the X
    ("\x1b[Ab\r",             r"LED blue\r\n",                      4),    # arrow key (ESC [ A) ignored
    ("\r",                    None,                                 4),    # empty line: only a new prompt
    ("help\r",                r"Commands \(.*?this list\r\n",       4),
    ("w\r\n",                 r"LED white\r\n",                     7),    # CR LF counts as one line end
    ("xyz\x15o\r",            r"LED off\r\n",                       0),    # Ctrl-U deletes the line
]

PROMPT = "> "
BANNER = "RGB LED colour from the terminal"


def expected_changes():
    """The LED values the session must produce, change by change (from off at reset)."""
    out, led = [], 0
    for _, _, v in SESSION:
        if v != led:
            out.append(v)
            led = v
    return out


def check(uart, led_values):
    """uart: everything the system sent; led_values: the LED value after each change. Returns (ok, report)."""
    report, ok = [], True

    def fail(msg):
        nonlocal ok
        ok = False
        report.append("FAIL: " + msg)

    if BANNER not in uart:
        fail("no start-up banner")
    start = uart.find(PROMPT)
    if start < 0:
        fail("no prompt")
        return ok, report
    pos = start + len(PROMPT)
    for k, (typed, reply, _) in enumerate(SESSION):
        if reply is None:
            continue
        m = re.compile(reply, re.S).search(uart, pos)
        if m is None:
            fail("line %d %r: reply %r not found" % (k + 1, typed, reply))
            break
        pos = m.end()
    prompts = uart.count(PROMPT)
    if prompts != len(SESSION) + 1:
        fail("%d prompts, expected %d (one at start-up, one per line)" % (prompts, len(SESSION) + 1))
    want = expected_changes()
    if led_values != want:
        fail("LED changes %s, expected %s" % (led_values, want))
    if "dropped" in uart:
        fail("a line was dropped")
    report.append("%d lines, %d replies found in order, %d prompts, LED changes %s" %
                  (len(SESSION), sum(1 for s in SESSION if s[1]), prompts, led_values))
    return ok, report
