FIRRTL version 1.2.0
circuit ICache :
  module ICache :
    input clock : Clock
    input reset : UInt<1>
    input io_addr : UInt<32> @[src/main/scala/rv32i/ICache.scala 16:14]
    output io_data : UInt<32> @[src/main/scala/rv32i/ICache.scala 16:14]
    output io_busy : UInt<1> @[src/main/scala/rv32i/ICache.scala 16:14]
    input io_advance : UInt<1> @[src/main/scala/rv32i/ICache.scala 16:14]
    input io_mem_req_ready : UInt<1> @[src/main/scala/rv32i/ICache.scala 16:14]
    output io_mem_req_valid : UInt<1> @[src/main/scala/rv32i/ICache.scala 16:14]
    output io_mem_req_bits_addr : UInt<32> @[src/main/scala/rv32i/ICache.scala 16:14]
    output io_mem_req_bits_write : UInt<1> @[src/main/scala/rv32i/ICache.scala 16:14]
    output io_mem_req_bits_wdata : UInt<32> @[src/main/scala/rv32i/ICache.scala 16:14]
    output io_mem_req_bits_wstrb : UInt<4> @[src/main/scala/rv32i/ICache.scala 16:14]
    input io_mem_resp_valid : UInt<1> @[src/main/scala/rv32i/ICache.scala 16:14]
    input io_mem_resp_bits_line_0 : UInt<32> @[src/main/scala/rv32i/ICache.scala 16:14]
    input io_mem_resp_bits_line_1 : UInt<32> @[src/main/scala/rv32i/ICache.scala 16:14]
    input io_mem_resp_bits_line_2 : UInt<32> @[src/main/scala/rv32i/ICache.scala 16:14]
    input io_mem_resp_bits_line_3 : UInt<32> @[src/main/scala/rv32i/ICache.scala 16:14]
    output io_stats_accesses : UInt<32> @[src/main/scala/rv32i/ICache.scala 16:14]
    output io_stats_misses : UInt<32> @[src/main/scala/rv32i/ICache.scala 16:14]
    output io_stats_writes : UInt<32> @[src/main/scala/rv32i/ICache.scala 16:14]

    mem tags : @[src/main/scala/rv32i/ICache.scala 27:18]
      data-type => UInt<24>
      depth => 16
      read-latency => 0
      write-latency => 1
      reader => hit_MPORT
      writer => MPORT_1
      read-under-write => undefined
    mem lines_0 : @[src/main/scala/rv32i/ICache.scala 28:18]
      data-type => UInt<32>
      depth => 16
      read-latency => 0
      write-latency => 1
      reader => io_data_MPORT
      writer => MPORT
      read-under-write => undefined
    mem lines_1 : @[src/main/scala/rv32i/ICache.scala 28:18]
      data-type => UInt<32>
      depth => 16
      read-latency => 0
      write-latency => 1
      reader => io_data_MPORT
      writer => MPORT
      read-under-write => undefined
    mem lines_2 : @[src/main/scala/rv32i/ICache.scala 28:18]
      data-type => UInt<32>
      depth => 16
      read-latency => 0
      write-latency => 1
      reader => io_data_MPORT
      writer => MPORT
      read-under-write => undefined
    mem lines_3 : @[src/main/scala/rv32i/ICache.scala 28:18]
      data-type => UInt<32>
      depth => 16
      read-latency => 0
      write-latency => 1
      reader => io_data_MPORT
      writer => MPORT
      read-under-write => undefined
    reg valid_0 : UInt<1>, clock with :
      reset => (UInt<1>("h0"), valid_0) @[src/main/scala/rv32i/ICache.scala 26:22]
    reg valid_1 : UInt<1>, clock with :
      reset => (UInt<1>("h0"), valid_1) @[src/main/scala/rv32i/ICache.scala 26:22]
    reg valid_2 : UInt<1>, clock with :
      reset => (UInt<1>("h0"), valid_2) @[src/main/scala/rv32i/ICache.scala 26:22]
    reg valid_3 : UInt<1>, clock with :
      reset => (UInt<1>("h0"), valid_3) @[src/main/scala/rv32i/ICache.scala 26:22]
    reg valid_4 : UInt<1>, clock with :
      reset => (UInt<1>("h0"), valid_4) @[src/main/scala/rv32i/ICache.scala 26:22]
    reg valid_5 : UInt<1>, clock with :
      reset => (UInt<1>("h0"), valid_5) @[src/main/scala/rv32i/ICache.scala 26:22]
    reg valid_6 : UInt<1>, clock with :
      reset => (UInt<1>("h0"), valid_6) @[src/main/scala/rv32i/ICache.scala 26:22]
    reg valid_7 : UInt<1>, clock with :
      reset => (UInt<1>("h0"), valid_7) @[src/main/scala/rv32i/ICache.scala 26:22]
    reg valid_8 : UInt<1>, clock with :
      reset => (UInt<1>("h0"), valid_8) @[src/main/scala/rv32i/ICache.scala 26:22]
    reg valid_9 : UInt<1>, clock with :
      reset => (UInt<1>("h0"), valid_9) @[src/main/scala/rv32i/ICache.scala 26:22]
    reg valid_10 : UInt<1>, clock with :
      reset => (UInt<1>("h0"), valid_10) @[src/main/scala/rv32i/ICache.scala 26:22]
    reg valid_11 : UInt<1>, clock with :
      reset => (UInt<1>("h0"), valid_11) @[src/main/scala/rv32i/ICache.scala 26:22]
    reg valid_12 : UInt<1>, clock with :
      reset => (UInt<1>("h0"), valid_12) @[src/main/scala/rv32i/ICache.scala 26:22]
    reg valid_13 : UInt<1>, clock with :
      reset => (UInt<1>("h0"), valid_13) @[src/main/scala/rv32i/ICache.scala 26:22]
    reg valid_14 : UInt<1>, clock with :
      reset => (UInt<1>("h0"), valid_14) @[src/main/scala/rv32i/ICache.scala 26:22]
    reg valid_15 : UInt<1>, clock with :
      reset => (UInt<1>("h0"), valid_15) @[src/main/scala/rv32i/ICache.scala 26:22]
    node index = bits(io_addr, 7, 4) @[src/main/scala/rv32i/ICache.scala 30:22]
    node tag = bits(io_addr, 31, 8) @[src/main/scala/rv32i/ICache.scala 31:22]
    node word = bits(io_addr, 3, 2) @[src/main/scala/rv32i/ICache.scala 32:40]
    node _hit_T = eq(tags.hit_MPORT.data, tag) @[src/main/scala/rv32i/ICache.scala 33:43]
    node _GEN_0 = validif(eq(UInt<1>("h0"), index), valid_0) @[src/main/scala/rv32i/ICache.scala 33:{28,28}]
    node _GEN_1 = mux(eq(UInt<1>("h1"), index), valid_1, _GEN_0) @[src/main/scala/rv32i/ICache.scala 33:{28,28}]
    node _GEN_2 = mux(eq(UInt<2>("h2"), index), valid_2, _GEN_1) @[src/main/scala/rv32i/ICache.scala 33:{28,28}]
    node _GEN_3 = mux(eq(UInt<2>("h3"), index), valid_3, _GEN_2) @[src/main/scala/rv32i/ICache.scala 33:{28,28}]
    node _GEN_4 = mux(eq(UInt<3>("h4"), index), valid_4, _GEN_3) @[src/main/scala/rv32i/ICache.scala 33:{28,28}]
    node _GEN_5 = mux(eq(UInt<3>("h5"), index), valid_5, _GEN_4) @[src/main/scala/rv32i/ICache.scala 33:{28,28}]
    node _GEN_6 = mux(eq(UInt<3>("h6"), index), valid_6, _GEN_5) @[src/main/scala/rv32i/ICache.scala 33:{28,28}]
    node _GEN_7 = mux(eq(UInt<3>("h7"), index), valid_7, _GEN_6) @[src/main/scala/rv32i/ICache.scala 33:{28,28}]
    node _GEN_8 = mux(eq(UInt<4>("h8"), index), valid_8, _GEN_7) @[src/main/scala/rv32i/ICache.scala 33:{28,28}]
    node _GEN_9 = mux(eq(UInt<4>("h9"), index), valid_9, _GEN_8) @[src/main/scala/rv32i/ICache.scala 33:{28,28}]
    node _GEN_10 = mux(eq(UInt<4>("ha"), index), valid_10, _GEN_9) @[src/main/scala/rv32i/ICache.scala 33:{28,28}]
    node _GEN_11 = mux(eq(UInt<4>("hb"), index), valid_11, _GEN_10) @[src/main/scala/rv32i/ICache.scala 33:{28,28}]
    node _GEN_12 = mux(eq(UInt<4>("hc"), index), valid_12, _GEN_11) @[src/main/scala/rv32i/ICache.scala 33:{28,28}]
    node _GEN_13 = mux(eq(UInt<4>("hd"), index), valid_13, _GEN_12) @[src/main/scala/rv32i/ICache.scala 33:{28,28}]
    node _GEN_14 = mux(eq(UInt<4>("he"), index), valid_14, _GEN_13) @[src/main/scala/rv32i/ICache.scala 33:{28,28}]
    node _GEN_15 = mux(eq(UInt<4>("hf"), index), valid_15, _GEN_14) @[src/main/scala/rv32i/ICache.scala 33:{28,28}]
    node _valid_index = _GEN_15 @[src/main/scala/rv32i/ICache.scala 33:28]
    node hit = and(_valid_index, _hit_T) @[src/main/scala/rv32i/ICache.scala 33:28]
    reg state : UInt<1>, clock with :
      reset => (UInt<1>("h0"), state) @[src/main/scala/rv32i/ICache.scala 36:24]
    reg fillIdx : UInt<4>, clock with :
      reset => (UInt<1>("h0"), fillIdx) @[src/main/scala/rv32i/ICache.scala 37:20]
    reg fillTag : UInt<24>, clock with :
      reset => (UInt<1>("h0"), fillTag) @[src/main/scala/rv32i/ICache.scala 38:20]
    node _GEN_16 = validif(eq(UInt<1>("h0"), word), lines_0.io_data_MPORT.data) @[src/main/scala/rv32i/ICache.scala 40:{11,11}]
    node _GEN_17 = mux(eq(UInt<1>("h1"), word), lines_1.io_data_MPORT.data, _GEN_16) @[src/main/scala/rv32i/ICache.scala 40:{11,11}]
    node _GEN_18 = mux(eq(UInt<2>("h2"), word), lines_2.io_data_MPORT.data, _GEN_17) @[src/main/scala/rv32i/ICache.scala 40:{11,11}]
    node _GEN_19 = mux(eq(UInt<2>("h3"), word), lines_3.io_data_MPORT.data, _GEN_18) @[src/main/scala/rv32i/ICache.scala 40:{11,11}]
    node _io_busy_T = neq(state, UInt<1>("h0")) @[src/main/scala/rv32i/ICache.scala 41:20]
    node _io_busy_T_1 = eq(hit, UInt<1>("h0")) @[src/main/scala/rv32i/ICache.scala 41:33]
    node _io_busy_T_2 = or(_io_busy_T, _io_busy_T_1) @[src/main/scala/rv32i/ICache.scala 41:30]
    node _io_mem_req_valid_T = eq(state, UInt<1>("h0")) @[src/main/scala/rv32i/ICache.scala 43:34]
    node _io_mem_req_valid_T_1 = eq(hit, UInt<1>("h0")) @[src/main/scala/rv32i/ICache.scala 43:47]
    node _io_mem_req_valid_T_2 = and(_io_mem_req_valid_T, _io_mem_req_valid_T_1) @[src/main/scala/rv32i/ICache.scala 43:44]
    node _io_mem_req_bits_addr_T = bits(io_addr, 31, 4) @[src/main/scala/rv32i/ICache.scala 44:39]
    node _io_mem_req_bits_addr_T_1 = cat(_io_mem_req_bits_addr_T, UInt<4>("h0")) @[src/main/scala/rv32i/ICache.scala 44:31]
    node _T = and(io_mem_req_ready, io_mem_req_valid) @[src/main/scala/chisel3/util/Decoupled.scala 57:35]
    node _GEN_20 = mux(_T, UInt<1>("h1"), state) @[src/main/scala/rv32i/ICache.scala 49:25 50:13 36:24]
    node _GEN_21 = mux(_T, index, fillIdx) @[src/main/scala/rv32i/ICache.scala 49:25 51:13 37:20]
    node _GEN_22 = mux(_T, tag, fillTag) @[src/main/scala/rv32i/ICache.scala 49:25 52:13 38:20]
    node _T_1 = eq(state, UInt<1>("h1")) @[src/main/scala/rv32i/ICache.scala 54:14]
    node _T_2 = and(_T_1, io_mem_resp_valid) @[src/main/scala/rv32i/ICache.scala 54:24]
    node _valid_fillIdx = UInt<1>("h1") @[src/main/scala/rv32i/ICache.scala 57:{20,20}]
    node _GEN_23 = mux(eq(UInt<1>("h0"), fillIdx), _valid_fillIdx, valid_0) @[src/main/scala/rv32i/ICache.scala 57:{20,20} 26:22]
    node _GEN_24 = mux(eq(UInt<1>("h1"), fillIdx), _valid_fillIdx, valid_1) @[src/main/scala/rv32i/ICache.scala 57:{20,20} 26:22]
    node _GEN_25 = mux(eq(UInt<2>("h2"), fillIdx), _valid_fillIdx, valid_2) @[src/main/scala/rv32i/ICache.scala 57:{20,20} 26:22]
    node _GEN_26 = mux(eq(UInt<2>("h3"), fillIdx), _valid_fillIdx, valid_3) @[src/main/scala/rv32i/ICache.scala 57:{20,20} 26:22]
    node _GEN_27 = mux(eq(UInt<3>("h4"), fillIdx), _valid_fillIdx, valid_4) @[src/main/scala/rv32i/ICache.scala 57:{20,20} 26:22]
    node _GEN_28 = mux(eq(UInt<3>("h5"), fillIdx), _valid_fillIdx, valid_5) @[src/main/scala/rv32i/ICache.scala 57:{20,20} 26:22]
    node _GEN_29 = mux(eq(UInt<3>("h6"), fillIdx), _valid_fillIdx, valid_6) @[src/main/scala/rv32i/ICache.scala 57:{20,20} 26:22]
    node _GEN_30 = mux(eq(UInt<3>("h7"), fillIdx), _valid_fillIdx, valid_7) @[src/main/scala/rv32i/ICache.scala 57:{20,20} 26:22]
    node _GEN_31 = mux(eq(UInt<4>("h8"), fillIdx), _valid_fillIdx, valid_8) @[src/main/scala/rv32i/ICache.scala 57:{20,20} 26:22]
    node _GEN_32 = mux(eq(UInt<4>("h9"), fillIdx), _valid_fillIdx, valid_9) @[src/main/scala/rv32i/ICache.scala 57:{20,20} 26:22]
    node _GEN_33 = mux(eq(UInt<4>("ha"), fillIdx), _valid_fillIdx, valid_10) @[src/main/scala/rv32i/ICache.scala 57:{20,20} 26:22]
    node _GEN_34 = mux(eq(UInt<4>("hb"), fillIdx), _valid_fillIdx, valid_11) @[src/main/scala/rv32i/ICache.scala 57:{20,20} 26:22]
    node _GEN_35 = mux(eq(UInt<4>("hc"), fillIdx), _valid_fillIdx, valid_12) @[src/main/scala/rv32i/ICache.scala 57:{20,20} 26:22]
    node _GEN_36 = mux(eq(UInt<4>("hd"), fillIdx), _valid_fillIdx, valid_13) @[src/main/scala/rv32i/ICache.scala 57:{20,20} 26:22]
    node _GEN_37 = mux(eq(UInt<4>("he"), fillIdx), _valid_fillIdx, valid_14) @[src/main/scala/rv32i/ICache.scala 57:{20,20} 26:22]
    node _GEN_38 = mux(eq(UInt<4>("hf"), fillIdx), _valid_fillIdx, valid_15) @[src/main/scala/rv32i/ICache.scala 57:{20,20} 26:22]
    node _GEN_39 = validif(_T_2, fillIdx) @[src/main/scala/rv32i/ICache.scala 54:46 55:10]
    node _GEN_40 = validif(_T_2, clock) @[src/main/scala/rv32i/ICache.scala 54:46 55:10]
    node _GEN_41 = mux(_T_2, UInt<1>("h1"), UInt<1>("h0")) @[src/main/scala/rv32i/ICache.scala 54:46 55:10 28:18]
    node _GEN_42 = validif(_T_2, UInt<1>("h1")) @[src/main/scala/rv32i/ICache.scala 54:46 55:20]
    node _GEN_43 = validif(_T_2, io_mem_resp_bits_line_0) @[src/main/scala/rv32i/ICache.scala 54:46 55:20]
    node _GEN_44 = validif(_T_2, io_mem_resp_bits_line_1) @[src/main/scala/rv32i/ICache.scala 54:46 55:20]
    node _GEN_45 = validif(_T_2, io_mem_resp_bits_line_2) @[src/main/scala/rv32i/ICache.scala 54:46 55:20]
    node _GEN_46 = validif(_T_2, io_mem_resp_bits_line_3) @[src/main/scala/rv32i/ICache.scala 54:46 55:20]
    node _GEN_47 = validif(_T_2, fillTag) @[src/main/scala/rv32i/ICache.scala 54:46 56:20]
    node _GEN_48 = mux(_T_2, _GEN_23, valid_0) @[src/main/scala/rv32i/ICache.scala 26:22 54:46]
    node _GEN_49 = mux(_T_2, _GEN_24, valid_1) @[src/main/scala/rv32i/ICache.scala 26:22 54:46]
    node _GEN_50 = mux(_T_2, _GEN_25, valid_2) @[src/main/scala/rv32i/ICache.scala 26:22 54:46]
    node _GEN_51 = mux(_T_2, _GEN_26, valid_3) @[src/main/scala/rv32i/ICache.scala 26:22 54:46]
    node _GEN_52 = mux(_T_2, _GEN_27, valid_4) @[src/main/scala/rv32i/ICache.scala 26:22 54:46]
    node _GEN_53 = mux(_T_2, _GEN_28, valid_5) @[src/main/scala/rv32i/ICache.scala 26:22 54:46]
    node _GEN_54 = mux(_T_2, _GEN_29, valid_6) @[src/main/scala/rv32i/ICache.scala 26:22 54:46]
    node _GEN_55 = mux(_T_2, _GEN_30, valid_7) @[src/main/scala/rv32i/ICache.scala 26:22 54:46]
    node _GEN_56 = mux(_T_2, _GEN_31, valid_8) @[src/main/scala/rv32i/ICache.scala 26:22 54:46]
    node _GEN_57 = mux(_T_2, _GEN_32, valid_9) @[src/main/scala/rv32i/ICache.scala 26:22 54:46]
    node _GEN_58 = mux(_T_2, _GEN_33, valid_10) @[src/main/scala/rv32i/ICache.scala 26:22 54:46]
    node _GEN_59 = mux(_T_2, _GEN_34, valid_11) @[src/main/scala/rv32i/ICache.scala 26:22 54:46]
    node _GEN_60 = mux(_T_2, _GEN_35, valid_12) @[src/main/scala/rv32i/ICache.scala 26:22 54:46]
    node _GEN_61 = mux(_T_2, _GEN_36, valid_13) @[src/main/scala/rv32i/ICache.scala 26:22 54:46]
    node _GEN_62 = mux(_T_2, _GEN_37, valid_14) @[src/main/scala/rv32i/ICache.scala 26:22 54:46]
    node _GEN_63 = mux(_T_2, _GEN_38, valid_15) @[src/main/scala/rv32i/ICache.scala 26:22 54:46]
    node _GEN_64 = mux(_T_2, UInt<1>("h0"), _GEN_20) @[src/main/scala/rv32i/ICache.scala 54:46 58:11]
    reg accesses : UInt<32>, clock with :
      reset => (UInt<1>("h0"), accesses) @[src/main/scala/rv32i/ICache.scala 62:25]
    reg misses : UInt<32>, clock with :
      reset => (UInt<1>("h0"), misses) @[src/main/scala/rv32i/ICache.scala 63:25]
    node _T_3 = eq(io_busy, UInt<1>("h0")) @[src/main/scala/rv32i/ICache.scala 64:8]
    node _T_4 = and(_T_3, io_advance) @[src/main/scala/rv32i/ICache.scala 64:17]
    node _accesses_T = add(accesses, UInt<1>("h1")) @[src/main/scala/rv32i/ICache.scala 64:55]
    node _accesses_T_1 = tail(_accesses_T, 1) @[src/main/scala/rv32i/ICache.scala 64:55]
    node _GEN_65 = mux(_T_4, _accesses_T_1, accesses) @[src/main/scala/rv32i/ICache.scala 62:25 64:{32,43}]
    node _T_5 = and(io_mem_req_ready, io_mem_req_valid) @[src/main/scala/chisel3/util/Decoupled.scala 57:35]
    node _misses_T = add(misses, UInt<1>("h1")) @[src/main/scala/rv32i/ICache.scala 65:44]
    node _misses_T_1 = tail(_misses_T, 1) @[src/main/scala/rv32i/ICache.scala 65:44]
    node _GEN_66 = mux(_T_5, _misses_T_1, misses) @[src/main/scala/rv32i/ICache.scala 63:25 65:{25,34}]
    node _valid_WIRE_0 = UInt<1>("h0") @[src/main/scala/rv32i/ICache.scala 26:{30,30}]
    node _valid_WIRE_1 = UInt<1>("h0") @[src/main/scala/rv32i/ICache.scala 26:{30,30}]
    node _valid_WIRE_2 = UInt<1>("h0") @[src/main/scala/rv32i/ICache.scala 26:{30,30}]
    node _valid_WIRE_3 = UInt<1>("h0") @[src/main/scala/rv32i/ICache.scala 26:{30,30}]
    node _valid_WIRE_4 = UInt<1>("h0") @[src/main/scala/rv32i/ICache.scala 26:{30,30}]
    node _valid_WIRE_5 = UInt<1>("h0") @[src/main/scala/rv32i/ICache.scala 26:{30,30}]
    node _valid_WIRE_6 = UInt<1>("h0") @[src/main/scala/rv32i/ICache.scala 26:{30,30}]
    node _valid_WIRE_7 = UInt<1>("h0") @[src/main/scala/rv32i/ICache.scala 26:{30,30}]
    node _valid_WIRE_8 = UInt<1>("h0") @[src/main/scala/rv32i/ICache.scala 26:{30,30}]
    node _valid_WIRE_9 = UInt<1>("h0") @[src/main/scala/rv32i/ICache.scala 26:{30,30}]
    node _valid_WIRE_10 = UInt<1>("h0") @[src/main/scala/rv32i/ICache.scala 26:{30,30}]
    node _valid_WIRE_11 = UInt<1>("h0") @[src/main/scala/rv32i/ICache.scala 26:{30,30}]
    node _valid_WIRE_12 = UInt<1>("h0") @[src/main/scala/rv32i/ICache.scala 26:{30,30}]
    node _valid_WIRE_13 = UInt<1>("h0") @[src/main/scala/rv32i/ICache.scala 26:{30,30}]
    node _valid_WIRE_14 = UInt<1>("h0") @[src/main/scala/rv32i/ICache.scala 26:{30,30}]
    node _valid_WIRE_15 = UInt<1>("h0") @[src/main/scala/rv32i/ICache.scala 26:{30,30}]
    node _lines_io_data_MPORT_data_word = _GEN_19 @[src/main/scala/rv32i/ICache.scala 40:11]
    io_data <= _lines_io_data_MPORT_data_word @[src/main/scala/rv32i/ICache.scala 40:11]
    io_busy <= _io_busy_T_2 @[src/main/scala/rv32i/ICache.scala 41:11]
    io_mem_req_valid <= _io_mem_req_valid_T_2 @[src/main/scala/rv32i/ICache.scala 43:25]
    io_mem_req_bits_addr <= _io_mem_req_bits_addr_T_1 @[src/main/scala/rv32i/ICache.scala 44:25]
    io_mem_req_bits_write <= UInt<1>("h0") @[src/main/scala/rv32i/ICache.scala 45:25]
    io_mem_req_bits_wdata <= UInt<32>("h0") @[src/main/scala/rv32i/ICache.scala 46:25]
    io_mem_req_bits_wstrb <= UInt<4>("h0") @[src/main/scala/rv32i/ICache.scala 47:25]
    io_stats_accesses <= accesses @[src/main/scala/rv32i/ICache.scala 66:21]
    io_stats_misses <= misses @[src/main/scala/rv32i/ICache.scala 67:21]
    io_stats_writes <= UInt<32>("h0") @[src/main/scala/rv32i/ICache.scala 68:21]
    valid_0 <= mux(reset, _valid_WIRE_0, _GEN_48) @[src/main/scala/rv32i/ICache.scala 26:{22,22}]
    valid_1 <= mux(reset, _valid_WIRE_1, _GEN_49) @[src/main/scala/rv32i/ICache.scala 26:{22,22}]
    valid_2 <= mux(reset, _valid_WIRE_2, _GEN_50) @[src/main/scala/rv32i/ICache.scala 26:{22,22}]
    valid_3 <= mux(reset, _valid_WIRE_3, _GEN_51) @[src/main/scala/rv32i/ICache.scala 26:{22,22}]
    valid_4 <= mux(reset, _valid_WIRE_4, _GEN_52) @[src/main/scala/rv32i/ICache.scala 26:{22,22}]
    valid_5 <= mux(reset, _valid_WIRE_5, _GEN_53) @[src/main/scala/rv32i/ICache.scala 26:{22,22}]
    valid_6 <= mux(reset, _valid_WIRE_6, _GEN_54) @[src/main/scala/rv32i/ICache.scala 26:{22,22}]
    valid_7 <= mux(reset, _valid_WIRE_7, _GEN_55) @[src/main/scala/rv32i/ICache.scala 26:{22,22}]
    valid_8 <= mux(reset, _valid_WIRE_8, _GEN_56) @[src/main/scala/rv32i/ICache.scala 26:{22,22}]
    valid_9 <= mux(reset, _valid_WIRE_9, _GEN_57) @[src/main/scala/rv32i/ICache.scala 26:{22,22}]
    valid_10 <= mux(reset, _valid_WIRE_10, _GEN_58) @[src/main/scala/rv32i/ICache.scala 26:{22,22}]
    valid_11 <= mux(reset, _valid_WIRE_11, _GEN_59) @[src/main/scala/rv32i/ICache.scala 26:{22,22}]
    valid_12 <= mux(reset, _valid_WIRE_12, _GEN_60) @[src/main/scala/rv32i/ICache.scala 26:{22,22}]
    valid_13 <= mux(reset, _valid_WIRE_13, _GEN_61) @[src/main/scala/rv32i/ICache.scala 26:{22,22}]
    valid_14 <= mux(reset, _valid_WIRE_14, _GEN_62) @[src/main/scala/rv32i/ICache.scala 26:{22,22}]
    valid_15 <= mux(reset, _valid_WIRE_15, _GEN_63) @[src/main/scala/rv32i/ICache.scala 26:{22,22}]
    tags.hit_MPORT.addr <= index @[src/main/scala/rv32i/ICache.scala 33:35]
    tags.hit_MPORT.en <= UInt<1>("h1") @[src/main/scala/rv32i/ICache.scala 33:35]
    tags.hit_MPORT.clk <= clock @[src/main/scala/rv32i/ICache.scala 33:35]
    tags.MPORT_1.addr <= _GEN_39
    tags.MPORT_1.en <= _GEN_41
    tags.MPORT_1.clk <= _GEN_40
    tags.MPORT_1.data <= _GEN_47
    tags.MPORT_1.mask <= _GEN_42
    lines_0.io_data_MPORT.addr <= index @[src/main/scala/rv32i/ICache.scala 40:19]
    lines_1.io_data_MPORT.addr <= index @[src/main/scala/rv32i/ICache.scala 40:19]
    lines_2.io_data_MPORT.addr <= index @[src/main/scala/rv32i/ICache.scala 40:19]
    lines_3.io_data_MPORT.addr <= index @[src/main/scala/rv32i/ICache.scala 40:19]
    lines_0.io_data_MPORT.en <= UInt<1>("h1") @[src/main/scala/rv32i/ICache.scala 40:19]
    lines_1.io_data_MPORT.en <= UInt<1>("h1") @[src/main/scala/rv32i/ICache.scala 40:19]
    lines_2.io_data_MPORT.en <= UInt<1>("h1") @[src/main/scala/rv32i/ICache.scala 40:19]
    lines_3.io_data_MPORT.en <= UInt<1>("h1") @[src/main/scala/rv32i/ICache.scala 40:19]
    lines_0.io_data_MPORT.clk <= clock @[src/main/scala/rv32i/ICache.scala 40:19]
    lines_1.io_data_MPORT.clk <= clock @[src/main/scala/rv32i/ICache.scala 40:19]
    lines_2.io_data_MPORT.clk <= clock @[src/main/scala/rv32i/ICache.scala 40:19]
    lines_3.io_data_MPORT.clk <= clock @[src/main/scala/rv32i/ICache.scala 40:19]
    lines_0.MPORT.addr <= _GEN_39
    lines_1.MPORT.addr <= _GEN_39
    lines_2.MPORT.addr <= _GEN_39
    lines_3.MPORT.addr <= _GEN_39
    lines_0.MPORT.en <= _GEN_41
    lines_1.MPORT.en <= _GEN_41
    lines_2.MPORT.en <= _GEN_41
    lines_3.MPORT.en <= _GEN_41
    lines_0.MPORT.clk <= _GEN_40
    lines_1.MPORT.clk <= _GEN_40
    lines_2.MPORT.clk <= _GEN_40
    lines_3.MPORT.clk <= _GEN_40
    lines_0.MPORT.data <= _GEN_43
    lines_1.MPORT.data <= _GEN_44
    lines_2.MPORT.data <= _GEN_45
    lines_3.MPORT.data <= _GEN_46
    lines_0.MPORT.mask <= _GEN_42
    lines_1.MPORT.mask <= _GEN_42
    lines_2.MPORT.mask <= _GEN_42
    lines_3.MPORT.mask <= _GEN_42
    state <= mux(reset, UInt<1>("h0"), _GEN_64) @[src/main/scala/rv32i/ICache.scala 36:{24,24}]
    fillIdx <= _GEN_21
    fillTag <= _GEN_22
    accesses <= mux(reset, UInt<32>("h0"), _GEN_65) @[src/main/scala/rv32i/ICache.scala 62:{25,25}]
    misses <= mux(reset, UInt<32>("h0"), _GEN_66) @[src/main/scala/rv32i/ICache.scala 63:{25,25}]
