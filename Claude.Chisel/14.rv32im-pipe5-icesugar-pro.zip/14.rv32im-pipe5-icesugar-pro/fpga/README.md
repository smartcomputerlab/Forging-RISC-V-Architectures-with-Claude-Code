# RV32IM 5-stage pipeline (Stage 7) on the iCESugar-Pro

The Stage 7 5-stage pipelined RV32IM core (IF, ID, EX, MEM, WB with forwarding; RV32I, the M extension with a
combinational multiplier and a sequential divider, Zicsr, machine-mode traps), unchanged, in the same small system as
the Stage 3 board project (same memory map, RGB LED register and UART), for the **iCESugar-Pro** (Lattice ECP5
**LFE5U-25F-6BG256C**), built with the open-source flow Chisel → Yosys → nextpnr-ecp5 → ecppack.

The demo program prints a banner and 12! (computed with MUL, printed in decimal with DIVU and REMU) on the USB
serial port, echoes what you type, shows the low three bits of each typed
character on the RGB LED. Until you type the first character, the LED steps through its eight colours every half
second; from then on it keeps the colour of the last character typed.

A ready-made bitstream is included: `IceSugarProTop.bit`.

## 1. Quick start with the ready-made bitstream

1. Connect the iCESugar-Pro with a USB-C cable. The on-board iCELink shows up as a USB drive called **iCELink** and as
   a serial port (`/dev/ttyACM0` on Linux, `COMx` on Windows, `/dev/cu.usbmodem…` on macOS).
2. Open a terminal on the serial port at **115200 baud, 8N1**, no flow control, *before* programming (the banner is
   printed once, right after the FPGA starts):

```bash
picocom -b 115200 /dev/ttyACM0
```

   On Windows use PuTTY or Tera Term.
3. Copy `IceSugarProTop.bit` onto the iCELink drive (drag and drop). The iCELink programs the FPGA in a few seconds and
   the banner appears (`icesprog IceSugarProTop.bit` does the same from the command line; programming again restarts
   the program):

```
RV32IM, 5-stage pipeline (Stage 7) on iCESugar-Pro: type something, it is echoed and shown on the RGB LED
12! = 479001600 (MUL, printed with DIVU and REMU)
>
```

4. Type: every character comes back, and the LED shows its low three bits (bit 0 red, bit 1 green, bit 2 blue): `a` =
   red, `b` = green, `c` = red + green, `d` = blue, ... Enter starts a new line.

The LED pins and colours were measured on a real board with the LED pin test (`sbt "runMain rv32i.EmitFpgaPinTest"`,
which drives B11/A11/A12 directly and prints each combination): B11 = red, A11 = green, A12 = blue, all active-high.

## 2. The system

| Block | Details |
|---|---|
| Clock | 25 MHz oscillator (P6), used directly: **25 MHz** system clock |
| Reset | Held for 15 cycles after configuration |
| Core | Stage 7 pipelined `Core`, reset pc 0x80000000: one instruction per clock, +1 per load-use, +2 per taken branch/jump, +33 per division |
| Instruction ROM | 1 KiB (256 words) at 0x80000000, a constant table in LUTs, built from the program at generation time |
| Data RAM | 4 KiB at 0x80010000, accessed in MEM; Yosys maps it to 4 block RAMs (DP16KD), the EX/MEM address register becoming their read address register |
| LEDs | RGB LED: red B11, green A11, blue A12, active-high |
| UART | 115200 baud 8N1 on the iCELink USB serial port: FPGA TX = B9, FPGA RX = A9 |

Memory-mapped I/O at 0x10000000:

| Address | Register | Access |
|---|---|---|
| 0x10000000 | LED: bits 2:0 = {blue, green, red}, 1 = on | read/write |
| 0x10000004 | UART_TX: write a byte to send (only when UART_STATUS bit 0 = 1) | write |
| 0x10000008 | UART_STATUS: bit 0 = transmitter ready, bit 1 = a received byte is waiting | read |
| 0x1000000C | UART_RX: the received byte; reading it clears UART_STATUS bit 1 | read |

The `mcycle` CSR counts clock cycles (25,000,000 per second) and can be used for delays.

The pipeline splits the work of an instruction over five clock cycles, so its longest stage fits easily in the 40 ns of
the 25 MHz oscillator: no PLL is needed (`IceSugarProTop(usePll = true)` still offers 12.5 MHz from `pll25to12p5.v`).

Last build (Yosys 0.71, nextpnr-ecp5 0.11.1): 7,980 LUT4, 304 CCU2C (carry), 1,976 flip-flops, 4 DP16KD block RAMs (the
data RAM), 4 MULT18X18D (the 33 × 33 multiplier), 6 I/O; maximum frequency 37.95 MHz, constraint 25 MHz: **PASS**.

## 3. Building it yourself

Tools:

- Java and sbt (as for the rest of the project), for the Chisel → Verilog step
- Yosys, nextpnr-ecp5 and ecppack: the simplest way is the YosysHQ **oss-cad-suite**
  (https://github.com/YosysHQ/oss-cad-suite-build): download, unpack, then `source oss-cad-suite/environment`
- to program: the iCELink drive (no tool needed), or `icesprog` (https://github.com/wuxx/icesugar, tools folder)

From the `fpga` folder:

```bash
make
```

This runs `sbt "runMain rv32i.EmitFpga"` (Chisel → `build/IceSugarProTop.v`), Yosys (`synth_ecp5`), nextpnr-ecp5
(`--25k --package CABGA256 --speed 6`, pins in `icesugar_pro.lpf`) and ecppack, and leaves `build/IceSugarProTop.bit`.

```bash
make report
```

```bash
make prog ICELINK=/media/$USER/iCELink
```

`make report` shows the resource use and the maximum frequency. `make prog` copies the bitstream onto the iCELink
drive; use the drive's real mount point.

With the Python builds of the tools instead of oss-cad-suite (`pip install yowasp-yosys yowasp-nextpnr-ecp5`):

```bash
make YOWASP=1
```

## 4. Running your own program

The ROM contents are fixed when the Verilog is generated. Write a program for the memory map above (code at
0x80000000, at most 256 instructions, data and stack in the RAM at 0x80010000), as a hex file with one 32-bit word per
line, then:

```bash
cd .. && sbt "runMain rv32i.EmitFpga my_program.hex" && cd fpga && make
```

- With the project's assembler (`src/main/scala/rv32i/Asm.scala`): see `FpgaProgram` in
  `src/main/scala/rv32i/IceSugarPro.scala`, the demo, written that way.
- With GCC: compile for RV32I only, linked at 0x80000000, then convert the binary to one word per line:

```bash
riscv64-unknown-elf-gcc -march=rv32i -mabi=ilp32 -nostdlib -nostartfiles -Os -Wl,-Ttext=0x80000000 -o prog.elf start.S main.c
```

```bash
riscv64-unknown-elf-objcopy -O binary prog.elf prog.bin
```

```bash
python3 -c "import sys,struct; d=open('prog.bin','rb').read(); d+=bytes(-len(d)%4); print('\n'.join('%08x'%w for w in struct.unpack('<%dI'%(len(d)//4), d)))" > my_program.hex
```

  `start.S` has to set the stack pointer (for example `li sp, 0x80011000`) and call `main`. Only code goes into the ROM:
  the core cannot load data from the ROM (Harvard), so constant data (strings, tables) must be copied into the RAM at
  start-up, or built from instructions. The demo builds its banner in RAM with `li`/`sw`.

## 5. How it was checked

- `FpgaSpec` simulates the whole system (with the pipelined core: banner, 12! line, echo, LED) (core, ROM, RAM, LED register, UART transmitter and receiver) cycle by cycle, with
  a fast UART: the banner arrives bit-exact on the serial line, typed characters are echoed, CR becomes CR LF, the LED
  shows each character and steps when idle; a frame with a bad stop bit is ignored.
- The Stage 7 tests (pipeline timing, forwarding, load-use, divisions, programs in lockstep with the reference model) apply
  to the core unchanged.
- Synthesis, placement and routing complete; timing passes at 25 MHz with a 52 % margin; ecppack produces the bitstream.
- The board, LED pins and polarity (B11 red, A11 green, A12 blue, active-high) and UART were verified on a real board
  with the Stage 3 version of this system; this pipelined version has not been run on a board yet.

Pin sites come from the board vendor's repository (https://github.com/wuxx/icesugar-pro: `src/blink/blink.lpf`,
`src/uart_tx/top.lpf`, `src/litex_linux/top_bg256.lpf`).
