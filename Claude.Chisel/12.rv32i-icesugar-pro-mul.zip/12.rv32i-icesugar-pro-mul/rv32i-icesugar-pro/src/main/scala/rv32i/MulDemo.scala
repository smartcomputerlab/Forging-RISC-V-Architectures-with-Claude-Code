package rv32i

/** Multiplication demo for the iCESugar-Pro system (Stage 3, RV32I: there is no MUL instruction, so the product is
  * computed in software by shift-and-add). In an endless loop:
  *
  *   a = 1234            (typed on the UART terminal, echoed; Enter ends the number)
  *   b = -56
  *   a * b = -69104
  *
  * Input: optional '-' first, then up to 9 decimal digits (so |a|, |b| <= 999,999,999); Backspace (0x08 or 0x7f)
  * removes the last character; other characters are ignored; Enter (CR or LF) with no digit is ignored.
  * The product is exact: the full 64-bit product of the magnitudes, printed in decimal by repeated 64-bit division
  * by 10 (shift-and-subtract), with the sign in front.
  * LED: red while a is typed, green while b is typed, blue when the product is shown.
  */
object FpgaMulDemo {
  import FpgaMap._
  val Banner   = "\r\nRV32I multiplier (shift-and-add): two integers, up to 9 digits\r\n"
  val PromptA  = "a = "
  val PromptB  = "b = "
  val ResultIs = "a * b = "
  private val AtBanner = RamBase; private val AtA = RamBase + 0x80; private val AtB = RamBase + 0x90
  private val AtRes = RamBase + 0xa0; private val DigitEnd = RamBase + 0xe0   // digits are written backwards from here

  def apply(): Asm = {
    val a = new Asm(RomBase)
    // registers
    val io = 10; val str = 11; val ch = 12; val t = 13; val t2 = 5; val led = 14
    val v = 20; val neg = 21; val n = 22                 // getnum: value, minus sign typed, digit count
    val va = 24; val sign = 23                           // a, sign of the product
    val pl = 25; val ph = 26; val r = 27                 // 64-bit product / dividend (ph:pl), remainder
    val ml = 28; val mh = 29; val mb = 30; val cnt = 31  // multiplicand (mh:ml), multiplier, loop count
    // link registers: x1 putc, x2 puts, x3 getnum, x4 div10

    a.lui(io, IoBase >> 12)
    def store(s: String, at: Long): Unit = {             // strings are built in RAM (the core cannot load from the ROM)
      a.li(str, at)
      (s.getBytes("US-ASCII").toSeq :+ 0.toByte).grouped(4).zipWithIndex.foreach { case (g, k) =>
        a.li(t, g.zipWithIndex.map { case (b, i) => (b.toLong & 0xff) << (8 * i) }.sum); a.sw(t, 4L * k, str)
      }
    }
    store(Banner, AtBanner); store(PromptA, AtA); store(PromptB, AtB); store(ResultIs, AtRes)
    a.li(str, AtBanner); a.jal(2, "puts")

    a.label("main")
    a.li(led, 1); a.sw(led, Led, io)                     // red: enter a
    a.li(str, AtA); a.jal(2, "puts")
    a.jal(3, "getnum"); a.mv(va, v)
    a.li(led, 2); a.sw(led, Led, io)                     // green: enter b
    a.li(str, AtB); a.jal(2, "puts")
    a.jal(3, "getnum")

    // ---- product: sign = sign(a) xor sign(b); (ph:pl) = |a| * |b| by shift-and-add
    a.xor(sign, va, v); a.srli(sign, sign, 31)
    a.srai(t, va, 31); a.xor(ml, va, t); a.sub(ml, ml, t)    // ml = |a|
    a.srai(t, v, 31); a.xor(mb, v, t); a.sub(mb, mb, t)      // mb = |b|
    a.li(pl, 0); a.li(ph, 0); a.li(mh, 0)
    a.label("mloop")
    a.beq(mb, 0, "mdone")
    a.andi(t, mb, 1); a.beq(t, 0, "mskip")
    a.add(pl, pl, ml); a.sltu(t, pl, ml)                 // (ph:pl) += (mh:ml), carry in t
    a.add(ph, ph, mh); a.add(ph, ph, t)
    a.label("mskip")
    a.srli(t, ml, 31); a.slli(mh, mh, 1); a.or(mh, mh, t); a.slli(ml, ml, 1)   // (mh:ml) <<= 1
    a.srli(mb, mb, 1)
    a.jal(0, "mloop")
    a.label("mdone")

    // ---- print "a * b = ", the sign (not for 0), the decimal digits
    a.li(led, 4); a.sw(led, Led, io)                     // blue: result
    a.li(str, AtRes); a.jal(2, "puts")
    a.or(t, ph, pl); a.beq(t, 0, "nosign"); a.beq(sign, 0, "nosign")
    a.li(ch, '-'); a.jal(1, "putc")
    a.label("nosign")
    a.li(str, DigitEnd); a.sb(0, 0, str)                 // terminator, digits go in front of it
    a.label("dloop")
    a.jal(4, "div10")                                    // (ph:pl) /= 10, r = remainder
    a.addi(r, r, '0'); a.addi(str, str, -1); a.sb(r, 0, str)
    a.or(t, ph, pl); a.bne(t, 0, "dloop")
    a.jal(2, "puts")
    a.jal(1, "crlf")
    a.jal(0, "main")

    // ---- getnum: read a signed decimal number into v, echoing it; return with x3
    a.label("getnum")
    a.li(v, 0); a.li(neg, 0); a.li(n, 0)
    a.label("gwait")
    a.lw(t, UartStat, io); a.andi(t, t, 2); a.beq(t, 0, "gwait")
    a.lw(ch, UartRx, io)
    a.li(t, 13); a.beq(ch, t, "genter")
    a.li(t, 10); a.beq(ch, t, "genter")
    a.li(t, 8); a.beq(ch, t, "gback")
    a.li(t, 127); a.beq(ch, t, "gback")
    a.li(t, '-'); a.bne(ch, t, "gdigit")
    a.bne(n, 0, "gwait"); a.bne(neg, 0, "gwait")       // '-' only as the first character
    a.li(neg, 1); a.jal(1, "putc"); a.jal(0, "gwait")
    a.label("gdigit")
    a.addi(t, ch, -'0'); a.sltiu(t2, t, 10); a.beq(t2, 0, "gwait")   // not a digit: ignore
    a.sltiu(t2, n, 9); a.beq(t2, 0, "gwait")           // 9 digits already
    a.slli(t2, v, 3); a.slli(v, v, 1); a.add(v, v, t2); a.add(v, v, t)   // v = 10 v + digit
    a.addi(n, n, 1); a.jal(1, "putc"); a.jal(0, "gwait")
    a.label("gback")
    a.bne(n, 0, "gbdigit")
    a.beq(neg, 0, "gwait"); a.li(neg, 0); a.jal(0, "gerase")   // remove the '-'
    a.label("gbdigit")
    a.mv(pl, v); a.li(ph, 0); a.jal(4, "div10"); a.mv(v, pl)    // v = v / 10
    a.addi(n, n, -1)
    a.label("gerase")                                    // "\b \b" erases the character on the terminal
    a.li(ch, 8); a.jal(1, "putc"); a.li(ch, ' '); a.jal(1, "putc"); a.li(ch, 8); a.jal(1, "putc")
    a.jal(0, "gwait")
    a.label("genter")
    a.beq(n, 0, "gwait")                                 // no digit yet
    a.beq(neg, 0, "gpos"); a.sub(v, 0, v)
    a.label("gpos")
    a.jal(1, "crlf"); a.jalr(0, 3, 0)

    // ---- div10: (ph:pl) = (ph:pl) / 10, r = remainder; 64 steps of shift-and-subtract; return with x4
    a.label("div10")
    a.li(r, 0); a.li(cnt, 64)
    a.label("dstep")
    a.srli(t, ph, 31); a.slli(r, r, 1); a.or(r, r, t)            // r:ph:pl <<= 1
    a.srli(t, pl, 31); a.slli(ph, ph, 1); a.or(ph, ph, t); a.slli(pl, pl, 1)
    a.sltiu(t, r, 10); a.bne(t, 0, "dnext")
    a.addi(r, r, -10); a.ori(pl, pl, 1)                          // quotient bit 1
    a.label("dnext")
    a.addi(cnt, cnt, -1); a.bne(cnt, 0, "dstep")
    a.jalr(0, 4, 0)

    // ---- crlf: send CR LF (uses x1 only through putc; return with x6)
    a.label("crlf")
    a.mv(6, 1)
    a.li(ch, 13); a.jal(1, "putc"); a.li(ch, 10); a.jal(1, "putc")
    a.jalr(0, 6, 0)
    // ---- putc: send x12 (waits until the transmitter is ready); return with x1
    a.label("putc")
    a.lw(t, UartStat, io); a.andi(t, t, 1); a.beq(t, 0, "putc")
    a.sw(ch, UartTx, io)
    a.jalr(0, 1, 0)
    // ---- puts: send the zero-terminated string at x11; return with x2
    a.label("puts")
    a.lbu(ch, 0, str); a.beq(ch, 0, "puts_end")
    a.jal(1, "putc")
    a.addi(str, str, 1)
    a.jal(0, "puts")
    a.label("puts_end")
    a.jalr(0, 2, 0)
    a
  }
}

/** Writes fpga/memory.hex (one word per line, with the disassembly as a comment) and fpga/memory.lst.
  * Run: sbt "runMain rv32i.EmitMulDemo"
  * then: sbt "runMain rv32i.EmitFpga fpga/memory.hex" && make -C fpga
  */
object EmitMulDemo extends App {
  import java.nio.file.{Files, Paths}
  val prog = FpgaMulDemo().words
  require(prog.length <= FpgaMap.RomWords, s"${prog.length} words")
  val hex = prog.zipWithIndex.map { case (w, k) => f"$w%08x   # 0x${4 * k}%03x: ${Disasm(w, FpgaMap.RomBase + 4L * k)}" }
  Files.write(Paths.get("fpga", "memory.hex"), (hex.mkString("\n") + "\n").getBytes("UTF-8"))
  Files.write(Paths.get("fpga", "memory.lst"), Disasm.listing(prog, FpgaMap.RomBase).getBytes("UTF-8"))
  println(s"multiplication demo: ${prog.length} words of ${FpgaMap.RomWords}; fpga/memory.hex, fpga/memory.lst")
}
