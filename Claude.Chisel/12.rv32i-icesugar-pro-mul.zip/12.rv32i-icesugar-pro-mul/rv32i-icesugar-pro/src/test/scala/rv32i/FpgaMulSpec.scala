package rv32i

import chisel3._
import chiseltest._
import org.scalatest.flatspec.AnyFlatSpec
import org.scalatest.matchers.should.Matchers

/** The multiplication demo (FpgaMulDemo) on the whole FPGA system, with a fast UART: the numbers are typed on the
  * serial line and the transcript (prompts, echo, result) is checked character for character. */
class FpgaMulSpec extends AnyFlatSpec with ChiselScalatestTester with Matchers {
  private val Div = 8

  private class Terminal(c: IceSugarSoC) {
    val received = new StringBuilder
    private var rxBusy = false; private var cnt = 0; private var bit = 0; private var shift = 0
    private var outBits: List[Boolean] = Nil; private var outCnt = 0
    def send(s: String): Unit = s.foreach { ch => outBits ++= (false :: (0 until 8).map(i => ((ch >> i) & 1) == 1).toList) :+ true }
    def idle: Boolean = outBits.isEmpty
    def step(): Unit = {
      if (outBits.nonEmpty) {
        c.io.uartRx.poke(outBits.head.B); outCnt += 1
        if (outCnt == Div) { outCnt = 0; outBits = outBits.tail }
      } else c.io.uartRx.poke(true.B)
      val tx = c.io.uartTx.peek().litToBoolean
      if (!rxBusy) { if (!tx) { rxBusy = true; cnt = Div + Div / 2 - 1; bit = 0; shift = 0 } }
      else if (cnt == 0) {
        if (bit < 8) { shift |= (if (tx) 1 << bit else 0); bit += 1; cnt = Div - 1 }
        else { tx shouldBe true; received += shift.toChar; rxBusy = false }
      } else cnt -= 1
      c.clock.step()
    }
    def runUntil(cond: => Boolean, max: Int): Unit = { var n = 0; while (!cond) { step(); n += 1; require(n < max, s"timeout, got: $received") } }
    /** Types `s` one character at a time, waiting for the program after each one. */
    def typeSlowly(s: String): Unit = s.foreach { ch => send(ch.toString); runUntil(idle, 1000); for (_ <- 0 until 400) step() }
  }

  /** (keys typed for a, keys typed for b, echo of a, echo of b, product) */
  private val E = "\b \b"
  private val cases = Seq(
    ("12\r", "34\r", "12", "34", "408"),
    ("-7\r", "6\r", "-7", "6", "-42"),
    ("0\r", "-5\r", "0", "-5", "0"),                                   // no "-0"
    ("999999999\r", "999999999\r", "999999999", "999999999", "999999998000000001"),
    ("-999999999\r", "999999999\r", "-999999999", "999999999", "-999999998000000001"),
    ("-65536\r", "-65536\r", "-65536", "-65536", "4294967296"),         // carry into the high word
    ("123\b4\r", "x-\b5\r", s"123${E}4", s"-${E}5", "620"),           // Backspace, an ignored 'x'
    ("\r1234567890\r", "-\r-3\r", "123456789", "-3", "-370370367"),    // empty Enter, 10th digit, '-' then Enter
  )

  "The multiplication demo" should "read two numbers on the UART and print their exact product, in a loop" in {
    val prog = FpgaMulDemo().words
    prog.length should be <= FpgaMap.RomWords
    test(new IceSugarSoC(prog, Div)).withAnnotations(TestUtil.waves) { c =>
      c.clock.setTimeout(0)
      val t = new Terminal(c)
      c.io.uartRx.poke(true.B)
      var expected = FpgaMulDemo.Banner + "a = "
      t.runUntil(t.received.toString == expected, 200000)
      c.io.led.expect(1.U)
      for ((ka, kb, ea, eb, p) <- cases) {
        t.typeSlowly(ka)
        expected += ea + "\r\nb = "
        t.runUntil(t.received.toString == expected, 20000)
        c.io.led.expect(2.U)
        t.typeSlowly(kb)
        expected += eb + "\r\na * b = " + p + "\r\na = "
        t.runUntil(t.received.toString == expected, 100000)
        withClue(s"$ea * $eb: ") { t.received.toString shouldBe expected }
      }
    }
  }
}
