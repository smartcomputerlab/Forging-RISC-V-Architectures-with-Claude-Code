package rv32i

/** Factorial demo for the iCESugar-Pro system with the 5-stage pipelined RV32IM core. In an endless loop:
  *
  *   n = 25              (typed on the UART terminal, echoed; Enter ends the number)
  *   n! = 15511210043330985984000000
  *
  * n is 0..999 (up to 3 digits; further digits are ignored); Backspace (0x08 or 0x7f) removes the last digit, other
  * keys are ignored, Enter with no digit is ignored.
  * n! is exact: it is kept in RAM as an array of base-10000 limbs (least significant first) and multiplied by
  * 2, 3, ..., n with MUL and DIVU (999! has 2565 digits, 642 limbs). It is printed limb by limb, 4 digits each.
  * RGB LED: red when n = 0, green otherwise (set as soon as Enter is pressed); off until the first number.
  */
object FpgaFactDemo {
  import FpgaMap._
  val Banner = "\r\nRV32IM 5-stage pipeline: n! for n = 0..999, exact\r\n"
  val Prompt = "n = "
  val Result = "! = "
  val MaxDigits = 3
  private val AtBanner = RamBase; private val AtPrompt = RamBase + 0x80; private val AtResult = RamBase + 0x90
  val NumBase = RamBase + 0x100                        // the limbs of n!

  def apply(): Asm = {
    val a = new Asm(RomBase)
    val io = 10; val str = 11; val ch = 12; val t = 13; val t2 = 5; val led = 14
    val v = 20; val nd = 22                            // getnum: value, digit count
    val n = 24; val k = 25; val len = 26; val p = 27; val i = 28; val carry = 29; val q = 30; val base = 9
    val dv = 31; val lead = 7; val num = 8             // print: divisor, "still in leading zeros", limb pointer
    // link registers: x1 putc, x2 puts, x3 getnum, x4 printnum, x6 crlf

    a.lui(io, IoBase >> 12)
    a.sw(0, Led, io)                                   // LED off until the first number
    def store(s: String, at: Long): Unit = {           // strings are built in RAM (the core cannot load from the ROM)
      a.li(str, at)
      (s.getBytes("US-ASCII").toSeq :+ 0.toByte).grouped(4).zipWithIndex.foreach { case (g, kk) =>
        a.li(t, g.zipWithIndex.map { case (b, j) => (b.toLong & 0xff) << (8 * j) }.sum); a.sw(t, 4L * kk, str)
      }
    }
    store(Banner, AtBanner); store(Prompt, AtPrompt); store(Result, AtResult)
    a.li(base, 10000)
    a.li(str, AtBanner); a.jal(2, "puts")

    a.label("main")
    a.li(str, AtPrompt); a.jal(2, "puts")
    a.jal(3, "getnum"); a.mv(n, v)
    // LED: red (1) for n = 0, green (2) otherwise
    a.li(led, 1); a.beq(n, 0, "setled"); a.li(led, 2)
    a.label("setled")
    a.sw(led, Led, io)

    // ---- n! as base-10000 limbs at NumBase: start with 1, multiply by k = 2..n
    a.li(num, NumBase); a.li(t, 1); a.sw(t, 0, num); a.li(len, 1)
    a.li(k, 2)
    a.label("kloop")
    a.bltu(n, k, "kdone")
    a.li(carry, 0); a.mv(p, num); a.slli(i, len, 2); a.add(i, i, num)   // p walks the limbs, i = end
    a.label("limb")
    a.lw(t, 0, p); a.mul(t, t, k); a.add(t, t, carry)                  // t = limb * k + carry  (< 10^7)
    a.divu(carry, t, base); a.mul(q, carry, base); a.sub(t, t, q)      // carry = t / 10000, t = t % 10000
    a.sw(t, 0, p); a.addi(p, p, 4)
    a.bne(p, i, "limb")
    a.label("grow")                                                     // new top limbs from the carry
    a.beq(carry, 0, "knext")
    a.divu(q, carry, base); a.mul(t, q, base); a.sub(t, carry, t)
    a.sw(t, 0, p); a.addi(p, p, 4); a.addi(len, len, 1); a.mv(carry, q)
    a.jal(0, "grow")
    a.label("knext")
    a.addi(k, k, 1); a.jal(0, "kloop")
    a.label("kdone")

    // ---- print "n! = " and the limbs, most significant first
    a.mv(v, n); a.li(lead, 1); a.jal(4, "printnum")                     // n itself, without leading zeros
    a.li(str, AtResult); a.jal(2, "puts")
    a.li(lead, 1)
    a.slli(p, len, 2); a.add(p, p, num)
    a.label("ploop")
    a.addi(p, p, -4); a.lw(v, 0, p); a.jal(4, "printnum")             // the top limb sets lead = 0
    a.bne(p, num, "ploop")
    a.jal(6, "crlf")
    a.jal(0, "main")

    // ---- printnum: print v (< 10000) as 4 digits; while lead = 1, leading zeros are skipped (the last digit is
    //      always printed); lead becomes 0 after the first digit printed. Return with x4.
    a.label("printnum")
    a.li(dv, 1000)
    a.label("pdigit")
    a.divu(ch, v, dv); a.mul(t, ch, dv); a.sub(v, v, t)
    a.li(t, 1); a.beq(dv, t, "pout")                   // last digit: always
    a.bne(ch, 0, "pout"); a.bne(lead, 0, "pskip")
    a.label("pout")
    a.li(lead, 0); a.addi(ch, ch, '0'); a.jal(1, "putc")
    a.label("pskip")
    a.li(t, 10); a.divu(dv, dv, t); a.bne(dv, 0, "pdigit")
    a.jalr(0, 4, 0)

    // ---- getnum: read an unsigned decimal number (up to MaxDigits digits) into v, echoing it; return with x3
    a.label("getnum")
    a.li(v, 0); a.li(nd, 0)
    a.label("gwait")
    a.lw(t, UartStat, io); a.andi(t, t, 2); a.beq(t, 0, "gwait")
    a.lw(ch, UartRx, io)
    a.li(t, 13); a.beq(ch, t, "genter")
    a.li(t, 10); a.beq(ch, t, "genter")
    a.li(t, 8); a.beq(ch, t, "gback")
    a.li(t, 127); a.beq(ch, t, "gback")
    a.addi(t, ch, -'0'); a.sltiu(t2, t, 10); a.beq(t2, 0, "gwait")   // not a digit: ignore
    a.sltiu(t2, nd, MaxDigits); a.beq(t2, 0, "gwait")                 // enough digits already
    a.li(t2, 10); a.mul(v, v, t2); a.add(v, v, t)                      // v = 10 v + digit
    a.addi(nd, nd, 1); a.jal(1, "putc"); a.jal(0, "gwait")
    a.label("gback")
    a.beq(nd, 0, "gwait")
    a.li(t, 10); a.divu(v, v, t); a.addi(nd, nd, -1)                  // v = v / 10
    a.li(ch, 8); a.jal(1, "putc"); a.li(ch, ' '); a.jal(1, "putc"); a.li(ch, 8); a.jal(1, "putc")   // "\b \b"
    a.jal(0, "gwait")
    a.label("genter")
    a.beq(nd, 0, "gwait")                              // no digit yet
    a.jal(6, "crlf"); a.jalr(0, 3, 0)

    // ---- crlf: send CR LF; return with x6
    a.label("crlf")
    a.li(ch, 13); a.jal(1, "putc"); a.li(ch, 10); a.jal(1, "putc")
    a.jalr(0, 6, 0)
    // ---- putc: send x12 (waits until the transmitter is ready); return with x1
    a.label("putc")
    a.lw(t, UartStat, io); a.andi(t, t, 1); a.beq(t, 0, "putc")
    a.sw(ch, UartTx, io)
    a.jalr(0, 1, 0)
    // ---- puts: send the zero-terminated string at x11; return with x2
    a.label("puts")
    a.lbu(ch, 0, str); a.beq(ch, 0, "puts_end")
    a.jal(1, "putc")
    a.addi(str, str, 1)
    a.jal(0, "puts")
    a.label("puts_end")
    a.jalr(0, 2, 0)
    a
  }
}

/** Writes fpga/memory.hex (one word per line, with the disassembly as a comment) and fpga/memory.lst.
  * Run: sbt "runMain rv32i.EmitFactDemo"
  * then: sbt "runMain rv32i.EmitFpga fpga/memory.hex" && make -C fpga
  */
object EmitFactDemo extends App {
  import java.nio.file.{Files, Paths}
  val prog = FpgaFactDemo().words
  require(prog.length <= FpgaMap.RomWords, s"${prog.length} words")
  val hex = prog.zipWithIndex.map { case (w, k) => f"$w%08x   # 0x${4 * k}%03x: ${Disasm(w, FpgaMap.RomBase + 4L * k)}" }
  Files.write(Paths.get("fpga", "memory.hex"), (hex.mkString("\n") + "\n").getBytes("UTF-8"))
  Files.write(Paths.get("fpga", "memory.lst"), Disasm.listing(prog, FpgaMap.RomBase).getBytes("UTF-8"))
  println(s"factorial demo: ${prog.length} words of ${FpgaMap.RomWords}; fpga/memory.hex, fpga/memory.lst")
}
