package rv32i

import chisel3._
import chiseltest._
import org.scalatest.flatspec.AnyFlatSpec
import org.scalatest.matchers.should.Matchers

/** The factorial demo (FpgaFactDemo) on the whole FPGA system (pipelined RV32IM core, ROM, RAM, LED, UART) with a fast
  * UART: n is typed on the serial line, the transcript (prompt, echo, n!) is checked character for character, and the
  * LED is red after n = 0, green otherwise. (Large n are checked faster at instruction level, see the README.) */
class FpgaFactSpec extends AnyFlatSpec with ChiselScalatestTester with Matchers {
  private val Div = 8

  private class Terminal(c: IceSugarSoC) {
    val received = new StringBuilder
    private var rxBusy = false; private var cnt = 0; private var bit = 0; private var shift = 0
    private var outBits: List[Boolean] = Nil; private var outCnt = 0
    def send(s: String): Unit = s.foreach { ch => outBits ++= (false :: (0 until 8).map(i => ((ch >> i) & 1) == 1).toList) :+ true }
    def idle: Boolean = outBits.isEmpty
    def step(): Unit = {
      if (outBits.nonEmpty) {
        c.io.uartRx.poke(outBits.head.B); outCnt += 1
        if (outCnt == Div) { outCnt = 0; outBits = outBits.tail }
      } else c.io.uartRx.poke(true.B)
      val tx = c.io.uartTx.peek().litToBoolean
      if (!rxBusy) { if (!tx) { rxBusy = true; cnt = Div + Div / 2 - 1; bit = 0; shift = 0 } }
      else if (cnt == 0) {
        if (bit < 8) { shift |= (if (tx) 1 << bit else 0); bit += 1; cnt = Div - 1 }
        else { tx shouldBe true; received += shift.toChar; rxBusy = false }
      } else cnt -= 1
      c.clock.step()
    }
    def runUntil(cond: => Boolean, max: Int): Unit = { var n = 0; while (!cond) { step(); n += 1; require(n < max, s"timeout, got: $received") } }
    /** Types `s` one character at a time, letting the program take each one (and echo it) before the next. */
    def typeKeys(s: String): Unit = s.foreach { ch => send(ch.toString); runUntil(idle, 1000); for (_ <- 0 until 200) step() }
  }

  private def fact(n: Int): BigInt = (1 to n).map(BigInt(_)).product
  private val E = "\b \b"
  /** (keys typed, echo, n, LED after Enter) */
  private val cases = Seq(
    ("0\r", "0", 0, 1),                    // red
    ("5\r", "5", 5, 2),                    // green
    ("13\r", "13", 13, 2),                 // 6227020800: more than 32 bits
    ("\r1x2\b\b\b4\r", s"12${E}${E}4", 4, 2), // empty Enter, an ignored key, Backspace (one too many: ignored)
    ("1\r", "1", 1, 2),
    ("0\r", "0", 0, 1),                    // red again
  )

  "The factorial demo" should "read n on the UART, print n! exactly, show red for 0 and green otherwise, in a loop" in {
    val prog = FpgaFactDemo().words
    prog.length should be <= FpgaMap.RomWords
    test(new IceSugarSoC(prog, Div)).withAnnotations(TestUtil.waves) { c =>
      c.clock.setTimeout(0)
      val t = new Terminal(c)
      c.io.uartRx.poke(true.B)
      var expected = FpgaFactDemo.Banner + FpgaFactDemo.Prompt
      t.runUntil(t.received.toString == expected, 100000)
      c.io.led.expect(0.U)                                   // off before the first number
      for ((keys, echo, n, led) <- cases) {
        t.typeKeys(keys)
        expected += echo + "\r\n" + n + FpgaFactDemo.Result + fact(n) + "\r\n" + FpgaFactDemo.Prompt
        t.runUntil(t.received.toString == expected, 60000)
        withClue(s"n = $n: ") { c.io.led.expect(led.U) }
      }
    }
  }
}
