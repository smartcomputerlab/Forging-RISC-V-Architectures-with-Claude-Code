# RV32IMF 5-stage pipeline (Stage 10) on the iCESugar-Pro: computing pi

The Stage 10 core, unchanged, in the same small system as the earlier board projects (same memory map, RGB LED
register and UART), for the **iCESugar-Pro** (Lattice ECP5 **LFE5U-25F-6BG256C**). It is built with the open-source
flow Chisel → Yosys → nextpnr-ecp5 → ecppack. The core is RV32IMF with the 5-stage pipeline (IF, ID, EX, MEM, WB with
forwarding), the M extension, and the F extension: IEEE 754 single precision, with a sequential FPU in EX.

The program computes **pi in single precision**, three ways, from the number of terms n you type on the terminal, in
an endless loop. Every result is printed exactly rounded to 7 decimals, with its 32-bit pattern.

A ready-made bitstream is included: `IceSugarProTop.bit`.

## 1. Quick start with the ready-made bitstream

1. Connect the iCESugar-Pro with a USB-C cable. The on-board iCELink shows up as a USB drive called **iCELink** and as
   a serial port (`/dev/ttyACM0` on Linux, `COMx` on Windows, `/dev/cu.usbmodem…` on macOS).
2. Open a terminal on the serial port at **115200 baud, 8N1**, no flow control, *before* programming (the banner is
   printed once, right after the FPGA starts):

```bash
picocom -b 115200 /dev/ttyACM0
```

3. Program the FPGA: copy `IceSugarProTop.bit` onto the iCELink drive, or:

```bash
icesprog IceSugarProTop.bit
```

4. Type a number of terms and Enter:

```
RV32IMF 5-stage pipeline: pi in single precision
n terms = 1000
Leibniz: 3.1405926  0x4048ff78
Basel:   3.1406384  0x40490038
Machin:  3.1415927  0x40490fdb
pi:      3.1415927  0x40490fdb
n terms = 
```

- **Input:** n = 0 to 999999 (up to 6 digits; further digits are ignored), then Enter. Backspace corrects, other keys
  are ignored, and Enter before any digit is ignored.
- **RGB LED:** blue while computing, green when the results are printed; off until the first number.
- **Time:** about 10 µs per term at 12.5 MHz, so n = 999999 takes about 10 seconds; small n are instant.

## 2. The three methods

| Line | Formula | F instructions used |
|---|---|---|
| Leibniz | 4 × Σ_{k=0}^{n−1} (−1)^k / (2k+1) | FDIV, FADD, FSUB, FMUL |
| Basel | √(6 × Σ_{k=1}^{n} 1/k²) | FCVT.S.W, FMUL, FDIV, FADD, FSQRT |
| Machin | 16 atan(1/5) − 4 atan(1/239), atan(x) = Σ (−1)^j x^(2j+1)/(2j+1), min(n, 12) terms | FDIV, FMUL, FADD, FSUB, FMSUB (fused) |
| pi | the float nearest to pi, for comparison | FMV.W.X |

All the arithmetic is binary32 with round to nearest even, in the order of the formulas. The results show what single
precision can and cannot do:

| n | Leibniz | Basel | Machin |
|---|---|---|---|
| 2 | 2.6666665 | 2.7386129 | 3.1405971 |
| 12 | 3.0584028 | 3.0642877 | 3.1415927 |
| 10000 | 3.1414986 | 3.1413934 | 3.1415927 |
| 999999 | 3.1415973 | 3.1413934 | 3.1415927 |

- **Machin** converges fast: from 5 terms on it gives the float nearest to pi, 3.1415927 (0x40490fdb).
- **Leibniz** converges slowly (error about 1/n). For large n, adding tiny terms to a sum near 3.14 also loses their
  low bits: with 999999 terms it is 3.1415973, off by 5 units in the 6th decimal.
- **Basel** stops improving at about n = 4096: there 1/k² falls below half a unit in the last place of the sum
  (about 1.6449), so adding it changes nothing. The result stays at 3.1413934.

## 3. How the results are printed

The program does not use floating point to print. FMV.X.W moves the result's bits into an integer register. The value
is m × 2^(e−150), with m the 24-bit significand and e the biased exponent. The program multiplies m by 10^7 into 64
bits (MUL and MULHU), adds half a unit, and shifts right by 150 − e. That gives round(value × 10^7) exactly, which is
printed as d.ddddddd with DIVU and REMU, followed by the bits in hex. (Valid for values below 256, which covers every
result here.)

## 4. The system

| Block | Details |
|---|---|
| Clock | 25 MHz oscillator (P6) → ECP5 PLL (`pll25to12p5.v`) → **12.5 MHz** system clock |
| Reset | Held until the PLL locks, then for 15 cycles |
| Core | Stage 10 `Core`, reset pc 0x80000000: one instruction per clock, +1 per load-use, +2 per taken branch/jump, +33 per division, + the FPU latency (FADD/FSUB 5, FMUL and fused 29, FDIV/FSQRT 31, conversions 3–4) |
| Instruction ROM | **2 KiB (512 words)** at 0x80000000, a constant table in LUTs, built from the program at generation time |
| Data RAM | 4 KiB at 0x80010000 (4 DP16KD block RAMs) |
| LEDs | RGB LED: red B11, green A11, blue A12, active-high |
| UART | 115200 baud 8N1 on the iCELink USB serial port: FPGA TX = B9, FPGA RX = A9 |

Memory-mapped I/O at 0x10000000 (as in the earlier board projects):

| Address | Register | Access |
|---|---|---|
| 0x10000000 | LED: bits 2:0 = {blue, green, red}, 1 = on | read/write |
| 0x10000004 | UART_TX: write a byte to send (only when UART_STATUS bit 0 = 1) | write |
| 0x10000008 | UART_STATUS: bit 0 = transmitter ready, bit 1 = a received byte is waiting | read |
| 0x1000000C | UART_RX: the received byte; reading it clears UART_STATUS bit 1 | read |

Differences from the RV32IM pipelined board project:

- **12.5 MHz instead of 25 MHz.** The FPU's logic makes the EX stage longer: the first build reached only 25.6 MHz,
  too close to 25 MHz. At 12.5 MHz there is a safe margin. `mcycle` counts 12,500,000 per second.
- **ROM doubled to 512 words.** The pi program is 391 words. The memory map is unchanged.

Last build (Yosys 0.71, nextpnr-ecp5 0.11.1): 14,412 LUT4 (66 % of the logic cells), 739 CCU2C (carry), 3,711
flip-flops, 4 DP16KD block RAMs (the data RAM), 4 MULT18X18D (the integer multiplier), 1 PLL; maximum frequency
25.82 MHz, constraint 12.5 MHz: **PASS**, with about a factor of two of margin.

## 5. Building it yourself

Tools:

- Java and sbt (as for the rest of the project), for the Chisel → Verilog step
- Yosys, nextpnr-ecp5 and ecppack: the simplest way is the YosysHQ **oss-cad-suite**
  (https://github.com/YosysHQ/oss-cad-suite-build): download, unpack, then `source oss-cad-suite/environment`
- to program: the iCELink drive (no tool needed), or `icesprog` (https://github.com/wuxx/icesugar, tools folder)

From the `fpga` folder:

```bash
make
```

This runs `sbt "runMain rv32i.EmitFpga"` (Chisel → `build/IceSugarProTop.v`, with the pi program in the ROM; the
program is also written to `program.hex` and `program.lst`), then Yosys, nextpnr-ecp5 and ecppack, and leaves
`build/IceSugarProTop.bit`.

```bash
make report
```

```bash
make YOWASP=1
```

`make report` shows the resource use and the maximum frequency. `make YOWASP=1` uses the Python builds of the tools
(`pip install yowasp-yosys yowasp-nextpnr-ecp5`) instead of oss-cad-suite.

Other programs:

| Command (from the project folder) | ROM contents |
|---|---|
| `sbt "runMain rv32i.EmitFpga"` | the pi program (`src/main/scala/rv32i/PiDemo.scala`) |
| `sbt "runMain rv32i.EmitFpga echo"` | the echo / RGB LED demo of the earlier board projects (`FpgaProgram`) |
| `sbt "runMain rv32i.EmitFpga /full/path/to/my_program.hex"` | your own program: one 32-bit word per line, at most 512 words |
| `sbt "runMain rv32i.EmitFpgaPinTest"` | the LED pin test (in `build_pintest/`) |

Then run `make` in `fpga`. `make` only regenerates the Verilog when a Scala file changed; after `make clean` it
regenerates the pi program, so run your `EmitFpga` command again first.

`sbt "runMain rv32i.EmitPiDemo"` writes the pi program alone to `fpga/memory.hex` and `fpga/memory.lst`.

For your own programs in C or assembly, compile for `-march=rv32imf -mabi=ilp32f`, linked at 0x80000000. The core
cannot load data from the ROM (Harvard), so strings and constant tables must be built in RAM at start-up, as the pi
program does with `li`/`sw`.

## 6. How it was checked

- **Whole system, cycle by cycle** (`FpgaPiSpec`): core, ROM, RAM, LED, UART transmitter and receiver, with a fast UART.
  It types n = 2 and n = 12 (with an ignored key and Backspace) and checks the whole transcript character by character
  against an independent single-precision reference. It also checks the LED: off at start, blue while computing,
  green after.
- **Instruction level:** the program's output was compared with the same reference (numpy float32 for the arithmetic,
  exact fractions for the fused FMSUB, Python Decimal for the rounding to 7 decimals) for n = 0 to 13, 20, 77, 100,
  1000, 4096, 10000, 54321, 65536, 123456, 314159 and 999999: all identical.
- **The FPU itself:** the core is the Stage 10 core, unchanged, so its suites (in `src/test`) apply as they are: the FPU
  is checked bit for bit against the reference in all rounding modes, and the pipelined core runs in lockstep with the
  reference model. They were run in the Stage 10 project, not again here.
- `FpgaSpec`: the echo / LED demo and the LED pin test on this system.
- **Hardware build:** synthesis, placement and routing complete, timing passes at 12.5 MHz, and ecppack produces the
  bitstream.
