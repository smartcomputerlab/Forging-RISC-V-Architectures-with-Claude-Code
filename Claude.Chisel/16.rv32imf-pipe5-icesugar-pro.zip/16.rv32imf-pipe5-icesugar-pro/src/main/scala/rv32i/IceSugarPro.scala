package rv32i

import chisel3._
import chisel3.util._

/** Memory map of the FPGA system (data bus of the pipelined core). */
object FpgaMap {
  val RomBase  = 0x80000000L   // instruction ROM (fetch only), RomWords words
  val RomWords = 512
  val RamBase  = 0x80010000L   // data RAM, RamWords words, byte-addressable
  val RamWords = 1024
  val IoBase   = 0x10000000L   // memory-mapped I/O (word registers):
  val Led      = 0x00          //   LED      R/W  bits 2:0 = {blue, green, red}, 1 = on
  val UartTx   = 0x04          //   UART_TX  W    write a byte to send (only when UART_STATUS.0 = 1)
  val UartStat = 0x08          //   UART_STATUS R bit 0: transmitter ready, bit 1: a received byte is waiting
  val UartRx   = 0x0c          //   UART_RX  R    the received byte (reading it clears UART_STATUS.1)
}

/** The FPGA system: the Stage 7 5-stage pipelined RV32IM core, instruction ROM, data RAM, LEDs and a UART.
  *  - `program`: the ROM contents (at most 256 words), run from 0x80000000 after reset
  *  - `uartDivisor`: clock cycles per UART bit (25 MHz / 115200 baud = 217)
  * The ROM is a constant table (LUTs) read in IF; the RAM is inferred as distributed RAM (asynchronous read, byte write
  * enables) accessed in MEM. Loads and stores reach the bus only in MEM, after the instruction has committed in EX,
  * so a load from UART_RX (which consumes the byte) happens exactly once, even with flushes and stalls.
  */
class IceSugarSoC(program: Seq[Long], uartDivisor: Int) extends Module {
  import FpgaMap._
  require(program.length <= RomWords, s"program has ${program.length} words, the ROM holds $RomWords")
  val io = IO(new Bundle {
    val led    = Output(UInt(3.W))   // {blue, green, red}, 1 = on
    val uartTx = Output(Bool())
    val uartRx = Input(Bool())
  })

  val core = Module(new Core(resetPc = RomBase))

  // ---------------- instruction ROM ----------------
  val rom = VecInit((program ++ Seq.fill(RomWords - program.length)(0L)).map(_.U(32.W)))
  val fetchIdx = (core.io.imem.addr - RomBase.U)(log2Ceil(RomWords) + 1, 2)
  val fetchHit = core.io.imem.addr(31, log2Ceil(RomWords) + 2) === (RomBase >> (log2Ceil(RomWords) + 2)).U
  core.io.imem.data := Mux(fetchHit, rom(fetchIdx), 0.U)    // 0 outside the ROM: illegal instruction trap

  // ---------------- data bus ----------------
  val addr  = core.io.dmem.addr
  val isRam = addr(31, log2Ceil(RamWords) + 2) === (RamBase >> (log2Ceil(RamWords) + 2)).U
  val isIo  = addr(31, 5) === (IoBase >> 5).U
  val ioReg = addr(4, 0)

  // data RAM: four byte lanes, asynchronous read, write at the clock edge
  val ram     = Mem(RamWords, Vec(4, UInt(8.W)))
  val ramIdx  = addr(log2Ceil(RamWords) + 1, 2)
  val ramWord = ram(ramIdx).asUInt
  when(core.io.dmem.we && isRam) {
    ram.write(ramIdx, VecInit(Seq.tabulate(4)(k => core.io.dmem.wdata(8 * k + 7, 8 * k))), core.io.dmem.wstrb.asBools)
  }

  // ---------------- I/O ----------------
  val leds = RegInit(0.U(3.W))
  val tx   = Module(new UartTx(uartDivisor))
  val rx   = Module(new UartRx(uartDivisor))
  val ioWrite = core.io.dmem.we && isIo
  val ioRead  = core.io.dmem.re && isIo
  when(ioWrite && ioReg === Led.U) { leds := core.io.dmem.wdata(2, 0) }
  tx.io.valid := ioWrite && ioReg === UartTx.U
  tx.io.data  := core.io.dmem.wdata(7, 0)
  rx.io.rx    := io.uartRx
  rx.io.take  := ioRead && ioReg === UartRx.U
  val ioData = MuxLookup(ioReg, 0.U)(Seq(
    Led.U      -> leds,
    UartStat.U -> Cat(rx.io.valid, tx.io.ready),
    UartRx.U   -> rx.io.data
  ))

  core.io.dmem.rdata := Mux(isRam, ramWord, Mux(isIo, ioData, 0.U))
  io.led    := leds
  io.uartTx := tx.io.tx
}

/** The ECP5 PLL (EHXPLLL) configured by fpga/pll25to12p5.v: 25 MHz in, 12.5 MHz out. */
class pll25to12p5 extends BlackBox {
  val io = IO(new Bundle {
    val clkin   = Input(Clock())
    val clkout0 = Output(Clock())
    val locked  = Output(Bool())
  })
}

/** Top level for the iCESugar-Pro board (Lattice ECP5 LFE5U-25F-6BG256C): 25 MHz clock on P6, RGB LED on B11 (red),
  * A11 (green), A12 (blue), all active-high (measured on a board with the LED pin test), USB serial of the on-board
  * iCELink on B9 (FPGA TX) and A9 (FPGA RX). See fpga/icesugar_pro.lpf.
  * `usePll = false`: the system runs directly from the 25 MHz oscillator (the pipeline's longest stage fits in 40 ns);
  * `usePll = true`: from the 12.5 MHz PLL output (fpga/pll25to12p5.v), with reset held until the PLL locks.
  * Reset is held for 15 cycles after configuration (ECP5 flip-flops start at 0).
  */
class IceSugarProTop(program: Seq[Long], clockHz: Int = 25000000, baud: Int = 115200, ledActiveLow: Boolean = false,
                     usePll: Boolean = false) extends RawModule {
  val clk_i   = IO(Input(Clock()))
  val led_r   = IO(Output(Bool()))
  val led_g   = IO(Output(Bool()))
  val led_b   = IO(Output(Bool()))
  val uart_tx = IO(Output(Bool()))
  val uart_rx = IO(Input(Bool()))

  val (clk, locked) =
    if (usePll) { val pll = Module(new pll25to12p5); pll.io.clkin := clk_i; (pll.io.clkout0, pll.io.locked) }
    else (clk_i, true.B)

  val porCount = withClockAndReset(clk, !locked) { RegInit(0.U(4.W)) }
  val porDone  = porCount.andR
  withClockAndReset(clk, false.B) { when(!porDone) { porCount := porCount + 1.U } }

  val soc = withClockAndReset(clk, !porDone) { Module(new IceSugarSoC(program, (clockHz + baud / 2) / baud)) }
  soc.io.uartRx := uart_rx
  uart_tx := soc.io.uartTx
  private def drive(on: Bool): Bool = if (ledActiveLow) !on else on
  led_r := drive(soc.io.led(0))
  led_g := drive(soc.io.led(1))
  led_b := drive(soc.io.led(2))
}

/** The demo program: prints a banner and 12! (computed with MUL, printed in decimal with DIVU/REMU) on the UART, echoes
  * every received character (CR becomes CR LF) and shows its low three bits on the RGB LED. Until the first character arrives, the LED steps through its eight colours every
  * `stepCycles` clock cycles (mcycle CSR); from then on it keeps the colour of the last character typed.
  */
object FpgaProgram {
  import FpgaMap._
  val Banner = "\r\nRV32IMF, 5-stage pipeline (Stage 10) on iCESugar-Pro: type something, it is echoed and shown on the RGB LED\r\n"
  val FactText = "12! = "
  val Tail = " (MUL, printed with DIVU and REMU)\r\n> "
  /** Everything the program prints before waiting for keys. */
  val Greeting = Banner + FactText + "479001600" + Tail

  def apply(stepCycles: Long): Asm = {
    val a = new Asm(RomBase)
    val io = 10; val str = 11; val ch = 12; val t = 13; val led = 14; val last = 15; val now = 16; val d = 17; val step = 18
    val typed = 19                                 // 0 until the first character arrives
    a.lui(io, IoBase >> 12)                        // x10 = I/O base
    def store(s: String, at: Long): Unit = {       // copy a zero-terminated string into RAM (the ROM is fetch-only)
      a.li(str, at)
      (s.getBytes("US-ASCII").toSeq :+ 0.toByte).grouped(4).zipWithIndex.foreach { case (g, k) =>
        a.li(t, g.zipWithIndex.map { case (b, i) => (b.toLong & 0xff) << (8 * i) }.sum); a.sw(t, 4L * k, str)
      }
    }
    store(Banner, RamBase); store(FactText, RamBase + 0x100); store(Tail, RamBase + 0x140)
    a.li(str, RamBase); a.jal(1, "puts")
    // 12! with the multiplier
    val f = 20; val i = 21; val n = 22; val p = 23; val ten = 24; val dg = 25
    a.li(f, 1); a.li(i, 1); a.li(n, 13)
    a.label("fact"); a.mul(f, f, i); a.addi(i, i, 1); a.bne(i, n, "fact")
    a.li(str, RamBase + 0x100); a.jal(1, "puts")   // "12! = "
    // decimal digits, last one first, into a buffer in RAM: REMU gives the digit, DIVU the rest
    a.li(p, RamBase + 0x220); a.sb(0, 0, p); a.li(ten, 10)
    a.label("digit")
    a.addi(p, p, -1); a.remu(dg, f, ten); a.addi(dg, dg, '0'); a.sb(dg, 0, p); a.divu(f, f, ten); a.bne(f, 0, "digit")
    a.mv(str, p); a.jal(1, "puts")
    a.li(str, RamBase + 0x140); a.jal(1, "puts")   // tail and prompt
    a.li(led, 1); a.sw(led, Led, io)               // red
    a.csrrs(last, CsrAddr.mcycle, 0)
    a.li(step, stepCycles)
    a.li(typed, 0)
    a.label("loop")
    a.lw(t, UartStat, io); a.andi(now, t, 2); a.beq(now, 0, "idle")
    a.lw(ch, UartRx, io)                           // take the byte
    a.jal(1, "putc")                               // echo it
    a.andi(led, ch, 7); a.sw(led, Led, io)         // LED = low three bits of the character
    a.li(typed, 1)                                 // stop the colour stepping
    a.li(now, 13); a.bne(ch, now, "loop")
    a.li(ch, 10); a.jal(1, "putc")                 // CR -> CR LF
    a.jal(0, "loop")
    a.label("idle")
    a.bne(typed, 0, "loop")                        // a character was typed: keep its colour
    a.csrrs(now, CsrAddr.mcycle, 0)
    a.sub(d, now, last); a.bltu(d, step, "loop")
    a.mv(last, now)
    a.addi(led, led, 1); a.andi(led, led, 7); a.sw(led, Led, io)
    a.jal(0, "loop")
    // putc: send x12 (waits until the transmitter is ready)
    a.label("putc")
    a.lw(t, UartStat, io); a.andi(t, t, 1); a.beq(t, 0, "putc")
    a.sw(ch, UartTx, io)
    a.jalr(0, 1, 0)
    // puts: send the zero-terminated string at x11 (x2 keeps the return address)
    a.label("puts")
    a.mv(2, 1)
    a.label("puts_loop")
    a.lbu(ch, 0, str); a.beq(ch, 0, "puts_end")
    a.jal(1, "putc")
    a.addi(str, str, 1)
    a.jal(0, "puts_loop")
    a.label("puts_end")
    a.jalr(0, 2, 0)
    a
  }
}

/** Generates fpga/build/IceSugarProTop.v (plain Verilog for Yosys), fpga/program.hex and fpga/program.lst.
  * Run: sbt "runMain rv32i.EmitFpga"                 the pi program (FpgaPiDemo, PiDemo.scala)
  *      sbt "runMain rv32i.EmitFpga echo"            the echo / RGB LED demo (FpgaProgram)
  *      sbt "runMain rv32i.EmitFpga my_program.hex"  your own program (one 32-bit word per line, at most 512 words)
  * then: make -C fpga
  */
object EmitFpga extends App {
  import java.nio.file.{Files, Paths}
  val clockHz = 12500000                       // the PLL output (fpga/pll25to12p5.v): the FPU makes 25 MHz too tight
  val prog = args.headOption match {
    case Some("echo") => FpgaProgram(stepCycles = clockHz / 2).words
    case Some(file)   => FpgaHex.read(file)
    case None         => FpgaPiDemo().words
  }
  Files.createDirectories(Paths.get("fpga", "build"))
  val hex = prog.zipWithIndex.map { case (w, k) => f"$w%08x   # 0x${4 * k}%03x: ${Disasm(w, FpgaMap.RomBase + 4L * k)}" }
  Files.write(Paths.get("fpga", "program.hex"), (hex.mkString("\n") + "\n").getBytes("UTF-8"))
  Files.write(Paths.get("fpga", "program.lst"), Disasm.listing(prog, FpgaMap.RomBase).getBytes("UTF-8"))
  @scala.annotation.nowarn("cat=deprecation")
  val v = (new chisel3.stage.ChiselStage).emitVerilog(new IceSugarProTop(prog, clockHz, usePll = true), Array("--target-dir", "fpga/build"))
  Files.write(Paths.get("fpga", "build", "IceSugarProTop.v"), v.getBytes("UTF-8"))
  println(s"program: ${prog.length} words; Verilog: fpga/build/IceSugarProTop.v")
}

/** LED pin test: drives the three LED pins directly (build it with ledActiveLow = false, so register bit = pin level)
  * through all eight combinations, holding each for `holdCycles`, and prints the pin levels of each step on the UART:
  *   step: B11=1 A11=0 A12=0
  * Noting the colour seen at each step shows which colour each pin drives and whether it lights on 0 or on 1. */
object FpgaPinTest {
  import FpgaMap._
  val Header = "\r\nLED pin test: each step holds 2 s; note the colour of the RGB LED for each line\r\n"
  val Prefix = "step: B11="

  def apply(holdCycles: Long): Asm = {
    val a = new Asm(RomBase)
    val io = 10; val str = 11; val ch = 12; val t = 13; val v = 14; val last = 15; val now = 16; val d = 17; val hold = 18
    a.lui(io, IoBase >> 12)
    def store(s: String, at: Long): Unit = {
      a.li(str, at)
      (s.getBytes("US-ASCII").toSeq :+ 0.toByte).grouped(4).zipWithIndex.foreach { case (g, k) =>
        a.li(t, g.zipWithIndex.map { case (b, i) => (b.toLong & 0xff) << (8 * i) }.sum); a.sw(t, 4L * k, str)
      }
    }
    store(Header, RamBase); store(Prefix, RamBase + 0x100)
    a.li(str, RamBase); a.jal(1, "puts")
    a.li(hold, holdCycles)
    a.li(v, 0)
    a.label("step")
    a.sw(v, Led, io)                                       // pins = v (bit 0: B11, bit 1: A11, bit 2: A12)
    a.li(str, RamBase + 0x100); a.jal(1, "puts")           // "step: B11="
    a.andi(ch, v, 1); a.addi(ch, ch, '0'); a.jal(1, "putc")
    for ((name, bit) <- Seq(" A11=" -> 1, " A12=" -> 2)) {
      name.foreach { c => a.li(ch, c.toLong); a.jal(1, "putc") }
      a.srli(ch, v, bit); a.andi(ch, ch, 1); a.addi(ch, ch, '0'); a.jal(1, "putc")
    }
    a.li(ch, 13); a.jal(1, "putc"); a.li(ch, 10); a.jal(1, "putc")
    a.csrrs(last, CsrAddr.mcycle, 0)
    a.label("wait")
    a.csrrs(now, CsrAddr.mcycle, 0); a.sub(d, now, last); a.bltu(d, hold, "wait")
    a.addi(v, v, 1); a.andi(v, v, 7)
    a.jal(0, "step")
    a.label("putc")
    a.lw(t, UartStat, io); a.andi(t, t, 1); a.beq(t, 0, "putc")
    a.sw(ch, UartTx, io)
    a.jalr(0, 1, 0)
    a.label("puts")
    a.mv(2, 1)
    a.label("puts_loop")
    a.lbu(ch, 0, str); a.beq(ch, 0, "puts_end")
    a.jal(1, "putc")
    a.addi(str, str, 1)
    a.jal(0, "puts_loop")
    a.label("puts_end")
    a.jalr(0, 2, 0)
    a
  }
}

/** Builds the LED pin-test Verilog (raw pin levels: ledActiveLow = false) into fpga/build_pintest/.
  * Run: sbt "runMain rv32i.EmitFpgaPinTest"   then: make -C fpga pintest */
object EmitFpgaPinTest extends App {
  import java.nio.file.{Files, Paths}
  val clockHz = 12500000
  val prog = FpgaPinTest(holdCycles = 2L * clockHz).words
  Files.createDirectories(Paths.get("fpga", "build_pintest"))
  @scala.annotation.nowarn("cat=deprecation")
  val v = (new chisel3.stage.ChiselStage).emitVerilog(new IceSugarProTop(prog, clockHz, ledActiveLow = false, usePll = true),
    Array("--target-dir", "fpga/build_pintest"))
  Files.write(Paths.get("fpga", "build_pintest", "IceSugarProTop.v"), v.getBytes("UTF-8"))
  println(s"pin test: ${prog.length} words; Verilog: fpga/build_pintest/IceSugarProTop.v")
}

/** Hex program files: one 32-bit word per line, `#` comments, `_` separators, blank lines ignored. */
object FpgaHex {
  def read(file: String): Seq[Long] = {
    val src = scala.io.Source.fromFile(file)
    try src.getLines().map(_.split("#").headOption.getOrElse("").replace("_", "").trim).filter(_.nonEmpty)
      .map(java.lang.Long.parseLong(_, 16) & 0xFFFFFFFFL).toSeq
    finally src.close()
  }
}
