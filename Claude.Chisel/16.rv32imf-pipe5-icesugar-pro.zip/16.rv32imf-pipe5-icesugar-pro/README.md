# Stage 10 on the iCESugar-Pro FPGA: 5-stage pipelined RV32IMF core computing pi

**FPGA version.** This is the Stage 10 project with a board system for the iCESugar-Pro (Lattice ECP5): ROM, RAM,
RGB LED and UART around the unchanged core, at 12.5 MHz. The default program computes pi in single precision three
ways (Leibniz, Basel, Machin) from a number of terms typed on the serial terminal, in an endless loop. See
**[`fpga/README.md`](fpga/README.md)**; the ready-made bitstream is `fpga/IceSugarProTop.bit`.

| File | Contents |
|---|---|
| `src/main/scala/rv32i/PiDemo.scala` | the pi program (`FpgaPiDemo`, written with the project's assembler) and `EmitPiDemo` |
| `src/main/scala/rv32i/IceSugarPro.scala` | the board system (`IceSugarSoC`, `IceSugarProTop`), `EmitFpga`, the echo demo, the LED pin test |
| `src/main/scala/rv32i/Uart.scala` | UART transmitter and receiver (115200 8N1) |
| `src/test/scala/rv32i/FpgaPiSpec.scala`, `FpgaSpec.scala` | the whole system simulated cycle by cycle with a UART terminal model |
| `fpga/` | Makefile, pin constraints, PLL, `program.hex` / `memory.hex` (the pi program), bitstream |

`Asm.scala` and `Disasm.scala` moved from the tests to `src/main` so that the programs can be generated with
`sbt runMain`. The rest of this README describes the core, as in Stage 10.

---

# Stage 10: 5-stage pipelined RV32IMF core with a sequential FPU, in Chisel 3

The tenth core of the series, in package `rv32i`: the **RV32IMF** instruction set of Stage 9 (F extension: 32
floating-point registers, fcsr, all 26 single-precision instructions, IEEE 754 binary32 with the five rounding modes and
the five exception flags) on the **5-stage pipeline** of Stage 7 (IF, ID, EX, MEM, WB with forwarding, load-use stall,
branches resolved in EX, precise traps).

| Unit | Where | Cost in the pipeline |
|---|---|---|
| ALU, multiplier, FpMisc (sign injection, min/max, compares, class, FMV) | EX | 1 cycle per instruction |
| FLW / FSW | address in EX, access in MEM | 1 cycle; an FLW followed by a user of its value: +1 (load-use) |
| Sequential divider | EX | +33 cycles (IF/ID/EX freeze, MEM/WB drain) |
| Sequential FPU | EX | + its latency: FADD/FSUB 5, FMUL and the fused multiply-adds 29, FDIV/FSQRT 31, FCVT.W(U).S 3, FCVT.S.W(U) 4, special operands 2 |
| Taken branch, jump, trap, MRET | EX | +2 (two younger instructions flushed) |

f results are forwarded into EX from MEM and WB like x results, and both register files have a WB→ID bypass.
The rounding mode and the legality of each F instruction are decided in EX with the current `frm`, and the raised flags
accrue into `fflags` when the instruction commits in EX, where all CSR accesses happen. So the pipeline keeps the
program order of every fcsr access without extra hazard logic.

See `DESIGN_NOTES.md` for the pipeline control, the hazard table and every design choice.

## Instructions

| Group | Instructions |
|---|---|
| RV32I | LUI AUIPC JAL JALR, 6 branches, LB LH LW LBU LHU SB SH SW, 9 ALU-immediate and 10 ALU-register instructions |
| System | FENCE (no-op), ECALL, EBREAK, MRET, WFI (no-op), CSRRW CSRRS CSRRC CSRRWI CSRRSI CSRRCI |
| M extension | MUL MULH MULHSU MULHU (1 cycle); DIV DIVU REM REMU (34 cycles, 2 for x/0 and MIN/-1) |
| F extension | FLW FSW; FADD FSUB FMUL FDIV FSQRT; FMADD FMSUB FNMSUB FNMADD; FSGNJ FSGNJN FSGNJX; FMIN FMAX; FEQ FLT FLE; FCLASS; FCVT.W.S FCVT.WU.S FCVT.S.W FCVT.S.WU; FMV.X.W FMV.W.X |

CSRs: fflags (0x001), frm (0x002), fcsr (0x003), mstatus (SD = 1, FS = Dirty, MPP = M, MIE, MPIE), misa (`0x40001120`:
RV32IMF), mie, mtvec, mscratch, mepc, mcause, mtval, mip, mcycle(h), minstret(h), cycle(h), instret(h), mvendorid,
marchid, mimpid, mhartid. Exceptions: illegal instruction (including reserved rounding modes and non-S formats),
ECALL, EBREAK, misaligned load/store (FLW/FSW included), misaligned branch/jump target.

## Requirements

- Java 11+ (tested with 21) and sbt 1.10 (https://www.scala-sbt.org/download/); tests run on Treadle (no simulator to install)
- Optional: CIRCT firtool 1.37.0 on the PATH for firtool output from `Emit`; GTKWave to view waveforms

Pinned: Scala 2.13.12, Chisel 3.6.1 (+ chisel3-plugin), chiseltest 0.6.2, sbt 1.10.2.

## Commands

```bash
sbt test
```

The full suite takes about 45 minutes on Treadle (the FPU and FP program tests are long). One suite:

```bash
sbt "testOnly rv32i.FpuSpec"
```

More random FPU operations (here ten times the default):

```bash
FPU_TESTS=10 sbt "testOnly rv32i.FpuSpec"
```

Generate SystemVerilog for `Core`, `Fpu` and `RV32ITestWrapper` (with `program.hex` and `data.hex`) into `generated/`:

```bash
sbt "runMain rv32i.Emit"
```

## Source files (`src/main/scala/rv32i/`)

| File | Contents |
|---|---|
| `Core.scala` | The 5-stage pipelined RV32IMF core: IF/ID/EX/MEM/WB, x and f forwarding, load-use for both files, divider and FPU stalls in EX, precise traps |
| `Fpu.scala` | Sequential FPU: unpack, 24-step multiplier, aligner/adder, 27-step divider, 27-step square root, normalizer, rounder, float↔integer conversion; `FpuOp` (operations and latencies) |
| `FpMisc.scala` | Single-cycle FP operations: sign injection, min/max, compares, class |
| `FDecoder.scala` | Decoder for the 26 F instructions: encodings, rounding-mode legality, destinations |
| `FRegFile.scala` | f0..f31, three read ports (rs3 for the fused multiply-adds), one write port |
| `FpRef.scala` | Bit-exact software model of binary32 arithmetic (exact BigInt arithmetic, one rounding), `Rm`, `FFlags` |
| `CsrFile.scala` | Machine-mode CSRs plus fflags / frm / fcsr; flags accrue on every retiring FP instruction |
| `Defs.scala` | Opcodes, causes, CSR addresses, enums, memory ports, `Trace` (with the FP write and the raised flags), pipeline registers `IfId`, `IdEx` (+ `Ctrl`), `ExMem`, `MemWb` |
| `Decoder.scala`, `ImmGen.scala`, `RegFile.scala`, `Alu.scala`, `Multiplier.scala`, `DivUnit.scala` | Integer datapath (as in Stage 5) |
| `InstructionMemory.scala`, `DataMemory.scala`, `RV32ITestWrapper.scala` | The hex-file system: ROM at 0x80000000, RAM at 0x80010000 |
| `RefModel.scala` | Instruction-level reference model of the whole core (RV32IMF, CSRs, traps), using `FpRef` |
| `Emit.scala` | SystemVerilog generation |

Project root: `program.hex` (demo: single-precision dot product of two arrays from `data.hex` with FLW and FMADD.S,
stored with FSW and reloaded, then FDIV, FSQRT, FCVT in two rounding modes, FMUL, FLT, FCLASS, FMAX, FSGNJN, FMV.X.W,
an exact zero, a division by zero, and the fflags CSR), `data.hex`, `tools/rv32im_filter.py` (GTKWave filter process:
instruction words as assembly) and `tools/f32_filter.py` (GTKWave filter process: any 32-bit value as a float).

## Tests (`src/test/scala/rv32i/`)

| Suite | What it checks |
|---|---|
| `FpRefSpec` | The software reference against the JVM's IEEE arithmetic (+ − × ÷ √, fused multiply-add, int↔float) on 200,000 random operand sets in round-to-nearest-even, then RISC-V flags and special results by hand: canonical NaN, the other four rounding modes, overflow, underflow with tininess after rounding, conversions |
| `FpuSpec` | The FPU against `FpRef`, bit for bit, flags included, in all five rounding modes: 1,500 FADD and FSUB, 600 FMUL, 300 of each fused multiply-add, 500 FDIV and FSQRT, 1,000 of each conversion (scalable with `FPU_TESTS`), 35 corner cases × 5 rounding modes, exact latencies |
| `FpMiscSpec` | The single-cycle FP unit against `FpRef` on 20,000 operand pairs (9 operations each) |
| `CoreFpSpec` | The F extension on the core in lockstep with `RefModel`: every rounding FP instruction on special operands in all rounding modes (static and dynamic), the single-cycle ones on 96 operand pairs, FLW/FSW with misaligned traps, fflags/frm/fcsr and flag accrual, reserved rounding modes and non-RV32F encodings, 1,500 random mixed instructions, exact stall cycles |
| `CsrFileSpec` | CSRRW/RS/RC, misa = RV32IMF, mstatus with SD/FS, WARL masks, illegal accesses, counters, traps, fflags/frm/fcsr |
| `CoreFpPipeSpec` | FP in the pipeline: f forwarding at distances 1–3 and between x and f, FLW load-use on rs1/rs2/rs3 and FSW data, LW → FMV.W.X, no false stalls, frm written right before a dynamic FP instruction, fflags read right after one, wrong-path FP instructions flushed |
| `MemorySpec` | Memories, hex parsing, `program.hex` on the wrapper: every FP result, the flags, the store, 51 retirements and 236 empty cycles (222 FPU, 4 fill, 4 FLW load-use, 6 branch bubbles) |
| `CoreProgramSpec`, `CoreTimingSpec`, `CoreDivSpec` | The Stage 7 pipeline suites: programs in lockstep, the exact cycle of every instruction, redirect bubbles, load-use stalls, divisions |
| `AluSpec`, `ImmGenSpec`, `RegFileSpec`, `DecoderSpec`, `MultiplierSpec`, `DivRefSpec`, `DivUnitSpec` | The integer blocks |
| `WaveformSpec` | Nine demos that write VCDs and GTKWave sessions to `waves/` |

Test helpers: `Asm.scala` (assembler with the F instructions and `fli`), `CoreSim.scala` (lockstep harness, also
compares the FP write and the raised flags), `Disasm.scala` (RV32IMF), `FpGen.scala` (random float operands),
`Gtkw.scala`, `TestUtil.scala`.

## Interface of `Core`

```scala
class Core(resetPc: Long = 0x80000000L, hartId: Int = 0) extends Module {
  val io = IO(new Bundle {
    val imem  = new InstrMemPort   // addr out, data in (combinational)
    val dmem  = new DataMemPort    // addr, re, we, wdata, wstrb out; rdata in (combinational, aligned word)
    val trace = Output(new Trace)  // WB: one retirement or one trap per cycle, or neither (bubble, fill, stall)
  })
}
```

`Trace` adds to the Stage 5 fields: `fdWe`, `fdAddr`, `fdData` (the f register written) and `fflags` (the exception
flags raised by the instruction).

## Waveforms with GTKWave

```bash
sbt "testOnly rv32i.WaveformSpec"
```

| Demo | Contents |
|---|---|
| `waves/stage10_demo/` | `program.hex` + `data.hex` on `RV32ITestWrapper`: the float dot product and the FP operations after it |
| `waves/fp_ops/` | Every kind of F instruction: FPU operations, single-cycle ones, a signaling NaN (NV), a division by zero (DZ) |
| `waves/fpu_unit/` | The FPU alone: FADD, FMUL, FDIV, FSQRT, FMADD, FCVT.W.S (`fpu.gtkw`) |
| `waves/div_rem/`, `waves/div_unit/`, `waves/mul/` | Divisions, the divider alone, multiplications |
| `waves/upper_jumps/`, `waves/load_store_branch/`, `waves/trap/` | LUI/AUIPC/branches/JAL, a loop with loads and stores, traps |

Open from the project root:

```bash
gtkwave waves/stage10_demo/RV32ITestWrapper.vcd waves/stage10_demo/core.gtkw
```

```bash
gtkwave waves/fpu_unit/Fpu.vcd waves/fpu_unit/fpu.gtkw
```

Groups in `core.gtkw`: Clock; IF; ID (IF/ID register, `loadUse`); EX (ID/EX register, operands, result, `divStall`,
`exStall`, `trapNow`, `redirect`); MEM (EX/MEM register, data port); WB (MEM/WB register, x and f writes); Retire / trap;
Divider; **F extension in EX** (`isF`, legality, resolved rounding mode, `useFpu`, `fpuStall`, single-cycle result,
the f operands after forwarding, raised flags, FLW load-use); **FPU** (request, operation and rounding mode by name, operands
as floats, state UNPACK/MUL/ADD/DIV/SQRT/NORM/ROUND/TOINT/DONE, step counter, product, quotient/root and remainder,
raw and normalized significands with their exponents, sticky bit, result as a float and in hex, flags by name);
**FP registers f0..f11** (as floats); **fcsr** (frm by name, fflags by name); CSRs.

Each folder also holds the translate filters the session uses: `inst.filter` (assembly), `float.filter` (every float
value of that run as text, e.g. `-1.6666666 (0xbfd55555)`), `fpustate.filter`, `fpuop.filter`, `rm.filter`,
`fflags.filter`, and the multiplier/divider filters. For any other float signal: Data Format → Translate Filter
Process → `tools/f32_filter.py`.

Reading an FPU operation in `stage10_demo`: on FDIV.S, `useFpu` and `fpuStall` rise, the FPU `state` goes UNPACK →
DIV (27 steps, `count` 0…26, quotient bits shifting into `quo`) → NORM → ROUND → DONE, the pc and the instruction
hold in IF/ID/EX while MEM and WB drain, and the result (`-1.6666666`) leaves EX in the DONE cycle and retires two
cycles later in WB with `fflags` = NX.

A VCD for any test: `WAVES=1 sbt test` (files in `test_run_dir/<test name>/`).
