FIRRTL version 1.2.0
circuit ImmediateGenerator :
  module ImmediateGenerator :
    input clock : Clock
    input reset : UInt<1>
    input io_instr : UInt<32> @[src/main/scala/rv32i/ImmediateGenerator.scala 7:14]
    output io_imm : UInt<32> @[src/main/scala/rv32i/ImmediateGenerator.scala 7:14]

    node _io_imm_T = bits(io_instr, 31, 20) @[src/main/scala/rv32i/ImmediateGenerator.scala 11:21]
    node _io_imm_T_1 = asSInt(_io_imm_T) @[src/main/scala/rv32i/ImmediateGenerator.scala 11:30]
    node _io_imm_T_2 = pad(_io_imm_T_1, 32) @[src/main/scala/rv32i/ImmediateGenerator.scala 11:40]
    node _io_imm_T_3 = asUInt(_io_imm_T_2) @[src/main/scala/rv32i/ImmediateGenerator.scala 11:49]
    io_imm <= _io_imm_T_3 @[src/main/scala/rv32i/ImmediateGenerator.scala 11:10]
