package rv32i

import chisel3._
import chiseltest._
import org.scalatest.flatspec.AnyFlatSpec
import org.scalatest.matchers.should.Matchers

/** The exact demo program of the bitstream (stepCycles for 12.5 MHz) at the real UART speed (109 cycles per bit):
  * banner, then a key typed right after it must be echoed and shown on the LED. */
class FpgaRealSpeedSpec extends AnyFlatSpec with ChiselScalatestTester with Matchers {
  "The bitstream's demo program" should "echo a key typed right after the banner at the real UART speed" in {
    val Div = (12500000 + 115200 / 2) / 115200
    val prog = FpgaProgram(stepCycles = 12500000 / 2).words
    test(new IceSugarSoC(prog, Div)) { c =>
      c.clock.setTimeout(0)
      c.io.uartRx.poke(true.B)
      val got = new StringBuilder
      var busy = false; var cnt = 0; var bit = 0; var sh = 0; var cycles = 0
      var out: List[Boolean] = Nil; var outCnt = 0
      def step(): Unit = {
        if (out.nonEmpty) { c.io.uartRx.poke(out.head.B); outCnt += 1; if (outCnt == Div) { outCnt = 0; out = out.tail } }
        else c.io.uartRx.poke(true.B)
        val tx = c.io.uartTx.peek().litToBoolean
        if (!busy) { if (!tx) { busy = true; cnt = Div + Div / 2 - 1; bit = 0; sh = 0 } }
        else if (cnt == 0) { if (bit < 8) { sh |= (if (tx) 1 << bit else 0); bit += 1; cnt = Div - 1 } else { got += sh.toChar; busy = false } }
        else cnt -= 1
        c.clock.step(); cycles += 1
      }
      while (got.toString != FpgaProgram.Banner) { step(); require(cycles < 400000, s"banner timeout: $got") }
      val ledAfterBanner = c.io.led.peek().litValue
      out = (false :: (0 until 8).map(i => (('o'.toInt >> i) & 1) == 1).toList) :+ true    // type 'o'
      while (got.length < FpgaProgram.Banner.length + 1) { step(); require(cycles < 600000, "no echo") }
      got.last shouldBe 'o'
      for (_ <- 0 until 50) step()
      c.io.led.expect(7.U)
      ledAfterBanner shouldBe 1
    }
  }
}
