package rv32i

import chisel3._
import chiseltest._
import org.scalatest.flatspec.AnyFlatSpec
import org.scalatest.matchers.should.Matchers

/** The FPGA system (IceSugarSoC) simulated cycle by cycle with a fast UART (8 clock cycles per bit): the banner on the
  * serial line, the echo of received characters, the LED register, and the LED stepping when idle. */
class FpgaSpec extends AnyFlatSpec with ChiselScalatestTester with Matchers {
  private val Div = 8

  /** Serial line decoder and driver around the SoC, one clock cycle per call to `step`. */
  private class Terminal(c: IceSugarSoC) {
    val received = new StringBuilder
    private var rxBusy = false; private var cnt = 0; private var bit = 0; private var shift = 0
    private var outBits: List[Boolean] = Nil; private var outCnt = 0
    var cycles = 0L
    def send(s: String): Unit = s.foreach { ch => outBits ++= (false :: (0 until 8).map(i => ((ch >> i) & 1) == 1).toList) :+ true }
    def step(): Unit = {
      // drive the FPGA's RX line
      if (outBits.nonEmpty) {
        c.io.uartRx.poke(outBits.head.B)
        outCnt += 1
        if (outCnt == Div) { outCnt = 0; outBits = outBits.tail }
      } else c.io.uartRx.poke(true.B)
      // decode the FPGA's TX line (sample in the middle of each bit)
      val tx = c.io.uartTx.peek().litToBoolean
      if (!rxBusy) { if (!tx) { rxBusy = true; cnt = Div + Div / 2 - 1; bit = 0; shift = 0 } }
      else if (cnt == 0) {
        if (bit < 8) { shift |= (if (tx) 1 << bit else 0); bit += 1; cnt = Div - 1 }
        else { tx shouldBe true; received += shift.toChar; rxBusy = false }   // stop bit
      } else cnt -= 1
      c.clock.step(); cycles += 1
    }
    def runUntil(cond: => Boolean, max: Int): Unit = { var n = 0; while (!cond) { step(); n += 1; require(n < max, s"timeout, got: $received") } }
  }

  "IceSugarSoC" should "print the banner, step the LED until a key, then echo characters and keep their colour" in {
    val prog = FpgaProgram(stepCycles = 3000).words
    prog.length should be <= FpgaMap.RomWords
    test(new IceSugarSoC(prog, Div)).withAnnotations(TestUtil.waves) { c =>
      c.clock.setTimeout(0)
      val t = new Terminal(c)
      c.io.uartRx.poke(true.B)
      t.runUntil(t.received.toString == FpgaProgram.Banner, 200000)
      // before any key: the LED steps through all eight colours every 3000 cycles
      val seen = scala.collection.mutable.LinkedHashSet.empty[BigInt]
      for (_ <- 0 until 30000) { t.step(); seen += c.io.led.peek().litValue }
      seen.size shouldBe 8
      t.send("A")                                               // 'A' = 0x41: LED = 1 (red), echoed
      t.runUntil(t.received.length == FpgaProgram.Banner.length + 1, 20000)
      t.received.last shouldBe 'A'
      t.send("f")                                               // 'f' = 0x66: LED = 6 (green + blue)
      t.runUntil(t.received.length == FpgaProgram.Banner.length + 2, 20000)
      t.received.last shouldBe 'f'
      t.step(); t.step(); c.io.led.expect(6.U)
      t.send("\r")                                              // CR -> CR LF
      t.runUntil(t.received.endsWith("\r\n"), 20000)
      c.io.led.expect(5.U)                                      // 0x0d & 7
      // after a key: the LED keeps the last character's colour, no more stepping
      for (_ <- 0 until 30000) { t.step(); c.io.led.expect(5.U) }
    }
  }

  "The LED pin test" should "print each step's pin levels and drive them on the LED register" in {
    val prog = FpgaPinTest(holdCycles = 4000).words
    prog.length should be <= FpgaMap.RomWords
    test(new IceSugarSoC(prog, Div)) { c =>
      c.clock.setTimeout(0)
      val t = new Terminal(c)
      c.io.uartRx.poke(true.B)
      for (v <- 0 until 8) {
        val line = s"step: B11=${v & 1} A11=${(v >> 1) & 1} A12=${(v >> 2) & 1}\r\n"
        t.runUntil(t.received.toString.endsWith(line), 60000)
        c.io.led.expect(v.U)
      }
      t.received.toString should startWith (FpgaPinTest.Header)
    }
  }

  "UartRx" should "ignore a frame whose stop bit is 0 (framing error)" in {
    test(new UartRx(Div)) { c =>
      c.io.take.poke(false.B)
      val frame = false :: List.fill(8)(true) ++ List(false)     // start, 0xff, bad stop bit
      for (b <- frame; _ <- 0 until Div) { c.io.rx.poke(b.B); c.clock.step() }
      c.io.rx.poke(true.B); c.clock.step(3 * Div)
      c.io.valid.expect(false.B)
    }
  }
}
