package rv32i

import chisel3._
import chisel3.util._

/** UART transmitter, 8 data bits, no parity, 1 stop bit (8N1), LSB first. `divisor` = clock cycles per bit.
  * `ready` is high when a new byte can be written (`valid`). The line idles high. */
class UartTx(divisor: Int) extends Module {
  require(divisor >= 2)
  val io = IO(new Bundle {
    val valid = Input(Bool())
    val data  = Input(UInt(8.W))
    val ready = Output(Bool())
    val tx    = Output(Bool())
  })
  val shift = RegInit("h3ff".U(10.W))          // stop bit, 8 data bits, start bit (sent LSB first)
  val bits  = RegInit(0.U(4.W))                // bits left to send
  val count = RegInit(0.U(log2Ceil(divisor).W))
  io.ready := bits === 0.U
  io.tx    := shift(0)
  when(io.ready && io.valid) {
    shift := Cat(1.U(1.W), io.data, 0.U(1.W))
    bits  := 10.U
    count := 0.U
  }.elsewhen(bits =/= 0.U) {
    when(count === (divisor - 1).U) {
      count := 0.U
      shift := Cat(1.U(1.W), shift(9, 1))
      bits  := bits - 1.U
    }.otherwise { count := count + 1.U }
  }
}

/** UART receiver, 8N1. The input is synchronized (two flip-flops), a falling edge starts a frame, each bit is
  * sampled in the middle of its period. `valid` stays high until `take` (the byte has been read). */
class UartRx(divisor: Int) extends Module {
  require(divisor >= 4)
  val io = IO(new Bundle {
    val rx    = Input(Bool())
    val valid = Output(Bool())
    val data  = Output(UInt(8.W))
    val take  = Input(Bool())
  })
  val rxSync = RegNext(RegNext(io.rx, true.B), true.B)
  val busy   = RegInit(false.B)
  val count  = RegInit(0.U(log2Ceil(divisor * 3 / 2 + 1).W))
  val bitIdx = RegInit(0.U(4.W))
  val shift  = RegInit(0.U(8.W))
  val full   = RegInit(false.B)
  val data   = RegInit(0.U(8.W))
  when(io.take) { full := false.B }
  when(!busy) {
    when(!rxSync) {                              // start bit: wait 1.5 bit periods to the middle of bit 0
      busy := true.B; count := (divisor * 3 / 2 - 1).U; bitIdx := 0.U
    }
  }.otherwise {
    when(count === 0.U) {
      when(bitIdx === 8.U) {                     // middle of the stop bit
        busy := false.B
        when(rxSync) { data := shift; full := true.B }   // keep the byte only if the stop bit is 1
      }.otherwise {
        shift := Cat(rxSync, shift(7, 1))
        bitIdx := bitIdx + 1.U
        count := (divisor - 1).U
      }
    }.otherwise { count := count - 1.U }
  }
  io.valid := full
  io.data  := data
}
