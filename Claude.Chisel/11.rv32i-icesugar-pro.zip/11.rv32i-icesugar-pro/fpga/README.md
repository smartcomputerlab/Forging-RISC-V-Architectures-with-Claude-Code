# RV32I (Stage 3) on the iCESugar-Pro

The Stage 3 single-cycle RV32I core (all 40 RV32I instructions, Zicsr, machine-mode traps), unchanged, in a small
system for the **iCESugar-Pro** (Lattice ECP5 **LFE5U-25F-6BG256C**), built with the open-source flow
Chisel → Yosys → nextpnr-ecp5 → ecppack.

The demo program prints a banner on the USB serial port, echoes what you type, shows the low three bits of each typed
character on the RGB LED. Until you type the first character, the LED steps through its eight colours every half
second; from then on it keeps the colour of the last character typed.

A ready-made bitstream is included: `IceSugarProTop.bit`.

## 1. Quick start with the ready-made bitstream

1. Connect the iCESugar-Pro with a USB-C cable. The on-board iCELink shows up as a USB drive called **iCELink** and as
   a serial port (`/dev/ttyACM0` on Linux, `COMx` on Windows, `/dev/cu.usbmodem…` on macOS).
2. Open a terminal on the serial port at **115200 baud, 8N1**, no flow control, *before* programming (the banner is
   printed once, right after the FPGA starts):

```bash
picocom -b 115200 /dev/ttyACM0
```

   On Windows use PuTTY or Tera Term.
3. Copy `IceSugarProTop.bit` onto the iCELink drive (drag and drop). The iCELink programs the FPGA in a few seconds and
   the banner appears (`icesprog IceSugarProTop.bit` does the same from the command line; programming again restarts
   the program):

```
RV32I (Stage 3) on iCESugar-Pro: type something, it is echoed and shown on the RGB LED
>
```

4. Type: every character comes back, and the LED shows its low three bits (bit 0 red, bit 1 green, bit 2 blue): `a` =
   red, `b` = green, `c` = red + green, `d` = blue, ... Enter starts a new line.

The LED pins and colours were measured on a real board with the LED pin test (`sbt "runMain rv32i.EmitFpgaPinTest"`,
which drives B11/A11/A12 directly and prints each combination): B11 = red, A11 = green, A12 = blue, all active-high.

## 2. The system

| Block | Details |
|---|---|
| Clock | 25 MHz oscillator (P6) → ECP5 PLL (`pll25to12p5.v`) → **12.5 MHz** system clock |
| Reset | Held until the PLL locks, then for 15 cycles |
| Core | Stage 3 `Core`, reset pc 0x80000000, one instruction per clock |
| Instruction ROM | 1 KiB (256 words) at 0x80000000, a constant table in LUTs, built from the program at generation time |
| Data RAM | 4 KiB at 0x80010000, distributed RAM (asynchronous read, byte write enables) |
| LEDs | RGB LED: red B11, green A11, blue A12, active-high |
| UART | 115200 baud 8N1 on the iCELink USB serial port: FPGA TX = B9, FPGA RX = A9 |

Memory-mapped I/O at 0x10000000:

| Address | Register | Access |
|---|---|---|
| 0x10000000 | LED: bits 2:0 = {blue, green, red}, 1 = on | read/write |
| 0x10000004 | UART_TX: write a byte to send (only when UART_STATUS bit 0 = 1) | write |
| 0x10000008 | UART_STATUS: bit 0 = transmitter ready, bit 1 = a received byte is waiting | read |
| 0x1000000C | UART_RX: the received byte; reading it clears UART_STATUS bit 1 | read |

The `mcycle` CSR counts clock cycles (12,500,000 per second) and can be used for delays.

Why 12.5 MHz: the single-cycle core does fetch, decode, register read, ALU, data RAM access and write-back in one clock;
on this FPGA that path takes about 42 ns (nextpnr: 23–24 MHz maximum), so the 25 MHz oscillator is too fast. At
12.5 MHz there is almost a factor of two of timing margin. (The pipelined cores of Stages 6–8 would run faster.)

Last build (Yosys 0.71, nextpnr-ecp5 0.11.1): 7,371 LUT4, 104 CCU2C (carry), 1,083 flip-flops, 512 TRELLIS_DPR16X4
(the data RAM), 1 PLL, 6 I/O; maximum frequency 23.26 MHz, constraint 12.5 MHz: **PASS**.

## 3. Building it yourself

Tools:

- Java and sbt (as for the rest of the project), for the Chisel → Verilog step
- Yosys, nextpnr-ecp5 and ecppack: the simplest way is the YosysHQ **oss-cad-suite**
  (https://github.com/YosysHQ/oss-cad-suite-build): download, unpack, then `source oss-cad-suite/environment`
- to program: the iCELink drive (no tool needed), or `icesprog` (https://github.com/wuxx/icesugar, tools folder)

From the `fpga` folder:

```bash
make
```

This runs `sbt "runMain rv32i.EmitFpga"` (Chisel → `build/IceSugarProTop.v`), Yosys (`synth_ecp5`), nextpnr-ecp5
(`--25k --package CABGA256 --speed 6`, pins in `icesugar_pro.lpf`) and ecppack, and leaves `build/IceSugarProTop.bit`.

```bash
make report
```

```bash
make prog ICELINK=/media/$USER/iCELink
```

`make report` shows the resource use and the maximum frequency. `make prog` copies the bitstream onto the iCELink
drive; use the drive's real mount point.

With the Python builds of the tools instead of oss-cad-suite (`pip install yowasp-yosys yowasp-nextpnr-ecp5`):

```bash
make YOWASP=1
```

## 4. Running your own program

The ROM contents are fixed when the Verilog is generated. Write a program for the memory map above (code at
0x80000000, at most 256 instructions, data and stack in the RAM at 0x80010000), as a hex file with one 32-bit word per
line, then:

```bash
cd .. && sbt "runMain rv32i.EmitFpga my_program.hex" && cd fpga && make
```

- With the project's assembler (`src/main/scala/rv32i/Asm.scala`): see `FpgaProgram` in
  `src/main/scala/rv32i/IceSugarPro.scala`, the demo, written that way.
- With GCC: compile for RV32I only, linked at 0x80000000, then convert the binary to one word per line:

```bash
riscv64-unknown-elf-gcc -march=rv32i -mabi=ilp32 -nostdlib -nostartfiles -Os -Wl,-Ttext=0x80000000 -o prog.elf start.S main.c
```

```bash
riscv64-unknown-elf-objcopy -O binary prog.elf prog.bin
```

```bash
python3 -c "import sys,struct; d=open('prog.bin','rb').read(); d+=bytes(-len(d)%4); print('\n'.join('%08x'%w for w in struct.unpack('<%dI'%(len(d)//4), d)))" > my_program.hex
```

  `start.S` has to set the stack pointer (for example `li sp, 0x80011000`) and call `main`. Only code goes into the ROM:
  the core cannot load data from the ROM (Harvard), so constant data (strings, tables) must be copied into the RAM at
  start-up, or built from instructions. The demo builds its banner in RAM with `li`/`sw`.

## 5. How it was checked

- `FpgaSpec` simulates the whole system (core, ROM, RAM, LED register, UART transmitter and receiver) cycle by cycle, with
  a fast UART: the banner arrives bit-exact on the serial line, typed characters are echoed, CR becomes CR LF, the LED
  shows each character and steps when idle; a frame with a bad stop bit is ignored.
- The 30 Stage 3 tests (core, decoder, CSRs, traps, programs in lockstep with the reference model) still pass.
- Yosys `check -assert` finds no combinational loop; synthesis, placement and routing complete; timing passes at
  12.5 MHz with an 86 % margin; ecppack produces the bitstream.
- On a real board: the banner, the echo, the core running continuously at 12.5 MHz (LED pin test), and the LED pins and
  polarity (B11 red, A11 green, A12 blue, active-high).

Pin sites come from the board vendor's repository (https://github.com/wuxx/icesugar-pro: `src/blink/blink.lpf`,
`src/uart_tx/top.lpf`, `src/litex_linux/top_bg256.lpf`).
