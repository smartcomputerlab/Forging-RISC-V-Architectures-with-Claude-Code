package rv32i

import chisel3._
import chiseltest._
import org.scalatest.flatspec.AnyFlatSpec
import org.scalatest.matchers.should.Matchers

/** The real FreeRTOS firmware (firmware/freertos.hex, the colour cycle) on the whole FPGA system, cycle by cycle:
  * the RV32IM core with its timer interrupt, the 32 KiB RAM preloaded with the image, the CLINT, the LED register
  * and the UART.
  *
  * Treadle simulates this system at about 75 cycles per second, so time runs faster than on the board: mtime counts
  * 25 per clock cycle here instead of 1 per 25 cycles, so one FreeRTOS tick (10 ms) takes 400 cycles instead of
  * 250,000. The firmware is exactly the one in the bitstream. The run covers one full round and the start of the
  * next (red 2 s, off 1 s, green 2 s, off 1 s, blue 2 s, off 1 s, red). The test decodes the UART, records every LED
  * change and checks (as tools/ledcycle_check.py):
  *  - the start-up banner;
  *  - the LED only ever shows one colour or off;
  *  - the sequence, and the length of every interval between two changes: 2 s on, 1 s off.
  * Tolerance: in this compressed time a tick lasts only 400 cycles, and handing the turn to the next task (wake-up,
  * notification, task switch) takes longer than that, so the next colour's vTaskDelay starts one tick later: each
  * colour comes about 10 ms late. An interval may therefore be up to one tick plus half a tick longer, and half a
  * tick shorter. (On the board a tick is 250,000 cycles and the handover takes a few microseconds:
  * tools/rvsim.py at the board rate sees every change within 10 us.)
  * Set FREERTOS_CYCLES to change the length (default 420,000 cycles = 10.5 s of board time, about 95 minutes; the first red comes after the boot).
  */
class FpgaFreeRtosSpec extends AnyFlatSpec with ChiselScalatestTester with Matchers {
  private val Div = 8              // UART: 8 clock cycles per bit
  private val MtimeInc = 25        // mtime counts (microseconds) per clock cycle
  private val TolUs = 5000L        // half a tick
  private val TickUs = 10000L      // one tick: handing the turn over may cost one tick here (see above)

  "FreeRTOS" should "cycle the RGB LED through red, green and blue, 2 s each, with the LED off for 1 s in between" in {
    val firmware = FpgaMap.readHex("firmware/freertos.hex")
    val total = sys.env.get("FREERTOS_CYCLES").map(_.toLong).getOrElse(420000L)
    test(new IceSugarSoC(firmware, Div, mtimeDiv = 1, mtimeInc = MtimeInc)).withAnnotations(TestUtil.waves) { c =>
      c.clock.setTimeout(0)
      c.io.uartRx.poke(true.B)
      val uart = new StringBuilder
      var rxBusy = false; var cnt = 0; var bit = 0; var shift = 0
      var led = 0
      val changes = scala.collection.mutable.ArrayBuffer.empty[(Long, Int)]   // (mtime, new LED value)
      val t0 = System.nanoTime()
      var cycle = 0L
      while (cycle < total) {
        val tx = c.io.uartTx.peek().litToBoolean
        if (!rxBusy) { if (!tx) { rxBusy = true; cnt = Div + Div / 2 - 1; bit = 0; shift = 0 } }
        else if (cnt == 0) {
          if (bit < 8) { shift |= (if (tx) 1 << bit else 0); bit += 1; cnt = Div - 1 }
          else { tx shouldBe true; uart += shift.toChar; rxBusy = false }
        } else cnt -= 1
        val l = c.io.led.peek().litValue.toInt
        if (l != led) { changes += ((cycle * MtimeInc, l)); led = l }      // mtime = 25 x cycles since reset
        c.clock.step()
        cycle += 1
      }
      val secs = (System.nanoTime() - t0) / 1e9
      val tEnd = total * MtimeInc
      info(f"$total cycles in $secs%.0f s (${total / secs}%.0f cycles/s) = ${tEnd / 1e6}%.2f s of board time")
      info("UART: " + uart.toString.trim)
      uart.toString should include("colour cycle red, green, blue")

      for ((t, v) <- changes) withClue(s"mtime $t: ") { Seq(0, 1, 2, 4) should contain(v) }
      changes should not be empty
      val start = changes.head._1
      val names = Map(0 -> "off", 1 -> "red", 2 -> "green", 4 -> "blue")
      info("LED: " + changes.map { case (t, v) => f"${names(v)} at ${(t - start) / 1e6}%.3f s" }.mkString(", "))
      // expected values: red, off, green, off, blue, off, red, ... ; and the length of every interval between two
      // changes: 2 s on, 1 s off, measured change to change
      changes.head._2 shouldBe 1
      val wantVals = Iterator.from(0).map(k => if (k % 2 == 1) 0 else Seq(1, 2, 4)((k / 2) % 3))
      for (((t, v), w) <- changes.zip(wantVals.take(changes.length).toSeq)) withClue(s"mtime $t: ") { v shouldBe w }
      // the run must reach the return to red (a full round)
      changes.length should be >= 7
      var worst = 0L
      for (k <- 1 until changes.length) {
        val got = changes(k)._1 - changes(k - 1)._1
        val nominal = if (changes(k - 1)._2 != 0) 2000000L else 1000000L
        val err = got - nominal
        withClue(s"interval ${k} (${names(changes(k - 1)._2)}): $got us, nominal $nominal us: ") {
          err should be >= -TolUs
          err should be <= (TickUs + TolUs)
        }
        worst = worst max math.abs(err)
      }
      // and no change missing at the end: the last interval must not be overdue
      val lastNominal = if (changes.last._2 != 0) 2000000L else 1000000L
      (tEnd - changes.last._1) should be < (lastNominal + TickUs + TolUs)
      info(s"worst interval error $worst us (one tick = $TickUs us, one cycle = $MtimeInc us here)")
    }
  }
}
