package rv32i

import chiseltest._
import org.scalatest.flatspec.AnyFlatSpec
import org.scalatest.matchers.should.Matchers
import TestUtil._

/** This core is RV32IM: there is no A extension. Every encoding of the AMO opcode (0x2f), the eleven LR.W / SC.W /
  * AMO*.W instructions with all four aq/rl combinations and other widths, must trap as an illegal instruction
  * (mcause 2, mtval = the instruction), and must not read or write memory or a register. Runs in lockstep with
  * [[RefModel]] (CoreSim compares every retirement and trap).
  */
class CoreNoAmoSpec extends AnyFlatSpec with ChiselScalatestTester with Matchers {
  private val Data = 0x80010000L
  private val Log  = 0x80012000L

  "Core (RV32IM)" should "trap every A-extension encoding as an illegal instruction, without side effects" in {
    val f5s = Seq(AmoFn.LR, AmoFn.SC) ++ AmoFn.Amos
    val encs = (for (f5 <- f5s; aqrl <- 0 until 4)
      yield Enc.r((f5 << 2) | aqrl, if (f5 == AmoFn.LR) 0 else 1, 10, 2, 5, 0x2f)) ++
      Seq(Enc.r(0, 1, 10, 3, 5, 0x2f))                               // amoadd.d (64-bit width)
    val a = new Asm
    a.la(30, "handler"); a.csrrw(0, CsrAddr.mtvec, 30)
    a.li(24, Log); a.li(10, Data); a.li(1, 0x5a5a5a5aL); a.sw(1, 0, 10)
    a.li(5, 1234)                                                   // rd of every encoding: must stay 1234
    encs.foreach(w => a.word(w))
    a.lw(8, 0, 10)                                                  // memory unchanged
    a.halt()
    a.label("handler")
    a.csrrs(20, CsrAddr.mcause, 0); a.sw(20, 0, 24)
    a.csrrs(21, CsrAddr.mtval, 0); a.sw(21, 4, 24); a.addi(24, 24, 8)
    a.csrrs(29, CsrAddr.mepc, 0); a.addi(29, 29, 4); a.csrrw(0, CsrAddr.mepc, 29); a.mret()
    var res: CoreSim.Result = null
    test(new Core()).withAnnotations(TestUtil.waves) { c => res = CoreSim.run(c, a.words) }
    res.traps shouldBe encs.length
    for ((w, k) <- encs.zipWithIndex) withClue(f"encoding 0x$w%08x: ") {
      res.model.mem.readWord(Log + 8L * k) shouldBe Cause.IllegalInstruction.toLong
      res.model.mem.readWord(Log + 8L * k + 4) shouldBe w
    }
    res.model.x(5) shouldBe 1234L
    res.model.x(8) shouldBe 0x5a5a5a5aL
    // none of the trapping instructions touched memory
    res.events.filter(e => (e.inst & 0x7f) == 0x2f).foreach(e => withClue(f"0x${e.inst}%08x: ") {
      e.trap shouldBe true; e.memWe shouldBe false
    })
  }

  it should "report misa = RV32IM (no A bit)" in {
    val a = new Asm
    a.csrrs(2, CsrAddr.misa, 0); a.halt()
    var res: CoreSim.Result = null
    test(new Core()) { c => res = CoreSim.run(c, a.words) }
    res.model.x(2) shouldBe 0x40001100L
    (res.model.x(2) & 1L) shouldBe 0L
  }
}
