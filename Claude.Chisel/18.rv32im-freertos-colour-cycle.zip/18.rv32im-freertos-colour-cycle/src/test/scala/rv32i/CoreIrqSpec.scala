package rv32i

import chiseltest._
import org.scalatest.flatspec.AnyFlatSpec
import org.scalatest.matchers.should.Matchers
import scala.util.Random
import TestUtil._

/** The machine timer interrupt on the full core, in lockstep with [[RefModel]]. The harness plays the timer: the line
  * (mip.MTIP) is high while the cycle number is >= the word at `Cmp`, which programs write like mtimecmp (the word
  * starts at 0xffffffff: no interrupt). CoreSim checks every interrupt taken (MIE, MTIE and the line in that cycle)
  * and every instruction that retires instead (the interrupt must not have been pending).
  */
class CoreIrqSpec extends AnyFlatSpec with ChiselScalatestTester with Matchers {
  private val Data = 0x80010000L
  private val Cmp  = Data + 0x400
  private val timer: (Long, SimMemory) => Boolean = (cycle, mem) => cycle >= mem.readWord(Cmp)

  private def run(a: Asm, data: Seq[(Long, Long)] = Nil, maxCycles: Long = 400000): CoreSim.Result = {
    var res: CoreSim.Result = null
    test(new Core()).withAnnotations(TestUtil.waves) { c =>
      res = CoreSim.run(c, a.words, data = (Cmp -> 0xffffffffL) +: data, maxCycles = maxCycles, irq = timer)
    }
    res
  }

  "Core" should "take the timer interrupt only with MIE and MTIE, before the instruction, with priority over its exception" in {
    val a = new Asm
    a.la(1, "handler"); a.csrrw(0, CsrAddr.mtvec, 1)
    a.li(10, Cmp); a.li(2, 0x80); a.li(9, Cmp + 0x10)
    a.sw(0, 0, 10)                          // mtimecmp = 0: the line goes high (the store lands at the end of MEM)
    a.nop(); a.nop()
    a.csrrs(3, CsrAddr.mip, 0)              // 0x80: pending in mip, but MIE = MTIE = 0: not taken
    a.csrrs(0, CsrAddr.mie, 2)              // MTIE = 1, MIE still 0: not taken
    a.addi(4, 0, 4)
    a.csrrsi(0, CsrAddr.mstatus, 8)         // MIE = 1: taken before the next instruction
    val firstPc = a.here
    a.addi(5, 0, 5)                         // runs after MRET (mepc = its address)
    a.sw(0, 0, 10); a.nop()                 // pending again when the ECALL reaches EX
    val ecallPc = a.here
    a.ecall()                               // the interrupt comes first, then the ECALL itself
    a.csrrc(0, CsrAddr.mie, 2)              // MTIE = 0
    a.sw(0, 0, 10); a.nop(); a.nop()
    a.addi(6, 0, 6)                         // not taken: MTIE = 0
    a.csrrs(7, CsrAddr.mip, 0)              // still pending: 0x80
    a.halt()
    a.label("handler")
    a.csrrs(20, CsrAddr.mcause, 0)
    a.blt(20, 0, "intr")                    // interrupt: mcause < 0
    a.addi(26, 26, 1)                       // exception (ECALL): count it, skip it
    a.csrrs(21, CsrAddr.mepc, 0); a.addi(21, 21, 4); a.csrrw(0, CsrAddr.mepc, 21); a.mret()
    a.label("intr")
    a.addi(25, 25, 1)                       // count interrupts
    a.li(27, 0xffffffffL); a.sw(27, 0, 10)  // acknowledge: mtimecmp = max
    a.csrrs(22, CsrAddr.mepc, 0); a.sw(22, 0, 9); a.addi(9, 9, 4)   // log mepc
    a.csrrs(23, CsrAddr.mtval, 0); a.csrrs(24, CsrAddr.mstatus, 0)
    a.mret()
    val res = run(a)
    val x = res.model.x
    x(3) shouldBe 0x80L
    x(4) shouldBe 4L; x(5) shouldBe 5L; x(6) shouldBe 6L; x(7) shouldBe 0x80L
    x(25) shouldBe 2L                                         // two interrupts
    x(26) shouldBe 1L                                         // one ECALL
    x(20) shouldBe Cause.EcallFromM.toLong                    // the last trap was the ECALL
    x(23) shouldBe 0L; x(24) shouldBe 0x1880L                 // mtval = 0; MIE -> MPIE
    res.model.mem.readWord(Cmp + 0x10) shouldBe firstPc       // mepc = the interrupted instruction
    res.model.mem.readWord(Cmp + 0x14) shouldBe ecallPc
    res.events.filter(_.intr).map(_.pc) shouldBe Seq(firstPc, ecallPc)
    res.model.mcause shouldBe Cause.EcallFromM.toLong
  }

  it should "keep a computation exact under frequent interrupts (loads, stores, MUL, DIV, read-modify-write loops)" in {
    val a = new Asm
    // the handler uses only x28..x31 and re-arms the timer 20..83 cycles ahead
    a.la(28, "handler"); a.csrrw(0, CsrAddr.mtvec, 28)
    a.li(31, 0); a.li(30, 0)
    a.li(28, Cmp); a.csrrs(29, CsrAddr.mcycle, 0); a.addi(29, 29, 40); a.sw(29, 0, 28)
    a.li(1, 0x80); a.csrrs(0, CsrAddr.mie, 1); a.csrrsi(0, CsrAddr.mstatus, 8)
    a.li(10, Data)
    // 1. sum of i*i and of (1000*i)/7, i = 1..60
    a.li(1, 0); a.li(2, 0); a.li(3, 1); a.li(4, 61); a.li(5, 7); a.li(6, 1000)
    a.label("l1"); a.mul(7, 3, 3); a.add(1, 1, 7); a.mul(8, 3, 6); a.div(8, 8, 5); a.add(2, 2, 8)
    a.addi(3, 3, 1); a.bne(3, 4, "l1")
    // 2. store 0..63, then add them up with loads
    a.li(3, 0); a.li(4, 64); a.mv(11, 10)
    a.label("l2"); a.sw(3, 0, 11); a.addi(11, 11, 4); a.addi(3, 3, 1); a.bne(3, 4, "l2")
    a.li(3, 0); a.li(12, 0); a.mv(11, 10)
    a.label("l3"); a.lw(13, 0, 11); a.add(12, 12, 13); a.addi(11, 11, 4); a.addi(3, 3, 1); a.bne(3, 4, "l3")
    // 3. 150 load/increment/store of one word, and 150 load/add-3/store of another
    a.li(14, Data + 0x200); a.li(3, 150)
    a.label("l4"); a.lw(16, 0, 14); a.addi(16, 16, 1); a.sw(16, 0, 14); a.addi(3, 3, -1); a.bne(3, 0, "l4")
    a.li(18, Data + 0x204); a.li(3, 150); a.li(19, 3)
    a.label("l5"); a.lw(17, 0, 18); a.add(17, 17, 19); a.sw(17, 0, 18); a.addi(3, 3, -1); a.bne(3, 0, "l5")
    a.lw(20, 0x200, 10); a.lw(21, 0x204, 10)
    a.csrrci(0, CsrAddr.mstatus, 8)
    a.halt()
    a.label("handler")
    a.addi(30, 30, 1)                                       // interrupts taken
    a.addi(31, 31, 13); a.andi(31, 31, 63)                  // next period: 20 + (13 k mod 64)
    a.li(28, Cmp); a.csrrs(29, CsrAddr.mcycle, 0); a.add(29, 29, 31); a.addi(29, 29, 20); a.sw(29, 0, 28)
    a.mret()
    val res = run(a)
    val x = res.model.x
    x(1) shouldBe (1L to 60L).map(i => i * i).sum
    x(2) shouldBe (1L to 60L).map(i => 1000 * i / 7).sum
    x(12) shouldBe (0L until 64L).sum
    x(20) shouldBe 150L
    x(21) shouldBe 450L
    info(s"${x(30)} interrupts")
    x(30) should be > 50L
    res.events.count(_.intr) shouldBe x(30)
  }

  it should "let a division that has started finish, and interrupt one that has not, re-running it after MRET" in {
    val a = new Asm
    a.la(28, "handler"); a.csrrw(0, CsrAddr.mtvec, 28)
    a.li(1, 0x80); a.csrrs(0, CsrAddr.mie, 1); a.csrrsi(0, CsrAddr.mstatus, 8)
    a.li(10, Cmp); a.li(5, 1000000); a.li(6, 7); a.li(9, 0)
    // for k = 0..30: arm the timer k cycles ahead, then a division; the interrupt lands before, during or after it
    a.li(12, 0); a.li(13, 31)
    a.label("loop")
    a.csrrs(11, CsrAddr.mcycle, 0); a.add(11, 11, 12); a.sw(11, 0, 10); a.nop(); a.nop()
    a.div(7, 5, 6); a.add(9, 9, 7)
    a.addi(12, 12, 1); a.bne(12, 13, "loop")
    a.halt()
    a.label("handler")
    a.addi(30, 30, 1); a.li(29, 0xffffffffL); a.sw(29, 0, 10); a.mret()
    val res = run(a)
    res.model.x(9) shouldBe 31L * (1000000L / 7)
    res.model.x(30) shouldBe 31L
    val divs = res.events.filter(e => !e.trap && (e.inst & 0x7f) == 0x33 && ((e.inst >> 25) & 0x7f) == 1)
    val beforeDiv = res.events.filter(e => e.intr && divs.exists(_.pc == e.pc))
    info(s"${beforeDiv.length} interrupts taken at a division before it started")
    beforeDiv.length should be > 0
    divs.length shouldBe 31                   // every division retired once (an interrupted one is re-run)
    divs.count(_.cycles >= 34) shouldBe 31    // and always ran in full
  }

  it should "match the reference model on 3000 random instructions with interrupts at random times" in {
    val r = new Random(23)
    val a = new Asm
    a.la(28, "handler"); a.csrrw(0, CsrAddr.mtvec, 28)
    a.li(16, Data)
    for (k <- 1 to 15) a.li(k, rnd32(r))
    a.li(31, 5); a.li(28, Cmp); a.li(29, 100); a.sw(29, 0, 28)
    a.li(29, 0x80); a.csrrs(0, CsrAddr.mie, 29); a.csrrsi(0, CsrAddr.mstatus, 8)
    def reg = 1 + r.nextInt(15)
    def src = r.nextInt(16)
    for (_ <- 0 until 3000) r.nextInt(16) match {
      case 0 => a.add(reg, src, src); case 1 => a.sub(reg, src, src); case 2 => a.xor(reg, src, src)
      case 3 => a.addi(reg, src, r.nextInt(4096) - 2048); case 4 => a.sw(src, 4 * r.nextInt(8), 16)
      case 5 => a.lw(reg, 4 * r.nextInt(8), 16)
      case 6 => if (r.nextBoolean()) a.sb(src, r.nextInt(32), 16) else a.lbu(reg, r.nextInt(32), 16)
      case 7 => a.mul(reg, src, src); case 8 => a.div(reg, src, src); case 9 => a.remu(reg, src, src)
      case 10 => a.sh(src, 2 * r.nextInt(16), 16); case 11 => a.lh(reg, 2 * r.nextInt(16), 16)
      case 12 => a.mulh(reg, src, src); case 13 => a.divu(reg, src, src)
      case 14 => val l = s"b${a.here}"; a.beq(src, src, l); a.addi(reg, 0, 1); a.label(l)
      case _ => a.csrrs(reg, CsrAddr.mip, 0)
    }
    a.csrrci(0, CsrAddr.mstatus, 8)
    a.halt()
    a.label("handler")
    a.addi(30, 30, 1)
    a.addi(31, 31, 29); a.andi(31, 31, 127)
    a.li(28, Cmp); a.csrrs(29, CsrAddr.mcycle, 0); a.add(29, 29, 31); a.addi(29, 29, 5); a.sw(29, 0, 28)
    a.mret()
    val res = run(a, data = (0 until 8).map(k => (Data + 4L * k) -> rnd32(r)))
    info(s"${res.model.x(30)} interrupts")
    res.model.x(30) should be > 40L
    res.traps shouldBe res.model.x(30)       // the only traps are the interrupts
  }
}
