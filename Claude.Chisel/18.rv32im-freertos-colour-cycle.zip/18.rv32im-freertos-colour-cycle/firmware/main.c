/* FreeRTOS application for the RV32IM core on the iCESugar-Pro: the RGB LED cycles through its colours, one at a
 * time, with the LED off in between:
 *
 *     red 2 s, off 1 s, green 2 s, off 1 s, blue 2 s, off 1 s, red again ...   (one round: 9 s)
 *
 * Each colour belongs to its own task. The three tasks take turns: a task waits for its turn, lights its colour for
 * COLOUR_ON_MS, switches the LED off, waits LED_OFF_MS and then hands the turn to the next task (red -> green ->
 * blue -> red). The turn is passed with a FreeRTOS direct-to-task notification (xTaskNotifyGive /
 * ulTaskNotifyTake), a light-weight binary semaphore built into every task. Only the task holding the turn ever
 * writes the LED, so two colours can never be on together and the off gap is always there.
 *
 * Change the two times below (or the per-colour table in main) to change the pattern.
 */
#include <stdint.h>
#include "FreeRTOS.h"
#include "task.h"

#define COLOUR_ON_MS   2000u        /* how long each colour stays on */
#define LED_OFF_MS     1000u        /* LED off between two colours */

#define IO_BASE      0x10000000UL
#define LED          ( *( volatile uint32_t * ) ( IO_BASE + 0x00 ) )   /* bits 2:0 = {blue, green, red} */
#define UART_TX      ( *( volatile uint32_t * ) ( IO_BASE + 0x04 ) )
#define UART_STATUS  ( *( volatile uint32_t * ) ( IO_BASE + 0x08 ) )   /* bit 0: transmitter ready */

#define LED_RED      1u
#define LED_GREEN    2u
#define LED_BLUE     4u

typedef struct
{
    uint32_t ulMask;           /* the colour of this task */
    uint32_t ulOnMs;           /* how long it stays on */
    TaskHandle_t * pxNext;     /* the task that gets the turn afterwards */
} ColourParams_t;

static TaskHandle_t xRedTask, xGreenTask, xBlueTask;

static const ColourParams_t xRed   = { LED_RED,   COLOUR_ON_MS, &xGreenTask };
static const ColourParams_t xGreen = { LED_GREEN, COLOUR_ON_MS, &xBlueTask };
static const ColourParams_t xBlue  = { LED_BLUE,  COLOUR_ON_MS, &xRedTask };

static void vColourTask( void * pvParameters )
{
    const ColourParams_t * p = pvParameters;

    for( ; ; )
    {
        /* Wait for the turn. (portMAX_DELAY is a very long finite wait here, hence the loop.) */
        while( ulTaskNotifyTake( pdTRUE, portMAX_DELAY ) == 0 ) { }

        LED = p->ulMask;                                  /* this colour on, the others are off */
        vTaskDelay( pdMS_TO_TICKS( p->ulOnMs ) );
        LED = 0;                                          /* LED off */
        vTaskDelay( pdMS_TO_TICKS( LED_OFF_MS ) );

        xTaskNotifyGive( *p->pxNext );                    /* hand the turn on */
    }
}

/* ---- start-up message on the UART (polled, before the scheduler starts) ---- */
static void prvPuts( const char * s )
{
    for( ; *s != 0; s++ )
    {
        while( ( UART_STATUS & 1u ) == 0 ) { }
        UART_TX = ( uint32_t ) ( uint8_t ) *s;
    }
}

/* ---- faults: stop everything and show it on the LED (all three colours blink fast) ---- */
static void prvFault( void )
{
    __asm volatile ( "csrc mstatus, 8" );           /* interrupts off */
    for( ; ; )
    {
        LED = LED_RED | LED_GREEN | LED_BLUE;
        for( volatile uint32_t i = 0; i < 200000u; i++ ) { }
        LED = 0;
        for( volatile uint32_t i = 0; i < 200000u; i++ ) { }
    }
}

void vAssertCalled( const char * file, int line )                      { ( void ) file; ( void ) line; prvFault(); }
void vApplicationMallocFailedHook( void )                               { prvFault(); }
void vApplicationStackOverflowHook( TaskHandle_t xTask, char * pcName ) { ( void ) xTask; ( void ) pcName; prvFault(); }
/* Exceptions other than ECALL (illegal instruction, misaligned access, ...) and unexpected interrupts. */
void freertos_risc_v_application_exception_handler( void )              { prvFault(); }
void freertos_risc_v_application_interrupt_handler( void )              { prvFault(); }

extern void freertos_risc_v_trap_handler( void );

int main( void )
{
    LED = 0;
    __asm volatile ( "csrw mtvec, %0" : : "r" ( freertos_risc_v_trap_handler ) );

    prvPuts( "\r\nFreeRTOS " tskKERNEL_VERSION_NUMBER " on RV32IM (5-stage pipeline, Chisel) on iCESugar-Pro: "
             "colour cycle red, green, blue (2 s on, 1 s off)\r\n" );

    xTaskCreate( vColourTask, "red",   configMINIMAL_STACK_SIZE, ( void * ) &xRed,   2, &xRedTask );
    xTaskCreate( vColourTask, "green", configMINIMAL_STACK_SIZE, ( void * ) &xGreen, 2, &xGreenTask );
    xTaskCreate( vColourTask, "blue",  configMINIMAL_STACK_SIZE, ( void * ) &xBlue,  2, &xBlueTask );

    xTaskNotifyGive( xRedTask );    /* red has the first turn */

    vTaskStartScheduler();          /* does not return */
    prvFault();
    return 0;
}
