/* FreeRTOS configuration for the RV32IM 5-stage core (Stage 11 + timer interrupt) on the iCESugar-Pro.
 *
 * Memory: 32 KiB of block RAM at 0x80000000 holds the program, its data, the FreeRTOS heap and the stacks.
 * Timer:  a CLINT-style mtime / mtimecmp at the standard addresses; mtime counts at 1 MHz on the board
 *         (25 MHz / 25), so configCPU_CLOCK_HZ is the mtime frequency, as the RISC-V port expects:
 *         one tick = configCPU_CLOCK_HZ / configTICK_RATE_HZ = 10,000 mtime counts = 10 ms.
 */
#ifndef FREERTOS_CONFIG_H
#define FREERTOS_CONFIG_H

#define configMTIME_BASE_ADDRESS                 ( 0x0200BFF8UL )
#define configMTIMECMP_BASE_ADDRESS              ( 0x02004000UL )
#define configCPU_CLOCK_HZ                       ( 1000000UL )   /* mtime frequency */
#define configTICK_RATE_HZ                       ( 100 )         /* 10 ms tick */

#define configUSE_PREEMPTION                     1
#define configUSE_TIME_SLICING                   1
#define configUSE_PORT_OPTIMISED_TASK_SELECTION  0
#define configMAX_PRIORITIES                     5
#define configMINIMAL_STACK_SIZE                 ( 128 )         /* words */
#define configMAX_TASK_NAME_LEN                  8
#define configTICK_TYPE_WIDTH_IN_BITS            TICK_TYPE_WIDTH_32_BITS
#define configIDLE_SHOULD_YIELD                  1
#define configUSE_TASK_NOTIFICATIONS             1
#define configUSE_MUTEXES                        0
#define configUSE_RECURSIVE_MUTEXES              0
#define configUSE_COUNTING_SEMAPHORES            0
#define configQUEUE_REGISTRY_SIZE                0
#define configUSE_QUEUE_SETS                     0
#define configUSE_NEWLIB_REENTRANT               0
#define configENABLE_BACKWARD_COMPATIBILITY      0
#define configUSE_MINI_LIST_ITEM                 1
#define configSTACK_DEPTH_TYPE                   uint32_t
#define configHEAP_CLEAR_MEMORY_ON_FREE          0

#define configSUPPORT_STATIC_ALLOCATION          0
#define configSUPPORT_DYNAMIC_ALLOCATION         1
#define configTOTAL_HEAP_SIZE                    ( 12 * 1024 )
#define configAPPLICATION_ALLOCATED_HEAP         0

#define configUSE_IDLE_HOOK                      0
#define configUSE_TICK_HOOK                      0
#define configCHECK_FOR_STACK_OVERFLOW           2
#define configUSE_MALLOC_FAILED_HOOK             1
#define configUSE_DAEMON_TASK_STARTUP_HOOK       0

#define configGENERATE_RUN_TIME_STATS            0
#define configUSE_TRACE_FACILITY                 0
#define configUSE_STATS_FORMATTING_FUNCTIONS     0
#define configUSE_CO_ROUTINES                    0
#define configUSE_TIMERS                         0

#define INCLUDE_vTaskPrioritySet                 0
#define INCLUDE_uxTaskPriorityGet                0
#define INCLUDE_vTaskDelete                      0
#define INCLUDE_vTaskSuspend                     0
#define INCLUDE_xTaskDelayUntil                  1
#define INCLUDE_vTaskDelay                       1
#define INCLUDE_xTaskGetSchedulerState           0
#define INCLUDE_xTaskGetCurrentTaskHandle        0
#define INCLUDE_uxTaskGetStackHighWaterMark      0

/* A failed assertion stops the system and shows it on the LED (see main.c). */
void vAssertCalled( const char * file, int line );
#define configASSERT( x )    if( ( x ) == 0 ) vAssertCalled( __FILE__, __LINE__ )

#endif /* FREERTOS_CONFIG_H */
