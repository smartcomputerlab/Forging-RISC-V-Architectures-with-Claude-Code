# The core: RV32IM 5-stage pipeline with the machine timer interrupt

The Stage 7 core (RV32IM, 5-stage pipeline IF / ID / EX / MEM / WB with forwarding, load-use stall, static not-taken
branch prediction, parallel multiplier, sequential divider, Zicsr, precise machine-mode traps) with the **machine
timer interrupt** added for FreeRTOS. misa reads `0x40001100` (RV32IM).

This is the core of the earlier FreeRTOS examples (Stage 11, RV32IMA) with the **A extension taken out**. FreeRTOS on
a single hart does not need it: the kernel protects its data by switching interrupts off (`csrc mstatus, 8`), and the
compiler, told `-march=rv32im`, emits no LR, SC or AMO. In this core every encoding of the AMO opcode (0x2f) is an
illegal instruction: it traps with mcause 2 and mtval = the instruction, without touching memory or a register.
Removed with it: the MEM-stage read-modify-write, the LR/SC reservation, and their decoder outputs.

Everything else is unchanged: same ports, same timing for all 56 RV32IM + Zicsr + SYSTEM instructions, the same
interrupt behaviour, the same reference model (without the A extension), the same waveform tooling.

## Requirements

- Java 11 or newer (tested with Java 21)
- sbt 1.10 (https://www.scala-sbt.org/download/)
- No simulator to install: chiseltest runs on Treadle (pure Scala).
- For `Emit` only: CIRCT firtool on the PATH (target 1.37.0). Without it, `Emit` falls back to Chisel 3's built-in
  legacy compiler and prints a warning.

Versions are pinned in `build.sbt`: Scala 2.13.12, Chisel 3.6.1 (+ chisel3-plugin), chiseltest 0.6.2.

## Commands

Run all tests:

```bash
sbt test
```

Run one suite:

```bash
sbt "testOnly rv32i.CoreProgramSpec"
```

Generate SystemVerilog for `Core` into `generated/`:

```bash
sbt "runMain rv32i.Emit"
```

Install firtool 1.37.0 first to get firtool output with `-disable-all-randomization -strip-debug-info`
(Linux shown; use `firrtl-bin-macos-11.tar.gz` on macOS):

```bash
curl -sSL https://github.com/llvm/circt/releases/download/firtool-1.37.0/firrtl-bin-ubuntu-20.04.tar.gz | tar xz
export PATH="$PWD/firtool-1.37.0/bin:$PATH"
```

## Source files (`src/main/scala/rv32i/`)

| File | Contents |
|---|---|
| `Defs.scala` | Opcodes, `AmoFn` (funct5 codes of the A extension, kept only for the tests that check they trap), exception causes, CSR addresses (misa = RV32IM), `ASrc`/`WbSel`/`ImmSel`/`AluOp` enums, memory port and `Trace` bundles, pipeline registers `IfId`, `IdEx` (+ `Ctrl` with `lr`/`sc`/`amo`), `ExMem`, `MemWb` |
| `Decoder.scala` | RV32I + A + Zicsr + SYSTEM decoder; flags illegal encodings (the core decodes the M extension itself) |
| `ImmGen.scala` | I/S/B/U/J immediates |
| `RegFile.scala` | 32 × 32 register file, 2 read ports, 1 write port, x0 hardwired to zero |
| `Alu.scala` | ADD, SUB, shifts, comparisons, logic |
| `Multiplier.scala` | MUL, MULH, MULHSU, MULHU on one shared 33 × 33 multiplier (1 cycle) |
| `DivUnit.scala` | Sequential DIV, DIVU, REM, REMU (restoring, 1 bit/cycle) and `DivRef`, the software reference |
| `CsrFile.scala` | Machine-mode CSRs, counters, trap entry and MRET |
| `Core.scala` | The 5-stage pipelined RV32IM core (top-level module): the five stages, forwarding, load-use detection, redirect and divider stall control, the timer interrupt |
| `RefModel.scala` | Instruction-level reference model (`RefModel`, RV32IM) and sparse memory (`SimMemory`) |
| `Emit.scala` | SystemVerilog generation |

## Tests (`src/test/scala/rv32i/`)

| Suite | What it checks |
|---|---|
| `AluSpec` | Every ALU operation on all pairs of 22 edge values and 3,000 random operand pairs |
| `ImmGenSpec` | All five immediate formats on 500 random instructions per format |
| `RegFileSpec` | x0 hardwired to zero, all 31 registers, write enable, old value during a write |
| `DecoderSpec` | All RV32I/Zicsr/SYSTEM instructions with their control signals; illegal encodings, including all 512 encodings of the AMO opcode tested (8 widths x 32 funct5 x 2 aq/rl settings); all 128 major opcodes |
| `CsrFileSpec` | CSRRW/RS/RC, misa (RV32IM)/mhartid/WARL masks, illegal accesses, counters, trap entry and MRET |
| `MultiplierSpec` | MUL/MULH/MULHSU/MULHU on 484 edge pairs and 2,000 random pairs against BigInt |
| `DivRefSpec`, `DivUnitSpec` | The division reference against the spec's table; the divider on 1,024 edge cases and 2,000 random ones, exact latency, kill, handshake |
| `CoreDivSpec` | 40 division programs on the core with exact stall lengths, result forwarding to the next division, rd = x0 |
| `CoreProgramSpec` | Lockstep against `RefModel`: arithmetic, loads/stores, branches/jumps, dependency chains, M extension (corner cases, gcd, factorial), Zicsr and all six exception types, and 3,000 random instructions |
| `CoreNoAmoSpec` | **No A extension**, in lockstep with `RefModel`: LR.W, SC.W and the nine AMOs, each with the four aq/rl combinations, and a 64-bit-width AMO, all trap as illegal instructions (mcause 2, mtval = the instruction) and change neither memory nor rd; misa = RV32IM |
| `CoreIrqSpec` | **The machine timer interrupt** (this project), in lockstep with `RefModel`, which also checks that every pending interrupt is taken at the right instruction: only with MIE and MTIE, mip.MTIP, taken before the instruction (mepc = its pc, mcause = 0x80000007, mtval = 0), priority over that instruction's ECALL; a computation (MUL, DIV, loads, stores, read-modify-write loops) exact under frequent interrupts; a division that started finishes, one that has not is interrupted and re-run; 3,000 random instructions with interrupts at random times |
| `CoreTimingSpec` | Pipeline timing: all 56 instructions; 1 per cycle, +2 bubbles after every taken branch/jump/trap/MRET, +1 for load-use, forwarding without stalls, DIV/DIVU/REM/REMU 34 cycles (2 for divide-by-zero and overflow); the two wrong-path instructions behind a redirect have no effect |
| `WaveformSpec` | Four demo runs (also checked against `RefModel`) that write VCD waveforms and GTKWave session files to `waves/` |

Test helpers: `Asm.scala` (a two-pass assembler with labels), `CoreSim.scala` (the lockstep harness),
`Disasm.scala` (disassembler for listings and GTKWave filters), `Gtkw.scala` (GTKWave session writer) and
`TestUtil.scala` (shared values and the `WAVES` switch).

In this project all 40 core tests pass (about 13 minutes), including `CoreNoAmoSpec` and the 4 of `CoreIrqSpec`.

## Interface of `Core`

This project adds one input, `timerIrq` (mip.MTIP), and the trace's `intr` bit (the trap is the interrupt).

```scala
class Core(resetPc: Long = 0x80000000L, hartId: Int = 0) extends Module {
  val io = IO(new Bundle {
    val imem  = new InstrMemPort   // addr out, data in (combinational)
    val dmem  = new DataMemPort    // addr, re, we, wdata, wstrb out; rdata in (combinational, aligned word)
    val trace = Output(new Trace)  // WB stage: one retirement or trap per cycle, or neither (bubble)
  })
}
```

See `DESIGN_NOTES.md` for the execution rules and every design choice.

## Waveforms with GTKWave

Install GTKWave:

```bash
sudo apt-get install -y gtkwave
```

On macOS: `brew install --cask gtkwave`. On Windows: download it from https://gtkwave.sourceforge.net.

### Demo waveforms (`waves/`)

```bash
sbt "testOnly rv32i.WaveformSpec"
```

Each demo is checked against the reference model, then written to `waves/<demo>/`:

| Demo | What to look at |
|---|---|
| `waves/div_rem/` | DIV, REM, DIVU (33 stall cycles each), divide-by-zero and overflow (1 stall cycle each), MUL in one cycle, results used by the next instruction |
| `waves/load_store_branch/` | A loop with stores, loads of every size, a call and a return |
| `waves/trap/` | ECALL and an illegal instruction: trap to the handler, mcause/mepc, MRET |
| `waves/div_unit/` | The divider alone: request, 32 iterations, response, for DIV, REM and a divide-by-zero |

Every demo folder holds:

- `Core.vcd` (or `DivUnit.vcd`): the waveform, with every signal of every submodule
- `core.gtkw` (or `divunit.gtkw`): a GTKWave session with the useful signals already grouped and formatted
- `inst.filter`: shows the instruction bus as assembly (`div x3, x1, x2`) instead of hex
- `divstate.filter`: shows the divider state as IDLE / BUSY / DONE
- `program.lst`: the program with addresses, instruction words and disassembly

Open a demo **from the project root** (the session files use paths relative to it):

```bash
gtkwave waves/div_rem/Core.vcd waves/div_rem/core.gtkw
```

```bash
gtkwave waves/div_unit/DivUnit.vcd waves/div_unit/divunit.gtkw
```

The core view has these groups:

| Group | Signals |
|---|---|
| Clock | `clock`, `reset` |
| IF fetch | `fetchPc`, the fetched word (as assembly) |
| ID decode | `ifid_valid` (0 = bubble), `ifid_pc`, `idInst`, `loadUse`, register values read |
| EX execute | `idex_valid`, `idex_pc`, `idex_inst`, forwarding selects (`a_fromMem`, `a_fromWb`, `b_fromMem`, `b_fromWb`), operands `a`/`b`, `exResult`, `divStall`, `trapNow`, `redirect`, `nextPc` |
| MEM memory | `exmem_valid`, `exmem_inst`, `exmem_trap`, `exmem_result`, data-memory port |
| WB write-back | `memwb_valid`, `memwb_inst`, `memwb_trap`, `wbWrites`, `memwb_rd`, `memwb_wdata` |
| Retire / trap | `io_trace_valid`, `io_trace_trap`, `io_trace_cause`, `io_trace_pc`, `io_trace_rdAddr`, `io_trace_rdData` (signed) |
| Divider | request (`valid`, `ready`, `op`, `a`, `b`), `state`, `count`, `quot`, `rem`, `divisor`, signs, response |
| Data memory | `memRe`, `memWe`, address, read data, write data, byte strobes |
| Registers x1..x15 | `rf.regs_1` … `rf.regs_15` in signed decimal |
| CSRs | `mtvec`, `mepc`, `mcause`, `mcycle`, `minstret` |

All other signals of the design are in the VCD too; add them from GTKWave's signal tree.
Reading the pipeline: an instruction moves down one group per cycle (IF → ID → EX → MEM → WB). When `redirect` is
high, `ifid_valid` and `idex_valid` drop to 0 in the next cycle (two wrong-path instructions discarded) and `fetchPc`
jumps to the target. When `loadUse` is high, the instruction stays in ID for one more cycle and a bubble enters EX.
Reading a division in `div_rem`: `isDiv` rises, `divStall` stays high while `state` = BUSY and `count`
runs 0…31 (meanwhile IF, ID and EX hold their instructions and bubbles flow through MEM and WB), `io_resp_valid` pulses in the DONE cycle, and `io_trace_valid` retires the instruction
in that same cycle.

### Assembly text on instruction signals

GTKWave shows assembly instead of hex through a *translate filter*. Two kinds are available:

- **Filter file** (`waves/<demo>/inst.filter`, used by the demo `core.gtkw` sessions): one line per instruction
  word of that program, `<hex word> <assembly>`, written by `WaveformSpec` from `Disasm`.
- **Filter process** (`tools/rv32im_filter.py`): disassembles any RV32IM/Zicsr word, so it works on every VCD,
  including those from `WAVES=1 sbt test`. Branch/jump targets appear as offsets (`pc-4`).

To apply either one in GTKWave: select the instruction traces (e.g. `io_trace_inst`, `idInst`, `idex_inst`,
`exmem_inst`, `memwb_inst`), set **Data Format → Hex**, then **Data Format → Translate Filter File → Enable and
Select** (choose an `inst.filter`) or **Data Format → Translate Filter Process → Enable and Select** (choose
`tools/rv32im_filter.py`, which must be executable: `chmod +x tools/rv32im_filter.py`). Save the session with
**File → Write Save File** to keep it.

### A VCD for any test

```bash
WAVES=1 sbt test
```

or, for one suite:

```bash
WAVES=1 sbt "testOnly rv32i.CoreDivSpec"
```

chiseltest then writes `test_run_dir/<test name>/<Module>.vcd` for every hardware test, for example
`test_run_dir/Core_should_execute_DIV_DIVU_REM_and_REMU_including_the_specs_corner_cases/Core.vcd`.
Open it with `gtkwave <file>`, or with a demo's session file to reuse its signal layout:

```bash
gtkwave test_run_dir/<test name>/Core.vcd waves/div_rem/core.gtkw
```

`sbt -Dwaves=1 test` does the same as `WAVES=1`. Without either, no VCD is written, so the normal test run stays fast.
