# FreeRTOS on the RV32IM core on the iCESugar-Pro: colour cycle

The colour-cycle FreeRTOS example on an **RV32IM** core: the 5-stage pipeline written in Chisel, with the machine
timer interrupt, but **without the A extension** (atomic instructions), on the **iCESugar-Pro** board (Lattice ECP5
LFE5U-25F). The application is the same as in the RV32IMA colour-cycle example. The on-board **RGB LED** shows one
colour at a time, with the LED **off** in between:

```
red 2 s -> off 1 s -> green 2 s -> off 1 s -> blue 2 s -> off 1 s -> red ...      (one round: 9 s)
```

Each colour belongs to its own FreeRTOS task. The three tasks take turns, passing a token in a ring with FreeRTOS
task notifications.

A ready-made bitstream is included: `fpga/IceSugarProTop.bit`.

## 1. Quick start with the ready-made bitstream

1. Connect the iCESugar-Pro with a USB-C cable. The on-board iCELink appears as a USB drive called **iCELink** and as a
   serial port (`/dev/ttyACM0` on Linux).
2. Optional: open a terminal at **115200 baud, 8N1** before programming, to see the start-up message:

   ```bash
   picocom -b 115200 /dev/ttyACM0
   ```

3. Copy `fpga/IceSugarProTop.bit` onto the iCELink drive, or run:

   ```bash
   icesprog fpga/IceSugarProTop.bit
   ```

The terminal shows:

```
FreeRTOS V11.1.0 on RV32IM (5-stage pipeline, Chisel) on iCESugar-Pro: colour cycle red, green, blue (2 s on, 1 s off)
```

and the LED starts with red. If all three colours **blink fast together**, the firmware has stopped on a fault
(failed assertion, stack overflow, out of heap, or an unexpected exception): see `prvFault` in `firmware/main.c`.

## 2. The application (`firmware/main.c`)

The two times are at the top of the file:

```c
#define COLOUR_ON_MS   2000u        /* how long each colour stays on */
#define LED_OFF_MS     1000u        /* LED off between two colours */
```

One task function serves the three colours; each task gets its own parameter block: its colour, how long it stays
on, and which task comes next.

```c
static const ColourParams_t xRed   = { LED_RED,   COLOUR_ON_MS, &xGreenTask };
static const ColourParams_t xGreen = { LED_GREEN, COLOUR_ON_MS, &xBlueTask };
static const ColourParams_t xBlue  = { LED_BLUE,  COLOUR_ON_MS, &xRedTask };

static void vColourTask( void * pvParameters )
{
    const ColourParams_t * p = pvParameters;
    for( ; ; )
    {
        while( ulTaskNotifyTake( pdTRUE, portMAX_DELAY ) == 0 ) { }   /* wait for the turn */
        LED = p->ulMask;                                              /* this colour on */
        vTaskDelay( pdMS_TO_TICKS( p->ulOnMs ) );
        LED = 0;                                                      /* LED off */
        vTaskDelay( pdMS_TO_TICKS( LED_OFF_MS ) );
        xTaskNotifyGive( *p->pxNext );                                /* hand the turn on */
    }
}
```

`main()` creates the three tasks (all priority 2), gives red the first turn with `xTaskNotifyGive( xRedTask )` and
starts the scheduler.

**How the turn passes.** A direct-to-task notification works like a binary semaphore built into each task.
`ulTaskNotifyTake` blocks the task until another task calls `xTaskNotifyGive` for it. Exactly one task holds the
turn at any time; the other two are blocked and use no CPU. While the holder waits in `vTaskDelay`, all three are
blocked, and the FreeRTOS idle task runs.

**Why plain stores are enough here.** Only the task that holds the turn writes the LED, so there is never a second
writer to interfere with: a simple `LED = mask` is safe, and two colours can never be on together.

## Why FreeRTOS does not need the A extension

FreeRTOS runs here on a single core (one hart). The kernel protects its lists and counters by switching interrupts
off for a few instructions (`portDISABLE_INTERRUPTS` is `csrc mstatus, 8` in the RISC-V port): with one hart and no
interrupt, nothing can run between a read and the write that follows it. Neither the kernel, the port nor this
application uses an atomic instruction, and the compiler is told the core has none (`-march=rv32im`): the firmware
contains no word with the AMO opcode. (Only an application that shares data between tasks and interrupts *without*
a critical section would want atomics, like the AMOs of the "3 independent tasks" example; the same code on RV32IM
would wrap each update in `taskENTER_CRITICAL()` / `taskEXIT_CRITICAL()`.)

The core of the earlier examples (RV32IMA) was changed as follows:

- the decoder no longer recognises the AMO opcode (0x2f): LR.W, SC.W and the nine AMO*.W are illegal instructions
  and trap (mcause 2, mtval = the instruction), without touching memory or a register;
- the read-modify-write in the MEM stage and the LR/SC reservation are gone;
- misa reads `0x40001100` (RV32IM; the A bit is 0);
- the instruction-level simulator `tools/rvsim.py` stops with "illegal instruction" on any AMO, as the hardware would
  trap.

The firmware image is the same as in the RV32IMA colour-cycle example except for the start-up message: compiled for
`rv32im`, the code is identical, because the RV32IMA build had no atomic instruction either.

**Changing the pattern:**

- all colours on for 1 s and off for 2 s: set `COLOUR_ON_MS` to 1000 and `LED_OFF_MS` to 2000;
- a different time per colour: change `COLOUR_ON_MS` in one of the three parameter blocks (e.g. `1000u` for red);
- another order: change the `&x...Task` links, and which task gets the first `xTaskNotifyGive` in `main()`.

The times are in milliseconds and are rounded to the 10 ms tick. After a change, check at instruction level and
rebuild the bitstream (section 4). The checker `tools/ledcycle_check.py` has the same two times at its top
(`ON_US`, `OFF_US`): change them too.

## 3. The system

Unchanged from the earlier examples, except the core:

| Block | Details |
|---|---|
| Clock | 25 MHz oscillator (P6), used directly: **25 MHz** system clock |
| Core | RV32IM 5-stage pipeline + the machine timer interrupt (no A extension); reset pc 0x80000000 |
| RAM | **32 KiB at 0x80000000**: one memory for instructions and data, block RAM, loaded with the firmware by the bitstream |
| CLINT | mtimecmp at 0x02004000, mtime at 0x0200BFF8; mtime counts at **1 MHz**; MTIP = mtime >= mtimecmp |
| LED | 0x10000000: bits 2:0 = {blue, green, red}, 1 = on (pins B11 red, A11 green, A12 blue) |
| UART | 0x10000004 TX, 0x10000008 status, 0x1000000C RX; 115200 baud 8N1 on the iCELink serial port (B9 TX, A9 RX) |

FreeRTOS configuration (`firmware/FreeRTOSConfig.h`, unchanged): preemptive, 5 priorities, tick 100 Hz (10 ms),
task notifications on, heap_4 with 12 KiB, stack overflow checking, assertions on.

Memory use: the image is 7,244 bytes (6,912 code, 320 read-only data, 12 data). Then `.bss` (12,560 bytes, mostly
the 12 KiB heap with the four task control blocks and 512-byte stacks) and the 1 KiB interrupt stack: about 21 KiB of
the 32 KiB.

Last build (Yosys 0.71, nextpnr-ecp5 0.11.1), compared with the RV32IMA colour-cycle example:

| Resource | RV32IM (this) | RV32IMA | Of |
|---|---|---|---|
| LUT4 (Yosys) | 7,576 | 8,230 | |
| Logic cells (nextpnr) | 8,410 (34 %) | 9,138 (37 %) | 24,288 |
| Flip-flops | 2,116 (8 %) | 2,158 (9 %) | 24,288 |
| DP16KD block RAM | 32 (all 32 carry the firmware image) | 32 | 56 |
| MULT18X18D | 4 | 4 | 28 |

Without the A extension the system needs 654 fewer LUT4 (8 %) and 42 fewer flip-flops.

Maximum frequency **40.07 MHz** (RV32IMA: 40.66 MHz, the difference is placement noise), constraint 25 MHz: **PASS**.

## 4. Building it yourself

Tools:

- **Firmware:** clang and ld.lld with the RISC-V target (LLVM 14 or newer; Ubuntu: `sudo apt install clang lld llvm`),
  or a GNU RISC-V toolchain (`make GCC=1`), and Python 3
- **Hardware:** Java 11+ and sbt for Chisel; Yosys, nextpnr-ecp5 and ecppack (the YosysHQ oss-cad-suite, or
  `make YOWASP=1` with `pip install yowasp-yosys yowasp-nextpnr-ecp5`)

Everything at once, from the `fpga` folder:

```bash
make
```

This builds the firmware (`firmware/freertos.hex`), generates the Verilog with the firmware in the RAM
(`sbt "runMain rv32i.EmitFpga"`), then runs Yosys, nextpnr-ecp5 and ecppack and leaves `fpga/build/IceSugarProTop.bit`.

Only the firmware, from the `firmware` folder:

```bash
make
```

After changing the application, check it at instruction level (about 2 minutes), then run `make` in `fpga` again:
the new firmware has to go into the bitstream.

```bash
python3 tools/rvsim.py firmware/freertos.hex
```

## 5. How it was checked

The checks compare every LED change with the intended pattern (`tools/ledcycle_check.py`): the LED shows one colour
or nothing, the order is red, off, green, off, blue, off, and every change happens at its planned time. To make sure
the checks can fail, they were given five broken logs, and all five were caught: no off gap, two colours on
together, the wrong order, an off gap 0.5 s too short, and a colour missing.

1. **The core:** all 40 core tests pass (13 minutes): the ALU, decoder, registers, CSRs, multiplier and divider
   units; the core in lockstep with an independent instruction-level model (programs, timing, every exception);
   `CoreIrqSpec` for the timer interrupt; and `CoreNoAmoSpec`, new: every A-extension instruction (LR.W, SC.W, the
   nine AMOs, with all aq/rl settings) traps as an illegal instruction and changes neither memory nor a register,
   and misa reads RV32IM. The decoder test also tries all 512 encodings of the AMO opcode. (The RV32IMA core had 48
   tests: the 6 A-extension tests and the atomics waveform demo are gone, and one new test checks the traps.)

   ```bash
   sbt "testOnly rv32i.AluSpec rv32i.CoreDivSpec rv32i.CoreIrqSpec rv32i.CoreNoAmoSpec rv32i.CoreProgramSpec rv32i.CoreTimingSpec rv32i.CsrFileSpec rv32i.DecoderSpec rv32i.DivUnitSpec rv32i.ImmGenSpec rv32i.MultiplierSpec rv32i.RegFileSpec rv32i.WaveformSpec"
   ```

   (`sbt test` runs these and also `FpgaFreeRtosSpec`, which takes about 70 to 95 minutes.)
2. **The firmware at instruction level** (`tools/rvsim.py`, a separate simulator of the whole system, in Python):
   **pass.** Fast setting: 13 LED changes (red 0, off 2, green 3, off 5, blue 6, off 8, red 9, off 11 s ...),
   worst timing error 49 µs. Board rate (25 MHz, 19 s, 475 million instructions, 1899 timer interrupts): 13 changes,
   worst error 10 µs. Fed the firmware of the 3-task example (which uses `amoor.w`), the simulator stops with
   `illegal instruction 4094202f`, as the core does.

   ```bash
   python3 tools/rvsim.py firmware/freertos.hex                          # 20 s, fast setting
   python3 tools/rvsim.py firmware/freertos.hex --seconds 19 --div 25    # board rate, about 12 minutes
   ```

3. **The whole system, cycle by cycle** (`FpgaFreeRtosSpec`): the generated hardware (core, RAM with the firmware
   image, CLINT, LED, UART) runs the real firmware in the Chisel simulator. To make it feasible, time runs faster:
   mtime counts 25 per clock cycle (one tick every 400 cycles instead of 250,000; the firmware is unchanged), so
   420,000 cycles cover 10.5 s of board time: the boot, a full round and the return to red. The test checks the banner,
   that the LED only ever shows one colour or nothing, the order, and the length of every interval. In this
   compressed time, a tick lasts only 400 cycles. Handing the turn to the next task (wake-up, notification, task
   switch) takes longer than that, so each new colour starts about one tick (10 ms) late: the test allows one tick
   plus 5 ms. On the board a tick is 250,000 cycles and the handover takes microseconds (see item 2).
   **pass**: 420,000 cycles in 70 minutes. LED: red at 0.000 s, off 2.001, green 3.012, off 5.011, blue 6.022,
   off 8.021, red 9.031 s; worst interval error 10.8 ms (one tick plus 0.8 ms). Same result as the RV32IMA core.

   ```bash
   sbt "testOnly rv32i.FpgaFreeRtosSpec"
   ```

4. **The hardware build:** synthesis, placement and routing complete, timing passes at 25 MHz, all 32 block RAMs carry
   the firmware image, and ecppack produces the bitstream.

**Not done:** this bitstream has not been run on a real board yet (the RV32IMA examples, with the same system around
the core, have),
and the routed netlist was not simulated (no gate-level simulator was available).

## 6. Files

| Path | Contents |
|---|---|
| `firmware/main.c` | **The application**: `vColourTask` (three tasks), the turn passing, start-up message, fault handler |
| `firmware/` | Also `FreeRTOSConfig.h`, `start.S`, `link.ld`, `lib.c` + `include/` (minimal C library), `Makefile`, `tohex.py`, `FreeRTOS-Kernel/` (V11.1.0: kernel, RISC-V port, heap_4, MIT licence), and the built `freertos.elf` / `.hex` / `.lst` |
| `src/main/scala/rv32i/` | The core (`Core`, `CsrFile`, `Decoder`, …, see `CORE.md`), the system and top level (`IceSugarPro.scala`: `IceSugarSoC`, `Clint`, `IceSugarProTop`, `EmitFpga`), the UART |
| `src/test/scala/rv32i/` | Core tests (including `CoreNoAmoSpec`: no A extension), `FpgaFreeRtosSpec` (this application on the whole system) |
| `fpga/` | `Makefile`, `icesugar_pro.lpf` (pins), `IceSugarProTop.bit`, `build/` (Verilog, logs) |
| `tools/rvsim.py`, `tools/ledcycle_check.py`, `tools/rv32im_filter.py` | Instruction-level simulator of the system (RV32IM: stops on any AMO); the LED pattern check; GTKWave disassembly filter |
| `CORE.md`, `DESIGN_NOTES.md` | The core: instructions, tests, interface, waveforms; design choices, including the interrupt |
