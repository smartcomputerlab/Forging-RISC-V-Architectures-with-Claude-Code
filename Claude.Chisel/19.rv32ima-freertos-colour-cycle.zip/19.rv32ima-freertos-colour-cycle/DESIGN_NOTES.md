# Design notes: RV32IMA 5-stage pipelined core with atomics and a machine timer interrupt, and the FreeRTOS system

## Architecture

| Item | Choice |
|---|---|
| ISA | RV32I + M (MUL, MULH, MULHSU, MULHU, DIV, DIVU, REM, REMU) + **A** (LR.W, SC.W, AMOSWAP/ADD/XOR/AND/OR/MIN/MAX/MINU/MAXU.W) + Zicsr, machine mode only |
| Microarchitecture | Classic 5-stage pipeline: IF, ID, EX, MEM, WB, with forwarding and hazard detection: the Stage 7 core, extended |
| Branch prediction | Static not-taken: fetch always continues at pc + 4; branches and jumps resolve in EX, a taken branch/jump, trap or MRET costs 2 bubbles |
| Reset | pc = `0x80000000` (`Core(resetPc = ...)`), all registers and CSRs = 0 |
| Memories | Harvard, zero-wait ports: instruction and data read data are combinational functions of the address; stores land at the clock edge under a 4-bit byte mask |
| Multiply | Combinational, one shared 33 × 33 signed multiplier for all four MUL variants (1 cycle) |
| Atomics | Executed in MEM in one cycle: an AMO reads and writes its word in the same cycle; one LR/SC reservation (a word address) |
| Divide | Sequential restoring divider, one quotient bit per cycle: 34 cycles per DIV/DIVU/REM/REMU, 2 cycles for divide-by-zero and signed overflow |
| Interrupts | The machine timer interrupt (mip.MTIP from the system's CLINT), taken in EX (see below) |

## Pipeline

```
  IF            ID                    EX                         MEM             WB
fetchPc ─► IfId ─► Decoder, ImmGen ─► IdEx ─► forward ─► Alu/Mul ─► ExMem ─► dmem ─► MemWb ─► RegFile write
  ▲  imem          RegFile read  ▲            │          DivUnit             load align        trace
  │                (WB bypass)   │            │          CsrFile, branch, traps
  └──── redirect (nextPc) ◄──────┼────────────┘
                                 └── forwarding from ExMem (non-load) and MemWb
```

| Stage | Work | Pipeline register written |
|---|---|---|
| IF | Read the instruction at `fetchPc`; next fetch at `fetchPc + 4` | `IfId` (valid, pc, inst) |
| ID | Decode, immediate, register read with WB→ID bypass, load-use detection | `IdEx` (pc, inst, rs1/rs2/rd, operand values, imm, `Ctrl`) |
| EX | Forwarding, ALU, multiplier, divider, branch/jump resolution, CSR access, exception detection, trap entry, commit | `ExMem` (result, memory request, trap record, next pc) |
| MEM | Data memory access, load alignment and extension; AMO read-modify-write; LR/SC reservation | `MemWb` (write-back value, trace record) |
| WB | Register write, retirement trace | - |

Pipeline control, by priority:

| Condition | fetchPc, IfId | IdEx | ExMem |
|---|---|---|---|
| `divStall` (DIV/REM busy in EX) | hold | hold | bubble |
| `redirect` (taken branch, JAL, JALR, trap, MRET in EX) | fetchPc := target, IfId := bubble | bubble | the EX instruction (or its trap record) |
| `loadUse` (ID reads the destination of a load in EX) | hold | bubble | the load |
| otherwise | advance | advance | advance |

MEM and WB never stall.

## Hazards

| Hazard | Handling | Cost |
|---|---|---|
| RAW, distance 1 (producer in MEM) | Forward `ExMem.result` into EX (not for loads) | 0 |
| RAW, distance 2 (producer in WB) | Forward `MemWb.wdata` into EX | 0 |
| RAW, distance 3 (producer writing in WB while consumer is in ID) | WB→ID bypass of the register read | 0 |
| Load-use (load immediately followed by a reader of its rd) | Stall IF/ID one cycle, bubble into EX, then forward from WB | 1 cycle |
| Control (taken branch, JAL, JALR, trap, MRET) | Resolved in EX; flush IfId and IdEx; fetch the target | 2 cycles |
| Divider | IF/ID/EX freeze for 33 cycles (1 for divide-by-zero and overflow); MEM/WB drain | 33 cycles |
| CSR read-after-write | All CSR reads and writes happen in EX, in program order | 0 |
| Store data from a load | Store data is forwarded in EX like any rs2, so a load followed by a store of its rd is a load-use stall | 1 cycle |

Only real source registers count (`Ctrl.usesRs1` / `usesRs2`): LUI, AUIPC, JAL, CSR-immediate and SYSTEM instructions
never cause a false stall.

## The A extension

All eleven instructions are word-sized (funct3 = 010), take their address from rs1 with no offset, and are executed
in MEM:

| Instruction | MEM does | rd | Trace |
|---|---|---|---|
| LR.W | read the word; reserve its word address | the word | read |
| SC.W | if the reservation is valid and on this word: write rs2; always clear the reservation | 0 = stored, 1 = failed | write (only when it stored) |
| AMO*.W | read the old word, write f(old, rs2) in the same cycle | the old word | read and write (the value written) |

f is: SWAP rs2, ADD old + rs2, XOR, AND, OR, MIN / MAX (signed), MINU / MAXU (unsigned).

```
              EX                                   MEM
   rs1 ──► address (no ALU offset) ──► ExMem ──► dmem.addr ──► rdata ─┬──────────────────► rd (old word)
   rs2 ──► forwarded like store data ─► ExMem ─────────────┐          │
                                                            └─► f(old, rs2) ─► dmem.wdata (written at the clock edge)
                     reservation (valid, word address) ◄── set by LR, cleared by SC / trap / MRET
                     scOk = valid && same word ─► dmem.we for SC, rd = 0 / 1
```

**Why one cycle is atomic here.** The data port reads combinationally and writes at the clock edge, so the old word
is read and the new word written in the same MEM cycle, with nothing in between: no other instruction is in MEM, and
the core is the only master on the port. A memory with a registered read (block RAM) or a bus with other masters
would need a two-cycle read-then-write sequence that holds the port; the trace and the reference model would not
change.

**Hazards.** The result of LR, SC and the AMOs is produced in MEM, like a load's. They set `memRead`, so the existing
load-use logic stalls a dependent instruction right behind them for one cycle and nothing forwards their result from
EX/MEM; from MEM/WB it is forwarded as usual. rs1 and rs2 are ordinary EX operands, forwarded like a store's.

**Reservation.** One valid bit and a 30-bit word address, updated in MEM. LR sets it; SC (success or failure) clears
it; a trap or MRET taken in EX in the same cycle clears it last (that instruction is younger than the one in MEM).
So an LR/SC sequence interrupted by a trap always fails its SC and has to retry, as the spec expects after a context
switch.

## The machine timer interrupt (added for FreeRTOS)

The core has one interrupt input, `timerIrq`, which is mip.MTIP. It is pending when mstatus.MIE, mie.MTIE and MTIP
are all 1 (`CsrFile.irqPending`).

| Question | Answer |
|---|---|
| Where is it taken? | In EX, like an exception, on the instruction there, before it executes |
| Which instruction? | Any valid EX instruction, except a division that has already started (it finishes first; one that has not started is interrupted and re-run after MRET) |
| What happens? | Older instructions in MEM and WB complete; the EX instruction and the two younger ones are discarded; mepc = its pc, mcause = 0x80000007, mtval = 0, MPIE = MIE, MIE = 0, the LR/SC reservation is cleared; fetch restarts at mtvec (2 bubbles) |
| Priority | The interrupt wins over the exceptions of the same instruction (it never executed) |
| Latency | The line is sampled in EX and the CLINT registers MTIP: the interrupt is taken a few cycles after mtime reaches mtimecmp (later if EX holds a bubble, or a division that has started: up to 33 cycles) |
| Trace | A trap with `intr` = 1 and cause 7, reported in WB in program order |
| Reference model | `RefModel.interrupt()` takes it; the harness checks that the core takes it exactly when it is pending in the model (MIE, MTIE and the line in that EX cycle), and never otherwise |

Choices: the interrupt is never taken on a bubble (it waits for the next valid instruction, at most 2 cycles after a
redirect), so mepc is always the pc of a real instruction; WFI stays a no-op (allowed: it may complete at any time);
there are no software or external interrupts (mie.MSIE / MEIE are writable but nothing drives them).

## Precise exceptions

Every exception is known in EX: illegal instruction, ECALL and EBREAK come from ID; misaligned load/store/atomic
addresses and misaligned branch/jump targets are computed in EX. A misaligned LR.W is a load-address-misaligned
exception (4); a misaligned SC.W or AMO is a store/AMO-address-misaligned exception (6), mtval = the address. The trap is taken in EX:

- older instructions are in MEM and WB and complete normally;
- the trapping instruction does not access memory and does not write a register;
- the two younger instructions (IF/ID, ID/EX) are flushed;
- mepc/mcause/mtval/mstatus are written in EX and fetch restarts at mtvec.

A trap record then travels through MEM and WB, so the trace reports it in WB, in program order with the retirements.
Since nothing can fail after EX, an instruction that leaves EX is committed: `minstret` counts there.

## Execution rules (trace, WB stage)

Every cycle WB does exactly one of: retire an instruction (`trace.valid`), report a trap (`trace.trap`), or nothing
(a bubble). An instruction executed in EX in cycle t appears in the trace in cycle t + 2 (`Core.ExToWb`); the first
instruction after reset reaches WB after 4 empty cycles (`Core.FillCycles`).

Cycles between retirements: 1, plus 2 after a redirect, plus 1 for a load-use dependency (on a load, LR.W, SC.W or
an AMO), plus 33 for a regular DIV/DIVU/REM/REMU (1 for divide-by-zero or overflow). LR.W, SC.W and the AMOs take one
cycle.

Exception priority: illegal instruction (2) > ECALL (11) > EBREAK (3) > load misaligned (4) > store misaligned (6) >
instruction address misaligned (0).

## Choices made where the specification leaves an option

| Topic | Choice | Why |
|---|---|---|
| M-extension decoding | The core recognises OP + funct7 = 0000001 itself; the Decoder still reports it illegal | Keeps the Step 3 RV32I decoder (and its tests) unchanged; same pattern as Step 4 |
| Multiplier | One 33 × 33 signed product, operands extended by sign or zero | One array serves MUL/MULH/MULHSU/MULHU; maps to DSP blocks |
| Divider | Restoring division on magnitudes, signs fixed at the end, 1 bit/cycle | Smallest correct sequential divider: one 33-bit subtract/compare and four 32-bit registers |
| Divider special cases | x/0 and MIN/-1 answered in 1 cycle without iterating | They are defined by the spec's table, no division needed |
| Divider stall | IF, ID and EX freeze, bubbles go to MEM; `busy` stays high through the response cycle | The division stays in EX and cannot start twice; older instructions still drain |
| Forwarding | From EX/MEM (non-load) and MEM/WB into EX, plus WB→ID bypass | Removes every stall except load-use |
| Load-use | 1-cycle stall detected in ID | Load data is only available at the end of MEM |
| Branch resolution | In EX, 2 bubbles | Branch compare uses forwarded operands; resolving in ID would need forwarding into ID and more stalls |
| Bubble encoding | `valid` bit in every pipeline register; an empty IfId decodes as `addi x0, x0, 0` | No side effect possible from a bubble |
| Trap point | EX, reported in WB | All causes known in EX; keeps the trace in program order |
| Commit point / minstret | EX | Nothing can fail after EX; CSR reads stay in program order |
| Memories | Combinational (zero-wait) ports, instruction read in IF, data in MEM | Same memory interface and test harness as Step 5 |
| Divider kill | `kill` tied to `trapNow` | A division never traps here; it is a safety net for when interrupts are added |
| Misaligned loads/stores | Trap (cause 4 / 6, mtval = address) | Simplest correct option; allowed by the privileged spec |
| Misaligned LR / SC / AMO | Trap: LR cause 4, SC and AMO cause 6, mtval = address | Required: atomics are never emulated for misaligned addresses |
| AMO execution | Read and write in the same MEM cycle | Atomic on a zero-wait port with a single master; no extra state or stall |
| aq / rl bits | Accepted and ignored | An in-order pipeline with one data port already performs every access in program order |
| Reservation set | One aligned word (4 bytes) | The smallest set the spec allows; LR/SC are word-sized |
| Reservation clearing | Every SC.W (success or failure), every trap, every MRET; not plain stores | SC rule required; trap/MRET give the "context switch breaks the sequence" behaviour; with one hart no other store can intervene, and the spec does not require the same hart's stores to break it |
| SC.W failure code | rd = 1 | Any non-zero value is allowed; 1 is conventional |
| LR.W with rs2 =/= 0, other widths, unknown funct5 | Illegal instruction | Reserved encodings |
| Misaligned branch/jump targets | Trap at the branch/jump (cause 0, mtval = target), rd not written | Required with IALIGN = 32 |
| EBREAK mtval | pc | Allowed (pc or 0) |
| ECALL mtval | 0 | Required |
| Illegal-instruction mtval | The instruction word | Allowed, helps debugging |
| FENCE | No-op | Single hart, in-order, no caches |
| FENCE.I | Illegal | Zifencei is not part of the ISA string |
| WFI | No-op | Allowed; there are no interrupts to wait for |
| mtvec | Direct mode only, low two bits read as 0 | WARL; simplest |
| mepc | Bits 1:0 read as 0 | IALIGN = 32 |
| misa | `0x40001101` (RV32, I, M, A), writes ignored | WARL; reports exactly the implemented extensions |
| mstatus | MIE (bit 3) and MPIE (bit 7) writable, MPP fixed to 11 | Machine mode only |
| mie | Only MSIE, MTIE, MEIE bits writable | WARL |
| mip, mstatush | Read 0, writes ignored | No interrupt sources |
| mcycle | Counts every clock, including divider wait cycles | It measures time |
| minstret | Counts retired instructions only (not traps, not wait cycles) | Spec definition |
| Counter writes | A CSR write replaces one 32-bit half of the incremented value | Deterministic and easy to model |
| cycle/instret (user) | Read-only shadows of mcycle/minstret; `time` not implemented (illegal) | No real-time clock |
| Unknown CSR / write to read-only CSR | Illegal instruction | Required |
| x0 | Hardwired zero in the register file; writes ignored | Required |

## Verification

- Unit tests per block: ALU (all ops, edge pairs and random), ImmGen (all formats), RegFile (x0, read during write),
  Decoder (every instruction and every major opcode, legal and illegal), CsrFile (RW/RS/RC, WARL, illegal, counters,
  trap/mret), Multiplier (edge pairs and random against BigInt), DivUnit (edge pairs, random, latency, kill, handshake).
- Pipeline tests: `CoreTimingSpec` checks the cycle count of all 56 instructions including every redirect bubble,
  forwarding at distances 1-3 (no stall), load-use stalls (rs1, rs2, store data) and no false stalls, and that the two
  wrong-path instructions behind a taken branch, a jump, a trap and MRET have no effect.
- Program tests: hand-assembled programs run on `Core` and on `RefModel` in lockstep; every retirement and trap is
  compared field by field (pc, next pc, instruction, rd, rd value, memory address/size/data, cause), and final register
  values are also checked against independently computed constants.
- A extension (`CoreAmoSpec`): the 9 AMOs on 81 edge-operand pairs each, against an expected-value function written
  in the test; the LR/SC rules (no LR, second SC, other word, reservation kept across other instructions and plain
  stores, moved by a second LR, cleared by a trap alone, by MRET alone, rd = x0, an atomic counter retried after a
  trap); forwarding, load-use stalls and memory order around atomics; misaligned atomics and reserved encodings;
  exact timing; 3,000 random instructions with LR/SC pairs and AMOs (both SC outcomes occur many times).
- Planted bugs: eight faults were put into `Core.scala` one at a time and `CoreAmoSpec` failed for each: a trap that
  keeps the reservation, an MRET that keeps it, an SC that keeps it, a reservation that ignores the address, AMOMIN
  compared unsigned, no load-use stall behind an AMO, a failed SC that still writes, and a misaligned LR reported
  as a store fault. (The first one was only caught after adding the "SC inside the trap handler" case: before it,
  every handler ended with MRET, which cleared the reservation anyway.)
- Synthesis (Yosys 0.71, `synth_ecp5`, core only): 7,382 LUT4, 327 CCU2C, 2,173 flip-flops, 4 MULT18X18D, against
  6,909 / 295 / 2,136 / 4 for the Stage 7 core: the A extension costs about 470 LUT4 (+7 %) and 37 flip-flops.
