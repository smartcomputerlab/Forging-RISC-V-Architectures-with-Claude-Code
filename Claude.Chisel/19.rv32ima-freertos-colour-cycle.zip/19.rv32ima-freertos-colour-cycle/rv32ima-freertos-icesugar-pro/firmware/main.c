/* FreeRTOS application for the RV32IMA core on the iCESugar-Pro: three tasks blink the RGB LED.
 *
 * Each task owns one colour and toggles it at its own period with vTaskDelayUntil (drift-free):
 *     red    every 0.50 s   (priority 3)
 *     green  every 0.75 s   (priority 2)
 *     blue   every 1.25 s   (priority 1)
 * so the LED walks through all eight colour mixes; the whole pattern repeats every 15 s.
 *
 * The three tasks share one register, the LED register. A plain read-modify-write
 * (load, xor, store) could be preempted by the tick between the load and the store, and the other task's change
 * would then be lost. Each toggle is therefore one AMOXOR.W instruction (A extension): it reads, flips the bit and
 * writes back as one indivisible step, so no lock and no critical section is needed.
 */
#include <stdint.h>
#include "FreeRTOS.h"
#include "task.h"

#define IO_BASE      0x10000000UL
#define LED          ( *( volatile uint32_t * ) ( IO_BASE + 0x00 ) )   /* bits 2:0 = {blue, green, red} */
#define UART_TX      ( *( volatile uint32_t * ) ( IO_BASE + 0x04 ) )
#define UART_STATUS  ( *( volatile uint32_t * ) ( IO_BASE + 0x08 ) )   /* bit 0: transmitter ready */

#define LED_RED      1u
#define LED_GREEN    2u
#define LED_BLUE     4u

/* Flip the bits of `mask` in the LED register, atomically: amoxor.w x0, mask, (LED). */
static inline void prvLedToggle( uint32_t mask )
{
    __asm volatile ( "amoxor.w zero, %1, (%0)" : : "r" ( &LED ), "r" ( mask ) : "memory" );
}

typedef struct
{
    uint32_t ulMask;           /* colour bit */
    TickType_t xHalfPeriod;    /* ticks between two toggles */
} BlinkParams_t;

static const BlinkParams_t xRed   = { LED_RED,   pdMS_TO_TICKS( 500 ) };
static const BlinkParams_t xGreen = { LED_GREEN, pdMS_TO_TICKS( 750 ) };
static const BlinkParams_t xBlue  = { LED_BLUE,  pdMS_TO_TICKS( 1250 ) };

static void vBlinkTask( void * pvParameters )
{
    const BlinkParams_t * p = pvParameters;
    TickType_t xLastWake = xTaskGetTickCount();

    for( ; ; )
    {
        vTaskDelayUntil( &xLastWake, p->xHalfPeriod );
        prvLedToggle( p->ulMask );
    }
}

/* ---- start-up message on the UART (polled, before the scheduler starts) ---- */
static void prvPuts( const char * s )
{
    for( ; *s != 0; s++ )
    {
        while( ( UART_STATUS & 1u ) == 0 ) { }
        UART_TX = ( uint32_t ) ( uint8_t ) *s;
    }
}

/* ---- faults: stop everything and show it on the LED (all three colours blink fast) ---- */
static void prvFault( void )
{
    __asm volatile ( "csrc mstatus, 8" );           /* interrupts off */
    for( ; ; )
    {
        LED = LED_RED | LED_GREEN | LED_BLUE;
        for( volatile uint32_t i = 0; i < 200000u; i++ ) { }
        LED = 0;
        for( volatile uint32_t i = 0; i < 200000u; i++ ) { }
    }
}

void vAssertCalled( const char * file, int line )                      { ( void ) file; ( void ) line; prvFault(); }
void vApplicationMallocFailedHook( void )                               { prvFault(); }
void vApplicationStackOverflowHook( TaskHandle_t xTask, char * pcName ) { ( void ) xTask; ( void ) pcName; prvFault(); }
/* Exceptions other than ECALL (illegal instruction, misaligned access, ...) and unexpected interrupts. */
void freertos_risc_v_application_exception_handler( void )              { prvFault(); }
void freertos_risc_v_application_interrupt_handler( void )              { prvFault(); }

extern void freertos_risc_v_trap_handler( void );

int main( void )
{
    LED = 0;
    __asm volatile ( "csrw mtvec, %0" : : "r" ( freertos_risc_v_trap_handler ) );

    prvPuts( "\r\nFreeRTOS " tskKERNEL_VERSION_NUMBER " on RV32IMA (5-stage pipeline, Chisel) on iCESugar-Pro: "
             "3 tasks blink the RGB LED\r\n" );

    xTaskCreate( vBlinkTask, "red",   configMINIMAL_STACK_SIZE, ( void * ) &xRed,   3, NULL );
    xTaskCreate( vBlinkTask, "green", configMINIMAL_STACK_SIZE, ( void * ) &xGreen, 2, NULL );
    xTaskCreate( vBlinkTask, "blue",  configMINIMAL_STACK_SIZE, ( void * ) &xBlue,  1, NULL );

    vTaskStartScheduler();          /* does not return */
    prvFault();
    return 0;
}
