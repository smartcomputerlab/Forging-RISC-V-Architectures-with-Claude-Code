# Firmware: FreeRTOS V11.1.0 for the RV32IMA system

| File | Contents |
|---|---|
| `main.c` | The application: three tasks blink the RGB LED with atomic AMOXOR.W toggles; start-up message on the UART; fault handler (all colours blink fast) |
| `FreeRTOSConfig.h` | Kernel configuration: CLINT addresses, mtime at 1 MHz, 100 Hz tick, 5 priorities, 12 KiB heap (heap_4), stack overflow check, assertions |
| `start.S` | Reset entry at 0x80000000: stack pointer, clear `.bss`, call `main` |
| `link.ld` | One 32 KiB RAM at 0x80000000; the stack of `main` becomes the interrupt stack (`__freertos_irq_stack_top`) |
| `lib.c`, `include/` | The C library functions FreeRTOS uses (`memset`, `memcpy`, `memcmp`, `strlen`) and stub headers: there is no C library |
| `tohex.py` | Binary image to hex (one 32-bit word per line), the format `EmitFpga` reads |
| `FreeRTOS-Kernel/` | FreeRTOS-Kernel V11.1.0, unchanged: `tasks.c`, `list.c`, `queue.c`, `include/`, the GCC RISC-V port with the `RISCV_MTIME_CLINT_no_extensions` chip header, `heap_4.c`; MIT licence in `LICENSE.md` |
| `freertos.elf`, `freertos.hex`, `freertos.lst` | The built firmware (in the bitstream) |

Build with clang (default) or GCC:

```bash
make
```

```bash
make GCC=1
```

Compiler flags: `-march=rv32ima -mabi=ilp32 -Os -ffreestanding`, linked without a C library. The core has no
compressed instructions (no C extension), no floating point and no FENCE.I. The firmware uses only RV32IMA + Zicsr
instructions, and the one AMO is the LED toggle.

How FreeRTOS uses the hardware:

- **Tick:** the RISC-V port's trap handler (`freertos_risc_v_trap_handler`, installed in `mtvec` by `main`) handles
  the machine timer interrupt. It writes the next compare value to mtimecmp (two 32-bit stores), calls
  `xTaskIncrementTick` and switches tasks when needed.
- **Yield:** `portYIELD` is an ECALL; the same handler switches context and returns to mepc + 4.
- **Critical sections:** `csrc mstatus, 8` / `csrs mstatus, 8` (MIE).
- **Context:** 31 integer registers, mstatus and the critical-nesting count on each task's stack; the interrupt
  stack is separate.

To change the blink periods or add tasks, edit `main.c`, then rebuild the bitstream (`make` in `../fpga`). Check the
result quickly at instruction level first:

```bash
python3 ../tools/rvsim.py freertos.hex
```

(`rvsim.py` checks the blink pattern of this application; for another application, read its UART and LED log.)
