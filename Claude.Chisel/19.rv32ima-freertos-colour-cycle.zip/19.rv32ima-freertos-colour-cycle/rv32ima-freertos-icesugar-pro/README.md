# FreeRTOS on the RV32IMA core (Stage 11) on the iCESugar-Pro

The Stage 11 core (RV32IMA, 5-stage pipeline, written in Chisel) on the **iCESugar-Pro** board (Lattice ECP5
LFE5U-25F), running **FreeRTOS V11.1.0**. The application is three FreeRTOS tasks that blink the on-board **RGB LED**,
each toggling one colour with an **atomic AMOXOR.W** instruction.

What this project adds to Stage 11:

| Part | What | Where |
|---|---|---|
| Core | The **machine timer interrupt**, which FreeRTOS needs for its tick (taken in EX, precise, checked in lockstep against the reference model) | `src/main/scala/rv32i/Core.scala`, `CsrFile.scala` |
| System | 32 KiB of block RAM holding program and data, a **CLINT** timer (mtime / mtimecmp), the RGB LED register, the UART | `src/main/scala/rv32i/IceSugarPro.scala` |
| Software | FreeRTOS V11.1.0 (RISC-V port, unchanged), start-up code, linker script, a small C library, the LED application | `firmware/` |
| Board | Yosys / nextpnr-ecp5 / ecppack flow, ready-made bitstream | `fpga/` |

A ready-made bitstream is included: `fpga/IceSugarProTop.bit`.

## 1. Quick start with the ready-made bitstream

1. Connect the iCESugar-Pro with a USB-C cable. The on-board iCELink appears as a USB drive called **iCELink** and as a
   serial port (`/dev/ttyACM0` on Linux).
2. Optional: open a terminal at **115200 baud, 8N1** before programming, to see the start-up message:

   ```bash
   picocom -b 115200 /dev/ttyACM0
   ```

3. Copy `fpga/IceSugarProTop.bit` onto the iCELink drive, or run:

   ```bash
   icesprog fpga/IceSugarProTop.bit
   ```

The terminal shows:

```
FreeRTOS V11.1.0 on RV32IMA (5-stage pipeline, Chisel) on iCESugar-Pro: 3 tasks blink the RGB LED
```

and the RGB LED starts changing colour:

| Task | Colour | Toggles every | Priority |
|---|---|---|---|
| `red` | red | 0.50 s | 3 |
| `green` | green | 0.75 s | 2 |
| `blue` | blue | 1.25 s | 1 |

Together they walk through all eight colour mixes (off, red, green, yellow, blue, magenta, cyan, white), and the
whole pattern repeats every 15 seconds. If all three colours **blink fast together**, the firmware has stopped on a
fault (failed assertion, stack overflow, out of heap, or an unexpected exception): see `prvFault` in
`firmware/main.c`.

## 2. The application

```c
static inline void prvLedToggle( uint32_t mask )      /* LED register at 0x10000000: bits {blue, green, red} */
{
    __asm volatile ( "amoxor.w zero, %1, (%0)" : : "r" ( &LED ), "r" ( mask ) : "memory" );
}

static void vBlinkTask( void * pvParameters )
{
    const BlinkParams_t * p = pvParameters;
    TickType_t xLastWake = xTaskGetTickCount();
    for( ; ; )
    {
        vTaskDelayUntil( &xLastWake, p->xHalfPeriod );   /* drift-free period */
        prvLedToggle( p->ulMask );
    }
}
```

`main()` sets `mtvec` to the FreeRTOS trap handler, prints the message, creates the three tasks (one function, three
parameter blocks) and starts the scheduler.

**Why AMOXOR.W.** All three tasks change the same register. With a plain load / xor / store, the tick interrupt
could switch tasks between the load and the store, and the other task's change would be lost when the first one
stores its stale value. AMOXOR.W reads the register, flips the bit and writes it back as one indivisible instruction
(the A extension of Stage 11), so no critical section or mutex is needed. The core performs it in one MEM cycle, on
the I/O register just as on RAM.

## 3. The system

| Block | Details |
|---|---|
| Clock | 25 MHz oscillator (P6), used directly: **25 MHz** system clock |
| Core | Stage 11 RV32IMA 5-stage pipeline + the machine timer interrupt; reset pc 0x80000000 |
| RAM | **32 KiB at 0x80000000**: one memory for instructions and data, block RAM, loaded with the firmware by the bitstream |
| CLINT | mtimecmp at 0x02004000, mtime at 0x0200BFF8 (the standard SiFive addresses FreeRTOS uses); mtime counts at **1 MHz**; MTIP = mtime >= mtimecmp |
| LED | 0x10000000: bits 2:0 = {blue, green, red}, 1 = on (pins B11 red, A11 green, A12 blue) |
| UART | 0x10000004 TX, 0x10000008 status, 0x1000000C RX; 115200 baud 8N1 on the iCELink serial port (B9 TX, A9 RX) |

Memory use of the firmware (`firmware/link.ld`): code 5.8 KiB, read-only data and data 0.3 KiB, `.bss` 12.3 KiB
(mostly the 12 KiB FreeRTOS heap, which holds the task control blocks and the three 512-byte task stacks), then a
1 KiB stack for `main()` that becomes the interrupt stack once the scheduler runs. About 19 KiB of the 32 KiB are
used.

FreeRTOS configuration (`firmware/FreeRTOSConfig.h`): preemptive, 5 priorities, tick 100 Hz (10 ms = 10,000 mtime
counts = 250,000 clock cycles), heap_4 with 12 KiB, stack overflow checking (method 2), assertions on.

**Why one memory, and how it becomes block RAM.** FreeRTOS is ordinary C: it reads constants and initialised data
with loads, so the program must be readable as data. The RAM therefore serves both the fetch (IF) and the data port
(MEM). It has four byte lanes and two read ports, plus one write port. The core's memory ports are combinational, but
both read addresses come directly from registers (`fetchPc` and the EX/MEM address). Yosys moves those registers into
the block RAMs' synchronous read ports, so the 32 KiB fits in **32 DP16KD** (two copies, one per read port) instead
of logic. The Chisel generator writes the firmware image into the Verilog as the RAM's initial contents.

Last build (Yosys 0.71, nextpnr-ecp5 0.11.1):

| Resource | Used | Of |
|---|---|---|
| LUT4 / logic cells | 9,022 | 24,288 (37 %) |
| Flip-flops | 2,158 | 24,288 (9 %) |
| DP16KD block RAM | 32 | 56 |
| MULT18X18D | 4 | 28 |

Maximum frequency **38.95 MHz**, constraint 25 MHz: **PASS**.

## 4. Building it yourself

Tools:

- **Firmware:** clang and ld.lld with the RISC-V target (LLVM 14 or newer; Ubuntu: `sudo apt install clang lld llvm`),
  or a GNU RISC-V toolchain (`make GCC=1`), and Python 3
- **Hardware:** Java 11+ and sbt for Chisel; Yosys, nextpnr-ecp5 and ecppack (the YosysHQ oss-cad-suite, or
  `make YOWASP=1` with `pip install yowasp-yosys yowasp-nextpnr-ecp5`)

Everything at once, from the `fpga` folder:

```bash
make
```

This builds the firmware (`firmware/freertos.hex`), generates the Verilog with the firmware in the RAM
(`sbt "runMain rv32i.EmitFpga"`), then runs Yosys, nextpnr-ecp5 and ecppack and leaves `fpga/build/IceSugarProTop.bit`.

Only the firmware, from the `firmware` folder:

```bash
make
```

This leaves `freertos.elf`, `freertos.hex` (one 32-bit word per line) and `freertos.lst` (disassembly). After changing
the application, run `make` in `fpga` again: the new firmware has to go into the bitstream.

## 5. How it was checked

1. **The core** (`sbt test`): all the Stage 11 test suites, plus `CoreIrqSpec` for the new interrupt. Every program
   runs in lockstep with the reference model, which now also decides, cycle by cycle, whether the interrupt must be
   taken. **48 tests, all passing** (about 17 minutes); `CoreIrqSpec` takes 125 to 148 interrupts per program, at
   every kind of instruction, including between an LR and its SC (the SC then fails and the loop retries).
2. **The firmware at instruction level** (`tools/rvsim.py`, a separate simulator of the whole system written in
   Python): FreeRTOS boots, prints its message and runs 1,500 ticks (15 s of board time) with 1,501 timer interrupts.
   Red toggles at ticks 50, 100, 150, …, green at 75, 150, …, blue at 125, 250, …, exactly. The same check passes
   with the board's real timer rate (25 clock cycles per mtime count, 375 ticks, 94 million instructions).

   ```bash
   python3 tools/rvsim.py firmware/freertos.hex
   ```

3. **The whole system, cycle by cycle** (`FpgaFreeRtosSpec`): the generated hardware (core, RAM with the firmware
   image, CLINT, LED, UART) runs the real firmware in the Chisel simulator. To make it feasible, mtime counts 10 per
   cycle (one tick every 1,000 cycles; the firmware is unchanged). The test decodes the UART and records every LED
   change. **Passes**: 300,000 cycles (260 ticks, about 65 minutes at 78 cycles/s). The UART prints the
   start-up message. Red toggles at ticks 50, 100, 150.06, 200, 250.06. Green toggles at 75, 150.47, 225. Blue toggles at
   125 and 250.49. Each toggle falls inside its own tick, and every LED change flips exactly one colour. When two tasks
   wake in the same tick, the higher-priority task toggles first: at tick 150, red goes 0.06 tick after the interrupt
   and green 0.47 tick after it. At tick 250, red goes first and blue follows.

   ```bash
   sbt "testOnly rv32i.FpgaFreeRtosSpec"
   ```

4. **The hardware build:** synthesis, placement and routing complete, timing passes at 25 MHz, all 32 block RAMs carry
   the firmware image, and ecppack produces the bitstream.

**Not done:** it has not been run on a real board yet, and the routed netlist was not simulated (no gate-level
simulator was available). The RTL that goes into Yosys is the one simulated in step 3. The step from it to block RAM
(moving the address registers into the RAM) is done by Yosys and was not independently simulated.

## 6. Files

| Path | Contents |
|---|---|
| `src/main/scala/rv32i/` | The core (`Core`, `CsrFile`, `Decoder`, …, see `CORE.md`), the system and top level (`IceSugarPro.scala`: `IceSugarSoC`, `Clint`, `IceSugarProTop`, `EmitFpga`), the UART |
| `src/test/scala/rv32i/` | Core tests (`CoreIrqSpec` is new), `FpgaFreeRtosSpec` (FreeRTOS on the whole system) |
| `firmware/` | `main.c` (the application), `FreeRTOSConfig.h`, `start.S`, `link.ld`, `lib.c` + `include/` (minimal C library), `Makefile`, `tohex.py`, `FreeRTOS-Kernel/` (V11.1.0: kernel, RISC-V port, heap_4, MIT licence), and the built `freertos.elf` / `.hex` / `.lst` |
| `fpga/` | `Makefile`, `icesugar_pro.lpf` (pins), `IceSugarProTop.bit`, `build/` (Verilog, logs) |
| `tools/rvsim.py` | Instruction-level simulator of the system, for long firmware runs |
| `CORE.md`, `DESIGN_NOTES.md` | The core: instructions, tests, interface, waveforms; design choices, including the interrupt |
