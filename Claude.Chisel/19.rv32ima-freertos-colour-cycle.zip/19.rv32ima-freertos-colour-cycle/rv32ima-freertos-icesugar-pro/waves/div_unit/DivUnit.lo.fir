FIRRTL version 1.2.0
circuit DivUnit :
  module DivUnit :
    input clock : Clock
    input reset : UInt<1>
    output io_req_ready : UInt<1> @[src/main/scala/rv32i/DivUnit.scala 37:14]
    input io_req_valid : UInt<1> @[src/main/scala/rv32i/DivUnit.scala 37:14]
    input io_req_bits_op : UInt<2> @[src/main/scala/rv32i/DivUnit.scala 37:14]
    input io_req_bits_a : UInt<32> @[src/main/scala/rv32i/DivUnit.scala 37:14]
    input io_req_bits_b : UInt<32> @[src/main/scala/rv32i/DivUnit.scala 37:14]
    output io_resp_valid : UInt<1> @[src/main/scala/rv32i/DivUnit.scala 37:14]
    output io_resp_bits : UInt<32> @[src/main/scala/rv32i/DivUnit.scala 37:14]
    input io_kill : UInt<1> @[src/main/scala/rv32i/DivUnit.scala 37:14]
    output io_busy : UInt<1> @[src/main/scala/rv32i/DivUnit.scala 37:14]

    reg state : UInt<2>, clock with :
      reset => (UInt<1>("h0"), state) @[src/main/scala/rv32i/DivUnit.scala 45:30]
    reg quot : UInt<32>, clock with :
      reset => (UInt<1>("h0"), quot) @[src/main/scala/rv32i/DivUnit.scala 50:28]
    reg rem : UInt<32>, clock with :
      reset => (UInt<1>("h0"), rem) @[src/main/scala/rv32i/DivUnit.scala 51:28]
    reg divisor : UInt<32>, clock with :
      reset => (UInt<1>("h0"), divisor) @[src/main/scala/rv32i/DivUnit.scala 52:28]
    reg count : UInt<5>, clock with :
      reset => (UInt<1>("h0"), count) @[src/main/scala/rv32i/DivUnit.scala 53:28]
    reg negQ : UInt<1>, clock with :
      reset => (UInt<1>("h0"), negQ) @[src/main/scala/rv32i/DivUnit.scala 54:28]
    reg negR : UInt<1>, clock with :
      reset => (UInt<1>("h0"), negR) @[src/main/scala/rv32i/DivUnit.scala 55:28]
    reg wantRem : UInt<1>, clock with :
      reset => (UInt<1>("h0"), wantRem) @[src/main/scala/rv32i/DivUnit.scala 56:28]
    reg result : UInt<32>, clock with :
      reset => (UInt<1>("h0"), result) @[src/main/scala/rv32i/DivUnit.scala 57:28]
    node _io_req_ready_T = eq(state, UInt<2>("h0")) @[src/main/scala/rv32i/DivUnit.scala 59:26]
    node _io_resp_valid_T = eq(state, UInt<2>("h2")) @[src/main/scala/rv32i/DivUnit.scala 60:26]
    node _io_busy_T = neq(state, UInt<2>("h0")) @[src/main/scala/rv32i/DivUnit.scala 62:26]
    node _T = and(io_req_ready, io_req_valid) @[src/main/scala/chisel3/util/Decoupled.scala 57:35]
    node _signed_T = bits(io_req_bits_op, 0, 0) @[src/main/scala/rv32i/DivUnit.scala 68:33]
    node signed = eq(_signed_T, UInt<1>("h0")) @[src/main/scala/rv32i/DivUnit.scala 68:18]
    node isRem = bits(io_req_bits_op, 1, 1) @[src/main/scala/rv32i/DivUnit.scala 69:32]
    node _negA_T = bits(io_req_bits_a, 31, 31) @[src/main/scala/rv32i/DivUnit.scala 70:29]
    node negA = and(signed, _negA_T) @[src/main/scala/rv32i/DivUnit.scala 70:25]
    node _negB_T = bits(io_req_bits_b, 31, 31) @[src/main/scala/rv32i/DivUnit.scala 71:29]
    node negB = and(signed, _negB_T) @[src/main/scala/rv32i/DivUnit.scala 71:25]
    node _negQ_T = neq(negA, negB) @[src/main/scala/rv32i/DivUnit.scala 74:21]
    node _quot_T = sub(UInt<32>("h0"), io_req_bits_a) @[src/main/scala/rv32i/DivUnit.scala 76:38]
    node _quot_T_1 = tail(_quot_T, 1) @[src/main/scala/rv32i/DivUnit.scala 76:38]
    node _quot_T_2 = mux(negA, _quot_T_1, io_req_bits_a) @[src/main/scala/rv32i/DivUnit.scala 76:19]
    node _divisor_T = sub(UInt<32>("h0"), io_req_bits_b) @[src/main/scala/rv32i/DivUnit.scala 77:38]
    node _divisor_T_1 = tail(_divisor_T, 1) @[src/main/scala/rv32i/DivUnit.scala 77:38]
    node _divisor_T_2 = mux(negB, _divisor_T_1, io_req_bits_b) @[src/main/scala/rv32i/DivUnit.scala 77:19]
    node _T_1 = eq(io_req_bits_b, UInt<1>("h0")) @[src/main/scala/rv32i/DivUnit.scala 81:12]
    node _result_T = mux(isRem, io_req_bits_a, UInt<32>("hffffffff")) @[src/main/scala/rv32i/DivUnit.scala 82:20]
    node _T_2 = eq(io_req_bits_a, UInt<32>("h80000000")) @[src/main/scala/rv32i/DivUnit.scala 84:28]
    node _T_3 = and(signed, _T_2) @[src/main/scala/rv32i/DivUnit.scala 84:23]
    node _T_4 = eq(io_req_bits_b, UInt<32>("hffffffff")) @[src/main/scala/rv32i/DivUnit.scala 84:44]
    node _T_5 = and(_T_3, _T_4) @[src/main/scala/rv32i/DivUnit.scala 84:39]
    node _result_T_1 = mux(isRem, UInt<32>("h0"), UInt<32>("h80000000")) @[src/main/scala/rv32i/DivUnit.scala 85:20]
    node _GEN_0 = mux(_T_5, _result_T_1, result) @[src/main/scala/rv32i/DivUnit.scala 84:57 85:14 57:28]
    node _GEN_1 = mux(_T_5, UInt<2>("h2"), UInt<2>("h1")) @[src/main/scala/rv32i/DivUnit.scala 84:57 86:14 88:13]
    node _GEN_2 = mux(_T_1, _result_T, _GEN_0) @[src/main/scala/rv32i/DivUnit.scala 81:21 82:14]
    node _GEN_3 = mux(_T_1, UInt<2>("h2"), _GEN_1) @[src/main/scala/rv32i/DivUnit.scala 81:21 83:14]
    node _GEN_4 = mux(_T, isRem, wantRem) @[src/main/scala/rv32i/DivUnit.scala 65:21 73:13 56:28]
    node _GEN_5 = mux(_T, _negQ_T, negQ) @[src/main/scala/rv32i/DivUnit.scala 65:21 74:13 54:28]
    node _GEN_6 = mux(_T, negA, negR) @[src/main/scala/rv32i/DivUnit.scala 65:21 75:13 55:28]
    node _GEN_7 = mux(_T, _quot_T_2, quot) @[src/main/scala/rv32i/DivUnit.scala 65:21 76:13 50:28]
    node _GEN_8 = mux(_T, _divisor_T_2, divisor) @[src/main/scala/rv32i/DivUnit.scala 65:21 77:13 52:28]
    node _GEN_9 = mux(_T, UInt<1>("h0"), rem) @[src/main/scala/rv32i/DivUnit.scala 65:21 78:13 51:28]
    node _GEN_10 = mux(_T, UInt<1>("h0"), count) @[src/main/scala/rv32i/DivUnit.scala 65:21 79:13 53:28]
    node _GEN_11 = mux(_T, _GEN_2, result) @[src/main/scala/rv32i/DivUnit.scala 65:21 57:28]
    node _GEN_12 = mux(_T, _GEN_3, state) @[src/main/scala/rv32i/DivUnit.scala 65:21 45:30]
    node _T_6 = eq(state, UInt<2>("h1")) @[src/main/scala/rv32i/DivUnit.scala 93:14]
    node _shifted_T = bits(quot, 31, 31) @[src/main/scala/rv32i/DivUnit.scala 94:33]
    node shifted = cat(rem, _shifted_T) @[src/main/scala/rv32i/DivUnit.scala 94:23]
    node fits = geq(shifted, divisor) @[src/main/scala/rv32i/DivUnit.scala 95:28]
    node _nextRem_T = sub(shifted, divisor) @[src/main/scala/rv32i/DivUnit.scala 96:38]
    node _nextRem_T_1 = tail(_nextRem_T, 1) @[src/main/scala/rv32i/DivUnit.scala 96:38]
    node _nextRem_T_2 = mux(fits, _nextRem_T_1, shifted) @[src/main/scala/rv32i/DivUnit.scala 96:23]
    node nextRem = bits(_nextRem_T_2, 31, 0) @[src/main/scala/rv32i/DivUnit.scala 96:57]
    node _nextQuot_T = bits(quot, 30, 0) @[src/main/scala/rv32i/DivUnit.scala 97:28]
    node nextQuot = cat(_nextQuot_T, fits) @[src/main/scala/rv32i/DivUnit.scala 97:23]
    node _count_T = add(count, UInt<1>("h1")) @[src/main/scala/rv32i/DivUnit.scala 101:20]
    node _count_T_1 = tail(_count_T, 1) @[src/main/scala/rv32i/DivUnit.scala 101:20]
    node _T_7 = eq(count, UInt<5>("h1f")) @[src/main/scala/rv32i/DivUnit.scala 103:16]
    node _q_T = sub(UInt<32>("h0"), nextQuot) @[src/main/scala/rv32i/DivUnit.scala 104:37]
    node _q_T_1 = tail(_q_T, 1) @[src/main/scala/rv32i/DivUnit.scala 104:37]
    node q = mux(negQ, _q_T_1, nextQuot) @[src/main/scala/rv32i/DivUnit.scala 104:18]
    node _r_T = sub(UInt<32>("h0"), nextRem) @[src/main/scala/rv32i/DivUnit.scala 105:37]
    node _r_T_1 = tail(_r_T, 1) @[src/main/scala/rv32i/DivUnit.scala 105:37]
    node r = mux(negR, _r_T_1, nextRem) @[src/main/scala/rv32i/DivUnit.scala 105:18]
    node _result_T_2 = mux(wantRem, r, q) @[src/main/scala/rv32i/DivUnit.scala 106:20]
    node _GEN_13 = mux(_T_7, _result_T_2, _GEN_11) @[src/main/scala/rv32i/DivUnit.scala 103:34 106:14]
    node _GEN_14 = mux(_T_7, UInt<2>("h2"), _GEN_12) @[src/main/scala/rv32i/DivUnit.scala 103:34 107:14]
    node _GEN_15 = mux(_T_6, nextRem, _GEN_9) @[src/main/scala/rv32i/DivUnit.scala 93:25 99:11]
    node _GEN_16 = mux(_T_6, nextQuot, _GEN_7) @[src/main/scala/rv32i/DivUnit.scala 100:11 93:25]
    node _GEN_17 = mux(_T_6, _count_T_1, _GEN_10) @[src/main/scala/rv32i/DivUnit.scala 101:11 93:25]
    node _GEN_18 = mux(_T_6, _GEN_13, _GEN_11) @[src/main/scala/rv32i/DivUnit.scala 93:25]
    node _GEN_19 = mux(_T_6, _GEN_14, _GEN_12) @[src/main/scala/rv32i/DivUnit.scala 93:25]
    node _T_8 = eq(state, UInt<2>("h2")) @[src/main/scala/rv32i/DivUnit.scala 111:14]
    node _GEN_20 = mux(_T_8, UInt<2>("h0"), _GEN_19) @[src/main/scala/rv32i/DivUnit.scala 111:25 112:11]
    node _GEN_21 = mux(io_kill, UInt<2>("h0"), _GEN_20) @[src/main/scala/rv32i/DivUnit.scala 115:17 116:11]
    io_req_ready <= _io_req_ready_T @[src/main/scala/rv32i/DivUnit.scala 59:17]
    io_resp_valid <= _io_resp_valid_T @[src/main/scala/rv32i/DivUnit.scala 60:17]
    io_resp_bits <= result @[src/main/scala/rv32i/DivUnit.scala 61:17]
    io_busy <= _io_busy_T @[src/main/scala/rv32i/DivUnit.scala 62:17]
    state <= mux(reset, UInt<2>("h0"), _GEN_21) @[src/main/scala/rv32i/DivUnit.scala 45:{30,30}]
    quot <= _GEN_16
    rem <= _GEN_15
    divisor <= _GEN_8
    count <= _GEN_17
    negQ <= _GEN_5
    negR <= _GEN_6
    wantRem <= _GEN_4
    result <= _GEN_18
