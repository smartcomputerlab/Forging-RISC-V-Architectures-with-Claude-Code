package rv32i

import chisel3._
import chiseltest._
import org.scalatest.flatspec.AnyFlatSpec
import org.scalatest.matchers.should.Matchers

/** The real FreeRTOS firmware (firmware/freertos.hex) on the whole FPGA system, cycle by cycle: the RV32IMA core with
  * its timer interrupt, the 32 KiB RAM preloaded with the image, the CLINT, the LED register and the UART.
  *
  * To keep the run short (Treadle simulates this system at about 80 cycles per second), mtime counts 10 per clock
  * cycle here instead of 1 per 25 cycles on the board, so one FreeRTOS tick (10,000 mtime counts) takes 1,000 cycles
  * instead of 250,000; the firmware is exactly the one in the bitstream. The test decodes the UART and records every LED change, then checks:
  *  - the start-up banner;
  *  - the three blink tasks: red toggles every 50 ticks, green every 75, blue every 125 (as cycles: 50,000,
  *    75,000 and 125,000), each one during its tick, red before green when they wake in the same tick (priority),
  *    and only one colour changes at a time;
  *  - the core's internal assertions hold throughout (they stop the simulation otherwise).
  * Set FREERTOS_TICKS to simulate more or fewer ticks (default 260: the first blue toggles and two red/green
  * coincidences).
  */
class FpgaFreeRtosSpec extends AnyFlatSpec with ChiselScalatestTester with Matchers {
  private val Div = 8                          // UART: 8 clock cycles per bit
  private val TickCycles = 1000                // 10,000 mtime counts at 10 per cycle

  "FreeRTOS" should "boot, print its banner and run three tasks that blink the RGB LED at their periods" in {
    val firmware = FpgaMap.readHex("firmware/freertos.hex")
    val ticks = sys.env.get("FREERTOS_TICKS").map(_.toInt).getOrElse(260)
    test(new IceSugarSoC(firmware, Div, mtimeDiv = 1, mtimeInc = 10)).withAnnotations(TestUtil.waves) { c =>
      c.clock.setTimeout(0)
      c.io.uartRx.poke(true.B)
      val uart = new StringBuilder
      var rxBusy = false; var cnt = 0; var bit = 0; var shift = 0
      var led = 0
      val changes = scala.collection.mutable.ArrayBuffer.empty[(Long, Int)]   // (cycle, new LED value)
      val total = 40000L + ticks.toLong * TickCycles
      val t0 = System.nanoTime()
      var cycle = 0L
      while (cycle < total) {
        val tx = c.io.uartTx.peek().litToBoolean
        if (!rxBusy) { if (!tx) { rxBusy = true; cnt = Div + Div / 2 - 1; bit = 0; shift = 0 } }
        else if (cnt == 0) {
          if (bit < 8) { shift |= (if (tx) 1 << bit else 0); bit += 1; cnt = Div - 1 }
          else { tx shouldBe true; uart += shift.toChar; rxBusy = false }
        } else cnt -= 1
        val l = c.io.led.peek().litValue.toInt
        if (l != led) { changes += ((cycle, l)); led = l }
        c.clock.step()
        cycle += 1
      }
      val secs = (System.nanoTime() - t0) / 1e9
      info(f"$total cycles in $secs%.0f s (${total / secs}%.0f cycles/s)")
      info("UART: " + uart.toString.trim)
      uart.toString should include("FreeRTOS V11.1.0 on RV32IMA")

      // per colour: the cycles at which it toggled
      val toggles = Map(1 -> "red", 2 -> "green", 4 -> "blue").map { case (b, name) =>
        var prev = 0
        val ts = changes.flatMap { case (cy, v) => val t = if (((v ^ prev) & b) != 0) Some(cy) else None; prev = v; t }
        b -> (name, ts.toSeq)
      }
      // each LED change flips exactly one colour (two tasks never write at once: the toggles are atomic)
      var prev = 0
      for ((cy, v) <- changes) { withClue(s"cycle $cy: ") { Integer.bitCount(v ^ prev) shouldBe 1 }; prev = v }
      val red = toggles(1)._2
      red.length should be >= 4
      // the tick of the first red toggle is tick 50: measure every toggle in ticks from there
      val tick50 = red.head
      def inTicks(cy: Long): Double = 50 + (cy - tick50).toDouble / TickCycles
      for ((b, (name, ts)) <- toggles.toSeq.sortBy(_._1)) {
        val period = Map(1 -> 50, 2 -> 75, 4 -> 125)(b)
        val got = ts.map(inTicks)
        info(f"$name%-5s toggles at ticks ${got.map(t => f"$t%.2f").mkString(", ")}")
        got.length shouldBe (ticks / period)
        // each toggle happens during its tick: after the tick interrupt, before the next one. (When two tasks wake
        // in the same tick, the higher-priority one runs first and the other follows a few hundred cycles later.)
        for ((t, k) <- got.zipWithIndex) withClue(s"$name toggle ${k + 1} at tick $t: ") {
          val due = period * (k + 1)
          t should be >= (due - 0.05)
          t should be < (due + 1.0)
        }
      }
      // ticks where red and green both toggle (150, 300, ...): red (priority 3) before green (priority 2)
      val (redTs, greenTs) = (toggles(1)._2.map(inTicks), toggles(2)._2.map(inTicks))
      for (g <- greenTs; r <- redTs if g.toInt == r.toInt) withClue(s"tick ${g.toInt}: ") { r should be < g }
    }
  }
}
