package rv32i

import chisel3._
import chiseltest._

/** Lockstep harness: runs a program on the hardware `Core` (with a combinational memory model) and on
  * [[RefModel]], and compares every retirement or trap field by field. Stops when `halt` (jal x0, 0) retires.
  */
object CoreSim {
  private def check(ok: Boolean, msg: => String): Unit = if (!ok) throw new AssertionError(msg)

  /** One retirement or trap: the instruction, whether it trapped, and how many clock cycles it took
    * (1 + the cycles before it in which nothing retired: divider waits and pipeline bubbles). */
  final case class Event(pc: Long, pcNext: Long, inst: Long, trap: Boolean, cycles: Int, rdData: Long = 0L, memWe: Boolean = false,
                         intr: Boolean = false)
  final case class Result(model: RefModel, retired: Int, traps: Int, cycles: Long, stallCycles: Long, events: Seq[Event])

  /** `irq(cycle, mem)`: the timer interrupt line (mip.MTIP) in that cycle; it may look at the hardware's memory,
    * e.g. a word the program writes like mtimecmp. Every interrupt the core takes is checked against [[RefModel]]
    * (MIE, MTIE and the line in its EX cycle), and so is every instruction that retires without one: if the
    * interrupt was pending in its EX cycle, it must have been taken (except for a division already in progress). */
  def run(c: Core, prog: Seq[Long], base: Long = 0x80000000L, data: Seq[(Long, Long)] = Nil,
          maxCycles: Long = 200000, irq: (Long, SimMemory) => Boolean = (_, _) => false): Result = {
    val hwMem = new SimMemory; hwMem.load(base, prog)
    val swMem = new SimMemory; swMem.load(base, prog)
    data.foreach { case (a, w) => hwMem.writeWord(a, w); swMem.writeWord(a, w) }
    val model = new RefModel(swMem, base)
    val irqLine = scala.collection.mutable.ArrayBuffer.empty[Boolean]
    model.mtip = t => t >= 0 && t < irqLine.length && irqLine(t.toInt)
    def isDivRem(w: Long) = (w & 0x7f) == 0x33 && ((w >> 25) & 0x7f) == 1 && ((w >> 12) & 4) != 0

    c.clock.setTimeout(0)
    var cycle = 0L
    var retired = 0
    var traps = 0
    var stalls = 0L
    var done = false
    var waitRun = 0
    val events = scala.collection.mutable.ArrayBuffer.empty[Event]
    while (!done) {
      check(cycle < maxCycles, s"no halt after $maxCycles cycles")
      val pc = c.io.imem.addr.peek().litValue.toLong
      c.io.imem.data.poke(hwMem.readWord(pc).U(32.W))
      c.io.dmem.rdata.poke(hwMem.readWord(c.io.dmem.addr.peek().litValue.toLong).U(32.W))
      val line = irq(cycle, hwMem)
      irqLine += line
      c.io.timerIrq.poke(line.B)

      val t = c.io.trace
      val valid = t.valid.peek().litToBoolean
      val trap  = t.trap.peek().litToBoolean
      check(!(valid && trap), "valid and trap in the same cycle")
      if (valid || trap) {
        // An AMO reads and writes the same word in one MEM cycle: the read data above is the old word.
        // CSRs are read in EX, Core.ExToWb cycles before the instruction reaches WB (where it is traced)
        val exCycle = cycle - Core.ExToWb
        val hwIntr = t.intr.peek().litToBoolean
        val r =
          if (hwIntr) {
            check(model.irqPending(exCycle), f"cycle $cycle: interrupt taken at pc 0x${model.pc}%08x but not pending in the model")
            model.interrupt()
          } else {
            check(!model.irqPending(exCycle) || isDivRem(model.mem.readWord(model.pc)),
              f"cycle $cycle: interrupt pending at pc 0x${model.pc}%08x but not taken")
            model.step(exCycle)
          }
        check(hwIntr == r.intr, s"cycle $cycle: intr hw=$hwIntr model=${r.intr}")
        def hw(d: UInt): Long = d.peek().litValue.toLong
        val where = f"cycle $cycle, pc 0x${r.pc}%08x, inst 0x${r.inst}%08x"
        check(trap == r.trap, s"$where: trap hw=$trap model=${r.trap}")
        if (trap) check(hw(t.cause) == r.cause, s"$where: cause hw=${hw(t.cause)} model=${r.cause}")
        check(hw(t.pc) == r.pc, f"$where: pc hw=0x${hw(t.pc)}%08x")
        check(hw(t.inst) == r.inst, f"$where: inst hw=0x${hw(t.inst)}%08x")
        check(hw(t.pcNext) == r.pcNext, f"$where: pcNext hw=0x${hw(t.pcNext)}%08x model=0x${r.pcNext}%08x")
        check(hw(t.rdAddr) == r.rdAddr, s"$where: rdAddr hw=${hw(t.rdAddr)} model=${r.rdAddr}")
        check(hw(t.rdData) == r.rdData, f"$where: rdData hw=0x${hw(t.rdData)}%08x model=0x${r.rdData}%08x")
        check(t.memRe.peek().litToBoolean == r.memRe, s"$where: memRe")
        check(t.memWe.peek().litToBoolean == r.memWe, s"$where: memWe")
        if (r.memRe || r.memWe) {
          check(hw(t.memAddr) == r.memAddr, f"$where: memAddr hw=0x${hw(t.memAddr)}%08x model=0x${r.memAddr}%08x")
          check(hw(t.memSize) == r.memSize, s"$where: memSize")
        }
        if (r.memWe) check(hw(t.memWdata) == r.memWdata, f"$where: memWdata hw=0x${hw(t.memWdata)}%08x model=0x${r.memWdata}%08x")
        if (trap) traps += 1 else retired += 1
        events += Event(r.pc, r.pcNext, r.inst, trap, waitRun + 1, r.rdData, r.memWe, r.intr)
        waitRun = 0
        if (valid && r.inst == Asm.Halt) done = true
      } else {
        // Nothing retires in WB this cycle. (Unlike the 1- and 2-stage cores, MEM may still be accessing memory
        // for an older, already committed instruction: every store is checked when it retires in WB.)
        stalls += 1
        waitRun += 1
      }

      // apply the store at the clock edge
      if (c.io.dmem.we.peek().litToBoolean) {
        hwMem.write(c.io.dmem.addr.peek().litValue.toLong, c.io.dmem.wdata.peek().litValue.toLong,
          c.io.dmem.wstrb.peek().litValue.toInt)
      }
      c.clock.step()
      cycle += 1
    }
    Result(model, retired, traps, cycle, stalls, events.toSeq)
  }
}
