package rv32i

import chiseltest._
import org.scalatest.flatspec.AnyFlatSpec
import org.scalatest.matchers.should.Matchers
import scala.util.Random
import TestUtil._

/** The A extension on the full 5-stage core: LR.W, SC.W and the nine AMO*.W. Every program runs in lockstep with
  * [[RefModel]] (CoreSim compares every retirement: registers, memory reads and writes, traps), and the results are
  * also checked against values computed independently here.
  */
class CoreAmoSpec extends AnyFlatSpec with ChiselScalatestTester with Matchers {
  private val Data = 0x80010000L

  /** The new memory word of an AMO, written independently of RefModel. */
  private def amoExpect(f5: Int, old: Long, b: Long): Long = {
    val so = old.toInt; val sb = b.toInt
    (f5 match {
      case AmoFn.SWAP => b
      case AmoFn.ADD  => (so + sb).toLong
      case AmoFn.XOR  => old ^ b
      case AmoFn.AND  => old & b
      case AmoFn.OR   => old | b
      case AmoFn.MIN  => math.min(so, sb).toLong
      case AmoFn.MAX  => math.max(so, sb).toLong
      case AmoFn.MINU => if (java.lang.Integer.compareUnsigned(so, sb) < 0) old else b
      case AmoFn.MAXU => if (java.lang.Integer.compareUnsigned(so, sb) > 0) old else b
    }) & M
  }

  private def run(a: Asm, data: Seq[(Long, Long)] = Nil): CoreSim.Result = {
    var res: CoreSim.Result = null
    test(new Core()).withAnnotations(TestUtil.waves) { c => res = CoreSim.run(c, a.words, data = data, maxCycles = 400000) }
    res
  }
  private def word(res: CoreSim.Result, addr: Long): Long = res.model.mem.readWord(addr)
  private def isAtomic(w: Long) = (w & 0x7f) == 0x2f
  private def f5Of(w: Long) = ((w >> 27) & 31).toInt

  "Core" should "execute the nine AMOs on edge operands: rd = old word, memory = f(old, rs2)" in {
    val vals = Seq(0L, 1L, 2L, 0x7fffffffL, 0x80000000L, 0x80000001L, 0xffffffffL, 0x12345678L, 0xaaaaaaaaL)
    val cases = for (f5 <- AmoFn.Amos; old <- vals; b <- vals) yield (f5, old, b)
    val Results = Data + 0x2000
    val a = new Asm
    a.li(20, Results)
    for (((f5, _, b), k) <- cases.zipWithIndex) {
      a.li(10, Data + 4L * k); a.li(6, b)
      a.amoW(f5, 5, 6, 10)
      a.sw(5, 0, 20); a.addi(20, 20, 4) // rd (the old word), used right after the AMO: a load-use stall
    }
    a.halt()
    val res = run(a, data = cases.zipWithIndex.map { case ((_, old, _), k) => (Data + 4L * k) -> old })
    res.traps shouldBe 0
    for (((f5, old, b), k) <- cases.zipWithIndex) withClue(f"funct5=0x$f5%02x old=0x$old%08x rs2=0x$b%08x: ") {
      word(res, Data + 4L * k) shouldBe amoExpect(f5, old, b)
      word(res, Results + 4L * k) shouldBe old
    }
    // every AMO was reported as a read and a write of the same word, with the value written
    res.events.count(e => isAtomic(e.inst) && e.memWe) shouldBe cases.length
  }

  it should "follow the LR/SC rules: reservation set by LR, cleared by SC, a trap and MRET, not by plain stores" in {
    val D = Data; val D4 = Data + 4; val Cnt = Data + 8
    val a = new Asm
    a.la(30, "trapOnly"); a.csrrw(0, CsrAddr.mtvec, 30)
    a.li(10, D); a.li(11, D4); a.li(1, 111); a.li(2, 222)
    a.sw(1, 0, 10)
    a.scW(3, 2, 10)                     // 1. SC without LR fails: x3 = 1, memory unchanged
    a.lrW(4, 10)                        // 2. LR then SC succeeds: x4 = 111, x5 = 0, memory = 222
    a.scW(5, 2, 10)
    a.scW(6, 1, 10)                     // 3. a second SC fails (the first one cleared the reservation): x6 = 1
    a.lrW(7, 10); a.scW(8, 1, 11)       // 4. SC on another word fails (x8 = 1, D+4 unchanged) ...
    a.scW(9, 1, 10)                     //    ... and clears the reservation: x9 = 1
    a.lrW(12, 10)                       // 5. the reservation survives ALU ops, a load, a branch and a plain store
    a.addi(13, 0, 1); a.lw(13, 0, 10); a.sw(1, 0, 10); a.beq(0, 0, "s5"); a.addi(13, 0, 99); a.label("s5")
    a.scW(14, 2, 10)                    //    x14 = 0, memory = 222
    a.lrW(15, 10); a.lrW(16, 11)        // 6. a second LR moves the reservation: SC on the first word fails
    a.scW(17, 1, 10)                    //    x17 = 1
    a.lrW(18, 10); a.ecall()            // 7. a trap clears it (the handler only returns): x19 = 1
    a.scW(19, 1, 10)
    a.la(30, "scInHandler"); a.csrrw(0, CsrAddr.mtvec, 30)
    a.lrW(18, 10); a.ecall()            // 7b. the trap alone clears it: an SC inside the handler, before MRET, fails
    a.la(30, "lrThenMret"); a.csrrw(0, CsrAddr.mtvec, 30)
    a.ecall()                           // 8. the handler takes a reservation, MRET clears it: x24 = 1
    a.scW(24, 1, 10)
    a.lrW(0, 10); a.scW(0, 1, 10)       // 9. rd = x0: LR still reserves, SC still stores (memory = 111)
    a.lw(20, 0, 10)
    // 10. atomic counter: 10 increments with LR / ADDI / SC / BNEZ-retry; one attempt is interrupted by a trap,
    //     so its SC fails and is retried (x26 counts the retries)
    a.add(9, 25, 0)                     //     keep the handler's SC result in x9 (x9 was 1 already)
    a.li(12, Cnt); a.li(21, 10); a.li(25, 1); a.la(30, "trapOnly"); a.csrrw(0, CsrAddr.mtvec, 30)
    a.label("inc")
    a.lrW(22, 12); a.addi(22, 22, 1)
    a.addi(27, 21, -5); a.bne(27, 0, "noTrap"); a.beq(25, 0, "noTrap"); a.li(25, 0); a.ecall()
    a.label("noTrap")
    a.scW(23, 22, 12); a.beq(23, 0, "ok"); a.addi(26, 26, 1); a.jump("inc")
    a.label("ok"); a.addi(21, 21, -1); a.bne(21, 0, "inc")
    a.lw(28, 0, 12)
    a.halt()
    a.label("trapOnly")
    a.csrrs(29, CsrAddr.mepc, 0); a.addi(29, 29, 4); a.csrrw(0, CsrAddr.mepc, 29); a.mret()
    a.label("scInHandler")
    a.scW(25, 1, 10)                    //     x25 = 1 (x25 is set again below)
    a.csrrs(29, CsrAddr.mepc, 0); a.addi(29, 29, 4); a.csrrw(0, CsrAddr.mepc, 29); a.mret()
    a.label("lrThenMret")
    a.lrW(31, 10)
    a.csrrs(29, CsrAddr.mepc, 0); a.addi(29, 29, 4); a.csrrw(0, CsrAddr.mepc, 29); a.mret()
    val res = run(a)
    val x = res.model.x
    Seq(3 -> 1L, 4 -> 111L, 5 -> 0L, 6 -> 1L, 8 -> 1L, 9 -> 1L, 14 -> 0L, 17 -> 1L, 19 -> 1L, 24 -> 1L, 20 -> 111L,
      26 -> 1L, 28 -> 10L, 31 -> 222L, 0 -> 0L).foreach { case (r, v) => withClue(s"x$r: ") { x(r) shouldBe v } }
    word(res, D4) shouldBe 0L
    res.traps shouldBe 4
    val scs = res.events.filter(e => isAtomic(e.inst) && f5Of(e.inst) == AmoFn.SC)
    scs.count(_.memWe) shouldBe (3 + 10)          // cases 2, 5, 9 and the ten increments
    scs.count(!_.memWe) shouldBe (8 + 1)          // cases 1, 3, 4 (twice), 6, 7, 7b, 8 and the interrupted attempt
  }

  it should "forward operands into an AMO, stall its users like a load, and keep memory order" in {
    val a = new Asm
    a.li(10, Data); a.li(1, 5); a.sw(1, 0, 10)
    a.addi(2, 0, 3); a.amoaddW(3, 2, 10)      // rs2 forwarded from the ALU just before: x3 = 5, mem = 8
    a.add(4, 3, 3)                            // uses the AMO result right away (1 stall): 10
    a.amoswapW(5, 4, 10)                      // x5 = 8, mem = 10
    a.lw(6, 0, 10)                            // a load right after the AMO sees the new word: 10
    a.amoaddW(7, 6, 10)                       // rs2 from that load (load-use stall): x7 = 10, mem = 20
    a.amoaddW(8, 7, 10)                       // rs2 from the previous AMO (stall): x8 = 20, mem = 30
    a.addi(11, 10, 4); a.amoorW(9, 8, 11)     // rs1 forwarded: mem[D+4] = 0 | 20, x9 = 0
    a.lw(12, 4, 10)                           // 20
    a.sw(1, 4, 10); a.amomaxW(13, 2, 11)      // store then AMO on the same word: x13 = 5, max(5, 3) = 5
    a.mv(15, 10); a.amoaddW(15, 1, 15)        // rd = rs1: x15 = 30 (old), mem = 35
    a.lw(16, 0, 10)                           // 35
    a.amoswapW(17, 17, 10)                    // rd = rs2 (x17 = 0): mem = 0, x17 = 35
    a.amoaddW(0, 1, 10)                       // rd = x0: mem = 5, no register written
    a.lw(18, 0, 10)                           // 5
    a.beq(0, 0, "skip"); a.amoaddW(19, 1, 10); a.lrW(19, 10); a.label("skip") // wrong path: no effect
    a.lw(19, 0, 10)                           // 5
    a.scW(20, 1, 10)                          // the wrong-path LR set no reservation: x20 = 1
    a.halt()
    val res = run(a)
    val x = res.model.x
    Seq(3 -> 5L, 4 -> 10L, 5 -> 8L, 6 -> 10L, 7 -> 10L, 8 -> 20L, 9 -> 0L, 12 -> 20L, 13 -> 5L, 15 -> 30L, 16 -> 35L,
      17 -> 35L, 18 -> 5L, 19 -> 5L, 20 -> 1L, 0 -> 0L).foreach { case (r, v) => withClue(s"x$r: ") { x(r) shouldBe v } }
    word(res, Data + 4) shouldBe 5L
  }

  it should "trap on misaligned atomics (LR: load, SC/AMO: store/AMO) and on reserved encodings, with no side effect" in {
    val Log = Data + 0x100
    val a = new Asm
    a.la(30, "handler"); a.csrrw(0, CsrAddr.mtvec, 30)
    a.li(24, Log); a.li(10, Data); a.li(1, 77); a.sw(1, 0, 10)
    a.addi(11, 10, 2); a.addi(12, 10, 1); a.addi(13, 10, 3)
    a.lrW(3, 11)                                    // cause 4, tval D+2
    a.scW(4, 1, 11)                                 // cause 6
    a.amoaddW(5, 1, 11)                             // cause 6
    a.amoswapW(6, 1, 12)                            // cause 6, tval D+1
    a.amomaxuW(7, 1, 13)                            // cause 6, tval D+3
    val badF3 = Enc.r(0, 1, 10, 3, 8, 0x2f); a.word(badF3)               // amoadd.d: illegal (RV32)
    val lrRs2 = Enc.r(AmoFn.LR << 2, 1, 10, 2, 8, 0x2f); a.word(lrRs2)   // lr.w with rs2 = x1: illegal
    val badF5 = Enc.r(0x05 << 2, 1, 10, 2, 8, 0x2f); a.word(badF5)       // funct5 = 00101: illegal
    a.lrW(14, 11); a.scW(9, 1, 10)                  // a trapping LR reserves nothing: x9 = 1
    a.lw(8, 0, 10)                                  // memory unchanged: 77
    a.halt()
    a.label("handler")
    a.csrrs(20, CsrAddr.mcause, 0); a.sw(20, 0, 24)
    a.csrrs(21, CsrAddr.mtval, 0); a.sw(21, 4, 24); a.addi(24, 24, 8)
    a.csrrs(29, CsrAddr.mepc, 0); a.addi(29, 29, 4); a.csrrw(0, CsrAddr.mepc, 29); a.mret()
    val res = run(a)
    val expected = Seq(4L -> (Data + 2), 6L -> (Data + 2), 6L -> (Data + 2), 6L -> (Data + 1), 6L -> (Data + 3),
      2L -> badF3, 2L -> lrRs2, 2L -> badF5, 4L -> (Data + 2))
    res.traps shouldBe expected.length
    for (((cause, tval), k) <- expected.zipWithIndex) withClue(s"trap $k: ") {
      word(res, Log + 8L * k) shouldBe cause
      word(res, Log + 8L * k + 4) shouldBe tval
    }
    Seq(3, 4, 5, 6, 7, 14).foreach(r => withClue(s"x$r: ") { res.model.x(r) shouldBe 0L })
    res.model.x(9) shouldBe 1L
    res.model.x(8) shouldBe 77L
    word(res, Data + 4) shouldBe 0L
  }

  it should "take one cycle per LR, SC and AMO, plus one for a user right behind (as after a load)" in {
    val a = new Asm
    a.li(10, Data); a.li(1, 1); a.li(2, 2)
    // all eleven, each followed by an independent instruction: no stall
    a.lrW(3, 10); a.nop(); a.scW(3, 1, 10); a.nop()
    for (f5 <- AmoFn.Amos) { a.amoW(f5, 3, 2, 10); a.nop() }
    // four users right behind: one stall each
    a.amoaddW(4, 1, 10); a.add(5, 4, 0)
    a.lrW(6, 10); a.addi(7, 6, 1)
    a.scW(8, 1, 10); a.add(9, 8, 8)
    a.amoswapW(11, 1, 10); a.amoaddW(12, 11, 10)
    // one instruction in between: forwarded from WB, no stall
    a.amoaddW(13, 1, 10); a.nop(); a.add(14, 13, 13)
    // a user of x0 or of another register: no stall
    a.amoaddW(0, 1, 10); a.add(15, 0, 0)
    a.halt()
    val res = run(a)
    res.traps shouldBe 0
    res.events.count(e => isAtomic(e.inst)) shouldBe 2 + 9 + 5 + 2
    res.stallCycles shouldBe (Core.FillCycles + 4)
    val names = res.events.map(e => Disasm(e.inst, e.pc).split(' ').head).toSet
    (Set("lr.w", "sc.w", "amoswap.w", "amoadd.w", "amoxor.w", "amoand.w", "amoor.w", "amomin.w", "amomax.w",
      "amominu.w", "amomaxu.w") -- names) shouldBe empty
  }

  it should "match the reference model on 3000 random instructions mixing ALU, loads, stores, LR, SC and AMOs" in {
    val r = new Random(11)
    val a = new Asm
    a.li(16, Data)
    for (k <- 0 until 4) a.li(17 + k, Data + 4L * k)   // x17..x20: aligned addresses of the four atomic words
    for (k <- 1 to 15) a.li(k, rnd32(r))
    def reg = 1 + r.nextInt(15)
    def src = r.nextInt(16)
    def at = 17 + r.nextInt(4)
    var n = 0
    while (n < 3000) {
      r.nextInt(14) match {
        case 0 => a.add(reg, src, src); n += 1
        case 1 => a.sub(reg, src, src); n += 1
        case 2 => a.xor(reg, src, src); n += 1
        case 3 => a.addi(reg, src, r.nextInt(4096) - 2048); n += 1
        case 4 => a.sw(src, 4 * r.nextInt(8), 16); n += 1
        case 5 => a.lw(reg, 4 * r.nextInt(8), 16); n += 1
        case 6 => if (r.nextBoolean()) a.sb(src, r.nextInt(32), 16) else a.lbu(reg, r.nextInt(32), 16); n += 1
        case 7 => a.mul(reg, src, src); n += 1
        case 8 | 9 => a.amoW(AmoFn.Amos(r.nextInt(9)), r.nextInt(16), src, at); n += 1
        case 10 => a.lrW(r.nextInt(16), at); n += 1
        case 11 => a.scW(r.nextInt(16), src, at); n += 1
        case _ =>                                  // an LR/SC pair, a few instructions apart, often on the same word
          val w = at
          a.lrW(reg, w)
          val gap = r.nextInt(3)
          for (_ <- 0 until gap) a.add(reg, src, src)
          a.scW(reg, src, if (r.nextInt(4) == 0) at else w)
          n += 2 + gap
      }
    }
    a.halt()
    val res = run(a, data = (0 until 8).map(k => (Data + 4L * k) -> rnd32(r)))
    res.traps shouldBe 0
    val scs = res.events.filter(e => isAtomic(e.inst) && f5Of(e.inst) == AmoFn.SC)
    scs.count(_.memWe) should be > 50
    scs.count(!_.memWe) should be > 50
    res.events.count(e => isAtomic(e.inst) && AmoFn.Amos.contains(f5Of(e.inst))) should be > 300
  }
}
