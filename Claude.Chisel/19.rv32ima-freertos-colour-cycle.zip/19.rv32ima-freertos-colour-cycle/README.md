# FreeRTOS on the RV32IMA core on the iCESugar-Pro: colour cycle

The third FreeRTOS example for the Stage 11 core (RV32IMA, 5-stage pipeline, written in Chisel, with the machine
timer interrupt) on the **iCESugar-Pro** board (Lattice ECP5 LFE5U-25F). The hardware is the same as in the first two
examples; only the application differs. The on-board **RGB LED** shows one colour at a time, with the LED **off**
in between:

```
red 2 s -> off 1 s -> green 2 s -> off 1 s -> blue 2 s -> off 1 s -> red ...      (one round: 9 s)
```

Each colour belongs to its own FreeRTOS task. The three tasks take turns, passing a token in a ring with FreeRTOS
task notifications.

A ready-made bitstream is included: `fpga/IceSugarProTop.bit`.

## 1. Quick start with the ready-made bitstream

1. Connect the iCESugar-Pro with a USB-C cable. The on-board iCELink appears as a USB drive called **iCELink** and as a
   serial port (`/dev/ttyACM0` on Linux).
2. Optional: open a terminal at **115200 baud, 8N1** before programming, to see the start-up message:

   ```bash
   picocom -b 115200 /dev/ttyACM0
   ```

3. Copy `fpga/IceSugarProTop.bit` onto the iCELink drive, or run:

   ```bash
   icesprog fpga/IceSugarProTop.bit
   ```

The terminal shows:

```
FreeRTOS V11.1.0 on RV32IMA (5-stage pipeline, Chisel) on iCESugar-Pro: colour cycle red, green, blue (2 s on, 1 s off)
```

and the LED starts with red. If all three colours **blink fast together**, the firmware has stopped on a fault
(failed assertion, stack overflow, out of heap, or an unexpected exception): see `prvFault` in `firmware/main.c`.

## 2. The application (`firmware/main.c`)

The two times are at the top of the file:

```c
#define COLOUR_ON_MS   2000u        /* how long each colour stays on */
#define LED_OFF_MS     1000u        /* LED off between two colours */
```

One task function serves the three colours; each task gets its own parameter block: its colour, how long it stays
on, and which task comes next.

```c
static const ColourParams_t xRed   = { LED_RED,   COLOUR_ON_MS, &xGreenTask };
static const ColourParams_t xGreen = { LED_GREEN, COLOUR_ON_MS, &xBlueTask };
static const ColourParams_t xBlue  = { LED_BLUE,  COLOUR_ON_MS, &xRedTask };

static void vColourTask( void * pvParameters )
{
    const ColourParams_t * p = pvParameters;
    for( ; ; )
    {
        while( ulTaskNotifyTake( pdTRUE, portMAX_DELAY ) == 0 ) { }   /* wait for the turn */
        LED = p->ulMask;                                              /* this colour on */
        vTaskDelay( pdMS_TO_TICKS( p->ulOnMs ) );
        LED = 0;                                                      /* LED off */
        vTaskDelay( pdMS_TO_TICKS( LED_OFF_MS ) );
        xTaskNotifyGive( *p->pxNext );                                /* hand the turn on */
    }
}
```

`main()` creates the three tasks (all priority 2), gives red the first turn with `xTaskNotifyGive( xRedTask )` and
starts the scheduler.

**How the turn passes.** A direct-to-task notification works like a binary semaphore built into each task.
`ulTaskNotifyTake` blocks the task until another task calls `xTaskNotifyGive` for it. Exactly one task holds the
turn at any time; the other two are blocked and use no CPU. While the holder waits in `vTaskDelay`, all three are
blocked, and the FreeRTOS idle task runs.

**Why plain stores are enough here.** Only the task that holds the turn writes the LED, so there is never a second
writer to interfere with: a simple `LED = mask` is safe, and two colours can never be on together. (The previous
example, where the three tasks wrote the LED at the same time, needed the atomic AMO instructions.)

**Changing the pattern:**

- all colours on for 1 s and off for 2 s: set `COLOUR_ON_MS` to 1000 and `LED_OFF_MS` to 2000;
- a different time per colour: change `COLOUR_ON_MS` in one of the three parameter blocks (e.g. `1000u` for red);
- another order: change the `&x...Task` links, and which task gets the first `xTaskNotifyGive` in `main()`.

The times are in milliseconds and are rounded to the 10 ms tick. After a change, check at instruction level and
rebuild the bitstream (section 4). The checker `tools/ledcycle_check.py` has the same two times at its top
(`ON_US`, `OFF_US`): change them too.

## 3. The system

Unchanged from the first two examples:

| Block | Details |
|---|---|
| Clock | 25 MHz oscillator (P6), used directly: **25 MHz** system clock |
| Core | Stage 11 RV32IMA 5-stage pipeline + the machine timer interrupt; reset pc 0x80000000 |
| RAM | **32 KiB at 0x80000000**: one memory for instructions and data, block RAM, loaded with the firmware by the bitstream |
| CLINT | mtimecmp at 0x02004000, mtime at 0x0200BFF8; mtime counts at **1 MHz**; MTIP = mtime >= mtimecmp |
| LED | 0x10000000: bits 2:0 = {blue, green, red}, 1 = on (pins B11 red, A11 green, A12 blue) |
| UART | 0x10000004 TX, 0x10000008 status, 0x1000000C RX; 115200 baud 8N1 on the iCELink serial port (B9 TX, A9 RX) |

FreeRTOS configuration (`firmware/FreeRTOSConfig.h`, unchanged): preemptive, 5 priorities, tick 100 Hz (10 ms),
task notifications on, heap_4 with 12 KiB, stack overflow checking, assertions on.

Memory use: the image is 7,248 bytes (6,912 code, 324 read-only data, 12 data). Then `.bss` (12,560 bytes, mostly
the 12 KiB heap with the four task control blocks and 512-byte stacks) and the 1 KiB interrupt stack: about 21 KiB of
the 32 KiB.

Last build (Yosys 0.71, nextpnr-ecp5 0.11.1). Only the RAM contents differ from the earlier examples:

| Resource | Used | Of |
|---|---|---|
| LUT4 / logic cells | 9,138 | 24,288 (37 %) |
| Flip-flops | 2,158 | 24,288 (9 %) |
| DP16KD block RAM | 32 (all 32 carry the firmware image) | 56 |
| MULT18X18D | 4 | 28 |

Maximum frequency **40.66 MHz**, constraint 25 MHz: **PASS**.

## 4. Building it yourself

Tools:

- **Firmware:** clang and ld.lld with the RISC-V target (LLVM 14 or newer; Ubuntu: `sudo apt install clang lld llvm`),
  or a GNU RISC-V toolchain (`make GCC=1`), and Python 3
- **Hardware:** Java 11+ and sbt for Chisel; Yosys, nextpnr-ecp5 and ecppack (the YosysHQ oss-cad-suite, or
  `make YOWASP=1` with `pip install yowasp-yosys yowasp-nextpnr-ecp5`)

Everything at once, from the `fpga` folder:

```bash
make
```

This builds the firmware (`firmware/freertos.hex`), generates the Verilog with the firmware in the RAM
(`sbt "runMain rv32i.EmitFpga"`), then runs Yosys, nextpnr-ecp5 and ecppack and leaves `fpga/build/IceSugarProTop.bit`.

Only the firmware, from the `firmware` folder:

```bash
make
```

After changing the application, check it at instruction level (about 2 minutes), then run `make` in `fpga` again:
the new firmware has to go into the bitstream.

```bash
python3 tools/rvsim.py firmware/freertos.hex
```

## 5. How it was checked

The checks compare every LED change with the intended pattern (`tools/ledcycle_check.py`): the LED shows one colour
or nothing, the order is red, off, green, off, blue, off, and every change happens at its planned time. To make sure
the checks can fail, they were given five broken logs, and all five were caught: no off gap, two colours on
together, the wrong order, an off gap 0.5 s too short, and a colour missing.

1. **The core:** unchanged from the first example (48 tests passing, including `CoreIrqSpec` for the timer
   interrupt).
2. **The firmware at instruction level** (`tools/rvsim.py`, a separate simulator of the whole system, in Python):
   the LED was checked over 20 s at a fast setting (mtime +1 every 5 cycles) and over 19 s at the board rate
   (mtime +1 every 25 cycles, 475 million instructions, 1,899 timer interrupts). Both runs **pass**: 13 changes,
   red at 0 s, off at 2 s, green at 3 s, off at 5 s, blue at 6 s, off at 8 s, red at 9 s, off at 11 s, …. Every
   change is within 49 µs of its planned time at the fast setting, and within **10 µs** at the board rate.

   ```bash
   python3 tools/rvsim.py firmware/freertos.hex                          # 20 s, fast setting
   python3 tools/rvsim.py firmware/freertos.hex --seconds 19 --div 25    # board rate, about 12 minutes
   ```

3. **The whole system, cycle by cycle** (`FpgaFreeRtosSpec`): the generated hardware (core, RAM with the firmware
   image, CLINT, LED, UART) runs the real firmware in the Chisel simulator. To make it feasible, time runs faster:
   mtime counts 25 per clock cycle (one tick every 400 cycles instead of 250,000; the firmware is unchanged), so
   420,000 cycles cover 10.5 s of board time: the boot, a full round and the return to red. The test checks the banner,
   that the LED only ever shows one colour or nothing, the order, and the length of every interval. In this
   compressed time, a tick lasts only 400 cycles. Handing the turn to the next task (wake-up, notification, task
   switch) takes longer than that, so each new colour starts about one tick (10 ms) late: the test allows one tick
   plus 5 ms. On the board a tick is 250,000 cycles and the handover takes microseconds (see the 10 µs above).
   Result: **pass** (420,000 cycles, 94 minutes, 74 cycles/s). The banner arrives, and the LED goes red at 0 s,
   off at 2.001 s, green at 3.012 s, off at 5.011 s, blue at 6.022 s, off at 8.021 s, red at 9.031 s. The worst
   interval error is 10.8 ms: the one tick of the handover described above.

   ```bash
   sbt "testOnly rv32i.FpgaFreeRtosSpec"
   ```

4. **The hardware build:** synthesis, placement and routing complete, timing passes at 25 MHz, all 32 block RAMs carry
   the firmware image, and ecppack produces the bitstream.

**Not done:** this bitstream has not been run on a real board yet (the first example, with the same hardware, has),
and the routed netlist was not simulated (no gate-level simulator was available).

## 6. Files

| Path | Contents |
|---|---|
| `firmware/main.c` | **The application**: `vColourTask` (three tasks), the turn passing, start-up message, fault handler |
| `firmware/` | Also `FreeRTOSConfig.h`, `start.S`, `link.ld`, `lib.c` + `include/` (minimal C library), `Makefile`, `tohex.py`, `FreeRTOS-Kernel/` (V11.1.0: kernel, RISC-V port, heap_4, MIT licence), and the built `freertos.elf` / `.hex` / `.lst` |
| `src/main/scala/rv32i/` | The core (`Core`, `CsrFile`, `Decoder`, …, see `CORE.md`), the system and top level (`IceSugarPro.scala`: `IceSugarSoC`, `Clint`, `IceSugarProTop`, `EmitFpga`), the UART |
| `src/test/scala/rv32i/` | Core tests, `FpgaFreeRtosSpec` (this application on the whole system) |
| `fpga/` | `Makefile`, `icesugar_pro.lpf` (pins), `IceSugarProTop.bit`, `build/` (Verilog, logs) |
| `tools/rvsim.py`, `tools/ledcycle_check.py` | Instruction-level simulator of the system; the LED pattern check |
| `CORE.md`, `DESIGN_NOTES.md` | The core: instructions, tests, interface, waveforms; design choices, including the interrupt |
