package rv32i

import chisel3._
import chisel3.util._
import chisel3.experimental.{annotate, ChiselAnnotation}
import firrtl.annotations.MemoryArrayInitAnnotation

import java.nio.file.{Files, Paths}
import scala.jdk.CollectionConverters._

/** Memory map of the FreeRTOS system. */
object FpgaMap {
  val RamBase   = 0x80000000L   // 32 KiB RAM: program, data, heap, stacks (reset pc = RamBase)
  val RamWords  = 8192
  val ClintBase = 0x02000000L   // CLINT (SiFive layout, one hart):
  val MtimecmpLo = 0x4000       //   mtimecmp low / high (R/W, reset 0xffffffff_ffffffff: no interrupt)
  val MtimecmpHi = 0x4004
  val MtimeLo    = 0xbff8       //   mtime low / high (R/W), counts mtimeInc every mtimeDiv clock cycles
  val MtimeHi    = 0xbffc
  val IoBase    = 0x10000000L   // I/O registers (as in the earlier board projects):
  val Led       = 0x00          //   LED      R/W  bits 2:0 = {blue, green, red}, 1 = on
  val UartTx    = 0x04          //   UART_TX  W    byte to send (only when UART_STATUS.0 = 1)
  val UartStat  = 0x08          //   UART_STATUS R bit 0: transmitter ready, bit 1: a received byte is waiting
  val UartRx    = 0x0c          //   UART_RX  R    the received byte (reading it clears UART_STATUS.1)

  /** Reads a hex file with one 32-bit word per line (blank lines ignored). */
  def readHex(path: String): Seq[Long] =
    Files.readAllLines(Paths.get(path)).asScala.map(_.trim).filter(_.nonEmpty).map(java.lang.Long.parseLong(_, 16)).toSeq
}

/** CLINT timer: 64-bit mtime and mtimecmp, `mtip` = (mtime >= mtimecmp), registered. Word access only (byte strobes
  * are honoured per byte). mtime advances by `inc` every `div` clock cycles: on the board 1 every 25 cycles of the
  * 25 MHz clock (1 MHz, the frequency FreeRTOS is configured for); in simulation it can run faster.
  */
class Clint(div: Int, inc: Int, init: BigInt = 0) extends Module {
  require(div >= 1 && inc >= 1)
  val io = IO(new Bundle {
    val reg   = Input(UInt(16.W))     // byte offset inside the CLINT
    val we    = Input(Bool())
    val wdata = Input(UInt(32.W))
    val wstrb = Input(UInt(4.W))
    val rdata = Output(UInt(32.W))
    val mtip  = Output(Bool())
  })
  import FpgaMap._
  val mtime    = RegInit(init.U(64.W))   // init: only for simulation (start mid-way); 0 on the board
  val mtimecmp = RegInit(~0.U(64.W))
  val pre      = if (div > 1) Some(RegInit(0.U(log2Ceil(div).W))) else None
  val step     = pre.map(_ === (div - 1).U).getOrElse(true.B)
  pre.foreach(p => p := Mux(step, 0.U, p + 1.U))
  val mtimeNext = Mux(step, mtime + inc.U, mtime)

  private def merge(old: UInt): UInt =
    Cat((3 to 0 by -1).map(k => Mux(io.wstrb(k), io.wdata(8 * k + 7, 8 * k), old(8 * k + 7, 8 * k))))
  mtime := mtimeNext
  when(io.we) {
    switch(io.reg) {
      is(MtimecmpLo.U) { mtimecmp := Cat(mtimecmp(63, 32), merge(mtimecmp(31, 0))) }
      is(MtimecmpHi.U) { mtimecmp := Cat(merge(mtimecmp(63, 32)), mtimecmp(31, 0)) }
      is(MtimeLo.U)    { mtime := Cat(mtimeNext(63, 32), merge(mtime(31, 0))) }
      is(MtimeHi.U)    { mtime := Cat(merge(mtime(63, 32)), mtimeNext(31, 0)) }
    }
  }
  io.rdata := MuxLookup(io.reg, 0.U)(Seq(
    MtimecmpLo.U -> mtimecmp(31, 0), MtimecmpHi.U -> mtimecmp(63, 32),
    MtimeLo.U    -> mtime(31, 0),    MtimeHi.U    -> mtime(63, 32)))
  io.mtip := RegNext(mtime >= mtimecmp, false.B)
}

/** The FreeRTOS system: the RV32IMA 5-stage core with its timer interrupt, 32 KiB of RAM holding the firmware, the
  * CLINT timer, the RGB LED and the UART.
  *
  *  - RAM: one memory for instructions and data (von Neumann), four byte lanes, preloaded with `firmware` (the
  *    bitstream carries it). The core reads it twice per cycle (fetch in IF, data in MEM) and writes it in MEM. Both
  *    read addresses come straight from registers (fetchPc, the EX/MEM address), so Yosys can map the memory to
  *    block RAM (it moves those registers into the RAM's synchronous read ports; one copy per read port).
  *  - An AMO on the LED register reads and writes it in the same cycle, exactly as in RAM.
  */
class IceSugarSoC(firmware: Seq[Long], uartDivisor: Int, mtimeDiv: Int = 25, mtimeInc: Int = 1, mtimeInit: BigInt = 0)
    extends Module {
  import FpgaMap._
  require(firmware.length <= RamWords, s"firmware has ${firmware.length} words, the RAM holds $RamWords")
  val io = IO(new Bundle {
    val led    = Output(UInt(3.W))   // {blue, green, red}, 1 = on
    val uartTx = Output(Bool())
    val uartRx = Input(Bool())
  })

  val core  = Module(new Core(resetPc = RamBase))
  val clint = Module(new Clint(mtimeDiv, mtimeInc, mtimeInit))
  core.io.timerIrq := clint.io.mtip

  // ---------------- RAM: four byte lanes, preloaded with the firmware ----------------
  val idxBits = log2Ceil(RamWords)
  val lanes = Seq.tabulate(4) { k =>
    val m = Mem(RamWords, UInt(8.W))
    val init = (firmware ++ Seq.fill(RamWords - firmware.length)(0L)).map(w => BigInt((w >> (8 * k)) & 0xff))
    annotate(new ChiselAnnotation { override def toFirrtl = MemoryArrayInitAnnotation(m.toTarget, init) })
    m
  }
  private def inRam(a: UInt): Bool = a(31, idxBits + 2) === (RamBase >> (idxBits + 2)).U

  // fetch
  val fAddr = core.io.imem.addr
  val fIdx  = fAddr(idxBits + 1, 2)
  core.io.imem.data := Mux(inRam(fAddr), Cat(lanes.reverse.map(_(fIdx))), 0.U)   // 0 elsewhere: illegal instruction

  // data
  val addr  = core.io.dmem.addr
  val dIdx  = addr(idxBits + 1, 2)
  val isRam = inRam(addr)
  val isIo  = addr(31, 5) === (IoBase >> 5).U
  val isClint = addr(31, 16) === (ClintBase >> 16).U
  val ramWord = Cat(lanes.reverse.map(_(dIdx)))
  for (k <- 0 until 4) {
    when(core.io.dmem.we && isRam && core.io.dmem.wstrb(k)) { lanes(k)(dIdx) := core.io.dmem.wdata(8 * k + 7, 8 * k) }
  }

  // ---------------- CLINT ----------------
  clint.io.reg   := addr(15, 0)
  clint.io.we    := core.io.dmem.we && isClint
  clint.io.wdata := core.io.dmem.wdata
  clint.io.wstrb := core.io.dmem.wstrb

  // ---------------- LED and UART ----------------
  val ioReg = addr(4, 0)
  val leds  = RegInit(0.U(3.W))
  val tx    = Module(new UartTx(uartDivisor))
  val rx    = Module(new UartRx(uartDivisor))
  val ioWrite = core.io.dmem.we && isIo
  val ioRead  = core.io.dmem.re && isIo
  when(ioWrite && ioReg === Led.U) { leds := core.io.dmem.wdata(2, 0) }
  tx.io.valid := ioWrite && ioReg === UartTx.U
  tx.io.data  := core.io.dmem.wdata(7, 0)
  rx.io.rx    := io.uartRx
  rx.io.take  := ioRead && ioReg === UartRx.U
  val ioData = MuxLookup(ioReg, 0.U)(Seq(
    Led.U      -> leds,
    UartStat.U -> Cat(rx.io.valid, tx.io.ready),
    UartRx.U   -> rx.io.data
  ))

  core.io.dmem.rdata := Mux(isRam, ramWord, Mux(isIo, ioData, Mux(isClint, clint.io.rdata, 0.U)))
  io.led    := leds
  io.uartTx := tx.io.tx
}

/** The ECP5 PLL (EHXPLLL) configured by fpga/pll25to12p5.v: 25 MHz in, 12.5 MHz out. */
class pll25to12p5 extends BlackBox {
  val io = IO(new Bundle {
    val clkin   = Input(Clock())
    val clkout0 = Output(Clock())
    val locked  = Output(Bool())
  })
}

/** Top level for the iCESugar-Pro board (Lattice ECP5 LFE5U-25F-6BG256C): 25 MHz clock on P6, RGB LED on B11 (red),
  * A11 (green), A12 (blue), active-high, USB serial of the on-board iCELink on B9 (FPGA TX) and A9 (FPGA RX).
  * `usePll = false`: the system runs from the 25 MHz oscillator; `usePll = true`: from the 12.5 MHz PLL output.
  * mtime always counts at 1 MHz (`clockHz` / 1 MHz cycles per count). Reset is held for 15 cycles after configuration.
  */
class IceSugarProTop(firmware: Seq[Long], clockHz: Int = 25000000, baud: Int = 115200, usePll: Boolean = false)
    extends RawModule {
  require(clockHz % 1000000 == 0, "mtime counts at 1 MHz: the clock must be a whole number of MHz")
  val clk_i   = IO(Input(Clock()))
  val led_r   = IO(Output(Bool()))
  val led_g   = IO(Output(Bool()))
  val led_b   = IO(Output(Bool()))
  val uart_tx = IO(Output(Bool()))
  val uart_rx = IO(Input(Bool()))

  val (clk, locked) =
    if (usePll) { val pll = Module(new pll25to12p5); pll.io.clkin := clk_i; (pll.io.clkout0, pll.io.locked) }
    else (clk_i, true.B)

  val porCount = withClockAndReset(clk, !locked) { RegInit(0.U(4.W)) }
  val porDone  = porCount.andR
  withClockAndReset(clk, false.B) { when(!porDone) { porCount := porCount + 1.U } }

  val soc = withClockAndReset(clk, !porDone) {
    Module(new IceSugarSoC(firmware, (clockHz + baud / 2) / baud, mtimeDiv = clockHz / 1000000, mtimeInc = 1))
  }
  soc.io.uartRx := uart_rx
  uart_tx := soc.io.uartTx
  led_r := soc.io.led(0)
  led_g := soc.io.led(1)
  led_b := soc.io.led(2)
}

/** Generates fpga/build/IceSugarProTop.v (plain Verilog for Yosys) with the firmware in the RAM.
  * Run: sbt "runMain rv32i.EmitFpga"                     firmware/freertos.hex (build it first: make -C firmware)
  *      sbt "runMain rv32i.EmitFpga path/to/program.hex"  any other program (one 32-bit word per line, <= 8192 words)
  * then: make -C fpga
  */
object EmitFpga extends App {
  val hex = args.headOption.getOrElse("firmware/freertos.hex")
  val firmware = FpgaMap.readHex(hex)
  println(s"$hex: ${firmware.length} words")
  val v = (new chisel3.stage.ChiselStage).emitVerilog(new IceSugarProTop(firmware), Array("--target-dir", "fpga/build"))
  // The RAM contents are emitted as `lanes_k[i] = v;` inside the simulation-only `ifndef SYNTHESIS initial block,
  // which Yosys skips (it defines SYNTHESIS). Move them into their own initial block so the bitstream carries them.
  val isInit = """^\s*lanes_[0-3]\[\d+\] = \d+;$""".r
  val lines = v.split("\n", -1).toSeq
  val init = lines.filter(l => isInit.matches(l))
  require(init.length == 4 * FpgaMap.RamWords, s"expected ${4 * FpgaMap.RamWords} RAM init lines, found ${init.length}")
  val firstInit = lines.indexWhere(l => isInit.matches(l))
  val socEnd = lines.indexWhere(_.startsWith("endmodule"), firstInit)
  val block = Seq("// firmware image: outside the SYNTHESIS guard, so that Yosys loads it into the block RAM", "initial begin") ++
    init.filter(l => !l.trim.endsWith("= 0;")) ++ Seq("end")
  val out = (lines.take(socEnd).filterNot(l => isInit.matches(l)) ++ block ++ lines.drop(socEnd)).mkString("\n")
  Files.write(Paths.get("fpga/build/IceSugarProTop.v"), out.getBytes("UTF-8"))
  println(s"wrote fpga/build/IceSugarProTop.v (${init.count(l => !l.trim.endsWith("= 0;"))} non-zero RAM bytes)")
}
