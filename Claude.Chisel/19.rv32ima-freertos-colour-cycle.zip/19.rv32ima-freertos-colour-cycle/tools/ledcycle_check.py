"""Checks the LED pattern of the colour-cycle application (firmware/main.c) from a log of LED changes.

The log is a list of (mtime, LED value) pairs, mtime in microseconds (1 MHz, as on the board). It is used by
tools/rvsim.py; the cycle-accurate FpgaFreeRtosSpec does the same check in Scala.

Expected, from the first change (red on): red 2 s, off 1 s, green 2 s, off 1 s, blue 2 s, off 1 s, and again.
Every change must happen within EDGE_TOL_US of its planned time (the changes happen at a 10 ms tick plus the task
switch time), and the LED value must always be one colour or off.
"""

ON_US, OFF_US = 2000000, 1000000
EDGE_TOL_US = 1000
SEQUENCE = (1, 2, 4)        # red, green, blue


def expected(t0, t_end):
    out, t, k = [], t0, 0
    while True:
        colour = SEQUENCE[k % 3]
        if t > t_end: return out
        out.append((t, colour))
        t += ON_US
        if t > t_end: return out
        out.append((t, 0))
        t += OFF_US
        k += 1


def check(log, t_end):
    report, ok = [], True
    for t, v in log:
        if v not in (0, 1, 2, 4):
            report.append("mtime %d: LED %s is not a single colour" % (t, format(v, "03b"))); ok = False
    if not log:
        return False, ["the LED never changed"]
    want = expected(log[0][0], t_end - EDGE_TOL_US)
    worst = 0
    for (tg, vg), (tw, vw) in zip(log, want):
        worst = max(worst, abs(tg - tw))
        if vg != vw or abs(tg - tw) > EDGE_TOL_US: ok = False
    if not (len(want) <= len(log) <= len(want) + 1): ok = False
    names = {0: "off", 1: "red", 2: "green", 4: "blue"}
    t0 = log[0][0]
    report.append("%d LED changes (expected %d), worst timing error %d us" % (len(log), len(want), worst))
    report.append("sequence: " + ", ".join("%s at %.3f s" % (names.get(v, format(v, "03b")), (t - t0) / 1e6)
                                            for t, v in log[:8]) + (" ..." if len(log) > 8 else ""))
    if not ok:
        report.append("expected: " + ", ".join("%s at %.3f s" % (names[v], (t - t0) / 1e6) for t, v in want[:8]))
    return ok, report
