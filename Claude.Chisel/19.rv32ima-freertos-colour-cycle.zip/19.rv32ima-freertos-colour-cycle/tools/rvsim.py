#!/usr/bin/env python3
"""Instruction-level simulator of the FreeRTOS system: RV32IMA + Zicsr, machine mode, the machine timer interrupt,
the CLINT (mtime / mtimecmp), the RGB LED register and the UART transmitter, with the same memory map as the FPGA
system (IceSugarPro.scala). Written independently of the Chisel code, to check the firmware over long runs.

Time: one instruction = one clock cycle (the pipeline is faster or slower around branches and divisions, but the
firmware only depends on mtime). mtime grows by MTIME_INC every MTIME_DIV instructions.

    python3 tools/rvsim.py firmware/freertos.hex [--seconds S] [--div D] [--inc I]

prints the UART output and checks the LED pattern of the colour-cycle application (tools/ledcycle_check.py): red,
off, green, off, blue, off, 2 s on and 1 s off. The default --div 5 runs the CPU at 5 instructions per microsecond
(the board does about 20) to keep the run short; --div 25 is the board's rate.
"""
import argparse
import sys

import ledcycle_check

RAM_BASE, RAM_SIZE = 0x80000000, 32 * 1024
IO_BASE = 0x10000000
MTIMECMP, MTIME = 0x02004000, 0x0200BFF8
M32 = 0xFFFFFFFF


def sext(v, bits):
    v &= (1 << bits) - 1
    return v - (1 << bits) if v >> (bits - 1) else v


class Sim:
    def __init__(self, words, mtime_div, mtime_inc):
        self.mem = bytearray(RAM_SIZE)
        for k, w in enumerate(words):
            self.mem[4 * k:4 * k + 4] = w.to_bytes(4, "little")
        self.x = [0] * 32
        self.pc = RAM_BASE
        self.mstatus_mie = self.mstatus_mpie = 0
        self.mie = self.mtvec = self.mscratch = self.mepc = self.mcause = self.mtval = 0
        self.cycle = self.instret = 0
        self.mtime, self.mtimecmp = 0, (1 << 64) - 1
        self.div, self.inc, self.sub = mtime_div, mtime_inc, 0
        self.led = 0
        self.uart = []
        self.res = None
        self.led_log = []          # (cycle, mtime, new value)
        self.interrupts = 0

    # ---- memory and I/O
    def load32(self, a):
        if RAM_BASE <= a < RAM_BASE + RAM_SIZE:
            o = a - RAM_BASE
            return int.from_bytes(self.mem[o & ~3:(o & ~3) + 4], "little")
        if a & ~31 == IO_BASE:
            r = a & 31
            if r == 0: return self.led
            if r == 8: return 1                       # transmitter always ready, no received byte
            return 0
        if a == MTIMECMP: return self.mtimecmp & M32
        if a == MTIMECMP + 4: return self.mtimecmp >> 32
        if a == MTIME: return self.mtime & M32
        if a == MTIME + 4: return (self.mtime >> 32) & M32
        return 0

    def store(self, a, v, size):
        if RAM_BASE <= a < RAM_BASE + RAM_SIZE:
            o = a - RAM_BASE
            self.mem[o:o + size] = (v & ((1 << (8 * size)) - 1)).to_bytes(size, "little")
            return
        assert size == 4, "only word stores to I/O"
        if a == IO_BASE:
            if (v & 7) != self.led:
                self.led_log.append((self.cycle, self.mtime, v & 7))
            self.led = v & 7
        elif a == IO_BASE + 4:
            self.uart.append(chr(v & 0xff))
        elif a == MTIMECMP: self.mtimecmp = (self.mtimecmp & ~M32) | v
        elif a == MTIMECMP + 4: self.mtimecmp = (self.mtimecmp & M32) | (v << 32)
        elif a == MTIME: self.mtime = (self.mtime & ~M32) | v
        elif a == MTIME + 4: self.mtime = (self.mtime & M32) | (v << 32)

    # ---- CSRs
    def csr_read(self, n):
        return {0x300: (3 << 11) | (self.mstatus_mpie << 7) | (self.mstatus_mie << 3), 0x301: 0x40001101,
                0x304: self.mie, 0x305: self.mtvec, 0x340: self.mscratch, 0x341: self.mepc, 0x342: self.mcause,
                0x343: self.mtval, 0x344: 0x80 if self.mtime >= self.mtimecmp else 0,
                0xb00: self.cycle & M32, 0xb80: self.cycle >> 32, 0xc00: self.cycle & M32, 0xc80: self.cycle >> 32,
                0xb02: self.instret & M32, 0xb82: self.instret >> 32, 0xc02: self.instret & M32,
                0xc82: self.instret >> 32, 0xf11: 0, 0xf12: 0, 0xf13: 0, 0xf14: 0, 0x310: 0}[n]

    def csr_write(self, n, v):
        if n == 0x300: self.mstatus_mie, self.mstatus_mpie = (v >> 3) & 1, (v >> 7) & 1
        elif n == 0x304: self.mie = v & 0x888
        elif n == 0x305: self.mtvec = v & ~3
        elif n == 0x340: self.mscratch = v
        elif n == 0x341: self.mepc = v & ~3
        elif n == 0x342: self.mcause = v
        elif n == 0x343: self.mtval = v

    def trap(self, cause, tval, intr=False):
        self.mepc = self.pc
        self.mcause = (0x80000000 | cause) if intr else cause
        self.mtval = tval
        self.mstatus_mpie, self.mstatus_mie = self.mstatus_mie, 0
        self.res = None
        self.pc = self.mtvec

    # ---- one instruction
    def step(self):
        self.cycle += 1
        self.sub += 1
        if self.sub == self.div:
            self.sub = 0
            self.mtime += self.inc
        if self.mstatus_mie and (self.mie & 0x80) and self.mtime >= self.mtimecmp:
            self.interrupts += 1
            self.trap(7, 0, intr=True)
            return
        x, pc = self.x, self.pc
        i = self.load32(pc)
        op, rd, f3 = i & 0x7f, (i >> 7) & 31, (i >> 12) & 7
        rs1, rs2, f7 = (i >> 15) & 31, (i >> 20) & 31, i >> 25
        a, b = x[rs1], x[rs2]
        nxt = (pc + 4) & M32
        wb = None
        if op == 0x37: wb = i & 0xFFFFF000
        elif op == 0x17: wb = (pc + (i & 0xFFFFF000)) & M32
        elif op == 0x6f:
            off = sext(((i >> 31) << 20) | (((i >> 12) & 0xff) << 12) | (((i >> 20) & 1) << 11) | (((i >> 21) & 0x3ff) << 1), 21)
            wb, nxt = nxt, (pc + off) & M32
        elif op == 0x67:
            wb, nxt = nxt, (a + sext(i >> 20, 12)) & M32 & ~1
        elif op == 0x63:
            off = sext(((i >> 31) << 12) | (((i >> 7) & 1) << 11) | (((i >> 25) & 0x3f) << 5) | (((i >> 8) & 0xf) << 1), 13)
            sa, sb = sext(a, 32), sext(b, 32)
            t = [a == b, a != b, None, None, sa < sb, sa >= sb, a < b, a >= b][f3]
            if t: nxt = (pc + off) & M32
        elif op == 0x03:
            ad = (a + sext(i >> 20, 12)) & M32
            w = self.load32(ad); sh = 8 * (ad & 3)
            wb = [sext(w >> sh, 8) & M32, sext(w >> sh, 16) & M32, w, None, (w >> sh) & 0xff, (w >> sh) & 0xffff][f3]
        elif op == 0x23:
            ad = (a + sext(((i >> 25) << 5) | ((i >> 7) & 31), 12)) & M32
            self.store(ad, b, [1, 2, 4][f3])
        elif op == 0x13:
            imm = sext(i >> 20, 12) & M32; sh = rs2
            wb = [(a + imm) & M32, (a << sh) & M32, int(sext(a, 32) < sext(imm, 32)), int(a < imm), a ^ imm,
                  (sext(a, 32) >> sh) & M32 if f7 == 0x20 else a >> sh, a | imm, a & imm][f3]
        elif op == 0x33 and f7 == 1:
            sa, sb = sext(a, 32), sext(b, 32)
            if f3 == 0: wb = (sa * sb) & M32
            elif f3 == 1: wb = ((sa * sb) >> 32) & M32
            elif f3 == 2: wb = ((sa * b) >> 32) & M32
            elif f3 == 3: wb = ((a * b) >> 32) & M32
            elif f3 == 4: wb = M32 if b == 0 else (a if (sa == -2**31 and sb == -1) else int(sa / sb) & M32)
            elif f3 == 5: wb = M32 if b == 0 else a // b
            elif f3 == 6: wb = a if b == 0 else (0 if (sa == -2**31 and sb == -1) else (sa - sb * int(sa / sb)) & M32)
            else: wb = a if b == 0 else a % b
        elif op == 0x33:
            sh = b & 31
            wb = [((a - b) if f7 else (a + b)) & M32, (a << sh) & M32, int(sext(a, 32) < sext(b, 32)), int(a < b),
                  a ^ b, (sext(a, 32) >> sh) & M32 if f7 else a >> sh, a | b, a & b][f3]
        elif op == 0x2f:
            f5 = i >> 27
            assert f3 == 2 and a & 3 == 0, "bad atomic at %08x" % pc
            if f5 == 2:
                wb = self.load32(a); self.res = a
            elif f5 == 3:
                ok = self.res == a; self.res = None
                if ok: self.store(a, b, 4)
                wb = 0 if ok else 1
            else:
                old = self.load32(a); so, sb = sext(old, 32), sext(b, 32)
                new = {0: (old + b) & M32, 1: b, 4: old ^ b, 8: old | b, 0xc: old & b, 0x10: old if so < sb else b,
                       0x14: old if so > sb else b, 0x18: min(old, b), 0x1c: max(old, b)}[f5]
                self.store(a, new, 4); wb = old
        elif op == 0x0f: pass
        elif op == 0x73:
            if f3 == 0:
                if i == 0x73: self.trap(11, 0); return
                if i == 0x30200073:
                    self.mstatus_mie, self.mstatus_mpie = self.mstatus_mpie, 1
                    self.res = None
                    nxt = self.mepc
                elif i != 0x10500073: raise RuntimeError("unsupported SYSTEM %08x at %08x" % (i, pc))
            else:
                n = i >> 20
                src = rs1 if f3 & 4 else a
                old = self.csr_read(n)
                if (f3 & 3) == 1 or rs1 != 0:
                    self.csr_write(n, [None, src, old | src, old & ~src & M32][f3 & 3])
                wb = old
        else:
            raise RuntimeError("illegal instruction %08x at %08x" % (i, pc))
        if wb is not None and rd != 0:
            x[rd] = wb & M32
        self.instret += 1
        self.pc = nxt


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("hex")
    ap.add_argument("--seconds", type=float, default=20.0, help="mtime to simulate, in board seconds")
    ap.add_argument("--div", type=int, default=5, help="instructions per mtime step (25 on the board at 25 MHz)")
    ap.add_argument("--inc", type=int, default=1, help="mtime increment per step (1 on the board)")
    args = ap.parse_args()
    words = [int(l, 16) for l in open(args.hex) if l.strip()]
    s = Sim(words, args.div, args.inc)
    t_end = int(args.seconds * 1e6)
    while s.mtime < t_end:
        s.step()
    print("UART:", "".join(s.uart).strip())
    print("%d instructions, %d timer interrupts, %d LED changes" % (s.cycle, s.interrupts, len(s.led_log)))
    log = [(mt, v) for _, mt, v in s.led_log]
    ok, report = ledcycle_check.check(log, t_end)
    print("\n".join(report))
    print("PASS" if ok else "FAIL")
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
