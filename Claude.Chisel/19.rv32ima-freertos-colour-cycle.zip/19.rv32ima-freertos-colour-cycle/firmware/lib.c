/* Minimal C library for FreeRTOS on this bare-metal system. */
#include <string.h>
#include <stdint.h>

void * memset( void * s, int c, size_t n )
{
    uint8_t * p = s;
    while( n-- != 0 ) *p++ = ( uint8_t ) c;
    return s;
}

void * memcpy( void * d, const void * s, size_t n )
{
    uint8_t * p = d;
    const uint8_t * q = s;
    while( n-- != 0 ) *p++ = *q++;
    return d;
}

int memcmp( const void * a, const void * b, size_t n )
{
    const uint8_t * p = a, * q = b;
    for( ; n != 0; n--, p++, q++ )
        if( *p != *q ) return *p - *q;
    return 0;
}

size_t strlen( const char * s )
{
    size_t n = 0;
    while( s[ n ] != 0 ) n++;
    return n;
}
