/* Reset entry: stack pointer, .bss cleared, then main(). The whole image (code, read-only data and the initial
 * values of .data) is already in RAM: the bitstream loads it into the block RAM. */
    .section .text.start, "ax"
    .global _start
_start:
    la    sp, __stack_top
    la    t0, __bss_start
    la    t1, __bss_end
1:  bgeu  t0, t1, 2f
    sw    zero, 0(t0)
    addi  t0, t0, 4
    j     1b
2:  call  main
3:  j     3b
