#!/usr/bin/env python3
"""Binary image -> hex file with one 32-bit little-endian word per line (the format the Chisel system loads)."""
import sys
data = open(sys.argv[1], "rb").read()
data += b"\0" * (-len(data) % 4)
with open(sys.argv[2], "w") as f:
    for k in range(0, len(data), 4):
        f.write("%08x\n" % int.from_bytes(data[k:k + 4], "little"))
print("%s: %d words (%d bytes)" % (sys.argv[2], len(data) // 4, len(data)))
