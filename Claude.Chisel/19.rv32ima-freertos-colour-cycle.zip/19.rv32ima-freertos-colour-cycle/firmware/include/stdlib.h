/* FreeRTOS includes <stdlib.h> only for NULL and size_t: this bare-metal system has no C library. */
#ifndef STDLIB_H
#define STDLIB_H
#include <stddef.h>
#endif
