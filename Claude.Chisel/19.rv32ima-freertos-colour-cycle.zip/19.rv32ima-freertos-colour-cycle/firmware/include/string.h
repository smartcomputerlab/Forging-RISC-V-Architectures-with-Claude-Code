/* The few C library functions FreeRTOS needs (no C library on this bare-metal system): see lib.c. */
#ifndef STRING_H
#define STRING_H
#include <stddef.h>
void * memset( void * s, int c, size_t n );
void * memcpy( void * d, const void * s, size_t n );
int memcmp( const void * a, const void * b, size_t n );
size_t strlen( const char * s );
#endif
