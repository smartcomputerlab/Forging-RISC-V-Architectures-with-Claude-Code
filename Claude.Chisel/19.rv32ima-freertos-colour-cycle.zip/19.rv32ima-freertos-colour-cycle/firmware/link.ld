/* One 32 KiB RAM at 0x80000000 (block RAM, loaded by the bitstream): code, data, FreeRTOS heap, then the stack
 * used by main() and, after the scheduler starts, by interrupts (__freertos_irq_stack_top). */
OUTPUT_ARCH( "riscv" )
ENTRY( _start )

MEMORY { RAM ( rwx ) : ORIGIN = 0x80000000, LENGTH = 32K }

__stack_size = 1024;

SECTIONS
{
    .text : { KEEP( *( .text.start ) ) *( .text .text.* ) } > RAM
    .rodata : ALIGN( 4 ) { *( .srodata .srodata.* .rodata .rodata.* ) } > RAM
    .data : ALIGN( 4 ) { *( .sdata .sdata.* .data .data.* ) } > RAM
    .bss ( NOLOAD ) : ALIGN( 4 ) {
        __bss_start = .;
        *( .sbss .sbss.* .bss .bss.* COMMON )
        . = ALIGN( 4 );
        __bss_end = .;
    } > RAM
    .stack ( NOLOAD ) : ALIGN( 16 ) {
        . += __stack_size;
        __stack_top = .;
    } > RAM
    __freertos_irq_stack_top = __stack_top;
    __image_end = ADDR( .bss );
}
