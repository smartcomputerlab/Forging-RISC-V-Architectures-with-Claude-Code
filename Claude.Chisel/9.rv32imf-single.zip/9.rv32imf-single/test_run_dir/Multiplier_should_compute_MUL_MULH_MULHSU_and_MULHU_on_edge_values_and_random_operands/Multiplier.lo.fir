FIRRTL version 1.2.0
circuit Multiplier :
  module Multiplier :
    input clock : Clock
    input reset : UInt<1>
    input io_fn : UInt<2> @[src/main/scala/rv32i/Multiplier.scala 17:14]
    input io_a : UInt<32> @[src/main/scala/rv32i/Multiplier.scala 17:14]
    input io_b : UInt<32> @[src/main/scala/rv32i/Multiplier.scala 17:14]
    output io_result : UInt<32> @[src/main/scala/rv32i/Multiplier.scala 17:14]

    node _aSigned_T = eq(io_fn, UInt<1>("h1")) @[src/main/scala/rv32i/Multiplier.scala 24:23]
    node _aSigned_T_1 = eq(io_fn, UInt<2>("h2")) @[src/main/scala/rv32i/Multiplier.scala 24:40]
    node aSigned = or(_aSigned_T, _aSigned_T_1) @[src/main/scala/rv32i/Multiplier.scala 24:31]
    node bSigned = eq(io_fn, UInt<1>("h1")) @[src/main/scala/rv32i/Multiplier.scala 25:23]
    node _aExt_T = bits(io_a, 31, 31) @[src/main/scala/rv32i/Multiplier.scala 26:36]
    node _aExt_T_1 = and(aSigned, _aExt_T) @[src/main/scala/rv32i/Multiplier.scala 26:29]
    node _aExt_T_2 = cat(_aExt_T_1, io_a) @[src/main/scala/rv32i/Multiplier.scala 26:20]
    node aExt = asSInt(_aExt_T_2) @[src/main/scala/rv32i/Multiplier.scala 26:48]
    node _bExt_T = bits(io_b, 31, 31) @[src/main/scala/rv32i/Multiplier.scala 27:36]
    node _bExt_T_1 = and(bSigned, _bExt_T) @[src/main/scala/rv32i/Multiplier.scala 27:29]
    node _bExt_T_2 = cat(_bExt_T_1, io_b) @[src/main/scala/rv32i/Multiplier.scala 27:20]
    node bExt = asSInt(_bExt_T_2) @[src/main/scala/rv32i/Multiplier.scala 27:48]
    node _product_T = mul(aExt, bExt) @[src/main/scala/rv32i/Multiplier.scala 28:23]
    node product = asUInt(_product_T) @[src/main/scala/rv32i/Multiplier.scala 28:31]
    node _io_result_T = eq(io_fn, UInt<1>("h0")) @[src/main/scala/rv32i/Multiplier.scala 30:26]
    node _io_result_T_1 = bits(product, 31, 0) @[src/main/scala/rv32i/Multiplier.scala 30:42]
    node _io_result_T_2 = bits(product, 63, 32) @[src/main/scala/rv32i/Multiplier.scala 30:58]
    node _io_result_T_3 = mux(_io_result_T, _io_result_T_1, _io_result_T_2) @[src/main/scala/rv32i/Multiplier.scala 30:19]
    io_result <= _io_result_T_3 @[src/main/scala/rv32i/Multiplier.scala 30:13]
