package rv32i

import chisel3.RawModule
import chisel3.stage.ChiselGeneratorAnnotation
import java.io.File
import scala.annotation.nowarn

/** One file per module (instead of a single file holding the whole design).
  *
  *  - `sbt "runMain rv32i.EmitSplit"`          : SystemVerilog, generated-split/sv/<top>/<Module>.sv
  *  - `sbt "runMain rv32i.EmitSplit verilog"`  : Verilog-2001, generated-split/v/<top>/<Module>.v
  *
  * With CIRCT firtool on the PATH it uses `--split-verilog`; otherwise the legacy Scala FIRRTL compiler with
  * `-e` (emit all modules), which writes one file per module as well.
  */
object EmitSplit {
  private def hasFirtool =
    sys.env.getOrElse("PATH", "").split(File.pathSeparator).exists(d => new File(d, "firtool").canExecute)

  def emit(top: String, gen: => RawModule, verilog: Boolean): Unit = {
    val kind = if (verilog) "v" else "sv"
    val dir  = s"generated-split/$kind/$top"
    if (hasFirtool) {
      val opts = Seq("-disable-all-randomization", "-strip-debug-info") ++
        (if (verilog) Seq("--lowering-options=disallowLocalVariables,disallowPackedArrays,noAlwaysComb") else Nil)
      (new circt.stage.ChiselStage).execute(
        Array("--target", if (verilog) "verilog" else "systemverilog", "--split-verilog", "--target-dir", dir),
        Seq(ChiselGeneratorAnnotation(() => gen)) ++ opts.map(circt.stage.FirtoolOption(_)))
    } else legacy(dir, gen, verilog)
    val files = Option(new File(dir).listFiles).getOrElse(Array.empty[File])
      .filter(f => f.getName.endsWith(".v") || f.getName.endsWith(".sv")).map(_.getName).sorted
    println(s"$top -> $dir: ${files.mkString(", ")}")
  }

  @nowarn("cat=deprecation") // legacy compiler, only the fallback
  private def legacy(dir: String, gen: => RawModule, verilog: Boolean): Unit =
    (new chisel3.stage.ChiselStage).execute(
      Array("--target-dir", dir, "-e", if (verilog) "verilog" else "sverilog"),
      Seq(ChiselGeneratorAnnotation(() => gen)))

  def main(args: Array[String]): Unit = {
    val verilog = args.headOption.exists(_.toLowerCase.startsWith("v"))
    emit("RV32IRCore", new RV32IRCore(CoreParams(), Lab1.regs), verilog)
    emit("RV32ITestWrapper", new RV32ITestWrapper(CoreParams(), "memory.hex", Lab1.regs), verilog)
  }
}
