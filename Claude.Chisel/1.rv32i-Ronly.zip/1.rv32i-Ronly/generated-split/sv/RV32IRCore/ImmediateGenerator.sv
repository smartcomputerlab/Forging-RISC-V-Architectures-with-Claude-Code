module ImmediateGenerator(
  input  [31:0] io_instr, // @[src/main/scala/rv32i/ImmediateGenerator.scala 7:14]
  output [31:0] io_imm // @[src/main/scala/rv32i/ImmediateGenerator.scala 7:14]
);
  wire [11:0] _io_imm_T_1 = io_instr[31:20]; // @[src/main/scala/rv32i/ImmediateGenerator.scala 11:30]
  assign io_imm = {{20{_io_imm_T_1[11]}},_io_imm_T_1}; // @[src/main/scala/rv32i/ImmediateGenerator.scala 11:49]
endmodule
