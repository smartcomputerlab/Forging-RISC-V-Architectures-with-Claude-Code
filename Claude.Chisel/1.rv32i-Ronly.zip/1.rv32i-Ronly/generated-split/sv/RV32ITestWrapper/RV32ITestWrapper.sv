module RV32ITestWrapper(
  input         clock,
  input         reset,
  output [31:0] io_debugPC, // @[src/main/scala/rv32i/RV32ITestWrapper.scala 11:14]
  output [31:0] io_debugX1, // @[src/main/scala/rv32i/RV32ITestWrapper.scala 11:14]
  output [31:0] io_debugX2, // @[src/main/scala/rv32i/RV32ITestWrapper.scala 11:14]
  output [31:0] io_debugX3, // @[src/main/scala/rv32i/RV32ITestWrapper.scala 11:14]
  output [31:0] io_debugX4, // @[src/main/scala/rv32i/RV32ITestWrapper.scala 11:14]
  output [31:0] io_trace_pc, // @[src/main/scala/rv32i/RV32ITestWrapper.scala 11:14]
  output [31:0] io_trace_inst, // @[src/main/scala/rv32i/RV32ITestWrapper.scala 11:14]
  output        io_trace_valid, // @[src/main/scala/rv32i/RV32ITestWrapper.scala 11:14]
  output [4:0]  io_trace_rdAddr, // @[src/main/scala/rv32i/RV32ITestWrapper.scala 11:14]
  output [31:0] io_trace_rdData // @[src/main/scala/rv32i/RV32ITestWrapper.scala 11:14]
);
  wire  core_clock; // @[src/main/scala/rv32i/RV32ITestWrapper.scala 20:20]
  wire  core_reset; // @[src/main/scala/rv32i/RV32ITestWrapper.scala 20:20]
  wire [31:0] core_io_imemAddr; // @[src/main/scala/rv32i/RV32ITestWrapper.scala 20:20]
  wire [31:0] core_io_imemInst; // @[src/main/scala/rv32i/RV32ITestWrapper.scala 20:20]
  wire [31:0] core_io_debugPC; // @[src/main/scala/rv32i/RV32ITestWrapper.scala 20:20]
  wire [31:0] core_io_debugX1; // @[src/main/scala/rv32i/RV32ITestWrapper.scala 20:20]
  wire [31:0] core_io_debugX2; // @[src/main/scala/rv32i/RV32ITestWrapper.scala 20:20]
  wire [31:0] core_io_debugX3; // @[src/main/scala/rv32i/RV32ITestWrapper.scala 20:20]
  wire [31:0] core_io_debugX4; // @[src/main/scala/rv32i/RV32ITestWrapper.scala 20:20]
  wire [31:0] core_io_trace_pc; // @[src/main/scala/rv32i/RV32ITestWrapper.scala 20:20]
  wire [31:0] core_io_trace_inst; // @[src/main/scala/rv32i/RV32ITestWrapper.scala 20:20]
  wire  core_io_trace_valid; // @[src/main/scala/rv32i/RV32ITestWrapper.scala 20:20]
  wire [4:0] core_io_trace_rdAddr; // @[src/main/scala/rv32i/RV32ITestWrapper.scala 20:20]
  wire [31:0] core_io_trace_rdData; // @[src/main/scala/rv32i/RV32ITestWrapper.scala 20:20]
  wire [31:0] imem_io_addr; // @[src/main/scala/rv32i/RV32ITestWrapper.scala 21:20]
  wire [31:0] imem_io_inst; // @[src/main/scala/rv32i/RV32ITestWrapper.scala 21:20]
  RV32IRCore core ( // @[src/main/scala/rv32i/RV32ITestWrapper.scala 20:20]
    .clock(core_clock),
    .reset(core_reset),
    .io_imemAddr(core_io_imemAddr),
    .io_imemInst(core_io_imemInst),
    .io_debugPC(core_io_debugPC),
    .io_debugX1(core_io_debugX1),
    .io_debugX2(core_io_debugX2),
    .io_debugX3(core_io_debugX3),
    .io_debugX4(core_io_debugX4),
    .io_trace_pc(core_io_trace_pc),
    .io_trace_inst(core_io_trace_inst),
    .io_trace_valid(core_io_trace_valid),
    .io_trace_rdAddr(core_io_trace_rdAddr),
    .io_trace_rdData(core_io_trace_rdData)
  );
  InstructionMemory imem ( // @[src/main/scala/rv32i/RV32ITestWrapper.scala 21:20]
    .io_addr(imem_io_addr),
    .io_inst(imem_io_inst)
  );
  assign io_debugPC = core_io_debugPC; // @[src/main/scala/rv32i/RV32ITestWrapper.scala 26:14]
  assign io_debugX1 = core_io_debugX1; // @[src/main/scala/rv32i/RV32ITestWrapper.scala 27:14]
  assign io_debugX2 = core_io_debugX2; // @[src/main/scala/rv32i/RV32ITestWrapper.scala 28:14]
  assign io_debugX3 = core_io_debugX3; // @[src/main/scala/rv32i/RV32ITestWrapper.scala 29:14]
  assign io_debugX4 = core_io_debugX4; // @[src/main/scala/rv32i/RV32ITestWrapper.scala 30:14]
  assign io_trace_pc = core_io_trace_pc; // @[src/main/scala/rv32i/RV32ITestWrapper.scala 31:14]
  assign io_trace_inst = core_io_trace_inst; // @[src/main/scala/rv32i/RV32ITestWrapper.scala 31:14]
  assign io_trace_valid = core_io_trace_valid; // @[src/main/scala/rv32i/RV32ITestWrapper.scala 31:14]
  assign io_trace_rdAddr = core_io_trace_rdAddr; // @[src/main/scala/rv32i/RV32ITestWrapper.scala 31:14]
  assign io_trace_rdData = core_io_trace_rdData; // @[src/main/scala/rv32i/RV32ITestWrapper.scala 31:14]
  assign core_clock = clock;
  assign core_reset = reset;
  assign core_io_imemInst = imem_io_inst; // @[src/main/scala/rv32i/RV32ITestWrapper.scala 24:20]
  assign imem_io_addr = core_io_imemAddr; // @[src/main/scala/rv32i/RV32ITestWrapper.scala 23:20]
endmodule
