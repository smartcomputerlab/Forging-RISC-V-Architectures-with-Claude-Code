module RV32IRCore(
  input         clock,
  input         reset,
  output [31:0] io_imemAddr, // @[src/main/scala/rv32i/RV32IRCore.scala 23:14]
  input  [31:0] io_imemInst, // @[src/main/scala/rv32i/RV32IRCore.scala 23:14]
  output [31:0] io_debugPC, // @[src/main/scala/rv32i/RV32IRCore.scala 23:14]
  output [31:0] io_debugX1, // @[src/main/scala/rv32i/RV32IRCore.scala 23:14]
  output [31:0] io_debugX2, // @[src/main/scala/rv32i/RV32IRCore.scala 23:14]
  output [31:0] io_debugX3, // @[src/main/scala/rv32i/RV32IRCore.scala 23:14]
  output [31:0] io_debugX4, // @[src/main/scala/rv32i/RV32IRCore.scala 23:14]
  output [31:0] io_trace_pc, // @[src/main/scala/rv32i/RV32IRCore.scala 23:14]
  output [31:0] io_trace_inst, // @[src/main/scala/rv32i/RV32IRCore.scala 23:14]
  output        io_trace_valid, // @[src/main/scala/rv32i/RV32IRCore.scala 23:14]
  output [4:0]  io_trace_rdAddr, // @[src/main/scala/rv32i/RV32IRCore.scala 23:14]
  output [31:0] io_trace_rdData // @[src/main/scala/rv32i/RV32IRCore.scala 23:14]
);
`ifdef RANDOMIZE_REG_INIT
  reg [31:0] _RAND_0;
`endif // RANDOMIZE_REG_INIT
  wire [31:0] decoder_io_instr; // @[src/main/scala/rv32i/RV32IRCore.scala 43:23]
  wire [4:0] decoder_io_rs1; // @[src/main/scala/rv32i/RV32IRCore.scala 43:23]
  wire [4:0] decoder_io_rs2; // @[src/main/scala/rv32i/RV32IRCore.scala 43:23]
  wire [4:0] decoder_io_rd; // @[src/main/scala/rv32i/RV32IRCore.scala 43:23]
  wire [3:0] decoder_io_aluOp; // @[src/main/scala/rv32i/RV32IRCore.scala 43:23]
  wire  decoder_io_aluSrc; // @[src/main/scala/rv32i/RV32IRCore.scala 43:23]
  wire  decoder_io_regWrite; // @[src/main/scala/rv32i/RV32IRCore.scala 43:23]
  wire  decoder_io_valid; // @[src/main/scala/rv32i/RV32IRCore.scala 43:23]
  wire [31:0] immGen_io_instr; // @[src/main/scala/rv32i/RV32IRCore.scala 46:22]
  wire [31:0] immGen_io_imm; // @[src/main/scala/rv32i/RV32IRCore.scala 46:22]
  wire  regFile_clock; // @[src/main/scala/rv32i/RV32IRCore.scala 50:23]
  wire  regFile_reset; // @[src/main/scala/rv32i/RV32IRCore.scala 50:23]
  wire [4:0] regFile_io_rs1; // @[src/main/scala/rv32i/RV32IRCore.scala 50:23]
  wire [4:0] regFile_io_rs2; // @[src/main/scala/rv32i/RV32IRCore.scala 50:23]
  wire [4:0] regFile_io_rd; // @[src/main/scala/rv32i/RV32IRCore.scala 50:23]
  wire [31:0] regFile_io_writeData; // @[src/main/scala/rv32i/RV32IRCore.scala 50:23]
  wire  regFile_io_writeEnable; // @[src/main/scala/rv32i/RV32IRCore.scala 50:23]
  wire [31:0] regFile_io_readData1; // @[src/main/scala/rv32i/RV32IRCore.scala 50:23]
  wire [31:0] regFile_io_readData2; // @[src/main/scala/rv32i/RV32IRCore.scala 50:23]
  wire [31:0] regFile_io_debugRead_1; // @[src/main/scala/rv32i/RV32IRCore.scala 50:23]
  wire [31:0] regFile_io_debugRead_2; // @[src/main/scala/rv32i/RV32IRCore.scala 50:23]
  wire [31:0] regFile_io_debugRead_3; // @[src/main/scala/rv32i/RV32IRCore.scala 50:23]
  wire [31:0] regFile_io_debugRead_4; // @[src/main/scala/rv32i/RV32IRCore.scala 50:23]
  wire [31:0] alu_io_a; // @[src/main/scala/rv32i/RV32IRCore.scala 55:19]
  wire [31:0] alu_io_b; // @[src/main/scala/rv32i/RV32IRCore.scala 55:19]
  wire [3:0] alu_io_op; // @[src/main/scala/rv32i/RV32IRCore.scala 55:19]
  wire [31:0] alu_io_y; // @[src/main/scala/rv32i/RV32IRCore.scala 55:19]
  reg [31:0] pc; // @[src/main/scala/rv32i/RV32IRCore.scala 38:19]
  wire [31:0] _pc_T_1 = pc + 32'h4; // @[src/main/scala/rv32i/RV32IRCore.scala 66:12]
  wire  writes = decoder_io_regWrite & decoder_io_rd != 5'h0; // @[src/main/scala/rv32i/RV32IRCore.scala 74:36]
  Decoder decoder ( // @[src/main/scala/rv32i/RV32IRCore.scala 43:23]
    .io_instr(decoder_io_instr),
    .io_rs1(decoder_io_rs1),
    .io_rs2(decoder_io_rs2),
    .io_rd(decoder_io_rd),
    .io_aluOp(decoder_io_aluOp),
    .io_aluSrc(decoder_io_aluSrc),
    .io_regWrite(decoder_io_regWrite),
    .io_valid(decoder_io_valid)
  );
  ImmediateGenerator immGen ( // @[src/main/scala/rv32i/RV32IRCore.scala 46:22]
    .io_instr(immGen_io_instr),
    .io_imm(immGen_io_imm)
  );
  RegisterFile regFile ( // @[src/main/scala/rv32i/RV32IRCore.scala 50:23]
    .clock(regFile_clock),
    .reset(regFile_reset),
    .io_rs1(regFile_io_rs1),
    .io_rs2(regFile_io_rs2),
    .io_rd(regFile_io_rd),
    .io_writeData(regFile_io_writeData),
    .io_writeEnable(regFile_io_writeEnable),
    .io_readData1(regFile_io_readData1),
    .io_readData2(regFile_io_readData2),
    .io_debugRead_1(regFile_io_debugRead_1),
    .io_debugRead_2(regFile_io_debugRead_2),
    .io_debugRead_3(regFile_io_debugRead_3),
    .io_debugRead_4(regFile_io_debugRead_4)
  );
  ALU alu ( // @[src/main/scala/rv32i/RV32IRCore.scala 55:19]
    .io_a(alu_io_a),
    .io_b(alu_io_b),
    .io_op(alu_io_op),
    .io_y(alu_io_y)
  );
  assign io_imemAddr = pc; // @[src/main/scala/rv32i/RV32IRCore.scala 39:15]
  assign io_debugPC = pc; // @[src/main/scala/rv32i/RV32IRCore.scala 40:15]
  assign io_debugX1 = regFile_io_debugRead_1; // @[src/main/scala/rv32i/RV32IRCore.scala 69:14]
  assign io_debugX2 = regFile_io_debugRead_2; // @[src/main/scala/rv32i/RV32IRCore.scala 70:14]
  assign io_debugX3 = regFile_io_debugRead_3; // @[src/main/scala/rv32i/RV32IRCore.scala 71:14]
  assign io_debugX4 = regFile_io_debugRead_4; // @[src/main/scala/rv32i/RV32IRCore.scala 72:14]
  assign io_trace_pc = pc; // @[src/main/scala/rv32i/RV32IRCore.scala 75:19]
  assign io_trace_inst = io_imemInst; // @[src/main/scala/rv32i/RV32IRCore.scala 76:19]
  assign io_trace_valid = decoder_io_valid; // @[src/main/scala/rv32i/RV32IRCore.scala 77:19]
  assign io_trace_rdAddr = writes ? decoder_io_rd : 5'h0; // @[src/main/scala/rv32i/RV32IRCore.scala 78:25]
  assign io_trace_rdData = writes ? alu_io_y : 32'h0; // @[src/main/scala/rv32i/RV32IRCore.scala 79:25]
  assign decoder_io_instr = io_imemInst; // @[src/main/scala/rv32i/RV32IRCore.scala 44:20]
  assign immGen_io_instr = io_imemInst; // @[src/main/scala/rv32i/RV32IRCore.scala 47:19]
  assign regFile_clock = clock;
  assign regFile_reset = reset;
  assign regFile_io_rs1 = decoder_io_rs1; // @[src/main/scala/rv32i/RV32IRCore.scala 51:18]
  assign regFile_io_rs2 = decoder_io_rs2; // @[src/main/scala/rv32i/RV32IRCore.scala 52:18]
  assign regFile_io_rd = decoder_io_rd; // @[src/main/scala/rv32i/RV32IRCore.scala 61:26]
  assign regFile_io_writeData = alu_io_y; // @[src/main/scala/rv32i/RV32IRCore.scala 62:26]
  assign regFile_io_writeEnable = decoder_io_regWrite; // @[src/main/scala/rv32i/RV32IRCore.scala 63:26]
  assign alu_io_a = regFile_io_readData1; // @[src/main/scala/rv32i/RV32IRCore.scala 56:13]
  assign alu_io_b = decoder_io_aluSrc ? immGen_io_imm : regFile_io_readData2; // @[src/main/scala/rv32i/RV32IRCore.scala 57:19]
  assign alu_io_op = decoder_io_aluOp; // @[src/main/scala/rv32i/RV32IRCore.scala 58:13]
  always @(posedge clock) begin
    if (reset) begin // @[src/main/scala/rv32i/RV32IRCore.scala 38:19]
      pc <= 32'h0; // @[src/main/scala/rv32i/RV32IRCore.scala 38:19]
    end else begin
      pc <= _pc_T_1; // @[src/main/scala/rv32i/RV32IRCore.scala 66:6]
    end
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (~reset & ~(~(decoder_io_regWrite & ~decoder_io_valid))) begin
          $fwrite(32'h80000002,
            "Assertion failed: register write by an unrecognised instruction\n    at RV32IRCore.scala:81 assert(!(decoder.io.regWrite && !decoder.io.valid), \"register write by an unrecognised instruction\")\n"
            ); // @[src/main/scala/rv32i/RV32IRCore.scala 81:9]
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif // SYNTHESIS
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (~reset & ~(~(decoder_io_regWrite & ~decoder_io_valid))) begin
          $fatal; // @[src/main/scala/rv32i/RV32IRCore.scala 81:9]
        end
    `ifdef STOP_COND
      end
    `endif
    `endif // SYNTHESIS
  end
// Register and memory initialization
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif
`ifndef RANDOM
`define RANDOM $random
`endif
`ifdef RANDOMIZE_MEM_INIT
  integer initvar;
`endif
`ifndef SYNTHESIS
`ifdef FIRRTL_BEFORE_INITIAL
`FIRRTL_BEFORE_INITIAL
`endif
initial begin
  `ifdef RANDOMIZE
    `ifdef INIT_RANDOM
      `INIT_RANDOM
    `endif
    `ifndef VERILATOR
      `ifdef RANDOMIZE_DELAY
        #`RANDOMIZE_DELAY begin end
      `else
        #0.002 begin end
      `endif
    `endif
`ifdef RANDOMIZE_REG_INIT
  _RAND_0 = {1{`RANDOM}};
  pc = _RAND_0[31:0];
`endif // RANDOMIZE_REG_INIT
  `endif // RANDOMIZE
end // initial
`ifdef FIRRTL_AFTER_INITIAL
`FIRRTL_AFTER_INITIAL
`endif
`endif // SYNTHESIS
endmodule
