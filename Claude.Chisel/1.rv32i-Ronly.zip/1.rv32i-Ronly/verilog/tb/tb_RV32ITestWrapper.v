// Testbench for the whole system RV32ITestWrapper.v (core + InstructionMemory holding memory.hex, the lab1 program).
// One vector per cycle: {pc, inst, valid[3:0], rdAddr[7:0], rdData, x1, x2, x3, x4}.
`timescale 1ns/1ps
`include "counts.vh"
module tb_RV32ITestWrapper;
  reg  [235:0] vec [0:`N_WRAPPER_TRACE-1];
  reg          clock, reset;
  wire [31:0]  debugPC, x1, x2, x3, x4, tPc, tInst, tData;
  wire         tValid;
  wire [4:0]   tRd;
  reg  [31:0]  ePc, eInst, eData, e1, e2, e3, e4;
  reg  [3:0]   eValid;
  reg  [7:0]   eRd;
  integer i, errors;

  RV32ITestWrapper dut (.clock(clock), .reset(reset), .io_debugPC(debugPC),
                        .io_debugX1(x1), .io_debugX2(x2), .io_debugX3(x3), .io_debugX4(x4),
                        .io_trace_pc(tPc), .io_trace_inst(tInst), .io_trace_valid(tValid), .io_trace_rdAddr(tRd),
                        .io_trace_rdData(tData));

  initial begin
    $readmemh("tb/vectors/wrapper_trace.hex", vec);
    errors = 0;
    clock = 0; reset = 1;
    #5 clock = 1; #5 clock = 0; reset = 0;
    for (i = 0; i < `N_WRAPPER_TRACE; i = i + 1) begin
      {ePc, eInst, eValid, eRd, eData, e1, e2, e3, e4} = vec[i];
      #1;
      $display("cycle %2d  pc=%h  inst=%h  valid=%b  x%0d <= %h   x1..x4 = %0d %0d %0d %0d",
               i, tPc, tInst, tValid, tRd, tData, x1, x2, x3, x4);
      if (tPc !== ePc || debugPC !== ePc || tInst !== eInst || tValid !== eValid[0] || tRd !== eRd[4:0] ||
          tData !== eData || x1 !== e1 || x2 !== e2 || x3 !== e3 || x4 !== e4) begin
        errors = errors + 1;
        $display("  ^ expected pc=%h inst=%h valid=%b x%0d <= %h   x1..x4 = %0d %0d %0d %0d",
                 ePc, eInst, eValid[0], eRd, eData, e1, e2, e3, e4);
      end
      #4 clock = 1; #5 clock = 0;
    end
    if (errors == 0) $display("PASS tb_RV32ITestWrapper: %0d cycles, x3 = %0d, x4 = %0d", `N_WRAPPER_TRACE, x3, x4);
    else             $display("FAIL tb_RV32ITestWrapper: %0d of %0d cycles wrong", errors, `N_WRAPPER_TRACE);
    $finish;
  end
endmodule
