// Testbench for the core RV32IRCore.v with its submodules (ALU, Decoder, ImmediateGenerator, RegisterFile).
// The instruction memory is in the testbench (core_prog.hex: 1,000 random instructions, valid and invalid).
// One vector per cycle (before the clock edge):
//   {pc, inst, valid[3:0], rdAddr[7:0], rdData, x1, x2, x3, x4}   (x1..x4: debug outputs, state before the write)
`timescale 1ns/1ps
`include "counts.vh"
module tb_RV32IRCore;
  reg  [235:0] vec  [0:`N_CORE_TRACE-1];
  reg  [31:0]  prog [0:1023];
  reg          clock, reset;
  wire [31:0]  imemAddr, imemInst, debugPC, x1, x2, x3, x4, tPc, tInst, tData;
  wire         tValid;
  wire [4:0]   tRd;
  reg  [31:0]  ePc, eInst, eData, e1, e2, e3, e4;
  reg  [3:0]   eValid;
  reg  [7:0]   eRd;
  integer i, errors;

  assign imemInst = (imemAddr[31:12] == 20'd0) ? prog[imemAddr[11:2]] : 32'd0;

  RV32IRCore dut (.clock(clock), .reset(reset), .io_imemAddr(imemAddr), .io_imemInst(imemInst),
                  .io_debugPC(debugPC), .io_debugX1(x1), .io_debugX2(x2), .io_debugX3(x3), .io_debugX4(x4),
                  .io_trace_pc(tPc), .io_trace_inst(tInst), .io_trace_valid(tValid), .io_trace_rdAddr(tRd),
                  .io_trace_rdData(tData));

  initial begin
    for (i = 0; i < 1024; i = i + 1) prog[i] = 32'd0;
    $readmemh("tb/vectors/core_prog.hex", prog);
    $readmemh("tb/vectors/core_trace.hex", vec);
    errors = 0;
    clock = 0; reset = 1;
    #5 clock = 1; #5 clock = 0; reset = 0;            // one reset edge: pc = 0, x1 = 10, x2 = 3
    for (i = 0; i < `N_CORE_TRACE; i = i + 1) begin
      {ePc, eInst, eValid, eRd, eData, e1, e2, e3, e4} = vec[i];
      #1;
      if (tPc !== ePc || debugPC !== ePc || tInst !== eInst || tValid !== eValid[0] || tRd !== eRd[4:0] ||
          tData !== eData || x1 !== e1 || x2 !== e2 || x3 !== e3 || x4 !== e4) begin
        errors = errors + 1;
        if (errors <= 10)
          $display("tb_RV32IRCore cycle %0d: pc=%h inst=%h valid=%b x%0d=%h (x1..x4 %h %h %h %h), expected pc=%h inst=%h valid=%b x%0d=%h (%h %h %h %h)",
                   i, tPc, tInst, tValid, tRd, tData, x1, x2, x3, x4, ePc, eInst, eValid[0], eRd, eData, e1, e2, e3, e4);
      end
      #4 clock = 1; #5 clock = 0;
    end
    if (errors == 0) $display("PASS tb_RV32IRCore: %0d cycles", `N_CORE_TRACE);
    else             $display("FAIL tb_RV32IRCore: %0d of %0d cycles wrong", errors, `N_CORE_TRACE);
    $finish;
  end
endmodule
