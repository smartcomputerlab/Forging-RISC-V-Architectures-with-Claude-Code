// Testbench for Decoder.v alone (combinational).
// Vector: {instr[31:0], rs1[7:0], rs2[7:0], rd[7:0], aluOp[3:0], {1'b0, aluSrc, regWrite, valid}}.
`timescale 1ns/1ps
`include "counts.vh"
module tb_Decoder;
  reg  [63:0] vec [0:`N_DECODER-1];
  reg  [31:0] instr;
  reg  [7:0]  eRs1, eRs2, eRd;
  reg  [3:0]  eOp, eFlags;
  wire [4:0]  rs1, rs2, rd;
  wire [3:0]  aluOp;
  wire        aluSrc, regWrite, valid;
  integer i, errors;

  Decoder dut (.io_instr(instr), .io_rs1(rs1), .io_rs2(rs2), .io_rd(rd), .io_aluOp(aluOp),
               .io_aluSrc(aluSrc), .io_regWrite(regWrite), .io_valid(valid));

  initial begin
    $readmemh("tb/vectors/decoder.hex", vec);
    errors = 0;
    for (i = 0; i < `N_DECODER; i = i + 1) begin
      {instr, eRs1, eRs2, eRd, eOp, eFlags} = vec[i];
      #1;
      if (rs1 !== eRs1[4:0] || rs2 !== eRs2[4:0] || rd !== eRd[4:0] || aluOp !== eOp ||
          {aluSrc, regWrite, valid} !== eFlags[2:0]) begin
        errors = errors + 1;
        if (errors <= 10)
          $display("tb_Decoder vector %0d: instr=%h -> rs1=%0d rs2=%0d rd=%0d op=%0d src/we/valid=%b%b%b, expected %0d %0d %0d %0d %b",
                   i, instr, rs1, rs2, rd, aluOp, aluSrc, regWrite, valid, eRs1, eRs2, eRd, eOp, eFlags[2:0]);
      end
    end
    if (errors == 0) $display("PASS tb_Decoder: %0d vectors", `N_DECODER);
    else             $display("FAIL tb_Decoder: %0d of %0d vectors wrong", errors, `N_DECODER);
    $finish;
  end
endmodule
