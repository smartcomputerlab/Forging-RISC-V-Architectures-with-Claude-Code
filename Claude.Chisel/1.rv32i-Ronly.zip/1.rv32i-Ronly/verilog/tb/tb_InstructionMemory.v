// Testbench for InstructionMemory.v alone (combinational ROM holding memory.hex). Vector: {addr[31:0], inst[31:0]}.
`timescale 1ns/1ps
`include "counts.vh"
module tb_InstructionMemory;
  reg  [63:0] vec [0:`N_IMEM-1];
  reg  [31:0] addr, expInst;
  wire [31:0] inst;
  integer i, errors;

  InstructionMemory dut (.io_addr(addr), .io_inst(inst));

  initial begin
    $readmemh("tb/vectors/imem.hex", vec);
    errors = 0;
    for (i = 0; i < `N_IMEM; i = i + 1) begin
      {addr, expInst} = vec[i];
      #1;
      if (inst !== expInst) begin
        errors = errors + 1;
        if (errors <= 10) $display("tb_InstructionMemory vector %0d: addr=%h -> %h, expected %h", i, addr, inst, expInst);
      end
    end
    if (errors == 0) $display("PASS tb_InstructionMemory: %0d vectors", `N_IMEM);
    else             $display("FAIL tb_InstructionMemory: %0d of %0d vectors wrong", errors, `N_IMEM);
    $finish;
  end
endmodule
