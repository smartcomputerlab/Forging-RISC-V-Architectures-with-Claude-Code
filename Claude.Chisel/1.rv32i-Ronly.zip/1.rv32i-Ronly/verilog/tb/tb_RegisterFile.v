// Testbench for RegisterFile.v alone (clocked, synchronous reset; reset values of the lab1 build: x1 = 10, x2 = 3).
// One vector per cycle: {we[3:0], rd[7:0], wdata[31:0], rs1[7:0], rs2[7:0], expRead1[31:0], expRead2[31:0]}.
// The reads are checked before the clock edge (they show the state before this cycle's write).
`timescale 1ns/1ps
`include "counts.vh"
module tb_RegisterFile;
  reg  [123:0] vec [0:`N_REGFILE-1];
  reg          clock, reset, we;
  reg  [4:0]   rd, rs1, rs2;
  reg  [31:0]  wdata, e1, e2;
  reg  [3:0]   weV;
  reg  [7:0]   rdV, rs1V, rs2V;
  wire [31:0]  r1, r2;
  integer i, errors;

  RegisterFile dut (.clock(clock), .reset(reset), .io_rs1(rs1), .io_rs2(rs2), .io_rd(rd), .io_writeData(wdata),
                    .io_writeEnable(we), .io_readData1(r1), .io_readData2(r2));

  initial begin
    $readmemh("tb/vectors/regfile.hex", vec);
    errors = 0;
    clock = 0; reset = 1; we = 0; rd = 0; rs1 = 0; rs2 = 0; wdata = 0;
    #5 clock = 1; #5 clock = 0; reset = 0;            // one reset edge
    for (i = 0; i < `N_REGFILE; i = i + 1) begin
      {weV, rdV, wdata, rs1V, rs2V, e1, e2} = vec[i];
      we = weV[0]; rd = rdV[4:0]; rs1 = rs1V[4:0]; rs2 = rs2V[4:0];
      #1;
      if (r1 !== e1 || r2 !== e2) begin
        errors = errors + 1;
        if (errors <= 10) $display("tb_RegisterFile cycle %0d: x%0d=%h x%0d=%h, expected %h %h", i, rs1, r1, rs2, r2, e1, e2);
      end
      #4 clock = 1; #5 clock = 0;
    end
    if (errors == 0) $display("PASS tb_RegisterFile: %0d cycles", `N_REGFILE);
    else             $display("FAIL tb_RegisterFile: %0d of %0d cycles wrong", errors, `N_REGFILE);
    $finish;
  end
endmodule
