// Testbench for ALU.v alone (combinational). Vector: {op[3:0], a[31:0], b[31:0], y[31:0]} per line.
`timescale 1ns/1ps
`include "counts.vh"
module tb_ALU;
  reg  [99:0] vec [0:`N_ALU-1];
  reg  [3:0]  op;
  reg  [31:0] a, b, expY;
  wire [31:0] y;
  integer i, errors;

  ALU dut (.io_a(a), .io_b(b), .io_op(op), .io_y(y));

  initial begin
    $readmemh("tb/vectors/alu.hex", vec);
    errors = 0;
    for (i = 0; i < `N_ALU; i = i + 1) begin
      {op, a, b, expY} = vec[i];
      #1;
      if (y !== expY) begin
        errors = errors + 1;
        if (errors <= 10) $display("tb_ALU vector %0d: op=%0d a=%h b=%h -> y=%h, expected %h", i, op, a, b, y, expY);
      end
    end
    if (errors == 0) $display("PASS tb_ALU: %0d vectors", `N_ALU);
    else             $display("FAIL tb_ALU: %0d of %0d vectors wrong", errors, `N_ALU);
    $finish;
  end
endmodule
