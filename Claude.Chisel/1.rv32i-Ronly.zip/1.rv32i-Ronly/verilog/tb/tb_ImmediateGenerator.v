// Testbench for ImmediateGenerator.v alone (combinational). Vector: {instr[31:0], imm[31:0]}.
`timescale 1ns/1ps
`include "counts.vh"
module tb_ImmediateGenerator;
  reg  [63:0] vec [0:`N_IMM-1];
  reg  [31:0] instr, expImm;
  wire [31:0] imm;
  integer i, errors;

  ImmediateGenerator dut (.io_instr(instr), .io_imm(imm));

  initial begin
    $readmemh("tb/vectors/imm.hex", vec);
    errors = 0;
    for (i = 0; i < `N_IMM; i = i + 1) begin
      {instr, expImm} = vec[i];
      #1;
      if (imm !== expImm) begin
        errors = errors + 1;
        if (errors <= 10) $display("tb_ImmediateGenerator vector %0d: instr=%h -> imm=%h, expected %h", i, instr, imm, expImm);
      end
    end
    if (errors == 0) $display("PASS tb_ImmediateGenerator: %0d vectors", `N_IMM);
    else             $display("FAIL tb_ImmediateGenerator: %0d of %0d vectors wrong", errors, `N_IMM);
    $finish;
  end
endmodule
