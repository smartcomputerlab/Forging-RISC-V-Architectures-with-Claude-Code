package rv32i

/** Throw (projectile) demo for the iCESugar-Pro system with the 5-stage pipelined RV32IMF core (Stage 10).
  * An object is thrown from the ground with speed V (m/s) at angle A (degrees above the horizontal), on flat ground,
  * without air drag, with g = 9.81 m/s^2. In an endless loop:
  *
  *   V (m/s) = 20          (typed on the UART terminal, echoed; up to 4 digits and 2 decimals; Enter ends it)
  *   A (deg) = 45
  *   distance  R = 40.77 m     R = V^2 sin(2A) / g = 2 V^2 sin(A) cos(A) / g
  *   time      T = 2.88 s      T = 2 V sin(A) / g
  *   height    H = 10.19 m     H = V^2 sin(A)^2 / (2 g)
  *
  * All the arithmetic is IEEE 754 single precision (F extension). sin and cos are polynomials (Taylor series to x^9
  * and x^10, Horner's scheme) on [0, pi/4]: the angle is reduced exactly in integer hundredths of a degree, with
  * sin(A) = cos(90 - A) and cos(A) = sin(90 - A) above 45 degrees. Results are printed rounded to 2 decimals (the exact
  * value of the float, rounded half up, without floating point: see `p2`).
  * Input: digits, at most one '.', at most 4 digits before it and 2 after; Backspace (0x08 or 0x7f) corrects, other
  * keys are ignored, Enter with no digit is ignored. A above 90 is refused with a message.
  * RGB LED: off until the first result; green for a result, blue when A = 45 (the angle of the longest throw for a
  * given V), red when A is out of range.
  */
object FpgaThrowDemo {
  import FpgaMap._
  val Banner   = "\r\nRV32IMF 5-stage pipeline: throw distance on flat ground, no air drag, g = 9.81 m/s^2\r\n"
  val PromptV  = "V (m/s) = "
  val PromptA  = "A (deg) = "
  val LabelR   = "distance  R = "
  val LabelT   = "time      T = "
  val LabelH   = "height    H = "
  val Meters   = " m\r\n"
  val Seconds  = " s\r\n"
  val BadAngle = "A must be 0 to 90 degrees\r\n"
  val MaxInt = 4; val MaxFrac = 2
  val LedRed = 1; val LedGreen = 2; val LedBlue = 4

  // ---- single-precision constants (the program loads exactly these bit patterns)
  val G: Float      = 9.81f
  val DegH: Float   = (math.Pi / 18000.0).toFloat           // radians per hundredth of a degree
  val SinC: Seq[Float] = Seq(-1.0 / 6, 1.0 / 120, -1.0 / 5040, 1.0 / 362880).map(_.toFloat)              // x^3 .. x^9
  val CosC: Seq[Float] = Seq(-1.0 / 2, 1.0 / 24, -1.0 / 720, 1.0 / 40320, -1.0 / 3628800).map(_.toFloat) // x^2 .. x^10

  // ---- the same computation in Scala Float (IEEE single, round to nearest even), in the same order as the program
  def sinp(x: Float): Float = { val x2 = x * x; var p = SinC(3); for (c <- SinC.reverse.tail) p = p * x2 + c; (p * x2 + 1.0f) * x }
  def cosp(x: Float): Float = { val x2 = x * x; var p = CosC(4); for (c <- CosC.reverse.tail) p = p * x2 + c; p * x2 + 1.0f }
  /** (R, T, H) for V and A in hundredths (A100 <= 9000). */
  def compute(v100: Int, a100: Int): (Float, Float, Float) = {
    val v = v100.toFloat / 100.0f
    val (s, c) =
      if (a100 <= 4500) { val x = a100.toFloat * DegH; (sinp(x), cosp(x)) }
      else { val x = (9000 - a100).toFloat * DegH; (cosp(x), sinp(x)) }
    val v2 = v * v
    val sc = s * c
    val r = v2 * (sc + sc) / G
    val vs = v * s
    val t = (vs + vs) / G
    val h = v2 * (s * s) / (G + G)
    (r, t, h)
  }
  /** A non-negative float rounded half up to 2 decimals, as the program prints it. */
  def fmt2(f: Float): String = new java.math.BigDecimal(f.toDouble).setScale(2, java.math.RoundingMode.HALF_UP).toPlainString
  /** The exact text printed for one (V, A), after the echo of A and its CR LF. */
  def transcript(v100: Int, a100: Int): String =
    if (a100 > 9000) BadAngle
    else { val (r, t, h) = compute(v100, a100); LabelR + fmt2(r) + Meters + LabelT + fmt2(t) + Seconds + LabelH + fmt2(h) + Meters }
  def led(a100: Int): Int = if (a100 > 9000) LedRed else if (a100 == 4500) LedBlue else LedGreen

  private val strings = Seq(Banner, PromptV, PromptA, LabelR, LabelT, LabelH, Meters, Seconds, BadAngle)
  private val at: Map[String, Long] =
    strings.scanLeft(RamBase)((p, s) => p + ((s.length + 1 + 3) & ~3)).zip(strings).map(_.swap).toMap
  private val Buf = RamBase + 0x200                     // digits of a number being printed

  def apply(): Asm = {
    val a = new Asm(RomBase)
    val io = 10; val str = 11; val ch = 12; val t = 13; val t2 = 5; val led = 14; val ten = 9
    val v = 20; val nf = 21; val ni = 22; val dot = 23  // getnum: value, digits after / before the point, '.' seen
    val v100 = 24; val a100 = 25; val n = 26
    val b = 27; val e = 28; val m = 29; val s = 30; val q = 31; val pv = 18; val p = 19   // p2, pdec
    // link registers: x1 putc, x2 puts, x3 getnum, x4 pdec, x6 crlf, x7 sinp / cosp, x8 p2
    // float registers: f1 = 1.0, f3..f6 sin coefficients, f7..f11 cos coefficients, f20 = 100, f21 = rad per 0.01 deg,
    //   f22 = g, f23 = 2g; f12 = x (argument), f13 = result, f14 = x^2, f15 = Horner sum; f16 = V, f17 = sin A,
    //   f18 = cos A, f19 = V^2, f24 = temporary, f31 = value to print
    a.lui(io, IoBase >> 12)
    a.sw(0, Led, io)                                    // LED off until the first result
    for (str0 <- strings) {                             // strings are built in RAM with li / sw (the ROM is fetch-only)
      a.li(str, at(str0))
      (str0.getBytes("US-ASCII").toSeq :+ 0.toByte).grouped(4).zipWithIndex.foreach { case (g, k) =>
        a.li(t, g.zipWithIndex.map { case (by, j) => (by.toLong & 0xff) << (8 * j) }.sum); a.sw(t, 4L * k, str)
      }
    }
    a.li(ten, 10)
    a.fli(1, 1.0f, t)
    SinC.zipWithIndex.foreach { case (c, k) => a.fli(3 + k, c, t) }
    CosC.zipWithIndex.foreach { case (c, k) => a.fli(7 + k, c, t) }
    a.fli(20, 100.0f, t); a.fli(21, DegH, t); a.fli(22, G, t); a.fadd(23, 22, 22, Rm.RNE)
    def puts(x: String): Unit = { a.li(str, at(x)); a.jal(2, "puts") }
    puts(Banner)

    a.label("main")
    puts(PromptV); a.jal(3, "getnum"); a.mv(v100, v)
    puts(PromptA); a.jal(3, "getnum"); a.mv(a100, v)
    a.li(t, 9000); a.bgeu(t, a100, "angle_ok")
    a.li(led, LedRed); a.sw(led, Led, io)
    puts(BadAngle); a.jal(0, "main")
    a.label("angle_ok")
    // ---- V = V100 / 100
    a.fcvtsw(16, v100, Rm.RNE); a.fdiv(16, 16, 20, Rm.RNE)
    // ---- sin A, cos A: reduced to [0, 45] degrees in integer hundredths
    a.li(t, 4500); a.bltu(t, a100, "above45")
    a.fcvtsw(12, a100, Rm.RNE); a.fmul(12, 12, 21, Rm.RNE)                 // x = A100 * (pi / 18000)
    a.jal(7, "sinp"); a.fsgnj(17, 13, 13)
    a.jal(7, "cosp"); a.fsgnj(18, 13, 13)
    a.jal(0, "trig_done")
    a.label("above45")
    a.li(t, 9000); a.sub(n, t, a100)
    a.fcvtsw(12, n, Rm.RNE); a.fmul(12, 12, 21, Rm.RNE)                    // x = (9000 - A100) * (pi / 18000)
    a.jal(7, "cosp"); a.fsgnj(17, 13, 13)                                  // sin A = cos(90 - A)
    a.jal(7, "sinp"); a.fsgnj(18, 13, 13)                                  // cos A = sin(90 - A)
    a.label("trig_done")
    a.fmul(19, 16, 16, Rm.RNE)                                             // V^2
    // ---- R = V^2 * (2 sin A cos A) / g
    a.fmul(24, 17, 18, Rm.RNE); a.fadd(24, 24, 24, Rm.RNE); a.fmul(24, 19, 24, Rm.RNE); a.fdiv(31, 24, 22, Rm.RNE)
    puts(LabelR); a.jal(8, "p2"); puts(Meters)
    // ---- T = 2 V sin A / g
    a.fmul(24, 16, 17, Rm.RNE); a.fadd(24, 24, 24, Rm.RNE); a.fdiv(31, 24, 22, Rm.RNE)
    puts(LabelT); a.jal(8, "p2"); puts(Seconds)
    // ---- H = V^2 sin^2 A / (2 g)
    a.fmul(24, 17, 17, Rm.RNE); a.fmul(24, 19, 24, Rm.RNE); a.fdiv(31, 24, 23, Rm.RNE)
    puts(LabelH); a.jal(8, "p2"); puts(Meters)
    // ---- LED: blue for A = 45 degrees, green otherwise
    a.li(led, LedGreen); a.li(t, 4500); a.bne(a100, t, "setled"); a.li(led, LedBlue)
    a.label("setled")
    a.sw(led, Led, io)
    a.jal(0, "main")

    // ---- sinp: f13 = x * (1 + x2 (S3 + x2 (S5 + x2 (S7 + x2 S9)))), x = f12; return with x7
    a.label("sinp")
    a.fmul(14, 12, 12, Rm.RNE)
    a.fsgnj(15, 6, 6)
    for (k <- Seq(5, 4, 3)) { a.fmul(15, 15, 14, Rm.RNE); a.fadd(15, 15, k, Rm.RNE) }
    a.fmul(15, 15, 14, Rm.RNE); a.fadd(15, 15, 1, Rm.RNE)
    a.fmul(13, 15, 12, Rm.RNE)
    a.jalr(0, 7, 0)
    // ---- cosp: f13 = 1 + x2 (C2 + x2 (C4 + x2 (C6 + x2 (C8 + x2 C10)))), x = f12; return with x7
    a.label("cosp")
    a.fmul(14, 12, 12, Rm.RNE)
    a.fsgnj(15, 11, 11)
    for (k <- Seq(10, 9, 8, 7)) { a.fmul(15, 15, 14, Rm.RNE); a.fadd(15, 15, k, Rm.RNE) }
    a.fmul(15, 15, 14, Rm.RNE); a.fadd(13, 15, 1, Rm.RNE)
    a.jalr(0, 7, 0)

    // ---- p2: print f31 (0 <= f31 < 2^24) rounded half up to 2 decimals, without floating point: the value is
    //      m * 2^-s (m: 24-bit significand, s = 150 - exponent), so q = (100 m + 2^(s-1)) >> s = round(100 * value).
    //      Return with x8.
    a.label("p2")
    a.fmvxw(b, 31)
    a.li(q, 0); a.beq(b, 0, "p2q")                      // +0.0
    a.srli(e, b, 23); a.andi(e, e, 255)
    a.li(t, 0x7fffff); a.and(m, b, t); a.li(t, 0x800000); a.or(m, m, t)
    a.li(t, 150); a.sub(s, t, e)
    a.li(t, 32); a.bgeu(s, t, "p2q")                    // value < 2^-8: rounds to 0.00
    a.li(t, 100); a.mul(q, m, t)                        // < 2^31
    a.beq(s, 0, "p2q")                                  // value is an integer >= 2^23: no rounding
    a.addi(t, s, -1); a.li(t2, 1); a.sll(t2, t2, t); a.add(q, q, t2); a.srl(q, q, s)
    a.label("p2q")
    a.li(t, 100); a.divu(pv, q, t); a.remu(q, q, t)
    a.jal(4, "pdec")                                    // integer part
    a.li(ch, '.'); a.jal(1, "putc")
    a.divu(ch, q, ten); a.addi(ch, ch, '0'); a.jal(1, "putc")
    a.remu(ch, q, ten); a.addi(ch, ch, '0'); a.jal(1, "putc")
    a.jalr(0, 8, 0)

    // ---- pdec: print pv (unsigned) in decimal: digits with REMU / DIVU into Buf, then sent in reverse; return with x4
    a.label("pdec")
    a.li(p, Buf)
    a.label("pd_div")
    a.remu(t, pv, ten); a.divu(pv, pv, ten)
    a.addi(t, t, '0'); a.sb(t, 0, p); a.addi(p, p, 1)
    a.bne(pv, 0, "pd_div")
    a.label("pd_out")
    a.addi(p, p, -1); a.lbu(ch, 0, p); a.jal(1, "putc")
    a.li(t, Buf); a.bne(p, t, "pd_out")
    a.jalr(0, 4, 0)

    // ---- getnum: read a decimal number (up to MaxInt digits, optionally '.' and up to MaxFrac digits), echoing it;
    //      returns v = the number in hundredths. Return with x3.
    a.label("getnum")
    a.li(v, 0); a.li(ni, 0); a.li(nf, 0); a.li(dot, 0)
    a.label("gwait")
    a.lw(t, UartStat, io); a.andi(t, t, 2); a.beq(t, 0, "gwait")
    a.lw(ch, UartRx, io)
    a.li(t, 13); a.beq(ch, t, "genter")
    a.li(t, 10); a.beq(ch, t, "genter")
    a.li(t, 8); a.beq(ch, t, "gback")
    a.li(t, 127); a.beq(ch, t, "gback")
    a.li(t, '.'); a.beq(ch, t, "gdot")
    a.addi(t, ch, -'0'); a.sltiu(t2, t, 10); a.beq(t2, 0, "gwait")       // not a digit: ignore
    a.bne(dot, 0, "gfrac")
    a.sltiu(t2, ni, MaxInt); a.beq(t2, 0, "gwait")                       // enough digits before the point
    a.addi(ni, ni, 1); a.jal(0, "gdigit")
    a.label("gfrac")
    a.sltiu(t2, nf, MaxFrac); a.beq(t2, 0, "gwait")                      // enough decimals
    a.addi(nf, nf, 1)
    a.label("gdigit")
    a.mul(v, v, ten); a.add(v, v, t)                                     // v = 10 v + digit
    a.jal(1, "putc"); a.jal(0, "gwait")
    a.label("gdot")
    a.bne(dot, 0, "gwait")                                               // a second '.': ignore
    a.li(dot, 1); a.jal(1, "putc"); a.jal(0, "gwait")
    a.label("gback")                                                     // remove the last decimal, the '.', or a digit
    a.beq(nf, 0, "gb_dot")
    a.addi(nf, nf, -1); a.divu(v, v, ten); a.jal(0, "gb_echo")
    a.label("gb_dot")
    a.beq(dot, 0, "gb_int")
    a.li(dot, 0); a.jal(0, "gb_echo")
    a.label("gb_int")
    a.beq(ni, 0, "gwait")                                                // nothing to remove
    a.addi(ni, ni, -1); a.divu(v, v, ten)
    a.label("gb_echo")
    a.li(ch, 8); a.jal(1, "putc"); a.li(ch, ' '); a.jal(1, "putc"); a.li(ch, 8); a.jal(1, "putc")   // "\b \b"
    a.jal(0, "gwait")
    a.label("genter")
    a.add(t, ni, nf); a.beq(t, 0, "gwait")                               // no digit yet
    a.li(t, 1); a.beq(nf, t, "gx10")                                     // scale to hundredths
    a.bne(nf, 0, "gscaled")
    a.mul(v, v, ten)
    a.label("gx10")
    a.mul(v, v, ten)
    a.label("gscaled")
    a.jal(6, "crlf"); a.jalr(0, 3, 0)

    // ---- crlf: send CR LF; return with x6
    a.label("crlf")
    a.li(ch, 13); a.jal(1, "putc"); a.li(ch, 10); a.jal(1, "putc")
    a.jalr(0, 6, 0)
    // ---- putc: send x12 (waits until the transmitter is ready); return with x1
    a.label("putc")
    a.lw(t, UartStat, io); a.andi(t, t, 1); a.beq(t, 0, "putc")
    a.sw(ch, UartTx, io)
    a.jalr(0, 1, 0)
    // ---- puts: send the zero-terminated string at x11; return with x2
    a.label("puts")
    a.lbu(ch, 0, str); a.beq(ch, 0, "puts_end")
    a.jal(1, "putc")
    a.addi(str, str, 1)
    a.jal(0, "puts")
    a.label("puts_end")
    a.jalr(0, 2, 0)
    a
  }
}

/** Writes fpga/memory.hex (one word per line, with the disassembly as a comment) and fpga/memory.lst.
  * Run: sbt "runMain rv32i.EmitThrowDemo"
  */
object EmitThrowDemo extends App {
  import java.nio.file.{Files, Paths}
  val prog = FpgaThrowDemo().words
  require(prog.length <= FpgaMap.RomWords, s"${prog.length} words")
  val hex = prog.zipWithIndex.map { case (w, k) => f"$w%08x   # 0x${4 * k}%03x: ${Disasm(w, FpgaMap.RomBase + 4L * k)}" }
  Files.createDirectories(Paths.get("fpga"))
  Files.write(Paths.get("fpga", "memory.hex"), (hex.mkString("\n") + "\n").getBytes("UTF-8"))
  Files.write(Paths.get("fpga", "memory.lst"), Disasm.listing(prog, FpgaMap.RomBase).getBytes("UTF-8"))
  println(s"throw demo: ${prog.length} words of ${FpgaMap.RomWords}; fpga/memory.hex, fpga/memory.lst")
}
