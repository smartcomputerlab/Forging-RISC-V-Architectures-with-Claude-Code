package rv32i

/** Pi demo for the iCESugar-Pro system with the 5-stage pipelined RV32IMF core (Stage 10). In an endless loop:
  *
  *   n terms = 1000                    (typed on the UART terminal, echoed; Enter ends the number)
  *   Leibniz: 3.1405926  0x4048ff78    4 * sum_{k=0}^{n-1} (-1)^k / (2k+1)            FDIV, FADD, FSUB, FMUL
  *   Basel:   3.1406384  0x40490038    sqrt(6 * sum_{k=1}^{n} 1/k^2)                  FCVT.S.W, FMUL, FDIV, FSQRT
  *   Machin:  3.1415927  0x40490fdb    16 atan(1/5) - 4 atan(1/239), min(n, 12) terms  FMUL, FDIV, FMSUB
  *   pi:      3.1415927  0x40490fdb    the float nearest to pi, for comparison
  *
  * Everything is computed in IEEE 754 single precision (binary32, round to nearest even), in the order written above.
  * n is 0..999999 (up to 6 digits; further digits are ignored); Backspace removes the last digit; other keys are
  * ignored; Enter with no digit is ignored.
  *
  * Each result is printed exactly rounded to 7 decimals, with its bit pattern: the float's bits are taken with
  * FMV.X.W, and its value m * 2^(e-150) (m = 24-bit significand) is scaled by 10^7 in 64-bit integer arithmetic
  * (MUL, MULHU, shifts), rounded half up, and printed with DIVU/REMU. (Valid for values below 256.)
  *
  * RGB LED: blue while computing, green when the results are printed; off until the first number.
  */
object FpgaPiDemo {
  import FpgaMap._
  val Banner = "\r\nRV32IMF 5-stage pipeline: pi in single precision\r\n"
  val Prompt = "n terms = "
  val Labels = Seq("Leibniz: ", "Basel:   ", "Machin:  ", "pi:      ")
  val MaxDigits = 6
  val MachinTerms = 12
  private val AtBanner = RamBase; private val AtPrompt = RamBase + 0x40
  private def atLabel(i: Int) = RamBase + 0x50 + 0x10 * i

  def apply(): Asm = {
    val a = new Asm(RomBase)
    // x registers
    val io = 10; val str = 11; val ch = 12; val t = 13; val led = 14; val t2 = 15
    val v = 20; val nd = 22                                   // getnum
    val n = 24; val k = 25; val mt = 23                       // terms, loop counter, Machin terms
    val b = 16; val e = 17; val m = 18; val lo = 19; val hi = 21; val s = 28; val q = 26; val rl = 27   // pfloat
    val pv = 29; val dv = 30; val lead = 31                   // pdec / phex
    // link registers: x1 putc, x2 puts, x3 getnum, x4 pdec, x6 crlf, x7 atan, x8 pfloat, x9 phex
    // f registers: f0 = 0, f1 = 1, f2 = 2, f7 = 4, f8 = 6, f9 = 16; f3 sum, f4 denominator / k, f5 term,
    //              f10 result, f11 atan argument, f12 atan result, f13 power, f14 x^2, f15 atan(1/5), f16 temp

    a.lui(io, IoBase >> 12)
    a.sw(0, Led, io)                                          // LED off until the first number
    def store(text: String, at: Long): Unit = {               // strings are built in RAM (no loads from the ROM)
      a.li(str, at)
      (text.getBytes("US-ASCII").toSeq :+ 0.toByte).grouped(4).zipWithIndex.foreach { case (g, kk) =>
        a.li(t, g.zipWithIndex.map { case (by, j) => (by.toLong & 0xff) << (8 * j) }.sum); a.sw(t, 4L * kk, str)
      }
    }
    store(Banner, AtBanner); store(Prompt, AtPrompt)
    Labels.zipWithIndex.foreach { case (l, i) => store(l, atLabel(i)) }
    a.fcvtsw(0, 0, Rm.RNE)                                    // f0 = 0.0
    a.fli(1, 1.0f, t); a.fli(2, 2.0f, t); a.fli(7, 4.0f, t); a.fli(8, 6.0f, t); a.fli(9, 16.0f, t)
    a.li(str, AtBanner); a.jal(2, "puts")

    a.label("main")
    a.li(str, AtPrompt); a.jal(2, "puts")
    a.jal(3, "getnum"); a.mv(n, v)
    a.li(led, 4); a.sw(led, Led, io)                          // blue: computing

    // ---- Leibniz: f10 = 4 * sum_{k=0}^{n-1} (-1)^k / (2k+1)
    a.fsgnj(3, 0, 0); a.fsgnj(4, 1, 1); a.li(k, 0)
    a.label("lz")
    a.bge(k, n, "lzdone")
    a.fdiv(5, 1, 4, Rm.RNE)                                   // 1 / (2k+1)
    a.andi(t, k, 1); a.bne(t, 0, "lzodd")
    a.fadd(3, 3, 5, Rm.RNE); a.jal(0, "lznext")
    a.label("lzodd")
    a.fsub(3, 3, 5, Rm.RNE)
    a.label("lznext")
    a.fadd(4, 4, 2, Rm.RNE); a.addi(k, k, 1); a.jal(0, "lz")
    a.label("lzdone")
    a.fmul(10, 3, 7, Rm.RNE)
    a.li(str, atLabel(0)); a.jal(2, "puts"); a.jal(8, "pfloat")

    // ---- Basel: f10 = sqrt(6 * sum_{k=1}^{n} 1/k^2)
    a.fsgnj(3, 0, 0); a.li(k, 1)
    a.label("bz")
    a.blt(n, k, "bzdone")
    a.fcvtsw(4, k, Rm.RNE); a.fmul(5, 4, 4, Rm.RNE); a.fdiv(5, 1, 5, Rm.RNE); a.fadd(3, 3, 5, Rm.RNE)
    a.addi(k, k, 1); a.jal(0, "bz")
    a.label("bzdone")
    a.fmul(3, 3, 8, Rm.RNE); a.fsqrt(10, 3, Rm.RNE)
    a.li(str, atLabel(1)); a.jal(2, "puts"); a.jal(8, "pfloat")

    // ---- Machin: f10 = 16 atan(1/5) - 4 atan(1/239), with min(n, MachinTerms) terms of each series
    a.mv(mt, n); a.li(t, MachinTerms); a.bge(t, n, "mtok"); a.mv(mt, t)
    a.label("mtok")
    a.li(t, 5); a.fcvtsw(11, t, Rm.RNE); a.fdiv(11, 1, 11, Rm.RNE); a.jal(7, "atan"); a.fsgnj(15, 12, 12)   // atan(1/5)
    a.li(t, 239); a.fcvtsw(11, t, Rm.RNE); a.fdiv(11, 1, 11, Rm.RNE); a.jal(7, "atan")                    // atan(1/239)
    a.fmul(16, 7, 12, Rm.RNE); a.fmsub(10, 9, 15, 16, Rm.RNE)                                             // 16 a5 - 4 a239 (fused)
    a.li(str, atLabel(2)); a.jal(2, "puts"); a.jal(8, "pfloat")

    // ---- the float nearest to pi
    a.fli(10, math.Pi.toFloat, t)
    a.li(str, atLabel(3)); a.jal(2, "puts"); a.jal(8, "pfloat")
    a.li(led, 2); a.sw(led, Led, io)                          // green: done
    a.jal(0, "main")

    // ---- atan: f12 = sum_{j=0}^{mt-1} (-1)^j f11^(2j+1) / (2j+1); return with x7
    a.label("atan")
    a.fsgnj(12, 0, 0); a.fsgnj(13, 11, 11); a.fmul(14, 11, 11, Rm.RNE); a.fsgnj(4, 1, 1); a.li(k, 0)
    a.label("aloop")
    a.bge(k, mt, "adone")
    a.fdiv(5, 13, 4, Rm.RNE)
    a.andi(t, k, 1); a.bne(t, 0, "aodd")
    a.fadd(12, 12, 5, Rm.RNE); a.jal(0, "anext")
    a.label("aodd")
    a.fsub(12, 12, 5, Rm.RNE)
    a.label("anext")
    a.fmul(13, 13, 14, Rm.RNE); a.fadd(4, 4, 2, Rm.RNE); a.addi(k, k, 1); a.jal(0, "aloop")
    a.label("adone")
    a.jalr(0, 7, 0)

    // ---- pfloat: print f10 (0 <= f10 < 256) as d.ddddddd rounded to 7 decimals, then "  0x" and its bits, CR LF.
    //      Return with x8.
    a.label("pfloat")
    a.fmvxw(b, 10)
    a.li(q, 0); a.beq(b, 0, "pfq")                            // +0.0
    a.srli(e, b, 23); a.andi(e, e, 255)                       // biased exponent
    a.li(t, 0x7fffff); a.and(m, b, t); a.li(t, 0x800000); a.or(m, m, t)   // significand with the hidden 1
    a.li(t, 150); a.sub(s, t, e)                              // value = m / 2^s
    a.li(t, 64); a.bgeu(s, t, "pfq")                          // below 2^-41: prints as 0
    a.li(t, 10000000); a.mul(lo, m, t); a.mulhu(hi, m, t)     // (hi:lo) = m * 10^7
    a.addi(t, s, -1); a.li(t2, 32); a.bgeu(t, t2, "pfrhi")    // + 2^(s-1): round half up
    a.li(rl, 1); a.sll(rl, rl, t); a.add(lo, lo, rl); a.sltu(rl, lo, rl); a.add(hi, hi, rl); a.jal(0, "pfsh")
    a.label("pfrhi")
    a.addi(t, t, -32); a.li(rl, 1); a.sll(rl, rl, t); a.add(hi, hi, rl)
    a.label("pfsh")                                           // q = (hi:lo) >> s   (16 <= s < 64)
    a.bgeu(s, t2, "pfshhi")
    a.srl(q, lo, s); a.sub(t, t2, s); a.sll(t, hi, t); a.or(q, q, t); a.jal(0, "pfq")
    a.label("pfshhi")
    a.addi(t, s, -32); a.srl(q, hi, t)
    a.label("pfq")                                            // q = round(value * 10^7)
    a.li(t, 10000000); a.divu(pv, q, t); a.remu(q, q, t)
    a.li(dv, 100); a.li(lead, 1); a.jal(4, "pdec")            // integer part
    a.li(ch, '.'); a.jal(1, "putc")
    a.mv(pv, q); a.li(dv, 1000000); a.li(lead, 0); a.jal(4, "pdec")   // 7 decimals
    for (c <- "  0x") { a.li(ch, c.toLong); a.jal(1, "putc") }
    a.mv(pv, b); a.jal(9, "phex")
    a.jal(6, "crlf")
    a.jalr(0, 8, 0)

    // ---- pdec: print pv with the digits of dv, dv/10, ..., 1; leading zeros skipped while lead = 1 (the last digit
    //      is always printed). Return with x4.
    a.label("pdec")
    a.divu(ch, pv, dv); a.mul(t, ch, dv); a.sub(pv, pv, t)
    a.li(t, 1); a.beq(dv, t, "pdout")
    a.bne(ch, 0, "pdout"); a.bne(lead, 0, "pdskip")
    a.label("pdout")
    a.li(lead, 0); a.addi(ch, ch, '0'); a.jal(1, "putc")
    a.label("pdskip")
    a.li(t, 10); a.divu(dv, dv, t); a.bne(dv, 0, "pdec")
    a.jalr(0, 4, 0)

    // ---- phex: print pv as 8 hex digits; return with x9
    a.label("phex")
    a.li(rl, 8)
    a.label("phloop")
    a.srli(ch, pv, 28); a.slli(pv, pv, 4)
    a.sltiu(t, ch, 10); a.addi(ch, ch, '0'); a.bne(t, 0, "phout"); a.addi(ch, ch, 'a' - '0' - 10)
    a.label("phout")
    a.jal(1, "putc")
    a.addi(rl, rl, -1); a.bne(rl, 0, "phloop")
    a.jalr(0, 9, 0)

    // ---- getnum: read an unsigned decimal number (up to MaxDigits digits) into v, echoing it; return with x3
    a.label("getnum")
    a.li(v, 0); a.li(nd, 0)
    a.label("gwait")
    a.lw(t, UartStat, io); a.andi(t, t, 2); a.beq(t, 0, "gwait")
    a.lw(ch, UartRx, io)
    a.li(t, 13); a.beq(ch, t, "genter")
    a.li(t, 10); a.beq(ch, t, "genter")
    a.li(t, 8); a.beq(ch, t, "gback")
    a.li(t, 127); a.beq(ch, t, "gback")
    a.addi(t, ch, -'0'); a.sltiu(t2, t, 10); a.beq(t2, 0, "gwait")   // not a digit: ignore
    a.sltiu(t2, nd, MaxDigits); a.beq(t2, 0, "gwait")                 // enough digits already
    a.li(t2, 10); a.mul(v, v, t2); a.add(v, v, t)                      // v = 10 v + digit
    a.addi(nd, nd, 1); a.jal(1, "putc"); a.jal(0, "gwait")
    a.label("gback")
    a.beq(nd, 0, "gwait")
    a.li(t, 10); a.divu(v, v, t); a.addi(nd, nd, -1)                  // v = v / 10
    a.li(ch, 8); a.jal(1, "putc"); a.li(ch, ' '); a.jal(1, "putc"); a.li(ch, 8); a.jal(1, "putc")   // "\b \b"
    a.jal(0, "gwait")
    a.label("genter")
    a.beq(nd, 0, "gwait")                                     // no digit yet
    a.jal(6, "crlf"); a.jalr(0, 3, 0)

    // ---- crlf: send CR LF; return with x6
    a.label("crlf")
    a.li(ch, 13); a.jal(1, "putc"); a.li(ch, 10); a.jal(1, "putc")
    a.jalr(0, 6, 0)
    // ---- putc: send x12 (waits until the transmitter is ready); return with x1
    a.label("putc")
    a.lw(t, UartStat, io); a.andi(t, t, 1); a.beq(t, 0, "putc")
    a.sw(ch, UartTx, io)
    a.jalr(0, 1, 0)
    // ---- puts: send the zero-terminated string at x11; return with x2
    a.label("puts")
    a.lbu(ch, 0, str); a.beq(ch, 0, "puts_end")
    a.jal(1, "putc")
    a.addi(str, str, 1)
    a.jal(0, "puts")
    a.label("puts_end")
    a.jalr(0, 2, 0)
    a
  }
}

/** Writes fpga/memory.hex (one word per line, with the disassembly as a comment) and fpga/memory.lst.
  * Run: sbt "runMain rv32i.EmitPiDemo"
  * then: sbt "runMain rv32i.EmitFpga fpga/memory.hex" && make -C fpga
  */
object EmitPiDemo extends App {
  import java.nio.file.{Files, Paths}
  val prog = FpgaPiDemo().words
  require(prog.length <= FpgaMap.RomWords, s"${prog.length} words, the ROM holds ${FpgaMap.RomWords}")
  val hex = prog.zipWithIndex.map { case (w, k) => f"$w%08x   # 0x${4 * k}%03x: ${Disasm(w, FpgaMap.RomBase + 4L * k)}" }
  Files.write(Paths.get("fpga", "memory.hex"), (hex.mkString("\n") + "\n").getBytes("UTF-8"))
  Files.write(Paths.get("fpga", "memory.lst"), Disasm.listing(prog, FpgaMap.RomBase).getBytes("UTF-8"))
  println(s"pi demo: ${prog.length} words of ${FpgaMap.RomWords}; fpga/memory.hex, fpga/memory.lst")
}
