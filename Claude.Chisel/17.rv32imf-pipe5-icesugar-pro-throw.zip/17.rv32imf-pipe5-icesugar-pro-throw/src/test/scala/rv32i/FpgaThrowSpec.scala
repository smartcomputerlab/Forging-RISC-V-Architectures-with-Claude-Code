package rv32i

import chisel3._
import chiseltest._
import org.scalatest.flatspec.AnyFlatSpec
import org.scalatest.matchers.should.Matchers

/** The throw demo (FpgaThrowDemo) on the whole FPGA system (5-stage pipelined RV32IMF core, ROM, RAM, LED, UART) with
  * a fast UART: V and A are typed on the serial line, and the transcript (prompts, echo, R, T, H) is checked character
  * for character against FpgaThrowDemo.transcript, the same computation done in Scala Float (IEEE single precision);
  * the LED colour is checked after each throw. */
class FpgaThrowSpec extends AnyFlatSpec with ChiselScalatestTester with Matchers {
  private val Div = 8

  private class Terminal(c: IceSugarSoC) {
    val received = new StringBuilder
    private var rxBusy = false; private var cnt = 0; private var bit = 0; private var shift = 0
    private var outBits: List[Boolean] = Nil; private var outCnt = 0
    def send(s: String): Unit = s.foreach { ch => outBits ++= (false :: (0 until 8).map(i => ((ch >> i) & 1) == 1).toList) :+ true }
    def idle: Boolean = outBits.isEmpty
    def step(): Unit = {
      if (outBits.nonEmpty) {
        c.io.uartRx.poke(outBits.head.B); outCnt += 1
        if (outCnt == Div) { outCnt = 0; outBits = outBits.tail }
      } else c.io.uartRx.poke(true.B)
      val tx = c.io.uartTx.peek().litToBoolean
      if (!rxBusy) { if (!tx) { rxBusy = true; cnt = Div + Div / 2 - 1; bit = 0; shift = 0 } }
      else if (cnt == 0) {
        if (bit < 8) { shift |= (if (tx) 1 << bit else 0); bit += 1; cnt = Div - 1 }
        else { tx shouldBe true; received += shift.toChar; rxBusy = false }
      } else cnt -= 1
      c.clock.step()
    }
    def runUntil(cond: => Boolean, max: Int): Unit = { var n = 0; while (!cond) { step(); n += 1; require(n < max, s"timeout, got: $received") } }
    /** Types `s` one character at a time, letting the program take each one (and echo it) before the next. */
    def typeKeys(s: String): Unit = s.foreach { ch => send(ch.toString); runUntil(idle, 1000); for (_ <- 0 until 200) step() }
  }

  private val E = "\b \b"
  /** (keys for V, echo, V in hundredths, keys for A, echo, A in hundredths) */
  private val cases = Seq(
    ("20\r", "20", 2000, "45\r", "45", 4500),                                         // blue: the longest throw
    ("20\r", "20", 2000, "30\r", "30", 3000),
    ("\r2x0\b5.5.\b\b.75\r", s"20${E}5.5${E}${E}.75", 2575, "60\r", "60", 6000),     // editing keys
    ("10\r", "10", 1000, "90\r", "90", 9000),                                         // straight up: R = 0
    ("12.34\r", "12.34", 1234, "100\r", "100", 10000),                                // red: angle out of range
    ("9999.99\r", "9999.99", 999999, "37.5\r", "37.5", 3750),
  )

  "The throw demo" should "read V and A on the UART, print R, T and H in single precision, and set the LED, in a loop" in {
    val prog = FpgaThrowDemo().words
    prog.length should be <= FpgaMap.RomWords
    test(new IceSugarSoC(prog, Div)).withAnnotations(TestUtil.waves) { c =>
      c.clock.setTimeout(0)
      val t = new Terminal(c)
      c.io.uartRx.poke(true.B)
      import FpgaThrowDemo._
      var expected = Banner + PromptV
      t.runUntil(t.received.toString == expected, 200000)
      c.io.led.expect(0.U)                                   // off before the first result
      for ((keysV, echoV, v100, keysA, echoA, a100) <- cases) {
        t.typeKeys(keysV)
        expected += echoV + "\r\n" + PromptA
        t.runUntil(t.received.toString == expected, 20000)
        t.typeKeys(keysA)
        expected += echoA + "\r\n" + transcript(v100, a100) + PromptV
        t.runUntil(t.received.toString == expected, 100000)
        withClue(s"V = $echoV, A = $echoA: ") { c.io.led.expect(led(a100).U) }
      }
      println(t.received.toString.replace("\r", ""))
    }
  }
}
