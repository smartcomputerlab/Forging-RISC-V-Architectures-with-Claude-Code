package rv32i

import chisel3._
import chiseltest._
import org.scalatest.flatspec.AnyFlatSpec
import org.scalatest.matchers.should.Matchers

/** The pi demo (FpgaPiDemo) on the whole FPGA system (pipelined RV32IMF core with the FPU, ROM, RAM, LED, UART) with a
  * fast UART: n is typed on the serial line and the transcript is checked character for character.
  * The expected lines come from an independent single-precision reference (numpy float32 for the arithmetic, Python
  * Decimal for the exact rounding to 7 decimals); larger n are checked against it at instruction level (README). */
class FpgaPiSpec extends AnyFlatSpec with ChiselScalatestTester with Matchers {
  private val Div = 8

  private class Terminal(c: IceSugarSoC) {
    val received = new StringBuilder
    private var rxBusy = false; private var cnt = 0; private var bit = 0; private var shift = 0
    private var outBits: List[Boolean] = Nil; private var outCnt = 0
    def send(s: String): Unit = s.foreach { ch => outBits ++= (false :: (0 until 8).map(i => ((ch >> i) & 1) == 1).toList) :+ true }
    def idle: Boolean = outBits.isEmpty
    def step(): Unit = {
      if (outBits.nonEmpty) {
        c.io.uartRx.poke(outBits.head.B); outCnt += 1
        if (outCnt == Div) { outCnt = 0; outBits = outBits.tail }
      } else c.io.uartRx.poke(true.B)
      val tx = c.io.uartTx.peek().litToBoolean
      if (!rxBusy) { if (!tx) { rxBusy = true; cnt = Div + Div / 2 - 1; bit = 0; shift = 0 } }
      else if (cnt == 0) {
        if (bit < 8) { shift |= (if (tx) 1 << bit else 0); bit += 1; cnt = Div - 1 }
        else { tx shouldBe true; received += shift.toChar; rxBusy = false }
      } else cnt -= 1
      c.clock.step()
    }
    def runUntil(cond: => Boolean, max: Int): Unit = { var n = 0; while (!cond) { step(); n += 1; require(n < max, s"timeout, got: $received") } }
    def typeKeys(s: String): Unit = s.foreach { ch => send(ch.toString); runUntil(idle, 1000); for (_ <- 0 until 200) step() }
  }

  private val E = "\b \b"
  private val Pi = "pi:      3.1415927  0x40490fdb\r\n"
  /** (keys typed, echo, the four result lines) */
  private val cases = Seq(
    ("2\r", "2",
      "Leibniz: 2.6666665  0x402aaaaa\r\nBasel:   2.7386129  0x402f456f\r\nMachin:  3.1405971  0x4048ff8b\r\n" + Pi),
    ("1x3\b2\r", s"13${E}2",                                  // an ignored key, Backspace: n = 12
      "Leibniz: 3.0584028  0x4043bcdf\r\nBasel:   3.0642877  0x40441d4a\r\nMachin:  3.1415927  0x40490fdb\r\n" + Pi),
  )

  "The pi demo" should "read n on the UART and print the three single-precision approximations of pi, in a loop" in {
    val prog = FpgaPiDemo().words
    prog.length should be <= FpgaMap.RomWords
    test(new IceSugarSoC(prog, Div)).withAnnotations(TestUtil.waves) { c =>
      c.clock.setTimeout(0)
      val t = new Terminal(c)
      c.io.uartRx.poke(true.B)
      var expected = FpgaPiDemo.Banner + FpgaPiDemo.Prompt
      t.runUntil(t.received.toString == expected, 100000)
      c.io.led.expect(0.U)                                   // off before the first number
      for ((keys, echo, lines) <- cases) {
        t.typeKeys(keys)
        t.runUntil(c.io.led.peek().litValue == 4, 20000)     // blue: computing
        expected += echo + "\r\n" + lines + FpgaPiDemo.Prompt
        t.runUntil(t.received.toString == expected, 100000)
        c.io.led.expect(2.U)                                 // green: done
      }
    }
  }
}
