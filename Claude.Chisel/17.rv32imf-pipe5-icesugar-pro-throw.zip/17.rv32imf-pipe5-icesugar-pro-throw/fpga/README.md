# RV32IMF 5-stage pipeline (Stage 10) on the iCESugar-Pro: throw distance

The Stage 10 core, unchanged, in the same small system as the earlier board projects (same memory map, RGB LED
register and UART), for the **iCESugar-Pro** (Lattice ECP5 **LFE5U-25F-6BG256C**). It is built with the open-source
flow Chisel → Yosys → nextpnr-ecp5 → ecppack. The core is RV32IMF with the 5-stage pipeline (IF, ID, EX, MEM, WB with
forwarding), the M extension, and the F extension: IEEE 754 single precision, with a sequential FPU in EX.

The program computes how far an object goes when it is **thrown with speed V (m/s) at angle A (degrees)**, with its
flight time and highest point, in single-precision floating point, in an endless loop.

A ready-made bitstream is included: `IceSugarProTop.bit`.

## 1. Quick start with the ready-made bitstream

1. Connect the iCESugar-Pro with a USB-C cable. The on-board iCELink shows up as a USB drive called **iCELink** and as
   a serial port (`/dev/ttyACM0` on Linux, `COMx` on Windows, `/dev/cu.usbmodem…` on macOS).
2. Open a terminal on the serial port at **115200 baud, 8N1**, no flow control, *before* programming (the banner is
   printed once, right after the FPGA starts):

   ```bash
   picocom -b 115200 /dev/ttyACM0
   ```

3. Program the FPGA: copy `IceSugarProTop.bit` onto the iCELink drive, or:

   ```bash
   icesprog IceSugarProTop.bit
   ```

4. Type the speed, Enter, the angle, Enter:

   ```
   RV32IMF 5-stage pipeline: throw distance on flat ground, no air drag, g = 9.81 m/s^2
   V (m/s) = 20
   A (deg) = 45
   distance  R = 40.77 m
   time      T = 2.88 s
   height    H = 10.19 m
   V (m/s) = 20
   A (deg) = 30
   distance  R = 35.31 m
   time      T = 2.04 s
   height    H = 5.10 m
   V (m/s) = 25.75
   A (deg) = 100
   A must be 0 to 90 degrees
   V (m/s) = 
   ```

- **Input:** V from 0 to 9999.99 m/s and A from 0 to 90 degrees, each with up to 4 digits before the decimal point and
  2 after it (`12`, `12.5` and `12.75` all work), then Enter. Backspace corrects (also the point), other keys are
  ignored, and Enter before any digit is ignored. An angle above 90 is refused with a message.
- **RGB LED:** **green** after a result, **blue** when A = 45 degrees (the angle of the longest throw for a given
  speed), **red** when the angle is out of range; off until the first result.
- **Time:** the computation takes well under a millisecond; what you see is the UART printing.

## 2. The physics

The object starts from the ground and lands at the same height, on flat ground, without air drag, with
g = 9.81 m/s². With the horizontal speed V cos A and the vertical speed V sin A:

| Line | Formula | Meaning |
|---|---|---|
| distance R | R = V² sin(2A) / g = 2 V² sin A cos A / g | where the object lands |
| time T | T = 2 V sin A / g | how long it is in the air |
| height H | H = V² sin² A / (2 g) | the highest point of the trajectory |

For a given speed, R is largest at 45° (R = V²/g), and two complementary angles give the same distance (30° and 60°:
35.31 m at 20 m/s), the steeper one with a longer, higher flight:

| V = 20 m/s | 15° | 30° | 45° | 60° | 75° | 90° |
|---|---|---|---|---|---|---|
| R (m) | 20.39 | 35.31 | 40.77 | 35.31 | 20.39 | 0.00 |
| T (s) | 1.06 | 2.04 | 2.88 | 3.53 | 3.94 | 4.08 |
| H (m) | 1.37 | 5.10 | 10.19 | 15.29 | 19.02 | 20.39 |

## 3. How the program computes it

Everything is single precision (binary32, round to nearest even), with the F instructions FCVT.S.W, FMUL, FADD, FDIV
and FMV:

1. **Input to floats.** Both numbers are read as integers in hundredths (`25.75` → 2575, with MUL by 10), then
   V = FCVT.S.W(V100) / 100.
2. **Angle reduction in integers.** sin and cos are needed only on [0°, 45°]: for A ≤ 45° the program uses
   x = A100 × (π / 18000) radians; above 45° it uses x = (9000 − A100) × (π / 18000), with sin A = cos(90° − A) and
   cos A = sin(90° − A). The subtraction is exact because it is done on integers, so A = 90° gives exactly cos A = 0
   and R = 0.
3. **sin and cos as polynomials** (Taylor series, Horner's scheme), on x ≤ π/4:
   - sin x = x (1 + x² (−1/6 + x² (1/120 + x² (−1/5040 + x² / 362880))))
   - cos x = 1 + x² (−1/2 + x² (1/24 + x² (−1/720 + x² (1/40320 − x² / 3628800))))

   The terms left out are below 2·10⁻⁹. The largest error over 0° to 45° in steps of 0.01° is 8·10⁻⁸ for sin and
   9·10⁻⁸ for cos, about one unit in the last place of a float.
4. **The formulas,** in this order: V², s·c, R = V² (2 s c) / g; T = (2 V s) / g; H = V² (s s) / (2 g).
5. **Printing without floating point.** FMV.X.W moves the bits of the result to an integer register. The value is
   m × 2^−s, with m the 24-bit significand and s = 150 − exponent. Then q = (100 m + 2^(s−1)) >> s is exactly the value
   × 100, rounded half up. It is printed as q / 100, '.', and two digits, with DIVU and REMU. (Valid below 2²⁴, which
   covers every result: the largest, R at V = 9999.99 and 45°, is about 1.02 × 10⁷ m.)

**Precision.** A float has 24 bits, about 7 significant decimal digits. Against the exact formulas in double precision,
over the 5,285 inputs that were tested, the largest relative error is 3.3·10⁻⁷ for R, 2.7·10⁻⁷ for T and 4.4·10⁻⁷ for
H. For everyday speeds every printed digit is right. For very large values the two decimals go beyond what single
precision holds: R = 10193660.00 m at 9999.99 m/s is correct to about 7 digits.

## 4. The system

| Block | Details |
|---|---|
| Clock | 25 MHz oscillator (P6) → ECP5 PLL (`pll25to12p5.v`) → **12.5 MHz** system clock |
| Reset | Held until the PLL locks, then for 15 cycles |
| Core | Stage 10 `Core`, reset pc 0x80000000: one instruction per clock, +1 per load-use, +2 per taken branch/jump, +33 per division, + the FPU latency (FADD/FSUB 5, FMUL and fused 29, FDIV/FSQRT 31, conversions 3–4) |
| Instruction ROM | **2 KiB (512 words)** at 0x80000000, a constant table in LUTs, built from the program at generation time |
| Data RAM | 4 KiB at 0x80010000 |
| LEDs | RGB LED: red B11, green A11, blue A12, active-high |
| UART | 115200 baud 8N1 on the iCELink USB serial port: FPGA TX = B9, FPGA RX = A9 |

Memory-mapped I/O at 0x10000000 (as in the earlier board projects):

| Address | Register | Access |
|---|---|---|
| 0x10000000 | LED: bits 2:0 = {blue, green, red}, 1 = on | read/write |
| 0x10000004 | UART_TX: write a byte to send (only when UART_STATUS bit 0 = 1) | write |
| 0x10000008 | UART_STATUS: bit 0 = transmitter ready, bit 1 = a received byte is waiting | read |
| 0x1000000C | UART_RX: the received byte; reading it clears UART_STATUS bit 1 | read |

As in the pi project, the system runs at **12.5 MHz** (the FPU makes the EX stage too long for a safe 25 MHz) and the
ROM holds **512 words**. The throw program is 482 words: about 220 of them build the strings in RAM and load the
float constants (the core cannot load data from the ROM), the rest is code.

Last build (Yosys 0.71, nextpnr-ecp5 0.11.1): 14,473 LUT4 (66 % of the logic cells), 740 CCU2C (carry), 3,711
flip-flops, 4 DP16KD block RAMs (the data RAM), 4 MULT18X18D (the integer multiplier), 1 PLL; maximum frequency
27.13 MHz, constraint 12.5 MHz: **PASS**, with more than a factor of two of margin.

## 5. Building it yourself

Tools:

- Java and sbt (as for the rest of the project), for the Chisel → Verilog step
- Yosys, nextpnr-ecp5 and ecppack: the simplest way is the YosysHQ **oss-cad-suite**
  (https://github.com/YosysHQ/oss-cad-suite-build): download, unpack, then `source oss-cad-suite/environment`
- to program: the iCELink drive (no tool needed), or `icesprog` (https://github.com/wuxx/icesugar, tools folder)

From the `fpga` folder:

```bash
make
```

This runs `sbt "runMain rv32i.EmitFpga"` (Chisel → `build/IceSugarProTop.v`, with the throw program in the ROM; the
program is also written to `program.hex` and `program.lst`), then Yosys, nextpnr-ecp5 and ecppack, and leaves
`build/IceSugarProTop.bit`.

```bash
make report
```

```bash
make YOWASP=1
```

`make report` shows the resource use and the maximum frequency. `make YOWASP=1` uses the Python builds of the tools
(`pip install yowasp-yosys yowasp-nextpnr-ecp5`) instead of oss-cad-suite.

Other programs:

| Command (from the project folder) | ROM contents |
|---|---|
| `sbt "runMain rv32i.EmitFpga"` | the throw program (`src/main/scala/rv32i/ThrowDemo.scala`) |
| `sbt "runMain rv32i.EmitFpga pi"` | the pi program of the previous project (`PiDemo.scala`) |
| `sbt "runMain rv32i.EmitFpga echo"` | the echo / RGB LED demo of the earlier board projects (`FpgaProgram`) |
| `sbt "runMain rv32i.EmitFpga /full/path/to/my_program.hex"` | your own program: one 32-bit word per line, at most 512 words |
| `sbt "runMain rv32i.EmitFpgaPinTest"` | the LED pin test (in `build_pintest/`) |

Then run `make` in `fpga`. `make` only regenerates the Verilog when a Scala file changed; after `make clean` it
regenerates the throw program, so run your `EmitFpga` command again first.

`sbt "runMain rv32i.EmitThrowDemo"` writes the throw program alone to `fpga/memory.hex` and `fpga/memory.lst`.

To change g (for example 1.62 m/s² for the Moon), edit `val G` in `ThrowDemo.scala` and the banner text.

## 6. How it was checked

- **Whole system, cycle by cycle** (`FpgaThrowSpec`, passing, about 2 hours in Treadle): core, FPU, ROM, RAM, LED, UART transmitter and receiver, with
  a fast UART. It types six throws: (20, 45), (20, 30), 25.75 typed with an empty Enter, an ignored key, Backspaces
  and a second point, then 60, (10, 90), (12.34, 100) refused, and (9999.99, 37.5). It checks the whole transcript
  character by character against the same computation written in Scala `Float` (IEEE single precision), and the LED
  colour after each throw (blue, green, green, green, red, green).
- **Instruction level:** the program's output was compared with an independent NumPy float32 model for 5,285 inputs:
  3,000 random V from 0 to 9999.99 with random A, 2,000 small V, a sweep from 0° to 90° in steps of 1° for V = 1, 20
  and 999.99, and edge cases (V = 0, V = 0.01, A = 0, 44.99, 45, 90, 90.01, 120). All transcripts and all LED colours are identical.
- **Accuracy:** the same 5,285 results against the exact formulas in double precision (section 3).
- **The system:** the SoC, the PLL and the core are unchanged from the pi project, where `FpgaSpec` (echo / LED demo,
  LED pin test, UART framing) and the Stage 10 core suites passed.
- **Hardware build:** synthesis, placement and routing complete, timing passes at 12.5 MHz (27.13 MHz maximum), and
  ecppack produces the bitstream.
