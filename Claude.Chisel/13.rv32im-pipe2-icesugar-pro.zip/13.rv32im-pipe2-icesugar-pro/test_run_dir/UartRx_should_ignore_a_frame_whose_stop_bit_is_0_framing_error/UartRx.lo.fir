FIRRTL version 1.2.0
circuit UartRx :
  module UartRx :
    input clock : Clock
    input reset : UInt<1>
    input io_rx : UInt<1> @[src/main/scala/rv32i/Uart.scala 38:14]
    output io_valid : UInt<1> @[src/main/scala/rv32i/Uart.scala 38:14]
    output io_data : UInt<8> @[src/main/scala/rv32i/Uart.scala 38:14]
    input io_take : UInt<1> @[src/main/scala/rv32i/Uart.scala 38:14]

    reg rxSync_REG : UInt<1>, clock with :
      reset => (UInt<1>("h0"), rxSync_REG) @[src/main/scala/rv32i/Uart.scala 44:31]
    reg rxSync : UInt<1>, clock with :
      reset => (UInt<1>("h0"), rxSync) @[src/main/scala/rv32i/Uart.scala 44:23]
    reg busy : UInt<1>, clock with :
      reset => (UInt<1>("h0"), busy) @[src/main/scala/rv32i/Uart.scala 45:23]
    reg count : UInt<4>, clock with :
      reset => (UInt<1>("h0"), count) @[src/main/scala/rv32i/Uart.scala 46:23]
    reg bitIdx : UInt<4>, clock with :
      reset => (UInt<1>("h0"), bitIdx) @[src/main/scala/rv32i/Uart.scala 47:23]
    reg shift : UInt<8>, clock with :
      reset => (UInt<1>("h0"), shift) @[src/main/scala/rv32i/Uart.scala 48:23]
    reg full : UInt<1>, clock with :
      reset => (UInt<1>("h0"), full) @[src/main/scala/rv32i/Uart.scala 49:23]
    reg data : UInt<8>, clock with :
      reset => (UInt<1>("h0"), data) @[src/main/scala/rv32i/Uart.scala 50:23]
    node _GEN_0 = mux(io_take, UInt<1>("h0"), full) @[src/main/scala/rv32i/Uart.scala 51:17 49:23 51:24]
    node _T = eq(busy, UInt<1>("h0")) @[src/main/scala/rv32i/Uart.scala 52:8]
    node _T_1 = eq(rxSync, UInt<1>("h0")) @[src/main/scala/rv32i/Uart.scala 53:10]
    node _GEN_1 = mux(_T_1, UInt<1>("h1"), busy) @[src/main/scala/rv32i/Uart.scala 53:19 54:12 45:23]
    node _GEN_2 = mux(_T_1, UInt<4>("hb"), count) @[src/main/scala/rv32i/Uart.scala 53:19 46:23 54:29]
    node _GEN_3 = mux(_T_1, UInt<1>("h0"), bitIdx) @[src/main/scala/rv32i/Uart.scala 53:19 47:23 54:64]
    node _T_2 = eq(count, UInt<1>("h0")) @[src/main/scala/rv32i/Uart.scala 57:16]
    node _T_3 = eq(bitIdx, UInt<4>("h8")) @[src/main/scala/rv32i/Uart.scala 58:19]
    node _GEN_4 = mux(rxSync, shift, data) @[src/main/scala/rv32i/Uart.scala 60:22 50:23 60:29]
    node _GEN_5 = mux(rxSync, UInt<1>("h1"), _GEN_0) @[src/main/scala/rv32i/Uart.scala 60:{22,44}]
    node _shift_T = bits(shift, 7, 1) @[src/main/scala/rv32i/Uart.scala 62:35]
    node _shift_T_1 = cat(rxSync, _shift_T) @[src/main/scala/rv32i/Uart.scala 62:21]
    node _bitIdx_T = add(bitIdx, UInt<1>("h1")) @[src/main/scala/rv32i/Uart.scala 63:26]
    node _bitIdx_T_1 = tail(_bitIdx_T, 1) @[src/main/scala/rv32i/Uart.scala 63:26]
    node _GEN_6 = mux(_T_3, UInt<1>("h0"), busy) @[src/main/scala/rv32i/Uart.scala 58:28 59:14 45:23]
    node _GEN_7 = mux(_T_3, _GEN_4, data) @[src/main/scala/rv32i/Uart.scala 50:23 58:28]
    node _GEN_8 = mux(_T_3, _GEN_5, _GEN_0) @[src/main/scala/rv32i/Uart.scala 58:28]
    node _GEN_9 = mux(_T_3, shift, _shift_T_1) @[src/main/scala/rv32i/Uart.scala 48:23 58:28 62:15]
    node _GEN_10 = mux(_T_3, bitIdx, _bitIdx_T_1) @[src/main/scala/rv32i/Uart.scala 47:23 58:28 63:16]
    node _GEN_11 = mux(_T_3, count, UInt<3>("h7")) @[src/main/scala/rv32i/Uart.scala 46:23 58:28 64:15]
    node _count_T = sub(count, UInt<1>("h1")) @[src/main/scala/rv32i/Uart.scala 66:34]
    node _count_T_1 = tail(_count_T, 1) @[src/main/scala/rv32i/Uart.scala 66:34]
    node _GEN_12 = mux(_T_2, _GEN_6, busy) @[src/main/scala/rv32i/Uart.scala 45:23 57:25]
    node _GEN_13 = mux(_T_2, _GEN_7, data) @[src/main/scala/rv32i/Uart.scala 50:23 57:25]
    node _GEN_14 = mux(_T_2, _GEN_8, _GEN_0) @[src/main/scala/rv32i/Uart.scala 57:25]
    node _GEN_15 = mux(_T_2, _GEN_9, shift) @[src/main/scala/rv32i/Uart.scala 48:23 57:25]
    node _GEN_16 = mux(_T_2, _GEN_10, bitIdx) @[src/main/scala/rv32i/Uart.scala 47:23 57:25]
    node _GEN_17 = mux(_T_2, _GEN_11, _count_T_1) @[src/main/scala/rv32i/Uart.scala 57:25 66:25]
    node _GEN_18 = mux(_T, _GEN_1, _GEN_12) @[src/main/scala/rv32i/Uart.scala 52:15]
    node _GEN_19 = mux(_T, _GEN_2, _GEN_17) @[src/main/scala/rv32i/Uart.scala 52:15]
    node _GEN_20 = mux(_T, _GEN_3, _GEN_16) @[src/main/scala/rv32i/Uart.scala 52:15]
    node _GEN_21 = mux(_T, data, _GEN_13) @[src/main/scala/rv32i/Uart.scala 52:15 50:23]
    node _GEN_22 = mux(_T, _GEN_0, _GEN_14) @[src/main/scala/rv32i/Uart.scala 52:15]
    node _GEN_23 = mux(_T, shift, _GEN_15) @[src/main/scala/rv32i/Uart.scala 52:15 48:23]
    io_valid <= full @[src/main/scala/rv32i/Uart.scala 68:12]
    io_data <= data @[src/main/scala/rv32i/Uart.scala 69:12]
    rxSync_REG <= mux(reset, UInt<1>("h1"), io_rx) @[src/main/scala/rv32i/Uart.scala 44:{31,31,31}]
    rxSync <= mux(reset, UInt<1>("h1"), rxSync_REG) @[src/main/scala/rv32i/Uart.scala 44:{23,23,23}]
    busy <= mux(reset, UInt<1>("h0"), _GEN_18) @[src/main/scala/rv32i/Uart.scala 45:{23,23}]
    count <= mux(reset, UInt<4>("h0"), _GEN_19) @[src/main/scala/rv32i/Uart.scala 46:{23,23}]
    bitIdx <= mux(reset, UInt<4>("h0"), _GEN_20) @[src/main/scala/rv32i/Uart.scala 47:{23,23}]
    shift <= mux(reset, UInt<8>("h0"), _GEN_23) @[src/main/scala/rv32i/Uart.scala 48:{23,23}]
    full <= mux(reset, UInt<1>("h0"), _GEN_22) @[src/main/scala/rv32i/Uart.scala 49:{23,23}]
    data <= mux(reset, UInt<8>("h0"), _GEN_21) @[src/main/scala/rv32i/Uart.scala 50:{23,23}]
