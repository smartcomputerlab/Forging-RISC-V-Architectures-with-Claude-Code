# RV32IM 2-stage pipeline (Stage 6) on the iCESugar-Pro: greatest common divisor

The Stage 6 core, unchanged, in the same small system as the earlier board projects (same memory map, RGB LED
register and UART), for the **iCESugar-Pro** (Lattice ECP5 **LFE5U-25F-6BG256C**). It is built with the open-source
flow Chisel → Yosys → nextpnr-ecp5 → ecppack. The core is RV32IM with a 2-stage pipeline: IF (fetch) and EX (decode,
register read, ALU, multiplier, divider, branches, data memory, CSRs and write-back), a parallel multiplier and a
sequential divider (33 cycles for DIVU / REMU).

The program computes the **greatest common divisor** of two numbers typed on the terminal with **Euclid's
algorithm**, prints every step, and shows the result on the RGB LED, in an endless loop.

A ready-made bitstream is included: `IceSugarProTop.bit`.

## 1. Quick start with the ready-made bitstream

1. Connect the iCESugar-Pro with a USB-C cable. The on-board iCELink shows up as a USB drive called **iCELink** and as
   a serial port (`/dev/ttyACM0` on Linux, `COMx` on Windows, `/dev/cu.usbmodem…` on macOS).
2. Open a terminal on the serial port at **115200 baud, 8N1**, no flow control, *before* programming (the banner is
   printed once, right after the FPGA starts):

   ```bash
   picocom -b 115200 /dev/ttyACM0
   ```

3. Program the FPGA: copy `IceSugarProTop.bit` onto the iCELink drive, or:

   ```bash
   icesprog IceSugarProTop.bit
   ```

4. Type a, Enter, b, Enter:

   ```
   RV32IM 2-stage pipeline: greatest common divisor, Euclid's algorithm with DIVU and REMU
   a = 84
   b = 36
   84 = 2 x 36 + 12
   36 = 3 x 12 + 0
   gcd(84, 36) = 12
   a = 35
   b = 64
   35 = 0 x 64 + 35
   64 = 1 x 35 + 29
   35 = 1 x 29 + 6
   29 = 4 x 6 + 5
   6 = 1 x 5 + 1
   5 = 5 x 1 + 0
   gcd(35, 64) = 1, coprime
   a = 0
   b = 0
   gcd(0, 0) is undefined
   a = 
   ```

- **Input:** a and b are 0 to 999999999 (up to 9 digits; further digits are ignored), each ended by Enter. Backspace
  corrects, other keys are ignored, and Enter before any digit is ignored.
- **RGB LED** (set when b is entered): **green** when a and b are coprime (gcd = 1), **blue** when they have a common
  divisor greater than 1, **red** for gcd(0, 0), which is undefined. Off until the first result.

## 2. The algorithm

Euclid's algorithm replaces (a, b) by (b, a mod b) until b is 0; the last non-zero value is the gcd. Each step prints
the division a = q × b + r, with q computed by **DIVU** and r by **REMU** (both on the sequential divider, which
freezes the pipeline for 33 cycles each):

```
x = a; y = b
while y != 0:
    q = x / y          DIVU
    r = x % y          REMU
    print "x = q x y + r"
    x = y; y = r
gcd = x                (gcd(a, 0) = a; gcd(0, 0) is undefined)
```

- If a < b, the first step only swaps them (35 = 0 × 64 + 35).
- The number of steps is at most about 45 for 9-digit numbers (the worst case is two consecutive Fibonacci numbers:
  gcd(832040, 514229) takes 28 steps).
- Numbers are printed in decimal with REMU / DIVU by 10 (digits stored in RAM, then sent most significant first), and
  read with MUL by 10 (v = 10 v + digit).

## 3. The system

| Block | Details |
|---|---|
| Clock | 25 MHz oscillator (P6) → ECP5 PLL (`pll25to12p5.v`) → **12.5 MHz** system clock |
| Reset | Held until the PLL locks, then for 15 cycles |
| Core | Stage 6 `Core`, reset pc 0x80000000: one instruction per clock, +1 per taken branch / jump (the fetched instruction is flushed), +33 per division (DIV, DIVU, REM, REMU) |
| Instruction ROM | **2 KiB (512 words)** at 0x80000000, a constant table in LUTs, built from the program at generation time |
| Data RAM | 4 KiB at 0x80010000, asynchronous read, byte write enables (distributed RAM in the logic cells) |
| LEDs | RGB LED: red B11, green A11, blue A12, active-high |
| UART | 115200 baud 8N1 on the iCELink USB serial port: FPGA TX = B9, FPGA RX = A9 |

Memory-mapped I/O at 0x10000000 (as in the earlier board projects):

| Address | Register | Access |
|---|---|---|
| 0x10000000 | LED: bits 2:0 = {blue, green, red}, 1 = on | read/write |
| 0x10000004 | UART_TX: write a byte to send (only when UART_STATUS bit 0 = 1) | write |
| 0x10000008 | UART_STATUS: bit 0 = transmitter ready, bit 1 = a received byte is waiting | read |
| 0x1000000C | UART_RX: the received byte; reading it clears UART_STATUS bit 1 | read |

In the 2-stage core, loads and stores reach the bus in EX, only for a valid instruction that does not trap, in the
single cycle it executes (never while the divider is busy). So a read of UART_RX, which consumes the byte, happens
exactly once.

Differences from the RV32IM 5-stage board project:

- **12.5 MHz instead of 25 MHz.** With only two stages, EX does everything in one clock cycle: decode, register read,
  ALU, data RAM, the branch decision and write-back. That path is long: at 25 MHz the first build reached only
  22.9 MHz (FAIL). At 12.5 MHz there is a safe margin. `mcycle` counts 12,500,000 per second.
- **ROM doubled to 512 words.** The GCD program is 309 words (the first 150 build the strings in RAM with `li`/`sw`). The memory
  map is unchanged.

Last build (Yosys 0.71, nextpnr-ecp5 0.11.1): 12,076 LUT4 (65 % of the logic cells, most of it the 512-word ROM table
and the EX stage), 303 CCU2C (carry), 1,608 flip-flops (1,024 of them the register file), 512 TRELLIS_DPR16X4
distributed-RAM cells (the 4 KiB data RAM, asynchronous read), 4 MULT18X18D (the multiplier), 1 PLL; maximum
frequency 23.22 MHz, constraint 12.5 MHz: **PASS**, with a margin of about 85 %.

## 4. Building it yourself

Tools:

- Java and sbt (as for the rest of the project), for the Chisel → Verilog step
- Yosys, nextpnr-ecp5 and ecppack: the simplest way is the YosysHQ **oss-cad-suite**
  (https://github.com/YosysHQ/oss-cad-suite-build): download, unpack, then `source oss-cad-suite/environment`
- to program: the iCELink drive (no tool needed), or `icesprog` (https://github.com/wuxx/icesugar, tools folder)

From the `fpga` folder:

```bash
make
```

This runs `sbt "runMain rv32i.EmitFpga"` (Chisel → `build/IceSugarProTop.v`, with the GCD program in the ROM; the
program is also written to `program.hex` and `program.lst`), then Yosys, nextpnr-ecp5 and ecppack, and leaves
`build/IceSugarProTop.bit`.

```bash
make report
```

```bash
make YOWASP=1
```

`make report` shows the resource use and the maximum frequency. `make YOWASP=1` uses the Python builds of the tools
(`pip install yowasp-yosys yowasp-nextpnr-ecp5`) instead of oss-cad-suite.

Other programs:

| Command (from the project folder) | ROM contents |
|---|---|
| `sbt "runMain rv32i.EmitFpga"` | the GCD program (`src/main/scala/rv32i/GcdDemo.scala`) |
| `sbt "runMain rv32i.EmitFpga echo"` | the echo / RGB LED demo of the earlier board projects (`FpgaProgram`) |
| `sbt "runMain rv32i.EmitFpga /full/path/to/my_program.hex"` | your own program: one 32-bit word per line, at most 512 words |
| `sbt "runMain rv32i.EmitFpgaPinTest"` | the LED pin test (in `build_pintest/`) |

Then run `make` in `fpga`. `make` only regenerates the Verilog when a Scala file changed; after `make clean` it
regenerates the GCD program, so run your `EmitFpga` command again first.

`sbt "runMain rv32i.EmitGcdDemo"` writes the GCD program alone to `fpga/memory.hex` and `fpga/memory.lst`.

For your own programs in C or assembly, compile for `-march=rv32im -mabi=ilp32`, linked at 0x80000000. The core cannot
load data from the ROM (Harvard), so strings and constant tables must be built in RAM at start-up, as the GCD program
does with `li`/`sw`.

## 5. How it was checked

- **Whole system, cycle by cycle** (`FpgaGcdSpec`): core, ROM, RAM, LED, UART transmitter and receiver, with a fast
  UART. It types six pairs: (84, 36), (35, 64), (0, 0), (17, 0) typed with an empty Enter, an ignored key and a
  Backspace, (987654321, 123456789) with a 10th digit that is ignored, and (4294967, 65536). It checks the whole
  transcript character by character against a model of Euclid's algorithm written independently in the test, and the
  LED colour after each pair (blue, green, red, blue, blue, green).
- **Instruction level:** the program's output was compared with an independent Python model for 3,212 pairs: edge
  cases (0, 1, a < b, equal values, Fibonacci neighbours, 999999999), 3,000 random pairs of 1 to 9 digits, and 200
  pairs with a known common factor (7, 12, 1000, 99991). All transcripts and all LED colours are identical.
- `FpgaSpec`: the echo / LED demo, the LED pin test and the UART receiver's framing check, on this system.
- **The core itself:** the 12 Stage 6 suites (in `src/test`), rerun in this project: 45 tests, all passing (unit
  tests of every block, lockstep program tests against the instruction-level reference model, timing, waveforms).
- **Hardware build:** synthesis, placement and routing complete, timing passes at 12.5 MHz, and ecppack produces the
  bitstream.
