# Design notes: Stage 6, 2-stage pipelined RV32IM core (IF / EX)

## Architecture

| Item | Choice |
|---|---|
| ISA | RV32IM (40 + 8 instructions) + Zicsr (6) + MRET and WFI, machine mode only |
| Microarchitecture | 2-stage pipeline: IF (fetch) and EX (decode, register read, execute, memory, write-back); the Stage 5 datapath in EX |
| Branch prediction | Static not-taken: fetch continues at pc + 4; a taken branch/jump, trap or MRET costs 1 bubble |
| Reset | pc = `0x80000000` (`Core(resetPc = ...)`), registers and CSRs = 0 |
| Memories | Harvard, zero-wait ports: instruction and data read data are combinational functions of the address; stores land at the clock edge under a 4-bit byte mask |
| System (`RV32ITestWrapper`) | `InstructionMemory` (ROM from a hex file at 0x80000000) + `DataMemory` (RAM, 256 words, initial content from a hex file, at 0x80010000) |
| Multiplication | Combinational ("parallel"): one shared 33 × 33 signed multiplier, operands extended by their sign (signed operand) or by 0 (unsigned); the low 64 bits of the product are exact for all four instructions. 1 cycle |
| Division | Sequential restoring divider on the operand magnitudes, one quotient bit per cycle, signs fixed at the end: 34 cycles per DIV/DIVU/REM/REMU, 2 for divide-by-zero and signed overflow (answered without iterating, as the spec's table requires). The core holds the pc while it waits |
| Interrupts | None |

## Stage progression

| Stage | Instructions | New hardware |
|---|---|---|
| 1 | R-type and I-type ALU (19) | ALU, register file, decoder, immediate generator |
| 2 | + loads, JALR (25) | Read-only data memory, load alignment, write-back mux, JALR |
| 3 | All of RV32I + Zicsr + MRET/WFI | Stores (byte strobes), branches, LUI/AUIPC/JAL, CSR file, precise exceptions |
| 4 | + MUL, MULH, MULHSU, MULHU | Combinational 33 × 33 multiplier |
| 5 | + DIV, DIVU, REM, REMU | Sequential divider; the core waits while it works |
| **6** | **Same ISA (RV32IM)** | **2-stage pipeline IF / EX: `IfEx` register, static not-taken prediction, flush on redirect, freeze on division** |
| 7 | Same ISA | 5-stage pipeline with forwarding and load-use stall (`rv32im-pipe5`) |
| 5 | + DIV, DIVU, REM, REMU | Sequential divider (34 cycles) |

Stage 5 is the Stage 4 core with a `DivUnit`. The core recognises all eight M instructions itself (OP opcode,
funct7 = 0000001) and overrides the decoder's "illegal" for those, so the Stage 3 `Decoder` and its tests are unchanged.
A division sends a request to the divider and waits (`divStall`): the pc is held, nothing is written, and the same
instruction stays on the fetch port. `busy` stays high through the divider's response cycle, so the held instruction
cannot start a second division. The division retires in the response cycle with the divider's result.

The pipelined versions of this core are the separate `rv32im-pipe2` (IF/EX) and `rv32im-pipe5` (IF/ID/EX/MEM/WB)
projects.

## Pipeline

```
            IF stage                       IfEx register                  EX stage
 fetchPc ──► imem ──► inst ──►  ┌ valid ┐  ──► Decoder, RegFile read, ImmGen
    ▲                           │ pc    │      Alu / Multiplier / DivUnit (33 cycles)
    │  +4 (predict not taken)   └ inst  ┘      dmem, CsrFile, write-back to RegFile
    └────────── redirect: nextPc (taken branch/jump, trap, MRET) ◄────────┘
```

| Event in EX | fetchPc | IfEx |
|---|---|---|
| Normal (incl. not-taken branch) | fetchPc + 4 | {valid, fetchPc, imem data} |
| Taken branch, JAL, JALR, trap, MRET (`redirect`) | nextPc (the target) | bubble (wrong-path instruction discarded) |
| DIV/DIVU/REM/REMU in progress (`divStall`) | hold | hold |

## Hazards

| Hazard | Handling |
|---|---|
| Data (RAW) | None possible: registers are read and written in EX, so the next instruction reads the value written at the end of the previous EX cycle. No forwarding, no interlock |
| Control | Resolved in EX; 1-cycle penalty for every taken branch, JAL, JALR, trap and MRET; not-taken branches are free |
| Structural (divider) | Both stages freeze while the divider works (33 cycles, 1 for divide-by-zero and overflow) |
| CSR / memory ordering | All CSR and memory accesses happen in EX, in program order; wrong-path instructions never reach EX |

## Execution rules

Every cycle EX does exactly one of:

1. **retire** (`trace.valid`): one instruction completes and its effects are visible at the edge;
2. **trap** (`trace.trap`): the instruction changes nothing except mepc, mcause, mtval, mstatus; fetch is redirected to mtvec;
3. **nothing** (both low): a bubble (after reset, or after a redirect) or a cycle waiting for the divider; no state
   changes (checked by assertions in `Core`).

Cycles per instruction: 1, plus 1 if the previous instruction redirected fetch, plus 33 for a regular
DIV/DIVU/REM/REMU (1 for divide-by-zero or overflow). The first instruction after reset arrives after one fill bubble.

Exception priority: illegal instruction (2) > ECALL (11) > EBREAK (3) > load misaligned (4) > store misaligned (6) >
instruction address misaligned (0).

## Choices made where the specification leaves an option

| Topic | Choice | Why |
|---|---|---|
| Misaligned loads/stores | Trap (cause 4 / 6, mtval = address) | Simplest correct option; allowed by the privileged spec |
| Misaligned branch/jump targets | Trap at the branch/jump (cause 0, mtval = target), rd not written | Required with IALIGN = 32 |
| EBREAK mtval | pc | Allowed (pc or 0) |
| ECALL mtval | 0 | Required |
| Illegal-instruction mtval | The instruction word | Allowed, helps debugging |
| FENCE | No-op | Single hart, in-order, no caches |
| FENCE.I | Illegal | Zifencei is not part of the ISA |
| WFI | No-op | No interrupts to wait for |
| mtvec | Direct mode only, low two bits read as 0 | WARL |
| mepc | Bits 1:0 read as 0 | IALIGN = 32 |
| misa | `0x40001100` (RV32, I, M), writes ignored | The whole M extension is implemented |
| Divider kill | `kill` tied to `trapNow` | A division never traps; it is a safety net for interrupts |
| Pipeline depth | 2 stages, register read and write-back in the same stage | Removes all data hazards: no forwarding logic needed |
| Branch resolution | In EX, target fetched in the next cycle (1 bubble) | Keeps the EX-to-imem path out of the critical path; static not-taken needs no predictor state |
| Bubble encoding | IfEx.valid = 0, EX executes `addi x0, x0, 0` and `retire` is gated | No side effect possible from a bubble |
| Instruction memory | Combinational (zero-wait) port, read in IF | Same memory interface and system as Stage 5 |
| mcycle while dividing | Counts the wait cycles | It measures time; minstret counts the division once |
| Multiplier structure | One 33 × 33 signed array for all four instructions | One array instead of four; maps onto DSP blocks on an FPGA (about 4 DSP48 on Xilinx 7-series) |
| mstatus | MIE (bit 3) and MPIE (bit 7) writable, MPP fixed to 11 | Machine mode only |
| mie | Only MSIE, MTIE, MEIE writable | WARL |
| mip, mstatush | Read 0, writes ignored | No interrupt sources |
| mcycle / minstret | Every clock / every retired instruction; a CSR write replaces one 32-bit half of the incremented value | Deterministic and easy to model |
| cycle/instret (user) | Read-only shadows; `time` not implemented (illegal) | No real-time clock |
| Unknown CSR / write to a read-only CSR | Illegal instruction | Required |
| Data memory | 256 words of registers with an initial content, accesses outside it read 0 and are not written | Simulates and synthesises with the same initial content; no access faults in this stage |

## Verification

- Unit tests: ALU, ImmGen, RegFile, Decoder (48 instructions with their control signals, 29 illegal encodings
  the decoder still rejects the 8 M encodings, all 128 opcodes), Multiplier (484 edge pairs, 2,000 random), DivUnit
  (1,024 edge cases, 2,000 random, latency, kill, handshake) and DivRef (the spec's table), CsrFile, InstructionMemory and DataMemory (byte strobes,
  outside accesses), the wrapper running `program.hex` on `data.hex`.
- Program tests (`CoreProgramSpec`), each in lockstep with `RefModel` (every retirement and trap compared field by
  field) and with final registers checked against independent constants: arithmetic and logic; loads and stores of
  every size; every branch both ways, JAL, JALR; dependency chains; loops in pure RV32I (gcd by subtraction, a sum,
  shift-and-add multiplication); the four multiplications on corner cases (MIN × −1, MIN × MIN, −1 × −1, large
  operands, rd = x0); 12! with MUL; the four divisions on the spec's corner cases with exact wait lengths; gcd with
  REM; MUL and DIV results used by the next instruction; Zicsr and all six exception types;
  3,000 random instructions including multiplications and divisions. `CoreDivSpec`: 40 division programs with exact wait
  lengths.
- Pipeline timing (`CoreTimingSpec`): the cycle count of all 56 instructions including every redirect bubble, and the
  wrong-path instruction behind a taken branch, a jump, a trap and MRET never takes effect.
- Planted bugs: no flush on a redirect (8 failing tests), no freeze while dividing (7 failing tests): both caught.
