package rv32i

import chisel3._
import chiseltest._
import org.scalatest.flatspec.AnyFlatSpec
import org.scalatest.matchers.should.Matchers

/** The GCD demo (FpgaGcdDemo) on the whole FPGA system (2-stage pipelined RV32IM core, ROM, RAM, LED, UART) with a
  * fast UART: a and b are typed on the serial line, the transcript (prompts, echo, Euclid's steps, the result) is
  * checked character for character against a model computed here, and the LED colour after each pair. */
class FpgaGcdSpec extends AnyFlatSpec with ChiselScalatestTester with Matchers {
  private val Div = 8

  private class Terminal(c: IceSugarSoC) {
    val received = new StringBuilder
    private var rxBusy = false; private var cnt = 0; private var bit = 0; private var shift = 0
    private var outBits: List[Boolean] = Nil; private var outCnt = 0
    def send(s: String): Unit = s.foreach { ch => outBits ++= (false :: (0 until 8).map(i => ((ch >> i) & 1) == 1).toList) :+ true }
    def idle: Boolean = outBits.isEmpty
    def step(): Unit = {
      if (outBits.nonEmpty) {
        c.io.uartRx.poke(outBits.head.B); outCnt += 1
        if (outCnt == Div) { outCnt = 0; outBits = outBits.tail }
      } else c.io.uartRx.poke(true.B)
      val tx = c.io.uartTx.peek().litToBoolean
      if (!rxBusy) { if (!tx) { rxBusy = true; cnt = Div + Div / 2 - 1; bit = 0; shift = 0 } }
      else if (cnt == 0) {
        if (bit < 8) { shift |= (if (tx) 1 << bit else 0); bit += 1; cnt = Div - 1 }
        else { tx shouldBe true; received += shift.toChar; rxBusy = false }
      } else cnt -= 1
      c.clock.step()
    }
    def runUntil(cond: => Boolean, max: Int): Unit = { var n = 0; while (!cond) { step(); n += 1; require(n < max, s"timeout, got: $received") } }
    /** Types `s` one character at a time, letting the program take each one (and echo it) before the next. */
    def typeKeys(s: String): Unit = s.foreach { ch => send(ch.toString); runUntil(idle, 1000); for (_ <- 0 until 200) step() }
  }

  private val E = "\b \b"
  /** (keys for a, echo, a, keys for b, echo, b) */
  private val cases = Seq(
    ("84\r", "84", 84L, "36\r", "36", 36L),                                // blue: gcd 12
    ("35\r", "35", 35L, "64\r", "64", 64L),                                // green: coprime (first step swaps them)
    ("0\r", "0", 0L, "0\r", "0", 0L),                                      // red: undefined
    ("\r1x2\b7\r", s"12${E}7", 17L, "0\r", "0", 0L),                       // empty Enter, ignored key, Backspace
    ("9876543210\r", "987654321", 987654321L, "123456789\r", "123456789", 123456789L),   // 10th digit ignored
    ("4294967\r", "4294967", 4294967L, "65536\r", "65536", 65536L),
  )

  "The GCD demo" should "read a and b on the UART, print Euclid's steps and gcd(a, b), and set the LED, in a loop" in {
    val prog = FpgaGcdDemo().words
    prog.length should be <= FpgaMap.RomWords
    test(new IceSugarSoC(prog, Div)).withAnnotations(TestUtil.waves) { c =>
      c.clock.setTimeout(0)
      val t = new Terminal(c)
      c.io.uartRx.poke(true.B)
      import FpgaGcdDemo._
      var expected = Banner + PromptA
      t.runUntil(t.received.toString == expected, 100000)
      c.io.led.expect(0.U)                                   // off before the first result
      for ((keysA, echoA, va, keysB, echoB, vb) <- cases) {
        t.typeKeys(keysA)
        expected += echoA + "\r\n" + PromptB
        t.runUntil(t.received.toString == expected, 20000)
        t.typeKeys(keysB)
        expected += echoB + "\r\n" + transcript(va, vb) + PromptA
        t.runUntil(t.received.toString == expected, 200000)
        withClue(s"gcd($va, $vb): ") { c.io.led.expect(led(va, vb).U) }
      }
      println(t.received.toString.replace("\r", ""))
    }
  }
}
