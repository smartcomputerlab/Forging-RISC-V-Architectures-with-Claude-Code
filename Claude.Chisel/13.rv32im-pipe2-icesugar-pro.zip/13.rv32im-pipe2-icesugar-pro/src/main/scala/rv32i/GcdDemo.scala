package rv32i

/** Greatest common divisor demo for the iCESugar-Pro system with the 2-stage pipelined RV32IM core (Stage 6).
  * In an endless loop:
  *
  *   a = 84              (typed on the UART terminal, echoed; Enter ends the number)
  *   b = 36
  *   84 = 2 x 36 + 12    (one line per step of Euclid's algorithm: q = a / b with DIVU, r = a % b with REMU)
  *   36 = 3 x 12 + 0
  *   gcd(84, 36) = 12
  *
  * a and b are 0..999999999 (up to 9 digits; further digits are ignored); Backspace (0x08 or 0x7f) removes the last
  * digit, other keys are ignored, Enter with no digit is ignored. gcd(a, 0) = a; gcd(0, 0) is undefined.
  * RGB LED (set as soon as b is entered): green when a and b are coprime (gcd = 1), blue when they have a common
  * divisor greater than 1, red for gcd(0, 0); off until the first result.
  */
object FpgaGcdDemo {
  import FpgaMap._
  val Banner    = "\r\nRV32IM 2-stage pipeline: greatest common divisor, Euclid's algorithm with DIVU and REMU\r\n"
  val PromptA   = "a = "
  val PromptB   = "b = "
  val Eq        = " = "
  val Times     = " x "
  val Plus      = " + "
  val GcdOpen   = "gcd("
  val Comma     = ", "
  val GcdClose  = ") = "
  val Coprime   = ", coprime"
  val Undefined = ") is undefined"
  val MaxDigits = 9
  val LedRed = 1; val LedGreen = 2; val LedBlue = 4

  /** The strings in RAM (the core cannot load data from the ROM), each at a word-aligned address. */
  private val strings = Seq(Banner, PromptA, PromptB, Eq, Times, Plus, GcdOpen, Comma, GcdClose, Coprime, Undefined)
  private val at: Map[String, Long] =
    strings.scanLeft(RamBase)((p, s) => p + ((s.length + 1 + 3) & ~3)).zip(strings).map(_.swap).toMap
  private val Buf = RamBase + 0x200                    // digits of a number being printed (least significant first)

  /** The exact text the program prints for one pair (a, b) after the echo of b and its CR LF. */
  def transcript(a: Long, b: Long): String = {
    val sb = new StringBuilder
    var (x, y) = (a, b)
    while (y != 0) { sb ++= s"$x$Eq${x / y}$Times$y$Plus${x % y}\r\n"; val r = x % y; x = y; y = r }
    if (a == 0 && b == 0) sb ++= s"$GcdOpen$a$Comma$b$Undefined\r\n"
    else sb ++= s"$GcdOpen$a$Comma$b$GcdClose$x" + (if (x == 1) Coprime else "") + "\r\n"
    sb.toString
  }
  def led(a: Long, b: Long): Int = { val g = BigInt(a).gcd(BigInt(b)); if (g == 0) LedRed else if (g == 1) LedGreen else LedBlue }

  def apply(): Asm = {
    val a = new Asm(RomBase)
    val io = 10; val str = 11; val ch = 12; val t = 13; val t2 = 5; val led = 14; val ten = 9
    val v = 20; val nd = 22                            // getnum: value, digit count; pdec: the value to print
    val A0 = 24; val B0 = 25; val x = 26; val y = 27; val q = 28; val r = 29; val p = 30
    // link registers: x1 putc, x2 puts, x3 getnum, x4 pdec, x6 crlf

    a.lui(io, IoBase >> 12)
    a.sw(0, Led, io)                                   // LED off until the first result
    for (s <- strings) {                               // strings are built in RAM with li / sw
      a.li(str, at(s))
      (s.getBytes("US-ASCII").toSeq :+ 0.toByte).grouped(4).zipWithIndex.foreach { case (g, k) =>
        a.li(t, g.zipWithIndex.map { case (b, j) => (b.toLong & 0xff) << (8 * j) }.sum); a.sw(t, 4L * k, str)
      }
    }
    a.li(ten, 10)
    def puts(s: String): Unit = { a.li(str, at(s)); a.jal(2, "puts") }
    def pdec(reg: Int): Unit = { a.mv(v, reg); a.jal(4, "pdec") }
    puts(Banner)

    a.label("main")
    puts(PromptA); a.jal(3, "getnum"); a.mv(A0, v)
    puts(PromptB); a.jal(3, "getnum"); a.mv(B0, v)
    // ---- Euclid's algorithm, printing one line per step: x = q * y + r
    a.mv(x, A0); a.mv(y, B0)
    a.label("step")
    a.beq(y, 0, "done")
    a.divu(q, x, y); a.remu(r, x, y)
    pdec(x); puts(Eq); pdec(q); puts(Times); pdec(y); puts(Plus); pdec(r); a.jal(6, "crlf")
    a.mv(x, y); a.mv(y, r)
    a.jal(0, "step")
    a.label("done")                                    // x = gcd(A0, B0)
    // ---- LED: red for gcd(0, 0), green for gcd = 1, blue otherwise
    a.li(led, LedRed); a.beq(x, 0, "setled")
    a.li(led, LedGreen); a.li(t, 1); a.beq(x, t, "setled")
    a.li(led, LedBlue)
    a.label("setled")
    a.sw(led, Led, io)
    // ---- "gcd(a, b) = g[, coprime]" or "gcd(0, 0) is undefined"
    puts(GcdOpen); pdec(A0); puts(Comma); pdec(B0)
    a.bne(x, 0, "defined")
    puts(Undefined); a.jal(0, "endline")
    a.label("defined")
    puts(GcdClose); pdec(x)
    a.li(t, 1); a.bne(x, t, "endline")
    puts(Coprime)
    a.label("endline")
    a.jal(6, "crlf")
    a.jal(0, "main")

    // ---- pdec: print v (unsigned 32-bit) in decimal: digits with REMU / DIVU into Buf, then sent in reverse;
    //      return with x4
    a.label("pdec")
    a.li(p, Buf)
    a.label("pd_div")
    a.remu(t, v, ten); a.divu(v, v, ten)
    a.addi(t, t, '0'); a.sb(t, 0, p); a.addi(p, p, 1)
    a.bne(v, 0, "pd_div")
    a.label("pd_out")
    a.addi(p, p, -1); a.lbu(ch, 0, p); a.jal(1, "putc")
    a.li(t, Buf); a.bne(p, t, "pd_out")
    a.jalr(0, 4, 0)

    // ---- getnum: read an unsigned decimal number (up to MaxDigits digits) into v, echoing it; return with x3
    a.label("getnum")
    a.li(v, 0); a.li(nd, 0)
    a.label("gwait")
    a.lw(t, UartStat, io); a.andi(t, t, 2); a.beq(t, 0, "gwait")
    a.lw(ch, UartRx, io)
    a.li(t, 13); a.beq(ch, t, "genter")
    a.li(t, 10); a.beq(ch, t, "genter")
    a.li(t, 8); a.beq(ch, t, "gback")
    a.li(t, 127); a.beq(ch, t, "gback")
    a.addi(t, ch, -'0'); a.sltiu(t2, t, 10); a.beq(t2, 0, "gwait")   // not a digit: ignore
    a.sltiu(t2, nd, MaxDigits); a.beq(t2, 0, "gwait")                 // enough digits already
    a.mul(v, v, ten); a.add(v, v, t)                                   // v = 10 v + digit
    a.addi(nd, nd, 1); a.jal(1, "putc"); a.jal(0, "gwait")
    a.label("gback")
    a.beq(nd, 0, "gwait")
    a.divu(v, v, ten); a.addi(nd, nd, -1)                              // v = v / 10
    a.li(ch, 8); a.jal(1, "putc"); a.li(ch, ' '); a.jal(1, "putc"); a.li(ch, 8); a.jal(1, "putc")   // "\b \b"
    a.jal(0, "gwait")
    a.label("genter")
    a.beq(nd, 0, "gwait")                              // no digit yet
    a.jal(6, "crlf"); a.jalr(0, 3, 0)

    // ---- crlf: send CR LF; return with x6
    a.label("crlf")
    a.li(ch, 13); a.jal(1, "putc"); a.li(ch, 10); a.jal(1, "putc")
    a.jalr(0, 6, 0)
    // ---- putc: send x12 (waits until the transmitter is ready); return with x1
    a.label("putc")
    a.lw(t, UartStat, io); a.andi(t, t, 1); a.beq(t, 0, "putc")
    a.sw(ch, UartTx, io)
    a.jalr(0, 1, 0)
    // ---- puts: send the zero-terminated string at x11; return with x2
    a.label("puts")
    a.lbu(ch, 0, str); a.beq(ch, 0, "puts_end")
    a.jal(1, "putc")
    a.addi(str, str, 1)
    a.jal(0, "puts")
    a.label("puts_end")
    a.jalr(0, 2, 0)
    a
  }
}

/** Writes fpga/memory.hex (one word per line, with the disassembly as a comment) and fpga/memory.lst.
  * Run: sbt "runMain rv32i.EmitGcdDemo"
  */
object EmitGcdDemo extends App {
  import java.nio.file.{Files, Paths}
  val prog = FpgaGcdDemo().words
  require(prog.length <= FpgaMap.RomWords, s"${prog.length} words")
  val hex = prog.zipWithIndex.map { case (w, k) => f"$w%08x   # 0x${4 * k}%03x: ${Disasm(w, FpgaMap.RomBase + 4L * k)}" }
  Files.createDirectories(Paths.get("fpga"))
  Files.write(Paths.get("fpga", "memory.hex"), (hex.mkString("\n") + "\n").getBytes("UTF-8"))
  Files.write(Paths.get("fpga", "memory.lst"), Disasm.listing(prog, FpgaMap.RomBase).getBytes("UTF-8"))
  println(s"gcd demo: ${prog.length} words of ${FpgaMap.RomWords}; fpga/memory.hex, fpga/memory.lst")
}
