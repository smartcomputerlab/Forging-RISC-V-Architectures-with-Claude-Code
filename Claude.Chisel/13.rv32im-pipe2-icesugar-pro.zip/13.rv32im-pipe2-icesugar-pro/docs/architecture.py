# Architecture diagram of the Stage 6 RV32IM 2-stage core (Defs.scala + Core.scala), as SVG.
W, H = 1820, 1290
out = []
def a(s): out.append(s)

C = dict(ink="#1f2937", mute="#6b7280", line="#374151", ifc="#e0f2fe", ifs="#0369a1", exc="#fef3c7", exs="#b45309",
         reg="#ede9fe", regs="#6d28d9", mem="#dcfce7", mems="#15803d", ctl="#fee2e2", ctls="#b91c1c", box="#ffffff",
         csr="#fce7f3", csrs="#be185d", ctrlw="#dc2626", bus="#1d4ed8")

a(f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" viewBox="0 0 {W} {H}" font-family="Inter, Helvetica, Arial, sans-serif" xml:space="preserve">')
a('''<defs>
<marker id="ar" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M0,0 L10,5 L0,10 z" fill="#374151"/></marker>
<marker id="arb" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M0,0 L10,5 L0,10 z" fill="#1d4ed8"/></marker>
<marker id="arr" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M0,0 L10,5 L0,10 z" fill="#dc2626"/></marker>
</defs>''')
a(f'<rect width="{W}" height="{H}" fill="#f8fafc"/>')

def text(x, y, s, size=13, weight=400, fill=C["ink"], anchor="start", italic=False, mono=False):
    fam = ' font-family="JetBrains Mono, Menlo, Consolas, monospace"' if mono else ''
    st = ' font-style="italic"' if italic else ''
    s = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    a(f'<text x="{x}" y="{y}" font-size="{size}" font-weight="{weight}" fill="{fill}" text-anchor="{anchor}" style="white-space:pre"{fam}{st}>{s}</text>')

def box(x, y, w, h, title, lines=(), fill=C["box"], stroke=C["line"], tsize=15, lsize=11.5, rx=8, mono=True):
    a(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{rx}" fill="{fill}" stroke="{stroke}" stroke-width="1.6"/>')
    text(x + w / 2, y + 21, title, tsize, 700, stroke, "middle")
    for k, l in enumerate(lines):
        text(x + 10, y + 42 + k * 15.5, l, lsize, 400, C["ink"], mono=mono)

def mux(x, y, w, h, title, inputs, stroke=C["line"]):
    a(f'<path d="M{x},{y} L{x+w},{y+14} L{x+w},{y+h-14} L{x},{y+h} Z" fill="#f1f5f9" stroke="{stroke}" stroke-width="1.6"/>')
    text(x + w / 2, y - 6, title, 11.5, 700, stroke, "middle")
    n = len(inputs)
    for k, l in enumerate(inputs):
        text(x + 5, y + (k + 1) * h / (n + 1) + 4, l, 10, 600, C["ink"], mono=True)

def wire(pts, label=None, lx=None, ly=None, color=None, dash=False, marker="ar", width=1.6, lanchor="start"):
    color = color or C["line"]
    d = " ".join(("M" if i == 0 else "L") + f"{x},{y}" for i, (x, y) in enumerate(pts))
    da = ' stroke-dasharray="5,4"' if dash else ''
    a(f'<path d="{d}" fill="none" stroke="{color}" stroke-width="{width}"{da} marker-end="url(#{marker})"/>')
    if label:
        text(lx if lx is not None else pts[0][0] + 4, ly if ly is not None else pts[0][1] - 5, label, 10.5, 600, color, lanchor, mono=True)

def dot(x, y, color=None): a(f'<circle cx="{x}" cy="{y}" r="3.2" fill="{color or C["line"]}"/>')

# ------------------------------------------------------------------ title and stage bands
text(30, 40, "RV32IM_Zicsr core — Stage 6: 2-stage pipeline (IF | EX), machine mode, precise traps", 24, 800)
text(30, 64, "package rv32i · Defs.scala (opcodes, causes, CSR map, enums, ports, Trace, IfEx) and Core.scala · Chisel 3.6", 13.5, 400, C["mute"])

a(f'<rect x="20" y="84" width="330" height="800" rx="12" fill="{C["ifc"]}" stroke="{C["ifs"]}" stroke-width="1.5" opacity="0.55"/>')
text(36, 108, "IF — fetch", 17, 800, C["ifs"])
a(f'<rect x="440" y="84" width="1360" height="800" rx="12" fill="{C["exc"]}" stroke="{C["exs"]}" stroke-width="1.5" opacity="0.45"/>')
text(456, 108, "EX — execute", 17, 800, C["exs"])

# ------------------------------------------------------------------ IF stage
mux(48, 170, 54, 150, "fetch mux", ["+4", "tgt", "hold"], C["ifs"])
box(140, 200, 150, 64, "fetchPc", ["RegInit(resetPc)"], C["reg"], C["regs"])
box(140, 300, 150, 44, "+ 4", [], "#ffffff", C["ifs"], tsize=16)
box(60, 430, 250, 140, "Instruction memory", ["InstrMemPort", "  addr  : Output UInt(32)", "  data  : Input  UInt(32)", "zero-wait: data = f(addr)", "(combinational ROM)"], C["mem"], C["mems"])
wire([(102, 245), (140, 232)])                                           # mux -> fetchPc
wire([(290, 232), (318, 232), (318, 322), (290, 322)], color=C["ifs"])   # fetchPc -> +4
wire([(140, 322), (24 + 6, 322), (30, 205), (48, 205)], "fetchPc+4", 34, 316, C["ifs"])
wire([(318, 232), (318, 400), (185, 400), (185, 430)], "addr", 192, 418)
dot(318, 232)
wire([(310, 500), (380, 500)], "data", 316, 494)                        # imem.data -> IfEx.inst
wire([(318, 232), (380, 232)], "pc", 330, 226)
text(36, 610, "Fetch continues at fetchPc + 4 every cycle", 12, 600, C["ifs"])
text(36, 628, "(static not-taken prediction).", 12, 400, C["ifs"])
text(36, 652, "redirect: fetchPc := nextPc, IfEx.valid := 0", 12, 400, C["ink"], mono=True)
text(36, 670, "divStall: fetchPc and IfEx hold", 12, 400, C["ink"], mono=True)
text(36, 688, "assert fetchPc(1,0) === 0", 12, 400, C["ink"], mono=True)

# ------------------------------------------------------------------ IfEx register
a(f'<rect x="380" y="150" width="44" height="690" rx="6" fill="{C["reg"]}" stroke="{C["regs"]}" stroke-width="2"/>')
text(402, 140, "IfEx", 15, 800, C["regs"], "middle")
for yy, l in ((205, "valid"), (237, "pc"), (505, "inst")):
    text(402, yy, l, 11, 700, C["regs"], "middle", mono=True)
a(f'<line x1="380" y1="215" x2="424" y2="215" stroke="{C["regs"]}" stroke-dasharray="3,3"/>')
a(f'<line x1="380" y1="250" x2="424" y2="250" stroke="{C["regs"]}" stroke-dasharray="3,3"/>')
text(402, 862, "class IfEx", 11, 600, C["regs"], "middle", mono=True)

# ------------------------------------------------------------------ EX: decoder, immgen, regfile
box(470, 130, 230, 300, "Decoder", [
    "inst[6:0] = Opcode:", " OP 0x33  OP_IMM 0x13", " LOAD 0x03  STORE 0x23", " BRANCH 0x63  JAL 0x6f", " JALR 0x67  LUI 0x37",
    " AUIPC 0x17  SYSTEM 0x73", " MISC_MEM 0x0f (FENCE)", "outputs:", " aluSrcA: ASrc  aluSrcImm", " aluOp: AluOp  immSel: ImmSel",
    " wbSel: WbSel  regWrite rd", " memRead memWrite memSize", " branch jal jalr csr", " ecall ebreak mret illegal"], "#fff7ed", C["exs"])
box(470, 460, 230, 104, "ImmGen", ["immSel: ImmSel", "  I | S | B | U | J", "sign-extended imm(32)"], "#fff7ed", C["exs"])
box(470, 600, 230, 116, "RV32M select", ["OP with funct7 = 0000001:", "  funct3 0-3 → isMul", "  funct3 4-7 → isDiv", "rd = inst[11:7]"], "#fff7ed", C["exs"])

wire([(424, 505), (450, 505), (450, 280), (470, 280)], "inst", 428, 499)
wire([(450, 505), (450, 512), (470, 512)])
wire([(450, 512), (450, 658), (470, 658)])
dot(450, 505); dot(450, 512)

box(740, 330, 190, 150, "RegFile", ["32 × 32, x0 = 0", "2 read ports (comb.)", "1 write port (edge)", "raddr1 = inst[19:15]", "raddr2 = inst[24:20]", "we = regWrite && retire"], C["reg"], C["regs"])
wire([(450, 445), (740, 445)], "rs1, rs2 fields", 560, 441)
dot(450, 445)

# ASrc mux and B mux
mux(980, 140, 46, 96, "ASrc", ["RS1", "PC", "ZERO"])
mux(980, 260, 46, 76, "b sel", ["rs2", "imm"])
wire([(930, 360), (945, 360), (945, 165), (980, 165)], "rs1v", 949, 250, C["bus"], marker="arb")
wire([(930, 420), (958, 420), (958, 280), (980, 280)], "rs2v", 934, 414, C["bus"], marker="arb")
wire([(424, 237), (436, 237), (436, 118), (965, 118), (965, 188), (980, 188)], "pc", 948, 134, C["bus"], marker="arb")
wire([(700, 520), (970, 520), (970, 318), (980, 318)], "imm", 712, 514, C["bus"], marker="arb")

box(1060, 140, 170, 196, "ALU", ["AluOp:", " ADD SUB SLL SLT", " SLTU XOR SRL SRA", " OR AND", "aluY = f(a, b)", "→ address, JALR target,", "  LUI/AUIPC result"], "#fff7ed", C["exs"])
wire([(1026, 188), (1060, 188)], "a", 1036, 182)
wire([(1026, 298), (1060, 298)], "b", 1036, 292)

# Multiplier, DivUnit
box(1060, 370, 170, 88, "Multiplier", ["33 × 33 combinational", "MUL MULH MULHSU MULHU", "1 cycle"], "#fff7ed", C["exs"])
box(1060, 476, 170, 116, "DivUnit(32)", ["sequential, 1 bit/cycle", "DIV DIVU REM REMU", "34 cyc; ÷0 / ovf: 2", "req resp busy kill", "stall until resp"], "#fff7ed", C["exs"])
wire([(958, 420), (958, 414), (1060, 414)], None, color=C["bus"], marker="arb")
wire([(958, 420), (958, 534), (1060, 534)], "rs1v, rs2v", 976, 470, C["bus"], marker="arb")
dot(958, 420)

# Branch unit
box(1270, 130, 210, 168, "Branch / jump unit", ["eq, lt (signed), ltu", "funct3: BEQ BNE BLT BGE", "        BLTU BGEU", "brTarget   = pc + imm", "jalrTarget = aluY & ~1", "ctlTaken = br | JAL | JALR", "fetchMis = target(1)"], "#fff7ed", C["exs"])

# Load/store align and data memory
box(1270, 330, 210, 140, "Load / store lanes", ["memSize 0 byte 1 half 2 word", "store: wdata in lanes,", "  wstrb = byte mask", "load: align + sign/zero", "misaligned → trap", "  (cause 4 / 6)"], "#fff7ed", C["exs"])
box(1270, 500, 210, 150, "Data memory", ["DataMemPort", "  addr re we wdata wstrb", "  rdata (word, comb.)", "zero-wait read,", "store at clock edge", "re/we gated by !trapNow"], C["mem"], C["mems"])
wire([(1230, 238), (1250, 238), (1250, 560), (1270, 560)], None, C["bus"], marker="arb")
text(1233, 232, "aluY", 10.5, 600, C["bus"], mono=True)
wire([(1375, 470), (1375, 500)], "wdata/wstrb", 1300, 490)
wire([(1420, 500), (1420, 470)], "rdata", 1426, 490)
wire([(1250, 238), (1250, 220), (1270, 220)], None, C["bus"], marker="arb")
dot(1250, 238)

# CSR file and trap logic
box(1520, 130, 260, 230, "CsrFile", ["Zicsr: CSRRW/S/C (+I)", "mstatus 300  misa 301", "mie 304  mtvec 305", "mstatush 310  mscratch 340", "mepc 341  mcause 342", "mtval 343  mip 344", "mcycle(h) b00/b80", "minstret(h) b02/b82", "cycle/instret c00..c82", "mvendorid..mhartid f11..f14", "misa = 0x40001100 (RV32IM)", "trapEnter, mretEnter, commit"], C["csr"], C["csrs"])
box(1520, 390, 260, 168, "Trap logic", ["trapNow = illegal | ecall |", "  ebreak | load/store/fetch", "  misaligned", "Cause → mcause:", " 0 instr misaligned 2 illegal", " 3 breakpoint 4 load mis.", " 6 store mis. 11 ECALL (M)", "div.kill := trapNow"], C["ctl"], C["ctls"])

# Write-back and next pc
mux(1540, 600, 60, 150, "WbSel", ["ALU", "MEM", "PC4", "CSR"], C["exs"])
text(1610, 622, "isMul → mul result", 11, 600, C["exs"], mono=True)
text(1610, 638, "isDiv → div result", 11, 600, C["exs"], mono=True)
text(1610, 654, "(last connect wins)", 11, 400, C["mute"], mono=True)
mux(1540, 790, 60, 92, "nextPc", ["mtvec", "pc", "mepc", "tgt/+4"], C["ctls"])
text(1616, 820, "priority: trap, divStall,", 11, 600, C["ctls"], mono=True)
text(1616, 836, "MRET, taken, pc + 4", 11, 600, C["ctls"], mono=True)
text(1616, 856, "redirect = valid & !divStall", 11, 400, C["ink"], mono=True)
text(1616, 872, "  & (trap | mret | taken)", 11, 400, C["ink"], mono=True)

wire([(1240, 238), (1240, 760), (1515, 760), (1515, 630), (1540, 630)], None, C["bus"], marker="arb")
wire([(1480, 600), (1490, 600), (1490, 660), (1540, 660)], None)
text(1486, 672, "load data", 10.5, 600, C["line"], "end", mono=True)
wire([(1520, 330), (1505, 330), (1505, 720), (1540, 720)], None, C["csrs"])
text(1490, 326, "rdata", 10.5, 600, C["csrs"], "end", mono=True)
# write-back to regfile (top return path)
wire([(1600, 675), (1808, 675), (1808, 89), (835, 89), (835, 330)], "wbData → rd (we = regWrite && retire)", 1300, 80, C["exs"])
# nextPc back to IF
wire([(1600, 836), (1608, 836), (1608, 878), (30, 878), (30, 245), (48, 245)], None, C["ctls"], marker="arr")
text(560, 873, "nextPc → fetch mux on redirect (taken branch, JAL, JALR, trap → mtvec, MRET → mepc): IfEx flushed, 1 bubble", 12, 700, C["ctls"])
wire([(1780, 300), (1794, 300), (1794, 770), (1525, 770), (1525, 812), (1540, 812)], None, C["csrs"])
text(1788, 765, "mtvec, mepc", 10.5, 600, C["csrs"], "end", mono=True)
# divStall control
wire([(1145, 592), (1145, 852), (75, 852), (75, 320)], None, C["ctrlw"], dash=True, marker="arr")
text(560, 846, "divStall → fetch mux: hold fetchPc and IfEx while the divider works (nothing retires)", 12, 700, C["ctrlw"])

# Trace
box(760, 600, 330, 222, "Trace (io.trace, one record per cycle)", [
    "valid    instruction retired", "trap     exception taken (cause 4b)", "pc, pcNext, inst",
    "rdAddr, rdData   (0 if no write)", "memAddr memRe memWe memSize", "memWdata (not in lanes)",
    "both low: bubble or divider wait", "retire = valid && !trap && !divStall", "assert !(valid && trap)",
    "assert trapping instr. changes nothing"], "#ffffff", C["ink"])

# ------------------------------------------------------------------ legend / Defs summary
y0 = 910
a(f'<rect x="20" y="{y0}" width="1780" height="360" rx="12" fill="#ffffff" stroke="#cbd5e1"/>')
text(36, y0 + 28, "Defs.scala at a glance", 17, 800)
cols = [
    ("object Opcode (inst[6:0])", ["LOAD     0x03", "MISC_MEM 0x0f", "OP_IMM   0x13", "AUIPC    0x17", "STORE    0x23", "OP       0x33", "LUI      0x37", "BRANCH   0x63", "JALR     0x67", "JAL      0x6f", "SYSTEM   0x73"]),
    ("object Cause (mcause, interrupt = 0)", ["0  InstrAddrMisaligned", "2  IllegalInstruction", "3  Breakpoint", "4  LoadAddrMisaligned", "6  StoreAddrMisaligned", "11 EcallFromM"]),
    ("ChiselEnum selects", ["ASrc   : RS1 | PC | ZERO", "WbSel  : ALU | MEM | PC4 | CSR", "ImmSel : I | S | B | U | J", "AluOp  : ADD SUB SLL SLT SLTU", "         XOR SRL SRA OR AND"]),
    ("Ports (Bundles)", ["InstrMemPort", "  addr Output(32)  data Input(32)", "DataMemPort", "  addr re we wdata wstrb  (out)", "  rdata                  (in)", "both zero-wait, combinational read;", "store written at the clock edge"]),
    ("Trace and IfEx", ["Trace: valid trap cause(4) pc pcNext", "  inst rdAddr(5) rdData memAddr", "  memRe memWe memSize(2) memWdata", "IfEx : valid pc inst", "  valid = 0: bubble after reset", "  or after a redirect (flush)"]),
]
xs = [36, 300, 640, 990, 1390]
for (t, ls), x in zip(cols, xs):
    text(x, y0 + 62, t, 13.5, 700, C["exs"])
    for k, l in enumerate(ls):
        text(x, y0 + 86 + k * 20, l, 12.5, 400, C["ink"], mono=True)
text(36, y0 + 345, "Timing: 1 instruction per cycle; taken branch / jump / trap / MRET: +1 bubble; DIV/REM: +33 cycles (÷0 and overflow: +1); MUL: no stall.", 12.5, 600, C["mute"])
a('</svg>')
open(__import__('os').path.join(__import__('os').path.dirname(__import__('os').path.abspath(__file__)), 'architecture.svg'), 'w').write("\n".join(out))
print("ok")
