# Stage 6 on the iCESugar-Pro FPGA: 2-stage pipelined RV32IM core computing the greatest common divisor

**FPGA version.** This is the Stage 6 project with a board system for the iCESugar-Pro (Lattice ECP5): ROM, RAM,
RGB LED and UART around the unchanged core, at 12.5 MHz. The default program reads two numbers on the serial terminal,
computes their greatest common divisor with Euclid's algorithm (DIVU and REMU), prints every step and shows the result
on the RGB LED (green: coprime, blue: common divisor, red: gcd(0, 0)), in an endless loop. See
**[`fpga/README.md`](fpga/README.md)**; the ready-made bitstream is `fpga/IceSugarProTop.bit`.

| File | Contents |
|---|---|
| `src/main/scala/rv32i/GcdDemo.scala` | the GCD program (`FpgaGcdDemo`, written with the project's assembler) and `EmitGcdDemo` |
| `src/main/scala/rv32i/IceSugarPro.scala` | the board system (`IceSugarSoC`, `IceSugarProTop`), `EmitFpga`, the echo demo, the LED pin test |
| `src/main/scala/rv32i/Uart.scala` | UART transmitter and receiver (115200 8N1) |
| `src/test/scala/rv32i/FpgaGcdSpec.scala`, `FpgaSpec.scala` | the whole system simulated cycle by cycle with a UART terminal model |
| `fpga/` | Makefile, pin constraints, PLL, `program.hex` / `memory.hex` (the GCD program), bitstream |

`Asm.scala` and `Disasm.scala` moved from the tests to `src/main` so that the programs can be generated with
`sbt runMain`. The rest of this README describes the core, as in Stage 6.

---

# Stage 6: 2-stage pipelined RV32IM core (IF / EX), parallel multiplication, sequential division, in Chisel 3

The sixth core of the series and the first pipelined one, in package `rv32i`: the Stage 5 RV32IM core (all RV32I
instructions, Zicsr, MRET, WFI, precise machine-mode exceptions, MUL/MULH/MULHSU/MULHU on a parallel multiplier,
DIV/DIVU/REM/REMU on a sequential divider) split into two pipeline stages:

| Stage | Work |
|---|---|
| IF (fetch) | `fetchPc` reads the instruction memory; the word and its pc go into the `IfEx` pipeline register |
| EX (execute) | Decode, register read, ALU / multiplier / divider, branches and jumps, data memory, CSRs, write-back |

- No data hazards: registers are read and written in the same stage, so no forwarding is needed.
- Branches are predicted not taken: a taken branch, JAL, JALR, a trap or MRET flushes the fetched instruction (1 bubble).
- A division freezes both stages for 33 cycles (1 for divide-by-zero and signed overflow).
- After reset, the first instruction reaches EX after one fill bubble.

The next stage of the series is the 5-stage pipeline (`rv32im-pipe5`).

It comes with a hex-file system (`RV32ITestWrapper`: instruction ROM + data RAM), unit tests for every block, lockstep
program tests against an instruction-level reference model, VCD waveforms with GTKWave sessions, and SystemVerilog
generation. See `DESIGN_NOTES.md` for the execution rules and every design choice.

## Instructions

| Group | Instructions |
|---|---|
| U-type, jumps | LUI AUIPC JAL JALR |
| Branches | BEQ BNE BLT BGE BLTU BGEU |
| Loads, stores | LB LH LW LBU LHU, SB SH SW |
| ALU immediate | ADDI SLTI SLTIU XORI ORI ANDI SLLI SRLI SRAI |
| ALU register | ADD SUB SLL SLT SLTU XOR SRL SRA OR AND |
| System | FENCE (no-op), ECALL, EBREAK, MRET, WFI (no-op), CSRRW CSRRS CSRRC CSRRWI CSRRSI CSRRCI |
| M extension | MUL MULH MULHSU MULHU (1 cycle, parallel); DIV DIVU REM REMU (34 cycles, sequential; 2 for x/0 and MIN/-1) |

Exceptions: illegal instruction, ECALL, EBREAK, misaligned load, misaligned store, misaligned
branch/jump target. CSRs: mstatus, misa (`0x40001100`: RV32IM), mie, mtvec, mscratch, mepc, mcause, mtval, mip, mcycle(h),
minstret(h), cycle(h), instret(h), mvendorid, marchid, mimpid, mhartid.

## Requirements

- Java 11+ (tested with 21) and sbt 1.10 (https://www.scala-sbt.org/download/); tests run on Treadle (no simulator to install)
- Optional: CIRCT firtool 1.37.0 on the PATH for firtool output from `Emit`; GTKWave to view waveforms

Pinned: Scala 2.13.12, Chisel 3.6.1 (+ chisel3-plugin), chiseltest 0.6.2, sbt 1.10.2.

## Commands

```bash
sbt test
```

```bash
sbt "testOnly rv32i.CoreProgramSpec"
```

Generate SystemVerilog for `Core` and `RV32ITestWrapper` (with `program.hex` and `data.hex`) into `generated/`:

```bash
sbt "runMain rv32i.Emit"
```

With firtool 1.37.0 on the PATH the output uses `-disable-all-randomization -strip-debug-info` (Linux shown; use
`firrtl-bin-macos-11.tar.gz` on macOS):

```bash
curl -sSL https://github.com/llvm/circt/releases/download/firtool-1.37.0/firrtl-bin-ubuntu-20.04.tar.gz | tar xz
export PATH="$PWD/firtool-1.37.0/bin:$PATH"
```

## Source files (`src/main/scala/rv32i/`)

| File | Contents |
|---|---|
| `Defs.scala` | Opcodes, exception causes, CSR addresses, `ASrc`/`WbSel`/`ImmSel`/`AluOp` enums, memory port, `Trace` and `IfEx` (pipeline register) bundles |
| `Decoder.scala` | RV32I + Zicsr + SYSTEM decoder; flags illegal encodings |
| `ImmGen.scala` | I/S/B/U/J immediates |
| `RegFile.scala` | 32 × 32 register file, 2 read ports, 1 write port, x0 hardwired to zero |
| `Alu.scala` | ADD, SUB, shifts, comparisons, logic |
| `CsrFile.scala` | Machine-mode CSRs, counters, trap entry and MRET |
| `Core.scala` | The 2-stage pipelined RV32IM core (top-level module): IF stage, `IfEx` register, EX stage, redirect and divider-stall control |
| `Multiplier.scala` | MUL, MULH, MULHSU, MULHU on one shared 33 × 33 signed multiplier (combinational) |
| `DivUnit.scala` | Sequential DIV, DIVU, REM, REMU (restoring, 1 bit per cycle) and `DivRef`, the software reference |
| `InstructionMemory.scala` | ROM from a hex file, mapped at 0x80000000 |
| `DataMemory.scala` | RAM with byte strobes and an initial content from a hex file, mapped at 0x80010000 |
| `RV32ITestWrapper.scala` | Core + instruction memory + data memory |
| `RefModel.scala` | Instruction-level reference model (`RefModel`) and sparse memory (`SimMemory`) |
| `Emit.scala` | SystemVerilog generation |

Project root: `program.hex` (demo: dot product of two arrays from `data.hex` with MUL, stored and reloaded,
MULH/MULHU/MULHSU corner cases, then DIV/REM/DIVU/REMU including divide-by-zero and signed overflow),
`data.hex`, and `tools/rv32im_filter.py` (GTKWave translate filter process: any instruction word as assembly).

## Tests (`src/test/scala/rv32i/`)

| Suite | What it checks |
|---|---|
| `AluSpec` | Every ALU operation on all pairs of 22 edge values and 3,000 random operand pairs |
| `ImmGenSpec` | All five immediate formats on 500 random instructions per format |
| `RegFileSpec` | x0 hardwired to zero, all 31 registers, write enable, old value during a write |
| `DecoderSpec` | All 48 RV32I/Zicsr/SYSTEM instructions with their control signals, 29 illegal encodings (the decoder itself still rejects the 8 M encodings: the core accepts the multiplications), all 128 major opcodes |
| `MultiplierSpec` | MUL/MULH/MULHSU/MULHU on 484 edge pairs and 2,000 random pairs against BigInt |
| `DivRefSpec`, `DivUnitSpec` | The division reference against the spec's table; the divider on 1,024 edge cases and 2,000 random ones, exact latency, kill, handshake |
| `CoreDivSpec` | 40 division programs on the core with exact wait lengths, a division result used by the next division, rd = x0 |
| `CsrFileSpec` | CSRRW/RS/RC, misa, mhartid, WARL masks, illegal accesses, counters, trap entry and MRET |
| `MemorySpec` | Instruction memory mapping, hex parsing, data RAM byte strobes and outside accesses, `program.hex` on the wrapper |
| `CoreProgramSpec` | Lockstep against `RefModel`: arithmetic, loads/stores, branches/jumps, dependency chains, RV32I loops, the 4 multiplications on corner cases, 12! with MUL, the 4 divisions on corner cases, gcd with REM, MUL/DIV results used immediately, Zicsr and all six exception types, 3,000 random instructions (incl. multiplications and divisions) |
| `CoreTimingSpec` | Pipeline timing of all 56 instructions: 1 cycle each, +1 bubble after every taken branch/jump/trap/MRET, DIV/DIVU/REM/REMU 34 cycles (2 for divide-by-zero and overflow); the wrong-path instruction behind a taken branch, a jump, a trap and MRET has no effect |
| `WaveformSpec` | Seven demos that write VCDs and GTKWave sessions to `waves/` |

Test helpers: `Asm.scala` (two-pass assembler with labels), `CoreSim.scala` (lockstep harness), `Disasm.scala`,
`Gtkw.scala` (GTKWave session writer) and `TestUtil.scala` (the `WAVES` switch).

## Interface of `Core`

```scala
class Core(resetPc: Long = 0x80000000L, hartId: Int = 0) extends Module {
  val io = IO(new Bundle {
    val imem  = new InstrMemPort   // addr out, data in (combinational)
    val dmem  = new DataMemPort    // addr, re, we, wdata, wstrb out; rdata in (combinational, aligned word)
    val trace = Output(new Trace)  // EX stage: one retirement or trap per cycle, or neither (bubble / divider wait)
  })
}
```

## Waveforms with GTKWave

```bash
sbt "testOnly rv32i.WaveformSpec"
```

| Demo | Contents |
|---|---|
| `waves/stage6_demo/` | `program.hex` + `data.hex` on `RV32ITestWrapper` (dot product with MUL, then divisions) |
| `waves/div_rem/` | DIV, REM, DIVU waiting 33 cycles each, divide-by-zero and overflow (1 cycle each), MUL in one cycle |
| `waves/div_unit/` | The divider alone: request, 32 iterations, response (`divunit.gtkw`) |
| `waves/mul/` | The four multiplications on corner values, each in one cycle |
| `waves/upper_jumps/` | LUI, AUIPC, all six branches (taken and not taken), JAL |
| `waves/load_store_branch/` | A loop with stores, loads of every size, a call and a return |
| `waves/trap/` | ECALL and an illegal instruction (FENCE.I): trap to the handler, mcause/mepc, MRET |

Each folder holds the VCD, `core.gtkw` (session), `inst.filter` (instruction words as assembly), `mulfn.filter`
(MUL / MULH / MULHSU / MULHU), `divop.filter` (DIV / DIVU / REM / REMU), `divstate.filter` (IDLE / BUSY / DONE)
and `program.lst`.
Open from the project root:

```bash
gtkwave waves/stage6_demo/RV32ITestWrapper.vcd waves/stage6_demo/core.gtkw
```

```bash
gtkwave waves/div_rem/Core.vcd waves/div_rem/core.gtkw
```

Groups in `core.gtkw`: Clock; IF stage (`fetchPc`, fetched word as assembly); IF/EX pipeline register (`ifex_valid`
(0 = bubble), `ifex_pc`, `ifex_inst`); EX stage (`inst` as assembly and hex, a bubble shows as `nop (bubble)`,
`brTaken`, `ctlTaken`, `redirect`, `nextPc`); Multiplier (`isMul`, function by name, operands, 66-bit product, result); Divider stall (`isDiv`,
`divStall`); Divider (request, operation by name, state IDLE/BUSY/DONE, iteration `count`, partial quotient and remainder,
divisor, signs, response); Retire / trap (valid, trap, cause, rd, rd value); Data memory (load, store, address, read/write data,
byte strobes); Registers x1..x15 (signed decimal); CSRs (mtvec, mepc, mcause, mcycle, minstret).

Reading the pipeline: a word fetched in one cycle is in `ifex_inst` and executes in the next. When `redirect` is high,
`ifex_valid` drops to 0 in the next cycle (the wrong-path word is discarded) and `fetchPc` jumps to the target.
Reading a division in `div_rem`: `isDiv` rises, `divStall` stays high while `state` = BUSY and `count` runs 0…31
(meanwhile `fetchPc` and the IF/EX register hold their values), `io_resp_valid` pulses in the DONE cycle, and `io_trace_valid` retires the division
in that same cycle.

A VCD for any test: `WAVES=1 sbt test` (files in `test_run_dir/<test name>/`). Assembly on any instruction signal:
in GTKWave, Data Format → Translate Filter Process → `tools/rv32im_filter.py` (make it executable first).
